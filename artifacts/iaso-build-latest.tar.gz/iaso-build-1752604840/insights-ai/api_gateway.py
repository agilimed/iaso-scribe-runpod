"""
Scalable API Gateway for NexusCare AI Platform
Designed for chatbots, virtual assistants, agents, and future AI applications
Event-driven architecture with plugin system for extensibility
"""

import os
import asyncio
import uuid
from typing import Optional, Dict, List, Any, Union, Callable
from datetime import datetime
from enum import Enum
from abc import ABC, abstractmethod
import json

from fastapi import FastAPI, Depends, HTTPException, WebSocket, BackgroundTasks
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
import httpx
from aiokafka import AIOKafkaProducer, AIOKafkaConsumer
import redis.asyncio as redis
from qdrant_client import QdrantClient

# Add shared modules
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shared.security import setup_security, verify_token, limiter
from shared.config.dual_mode_config import config

# Service Discovery Registry
class ServiceRegistry:
    """Dynamic service registry for scalability"""
    
    def __init__(self):
        self.services = {
            # Core AI Services
            "clinical_ai": {
                "url": os.getenv("CLINICAL_AI_URL", "http://localhost:8002"),
                "type": "http",
                "capabilities": ["entity_extraction", "clinical_nlp"]
            },
            "text_to_sql": {
                "url": os.getenv("IASOQL_URL", "http://localhost:8008"),
                "type": "http",
                "capabilities": ["sql_generation", "query_optimization"]
            },
            "embeddings": {
                "url": os.getenv("EMBEDDINGS_URL", "localhost:50051"),
                "type": "grpc",
                "capabilities": ["text_embeddings", "similarity"]
            },
            "terminology": {
                "url": os.getenv("TERMINOLOGY_URL", "http://localhost:8001"),
                "type": "http",
                "capabilities": ["concept_search", "terminology_mapping"]
            },
            
            # LLM Services
            "slm_service": {
                "url": os.getenv("SLM_SERVICE_URL", "http://localhost:8007"),
                "type": "http",
                "capabilities": ["text_generation", "summarization", "qa"]
            },
            
            # Future Services (placeholder)
            "voice_recognition": {
                "url": os.getenv("VOICE_URL", "http://localhost:8009"),
                "type": "http",
                "capabilities": ["speech_to_text", "voice_commands"],
                "status": "planned"
            },
            "vision_ai": {
                "url": os.getenv("VISION_URL", "http://localhost:8010"),
                "type": "http",
                "capabilities": ["medical_imaging", "document_ocr"],
                "status": "planned"
            }
        }
    
    def get_service(self, capability: str) -> Optional[Dict]:
        """Get service by capability"""
        for name, service in self.services.items():
            if capability in service.get("capabilities", []):
                return {**service, "name": name}
        return None
    
    def register_service(self, name: str, config: Dict):
        """Register new service dynamically"""
        self.services[name] = config

# Event Types for async processing
class EventType(str, Enum):
    # Core Events
    TEXT_RECEIVED = "text.received"
    ENTITIES_EXTRACTED = "entities.extracted"
    SQL_GENERATED = "sql.generated"
    EMBEDDINGS_CREATED = "embeddings.created"
    
    # Conversation Events
    CONVERSATION_STARTED = "conversation.started"
    CONVERSATION_MESSAGE = "conversation.message"
    CONVERSATION_ENDED = "conversation.ended"
    
    # Agent Events
    AGENT_TASK_CREATED = "agent.task.created"
    AGENT_TASK_COMPLETED = "agent.task.completed"
    AGENT_ACTION_REQUIRED = "agent.action.required"
    
    # System Events
    SERVICE_HEALTH_CHECK = "service.health.check"
    CACHE_INVALIDATED = "cache.invalidated"
    MODEL_UPDATED = "model.updated"

# Base Plugin Interface
class AIPlugin(ABC):
    """Base class for AI service plugins"""
    
    @abstractmethod
    async def process(self, context: Dict) -> Dict:
        """Process request and return results"""
        pass
    
    @abstractmethod
    def get_capabilities(self) -> List[str]:
        """Return list of capabilities this plugin provides"""
        pass

# Conversation Context Manager
class ConversationManager:
    """Manages conversation state for chatbots and assistants"""
    
    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self.ttl = 3600  # 1 hour default TTL
    
    async def create_session(self, user_id: str) -> str:
        """Create new conversation session"""
        session_id = str(uuid.uuid4())
        session_key = f"session:{session_id}"
        
        session_data = {
            "user_id": user_id,
            "created_at": datetime.utcnow().isoformat(),
            "messages": [],
            "context": {},
            "agent_state": None
        }
        
        await self.redis.setex(
            session_key,
            self.ttl,
            json.dumps(session_data)
        )
        
        return session_id
    
    async def add_message(self, session_id: str, role: str, content: Dict):
        """Add message to conversation history"""
        session_key = f"session:{session_id}"
        session_data = await self.get_session(session_id)
        
        if session_data:
            session_data["messages"].append({
                "role": role,
                "content": content,
                "timestamp": datetime.utcnow().isoformat()
            })
            
            # Keep last 20 messages for context
            if len(session_data["messages"]) > 20:
                session_data["messages"] = session_data["messages"][-20:]
            
            await self.redis.setex(
                session_key,
                self.ttl,
                json.dumps(session_data)
            )
    
    async def get_session(self, session_id: str) -> Optional[Dict]:
        """Get session data"""
        session_key = f"session:{session_id}"
        data = await self.redis.get(session_key)
        return json.loads(data) if data else None
    
    async def update_context(self, session_id: str, context: Dict):
        """Update conversation context"""
        session_data = await self.get_session(session_id)
        if session_data:
            session_data["context"].update(context)
            await self.redis.setex(
                f"session:{session_id}",
                self.ttl,
                json.dumps(session_data)
            )

# Agent Orchestrator
class AgentOrchestrator:
    """Orchestrates AI agents for complex tasks"""
    
    def __init__(self, service_registry: ServiceRegistry):
        self.registry = service_registry
        self.active_agents = {}
    
    async def create_agent(self, agent_type: str, config: Dict) -> str:
        """Create new AI agent"""
        agent_id = str(uuid.uuid4())
        
        agent = {
            "id": agent_id,
            "type": agent_type,
            "config": config,
            "state": "initialized",
            "created_at": datetime.utcnow().isoformat(),
            "tasks": []
        }
        
        self.active_agents[agent_id] = agent
        return agent_id
    
    async def assign_task(self, agent_id: str, task: Dict) -> Dict:
        """Assign task to agent"""
        if agent_id not in self.active_agents:
            raise ValueError(f"Agent {agent_id} not found")
        
        agent = self.active_agents[agent_id]
        task_id = str(uuid.uuid4())
        
        task_data = {
            "id": task_id,
            "type": task.get("type"),
            "input": task.get("input"),
            "status": "pending",
            "created_at": datetime.utcnow().isoformat()
        }
        
        agent["tasks"].append(task_data)
        agent["state"] = "working"
        
        # Process task based on type
        result = await self._process_agent_task(agent, task_data)
        
        task_data["status"] = "completed"
        task_data["result"] = result
        task_data["completed_at"] = datetime.utcnow().isoformat()
        
        return task_data
    
    async def _process_agent_task(self, agent: Dict, task_data: Dict) -> Dict:
        """Process agent task based on type"""
        task_type = task_data.get("type")
        task_input = task_data.get("input")
        
        if task_type == "medical_research":
            # Extract entities, search literature, summarize
            entities = await self._call_clinical_service(task_input.get("query", ""))
            rag_results = await self._search_qdrant(
                await self._generate_embeddings(task_input.get("query", "")),
                "medical_knowledge"
            )
            summary = await self._call_slm_service({
                "task": "summarize",
                "context": rag_results,
                "entities": entities
            })
            return {
                "entities": entities,
                "sources": rag_results,
                "summary": summary
            }
        
        elif task_type == "patient_analysis":
            # Analyze patient data across multiple dimensions
            clinical_data = await self._call_clinical_service(task_input.get("patient_data", ""))
            sql_queries = await self._call_iasoql_service(
                f"Find all data for patient {task_input.get('patient_id')}"
            )
            return {
                "clinical_analysis": clinical_data,
                "data_queries": sql_queries
            }
        
        else:
            return {"error": f"Unknown task type: {task_type}"}

# Main Gateway with Plugin Architecture
class ScalableAPIGateway:
    """
    Scalable API Gateway with plugin architecture
    Supports chatbots, virtual assistants, agents, and custom AI applications
    """
    
    def __init__(self):
        # Core components
        self.service_registry = ServiceRegistry()
        self.http_client = httpx.AsyncClient(timeout=30.0)
        self.qdrant_client = QdrantClient(
            url=os.getenv("QDRANT_URL", "http://localhost:6333"),
            api_key=os.getenv("QDRANT_API_KEY", "")
        )
        
        # Redis for session management
        self.redis_client = None
        
        # Kafka for event streaming
        self.kafka_producer = None
        self.kafka_consumer = None
        
        # Conversation and agent management
        self.conversation_manager = None
        self.agent_orchestrator = AgentOrchestrator(self.service_registry)
        
        # Plugin system
        self.plugins: Dict[str, AIPlugin] = {}
        
        # WebSocket connections for real-time
        self.active_connections: Dict[str, WebSocket] = {}
    
    async def initialize(self):
        """Initialize gateway components"""
        # Initialize Redis
        self.redis_client = redis.Redis(
            host=os.getenv("REDIS_HOST", "localhost"),
            port=int(os.getenv("REDIS_PORT", 6379)),
            decode_responses=True
        )
        
        self.conversation_manager = ConversationManager(self.redis_client)
        
        # Initialize Kafka
        self.kafka_producer = AIOKafkaProducer(
            bootstrap_servers=os.getenv("KAFKA_BROKERS", "localhost:9092"),
            value_serializer=lambda v: json.dumps(v).encode()
        )
        await self.kafka_producer.start()
        
        # Load default plugins
        await self._load_default_plugins()
    
    async def shutdown(self):
        """Cleanup resources"""
        await self.http_client.aclose()
        await self.kafka_producer.stop()
        if self.kafka_consumer:
            await self.kafka_consumer.stop()
    
    async def _load_default_plugins(self):
        """Load default AI plugins"""
        # TODO: Implement plugin loading
        pass
    
    async def publish_event(self, event_type: EventType, data: Dict):
        """Publish event to Kafka for async processing"""
        event = {
            "id": str(uuid.uuid4()),
            "type": event_type,
            "timestamp": datetime.utcnow().isoformat(),
            "data": data
        }
        
        await self.kafka_producer.send(
            "ai-events",
            value=event
        )
    
    async def process_conversation_message(
        self,
        session_id: str,
        message: str,
        context: Optional[Dict] = None
    ) -> Dict:
        """
        Process message in conversation context
        Suitable for chatbots and virtual assistants
        """
        # Get or create session
        session = await self.conversation_manager.get_session(session_id)
        if not session:
            return {"error": "Session not found"}
        
        # Add user message
        await self.conversation_manager.add_message(
            session_id,
            "user",
            {"text": message}
        )
        
        # Publish event
        await self.publish_event(
            EventType.CONVERSATION_MESSAGE,
            {
                "session_id": session_id,
                "message": message,
                "user_id": session["user_id"]
            }
        )
        
        # Determine intent and route appropriately
        intent = await self._determine_intent(message, session)
        
        # Process based on intent
        response = await self._process_by_intent(intent, message, session)
        
        # Add assistant response
        await self.conversation_manager.add_message(
            session_id,
            "assistant",
            response
        )
        
        # Update context
        if context:
            await self.conversation_manager.update_context(session_id, context)
        
        return response
    
    async def _determine_intent(self, message: str, session: Dict) -> Dict:
        """Determine user intent using NLU"""
        # Simple intent detection - in production, use proper NLU
        message_lower = message.lower()
        
        if any(word in message_lower for word in ["sql", "query", "find", "show"]):
            return {"type": "query", "confidence": 0.8}
        elif any(word in message_lower for word in ["diagnose", "symptoms", "condition"]):
            return {"type": "clinical", "confidence": 0.9}
        elif any(word in message_lower for word in ["help", "what", "how"]):
            return {"type": "qa", "confidence": 0.7}
        elif any(word in message_lower for word in ["summarize", "summary"]):
            return {"type": "summarization", "confidence": 0.85}
        else:
            return {"type": "general", "confidence": 0.5}
    
    async def _process_by_intent(
        self,
        intent: Dict,
        message: str,
        session: Dict
    ) -> Dict:
        """Process message based on intent"""
        intent_type = intent["type"]
        
        if intent_type == "query":
            # Generate SQL query
            service = self.service_registry.get_service("sql_generation")
            if service:
                result = await self._call_service(service, {
                    "text": message,
                    "dialect": "clickhouse",
                    "schema_context": session.get("context", {}),
                    "include_explanation": True
                })
                return {
                    "type": "sql_response",
                    "sql": result.get("sql"),
                    "explanation": result.get("explanation"),
                    "confidence": result.get("confidence", 0.0),
                    "intent": intent
                }
        
        elif intent_type == "clinical":
            # Process clinical query
            service = self.service_registry.get_service("entity_extraction")
            if service:
                result = await self._call_service(service, {
                    "text": message,
                    "enable_medcat": True,
                    "enable_clinical_bert": True
                })
                return {
                    "type": "clinical_response",
                    "entities": result.get("entities", []),
                    "summary": result.get("summary"),
                    "confidence": result.get("confidence", 0.0),
                    "intent": intent
                }
        
        elif intent_type == "qa":
            # Question answering using SLM service
            service = self.service_registry.get_service("qa")
            if service:
                # Include conversation history for context
                history = session.get("messages", [])[-5:]  # Last 5 messages
                result = await self._call_service(service, {
                    "prompt": message,
                    "context": json.dumps(history),
                    "max_tokens": 500,
                    "temperature": 0.7
                })
                return {
                    "type": "qa_response",
                    "answer": result.get("text", result.get("response", "")),
                    "model": result.get("model"),
                    "intent": intent
                }
        
        elif intent_type == "summarization":
            # Summarization using SLM service
            service = self.service_registry.get_service("summarization")
            if service:
                result = await self._call_service(service, {
                    "prompt": f"Summarize the following: {message}",
                    "max_tokens": 200,
                    "temperature": 0.3
                })
                return {
                    "type": "summary_response",
                    "summary": result.get("text", result.get("response", "")),
                    "intent": intent
                }
        
        else:
            # General conversation - use SLM for response
            service = self.service_registry.get_service("text_generation")
            if service:
                result = await self._call_service(service, {
                    "prompt": message,
                    "max_tokens": 150,
                    "temperature": 0.8
                })
                return {
                    "type": "general_response",
                    "text": result.get("text", "I understand you're asking about: " + message),
                    "intent": intent,
                    "suggestions": [
                        "Ask me to find patient data",
                        "Request a clinical summary",
                        "Get help with medical queries"
                    ]
                }
            else:
                return {
                    "type": "general_response",
                    "text": "I understand you're asking about: " + message,
                    "intent": intent,
                    "suggestions": [
                        "Ask me to find patient data",
                        "Request a clinical summary",
                        "Get help with medical queries"
                    ]
                }
    
    async def _call_service(self, service: Dict, payload: Dict) -> Dict:
        """Call a registered service"""
        try:
            if service["type"] == "http":
                # Determine endpoint based on service
                endpoint = "/process"  # default
                if service["name"] == "text_to_sql":
                    endpoint = "/generate"
                elif service["name"] == "slm_service":
                    endpoint = "/generate"
                elif service["name"] == "terminology":
                    endpoint = "/search"
                
                response = await self.http_client.post(
                    service["url"] + endpoint,
                    json=payload
                )
                response.raise_for_status()
                return response.json()
            elif service["type"] == "grpc":
                # For embeddings service - use HTTP endpoint for now
                if "embeddings" in service["name"]:
                    response = await self.http_client.post(
                        "http://localhost:8050/embeddings",  # HTTP wrapper
                        json={"text": payload.get("text", "")}
                    )
                    response.raise_for_status()
                    return response.json()
                return {}
            else:
                return {}
        except Exception as e:
            print(f"Service call error: {e}")
            return {"error": str(e)}
    
    async def create_agent_task(
        self,
        user_id: str,
        task_type: str,
        parameters: Dict
    ) -> Dict:
        """
        Create an autonomous agent task
        For complex multi-step operations
        """
        # Create agent based on task type
        agent_config = {
            "user_id": user_id,
            "task_type": task_type,
            "parameters": parameters,
            "max_steps": parameters.get("max_steps", 10)
        }
        
        agent_id = await self.agent_orchestrator.create_agent(
            task_type,
            agent_config
        )
        
        # Publish event
        await self.publish_event(
            EventType.AGENT_TASK_CREATED,
            {
                "agent_id": agent_id,
                "user_id": user_id,
                "task_type": task_type
            }
        )
        
        # Start task processing
        task_result = await self.agent_orchestrator.assign_task(
            agent_id,
            {
                "type": task_type,
                "input": parameters
            }
        )
        
        return {
            "agent_id": agent_id,
            "task_id": task_result["id"],
            "status": task_result["status"],
            "initial_result": task_result.get("result")
        }
    
    async def _call_clinical_service(self, text: str) -> Dict:
        """Call clinical AI service for entity extraction"""
        service = self.service_registry.get_service("entity_extraction")
        if service:
            return await self._call_service(service, {
                "text": text,
                "enable_medcat": True,
                "enable_clinical_bert": True
            })
        return {}
    
    async def _call_iasoql_service(self, text: str) -> Dict:
        """Call IasoQL service for SQL generation"""
        service = self.service_registry.get_service("sql_generation")
        if service:
            return await self._call_service(service, {
                "text": text,
                "dialect": "clickhouse",
                "include_explanation": True
            })
        return {}
    
    async def _call_slm_service(self, request: Dict) -> Dict:
        """Call SLM service for text generation"""
        service = self.service_registry.get_service("text_generation")
        if service:
            task = request.get("task", "generate")
            prompt = ""
            
            if task == "summarize":
                context = json.dumps(request.get("context", {}))
                entities = json.dumps(request.get("entities", []))
                prompt = f"Summarize the following medical research findings:\nContext: {context}\nEntities: {entities}"
            else:
                prompt = request.get("prompt", "")
            
            return await self._call_service(service, {
                "prompt": prompt,
                "max_tokens": 500,
                "temperature": 0.7
            })
        return {}
    
    async def _generate_embeddings(self, text: str) -> List[float]:
        """Generate embeddings using BGE-M3"""
        service = self.service_registry.get_service("text_embeddings")
        if service:
            result = await self._call_service(service, {"text": text})
            return result.get("embeddings", [0.0] * 1024)
        # Mock fallback
        import numpy as np
        return np.random.randn(1024).tolist()
    
    async def _search_qdrant(self, embeddings: List[float], collection: str) -> List[Dict]:
        """Search Qdrant vector database"""
        try:
            results = self.qdrant_client.search(
                collection_name=collection,
                query_vector=embeddings,
                limit=5
            )
            return [
                {
                    "score": r.score,
                    "payload": r.payload
                }
                for r in results
            ]
        except Exception as e:
            print(f"Qdrant search error: {e}")
            return []
    
    async def handle_websocket(self, websocket: WebSocket, client_id: str):
        """Handle WebSocket connections for real-time communication"""
        await websocket.accept()
        self.active_connections[client_id] = websocket
        
        try:
            # Create session for this connection
            session_id = await self.conversation_manager.create_session(client_id)
            
            # Send welcome message
            await websocket.send_json({
                "type": "welcome",
                "session_id": session_id,
                "timestamp": datetime.utcnow().isoformat()
            })
            
            # Handle messages
            while True:
                data = await websocket.receive_json()
                
                if data.get("type") == "message":
                    # Process conversation message
                    response = await self.process_conversation_message(
                        session_id,
                        data.get("text", ""),
                        data.get("context")
                    )
                    
                    await websocket.send_json({
                        "type": "response",
                        "data": response,
                        "timestamp": datetime.utcnow().isoformat()
                    })
                
                elif data.get("type") == "agent_task":
                    # Create agent task
                    result = await self.create_agent_task(
                        client_id,
                        data.get("task_type"),
                        data.get("parameters", {})
                    )
                    
                    await websocket.send_json({
                        "type": "agent_created",
                        "data": result,
                        "timestamp": datetime.utcnow().isoformat()
                    })
        
        except Exception as e:
            print(f"WebSocket error: {e}")
        finally:
            del self.active_connections[client_id]

# Request/Response Models for different use cases
class ChatbotRequest(BaseModel):
    """Request model for chatbot interactions"""
    session_id: Optional[str] = None
    message: str
    context: Optional[Dict] = None
    streaming: bool = False

class AgentRequest(BaseModel):
    """Request model for agent creation"""
    task_type: str = Field(..., description="Type of agent task")
    parameters: Dict = Field(default_factory=dict)
    async_callback: Optional[str] = None

class BatchRequest(BaseModel):
    """Request model for batch processing"""
    items: List[Dict]
    processing_type: str
    parallel: bool = True

# FastAPI Application
app = FastAPI(
    title="NexusCare Scalable AI Gateway",
    description="Unified gateway for AI services, chatbots, agents, and assistants",
    version="3.0.0"
)

# Apply security
setup_security(
    app,
    allowed_origins=os.getenv("ALLOWED_ORIGINS", "http://localhost:3000").split(","),
    enable_auth=True,
    rate_limit="1000/hour"
)

# Initialize gateway
gateway = ScalableAPIGateway()

@app.on_event("startup")
async def startup():
    await gateway.initialize()

@app.on_event("shutdown")
async def shutdown():
    await gateway.shutdown()

# Chatbot endpoints
@app.post("/api/v1/chat")
@limiter.limit("200/minute")
async def chat_endpoint(
    request: ChatbotRequest,
    token_payload: dict = Depends(verify_token)
):
    """
    Chatbot conversation endpoint
    Maintains conversation context across messages
    """
    # Create session if not provided
    if not request.session_id:
        request.session_id = await gateway.conversation_manager.create_session(
            token_payload["sub"]
        )
    
    response = await gateway.process_conversation_message(
        request.session_id,
        request.message,
        request.context
    )
    
    return {
        "session_id": request.session_id,
        "response": response,
        "timestamp": datetime.utcnow().isoformat()
    }

# Agent endpoints
@app.post("/api/v1/agents")
@limiter.limit("50/minute")
async def create_agent(
    request: AgentRequest,
    background_tasks: BackgroundTasks,
    token_payload: dict = Depends(verify_token)
):
    """
    Create autonomous AI agent for complex tasks
    """
    result = await gateway.create_agent_task(
        token_payload["sub"],
        request.task_type,
        request.parameters
    )
    
    # If callback URL provided, notify when complete
    if request.async_callback:
        background_tasks.add_task(
            notify_completion,
            request.async_callback,
            result
        )
    
    return result

# WebSocket endpoint for real-time communication
@app.websocket("/ws/{client_id}")
async def websocket_endpoint(
    websocket: WebSocket,
    client_id: str
):
    """
    WebSocket endpoint for real-time chatbot/assistant interactions
    """
    await gateway.handle_websocket(websocket, client_id)

# Batch processing endpoint
@app.post("/api/v1/batch")
@limiter.limit("10/minute")
async def batch_process(
    request: BatchRequest,
    token_payload: dict = Depends(verify_token)
):
    """
    Batch processing for multiple items
    Useful for bulk operations
    """
    results = []
    
    if request.parallel:
        # Process in parallel
        tasks = []
        for item in request.items:
            # Create async tasks based on processing type
            pass
        results = await asyncio.gather(*tasks)
    else:
        # Process sequentially
        for item in request.items:
            # Process each item
            pass
    
    return {
        "processed": len(results),
        "results": results
    }

# Service discovery endpoint
@app.get("/api/v1/services")
async def list_services(
    token_payload: dict = Depends(verify_token)
):
    """List available AI services and their capabilities"""
    return {
        "services": gateway.service_registry.services,
        "timestamp": datetime.utcnow().isoformat()
    }

# Health check with service status
@app.get("/health")
async def health_check():
    """Comprehensive health check"""
    health_status = {
        "gateway": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "services": {},
        "components": {
            "redis": "unknown",
            "kafka": "unknown",
            "qdrant": "unknown"
        }
    }
    
    # Check Redis
    try:
        await gateway.redis_client.ping()
        health_status["components"]["redis"] = "healthy"
    except:
        health_status["components"]["redis"] = "unhealthy"
    
    # Check services
    for name, service in gateway.service_registry.services.items():
        if service.get("status") != "planned":
            try:
                response = await gateway.http_client.get(
                    service["url"] + "/health",
                    timeout=2.0
                )
                health_status["services"][name] = "healthy" if response.status_code == 200 else "unhealthy"
            except:
                health_status["services"][name] = "unreachable"
    
    return health_status

# Helper functions
async def notify_completion(callback_url: str, result: Dict):
    """Notify external system when agent task completes"""
    try:
        async with httpx.AsyncClient() as client:
            await client.post(callback_url, json=result)
    except Exception as e:
        print(f"Callback notification failed: {e}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)