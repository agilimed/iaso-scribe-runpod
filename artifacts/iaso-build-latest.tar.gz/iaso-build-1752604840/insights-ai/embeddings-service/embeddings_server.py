#!/usr/bin/env python3
"""
BGE-M3 Embeddings Service for NexusCare RAG System
Provides high-performance medical text embeddings via gRPC
"""

import os
import sys
import time
import logging
import signal
import threading
from concurrent import futures
from typing import List, Dict, Optional

import grpc
from grpc_health.v1 import health
from grpc_health.v1 import health_pb2
from grpc_health.v1 import health_pb2_grpc
from prometheus_client import start_http_server, Counter, Histogram, Gauge
from sentence_transformers import SentenceTransformer
import torch
import numpy as np
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging early so it's available for import errors
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Import the compiled protobuf modules
try:
    import rag_pb2
    import rag_pb2_grpc
except ImportError as e:
    logger.error(f"Failed to import protobuf modules: {e}")
    logger.error(f"Current directory: {os.getcwd()}")
    logger.error(f"Directory contents: {os.listdir('.')}")
    raise

# Prometheus metrics
embedding_requests = Counter('embedding_requests_total', 'Total number of embedding requests')
embedding_batch_requests = Counter('embedding_batch_requests_total', 'Total number of batch embedding requests')
embedding_errors = Counter('embedding_errors_total', 'Total number of embedding errors')
embedding_duration = Histogram('embedding_duration_seconds', 'Time spent generating embeddings')
batch_size_histogram = Histogram('embedding_batch_size', 'Distribution of batch sizes')
model_load_time = Gauge('model_load_time_seconds', 'Time taken to load the model')
active_requests = Gauge('active_embedding_requests', 'Number of active embedding requests')

class EmbeddingServicer(rag_pb2_grpc.EmbeddingServiceServicer):
    """BGE-M3 Embeddings Service Implementation"""
    
    def __init__(self, model_name: str = "BAAI/bge-m3", device: Optional[str] = None):
        """Initialize the embedding service with BGE-M3 model"""
        self.model_name = model_name
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
        
        logger.info(f"Initializing embedding service with model: {model_name}")
        logger.info(f"Using device: {self.device}")
        
        # Load model
        start_time = time.time()
        try:
            self.model = SentenceTransformer(model_name, device=self.device)
            # Set model to eval mode
            self.model.eval()
            load_time = time.time() - start_time
            model_load_time.set(load_time)
            logger.info(f"Model loaded successfully in {load_time:.2f} seconds")
            
            # Get model info
            self.embedding_dim = self.model.get_sentence_embedding_dimension()
            self.max_seq_length = self.model.max_seq_length
            logger.info(f"Embedding dimensions: {self.embedding_dim}")
            logger.info(f"Max sequence length: {self.max_seq_length}")
            
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            raise
    
    @embedding_duration.time()
    def GenerateEmbedding(self, request: rag_pb2.EmbeddingRequest, context):
        """Generate embedding for a single text"""
        embedding_requests.inc()
        active_requests.inc()
        
        try:
            # Validate input
            if not request.text:
                context.abort(grpc.StatusCode.INVALID_ARGUMENT, "Text cannot be empty")
            
            # Generate embedding
            start_time = time.time()
            with torch.no_grad():
                embedding = self.model.encode(
                    request.text,
                    convert_to_numpy=True,
                    normalize_embeddings=True  # BGE models benefit from normalization
                )
            
            processing_time = int((time.time() - start_time) * 1000)
            
            # Convert to list and return
            response = rag_pb2.EmbeddingResponse(
                embedding=embedding.tolist(),
                dimensions=len(embedding),
                model_used=self.model_name,
                processing_time_ms=processing_time
            )
            
            logger.debug(f"Generated embedding for text of length {len(request.text)} in {processing_time}ms")
            return response
            
        except Exception as e:
            embedding_errors.inc()
            logger.error(f"Error generating embedding: {e}")
            context.abort(grpc.StatusCode.INTERNAL, f"Failed to generate embedding: {str(e)}")
        finally:
            active_requests.dec()
    
    @embedding_duration.time()
    def GenerateEmbeddings(self, request: rag_pb2.BatchEmbeddingRequest, context):
        """Generate embeddings for multiple texts (batch)"""
        embedding_batch_requests.inc()
        active_requests.inc()
        batch_size_histogram.observe(len(request.texts))
        
        try:
            # Validate input
            if not request.texts:
                context.abort(grpc.StatusCode.INVALID_ARGUMENT, "Texts list cannot be empty")
            
            if len(request.texts) > 1000:  # Prevent OOM
                context.abort(grpc.StatusCode.INVALID_ARGUMENT, "Batch size cannot exceed 1000")
            
            # Generate embeddings
            start_time = time.time()
            with torch.no_grad():
                embeddings = self.model.encode(
                    request.texts,
                    convert_to_numpy=True,
                    normalize_embeddings=True,
                    batch_size=32,  # Optimize for throughput
                    show_progress_bar=False
                )
            
            processing_time = int((time.time() - start_time) * 1000)
            
            # Convert to response format
            embedding_vectors = []
            for embedding in embeddings:
                vector = rag_pb2.EmbeddingVector(
                    values=embedding.tolist(),
                    dimensions=len(embedding)
                )
                embedding_vectors.append(vector)
            
            response = rag_pb2.BatchEmbeddingResponse(
                embeddings=embedding_vectors,
                model_used=self.model_name,
                total_processing_time_ms=processing_time
            )
            
            logger.info(f"Generated {len(request.texts)} embeddings in {processing_time}ms")
            return response
            
        except Exception as e:
            embedding_errors.inc()
            logger.error(f"Error generating batch embeddings: {e}")
            context.abort(grpc.StatusCode.INTERNAL, f"Failed to generate embeddings: {str(e)}")
        finally:
            active_requests.dec()
    
    def GetModelInfo(self, request: rag_pb2.Empty, context):
        """Get information about the loaded model"""
        try:
            # BGE-M3 supports 100+ languages
            supported_languages = [
                "en", "zh", "es", "fr", "de", "ru", "ja", "ar", "pt", "it",
                "ko", "nl", "tr", "pl", "sv", "id", "vi", "th", "he", "el",
                # ... BGE-M3 supports 100+ languages
            ]
            
            capabilities = {
                "multi_functionality": "dense, multi-vector, sparse retrieval",
                "multi_linguality": "100+ languages",
                "multi_granularity": "short sentences to 8192 tokens",
                "medical_optimized": "false",  # Using general model
                "cpu_optimized": str(self.device == 'cpu')
            }
            
            return rag_pb2.ModelInfo(
                name=self.model_name,
                version="1.0.0",
                embedding_dimensions=self.embedding_dim,
                max_sequence_length=self.max_seq_length,
                supported_languages=supported_languages[:20],  # First 20 languages
                capabilities=capabilities
            )
        except Exception as e:
            logger.error(f"Error getting model info: {e}")
            context.abort(grpc.StatusCode.INTERNAL, f"Failed to get model info: {str(e)}")
    
    def HealthCheck(self, request: rag_pb2.Empty, context):
        """Health check endpoint"""
        try:
            # Test model is working
            test_embedding = self.model.encode("health check", convert_to_numpy=True)
            
            details = {
                "model": self.model_name,
                "device": self.device,
                "embedding_dim": str(self.embedding_dim),
                "status": "healthy"
            }
            
            return rag_pb2.HealthStatus(
                healthy=True,
                status="Embedding service is healthy",
                details=details
            )
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return rag_pb2.HealthStatus(
                healthy=False,
                status=f"Health check failed: {str(e)}",
                details={}
            )

def serve():
    """Start the gRPC server"""
    # Configuration
    port = int(os.environ.get('GRPC_PORT', '50051'))
    max_workers = int(os.environ.get('MAX_WORKERS', '10'))
    model_name = os.environ.get('MODEL_NAME', 'BAAI/bge-m3')
    prometheus_port = int(os.environ.get('PROMETHEUS_PORT', '8000'))
    
    # Start Prometheus metrics server
    start_http_server(prometheus_port)
    logger.info(f"Prometheus metrics available at http://localhost:{prometheus_port}")
    
    # Create gRPC server
    server = grpc.server(
        futures.ThreadPoolExecutor(max_workers=max_workers),
        options=[
            ('grpc.max_send_message_length', 50 * 1024 * 1024),  # 50MB
            ('grpc.max_receive_message_length', 50 * 1024 * 1024),  # 50MB
            ('grpc.keepalive_time_ms', 30000),
            ('grpc.keepalive_timeout_ms', 10000),
        ]
    )
    
    # Add services
    embedding_servicer = EmbeddingServicer(model_name=model_name)
    rag_pb2_grpc.add_EmbeddingServiceServicer_to_server(embedding_servicer, server)
    
    # Add health service
    health_servicer = health.HealthServicer()
    health_pb2_grpc.add_HealthServicer_to_server(health_servicer, server)
    health_servicer.set("nexuscare.rag.EmbeddingService", health_pb2.HealthCheckResponse.SERVING)
    
    # Start server
    server.add_insecure_port(f'[::]:{port}')
    server.start()
    logger.info(f"Embedding service started on port {port}")
    
    # Handle shutdown gracefully
    def handle_sigterm(*args):
        logger.info("Received shutdown signal")
        server.stop(grace_period=30)
    
    signal.signal(signal.SIGTERM, handle_sigterm)
    signal.signal(signal.SIGINT, handle_sigterm)
    
    try:
        server.wait_for_termination()
    except KeyboardInterrupt:
        server.stop(grace_period=30)
        logger.info("Server stopped")

if __name__ == '__main__':
    serve()