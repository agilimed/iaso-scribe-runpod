#!/usr/bin/env python3
"""
Test client for the embeddings service
"""

import grpc
import sys
import time
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    import rag_pb2
    import rag_pb2_grpc
except ImportError:
    logger.error("Proto modules not found. Please run ./compile_protos.sh first")
    sys.exit(1)

def test_single_embedding(stub):
    """Test single text embedding generation"""
    logger.info("Testing single embedding generation...")
    
    request = rag_pb2.EmbeddingRequest(
        text="Patient presents with chest pain and shortness of breath"
    )
    
    try:
        response = stub.GenerateEmbedding(request)
        logger.info(f"Success! Generated embedding with {response.dimensions} dimensions")
        logger.info(f"Model used: {response.model_used}")
        logger.info(f"Processing time: {response.processing_time_ms}ms")
        logger.info(f"First 5 values: {response.embedding[:5]}")
        return True
    except grpc.RpcError as e:
        logger.error(f"Failed to generate embedding: {e}")
        return False

def test_batch_embeddings(stub):
    """Test batch embedding generation"""
    logger.info("\nTesting batch embedding generation...")
    
    texts = [
        "Patient has diabetes mellitus type 2",
        "Blood pressure reading: 140/90 mmHg",
        "Laboratory results show elevated glucose levels",
        "Prescribed metformin 500mg twice daily",
        "Follow-up appointment scheduled in 3 months"
    ]
    
    request = rag_pb2.BatchEmbeddingRequest(texts=texts)
    
    try:
        response = stub.GenerateEmbeddings(request)
        logger.info(f"Success! Generated {len(response.embeddings)} embeddings")
        logger.info(f"Model used: {response.model_used}")
        logger.info(f"Total processing time: {response.total_processing_time_ms}ms")
        for i, emb in enumerate(response.embeddings):
            logger.info(f"  Text {i+1}: {emb.dimensions} dimensions")
        return True
    except grpc.RpcError as e:
        logger.error(f"Failed to generate batch embeddings: {e}")
        return False

def test_model_info(stub):
    """Test getting model information"""
    logger.info("\nTesting model info retrieval...")
    
    request = rag_pb2.Empty()
    
    try:
        response = stub.GetModelInfo(request)
        logger.info(f"Model: {response.name}")
        logger.info(f"Version: {response.version}")
        logger.info(f"Embedding dimensions: {response.embedding_dimensions}")
        logger.info(f"Max sequence length: {response.max_sequence_length}")
        logger.info(f"Supported languages: {len(response.supported_languages)}")
        logger.info(f"Capabilities: {dict(response.capabilities)}")
        return True
    except grpc.RpcError as e:
        logger.error(f"Failed to get model info: {e}")
        return False

def test_health_check(stub):
    """Test health check endpoint"""
    logger.info("\nTesting health check...")
    
    request = rag_pb2.Empty()
    
    try:
        response = stub.HealthCheck(request)
        logger.info(f"Health status: {'Healthy' if response.healthy else 'Unhealthy'}")
        logger.info(f"Status message: {response.status}")
        logger.info(f"Details: {dict(response.details)}")
        return response.healthy
    except grpc.RpcError as e:
        logger.error(f"Failed health check: {e}")
        return False

def main():
    """Run all tests"""
    # Connect to the service
    channel = grpc.insecure_channel('localhost:50051')
    stub = rag_pb2_grpc.EmbeddingServiceStub(channel)
    
    logger.info("Starting embeddings service tests...")
    logger.info("=" * 50)
    
    # Wait a moment for the service to be ready
    time.sleep(1)
    
    # Run tests
    tests = [
        ("Health Check", test_health_check),
        ("Model Info", test_model_info),
        ("Single Embedding", test_single_embedding),
        ("Batch Embeddings", test_batch_embeddings)
    ]
    
    results = []
    for test_name, test_func in tests:
        logger.info(f"\nRunning {test_name}...")
        logger.info("-" * 30)
        result = test_func(stub)
        results.append((test_name, result))
        time.sleep(0.5)  # Small delay between tests
    
    # Summary
    logger.info("\n" + "=" * 50)
    logger.info("TEST SUMMARY")
    logger.info("=" * 50)
    
    passed = 0
    for test_name, result in results:
        status = "PASSED" if result else "FAILED"
        logger.info(f"{test_name}: {status}")
        if result:
            passed += 1
    
    logger.info(f"\nTotal: {passed}/{len(tests)} tests passed")
    
    channel.close()
    return 0 if passed == len(tests) else 1

if __name__ == '__main__':
    sys.exit(main())