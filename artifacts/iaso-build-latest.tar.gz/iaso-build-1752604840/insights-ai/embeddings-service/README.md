# Embeddings Service

BGE-M3 embeddings service for the NexusCare RAG system. This service provides high-performance text embeddings via gRPC.

## Overview

The embeddings service uses the BAAI/bge-m3 model to generate embeddings for medical text. It supports:
- Single text embedding generation
- Batch embedding generation
- Multi-language support (100+ languages)
- CPU and GPU operation
- Health checks and metrics

## File Structure

```
embeddings-service/
├── rag.proto                      # Protocol buffer definitions
├── embeddings_server.py           # Main server implementation
├── embeddings_server_simplified.py # Simplified version with direct imports
├── requirements.txt               # Python dependencies
├── Dockerfile                     # Production Docker build
├── Dockerfile.simplified          # Simplified Docker build
├── cloudbuild.yaml               # Google Cloud Build config
├── cloudbuild-simplified.yaml    # Simplified Cloud Build config
├── compile_protos.sh             # Script to compile proto files locally
├── test_locally.sh               # Script to test service locally
└── test_client.py                # Test client for verification
```

## Setup

### Local Development

1. **Compile Proto Files**:
   ```bash
   ./compile_protos.sh
   ```

2. **Run Service Locally**:
   ```bash
   ./test_locally.sh
   ```

3. **Test the Service**:
   ```bash
   # In another terminal
   python test_client.py
   ```

### Docker Build

**Option 1: Original Dockerfile**
```bash
docker build -f Dockerfile -t embeddings-service .
```

**Option 2: Simplified Dockerfile** (Recommended)
```bash
docker build -f Dockerfile.simplified -t embeddings-service .
```

### Google Cloud Build

**Option 1: Original Build**
```bash
gcloud builds submit --config cloudbuild.yaml
```

**Option 2: Simplified Build** (Recommended)
```bash
gcloud builds submit --config cloudbuild-simplified.yaml
```

## Usage

### Environment Variables

- `GRPC_PORT`: gRPC server port (default: 50051)
- `PROMETHEUS_PORT`: Metrics port (default: 8000)
- `MODEL_NAME`: Model to use (default: BAAI/bge-m3)
- `MAX_WORKERS`: Max gRPC workers (default: 10)

### Running with Docker

```bash
docker run -p 50051:50051 -p 8000:8000 embeddings-service
```

### Kubernetes Deployment

See `/infrastructure/kubernetes/gke-deployment/applications/embeddings-service.yaml`

## API Reference

### GenerateEmbedding
Generate embedding for a single text.

```python
request = EmbeddingRequest(text="Patient has diabetes")
response = stub.GenerateEmbedding(request)
# response.embedding: list of floats
# response.dimensions: int
# response.model_used: string
# response.processing_time_ms: int
```

### GenerateEmbeddings
Generate embeddings for multiple texts (batch).

```python
request = BatchEmbeddingRequest(texts=["text1", "text2", "text3"])
response = stub.GenerateEmbeddings(request)
# response.embeddings: list of EmbeddingVector
# response.model_used: string
# response.total_processing_time_ms: int
```

### GetModelInfo
Get information about the loaded model.

```python
request = Empty()
response = stub.GetModelInfo(request)
# response.name: string
# response.version: string
# response.embedding_dimensions: int
# response.max_sequence_length: int
# response.supported_languages: list of strings
# response.capabilities: map of strings
```

### HealthCheck
Check service health.

```python
request = Empty()
response = stub.HealthCheck(request)
# response.healthy: bool
# response.status: string
# response.details: map of strings
```

## Troubleshooting

### ModuleNotFoundError: No module named 'rag_pb2'

This error occurs when the protobuf files haven't been compiled. Solutions:

1. **For local development**: Run `./compile_protos.sh`
2. **For Docker**: Use `Dockerfile.simplified` which compiles protos in the same directory
3. **Check proto path**: Ensure the proto files are in the expected location

### Import path issues

The service expects the compiled proto files in specific locations:
- **Original version**: `/app/backend/src/protos/`
- **Simplified version**: `/app/` (same directory as the server)

### Model loading errors

- Ensure sufficient memory (at least 4GB for CPU, 8GB recommended)
- For GPU: Ensure CUDA is available and compatible
- Model will be downloaded on first run (may take time)

## Performance Considerations

- **Batch Processing**: Use batch embeddings for better throughput
- **GPU Acceleration**: Significant speedup with CUDA-enabled GPUs
- **Model Caching**: Model is cached after first download
- **Normalization**: BGE models benefit from normalized embeddings

## Monitoring

- Prometheus metrics available at `:8000/metrics`
- Key metrics:
  - `embedding_requests_total`
  - `embedding_duration_seconds`
  - `embedding_batch_size`
  - `model_load_time_seconds`
  - `active_embedding_requests`