#!/bin/bash

# Script to test the embeddings service locally

echo "Setting up local test environment..."

# Ensure we're in the right directory
cd "$(dirname "$0")"

# Create a virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt

# Compile proto files
echo "Compiling proto files..."
./compile_protos.sh

# Run the service
echo "Starting embeddings service..."
export GRPC_PORT=50051
export PROMETHEUS_PORT=8000
export MODEL_NAME=BAAI/bge-m3

python embeddings_server_simplified.py