#!/bin/bash

# Script to compile protocol buffer files for the embeddings service

echo "Compiling protocol buffer files..."

# Ensure we're in the right directory
cd "$(dirname "$0")"

# Install grpcio-tools if not already installed
pip install grpcio-tools

# Compile the proto file
python -m grpc_tools.protoc \
    -I. \
    --python_out=. \
    --grpc_python_out=. \
    rag.proto

# Check if compilation was successful
if [ $? -eq 0 ]; then
    echo "Proto files compiled successfully!"
    echo "Generated files:"
    ls -la rag_pb2*.py
else
    echo "Error: Failed to compile proto files"
    exit 1
fi