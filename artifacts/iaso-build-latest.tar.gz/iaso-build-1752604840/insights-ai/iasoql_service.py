"""
IasoQL Text-to-SQL Service
Implements the actual text-to-SQL generation using trained IasoQL models
"""

import os
import asyncio
from typing import Optional, Dict, List, Any
from datetime import datetime
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from pydantic import BaseModel, Field
from fastapi import FastAPI, HTTPException
import json

# Model configuration
MODEL_PATH = os.getenv("IASOQL_MODEL_PATH", "./iasoql-7b-healthcare")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MAX_LENGTH = 2048
TEMPERATURE = 0.1  # Low temperature for deterministic SQL

class SQLRequest(BaseModel):
    text: str = Field(..., description="Natural language query")
    dialect: str = Field(default="clickhouse", description="SQL dialect")
    schema_context: Optional[Dict] = Field(None, description="Database schema context")
    max_length: int = Field(default=512, description="Maximum SQL length")
    include_explanation: bool = Field(default=True)

class SQLResponse(BaseModel):
    sql: str
    explanation: Optional[str] = None
    confidence: float
    dialect: str
    processing_time_ms: int

class IasoQLService:
    """
    IasoQL service for healthcare-specific text-to-SQL generation
    """
    
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.schema_cache = {}
        
    async def initialize(self):
        """Load the IasoQL model"""
        print(f"Loading IasoQL model from {MODEL_PATH}")
        
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
            self.model = AutoModelForCausalLM.from_pretrained(
                MODEL_PATH,
                torch_dtype=torch.float16 if DEVICE == "cuda" else torch.float32,
                device_map="auto" if DEVICE == "cuda" else None
            )
            
            if DEVICE == "cuda":
                self.model = self.model.cuda()
            
            self.model.eval()
            print(f"Model loaded successfully on {DEVICE}")
            
            # Load default FHIR schema
            self._load_default_schema()
            
        except Exception as e:
            print(f"Error loading model: {e}")
            # Fallback to mock mode for development
            self.model = None
    
    def _load_default_schema(self):
        """Load default FHIR ClickHouse schema"""
        self.default_schema = {
            "clickhouse": {
                "tables": {
                    "patients": {
                        "columns": ["id", "birth_date", "gender", "deceased", "address", "name"],
                        "description": "FHIR Patient resources"
                    },
                    "observations": {
                        "columns": ["id", "patient_id", "code", "value", "unit", "date", "status"],
                        "description": "FHIR Observation resources (lab results, vitals)"
                    },
                    "conditions": {
                        "columns": ["id", "patient_id", "code", "clinical_status", "onset_date", "abatement_date"],
                        "description": "FHIR Condition resources (diagnoses)"
                    },
                    "medications": {
                        "columns": ["id", "patient_id", "code", "status", "dosage", "start_date", "end_date"],
                        "description": "FHIR MedicationStatement resources"
                    },
                    "encounters": {
                        "columns": ["id", "patient_id", "type", "status", "start_date", "end_date", "location"],
                        "description": "FHIR Encounter resources"
                    }
                },
                "common_codes": {
                    "diabetes": ["44054006", "E11"],
                    "hypertension": ["38341003", "I10"],
                    "hba1c": ["4548-4", "43396009"],
                    "glucose": ["2339-0", "15074-8"],
                    "blood_pressure": ["85354-9", "55284-4"]
                }
            }
        }
    
    async def generate_sql(self, request: SQLRequest) -> SQLResponse:
        """Generate SQL from natural language query"""
        start_time = datetime.utcnow()
        
        # Prepare context and prompt
        prompt = self._create_prompt(request)
        
        # Generate SQL
        if self.model:
            sql, confidence = await self._generate_with_model(prompt)
        else:
            # Fallback mock generation for development
            sql, confidence = self._mock_generate(request)
        
        # Post-process SQL
        sql = self._post_process_sql(sql, request.dialect)
        
        # Generate explanation if requested
        explanation = None
        if request.include_explanation:
            explanation = self._generate_explanation(request.text, sql)
        
        # Calculate processing time
        processing_time = int((datetime.utcnow() - start_time).total_seconds() * 1000)
        
        return SQLResponse(
            sql=sql,
            explanation=explanation,
            confidence=confidence,
            dialect=request.dialect,
            processing_time_ms=processing_time
        )
    
    def _create_prompt(self, request: SQLRequest) -> str:
        """Create prompt for the model with schema context"""
        schema = request.schema_context or self.default_schema.get(request.dialect, {})
        
        # Build schema description
        schema_desc = ""
        if "tables" in schema:
            schema_desc = "Available tables:\n"
            for table, info in schema["tables"].items():
                cols = ", ".join(info["columns"])
                desc = info.get("description", "")
                schema_desc += f"- {table} ({cols}) - {desc}\n"
        
        # Build prompt in IasoQL format
        prompt = f"""### Task: Generate {request.dialect.upper()} SQL query for healthcare data.

### Database Schema:
{schema_desc}

### Medical Code Reference:
- Diabetes: SNOMED 44054006, ICD-10 E11
- HbA1c test: LOINC 4548-4
- Glucose test: LOINC 2339-0
- Blood pressure: LOINC 85354-9

### Natural Language Query:
{request.text}

### SQL Query:
```sql
"""
        
        return prompt
    
    async def _generate_with_model(self, prompt: str) -> tuple[str, float]:
        """Generate SQL using the IasoQL model"""
        inputs = self.tokenizer(prompt, return_tensors="pt", max_length=MAX_LENGTH, truncation=True)
        
        if DEVICE == "cuda":
            inputs = {k: v.cuda() for k, v in inputs.items()}
        
        with torch.no_grad():
            outputs = self.model.generate(
                inputs["input_ids"],
                max_new_tokens=512,
                temperature=TEMPERATURE,
                do_sample=True,
                top_p=0.95,
                num_return_sequences=1,
                pad_token_id=self.tokenizer.eos_token_id,
                eos_token_id=self.tokenizer.eos_token_id
            )
        
        # Decode the generated SQL
        generated = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Extract SQL from the generated text
        sql = self._extract_sql_from_generation(generated)
        
        # Calculate confidence based on model logits
        confidence = 0.85  # TODO: Calculate from actual logits
        
        return sql, confidence
    
    def _extract_sql_from_generation(self, generated: str) -> str:
        """Extract SQL query from model generation"""
        # Look for SQL between ```sql and ```
        if "```sql" in generated:
            start = generated.find("```sql") + 6
            end = generated.find("```", start)
            if end > start:
                return generated[start:end].strip()
        
        # Fallback: look for SELECT statement
        if "SELECT" in generated:
            start = generated.find("SELECT")
            # Find the end (usually a semicolon or end of string)
            sql = generated[start:]
            if ";" in sql:
                sql = sql[:sql.find(";") + 1]
            return sql.strip()
        
        return generated.strip()
    
    def _mock_generate(self, request: SQLRequest) -> tuple[str, float]:
        """Mock SQL generation for development"""
        text_lower = request.text.lower()
        
        # Simple pattern matching for common queries
        if "diabetes" in text_lower and "hba1c" in text_lower:
            if ">" in text_lower or "greater" in text_lower:
                sql = """SELECT 
    p.id as patient_id,
    p.name,
    o.value as hba1c_value,
    o.date as test_date
FROM patients p
JOIN conditions c ON p.id = c.patient_id
JOIN observations o ON p.id = o.patient_id
WHERE c.code = '44054006'  -- Diabetes
    AND o.code = '4548-4'   -- HbA1c
    AND o.value > 7.0
    AND o.date > now() - INTERVAL 6 MONTH
ORDER BY o.value DESC"""
                confidence = 0.9
            else:
                sql = """SELECT 
    p.id as patient_id,
    p.name,
    o.value as hba1c_value,
    o.date as test_date
FROM patients p
JOIN conditions c ON p.id = c.patient_id
JOIN observations o ON p.id = o.patient_id
WHERE c.code = '44054006'  -- Diabetes
    AND o.code = '4548-4'   -- HbA1c
ORDER BY o.date DESC
LIMIT 100"""
                confidence = 0.85
                
        elif "medications" in text_lower:
            sql = """SELECT 
    p.id as patient_id,
    p.name,
    m.code as medication_code,
    m.dosage,
    m.start_date
FROM patients p
JOIN medications m ON p.id = m.patient_id
WHERE m.status = 'active'
ORDER BY m.start_date DESC"""
            confidence = 0.8
            
        else:
            # Generic patient query
            sql = "SELECT * FROM patients LIMIT 10"
            confidence = 0.5
        
        return sql, confidence
    
    def _post_process_sql(self, sql: str, dialect: str) -> str:
        """Post-process SQL for specific dialect"""
        sql = sql.strip()
        
        if dialect == "clickhouse":
            # ClickHouse specific adjustments
            sql = sql.replace(" BOOLEAN", " UInt8")
            sql = sql.replace("::json", "")
            
        elif dialect == "postgresql":
            # PostgreSQL specific adjustments
            sql = sql.replace(" String", " VARCHAR")
            sql = sql.replace("now()", "CURRENT_TIMESTAMP")
        
        # Ensure SQL ends with semicolon
        if not sql.endswith(";"):
            sql += ";"
        
        return sql
    
    def _generate_explanation(self, query: str, sql: str) -> str:
        """Generate explanation for the SQL query"""
        explanation_parts = []
        
        # Analyze query intent
        if "diabetes" in query.lower():
            explanation_parts.append("Filtering for patients with diabetes (SNOMED: 44054006)")
        
        if "hba1c" in query.lower():
            explanation_parts.append("Looking for HbA1c test results (LOINC: 4548-4)")
        
        if "JOIN" in sql:
            tables = []
            for table in ["patients", "observations", "conditions", "medications", "encounters"]:
                if table in sql:
                    tables.append(table)
            explanation_parts.append(f"Joining tables: {', '.join(tables)}")
        
        if "WHERE" in sql:
            explanation_parts.append("Applying filters based on the query criteria")
        
        if not explanation_parts:
            explanation_parts.append("Generating SQL query based on the natural language input")
        
        return " ".join(explanation_parts)

# FastAPI Application
app = FastAPI(
    title="IasoQL Text-to-SQL Service",
    description="Healthcare-specific SQL generation from natural language",
    version="1.0.0"
)

service = IasoQLService()

@app.on_event("startup")
async def startup():
    await service.initialize()

@app.post("/generate", response_model=SQLResponse)
async def generate_sql(request: SQLRequest):
    """Generate SQL from natural language healthcare query"""
    try:
        return await service.generate_sql(request)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "model_loaded": service.model is not None,
        "device": DEVICE,
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/schema/{dialect}")
async def get_schema(dialect: str):
    """Get available schema for a SQL dialect"""
    if dialect in service.default_schema:
        return service.default_schema[dialect]
    else:
        raise HTTPException(status_code=404, detail=f"Schema not found for dialect: {dialect}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8008)