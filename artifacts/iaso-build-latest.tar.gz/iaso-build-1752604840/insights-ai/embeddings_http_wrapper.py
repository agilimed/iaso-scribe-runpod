"""
HTTP wrapper for BGE-M3 embeddings service
Provides HTTP endpoints for the gRPC embeddings service
"""

import os
import numpy as np
from typing import List, Dict, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import torch
from transformers import AutoTokenizer, AutoModel
import asyncio
from datetime import datetime

# Model configuration
MODEL_NAME = "BAAI/bge-m3"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MAX_LENGTH = 8192  # BGE-M3 supports up to 8192 tokens

class EmbeddingRequest(BaseModel):
    text: str = Field(..., description="Text to generate embeddings for")
    model: str = Field(default="BGE-M3", description="Model to use")
    pooling_method: str = Field(default="cls", description="Pooling method: cls, mean, max")

class EmbeddingResponse(BaseModel):
    embeddings: List[float]
    model: str
    dimensions: int
    processing_time_ms: int

class MultiEmbeddingRequest(BaseModel):
    texts: List[str] = Field(..., description="List of texts to generate embeddings for")
    model: str = Field(default="BGE-M3", description="Model to use")
    pooling_method: str = Field(default="cls", description="Pooling method")

class MultiEmbeddingResponse(BaseModel):
    embeddings: List[List[float]]
    model: str
    dimensions: int
    count: int
    processing_time_ms: int

class EmbeddingsService:
    """Service for generating medical text embeddings"""
    
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.device = DEVICE
        
    async def initialize(self):
        """Load the BGE-M3 model"""
        print(f"Loading BGE-M3 model...")
        
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
            self.model = AutoModel.from_pretrained(MODEL_NAME)
            
            if self.device == "cuda":
                self.model = self.model.cuda()
            
            self.model.eval()
            print(f"Model loaded successfully on {self.device}")
            
        except Exception as e:
            print(f"Error loading model: {e}")
            # Fall back to mock mode
            self.model = None
    
    def _pool_embeddings(self, embeddings: torch.Tensor, attention_mask: torch.Tensor, method: str = "cls") -> torch.Tensor:
        """Apply pooling to token embeddings"""
        if method == "cls":
            # Use CLS token
            return embeddings[:, 0, :]
        elif method == "mean":
            # Mean pooling
            input_mask_expanded = attention_mask.unsqueeze(-1).expand(embeddings.size()).float()
            sum_embeddings = torch.sum(embeddings * input_mask_expanded, 1)
            sum_mask = torch.clamp(input_mask_expanded.sum(1), min=1e-9)
            return sum_embeddings / sum_mask
        elif method == "max":
            # Max pooling
            input_mask_expanded = attention_mask.unsqueeze(-1).expand(embeddings.size()).float()
            embeddings[input_mask_expanded == 0] = -1e9
            return torch.max(embeddings, 1)[0]
        else:
            return embeddings[:, 0, :]
    
    async def generate_embedding(self, text: str, pooling_method: str = "cls") -> List[float]:
        """Generate embedding for a single text"""
        if self.model is None:
            # Mock embeddings
            return np.random.randn(1024).tolist()
        
        # Tokenize
        inputs = self.tokenizer(
            text,
            padding=True,
            truncation=True,
            max_length=MAX_LENGTH,
            return_tensors="pt"
        )
        
        if self.device == "cuda":
            inputs = {k: v.cuda() for k, v in inputs.items()}
        
        # Generate embeddings
        with torch.no_grad():
            outputs = self.model(**inputs)
            embeddings = outputs.last_hidden_state
            
            # Apply pooling
            pooled = self._pool_embeddings(embeddings, inputs["attention_mask"], pooling_method)
            
            # Normalize
            pooled = torch.nn.functional.normalize(pooled, p=2, dim=1)
            
        return pooled.cpu().numpy()[0].tolist()
    
    async def generate_batch_embeddings(self, texts: List[str], pooling_method: str = "cls") -> List[List[float]]:
        """Generate embeddings for multiple texts"""
        if self.model is None:
            # Mock embeddings
            return [np.random.randn(1024).tolist() for _ in texts]
        
        # Process in batches of 8 for efficiency
        batch_size = 8
        all_embeddings = []
        
        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i:i + batch_size]
            
            # Tokenize batch
            inputs = self.tokenizer(
                batch_texts,
                padding=True,
                truncation=True,
                max_length=MAX_LENGTH,
                return_tensors="pt"
            )
            
            if self.device == "cuda":
                inputs = {k: v.cuda() for k, v in inputs.items()}
            
            # Generate embeddings
            with torch.no_grad():
                outputs = self.model(**inputs)
                embeddings = outputs.last_hidden_state
                
                # Apply pooling
                pooled = self._pool_embeddings(embeddings, inputs["attention_mask"], pooling_method)
                
                # Normalize
                pooled = torch.nn.functional.normalize(pooled, p=2, dim=1)
                
                all_embeddings.extend(pooled.cpu().numpy().tolist())
        
        return all_embeddings

# FastAPI Application
app = FastAPI(
    title="BGE-M3 Embeddings Service",
    description="HTTP wrapper for BGE-M3 embeddings generation",
    version="1.0.0"
)

service = EmbeddingsService()

@app.on_event("startup")
async def startup():
    await service.initialize()

@app.post("/embeddings", response_model=EmbeddingResponse)
async def generate_embedding(request: EmbeddingRequest):
    """Generate embeddings for a single text"""
    start_time = datetime.utcnow()
    
    try:
        embeddings = await service.generate_embedding(request.text, request.pooling_method)
        
        processing_time = int((datetime.utcnow() - start_time).total_seconds() * 1000)
        
        return EmbeddingResponse(
            embeddings=embeddings,
            model=request.model,
            dimensions=len(embeddings),
            processing_time_ms=processing_time
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/embeddings/batch", response_model=MultiEmbeddingResponse)
async def generate_batch_embeddings(request: MultiEmbeddingRequest):
    """Generate embeddings for multiple texts"""
    start_time = datetime.utcnow()
    
    try:
        embeddings = await service.generate_batch_embeddings(request.texts, request.pooling_method)
        
        processing_time = int((datetime.utcnow() - start_time).total_seconds() * 1000)
        
        return MultiEmbeddingResponse(
            embeddings=embeddings,
            model=request.model,
            dimensions=len(embeddings[0]) if embeddings else 0,
            count=len(embeddings),
            processing_time_ms=processing_time
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "model_loaded": service.model is not None,
        "device": service.device,
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/model/info")
async def model_info():
    """Get information about the loaded model"""
    return {
        "model_name": MODEL_NAME,
        "embedding_dimensions": 1024,
        "max_sequence_length": MAX_LENGTH,
        "device": service.device,
        "pooling_methods": ["cls", "mean", "max"]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8050)