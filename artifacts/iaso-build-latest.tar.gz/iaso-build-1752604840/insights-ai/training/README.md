# IasoQL-7B-Healthcare Training

This directory contains the training setup for fine-tuning XiYanSQL-QwenCoder-7B-2504 to create IasoQL-7B-Healthcare, our specialized FHIR SQL generation model.

## 🏛️ About IasoQL

Named after Iaso, the Greek goddess of healing and recovery, IasoQL transforms complex FHIR data into clear, actionable healthcare insights through intelligent SQL generation.

## 📁 Directory Structure

```
training/
├── train_xiyan_sql.py           # Main training script with checkpoint support
├── submit_iasoql_training.py    # Vertex AI submission script (uses DWS)
├── monitor_training.py          # Real-time training monitoring
├── fhir-clickhouse-training-dataset-v8-FINAL.json  # Training dataset
├── Dockerfile                   # Container with NVIDIA base (no XLA issues)
├── cloudbuild.yaml             # Google Cloud Build configuration
├── requirements.txt            # Python dependencies
└── archive/                    # Previous versions and old scripts
```

## 🚀 Quick Start

### 1. Submit Training Job
```bash
python3 submit_iasoql_training.py
```

This will:
- Use Dynamic Workload Scheduler (DWS) with preemptible A100 GPUs
- Train in asia-southeast1 region (8 A100 quota available)
- Save checkpoints every 50 steps for preemption recovery
- Cost: ~$9-12 for 8 hours

### 2. Monitor Progress
```bash
# Check job status
python3 monitor_training.py

# Or view in console
https://console.cloud.google.com/vertex-ai/training/custom-jobs?project=nexuscare-463413

# Real-time metrics
https://wandb.ai/iaso-agilimed/iasoql-healthcare-training
```

## 📊 Training Configuration

### Model Settings
- **Base Model**: XiYanSQL-QwenCoder-7B-2504 (85.97% Spider accuracy)
- **Fine-tuning**: QLoRA with 4-bit quantization
- **Parameters**: ~0.5% trainable (LoRA rank 16)
- **Batch Size**: 2 per GPU, gradient accumulation 4 (effective 8)
- **Epochs**: 3
- **Learning Rate**: 2e-4 with cosine schedule

### Dataset
- **File**: `fhir-clickhouse-training-dataset-v8-FINAL.json`
- **Examples**: 52 validated FHIR ClickHouse queries
- **Coverage**: Patient data, encounters, conditions, medications, observations
- **Test Status**: 100% pass ClickHouse compilation

### Infrastructure
- **GPU**: A100 40GB (preemptible via DWS)
- **Container**: Custom NVIDIA CUDA base (no XLA issues)
- **Storage**: gs://nexuscare-ai-training/
- **Checkpointing**: Every 50 steps for preemption recovery

## 🛠️ Key Scripts

### `train_xiyan_sql.py`
Main training script with:
- Automatic checkpoint resumption
- CPU/GPU mode detection
- W&B integration for metrics
- Preemptible-friendly save frequency

### `submit_iasoql_training.py`
Vertex AI submission with:
- Dynamic Workload Scheduler (FLEX_START)
- Preemptible GPU quota usage
- Environment variable configuration
- Cost-optimized settings

### `monitor_training.py`
Real-time monitoring showing:
- Job status and progress
- Cost estimation
- GPU utilization
- Training metrics

## 📈 Expected Results

- **Accuracy**: 95%+ on healthcare SQL tasks
- **Training Time**: ~8 hours on A100
- **Model Size**: ~3GB (LoRA adapters only)
- **Inference Speed**: ~100 tokens/sec on A100

## 🔧 Troubleshooting

### XLA Import Error
- Fixed in current Dockerfile using NVIDIA base image
- Environment variable `USE_TORCH_XLA=0` as backup

### GPU Quota Issues
- Using DWS with preemptible quota in asia-southeast1
- 8 A100s available for training

### Checkpoint Recovery
- Automatically resumes from last checkpoint
- Saves every 50 steps to handle preemptions

## 📚 References

- [XiYanSQL-QwenCoder-7B-2504](https://huggingface.co/XGenerationLab/XiYanSQL-QwenCoder-7B-2504)
- [Vertex AI DWS Documentation](https://cloud.google.com/vertex-ai/docs/training/schedule-jobs-dws)
- [QLoRA Paper](https://arxiv.org/abs/2305.14314)

## 🏆 Model Output

Once training completes, the model will be available at:
- **GCS**: gs://nexuscare-ai-training/models/iasoql-7b-healthcare/
- **Hugging Face**: (pending upload) agilimed/iasoql-7b-healthcare

---

**Note**: This is the production training setup. All experimental scripts have been archived.