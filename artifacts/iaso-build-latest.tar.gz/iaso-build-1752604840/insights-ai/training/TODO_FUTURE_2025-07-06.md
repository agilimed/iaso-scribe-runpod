# TODO_FUTURE: IASO Multi-Modal FHIR Intelligence
*Date: 2025-07-06*

## Vision
Transform IASO from a SQL-only model into a comprehensive FHIR-intelligent system that can:
1. Generate ClickHouse SQL for fast analytics
2. Construct FHIR API calls for detailed records
3. Intelligently route queries to the appropriate backend
4. Combine both approaches for comprehensive insights

## Current State
- **Model**: IasoQL-7B-Healthcare (LoRA fine-tuned on XiYanSQL-QwenCoder-7B)
- **Training**: 52 healthcare SQL examples
- **Capability**: ClickHouse SQL generation for FHIR data analytics

## Future Architecture

### Phase 1: Dual-Mode Training
Extend the model to handle both SQL and API generation:

```python
# Training data structure
{
    "instruction": "Count diabetic patients by age group",
    "mode": "analytics",
    "output": "SELECT age_group, COUNT(*) FROM patients WHERE conditions @> '[{\"code\":\"diabetes\"}]' GROUP BY age_group"
},
{
    "instruction": "Get full medical record for patient 12345",
    "mode": "detail",
    "output": "GET /Patient/12345/$everything"
}
```

### Phase 2: FHIR API Pattern Training

Key patterns to train:
- **Search Parameters**: `GET /Patient?name={name}&birthdate={date}`
- **Includes**: `GET /Encounter?_include=Encounter:patient`
- **Reverse Includes**: `GET /Patient/{id}?_revinclude=Observation:patient`
- **Operations**: `$everything`, `$document`, `$validate`
- **Batch/Transactions**: Bundle operations

### Phase 3: Intelligent Query Router

```python
class IASOQueryRouter:
    def analyze_query(self, user_query):
        # Determine query intent
        if "count" in query or "average" in query:
            return "analytics"  # Use ClickHouse
        elif "details" in query or "full record" in query:
            return "api"  # Use FHIR API
        elif "analyze" in query and "then get" in query:
            return "hybrid"  # Use both
```

## Training Data Requirements

### 1. Collect Existing Patterns
```sql
-- Extract common API patterns from audit logs
SELECT endpoint, parameters, use_case, response_time
FROM api_audit_logs 
WHERE success = true
ORDER BY frequency DESC
LIMIT 1000;
```

### 2. Create Training Pairs
```json
{
  "examples": [
    {
      "query": "How many patients were admitted with COVID-19 last month?",
      "intent": "count_with_condition",
      "responses": {
        "sql": {
          "query": "SELECT COUNT(DISTINCT patient_id) FROM encounters WHERE reason_code LIKE '%COVID%' AND period_start > now() - INTERVAL 1 MONTH",
          "use_case": "Fast aggregation"
        },
        "api": {
          "request": "GET /Encounter?reason-code=http://snomed.info/sct|840539006&date=ge2024-12-06&_summary=count",
          "use_case": "FHIR-compliant count"
        }
      }
    }
  ]
}
```

### 3. Multi-Task Training Configuration
```python
training_config = {
    "base_model": "iasoql-healthcare",
    "tasks": [
        "sql_generation",
        "api_generation", 
        "query_routing"
    ],
    "training_examples": {
        "sql": 200,
        "api": 200,
        "routing": 100
    },
    "epochs": 3,
    "learning_rate": 1e-4
}
```

## Implementation Steps

### Step 1: Data Collection (Week 1)
- [ ] Extract 200+ common FHIR API patterns from production logs
- [ ] Document query intent → API mapping patterns
- [ ] Create SQL ↔ API equivalent pairs for same queries

### Step 2: Training Data Preparation (Week 2)
- [ ] Format data in multi-task training structure
- [ ] Add FHIR-specific context (resource types, search parameters)
- [ ] Include error cases and edge conditions

### Step 3: Model Training (Week 3)
- [ ] Set up multi-task LoRA configuration
- [ ] Train on combined SQL + API dataset
- [ ] Implement query router logic

### Step 4: Evaluation (Week 4)
- [ ] Test SQL generation accuracy (maintain >90%)
- [ ] Test API generation validity
- [ ] Measure query routing accuracy
- [ ] End-to-end latency testing

## Expected Outcomes

1. **Single Model, Multiple Capabilities**:
   - Input: "Show me diabetic patients' latest glucose readings"
   - Output Options:
     - SQL: `SELECT patient_id, value, date FROM observations WHERE code='glucose' AND patient_id IN (SELECT id FROM patients WHERE conditions @> '[{\"code\":\"diabetes\"}]')`
     - API: `GET /Observation?code=http://loinc.org|2339-0&patient.condition.code=http://snomed.info/sct|73211009`

2. **Intelligent Backend Selection**:
   - Analytics queries → ClickHouse (fast)
   - Patient details → FHIR API (complete)
   - Complex queries → Hybrid approach

3. **Performance Targets**:
   - SQL queries: <100ms (via ClickHouse)
   - API construction: <50ms
   - Query routing: 95% accuracy

## Future Enhancements

### V3.0 - Conversational Memory
- Remember context across queries
- Chain SQL results into API calls
- Progressive refinement of results

### V4.0 - Write Operations
- Generate FHIR Create/Update operations
- Validate resources before submission
- Handle transaction bundles

### V5.0 - Explain & Optimize
- Explain why SQL vs API was chosen
- Suggest query optimizations
- Provide alternative approaches

## Resources Needed

1. **Training Infrastructure**:
   - 1x A100 GPU for 2-3 hours
   - ~$10-20 training cost

2. **Data Requirements**:
   - 500+ query examples
   - Production API logs
   - FHIR specification docs

3. **Evaluation Dataset**:
   - 100 held-out test queries
   - Coverage of all FHIR resources
   - Edge cases and complex scenarios

## Success Metrics

- **Accuracy**: >90% valid SQL/API generation
- **Routing**: >95% correct backend selection
- **Latency**: <100ms for query analysis
- **Coverage**: Support for all major FHIR resources
- **User Satisfaction**: Reduced time to insights

---

*This enhancement will position IASO as a comprehensive FHIR-intelligent assistant, capable of leveraging both fast analytics (ClickHouse) and detailed records (FHIR APIs) to provide complete healthcare insights.*