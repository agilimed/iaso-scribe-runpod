# AI Training Folder Cleanup Summary - July 7, 2025

## What Was Cleaned Up

### Removed Files
- **Test Scripts**: All test*.js, test*.py, test*.sh files
- **Old Proxy Files**: sqlcoder-proxy.js, test-vllm-wrapper.js
- **Training Scripts**: merge_lora_weights.py, submit_iasoql_training.py, train_xiyan_sql.py
- **Build Files**: cloudbuild.yaml, Dockerfile (from root)
- **Temporary Files**: check_models.js

### Removed Directories
- **vertex-deployment/**: Moved to archive (deployment completed)
- **vertex-merge-job/**: Removed (merge job completed successfully)
- **deployment/**: Moved all scripts to archive

### Archived Items
- All deployment scripts moved to `archive/deployment-scripts-2025-07-06/`
- Previous cleanup items remain in `archive/`

## Current Structure

### Active Directories
- **14b/**: Active 14B model work (preserved as requested)
- **archive/**: Historical files and scripts

### Active Files
- **README.md**: Main documentation
- **DEPLOY_SUCCESS.md**: IasoQL deployment documentation
- **MODEL_BRANDING_SUGGESTIONS.md**: Model naming suggestions
- **VERTEX_AI_TRAINING_SETUP.md**: Training setup guide
- **fhir-clickhouse-training-dataset-v8-FINAL.json**: Training dataset
- **requirements.txt**: Python dependencies

### Status Files
- **CLEANUP_COMPLETE_2025-07-06.md**: Previous cleanup record
- **TODO_FUTURE_2025-07-06.md**: Future improvements

## What's Left

The folder is now clean with only:
1. Essential documentation
2. The 14B model work directory (as requested)
3. Archived historical files
4. The final training dataset
5. Requirements file

All test scripts, temporary files, and completed deployment scripts have been removed or archived.