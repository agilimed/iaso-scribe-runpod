#!/usr/bin/env python3
"""
IasoQL-14B Training Script for Pre-Quantized Models

This script fine-tunes a pre-quantized 14B model using LoRA+DoRA.
Much faster startup and lower memory requirements.
"""

import os
import json
import torch
import logging
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime
import gc

from datasets import Dataset
from transformers import (
    AutoTokenizer, 
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
    EarlyStoppingCallback
)
from peft import (
    LoraConfig, 
    get_peft_model, 
    prepare_model_for_kbit_training,
    TaskType
)
from google.cloud import storage

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class IasoQL14BTrainerPreQuantized:
    def __init__(self, config: Dict):
        self.config = config
        # Path to pre-quantized model (local or GCS)
        self.model_path = config.get('quantized_model_path', './quantized_models/iasoql-14b-base-quantized')
        self.output_dir = config.get('output_dir', '/gcs/nexuscare-ai-training/models/iasoql-agilimed-healthcare-14b')
        self.dataset_path = config.get('dataset_path', '../fhir-clickhouse-training-dataset-v8-FINAL.json')
        
        logger.info(f"Initializing iasoql-agilimed-healthcare-14b trainer with pre-quantized model: {self.model_path}")
        
    def download_model_from_gcs(self, gcs_path: str, local_path: str):
        """Download pre-quantized model from GCS if needed"""
        logger.info(f"Downloading model from {gcs_path}")
        
        # Parse GCS path
        parts = gcs_path.replace("gs://", "").split("/", 1)
        bucket_name = parts[0]
        prefix = parts[1]
        
        client = storage.Client()
        bucket = client.bucket(bucket_name)
        
        Path(local_path).mkdir(parents=True, exist_ok=True)
        
        blobs = bucket.list_blobs(prefix=prefix)
        for blob in blobs:
            if blob.name.startswith(prefix):
                relative_path = blob.name[len(prefix):].lstrip("/")
                local_file = os.path.join(local_path, relative_path)
                
                Path(os.path.dirname(local_file)).mkdir(parents=True, exist_ok=True)
                blob.download_to_filename(local_file)
                logger.info(f"Downloaded: {relative_path}")
        
        return local_path
        
    def load_dataset(self) -> Dataset:
        """Load and prepare the FHIR ClickHouse training dataset"""
        logger.info(f"Loading dataset from {self.dataset_path}")
        
        with open(self.dataset_path, 'r') as f:
            data = json.load(f)
        
        # Extract SQL queries
        sql_examples = []
        for example in data['sql_queries']:
            prompt = f"Question: {example['question']}\nAnswer: {example['query']}"
            sql_examples.append({"text": prompt})
        
        # Add function examples
        for example in data.get('function_examples', []):
            prompt = f"Function: {example['name']}\nDescription: {example['description']}\nUsage: {example['usage']}"
            sql_examples.append({"text": prompt})
        
        dataset = Dataset.from_list(sql_examples)
        logger.info(f"Loaded {len(dataset)} training examples")
        
        return dataset
    
    def get_lora_config(self) -> LoraConfig:
        """Configure LoRA with DoRA enhancement"""
        return LoraConfig(
            r=32,  # Higher rank for 14B model
            lora_alpha=64,
            target_modules=[
                "q_proj", "k_proj", "v_proj", "o_proj",
                "gate_proj", "up_proj", "down_proj"
            ],
            lora_dropout=0.1,
            bias="none",
            task_type=TaskType.CAUSAL_LM,
            # DoRA specific parameters
            use_dora=True,  # Enable DoRA
            dora_magnitude_scale=True,  # Enable magnitude scaling
        )
    
    def prepare_model_and_tokenizer(self):
        """Load pre-quantized model and prepare for training"""
        
        # Download from GCS if needed
        model_path = self.model_path
        if model_path.startswith("gs://"):
            local_path = "/tmp/quantized-model"
            model_path = self.download_model_from_gcs(model_path, local_path)
        
        # Verify quantization info exists
        quant_info_path = os.path.join(model_path, "quantization_info.json")
        if os.path.exists(quant_info_path):
            with open(quant_info_path, 'r') as f:
                quant_info = json.load(f)
            logger.info(f"Loading pre-quantized model: {quant_info['base_model']}")
            logger.info(f"Quantized on: {quant_info['quantized_at']}")
            logger.info(f"Model size: {quant_info['model_size_gb']:.2f} GB")
        
        logger.info("Loading tokenizer...")
        self.tokenizer = AutoTokenizer.from_pretrained(
            model_path,
            trust_remote_code=True,
            padding_side="left"
        )
        
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        logger.info("Loading pre-quantized model...")
        # Load without quantization config since it's already quantized
        self.model = AutoModelForCausalLM.from_pretrained(
            model_path,
            device_map="auto",
            trust_remote_code=True,
            torch_dtype=torch.bfloat16,
        )
        
        # Prepare model for k-bit training
        self.model = prepare_model_for_kbit_training(self.model)
        
        # Apply LoRA+DoRA
        logger.info("Applying LoRA+DoRA configuration...")
        lora_config = self.get_lora_config()
        self.model = get_peft_model(self.model, lora_config)
        
        # Print trainable parameters
        self.model.print_trainable_parameters()
        
        # Enable gradient checkpointing for memory efficiency
        self.model.enable_input_require_grads()
        self.model.gradient_checkpointing_enable()
        
        logger.info("Model ready for training!")
        
    def tokenize_function(self, examples):
        """Tokenize the examples"""
        tokenized = self.tokenizer(
            examples["text"],
            truncation=True,
            padding="max_length",
            max_length=2048,
        )
        tokenized["labels"] = tokenized["input_ids"].copy()
        return tokenized
    
    def get_training_args(self) -> TrainingArguments:
        """Configure training arguments"""
        return TrainingArguments(
            output_dir=self.output_dir,
            num_train_epochs=3,
            per_device_train_batch_size=1,
            gradient_accumulation_steps=16,
            gradient_checkpointing=True,
            optim="paged_adamw_8bit",
            logging_steps=10,
            save_strategy="steps",
            save_steps=50,
            save_total_limit=3,
            evaluation_strategy="steps",
            eval_steps=100,
            warmup_steps=100,
            learning_rate=1e-4,
            lr_scheduler_type="cosine",
            bf16=True,
            tf32=True,
            push_to_hub=False,
            report_to=[],
            load_best_model_at_end=True,
            metric_for_best_model="loss",
            greater_is_better=False,
            # Memory optimization
            gradient_checkpointing_kwargs={"use_reentrant": False},
            ddp_find_unused_parameters=False,
            fsdp="full_shard auto_wrap",
            fsdp_config={
                "fsdp_transformer_layer_cls_to_wrap": ["Qwen2DecoderLayer"],
            },
        )
    
    def train(self):
        """Main training loop"""
        # Load dataset
        dataset = self.load_dataset()
        
        # Prepare model and tokenizer
        self.prepare_model_and_tokenizer()
        
        # Tokenize dataset
        logger.info("Tokenizing dataset...")
        tokenized_dataset = dataset.map(
            self.tokenize_function,
            batched=True,
            remove_columns=dataset.column_names
        )
        
        # Split dataset
        split_dataset = tokenized_dataset.train_test_split(test_size=0.1, seed=42)
        train_dataset = split_dataset["train"]
        eval_dataset = split_dataset["test"]
        
        # Data collator
        data_collator = DataCollatorForLanguageModeling(
            tokenizer=self.tokenizer,
            mlm=False,
        )
        
        # Training arguments
        training_args = self.get_training_args()
        
        # Initialize trainer
        trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
            data_collator=data_collator,
            callbacks=[EarlyStoppingCallback(early_stopping_patience=3)],
        )
        
        # Check for checkpoint
        checkpoint = None
        if os.path.exists(self.output_dir):
            checkpoints = list(Path(self.output_dir).glob("checkpoint-*"))
            if checkpoints:
                checkpoint = str(max(checkpoints, key=lambda x: int(x.name.split("-")[-1])))
                logger.info(f"Resuming from checkpoint: {checkpoint}")
        
        # Train
        logger.info("Starting training...")
        trainer.train(resume_from_checkpoint=checkpoint)
        
        # Save final model
        logger.info("Saving final model...")
        trainer.save_model(f"{self.output_dir}/final")
        self.tokenizer.save_pretrained(f"{self.output_dir}/final")
        
        # Save training info
        training_info = {
            "base_model": self.model_path,
            "training_completed": datetime.now().isoformat(),
            "final_loss": trainer.state.log_history[-1].get('loss', 'N/A'),
            "total_steps": trainer.state.global_step,
        }
        
        with open(f"{self.output_dir}/final/training_info.json", "w") as f:
            json.dump(training_info, f, indent=2)
        
        # Save to GCS if configured
        if self.output_dir.startswith('/gcs/'):
            self._upload_to_gcs()
        
        logger.info("Training completed successfully!")
        
    def _upload_to_gcs(self):
        """Upload model to Google Cloud Storage"""
        logger.info("Uploading model to GCS...")
        client = storage.Client()
        bucket_name = "nexuscare-ai-training"
        prefix = "models/iasoql-agilimed-healthcare-14b"
        
        bucket = client.bucket(bucket_name)
        
        for root, dirs, files in os.walk(f"{self.output_dir}/final"):
            for file in files:
                local_path = os.path.join(root, file)
                blob_path = f"{prefix}/{os.path.relpath(local_path, f'{self.output_dir}/final')}"
                blob = bucket.blob(blob_path)
                blob.upload_from_filename(local_path)
                logger.info(f"Uploaded {blob_path}")

def main():
    # Configuration
    config = {
        # Use pre-quantized model (local or GCS path)
        "quantized_model_path": os.environ.get(
            "QUANTIZED_MODEL_PATH", 
            "./quantized_models/iasoql-14b-base-quantized"
        ),
        "output_dir": os.environ.get(
            "OUTPUT_DIR", 
            "/gcs/nexuscare-ai-training/models/iasoql-agilimed-healthcare-14b"
        ),
        "dataset_path": os.environ.get(
            "DATASET_PATH", 
            "../fhir-clickhouse-training-dataset-v8-FINAL.json"
        ),
    }
    
    # Initialize trainer
    trainer = IasoQL14BTrainerPreQuantized(config)
    
    # Train
    trainer.train()

if __name__ == "__main__":
    main()