# Complete Workflow: Pre-Quantize → Train → Deploy

## Overview

This workflow uses the recommended approach of pre-quantizing the base model, then training on the quantized version.

## Step 1: Pre-Quantize the Base Model (One-time)

This step creates a quantized version of XiYanSQL-QwenCoder-14B-2504.

```bash
# Run the quantization script
python quantize_base_model.py
```

This will:
- Download the 14B model from HuggingFace
- Quantize to 4-bit using BitsAndBytes
- Save locally (~7GB) 
- Optionally upload to GCS

**Output**: `./quantized_models/iasoql-14b-base-quantized/` or `gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized`

## Step 2: Train on Pre-Quantized Model

### Option A: Local Quantized Model
```bash
# If you quantized locally
export QUANTIZED_MODEL_PATH="./quantized_models/iasoql-14b-base-quantized"
export HF_TOKEN="your-huggingface-token"

python submit_training_14b_prequantized.py
```

### Option B: GCS Quantized Model
```bash
# If you uploaded to GCS
export QUANTIZED_MODEL_PATH="gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized"
export HF_TOKEN="your-huggingface-token"

python submit_training_14b_prequantized.py
```

## Step 3: Deploy with LoRAResolver

After training completes:

```bash
# Generate deployment files
python deploy_vllm_lora_resolver.py

# Build container
gcloud builds submit --config=cloudbuild-vllm-resolver.yaml --project=nexuscare-463413

# Deploy to Kubernetes
kubectl apply -f deploy-vllm-resolver.yaml
```

## Benefits of This Approach

### Training Benefits:
- ✅ **5x faster startup** (loads in ~30 seconds vs 5 minutes)
- ✅ **Lower memory** (stays at 7GB, no 28GB spike)
- ✅ **Consistent** (same quantized model every time)
- ✅ **Reusable** (quantize once, train multiple times)

### Deployment Benefits:
- ✅ **Fast pod startup** (critical for auto-scaling)
- ✅ **Predictable memory** (easier resource planning)
- ✅ **Version control** (can track quantized model versions)

## File Structure After Completion

```
14b/
├── quantized_models/
│   └── iasoql-14b-base-quantized/    # Pre-quantized base model
│       ├── model.safetensors
│       ├── config.json
│       ├── tokenizer.json
│       └── quantization_info.json
│
├── trained_models/
│   └── iasoql-agilimed-healthcare-14b/  # LoRA adapters
│       ├── adapter_model.safetensors
│       ├── adapter_config.json
│       └── training_info.json
│
└── deployment/
    ├── Dockerfile.vllm-resolver
    └── deploy-vllm-resolver.yaml
```

## Monitoring Progress

1. **Quantization**: Watch console output (~10 minutes)
2. **Training**: 
   - Vertex AI Console: https://console.cloud.google.com/vertex-ai/training/custom-jobs
   - Logs: `gcloud ai custom-jobs stream-logs JOB_ID`
3. **Deployment**: 
   - `kubectl get pods -n nexuscare -w`
   - `kubectl logs -n nexuscare -l app=iasoql-vllm-resolver -f`

## Troubleshooting

### Quantization OOM
```bash
# Use CPU-only quantization if GPU OOM
CUDA_VISIBLE_DEVICES="" python quantize_base_model.py
```

### Training Issues
```bash
# Check job status
gcloud ai custom-jobs list --region=europe-west4

# Stream logs
gcloud ai custom-jobs stream-logs JOB_ID --region=europe-west4
```

### Deployment Issues
```bash
# Check LoRA resolver
kubectl exec -n nexuscare POD_NAME -- ls -la /models/lora_adapters/
```

## Next: Start with Step 1!

Ready to begin? Start by running the quantization script!