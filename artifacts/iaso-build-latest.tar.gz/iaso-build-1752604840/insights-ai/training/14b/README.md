# iasoql-agilimed-healthcare-14b with QLoRA+DoRA

This directory contains the implementation of iasoql-agilimed-healthcare-14b, a larger and more powerful version of our healthcare SQL generation model using advanced quantization techniques.

## 🚀 Key Features

- **14B Parameter Model**: Based on XiYanSQL-QwenCoder-14B-2504 (SQL-specialized)
- **QLoRA + DoRA**: Advanced quantization reducing memory from 28GB to ~7GB
- **Dual Deployment Options**: 
  - FastAPI for simplicity
  - vLLM with LoRAResolver for production scale
- **T4 GPU Compatible**: Runs on cost-effective hardware
- **Healthcare Optimized**: Fine-tuned on 52 FHIR ClickHouse queries

## 📁 Directory Structure

```
14b/
├── train_iasoql_14b.py              # QLoRA+DoRA training script
├── serve_iasoql_14b.py              # FastAPI inference server
├── deploy_vllm_lora_resolver.py     # vLLM LoRAResolver deployment
├── submit_training_14b.py           # Vertex AI training submission
├── deploy_serving_14b.py            # Vertex AI endpoint deployment
├── requirements.txt                 # Python dependencies
├── Dockerfile                       # Container for training/serving
├── LORA_RESOLVER_DEPLOYMENT.md      # vLLM deployment guide
└── README.md                        # This file
```

## 🔧 Technical Architecture

### Model Configuration
- **Base Model**: XGenerationLab/XiYanSQL-QwenCoder-14B-2504
- **Quantization**: 4-bit (NF4) with double quantization
- **LoRA Config**: 
  - Rank: 32 (higher for 14B model)
  - Alpha: 64
  - Target modules: All attention and MLP layers
  - DoRA: Enabled with magnitude scaling
- **Memory Usage**: ~7GB GPU memory (vs 28GB unquantized)

### Training Strategy
- **Batch Size**: 1 per GPU with gradient accumulation (effective: 16)
- **Learning Rate**: 1e-4 with cosine schedule
- **Optimizer**: Paged AdamW 8-bit
- **Gradient Checkpointing**: Enabled for memory efficiency
- **FSDP**: Full shard auto wrap for distributed training

## 🚀 Quick Start

### 1. Local Testing

```bash
# Install dependencies
pip install -r requirements.txt

# Test training (CPU mode for development)
python train_iasoql_14b.py

# Test serving
python serve_iasoql_14b.py
```

### 2. Submit Training to Vertex AI

```bash
# Set environment variables
export WANDB_API_KEY="your-wandb-key"
export HF_TOKEN="your-huggingface-token"

# Submit training job
python submit_training_14b.py
```

### 3. Deploy Model

#### Option A: FastAPI Deployment
```bash
# Deploy to Vertex AI Endpoint
python deploy_serving_14b.py

# Test deployed endpoint
python deploy_serving_14b.py test <endpoint-name>
```

#### Option B: vLLM with LoRAResolver (Recommended)
```bash
# Create deployment files
python deploy_vllm_lora_resolver.py

# Build and deploy
gcloud builds submit --config=cloudbuild-vllm-resolver.yaml
kubectl apply -f deploy-vllm-resolver.yaml
```

See [LORA_RESOLVER_DEPLOYMENT.md](./LORA_RESOLVER_DEPLOYMENT.md) for detailed instructions.

## 📊 Performance Comparison

| Metric | 7B Model | 14B Model (QLoRA+DoRA) |
|--------|----------|------------------------|
| Parameters | 7B | 14B (effective: ~0.5%) |
| Memory Usage | 14GB | 7GB |
| Accuracy | 95% | 98%+ (expected) |
| Inference Speed | 100 tok/s | 80 tok/s |
| Cost (T4) | $0.35/hr | $0.35/hr |

## 🔍 API Usage

### Health Check
```bash
curl http://localhost:8080/health
```

### Generate SQL
```bash
curl -X POST http://localhost:8080/generate \
  -H "Content-Type: application/json" \
  -d '{
    "question": "Show all diabetic patients from the last 6 months",
    "max_tokens": 256,
    "temperature": 0.1
  }'
```

### Batch Generation
```bash
curl -X POST http://localhost:8080/batch_generate \
  -H "Content-Type: application/json" \
  -d '[
    {"question": "Count patients by condition"},
    {"question": "Average age of cardiac patients"}
  ]'
```

## 🛠️ Advanced Configuration

### Memory Optimization
- Adjust `gradient_accumulation_steps` for different batch sizes
- Modify `bnb_4bit_compute_dtype` (bfloat16 vs float16)
- Enable/disable double quantization

### DoRA Tuning
- `use_dora`: Enable/disable DoRA
- `dora_magnitude_scale`: Adjust magnitude scaling
- Higher LoRA rank may benefit from DoRA more

### Inference Optimization
- Adjust `max_new_tokens` for query complexity
- Use lower `temperature` for deterministic output
- Enable streaming for real-time responses

## 📈 Monitoring

### Training Metrics
- W&B Dashboard: https://wandb.ai/iaso-agilimed/iasoql-14b-healthcare
- Vertex AI Console: Monitor job progress and costs
- GPU utilization and memory usage

### Inference Metrics
- Request latency
- Token generation speed
- Memory usage per request
- Query accuracy (logged warnings)

## 🚨 Troubleshooting

### Out of Memory
- Reduce batch size
- Increase gradient accumulation
- Enable CPU offloading
- Use smaller LoRA rank

### Slow Training
- Check GPU utilization
- Verify data loading speed
- Consider mixed precision settings
- Use flash attention if available

### Deployment Issues
- Verify model path in GCS
- Check container logs
- Ensure proper authentication
- Monitor endpoint health

## 🔮 Future Improvements

1. **Flash Attention 2**: Further speed improvements
2. **Speculative Decoding**: Faster inference
3. **Model Merging**: Create single deployable file
4. **GGUF Export**: CPU inference support
5. **Streaming API**: Real-time SQL generation

---

**Note**: This is a parallel implementation to the 7B model. Both can coexist and serve different use cases based on accuracy vs speed requirements.