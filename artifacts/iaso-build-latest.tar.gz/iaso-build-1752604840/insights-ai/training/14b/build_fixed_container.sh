#!/bin/bash

# Build and push fixed training container with correct transformers version

PROJECT_ID="nexuscare-463413"
IMAGE_NAME="iasoql-14b-trainer-fixed"
IMAGE_TAG="latest"
IMAGE_URI="gcr.io/${PROJECT_ID}/${IMAGE_NAME}:${IMAGE_TAG}"

echo "Building fixed container with transformers>=4.37.0..."

# Build the Docker image
docker build -f Dockerfile.fixed -t ${IMAGE_URI} .

echo "Built image: ${IMAGE_URI}"

# Push to Google Container Registry
echo "Pushing to GCR..."
docker push ${IMAGE_URI}

echo "✅ Fixed container pushed successfully!"
echo "Image URI: ${IMAGE_URI}"
echo ""
echo "Use this image in your training job YAML:"
echo "  imageUri: ${IMAGE_URI}"