# IasoQL Testing Guide for Conversational Analytics

## Current Architecture Status

The conversational analytics module at http://localhost:3000/admin/insights/chat is currently using:
- **LlamaIndex + SQLCoder** (NOT IasoQL yet)
- SQLCoder endpoint: `https://sqlcoder-endpoint-kt4atarccq-uc.a.run.app`
- Service: `LlamaIndexConversationalService.ts`

## How to Test IasoQL Integration

### Option 1: Quick Test Script

```bash
# 1. First, test IasoQL directly
cd backend
node src/scripts/test-iasoql-service-health.js

# 2. Test with complex queries
node src/scripts/test-enhanced-iasoql.js
```

### Option 2: Integrate IasoQL into Conversational Analytics

To switch from SQLCoder to IasoQL, you need to modify the LlamaIndexConversationalService:

```javascript
// In LlamaIndexConversationalService.ts, change line 73:
// FROM:
this.sqlCoderUrl = process.env.SQLCODER_SERVICE_URL || 'https://sqlcoder-endpoint-kt4atarccq-uc.a.run.app';

// TO:
this.sqlCoderUrl = process.env.IASOQL_SERVICE_URL || 'https://iasoql-agilimed-healthcare-kt4atarccq-uc.a.run.app';
```

### Option 3: Test IasoQL via API

```bash
# 1. Get authentication token
TOKEN=$(gcloud auth print-identity-token)

# 2. Test IasoQL directly
curl -X POST https://iasoql-agilimed-healthcare-kt4atarccq-uc.a.run.app/v1/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer token-iasoql-agilimed" \
  -H "X-Serverless-Authorization: Bearer $TOKEN" \
  -d '{
    "model": "iasoql-agilimed-healthcare",
    "prompt": "Generate ClickHouse SQL to count patients by gender",
    "max_tokens": 500,
    "temperature": 0.1
  }'
```

### Option 4: Create a Test Endpoint

Create a new test file to compare SQLCoder vs IasoQL:

```javascript
// src/scripts/test-compare-sql-generators.js
const { createIasoQLLLM } = require('../services/ai/llamaindex/IasoQLLLM');
const { createEnhancedIasoQLLLM } = require('../services/ai/llamaindex/EnhancedIasoQLLLM');

async function compareGenerators() {
  const queries = [
    "How many patients do we have?",
    "Show me patients with diabetes",
    "Find patients with fever admitted in last 72 hours",
    "What's the average length of stay by department?"
  ];

  // Test IasoQL
  const iasoql = createIasoQLLLM({ model: 'iasoql' });
  
  // Test Enhanced IasoQL
  const enhancedIasoql = createEnhancedIasoQLLLM({ 
    model: 'iasoql',
    useQueryAnalyzer: true 
  });
  await enhancedIasoql.initialize();

  for (const query of queries) {
    console.log(`\nQuery: "${query}"`);
    
    // Standard IasoQL
    const iasoqlResult = await iasoql.complete({ prompt: query });
    console.log("IasoQL:", iasoqlResult.text);
    
    // Enhanced IasoQL
    const enhancedResult = await enhancedIasoql.complete({ prompt: query });
    console.log("Enhanced:", enhancedResult.text);
  }
}

compareGenerators().catch(console.error);
```

## Testing in the UI

### Step 1: Access the Chat Interface
1. Open http://localhost:3000/admin/insights/chat
2. Login with credentials (sysadmin, demo, or appadmin)

### Step 2: Test Queries

Try these test queries to verify functionality:

#### Basic Queries
- "How many patients do we have?"
- "Show me all encounters today"
- "Count observations by type"

#### Medium Complexity
- "Show me patients by gender"
- "What's the bed occupancy rate?"
- "List all emergency department visits"

#### Complex Queries (Test Token Limits)
- "Find all diabetic patients with HbA1c > 7 who have had more than 3 emergency visits in the past 6 months"
- "Show me patients with both diabetes and heart disease who haven't had a checkup in the last 90 days"
- "Calculate the average medication adherence rate for chronic patients and identify high-risk cases"

### Step 3: Monitor the Backend Logs

```bash
# Watch backend logs
docker logs -f nexuscare-backend

# Or if running locally
# Look for these log messages:
# [LlamaIndex] Using Query Engine for enhanced SQL generation
# [LlamaIndex] SQLCoder response received
```

## Current Integration Points

### 1. API Endpoint
- **URL**: `/api/insights/chat/query`
- **Method**: POST
- **Auth**: JWT token required

### 2. Request Format
```json
{
  "query": "How many patients do we have?",
  "sessionId": "optional-session-id"
}
```

### 3. Response Format
```json
{
  "success": true,
  "query": "How many patients do we have?",
  "interpretation": "Analyzing demographics data...",
  "sql": "SELECT COUNT(*) FROM fhir_current WHERE...",
  "results": [...],
  "insights": ["Found 1,234 patients"],
  "suggestions": ["Show gender breakdown"],
  "visualizationType": "metric",
  "metadata": {
    "executionTime": 1234,
    "confidence": 0.9
  }
}
```

## How to Switch to IasoQL

### Option A: Environment Variable
```bash
# Set in .env file
SQLCODER_SERVICE_URL=https://iasoql-agilimed-healthcare-kt4atarccq-uc.a.run.app
```

### Option B: Direct Code Change
Modify `LlamaIndexConversationalService.ts` line 73

### Option C: Create New Service
Create `IasoQLConversationalService.ts` that uses IasoQL instead of SQLCoder

## Testing Enhanced Features

### 1. Query Complexity Analysis
```javascript
// The Enhanced IasoQL will automatically:
- Detect query complexity
- Use existing metrics if available
- Cache similar queries
- Handle token limits with chunking
```

### 2. Monitor Performance
```javascript
// Look for these in logs:
"Using existing metric: <metric_id>"
"Used cached query (95% match)"
"Generated in 250ms"
```

### 3. Test Token Limit Handling
Use very complex queries to trigger progressive generation:
```
"Find all patients with chronic conditions who have had abnormal lab results in the past 90 days, calculate their risk scores based on comorbidities and medication adherence, group by department and age range, and identify those requiring immediate intervention"
```

## Troubleshooting

### Common Issues

1. **401 Unauthorized**
   - Check Google Cloud authentication
   - Verify API key is correct
   - Ensure identity token is fresh

2. **SQL Generation Errors**
   - Check schema context is correct
   - Verify ClickHouse table structure
   - Look for SQL syntax issues

3. **Performance Issues**
   - Enable query caching
   - Use existing metrics
   - Check token limits

### Debug Mode
```javascript
// Add to your test script
process.env.DEBUG = 'iasoql:*';
```

## Next Steps

1. **Test Current Setup**: Verify SQLCoder is working
2. **Compare Models**: Run comparison tests
3. **Switch to IasoQL**: Update service URL
4. **Enable Enhancements**: Use EnhancedIasoQLLLM
5. **Monitor Performance**: Track improvements

## Summary

The conversational analytics module is currently using SQLCoder, not IasoQL. To test IasoQL:
1. Use the test scripts provided
2. Switch the service URL
3. Test with various query complexities
4. Monitor performance improvements
5. Enable enhanced features for better performance