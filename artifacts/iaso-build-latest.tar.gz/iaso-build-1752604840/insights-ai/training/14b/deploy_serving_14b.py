#!/usr/bin/env python3
"""
Deploy IasoQL-14B FastAPI server to Vertex AI Endpoints
"""

import os
import json
from datetime import datetime
from google.cloud import aiplatform

# Initialize Vertex AI
PROJECT_ID = "nexuscare-463413"
REGION = "us-central1"
BUCKET_NAME = "nexuscare-ai-training"

aiplatform.init(
    project=PROJECT_ID,
    location=REGION,
)

def create_model():
    """Create a Vertex AI Model resource"""
    
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    model_name = f"iasoql-agilimed-healthcare-14b-{timestamp}"
    
    # Container image for serving
    serving_image_uri = f"gcr.io/{PROJECT_ID}/iasoql-14b-serving:latest"
    
    # Create model
    model = aiplatform.Model.upload(
        display_name=model_name,
        serving_container_image_uri=serving_image_uri,
        serving_container_ports=[8080],
        serving_container_health_route="/health",
        serving_container_predict_route="/generate",
        serving_container_environment_variables={
            "MODEL_PATH": f"gs://{BUCKET_NAME}/models/iasoql-agilimed-healthcare-14b/latest",
        },
    )
    
    print(f"Model created: {model_name}")
    print(f"Model resource name: {model.resource_name}")
    
    return model

def deploy_model(model):
    """Deploy model to an endpoint"""
    
    endpoint_name = f"iasoql-14b-endpoint-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    
    # Create endpoint
    endpoint = aiplatform.Endpoint.create(
        display_name=endpoint_name,
    )
    
    print(f"Endpoint created: {endpoint_name}")
    
    # Deploy model to endpoint
    deployed_model = endpoint.deploy(
        model=model,
        deployed_model_display_name="iasoql-agilimed-healthcare-14b",
        machine_type="g2-standard-16",  # T4 GPU
        accelerator_type="NVIDIA_TESLA_T4",
        accelerator_count=1,
        min_replica_count=1,
        max_replica_count=3,
        traffic_split={"0": 100},
        enable_access_logging=True,
    )
    
    print(f"Model deployed to endpoint: {endpoint.resource_name}")
    print(f"Endpoint URL: https://{REGION}-aiplatform.googleapis.com/v1/{endpoint.resource_name}:predict")
    
    return endpoint

def build_serving_image():
    """Build and push serving Docker image"""
    
    # Create Dockerfile for serving only
    serving_dockerfile = """FROM nvidia/cuda:12.1.0-cudnn8-runtime-ubuntu22.04

ENV DEBIAN_FRONTEND=noninteractive
ENV PYTHONUNBUFFERED=1

RUN apt-get update && apt-get install -y \\
    python3.10 \\
    python3-pip \\
    && rm -rf /var/lib/apt/lists/*

RUN ln -s /usr/bin/python3.10 /usr/bin/python
RUN python -m pip install --upgrade pip

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY serve_iasoql_14b.py .

EXPOSE 8080

CMD ["python", "serve_iasoql_14b.py"]
"""
    
    with open("Dockerfile.serving", "w") as f:
        f.write(serving_dockerfile)
    
    # Create cloudbuild for serving image
    cloudbuild_config = {
        "steps": [
            {
                "name": "gcr.io/cloud-builders/docker",
                "args": [
                    "build",
                    "-t", f"gcr.io/{PROJECT_ID}/iasoql-14b-serving:latest",
                    "-f", "Dockerfile.serving",
                    "."
                ]
            },
            {
                "name": "gcr.io/cloud-builders/docker",
                "args": [
                    "push",
                    f"gcr.io/{PROJECT_ID}/iasoql-14b-serving:latest"
                ]
            }
        ],
        "timeout": "1800s"
    }
    
    with open("cloudbuild-serving.yaml", "w") as f:
        import yaml
        yaml.dump(cloudbuild_config, f)
    
    # Submit build
    os.system(f"gcloud builds submit --config=cloudbuild-serving.yaml --project={PROJECT_ID}")
    
    print("Serving image built and pushed successfully!")

def test_endpoint(endpoint_name: str):
    """Test the deployed endpoint"""
    
    # Create test client
    endpoint = aiplatform.Endpoint(endpoint_name)
    
    # Test request
    test_request = {
        "instances": [{
            "question": "Show me all patients diagnosed with diabetes in the last 6 months",
            "max_tokens": 256,
            "temperature": 0.1
        }]
    }
    
    print("Testing endpoint...")
    response = endpoint.predict(instances=test_request["instances"])
    
    print("Response:", json.dumps(response.predictions, indent=2))

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        # Test existing endpoint
        if len(sys.argv) < 3:
            print("Usage: python deploy_serving_14b.py test <endpoint_name>")
            sys.exit(1)
        test_endpoint(sys.argv[2])
    else:
        # Build serving image
        build_serving_image()
        
        # Create and deploy model
        model = create_model()
        endpoint = deploy_model(model)
        
        # Test the endpoint
        test_endpoint(endpoint.resource_name)