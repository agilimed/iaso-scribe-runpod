#!/usr/bin/env python3
"""
Submit training job with tokenizer fix for IasoQL-14B
Fixes the Qwen2Tokenizer compatibility issue
"""

import subprocess
import sys
from datetime import datetime
from pathlib import Path

def main():
    # Job configuration
    project_id = "nexuscare-463413"
    location = "us-central1"
    job_name = f"iasoql-14b-training-tokenizer-fix-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    job_spec = Path(__file__).parent / "training-job-tokenizer-fix.yaml"
    
    # Verify job spec exists
    if not job_spec.exists():
        print(f"❌ Job spec not found: {job_spec}")
        sys.exit(1)
    
    print(f"📋 Submitting training job: {job_name}")
    print(f"📍 Region: {location}")
    print(f"📄 Job spec: {job_spec}")
    print()
    
    # Submit job using gcloud
    cmd = [
        "gcloud", "ai", "custom-jobs", "create",
        f"--region={location}",
        f"--display-name={job_name}",
        f"--config={job_spec}",
        f"--project={project_id}"
    ]
    
    print("🚀 Submitting job to Vertex AI...")
    print(f"Command: {' '.join(cmd)}")
    print()
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        print("✅ Job submitted successfully!")
        print()
        print("Output:")
        print(result.stdout)
        
        # Extract job ID from output
        for line in result.stdout.splitlines():
            if "name:" in line:
                job_id = line.split("/")[-1]
                print(f"\n📋 Job ID: {job_id}")
                print(f"\n🔗 View job: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={project_id}")
                print(f"\n📊 Monitor logs: https://console.cloud.google.com/logs/viewer?project={project_id}&resource=ml_job%2Fjob_id%2F{job_id}")
                break
                
    except subprocess.CalledProcessError as e:
        print(f"❌ Error submitting job: {e}")
        print("stderr:", e.stderr)
        sys.exit(1)
    
    print("\n💡 To monitor the job:")
    print("   ./monitor_jobs.sh")
    print("\n💡 After training completes:")
    print("   python3 deploy_vllm_lora_resolver.py")

if __name__ == "__main__":
    main()