#!/usr/bin/env python3
"""
Compare IasoQL-7B and IasoQL-14B models
"""

import json
import time
import requests
from typing import Dict, List
import pandas as pd

# Test queries from the training dataset
TEST_QUERIES = [
    {
        "id": "basic_count",
        "question": "How many patients are in the system?",
        "expected_keywords": ["COUNT", "patient", "SELECT"]
    },
    {
        "id": "condition_filter", 
        "question": "Show all patients diagnosed with diabetes (ICD-10 code E11)",
        "expected_keywords": ["patient", "condition", "E11", "WHERE"]
    },
    {
        "id": "time_range",
        "question": "List all encounters from the last 30 days",
        "expected_keywords": ["encounter", "toDate", "now()", "INTERVAL"]
    },
    {
        "id": "aggregation",
        "question": "What is the average age of patients with hypertension?",
        "expected_keywords": ["AVG", "age", "patient", "condition", "hypertension"]
    },
    {
        "id": "complex_join",
        "question": "Show all medications prescribed to cardiac patients in 2024",
        "expected_keywords": ["medication_request", "patient", "condition", "cardiac", "2024"]
    }
]

class ModelComparator:
    def __init__(self, model_7b_url: str, model_14b_url: str):
        self.model_7b_url = model_7b_url
        self.model_14b_url = model_14b_url
        self.results = []
    
    def test_query(self, model_url: str, query: Dict) -> Dict:
        """Test a single query against a model"""
        
        start_time = time.time()
        
        try:
            response = requests.post(
                f"{model_url}/generate",
                json={
                    "question": query["question"],
                    "max_tokens": 512,
                    "temperature": 0.1
                },
                timeout=30
            )
            
            end_time = time.time()
            
            if response.status_code == 200:
                result = response.json()
                
                # Check for expected keywords
                generated_sql = result.get("query", "").upper()
                keywords_found = sum(
                    1 for keyword in query["expected_keywords"]
                    if keyword.upper() in generated_sql
                )
                keyword_coverage = keywords_found / len(query["expected_keywords"])
                
                return {
                    "success": True,
                    "sql": result.get("query", ""),
                    "confidence": result.get("confidence", 0),
                    "latency": end_time - start_time,
                    "keyword_coverage": keyword_coverage,
                    "warnings": result.get("warnings", [])
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP {response.status_code}",
                    "latency": end_time - start_time
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "latency": time.time() - start_time
            }
    
    def compare_models(self):
        """Run comparison tests on both models"""
        
        print("Starting model comparison...\n")
        
        for query in TEST_QUERIES:
            print(f"Testing: {query['question']}")
            
            # Test 7B model
            print("  - Testing 7B model...")
            result_7b = self.test_query(self.model_7b_url, query)
            
            # Test 14B model
            print("  - Testing 14B model...")
            result_14b = self.test_query(self.model_14b_url, query)
            
            # Store results
            self.results.append({
                "query_id": query["id"],
                "question": query["question"],
                "7b_result": result_7b,
                "14b_result": result_14b
            })
            
            print(f"  ✓ Complete\n")
    
    def generate_report(self):
        """Generate comparison report"""
        
        print("\n=== Model Comparison Report ===\n")
        
        # Calculate aggregate metrics
        metrics_7b = {
            "success_rate": 0,
            "avg_confidence": 0,
            "avg_latency": 0,
            "avg_keyword_coverage": 0
        }
        
        metrics_14b = {
            "success_rate": 0,
            "avg_confidence": 0,
            "avg_latency": 0,
            "avg_keyword_coverage": 0
        }
        
        successful_7b = 0
        successful_14b = 0
        
        for result in self.results:
            if result["7b_result"]["success"]:
                successful_7b += 1
                metrics_7b["avg_confidence"] += result["7b_result"].get("confidence", 0)
                metrics_7b["avg_keyword_coverage"] += result["7b_result"].get("keyword_coverage", 0)
            metrics_7b["avg_latency"] += result["7b_result"]["latency"]
            
            if result["14b_result"]["success"]:
                successful_14b += 1
                metrics_14b["avg_confidence"] += result["14b_result"].get("confidence", 0)
                metrics_14b["avg_keyword_coverage"] += result["14b_result"].get("keyword_coverage", 0)
            metrics_14b["avg_latency"] += result["14b_result"]["latency"]
        
        n = len(self.results)
        metrics_7b["success_rate"] = successful_7b / n if n > 0 else 0
        metrics_14b["success_rate"] = successful_14b / n if n > 0 else 0
        
        if successful_7b > 0:
            metrics_7b["avg_confidence"] /= successful_7b
            metrics_7b["avg_keyword_coverage"] /= successful_7b
        
        if successful_14b > 0:
            metrics_14b["avg_confidence"] /= successful_14b
            metrics_14b["avg_keyword_coverage"] /= successful_14b
        
        metrics_7b["avg_latency"] /= n if n > 0 else 1
        metrics_14b["avg_latency"] /= n if n > 0 else 1
        
        # Print summary table
        print("Summary Metrics:")
        print("-" * 60)
        print(f"{'Metric':<30} {'7B Model':<15} {'14B Model':<15}")
        print("-" * 60)
        print(f"{'Success Rate':<30} {metrics_7b['success_rate']:.1%} {metrics_14b['success_rate']:.1%}")
        print(f"{'Average Confidence':<30} {metrics_7b['avg_confidence']:.2f} {metrics_14b['avg_confidence']:.2f}")
        print(f"{'Average Latency (s)':<30} {metrics_7b['avg_latency']:.2f} {metrics_14b['avg_latency']:.2f}")
        print(f"{'Keyword Coverage':<30} {metrics_7b['avg_keyword_coverage']:.1%} {metrics_14b['avg_keyword_coverage']:.1%}")
        
        # Detailed results
        print("\n\nDetailed Results:")
        print("=" * 80)
        
        for result in self.results:
            print(f"\nQuery: {result['question']}")
            print("-" * 80)
            
            # 7B Result
            print("7B Model:")
            if result["7b_result"]["success"]:
                print(f"  SQL: {result['7b_result']['sql'][:100]}...")
                print(f"  Confidence: {result['7b_result']['confidence']:.2f}")
                print(f"  Latency: {result['7b_result']['latency']:.2f}s")
            else:
                print(f"  Error: {result['7b_result']['error']}")
            
            # 14B Result
            print("\n14B Model:")
            if result["14b_result"]["success"]:
                print(f"  SQL: {result['14b_result']['sql'][:100]}...")
                print(f"  Confidence: {result['14b_result']['confidence']:.2f}")
                print(f"  Latency: {result['14b_result']['latency']:.2f}s")
            else:
                print(f"  Error: {result['14b_result']['error']}")
        
        # Save results to file
        self.save_results()
    
    def save_results(self):
        """Save comparison results to JSON"""
        
        output = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "model_7b_url": self.model_7b_url,
            "model_14b_url": self.model_14b_url,
            "results": self.results
        }
        
        with open("model_comparison_results.json", "w") as f:
            json.dump(output, f, indent=2)
        
        print("\n\nResults saved to model_comparison_results.json")

def main():
    """Run model comparison"""
    
    import argparse
    
    parser = argparse.ArgumentParser(description="Compare IasoQL-7B and IasoQL-14B models")
    parser.add_argument(
        "--model-7b-url",
        default="http://localhost:8080",
        help="URL for 7B model endpoint"
    )
    parser.add_argument(
        "--model-14b-url", 
        default="http://localhost:8081",
        help="URL for 14B model endpoint"
    )
    
    args = parser.parse_args()
    
    comparator = ModelComparator(args.model_7b_url, args.model_14b_url)
    comparator.compare_models()
    comparator.generate_report()

if __name__ == "__main__":
    main()