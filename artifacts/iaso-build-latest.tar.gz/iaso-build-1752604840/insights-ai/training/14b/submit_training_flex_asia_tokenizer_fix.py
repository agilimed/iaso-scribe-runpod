#!/usr/bin/env python3
"""
Submit training job with tokenizer fix using FLEX_START in asia-southeast1
Uses preemptible A100 GPU for cost optimization
"""

from google.cloud import aiplatform
from datetime import datetime
import time

# Initialize Vertex AI
project_id = "nexuscare-463413"
location = "asia-southeast1"  # Best availability for A100s
aiplatform.init(project=project_id, location=location)

# Job configuration
job_name = f"iasoql-14b-training-tokenizer-fix-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
job_spec_path = "training-job-tokenizer-fix.yaml"

# Read job spec
with open(job_spec_path, 'r') as f:
    import yaml
    job_spec = yaml.safe_load(f)

# Create custom job with FLEX_START scheduling
print(f"🚀 Submitting training job: {job_name}")
print(f"📍 Region: {location} (best A100 availability)")
print(f"⚡ Scheduling: FLEX_START (preemptible)")
print(f"🖥️  GPU: 1x NVIDIA A100")
print()

job = aiplatform.CustomJob(
    display_name=job_name,
    worker_pool_specs=job_spec['workerPoolSpecs'],
    scheduling={
        "strategy": "FLEX_START",  # Dynamic Workload Scheduler
        "disable_retries": False,
        "restart_job_on_worker_restart": True,
        "max_wait_duration": "86400s",  # 24 hours max wait
        "max_run_duration": "86400s",    # 24 hours max runtime
    }
)

# Submit the job
print("📤 Submitting to Vertex AI...")
job.submit(enable_web_access=True)

print(f"✅ Job submitted successfully!")
print(f"📋 Job ID: {job.resource_name.split('/')[-1]}")
print(f"🔗 Console: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={project_id}")
print()
print("⏱️  The job will start when resources become available (FLEX_START)")
print("💰 Using preemptible pricing (~$1.36/hour for A100)")
print()
print("📊 Monitor progress:")
print("   ./monitor_jobs.sh")
print()
print("💡 After training completes:")
print("   python3 deploy_vllm_lora_resolver.py")