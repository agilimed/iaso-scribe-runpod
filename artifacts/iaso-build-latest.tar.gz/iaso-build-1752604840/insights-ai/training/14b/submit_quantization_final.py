#!/usr/bin/env python3
"""
Submit quantization job with preemptible instances
"""

import os
from datetime import datetime
from google.cloud import aiplatform_v1
from google.protobuf import duration_pb2

PROJECT_ID = "nexuscare-463413"
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = f"ai-training@{PROJECT_ID}.iam.gserviceaccount.com"

# Regions to try in order
REGIONS = [
    "europe-west4",      # Netherlands - good T4 availability
    "asia-southeast1",   # Singapore
    "europe-west1",      # Belgium
]

def create_custom_job(region):
    """Create custom job with preemptible configuration"""
    
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    job_name = f"iasoql-14b-quantization-{timestamp}"
    
    # Initialize client
    client = aiplatform_v1.JobServiceClient(
        client_options={"api_endpoint": f"{region}-aiplatform.googleapis.com"}
    )
    
    # Define the custom job
    custom_job = {
        "display_name": job_name,
        "job_spec": {
            "worker_pool_specs": [
                {
                    "machine_spec": {
                        "machine_type": "n1-highmem-8",  # Use n1 with T4
                        "accelerator_type": "NVIDIA_TESLA_T4",
                        "accelerator_count": 1,
                    },
                    "replica_count": 1,
                    "container_spec": {
                        "image_uri": f"gcr.io/{PROJECT_ID}/iasoql-14b-quantization:latest",
                        "command": ["python", "quantize_base_model_cloud.py"],
                        "env": [
                            {
                                "name": "OUTPUT_PATH",
                                "value": f"gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized"
                            }
                        ],
                    },
                }
            ],
            "scheduling": {
                "timeout": duration_pb2.Duration(seconds=7200),  # 2 hours
                "restart_job_on_worker_restart": True,
                # Use standard preemptible (spot) instances
                "disable_retries": False,
            },
            "use_spot": True,  # Use preemptible instances
            "service_account": SERVICE_ACCOUNT,
            "enable_web_access": True,
        }
    }
    
    # Submit the job
    parent = f"projects/{PROJECT_ID}/locations/{region}"
    
    try:
        operation = client.create_custom_job(
            parent=parent,
            custom_job=custom_job
        )
        
        print(f"✅ Job submitted in {region}!")
        print(f"Job name: {job_name}")
        print(f"Operation: {operation.name}")
        return True
        
    except Exception as e:
        print(f"❌ Failed in {region}: {str(e)}")
        return False

def main():
    print("=== Submitting Quantization Job ===")
    print("Configuration:")
    print("- Model: XiYanSQL-QwenCoder-14B-2504")
    print("- Quantization: 4-bit with BitsAndBytes")
    print("- GPU: Preemptible T4 with FLEX_START")
    print(f"- Output: gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized")
    print()
    
    # Try each region
    for region in REGIONS:
        print(f"\nTrying {region}...")
        if create_custom_job(region):
            print(f"\n✅ SUCCESS! Job submitted in {region}")
            print("\n=== Next Steps ===")
            print("1. Monitor at: https://console.cloud.google.com/vertex-ai/training/custom-jobs")
            print("2. Quantization takes ~10-15 minutes")
            print("3. After completion, run: python3 submit_training_14b_prequantized.py")
            break
    else:
        print("\n❌ Failed to submit in all regions")

if __name__ == "__main__":
    main()