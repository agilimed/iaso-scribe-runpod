#!/usr/bin/env python3
"""
Deploy IasoQL models using vLLM with LoRAResolver
This approach uses vLLM's new LoRAResolver plugin system for dynamic LoRA loading
"""

import os
import json
import shutil
from pathlib import Path
from datetime import datetime
from google.cloud import storage, aiplatform

# Configuration
PROJECT_ID = "nexuscare-463413"
REGION = "us-central1"
BUCKET_NAME = "nexuscare-ai-training"

def create_vllm_dockerfile():
    """Create Dockerfile with LoRAResolver support"""
    
    dockerfile_content = """# Use vLLM base image with CUDA support
FROM vllm/vllm-openai:latest

# Environment setup for LoRAResolver
ENV VLLM_ALLOW_RUNTIME_LORA_UPDATING=True
ENV VLLM_PLUGINS=lora_filesystem_resolver
ENV VLLM_LORA_RESOLVER_CACHE_DIR=/models/lora_adapters

# Force V0 engine if needed (fallback)
ENV VLLM_ENGINE_VERSION=0
ENV VLLM_USE_V1=0

# Install additional dependencies
RUN pip install --no-cache-dir \\
    google-cloud-storage \\
    boto3 \\
    s3fs

# Create directories
RUN mkdir -p /models/lora_adapters/iasoql-7b-healthcare
RUN mkdir -p /models/lora_adapters/iasoql-agilimed-healthcare-14b

# Copy LoRA adapter management script
COPY lora_manager.py /app/lora_manager.py

# Copy startup script
COPY start_vllm.sh /app/start_vllm.sh
RUN chmod +x /app/start_vllm.sh

# Default model will be the base model
ENV MODEL_NAME="XGenerationLab/XiYanSQL-QwenCoder-14B-2504"

# Expose port
EXPOSE 8000

# Start vLLM with LoRA support (without pre-specifying adapters)
ENTRYPOINT ["/app/start_vllm.sh"]
"""
    
    with open("Dockerfile.vllm-resolver", "w") as f:
        f.write(dockerfile_content)
    
    return "Dockerfile.vllm-resolver"

def create_startup_script():
    """Create startup script for vLLM with LoRAResolver"""
    
    script_content = """#!/bin/bash
set -e

echo "Starting vLLM with LoRAResolver support..."

# Download LoRA adapters from GCS if configured
if [ ! -z "$GCS_LORA_PATH" ]; then
    echo "Downloading LoRA adapters from GCS..."
    python /app/lora_manager.py download
fi

# Start vLLM without specifying adapters (they'll be loaded dynamically)
python -m vllm.entrypoints.openai.api_server \\
    --model $MODEL_NAME \\
    --enable-lora \\
    --max-lora-rank 64 \\
    --max-cpu-loras 4 \\
    --gpu-memory-utilization 0.9 \\
    --max-model-len 4096 \\
    --host 0.0.0.0 \\
    --port 8000 \\
    --served-model-name iasoql-healthcare \\
    --trust-remote-code
"""
    
    with open("start_vllm.sh", "w") as f:
        f.write(script_content)
    
    os.chmod("start_vllm.sh", 0o755)
    
    return "start_vllm.sh"

def create_lora_manager():
    """Create LoRA adapter management script"""
    
    manager_content = '''#!/usr/bin/env python3
"""
LoRA Adapter Manager for vLLM with LoRAResolver
Handles downloading and organizing LoRA adapters for dynamic loading
"""

import os
import json
import shutil
from pathlib import Path
from google.cloud import storage

class LoRAAdapterManager:
    def __init__(self):
        self.cache_dir = os.getenv("VLLM_LORA_RESOLVER_CACHE_DIR", "/models/lora_adapters")
        self.gcs_bucket = os.getenv("GCS_BUCKET", "nexuscare-ai-training")
        self.gcs_prefix = os.getenv("GCS_LORA_PATH", "models/lora-adapters")
        
    def download_from_gcs(self):
        """Download all LoRA adapters from GCS"""
        client = storage.Client()
        bucket = client.bucket(self.gcs_bucket)
        
        # List all LoRA adapters in GCS
        blobs = bucket.list_blobs(prefix=self.gcs_prefix)
        
        for blob in blobs:
            if blob.name.endswith("/adapter_config.json"):
                # Extract adapter name from path
                adapter_name = blob.name.split("/")[-2]
                local_dir = Path(self.cache_dir) / adapter_name
                
                print(f"Downloading LoRA adapter: {adapter_name}")
                
                # Create local directory
                local_dir.mkdir(parents=True, exist_ok=True)
                
                # Download all files for this adapter
                adapter_prefix = "/".join(blob.name.split("/")[:-1])
                adapter_blobs = bucket.list_blobs(prefix=adapter_prefix)
                
                for adapter_blob in adapter_blobs:
                    filename = adapter_blob.name.split("/")[-1]
                    if filename:  # Skip directory entries
                        local_path = local_dir / filename
                        adapter_blob.download_to_filename(str(local_path))
                        print(f"  Downloaded: {filename}")
                
                # Create metadata file for tracking
                metadata = {
                    "name": adapter_name,
                    "source": f"gs://{self.gcs_bucket}/{adapter_prefix}",
                    "downloaded_at": str(Path.ctime(local_dir))
                }
                
                with open(local_dir / "metadata.json", "w") as f:
                    json.dump(metadata, f, indent=2)
        
        print("All LoRA adapters downloaded successfully!")
        
    def list_available_adapters(self):
        """List all available LoRA adapters in cache"""
        cache_path = Path(self.cache_dir)
        adapters = []
        
        if cache_path.exists():
            for adapter_dir in cache_path.iterdir():
                if adapter_dir.is_dir() and (adapter_dir / "adapter_config.json").exists():
                    adapters.append({
                        "name": adapter_dir.name,
                        "path": str(adapter_dir),
                        "has_metadata": (adapter_dir / "metadata.json").exists()
                    })
        
        return adapters
    
    def prepare_adapter_structure(self):
        """Ensure proper directory structure for LoRAResolver"""
        # Create cache directory if it doesn't exist
        Path(self.cache_dir).mkdir(parents=True, exist_ok=True)
        
        # Create symlinks for common adapter names
        common_names = {
            "iasoql-7b": "iasoql-7b-healthcare",
            "iasoql-14b": "iasoql-agilimed-healthcare-14b",
            "healthcare-sql": "iasoql-7b-healthcare",
            "healthcare-sql-14b": "iasoql-agilimed-healthcare-14b",
            "iasoql-agilimed-14b": "iasoql-agilimed-healthcare-14b"
        }
        
        for alias, target in common_names.items():
            alias_path = Path(self.cache_dir) / alias
            target_path = Path(self.cache_dir) / target
            
            if target_path.exists() and not alias_path.exists():
                alias_path.symlink_to(target_path)
                print(f"Created alias: {alias} -> {target}")

def main():
    import sys
    
    manager = LoRAAdapterManager()
    
    if len(sys.argv) > 1 and sys.argv[1] == "download":
        manager.download_from_gcs()
        manager.prepare_adapter_structure()
    elif len(sys.argv) > 1 and sys.argv[1] == "list":
        adapters = manager.list_available_adapters()
        print("Available LoRA adapters:")
        for adapter in adapters:
            print(f"  - {adapter['name']} ({adapter['path']})")
    else:
        print("Usage: lora_manager.py [download|list]")

if __name__ == "__main__":
    main()
'''
    
    with open("lora_manager.py", "w") as f:
        f.write(manager_content)
    
    return "lora_manager.py"

def create_test_client():
    """Create a test client for the vLLM LoRAResolver endpoint"""
    
    client_content = '''#!/usr/bin/env python3
"""
Test client for vLLM with LoRAResolver
Demonstrates dynamic LoRA loading and inference
"""

import requests
import json
import time

class vLLMLoRAClient:
    def __init__(self, base_url="http://localhost:8000"):
        self.base_url = base_url
        
    def load_lora_adapter(self, adapter_name: str, adapter_path: str = None):
        """Dynamically load a LoRA adapter"""
        
        # If no path provided, assume it's in the resolver cache
        if adapter_path is None:
            adapter_path = f"/models/lora_adapters/{adapter_name}"
        
        url = f"{self.base_url}/v1/load_lora_adapter"
        payload = {
            "lora_name": adapter_name,
            "lora_path": adapter_path
        }
        
        response = requests.post(url, json=payload)
        if response.status_code == 200:
            print(f"Successfully loaded LoRA adapter: {adapter_name}")
            return True
        else:
            print(f"Failed to load LoRA adapter: {response.text}")
            return False
    
    def generate_sql(self, question: str, adapter_name: str = None):
        """Generate SQL using the specified LoRA adapter"""
        
        url = f"{self.base_url}/v1/completions"
        
        prompt = f"""You are IasoQL, a specialized AI for generating ClickHouse SQL queries for healthcare FHIR data.

Question: {question}
SQL Query:"""
        
        payload = {
            "model": "iasoql-healthcare",
            "prompt": prompt,
            "max_tokens": 512,
            "temperature": 0.1,
            "stop": ["\\n\\n", ";"]
        }
        
        # If adapter specified, include it in the request
        if adapter_name:
            payload["lora_request"] = {
                "lora_name": adapter_name,
                "lora_int_id": abs(hash(adapter_name))
            }
        
        response = requests.post(url, json=payload)
        
        if response.status_code == 200:
            result = response.json()
            return result["choices"][0]["text"].strip()
        else:
            return f"Error: {response.text}"
    
    def test_adapters(self):
        """Test different LoRA adapters"""
        
        test_queries = [
            "Count all patients in the system",
            "Show patients diagnosed with diabetes in the last 6 months",
            "Calculate average age of patients with hypertension"
        ]
        
        adapters = ["iasoql-7b-healthcare", "iasoql-agilimed-healthcare-14b"]
        
        for adapter in adapters:
            print(f"\\n=== Testing {adapter} ===")
            
            # Load adapter (will use filesystem resolver)
            # No need to explicitly load if using resolver
            
            for query in test_queries:
                print(f"\\nQuery: {query}")
                start_time = time.time()
                
                sql = self.generate_sql(query, adapter)
                elapsed = time.time() - start_time
                
                print(f"SQL: {sql}")
                print(f"Time: {elapsed:.2f}s")

def main():
    client = vLLMLoRAClient()
    
    # Test the adapters
    client.test_adapters()

if __name__ == "__main__":
    main()
'''
    
    with open("test_vllm_client.py", "w") as f:
        f.write(client_content)
    
    return "test_vllm_client.py"

def create_deployment_yaml():
    """Create Kubernetes deployment YAML for vLLM with LoRAResolver"""
    
    deployment_yaml = """apiVersion: apps/v1
kind: Deployment
metadata:
  name: iasoql-vllm-resolver
  namespace: nexuscare
spec:
  replicas: 1
  selector:
    matchLabels:
      app: iasoql-vllm-resolver
  template:
    metadata:
      labels:
        app: iasoql-vllm-resolver
    spec:
      nodeSelector:
        cloud.google.com/gke-accelerator: nvidia-tesla-t4
      containers:
      - name: vllm-server
        image: gcr.io/nexuscare-463413/iasoql-vllm-resolver:latest
        ports:
        - containerPort: 8000
        env:
        - name: MODEL_NAME
          value: "XGenerationLab/XiYanSQL-QwenCoder-14B-2504"
        - name: GCS_BUCKET
          value: "nexuscare-ai-training"
        - name: GCS_LORA_PATH
          value: "models/lora-adapters"
        - name: VLLM_ALLOW_RUNTIME_LORA_UPDATING
          value: "True"
        - name: VLLM_PLUGINS
          value: "lora_filesystem_resolver"
        - name: VLLM_LORA_RESOLVER_CACHE_DIR
          value: "/models/lora_adapters"
        - name: HF_TOKEN
          valueFrom:
            secretKeyRef:
              name: huggingface-credentials
              key: token
        resources:
          requests:
            memory: "16Gi"
            cpu: "4"
            nvidia.com/gpu: "1"
          limits:
            memory: "32Gi"
            cpu: "8"
            nvidia.com/gpu: "1"
        volumeMounts:
        - name: lora-cache
          mountPath: /models/lora_adapters
      volumes:
      - name: lora-cache
        emptyDir:
          sizeLimit: 10Gi
---
apiVersion: v1
kind: Service
metadata:
  name: iasoql-vllm-resolver
  namespace: nexuscare
spec:
  selector:
    app: iasoql-vllm-resolver
  ports:
  - port: 80
    targetPort: 8000
  type: LoadBalancer
"""
    
    with open("deploy-vllm-resolver.yaml", "w") as f:
        f.write(deployment_yaml)
    
    return "deploy-vllm-resolver.yaml"

def build_and_push_image():
    """Build and push Docker image with LoRAResolver support"""
    
    # Create all necessary files
    create_vllm_dockerfile()
    create_startup_script()
    create_lora_manager()
    create_test_client()
    create_deployment_yaml()
    
    # Create cloudbuild.yaml
    cloudbuild_config = {
        "steps": [
            {
                "name": "gcr.io/cloud-builders/docker",
                "args": [
                    "build",
                    "-t", f"gcr.io/{PROJECT_ID}/iasoql-vllm-resolver:latest",
                    "-f", "Dockerfile.vllm-resolver",
                    "."
                ]
            },
            {
                "name": "gcr.io/cloud-builders/docker", 
                "args": [
                    "push",
                    f"gcr.io/{PROJECT_ID}/iasoql-vllm-resolver:latest"
                ]
            }
        ],
        "timeout": "1800s"
    }
    
    with open("cloudbuild-vllm-resolver.yaml", "w") as f:
        import yaml
        yaml.dump(cloudbuild_config, f)
    
    print("Created all deployment files for vLLM with LoRAResolver")
    print("\nTo build and deploy:")
    print(f"1. gcloud builds submit --config=cloudbuild-vllm-resolver.yaml --project={PROJECT_ID}")
    print("2. kubectl apply -f deploy-vllm-resolver.yaml")

def main():
    """Main deployment function"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Deploy vLLM with LoRAResolver")
    parser.add_argument("--build", action="store_true", help="Build and push image")
    parser.add_argument("--deploy", action="store_true", help="Deploy to Kubernetes")
    
    args = parser.parse_args()
    
    if args.build:
        build_and_push_image()
        print("\nImage build configuration created!")
    
    if args.deploy:
        os.system("kubectl apply -f deploy-vllm-resolver.yaml")
        print("\nDeployment applied to Kubernetes!")
    
    if not args.build and not args.deploy:
        # Just create the files
        build_and_push_image()

if __name__ == "__main__":
    main()