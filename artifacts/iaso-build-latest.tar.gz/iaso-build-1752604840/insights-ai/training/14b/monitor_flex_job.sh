#!/bin/bash

JOB_ID="4930045487081324544"
PROJECT_ID="nexuscare-463413"
REGION="asia-southeast1"

echo "=== Monitoring FLEX_START Quantization Job ==="
echo "Job ID: $JOB_ID"
echo "Region: $REGION"
echo "Strategy: FLEX_START (waits for preemptible A100 availability)"
echo ""

while true; do
  # Get job status
  STATUS=$(gcloud ai custom-jobs describe projects/$PROJECT_ID/locations/$REGION/customJobs/$JOB_ID \
    --format="value(state)" 2>/dev/null)
  
  # Get timestamp
  TIMESTAMP=$(date "+%H:%M:%S")
  
  case $STATUS in
    "JOB_STATE_PENDING")
      echo -ne "\r[$TIMESTAMP] Status: PENDING - Waiting for preemptible A100..."
      ;;
    "JOB_STATE_RUNNING")
      echo -ne "\r[$TIMESTAMP] Status: RUNNING - Quantization in progress!        "
      echo ""
      echo "✅ Job started! Monitoring output..."
      # Check if output exists
      gsutil ls gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized/ 2>/dev/null
      ;;
    "JOB_STATE_SUCCEEDED")
      echo ""
      echo "✅ Quantization completed successfully!"
      echo "Output: gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized/"
      echo ""
      echo "Next step: python3 submit_training_14b_prequantized.py"
      break
      ;;
    "JOB_STATE_FAILED"|"JOB_STATE_CANCELLED")
      echo ""
      echo "❌ Job $STATUS"
      gcloud ai custom-jobs describe projects/$PROJECT_ID/locations/$REGION/customJobs/$JOB_ID \
        --format="get(error.message)" 2>/dev/null
      break
      ;;
  esac
  
  sleep 30
done

echo ""
echo "Monitor in console: https://console.cloud.google.com/vertex-ai/locations/$REGION/training/custom-jobs?project=$PROJECT_ID"