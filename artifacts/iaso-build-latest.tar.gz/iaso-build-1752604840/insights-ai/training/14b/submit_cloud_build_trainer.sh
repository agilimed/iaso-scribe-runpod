#!/bin/bash

PROJECT_ID="nexuscare-463413"

echo "=== Submitting Cloud Build for 14B Trainer Container ==="
echo "Project: $PROJECT_ID"
echo "Image: gcr.io/$PROJECT_ID/iasoql-14b-trainer:latest"

# Submit cloud build
gcloud builds submit \
  --config=cloudbuild-trainer.yaml \
  --project=$PROJECT_ID \
  .

if [ $? -eq 0 ]; then
  echo -e "\n✅ Cloud Build completed successfully!"
  echo "Image available at: gcr.io/$PROJECT_ID/iasoql-14b-trainer:latest"
  echo ""
  echo "Next steps:"
  echo "1. Wait for quantization to complete"
  echo "2. Run: python3 submit_training_14b_flex_start.py"
else
  echo -e "\n❌ Cloud Build failed!"
fi