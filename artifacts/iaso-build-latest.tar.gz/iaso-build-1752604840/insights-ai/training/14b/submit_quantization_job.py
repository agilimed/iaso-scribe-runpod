#!/usr/bin/env python3
"""
Submit quantization job to Vertex AI
This runs the model quantization in the cloud with proper GPU resources
"""

import os
import json
from datetime import datetime
from google.cloud import aiplatform

# Initialize Vertex AI
PROJECT_ID = "nexuscare-463413"
REGION = "asia-southeast1"  # Singapore - good availability
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = "ai-training@nexuscare-463413.iam.gserviceaccount.com"

aiplatform.init(
    project=PROJECT_ID,
    location=REGION,
    staging_bucket=f"gs://{BUCKET_NAME}"
)

def submit_quantization_job():
    """Submit quantization job to Vertex AI"""
    
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    job_name = f"iasoql-14b-quantization-{timestamp}"
    
    # Build container image URI
    image_uri = f"gcr.io/{PROJECT_ID}/iasoql-14b-quantization:latest"
    
    # Training job configuration
    job = aiplatform.CustomContainerTrainingJob(
        display_name=job_name,
        container_uri=image_uri,
        command=["python", "quantize_base_model.py"],
    )
    
    # Environment variables
    env_vars = {
        "OUTPUT_PATH": f"gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized",
    }
    
    # Run the quantization job with preemptible GPU
    job.run(
        replica_count=1,
        machine_type="g2-standard-16",  # T4 GPU with 16 vCPUs, 64GB RAM
        accelerator_type="NVIDIA_TESLA_T4",
        accelerator_count=1,
        environment_variables=env_vars,
        service_account=SERVICE_ACCOUNT,
        sync=False,
        scheduling={
            "timeout": "2h",  # Quantization should be quick
            "restart_job_on_worker_restart": True,
            "disable_retries": False,
            "strategy": "FLEX_START"  # Use preemptible with DWS
        },
        enable_web_access=True,
    )
    
    print(f"Quantization job submitted: {job_name}")
    print(f"Job resource name: {job.resource_name}")
    print(f"Output will be saved to: gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized")
    print(f"Monitor at: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={PROJECT_ID}")
    
    return job

def build_and_push_image():
    """Build and push Docker image for quantization"""
    print("Building Docker image for quantization...")
    
    # Create Dockerfile
    dockerfile_content = """FROM nvidia/cuda:12.1.0-cudnn8-devel-ubuntu22.04

ENV DEBIAN_FRONTEND=noninteractive
ENV PYTHONUNBUFFERED=1
ENV CUDA_VISIBLE_DEVICES=0

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    python3.10 \\
    python3.10-dev \\
    python3-pip \\
    git \\
    wget \\
    build-essential \\
    && rm -rf /var/lib/apt/lists/*

RUN ln -s /usr/bin/python3.10 /usr/bin/python
RUN python -m pip install --upgrade pip

WORKDIR /app

# Copy minimal requirements for quantization
COPY requirements-minimal.txt .
RUN pip install --no-cache-dir -r requirements-minimal.txt

# Copy scripts
COPY quantize_base_model.py .
# Dataset will be copied from parent directory during build

# Modified quantization script for cloud
COPY quantize_base_model_cloud.py .

# Default command
CMD ["python", "quantize_base_model_cloud.py"]
"""
    
    with open("Dockerfile.quantization", "w") as f:
        f.write(dockerfile_content)
    
    # Create cloud version of quantization script
    cloud_script = """#!/usr/bin/env python3
import os
import json
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from google.cloud import storage
from pathlib import Path
import gc

# Simple quantization without dataset dependency
print("Starting model quantization...")

# Configuration
base_model = "XGenerationLab/XiYanSQL-QwenCoder-14B-2504"
output_dir = "/tmp/quantized-model"
Path(output_dir).mkdir(parents=True, exist_ok=True)

# Load tokenizer
print("Loading tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(base_model, trust_remote_code=True)

# Configure quantization
print("Configuring 4-bit quantization...")
quantization_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_use_double_quant=True,
)

# Load and quantize model
print("Loading and quantizing model (this may take 5-10 minutes)...")
model = AutoModelForCausalLM.from_pretrained(
    base_model,
    quantization_config=quantization_config,
    device_map="auto",
    trust_remote_code=True,
    torch_dtype=torch.bfloat16,
)

print("Model loaded and quantized successfully!")
if torch.cuda.is_available():
    print(f"GPU memory used: {torch.cuda.memory_allocated() / 1e9:.2f} GB")

# Save quantized model
print(f"Saving quantized model to {output_dir}")
model.save_pretrained(output_dir, safe_serialization=True, max_shard_size="5GB")
tokenizer.save_pretrained(output_dir)

# Save quantization info
quant_info = {
    "base_model": base_model,
    "quantization_method": "bitsandbytes-4bit",
    "quantization_config": {
        "load_in_4bit": True,
        "bnb_4bit_quant_type": "nf4",
        "bnb_4bit_compute_dtype": "bfloat16",
        "bnb_4bit_use_double_quant": True
    }
}

with open(os.path.join(output_dir, "quantization_info.json"), "w") as f:
    json.dump(quant_info, f, indent=2)

# Cleanup
del model
gc.collect()
torch.cuda.empty_cache()

# Upload to GCS
gcs_path = os.environ.get("OUTPUT_PATH", "models/quantized/iasoql-14b-base-quantized")
print(f"Uploading to GCS: {gcs_path}")

if gcs_path.startswith("gs://"):
    parts = gcs_path.replace("gs://", "").split("/", 1)
    bucket_name = parts[0]
    prefix = parts[1]
else:
    bucket_name = "nexuscare-ai-training"
    prefix = gcs_path

client = storage.Client()
bucket = client.bucket(bucket_name)

for root, dirs, files in os.walk(output_dir):
    for file in files:
        local_file = os.path.join(root, file)
        blob_path = os.path.join(prefix, os.path.relpath(local_file, output_dir))
        blob = bucket.blob(blob_path)
        blob.upload_from_filename(local_file)
        print(f"Uploaded: {blob_path}")

print(f"Quantization complete! Model saved to: gs://{bucket_name}/{prefix}")
"""
    
    with open("quantize_base_model_cloud.py", "w") as f:
        f.write(cloud_script)
    
    # Create cloudbuild.yaml
    cloudbuild_config = {
        "steps": [
            {
                "name": "gcr.io/cloud-builders/docker",
                "args": [
                    "build",
                    "-t", f"gcr.io/{PROJECT_ID}/iasoql-14b-quantization:latest",
                    "-f", "Dockerfile.quantization",
                    "."
                ]
            },
            {
                "name": "gcr.io/cloud-builders/docker",
                "args": [
                    "push",
                    f"gcr.io/{PROJECT_ID}/iasoql-14b-quantization:latest"
                ]
            }
        ],
        "timeout": "1800s"
    }
    
    with open("cloudbuild-quantization.yaml", "w") as f:
        import yaml
        yaml.dump(cloudbuild_config, f)
    
    # Submit build
    os.system(f"gcloud builds submit --config=cloudbuild-quantization.yaml --project={PROJECT_ID}")
    
    print("Docker image built and pushed successfully!")

def check_preemptible_quota():
    """Check preemptible GPU quota in target regions"""
    print("\nChecking preemptible GPU quotas...")
    
    regions = ["asia-southeast1", "europe-west4", "europe-west1"]
    
    for region in regions:
        print(f"\nRegion: {region}")
        cmd = f"gcloud compute project-info describe --project={PROJECT_ID} | grep -A5 -i 'preemptible.*gpu' || echo 'No specific preemptible GPU quota found'"
        os.system(cmd)

if __name__ == "__main__":
    import sys
    
    print("=== Starting Model Quantization Process ===")
    print(f"Base Model: XiYanSQL-QwenCoder-14B-2504 (Public model)")
    print(f"Output: gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized")
    print(f"Region: {REGION} (using FLEX_START for preemptible GPU)")
    print()
    
    # Check quotas
    check_preemptible_quota()
    
    print("\nStarting quantization job...")
    
    # Build and push image
    build_and_push_image()
    
    # Submit quantization job
    submit_quantization_job()
    
    print("\n=== Next Steps ===")
    print("1. Monitor the quantization job in Vertex AI console")
    print("2. Once complete (~10-15 minutes), proceed with training")
    print("3. The quantized model will be at: gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized")