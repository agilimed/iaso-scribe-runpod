# vLLM LoRAResolver Deployment Guide

This guide explains how to deploy IasoQL models using vLLM's new LoRAResolver plugin system, which enables dynamic LoRA adapter loading without server restarts.

## 🎯 Why LoRAResolver?

The LoRAResolver approach solves several deployment challenges:

1. **Dynamic Loading**: Load LoRA adapters on-demand without restarting vLLM
2. **Simplified Deployment**: No need to specify adapters at startup
3. **Automatic Discovery**: vLLM automatically finds adapters in the cache directory
4. **Better Compatibility**: Works around vLLM's traditional LoRA loading issues

## 🔧 How It Works

### Environment Variables

```bash
# Enable runtime LoRA updates
VLLM_ALLOW_RUNTIME_LORA_UPDATING=True

# Enable the filesystem resolver plugin
VLLM_PLUGINS=lora_filesystem_resolver

# Set the cache directory for LoRA adapters
VLLM_LORA_RESOLVER_CACHE_DIR=/models/lora_adapters

# Force V0 engine if needed (fallback)
VLLM_ENGINE_VERSION=0
VLLM_USE_V1=0
```

### Directory Structure

```
/models/lora_adapters/
├── iasoql-7b-healthcare/
│   ├── adapter_config.json
│   ├── adapter_model.safetensors
│   └── metadata.json
├── iasoql-agilimed-healthcare-14b/
│   ├── adapter_config.json
│   ├── adapter_model.safetensors
│   └── metadata.json
└── [symlinks for aliases]
```

### Adapter Resolution Flow

1. Client requests inference with adapter name (e.g., "iasoql-7b-healthcare")
2. vLLM checks if adapter is already loaded
3. If not, LoRAResolver looks in cache directory
4. If found, adapter is loaded automatically
5. Request is processed with the adapter

## 🚀 Deployment Steps

### 1. Prepare Files

```bash
cd /Users/vivkris/dev_projects/nexuscare-platform/ai/training/14b

# Run the deployment script to create all files
python deploy_vllm_lora_resolver.py
```

This creates:
- `Dockerfile.vllm-resolver`: Container with LoRAResolver setup
- `start_vllm.sh`: Startup script for vLLM
- `lora_manager.py`: Adapter management utility
- `test_vllm_client.py`: Test client
- `deploy-vllm-resolver.yaml`: Kubernetes deployment

### 2. Build and Push Image

```bash
# Submit build to Google Cloud Build
gcloud builds submit \
  --config=cloudbuild-vllm-resolver.yaml \
  --project=nexuscare-463413
```

### 3. Upload LoRA Adapters to GCS

```bash
# Upload your trained LoRA adapters
gsutil -m cp -r /path/to/iasoql-7b-healthcare/* \
  gs://nexuscare-ai-training/models/lora-adapters/iasoql-7b-healthcare/

gsutil -m cp -r /path/to/iasoql-agilimed-healthcare-14b/* \
  gs://nexuscare-ai-training/models/lora-adapters/iasoql-agilimed-healthcare-14b/
```

### 4. Deploy to Kubernetes

```bash
# Apply the deployment
kubectl apply -f deploy-vllm-resolver.yaml

# Check status
kubectl get pods -n nexuscare -l app=iasoql-vllm-resolver
kubectl logs -n nexuscare -l app=iasoql-vllm-resolver
```

## 📡 API Usage

### Standard Inference (Adapter Auto-Resolution)

```python
import requests

# The adapter will be automatically resolved from the cache
response = requests.post("http://your-endpoint/v1/completions", json={
    "model": "iasoql-healthcare",
    "prompt": "Show all diabetic patients from the last 6 months\nSQL Query:",
    "max_tokens": 512,
    "temperature": 0.1,
    "lora_request": {
        "lora_name": "iasoql-7b-healthcare",
        "lora_int_id": 1
    }
})
```

### Dynamic Adapter Loading (Optional)

```python
# Explicitly load an adapter (usually not needed with resolver)
response = requests.post("http://your-endpoint/v1/load_lora_adapter", json={
    "lora_name": "iasoql-agilimed-healthcare-14b",
    "lora_path": "/models/lora_adapters/iasoql-agilimed-healthcare-14b"
})
```

## 🧪 Testing

### Local Testing

```bash
# Start vLLM locally with LoRAResolver
export VLLM_ALLOW_RUNTIME_LORA_UPDATING=True
export VLLM_PLUGINS=lora_filesystem_resolver
export VLLM_LORA_RESOLVER_CACHE_DIR=./lora_adapters

python -m vllm.entrypoints.openai.api_server \
  --model Qwen/Qwen2.5-14B-Instruct \
  --enable-lora \
  --host 0.0.0.0 \
  --port 8000

# In another terminal, test the client
python test_vllm_client.py
```

### Production Testing

```bash
# Get the service endpoint
kubectl get svc -n nexuscare iasoql-vllm-resolver

# Port forward for testing
kubectl port-forward -n nexuscare svc/iasoql-vllm-resolver 8000:80

# Run test client
python test_vllm_client.py
```

## 🔍 Troubleshooting

### Adapter Not Found

If vLLM can't find an adapter:

1. Check the cache directory exists and has correct permissions
2. Verify adapter files are in the expected location
3. Check logs for resolver messages:
   ```bash
   kubectl logs -n nexuscare -l app=iasoql-vllm-resolver | grep -i resolver
   ```

### Memory Issues

If running out of memory:

1. Reduce `--gpu-memory-utilization` (default 0.9)
2. Lower `--max-model-len` (default 4096)
3. Decrease `--max-cpu-loras` (number of CPU-cached adapters)

### V1 Engine Issues

If you encounter V1 engine compatibility issues:

```bash
# Force V0 engine
export VLLM_ENGINE_VERSION=0
export VLLM_USE_V1=0
```

## 📊 Performance Tuning

### Optimal Settings for T4 GPU

```python
# In start_vllm.sh
--gpu-memory-utilization 0.85  # Leave headroom
--max-lora-rank 64             # Support larger adapters
--max-cpu-loras 4              # Cache 4 adapters in CPU
--max-num-seqs 16              # Concurrent sequences
--enforce-eager                # Disable CUDA graphs if issues
```

### Caching Strategy

The filesystem resolver caches loaded adapters. To optimize:

1. Pre-load frequently used adapters at startup
2. Use consistent adapter names
3. Create symlinks for common aliases

## 🚨 Important Notes

1. **Security**: `VLLM_ALLOW_RUNTIME_LORA_UPDATING=True` allows dynamic model loading. Use with caution in production.

2. **Adapter Compatibility**: Ensure LoRA adapters are compatible with the base model version.

3. **Cache Management**: The cache directory should have sufficient space for all adapters (~1-3GB each).

4. **Monitoring**: Monitor adapter loading times and cache hits for optimization.

## 📚 References

- [vLLM LoRA Documentation](https://docs.vllm.ai/en/stable/features/lora.html)
- [LoRAResolver PR #15733](https://github.com/vllm-project/vllm/pull/15733)
- [Filesystem Resolver PR #16855](https://github.com/vllm-project/vllm/pull/16855)

---

This LoRAResolver approach provides a more flexible and robust deployment strategy compared to traditional vLLM LoRA serving, especially when dealing with multiple adapter versions or dynamic model selection requirements.