#!/usr/bin/env python3
"""
Debug script to find sql_queries in training_data
"""

import json

# Load the dataset
dataset_path = '../fhir-clickhouse-training-dataset-v8-FINAL.json'

with open(dataset_path, 'r') as f:
    data = json.load(f)

# Check training_data structure
training_data = data.get('training_data', {})
print("training_data keys:", list(training_data.keys()) if isinstance(training_data, dict) else type(training_data))

# Look for sql_queries in training_data
if isinstance(training_data, dict):
    sql_queries = training_data.get('sql_queries', [])
    print(f"\nNumber of sql_queries in training_data: {len(sql_queries)}")
    
    if sql_queries and len(sql_queries) > 0:
        print("\nFirst sql_query structure:")
        first_query = sql_queries[0]
        for k, v in first_query.items():
            print(f"  {k}: {v if len(str(v)) < 100 else str(v)[:100] + '...'}")
        
        print("\nSecond sql_query:")
        if len(sql_queries) > 1:
            second_query = sql_queries[1]
            for k, v in second_query.items():
                print(f"  {k}: {v if len(str(v)) < 100 else str(v)[:100] + '...'}")

# Also check function_examples
function_examples = training_data.get('function_examples', []) if isinstance(training_data, dict) else []
print(f"\nNumber of function_examples: {len(function_examples)}")