#!/bin/bash

PROJECT_ID="nexuscare-463413"
IMAGE_NAME="iasoql-14b-trainer"
TAG="latest"

echo "=== Building 14B Training Container ==="
echo "Project: $PROJECT_ID"
echo "Image: $IMAGE_NAME:$TAG"

# Build the container
echo -e "\n1. Building Docker image..."
docker build -f Dockerfile.trainer -t gcr.io/$PROJECT_ID/$IMAGE_NAME:$TAG .

if [ $? -ne 0 ]; then
    echo "❌ Docker build failed"
    exit 1
fi

# Push to GCR
echo -e "\n2. Pushing to Google Container Registry..."
docker push gcr.io/$PROJECT_ID/$IMAGE_NAME:$TAG

if [ $? -ne 0 ]; then
    echo "❌ Docker push failed"
    exit 1
fi

echo -e "\n✅ Training container built and pushed successfully!"
echo "Image: gcr.io/$PROJECT_ID/$IMAGE_NAME:$TAG"
echo ""
echo "Next steps:"
echo "1. Wait for quantization to complete"
echo "2. Run: python3 submit_training_14b_prequantized.py"