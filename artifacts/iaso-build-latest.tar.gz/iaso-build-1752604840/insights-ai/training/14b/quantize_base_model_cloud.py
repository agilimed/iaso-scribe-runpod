#!/usr/bin/env python3
import os
import json
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from google.cloud import storage
from pathlib import Path
import gc

# Simple quantization without dataset dependency
print("Starting model quantization...")

# Configuration
base_model = "XGenerationLab/XiYanSQL-QwenCoder-14B-2504"
output_dir = "/tmp/quantized-model"
Path(output_dir).mkdir(parents=True, exist_ok=True)

# Load tokenizer
print("Loading tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(base_model, trust_remote_code=True)

# Configure quantization
print("Configuring 4-bit quantization...")
quantization_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_use_double_quant=True,
)

# Load and quantize model
print("Loading and quantizing model (this may take 5-10 minutes)...")
model = AutoModelForCausalLM.from_pretrained(
    base_model,
    quantization_config=quantization_config,
    device_map="auto",
    trust_remote_code=True,
    torch_dtype=torch.bfloat16,
)

print("Model loaded and quantized successfully!")
if torch.cuda.is_available():
    print(f"GPU memory used: {torch.cuda.memory_allocated() / 1e9:.2f} GB")

# Save quantized model
print(f"Saving quantized model to {output_dir}")
model.save_pretrained(output_dir, safe_serialization=True, max_shard_size="5GB")
tokenizer.save_pretrained(output_dir)

# Save quantization info
quant_info = {
    "base_model": base_model,
    "quantization_method": "bitsandbytes-4bit",
    "quantization_config": {
        "load_in_4bit": True,
        "bnb_4bit_quant_type": "nf4",
        "bnb_4bit_compute_dtype": "bfloat16",
        "bnb_4bit_use_double_quant": True
    }
}

with open(os.path.join(output_dir, "quantization_info.json"), "w") as f:
    json.dump(quant_info, f, indent=2)

# Cleanup
del model
gc.collect()
torch.cuda.empty_cache()

# Upload to GCS
gcs_path = os.environ.get("OUTPUT_PATH", "models/quantized/iasoql-14b-base-quantized")
print(f"Uploading to GCS: {gcs_path}")

if gcs_path.startswith("gs://"):
    parts = gcs_path.replace("gs://", "").split("/", 1)
    bucket_name = parts[0]
    prefix = parts[1]
else:
    bucket_name = "nexuscare-ai-training"
    prefix = gcs_path

client = storage.Client()
bucket = client.bucket(bucket_name)

for root, dirs, files in os.walk(output_dir):
    for file in files:
        local_file = os.path.join(root, file)
        blob_path = os.path.join(prefix, os.path.relpath(local_file, output_dir))
        blob = bucket.blob(blob_path)
        blob.upload_from_filename(local_file)
        print(f"Uploaded: {blob_path}")

print(f"Quantization complete! Model saved to: gs://{bucket_name}/{prefix}")
