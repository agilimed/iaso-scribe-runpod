# Training Process Explained: QLoRA + DoRA

## How QLoRA Training Works

The training process uses **quantization during training**, not as a separate pre-step. Here's how it works:

### 1. **Model Loading with Quantization** (Automatic)
When the training script runs, it:
- Downloads the full 14B model (XiYanSQL-QwenCoder-14B-2504)
- **Simultaneously quantizes it** to 4-bit using BitsAndBytes
- This happens in-memory during model loading

```python
# This is what happens internally:
model = AutoModelForCausalLM.from_pretrained(
    "XGenerationLab/XiYanSQL-QwenCoder-14B-2504",
    quantization_config=BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",  # 4-bit Normal Float
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,  # Double quantization
    ),
    device_map="auto",
)
```

### 2. **LoRA + DoRA Application**
After quantization, the script:
- Freezes the quantized base model weights
- Adds trainable LoRA adapters (only ~0.5% of parameters)
- Enables DoRA for better accuracy through magnitude scaling

### 3. **Training Process**
- Only the LoRA adapters are trained
- Base model remains frozen and quantized
- Training happens on your 52 FHIR queries
- Saves only the small LoRA weights (~3GB)

## What You Get

### During Training:
- **Base Model**: 14B parameters quantized to 4-bit (~7GB RAM)
- **Trainable Parameters**: LoRA adapters only (~100M parameters)
- **Memory Usage**: ~16GB total (fits on T4 GPU)

### After Training:
- **LoRA Adapter Files**: ~3GB
  - `adapter_model.safetensors`
  - `adapter_config.json`
- **No need to save the quantized base model** (it's recreated on-demand)

### For Inference:
1. Load the base model with same quantization settings
2. Apply your trained LoRA adapters
3. Run inference with ~7GB memory usage

## Key Points

1. **No separate quantization step needed** - it happens automatically
2. **Base model is never modified** - only LoRA weights are trained
3. **Quantization is deterministic** - same settings = same quantized model
4. **DoRA enhancement** works on top of LoRA for better accuracy

## Next Steps

### Option 1: Start Training
```bash
# Just need HuggingFace token for model access
export HF_TOKEN="your-huggingface-token"

# Submit training
python submit_training_14b.py
```

### Option 2: Local Testing (if you have GPU)
```bash
# Install dependencies
pip install -r requirements.txt

# Run training locally
python train_iasoql_14b.py
```

The training script handles everything automatically - quantization, LoRA setup, and training!