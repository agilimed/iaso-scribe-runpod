# iasoql-agilimed-healthcare-14b Training Summary

## Approach Confirmation

### Base Model
- **Model**: XiYanSQL-QwenCoder-14B-2504
- **Source**: https://huggingface.co/XGenerationLab/XiYanSQL-QwenCoder-14B-2504
- **Why**: Already optimized for SQL generation tasks

### Quantization Strategy
- **QLoRA**: 4-bit quantization (NF4)
  - Reduces model from ~28GB to ~7GB
  - Enables T4 GPU deployment
- **DoRA Enhancement**: 
  - Decomposed Low-Rank Adaptation
  - Improves accuracy with magnitude scaling
  - Better parameter efficiency

### Training Configuration
- **Dataset**: 52 FHIR ClickHouse queries
- **LoRA Rank**: 32 (higher for 14B model)
- **Target Modules**: All attention + MLP layers
- **Batch Size**: 1 with gradient accumulation (effective: 16)
- **Epochs**: 3
- **Learning Rate**: 1e-4 with cosine schedule

### Infrastructure
- **GPU**: Preemptible NVIDIA T4 (16GB)
- **Regions**: 
  - Primary: europe-west4 (Netherlands)
  - Alternatives: asia-southeast1, europe-west1
- **Cost**: ~$0.35/hour (preemptible)
- **Training Time**: ~12-16 hours

### Expected Outcomes
- **Accuracy**: 98%+ on healthcare SQL tasks
- **Model Size**: ~3GB (LoRA adapters only)
- **Memory Usage**: ~7GB inference
- **Inference Speed**: ~80 tokens/sec on T4

## Quick Start Commands

```bash
# 1. Submit training job
cd /Users/vivkris/dev_projects/nexuscare-platform/ai/training/14b
export WANDB_API_KEY="your-key"
export HF_TOKEN="your-token"
python submit_training_14b.py

# 2. Monitor training
# Check Vertex AI console or W&B dashboard

# 3. Deploy with vLLM LoRAResolver
python deploy_vllm_lora_resolver.py
gcloud builds submit --config=cloudbuild-vllm-resolver.yaml
kubectl apply -f deploy-vllm-resolver.yaml
```