#!/usr/bin/env python3
"""
IasoQL-14B-Healthcare Training Script with QLoRA+DoRA

This script fine-tunes a 14B parameter model using QLoRA+DoRA for improved performance
while maintaining efficient memory usage (~7GB instead of 28GB).
"""

import os
import json
import torch
import logging
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime
import gc

from datasets import Dataset
from transformers import (
    AutoTokenizer, 
    AutoModelForCausalLM,
    BitsAndBytesConfig,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
    EarlyStoppingCallback
)
from peft import (
    LoraConfig, 
    get_peft_model, 
    prepare_model_for_kbit_training,
    TaskType
)
from google.cloud import storage

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class IasoQL14BTrainer:
    def __init__(self, config: Dict):
        self.config = config
        # Using XiYanSQL-QwenCoder-14B-2504 as base model
        self.model_name = config.get('base_model', 'XGenerationLab/XiYanSQL-QwenCoder-14B-2504')
        self.output_dir = config.get('output_dir', '/gcs/nexuscare-ai-training/models/iasoql-agilimed-healthcare-14b')
        self.dataset_path = config.get('dataset_path', '../fhir-clickhouse-training-dataset-v8-FINAL.json')
        
        # Skip wandb initialization - removed per requirements
        
        logger.info(f"Initializing iasoql-agilimed-healthcare-14b trainer with base model: {self.model_name}")
        
    def load_dataset(self) -> Dataset:
        """Load and prepare the FHIR ClickHouse training dataset"""
        logger.info(f"Loading dataset from {self.dataset_path}")
        
        with open(self.dataset_path, 'r') as f:
            data = json.load(f)
        
        # Extract SQL queries
        sql_examples = []
        for example in data['sql_queries']:
            prompt = f"Question: {example['question']}\nAnswer: {example['query']}"
            sql_examples.append({"text": prompt})
        
        # Add function examples
        for example in data.get('function_examples', []):
            prompt = f"Function: {example['name']}\nDescription: {example['description']}\nUsage: {example['usage']}"
            sql_examples.append({"text": prompt})
        
        dataset = Dataset.from_list(sql_examples)
        logger.info(f"Loaded {len(dataset)} training examples")
        
        return dataset
    
    def get_quantization_config(self) -> BitsAndBytesConfig:
        """Configure 4-bit quantization for QLoRA"""
        return BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True,
        )
    
    def get_lora_config(self) -> LoraConfig:
        """Configure LoRA with DoRA enhancement"""
        return LoraConfig(
            r=32,  # Higher rank for 14B model
            lora_alpha=64,
            target_modules=[
                "q_proj", "k_proj", "v_proj", "o_proj",
                "gate_proj", "up_proj", "down_proj"
            ],
            lora_dropout=0.1,
            bias="none",
            task_type=TaskType.CAUSAL_LM,
            # DoRA specific parameters
            use_dora=True,  # Enable DoRA
            dora_magnitude_scale=True,  # Enable magnitude scaling
        )
    
    def prepare_model_and_tokenizer(self):
        """Load and prepare the model with QLoRA+DoRA"""
        logger.info("Loading tokenizer...")
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.model_name,
            trust_remote_code=True,
            padding_side="left"
        )
        
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        logger.info("Loading model with 4-bit quantization...")
        quantization_config = self.get_quantization_config()
        
        self.model = AutoModelForCausalLM.from_pretrained(
            self.model_name,
            quantization_config=quantization_config,
            device_map="auto",
            trust_remote_code=True,
            torch_dtype=torch.bfloat16,
        )
        
        # Prepare model for k-bit training
        self.model = prepare_model_for_kbit_training(self.model)
        
        # Apply LoRA+DoRA
        logger.info("Applying LoRA+DoRA configuration...")
        lora_config = self.get_lora_config()
        self.model = get_peft_model(self.model, lora_config)
        
        # Print trainable parameters
        self.model.print_trainable_parameters()
        
        # Enable gradient checkpointing for memory efficiency
        self.model.enable_input_require_grads()
        self.model.gradient_checkpointing_enable()
        
    def tokenize_function(self, examples):
        """Tokenize the examples"""
        tokenized = self.tokenizer(
            examples["text"],
            truncation=True,
            padding="max_length",
            max_length=2048,  # Longer context for 14B model
        )
        tokenized["labels"] = tokenized["input_ids"].copy()
        return tokenized
    
    def get_training_args(self) -> TrainingArguments:
        """Configure training arguments optimized for 14B model"""
        return TrainingArguments(
            output_dir=self.output_dir,
            num_train_epochs=3,
            per_device_train_batch_size=1,  # Small batch due to model size
            gradient_accumulation_steps=16,  # Effective batch size of 16
            gradient_checkpointing=True,
            optim="paged_adamw_8bit",  # Memory efficient optimizer
            logging_steps=10,
            save_strategy="steps",
            save_steps=50,
            save_total_limit=3,
            evaluation_strategy="steps",
            eval_steps=100,
            warmup_steps=100,
            learning_rate=1e-4,  # Lower LR for larger model
            lr_scheduler_type="cosine",
            bf16=True,
            tf32=True,
            push_to_hub=False,
            report_to=[],  # Wandb removed
            load_best_model_at_end=True,
            metric_for_best_model="loss",
            greater_is_better=False,
            # Memory optimization
            gradient_checkpointing_kwargs={"use_reentrant": False},
            ddp_find_unused_parameters=False,
            fsdp="full_shard auto_wrap",
            fsdp_config={
                "fsdp_transformer_layer_cls_to_wrap": ["Qwen2DecoderLayer"],
            },
        )
    
    def train(self):
        """Main training loop"""
        # Load dataset
        dataset = self.load_dataset()
        
        # Prepare model and tokenizer
        self.prepare_model_and_tokenizer()
        
        # Tokenize dataset
        logger.info("Tokenizing dataset...")
        tokenized_dataset = dataset.map(
            self.tokenize_function,
            batched=True,
            remove_columns=dataset.column_names
        )
        
        # Split dataset
        split_dataset = tokenized_dataset.train_test_split(test_size=0.1, seed=42)
        train_dataset = split_dataset["train"]
        eval_dataset = split_dataset["test"]
        
        # Data collator
        data_collator = DataCollatorForLanguageModeling(
            tokenizer=self.tokenizer,
            mlm=False,
        )
        
        # Training arguments
        training_args = self.get_training_args()
        
        # Initialize trainer
        trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
            data_collator=data_collator,
            callbacks=[EarlyStoppingCallback(early_stopping_patience=3)],
        )
        
        # Check for checkpoint
        checkpoint = None
        if os.path.exists(self.output_dir):
            checkpoints = list(Path(self.output_dir).glob("checkpoint-*"))
            if checkpoints:
                checkpoint = str(max(checkpoints, key=lambda x: int(x.name.split("-")[-1])))
                logger.info(f"Resuming from checkpoint: {checkpoint}")
        
        # Train
        logger.info("Starting training...")
        trainer.train(resume_from_checkpoint=checkpoint)
        
        # Save final model
        logger.info("Saving final model...")
        trainer.save_model(f"{self.output_dir}/final")
        self.tokenizer.save_pretrained(f"{self.output_dir}/final")
        
        # Save to GCS if configured
        if self.output_dir.startswith('/gcs/'):
            self._upload_to_gcs()
        
        logger.info("Training completed successfully!")
        
    def _upload_to_gcs(self):
        """Upload model to Google Cloud Storage"""
        logger.info("Uploading model to GCS...")
        client = storage.Client()
        bucket_name = "nexuscare-ai-training"
        prefix = "models/iasoql-agilimed-healthcare-14b"
        
        bucket = client.bucket(bucket_name)
        
        for root, dirs, files in os.walk(f"{self.output_dir}/final"):
            for file in files:
                local_path = os.path.join(root, file)
                blob_path = f"{prefix}/{os.path.relpath(local_path, f'{self.output_dir}/final')}"
                blob = bucket.blob(blob_path)
                blob.upload_from_filename(local_path)
                logger.info(f"Uploaded {blob_path}")

def main():
    # Configuration
    config = {
        "base_model": "XGenerationLab/XiYanSQL-QwenCoder-14B-2504",
        "output_dir": os.environ.get("OUTPUT_DIR", "/gcs/nexuscare-ai-training/models/iasoql-agilimed-healthcare-14b"),
        "dataset_path": os.environ.get("DATASET_PATH", "../fhir-clickhouse-training-dataset-v8-FINAL.json"),
    }
    
    # Initialize trainer
    trainer = IasoQL14BTrainer(config)
    
    # Train
    trainer.train()

if __name__ == "__main__":
    main()