#!/usr/bin/env python3
"""
Submit 14B quantization job on A100 based on successful 7B configuration
"""

import os
from datetime import datetime
from google.cloud import aiplatform

# Configuration based on successful 7B A100 training
PROJECT_ID = "nexuscare-463413"
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = "vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com"
REGION = "asia-southeast1"  # Successfully used for 7B with 8 preemptible A100s

def main():
    print("=== Submitting 14B Quantization Job on A100 ===")
    print("Based on successful 7B model training configuration")
    print(f"Region: {REGION}")
    print("GPU: A100 (40GB VRAM)")
    
    # Initialize Vertex AI
    aiplatform.init(
        project=PROJECT_ID,
        location=REGION,
        staging_bucket=f"gs://{BUCKET_NAME}"
    )
    
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    job_name = f"iasoql-14b-quantization-a100-{timestamp}"
    
    # Create custom job with A100 configuration from 7B training
    custom_job = aiplatform.CustomJob(
        display_name=job_name,
        worker_pool_specs=[
            {
                "machine_spec": {
                    "machine_type": "a2-highgpu-1g",  # Same as 7B: 12 vCPUs, 85GB RAM
                    "accelerator_type": "NVIDIA_TESLA_A100",
                    "accelerator_count": 1,
                },
                "replica_count": 1,
                "disk_spec": {
                    "boot_disk_type": "pd-ssd",  # SSD for better performance
                    "boot_disk_size_gb": 200,
                },
                "container_spec": {
                    "image_uri": f"gcr.io/{PROJECT_ID}/iasoql-14b-quantization:latest",
                    "command": ["python", "quantize_base_model_cloud.py"],
                    "env": [
                        {
                            "name": "OUTPUT_PATH",
                            "value": f"gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized"
                        },
                        {
                            "name": "CUDA_VISIBLE_DEVICES",
                            "value": "0"
                        }
                    ],
                },
            }
        ],
        staging_bucket=f"gs://{BUCKET_NAME}",
    )
    
    # Submit job
    job = custom_job.submit(
        service_account=SERVICE_ACCOUNT,
        enable_web_access=True,
        timeout=28800,  # 8 hours in seconds like 7B training
    )
    
    print(f"\n✅ Job submitted successfully!")
    print(f"Job name: {job_name}")
    print(f"Job ID: {job.name}")
    print(f"Dashboard: https://console.cloud.google.com/vertex-ai/locations/{REGION}/training/custom-jobs?project={PROJECT_ID}")
    print("\nEstimated time: 10-15 minutes for quantization")
    print("Cost: ~$0.61 (A100 @ $3.67/hour)")

if __name__ == "__main__":
    main()