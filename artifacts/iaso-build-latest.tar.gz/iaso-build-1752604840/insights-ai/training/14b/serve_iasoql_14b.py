#!/usr/bin/env python3
"""
FastAPI Server for iasoql-agilimed-healthcare-14b

Serves the quantized 14B model with efficient inference using FastAPI.
Avoids vLLM compatibility issues while maintaining high performance.
"""

import os
import json
import torch
import logging
from typing import Dict, List, Optional, Any
from contextlib import asynccontextmanager
import gc

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    BitsAndBytesConfig,
    TextStreamer,
    StoppingCriteria,
    StoppingCriteriaList
)
from peft import PeftModel
from google.cloud import storage

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Global model instance
model_instance = None
tokenizer_instance = None

class SQLGenerationRequest(BaseModel):
    """Request model for SQL generation"""
    question: str = Field(..., description="Natural language question about healthcare data")
    context: Optional[Dict[str, Any]] = Field(default=None, description="Additional context for query generation")
    max_tokens: int = Field(default=512, description="Maximum tokens to generate")
    temperature: float = Field(default=0.1, description="Temperature for generation")
    top_p: float = Field(default=0.95, description="Top-p for nucleus sampling")
    stream: bool = Field(default=False, description="Enable streaming response")

class SQLGenerationResponse(BaseModel):
    """Response model for SQL generation"""
    query: str = Field(..., description="Generated SQL query")
    confidence: float = Field(..., description="Confidence score")
    execution_plan: Optional[str] = Field(default=None, description="Query execution plan")
    warnings: List[str] = Field(default_factory=list, description="Any warnings or notes")

class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    model_loaded: bool
    model_name: str
    memory_usage: Dict[str, float]

class StopOnSQLComplete(StoppingCriteria):
    """Stop generation when SQL query is complete"""
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer
        
    def __call__(self, input_ids, scores, **kwargs):
        # Check if we've generated a complete SQL statement
        text = self.tokenizer.decode(input_ids[0][-20:], skip_special_tokens=True)
        return ";" in text and (text.count("(") == text.count(")"))

class IasoQL14BServer:
    def __init__(self, model_path: str, device: str = "auto"):
        self.model_path = model_path
        self.device = device
        self.model = None
        self.tokenizer = None
        
    def load_model(self):
        """Load the quantized model with LoRA weights"""
        logger.info(f"Loading iasoql-agilimed-healthcare-14b from {self.model_path}")
        
        # Quantization config
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True,
        )
        
        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.model_path,
            trust_remote_code=True,
            padding_side="left"
        )
        
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        # Check if this is a merged model or separate base + LoRA
        adapter_config_path = os.path.join(self.model_path, "adapter_config.json")
        
        if os.path.exists(adapter_config_path):
            # Load base model + LoRA adapter
            logger.info("Loading base model with LoRA adapter...")
            with open(adapter_config_path, 'r') as f:
                adapter_config = json.load(f)
            
            base_model_name = adapter_config.get("base_model_name_or_path", "Qwen/Qwen2.5-14B-Instruct")
            
            base_model = AutoModelForCausalLM.from_pretrained(
                base_model_name,
                quantization_config=bnb_config,
                device_map=self.device,
                trust_remote_code=True,
                torch_dtype=torch.bfloat16,
            )
            
            self.model = PeftModel.from_pretrained(base_model, self.model_path)
        else:
            # Load merged model
            logger.info("Loading merged model...")
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_path,
                quantization_config=bnb_config,
                device_map=self.device,
                trust_remote_code=True,
                torch_dtype=torch.bfloat16,
            )
        
        self.model.eval()
        logger.info("Model loaded successfully!")
        
        # Log memory usage
        if torch.cuda.is_available():
            logger.info(f"GPU memory allocated: {torch.cuda.memory_allocated() / 1e9:.2f} GB")
    
    def generate_sql(self, question: str, context: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """Generate SQL query from natural language question"""
        # Prepare prompt
        prompt = self._prepare_prompt(question, context)
        
        # Tokenize
        inputs = self.tokenizer(prompt, return_tensors="pt", truncation=True, max_length=2048)
        inputs = {k: v.to(self.model.device) for k, v in inputs.items()}
        
        # Generate
        with torch.no_grad():
            # Set up generation parameters
            gen_kwargs = {
                "max_new_tokens": kwargs.get("max_tokens", 512),
                "temperature": kwargs.get("temperature", 0.1),
                "top_p": kwargs.get("top_p", 0.95),
                "do_sample": kwargs.get("temperature", 0.1) > 0,
                "pad_token_id": self.tokenizer.pad_token_id,
                "eos_token_id": self.tokenizer.eos_token_id,
            }
            
            # Add stopping criteria
            stopping_criteria = StoppingCriteriaList([StopOnSQLComplete(self.tokenizer)])
            
            outputs = self.model.generate(
                **inputs,
                **gen_kwargs,
                stopping_criteria=stopping_criteria
            )
        
        # Decode
        generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        sql_query = self._extract_sql(generated_text, len(prompt))
        
        # Calculate confidence (simplified)
        confidence = self._calculate_confidence(sql_query)
        
        # Generate warnings
        warnings = self._check_query_safety(sql_query)
        
        return {
            "query": sql_query,
            "confidence": confidence,
            "warnings": warnings
        }
    
    def _prepare_prompt(self, question: str, context: Optional[Dict] = None) -> str:
        """Prepare the prompt for SQL generation"""
        prompt = f"""You are IasoQL, a specialized AI for generating ClickHouse SQL queries for healthcare FHIR data.

Database Schema:
- fhir.patient: Patient demographics (id, name, birthDate, gender)
- fhir.encounter: Clinical encounters (id, patient_id, start, end, type)
- fhir.condition: Diagnoses (id, patient_id, code, onset_date)
- fhir.medication_request: Prescriptions (id, patient_id, medication, authored_on)
- fhir.observation: Lab results and vitals (id, patient_id, code, value, effective_date)

Question: {question}
"""
        
        if context:
            prompt += f"\nContext: {json.dumps(context, indent=2)}"
        
        prompt += "\nSQL Query:"
        
        return prompt
    
    def _extract_sql(self, generated_text: str, prompt_length: int) -> str:
        """Extract SQL query from generated text"""
        # Remove the prompt
        sql_text = generated_text[prompt_length:].strip()
        
        # Clean up the SQL
        if sql_text.startswith("```sql"):
            sql_text = sql_text[6:]
        if sql_text.endswith("```"):
            sql_text = sql_text[:-3]
        
        # Find the first complete SQL statement
        lines = sql_text.split('\n')
        sql_lines = []
        
        for line in lines:
            if line.strip():
                sql_lines.append(line)
                if ';' in line:
                    break
        
        return '\n'.join(sql_lines).strip()
    
    def _calculate_confidence(self, sql_query: str) -> float:
        """Calculate confidence score for generated query"""
        # Simple heuristic-based confidence
        confidence = 0.9
        
        # Check for common issues
        if not sql_query:
            return 0.0
        
        # Reduce confidence for very short queries
        if len(sql_query) < 20:
            confidence -= 0.2
        
        # Check for balanced parentheses
        if sql_query.count('(') != sql_query.count(')'):
            confidence -= 0.3
        
        # Check for SELECT statement
        if not sql_query.upper().startswith('SELECT'):
            confidence -= 0.2
        
        return max(0.1, min(1.0, confidence))
    
    def _check_query_safety(self, sql_query: str) -> List[str]:
        """Check query for potential issues"""
        warnings = []
        
        upper_query = sql_query.upper()
        
        # Check for dangerous operations
        if any(op in upper_query for op in ['DROP', 'DELETE', 'TRUNCATE', 'ALTER']):
            warnings.append("Query contains potentially dangerous operations")
        
        # Check for missing WHERE clause in certain cases
        if 'UPDATE' in upper_query and 'WHERE' not in upper_query:
            warnings.append("UPDATE without WHERE clause detected")
        
        # Check for SELECT *
        if 'SELECT *' in upper_query:
            warnings.append("Consider specifying columns instead of SELECT *")
        
        # Check for missing LIMIT
        if 'LIMIT' not in upper_query and 'COUNT' not in upper_query:
            warnings.append("Consider adding LIMIT clause for large result sets")
        
        return warnings
    
    def get_memory_usage(self) -> Dict[str, float]:
        """Get current memory usage"""
        memory_stats = {}
        
        if torch.cuda.is_available():
            memory_stats["gpu_allocated_gb"] = torch.cuda.memory_allocated() / 1e9
            memory_stats["gpu_reserved_gb"] = torch.cuda.memory_reserved() / 1e9
        
        # CPU memory
        import psutil
        process = psutil.Process()
        memory_stats["cpu_memory_gb"] = process.memory_info().rss / 1e9
        
        return memory_stats

# FastAPI app with lifespan management
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    global model_instance, tokenizer_instance
    
    model_path = os.environ.get("MODEL_PATH", "/models/iasoql-agilimed-healthcare-14b")
    if model_path.startswith("gs://"):
        # Download from GCS
        local_path = "/tmp/iasoql-agilimed-healthcare-14b"
        download_from_gcs(model_path, local_path)
        model_path = local_path
    
    server = IasoQL14BServer(model_path)
    server.load_model()
    
    model_instance = server
    
    yield
    
    # Shutdown
    del model_instance
    torch.cuda.empty_cache()
    gc.collect()

app = FastAPI(
    title="iasoql-agilimed-healthcare-14b SQL Generator",
    description="Advanced 14B parameter model for healthcare FHIR SQL generation",
    version="1.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy" if model_instance else "not_ready",
        model_loaded=model_instance is not None,
        model_name="iasoql-agilimed-healthcare-14b",
        memory_usage=model_instance.get_memory_usage() if model_instance else {}
    )

@app.post("/generate", response_model=SQLGenerationResponse)
async def generate_sql(request: SQLGenerationRequest):
    """Generate SQL query from natural language"""
    if not model_instance:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    try:
        result = model_instance.generate_sql(
            question=request.question,
            context=request.context,
            max_tokens=request.max_tokens,
            temperature=request.temperature,
            top_p=request.top_p
        )
        
        return SQLGenerationResponse(**result)
    
    except Exception as e:
        logger.error(f"Error generating SQL: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/batch_generate", response_model=List[SQLGenerationResponse])
async def batch_generate_sql(requests: List[SQLGenerationRequest]):
    """Generate SQL queries for multiple questions"""
    if not model_instance:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    results = []
    for request in requests:
        try:
            result = model_instance.generate_sql(
                question=request.question,
                context=request.context,
                max_tokens=request.max_tokens,
                temperature=request.temperature,
                top_p=request.top_p
            )
            results.append(SQLGenerationResponse(**result))
        except Exception as e:
            logger.error(f"Error in batch generation: {str(e)}")
            results.append(SQLGenerationResponse(
                query="",
                confidence=0.0,
                warnings=[f"Generation failed: {str(e)}"]
            ))
    
    return results

def download_from_gcs(gcs_path: str, local_path: str):
    """Download model from Google Cloud Storage"""
    logger.info(f"Downloading model from {gcs_path} to {local_path}")
    
    # Parse GCS path
    parts = gcs_path.replace("gs://", "").split("/", 1)
    bucket_name = parts[0]
    prefix = parts[1] if len(parts) > 1 else ""
    
    client = storage.Client()
    bucket = client.bucket(bucket_name)
    
    os.makedirs(local_path, exist_ok=True)
    
    for blob in bucket.list_blobs(prefix=prefix):
        if blob.name.startswith(prefix):
            # Calculate local file path
            relative_path = blob.name[len(prefix):].lstrip("/")
            local_file_path = os.path.join(local_path, relative_path)
            
            # Create directory if needed
            os.makedirs(os.path.dirname(local_file_path), exist_ok=True)
            
            # Download file
            blob.download_to_filename(local_file_path)
            logger.info(f"Downloaded {blob.name}")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    uvicorn.run(app, host="0.0.0.0", port=port)