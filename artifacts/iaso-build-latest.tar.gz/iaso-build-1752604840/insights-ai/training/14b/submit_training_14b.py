#!/usr/bin/env python3
"""
Submit IasoQL-14B training job to Vertex AI with QLoRA+DoRA
"""

import os
import json
from datetime import datetime
from google.cloud import aiplatform

# Initialize Vertex AI
PROJECT_ID = "nexuscare-463413"
REGION = "europe-west4"  # Netherlands - good GPU availability
# Alternative regions: "asia-southeast1" (Singapore), "europe-west1" (Belgium)
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = "ai-training@nexuscare-463413.iam.gserviceaccount.com"

aiplatform.init(
    project=PROJECT_ID,
    location=REGION,
    staging_bucket=f"gs://{BUCKET_NAME}"
)

def submit_training_job():
    """Submit training job to Vertex AI"""
    
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    job_name = f"iasoql-agilimed-healthcare-14b-{timestamp}"
    
    # Build container image URI
    image_uri = f"gcr.io/{PROJECT_ID}/iasoql-14b-training:latest"
    
    # Training job configuration
    job = aiplatform.CustomContainerTrainingJob(
        display_name=job_name,
        container_uri=image_uri,
        model_serving_container_image_uri=image_uri,  # Same image for serving
        command=["python", "train_iasoql_14b.py"],
    )
    
    # Environment variables
    env_vars = {
        "OUTPUT_DIR": f"/gcs/{BUCKET_NAME}/models/iasoql-agilimed-healthcare-14b/{timestamp}",
        "DATASET_PATH": "/app/dataset/fhir-clickhouse-training-dataset-v8-FINAL.json",
    }
    
    # Run the training job with preemptible GPUs
    model = job.run(
        replica_count=1,
        machine_type="g2-standard-16",  # T4 GPU with 16 vCPUs, 64GB RAM
        accelerator_type="NVIDIA_TESLA_T4",
        accelerator_count=1,
        environment_variables=env_vars,
        service_account=SERVICE_ACCOUNT,
        sync=False,  # Don't wait for completion
        scheduling={
            "timeout": "24h",
            "restart_job_on_worker_restart": True,
            "disable_retries": False,
            "strategy": "FLEX_START"  # Dynamic Workload Scheduler for preemptible
        },
        enable_web_access=True,  # For debugging
    )
    
    print(f"Training job submitted: {job_name}")
    print(f"Job resource name: {job.resource_name}")
    print(f"Monitor at: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={PROJECT_ID}")
    
    return job

def build_and_push_image():
    """Build and push Docker image to GCR"""
    print("Building Docker image...")
    
    # Create cloudbuild.yaml
    cloudbuild_config = {
        "steps": [
            {
                "name": "gcr.io/cloud-builders/docker",
                "args": [
                    "build",
                    "-t", f"gcr.io/{PROJECT_ID}/iasoql-14b-training:latest",
                    "-f", "Dockerfile",
                    "."
                ]
            },
            {
                "name": "gcr.io/cloud-builders/docker",
                "args": [
                    "push",
                    f"gcr.io/{PROJECT_ID}/iasoql-14b-training:latest"
                ]
            }
        ],
        "timeout": "3600s"
    }
    
    with open("cloudbuild.yaml", "w") as f:
        import yaml
        yaml.dump(cloudbuild_config, f)
    
    # Submit build
    os.system(f"gcloud builds submit --config=cloudbuild.yaml --project={PROJECT_ID}")
    
    print("Docker image built and pushed successfully!")

if __name__ == "__main__":
    # First build and push the image
    build_and_push_image()
    
    # Then submit the training job
    submit_training_job()