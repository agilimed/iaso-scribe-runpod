#!/usr/bin/env python3
"""
Submit quantization job with preemptible GPU and FLEX_START
"""

import os
from datetime import datetime
from google.cloud import aiplatform

# Try different regions with good preemptible GPU availability
REGIONS = [
    "europe-west4",      # Netherlands
    "asia-southeast1",   # Singapore  
    "europe-west1",      # Belgium
    "asia-south1",       # Mumbai
]

PROJECT_ID = "nexuscare-463413"
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = "ai-training@nexuscare-463413.iam.gserviceaccount.com"

def submit_quantization_job(region):
    """Submit quantization job to a specific region"""
    print(f"\n=== Attempting to submit in {region} ===")
    
    # Initialize Vertex AI for this region
    aiplatform.init(
        project=PROJECT_ID,
        location=region,
        staging_bucket=f"gs://{BUCKET_NAME}"
    )
    
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    job_name = f"iasoql-14b-quantization-{timestamp}"
    
    # Container image
    image_uri = f"gcr.io/{PROJECT_ID}/iasoql-14b-quantization:latest"
    
    try:
        # Create custom training job
        custom_job = aiplatform.CustomTrainingJob(
            display_name=job_name,
            container_uri=image_uri,
            command=["python", "quantize_base_model_cloud.py"],
        )
        
        # Submit with preemptible configuration
        job = custom_job.run(
            replica_count=1,
            machine_type="g2-standard-16",  # T4 GPU with 16 vCPUs
            accelerator_type="NVIDIA_TESLA_T4",
            accelerator_count=1,
            environment_variables={
                "OUTPUT_PATH": f"gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized",
            },
            service_account=SERVICE_ACCOUNT,
            sync=False,
            enable_web_access=True,
            # Use spot/preemptible instances
            reduction_server_replica_count=0,
            reduction_server_machine_type=None,
            boot_disk_type="pd-standard",
            boot_disk_size_gb=100,
        )
        
        print(f"✅ Job submitted successfully in {region}!")
        print(f"Job name: {job_name}")
        print(f"Monitor at: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={PROJECT_ID}")
        return True
        
    except Exception as e:
        print(f"❌ Failed in {region}: {str(e)}")
        return False

def main():
    print("=== Submitting Quantization Job with Preemptible GPU ===")
    print("Strategy: FLEX_START (Dynamic Workload Scheduler)")
    print(f"Model: XiYanSQL-QwenCoder-14B-2504")
    print(f"Output: gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized")
    
    # Try each region until one succeeds
    for region in REGIONS:
        if submit_quantization_job(region):
            print(f"\n✅ Successfully submitted in {region}")
            print("\n=== Next Steps ===")
            print("1. Monitor the quantization job (~10-15 minutes)")
            print("2. Once complete, run: python3 submit_training_14b_prequantized.py")
            print(f"3. Output will be at: gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized")
            break
    else:
        print("\n❌ Failed to submit job in all regions")
        print("Please check quotas and try again")

if __name__ == "__main__":
    main()