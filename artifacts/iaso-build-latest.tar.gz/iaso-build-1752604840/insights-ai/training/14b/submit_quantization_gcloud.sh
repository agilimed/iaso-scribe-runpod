#!/bin/bash

# Submit quantization job using gcloud directly

PROJECT_ID="nexuscare-463413"
REGION="us-central1"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
JOB_NAME="iasoql-14b-quantization-${TIMESTAMP}"
CONTAINER_IMAGE="gcr.io/${PROJECT_ID}/iasoql-14b-quantization:latest"
SERVICE_ACCOUNT="ai-training@${PROJECT_ID}.iam.gserviceaccount.com"

echo "=== Submitting Quantization Job via gcloud ==="
echo "Job name: ${JOB_NAME}"
echo "Region: ${REGION}"
echo "Container: ${CONTAINER_IMAGE}"

# Create job config
cat > /tmp/quantization-job-config.yaml << EOF
displayName: ${JOB_NAME}
jobSpec:
  workerPoolSpecs:
  - machineSpec:
      machineType: n1-highmem-8
      acceleratorType: NVIDIA_TESLA_T4
      acceleratorCount: 1
    replicaCount: 1
    containerSpec:
      imageUri: ${CONTAINER_IMAGE}
      command: ["python", "quantize_base_model_cloud.py"]
      env:
      - name: OUTPUT_PATH
        value: gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized
  serviceAccount: ${SERVICE_ACCOUNT}
  enableWebAccess: true
EOF

echo ""
echo "Submitting job..."

gcloud ai custom-jobs create \
  --region=${REGION} \
  --project=${PROJECT_ID} \
  --config=/tmp/quantization-job-config.yaml \
  --display-name=${JOB_NAME}

echo ""
echo "Monitor at: https://console.cloud.google.com/vertex-ai/locations/${REGION}/training/custom-jobs?project=${PROJECT_ID}"