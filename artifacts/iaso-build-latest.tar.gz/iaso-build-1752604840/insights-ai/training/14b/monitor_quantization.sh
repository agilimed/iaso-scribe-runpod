#!/bin/bash

echo "=== Monitoring Quantization Job ==="
echo

# Check in multiple regions
REGIONS="asia-southeast1 europe-west4 us-central1"

for REGION in $REGIONS; do
    echo "📍 Checking $REGION..."
    JOBS=$(gcloud ai custom-jobs list --region=$REGION --limit=3 --filter="displayName:iasoql-14b-quantization*" --format="table(displayName,state,createTime)" 2>/dev/null)
    if [ ! -z "$JOBS" ]; then
        echo "$JOBS"
    fi
    echo
done

# Check for quantized model
echo "💾 Checking for quantized model:"
gsutil ls -l gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized/ 2>/dev/null || echo "Model not yet available"
echo

# Check recent training output directories
echo "📂 Recent training outputs:"
gsutil ls gs://nexuscare-ai-training/aiplatform-custom-training-2025-07-07* 2>/dev/null | tail -5
echo

echo "=== Status Summary ==="
echo "• Job submitted at: 2025-07-07 01:12:22"
echo "• Expected completion: ~10-15 minutes"
echo "• Using preemptible T4 GPU in asia-southeast1"
echo "• Output location: gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized/"
echo
echo "Monitor live at: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project=nexuscare-463413"