#!/usr/bin/env python3
"""
Submit quantization job with detailed debugging
"""

import os
from datetime import datetime
from google.cloud import aiplatform
import traceback

PROJECT_ID = "nexuscare-463413"
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = f"ai-training@{PROJECT_ID}.iam.gserviceaccount.com"
REGION = "asia-southeast1"

def main():
    print("=== Submitting Quantization Job with Debug Info ===")
    
    try:
        # Initialize Vertex AI
        print(f"Initializing Vertex AI in {REGION}...")
        aiplatform.init(
            project=PROJECT_ID,
            location=REGION,
            staging_bucket=f"gs://{BUCKET_NAME}"
        )
        print("✅ Vertex AI initialized")
        
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        job_name = f"iasoql-14b-quantization-{timestamp}"
        container_uri = f"gcr.io/{PROJECT_ID}/iasoql-14b-quantization:latest"
        
        print(f"\nJob Configuration:")
        print(f"- Name: {job_name}")
        print(f"- Container: {container_uri}")
        print(f"- Region: {REGION}")
        print(f"- Machine: n1-highmem-8 with T4 GPU")
        
        # Verify container exists
        print(f"\nChecking container image...")
        import subprocess
        result = subprocess.run(
            ["gcloud", "container", "images", "describe", container_uri],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            print(f"⚠️  Warning: Container may not exist: {result.stderr}")
        else:
            print("✅ Container image found")
        
        # Create custom training job
        print(f"\nCreating custom training job...")
        custom_job = aiplatform.CustomContainerTrainingJob(
            display_name=job_name,
            container_uri=container_uri,
            command=["python", "quantize_base_model_cloud.py"],
        )
        print("✅ Training job object created")
        
        # Submit job
        print(f"\nSubmitting job...")
        job = custom_job.run(
            replica_count=1,
            machine_type="n1-highmem-8",
            accelerator_type="NVIDIA_TESLA_T4",
            accelerator_count=1,
            environment_variables={
                "OUTPUT_PATH": f"gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized",
            },
            service_account=SERVICE_ACCOUNT,
            sync=False,
            enable_web_access=True,
            boot_disk_type="pd-standard",
            boot_disk_size_gb=100,
        )
        
        print(f"\n✅ Job submitted successfully!")
        print(f"Job name: {job_name}")
        print(f"Job resource: {job.resource_name}")
        print(f"Dashboard: https://console.cloud.google.com/vertex-ai/locations/{REGION}/training/custom-jobs?project={PROJECT_ID}")
        
        # Get job details
        print(f"\nJob details:")
        print(f"- Display name: {job.display_name}")
        print(f"- State: {job.state}")
        print(f"- Create time: {job.create_time}")
        
    except Exception as e:
        print(f"\n❌ Error submitting job:")
        print(f"Error type: {type(e).__name__}")
        print(f"Error message: {str(e)}")
        print(f"\nFull traceback:")
        traceback.print_exc()
        
        # Additional debugging
        print(f"\n=== Debug Information ===")
        print(f"PROJECT_ID: {PROJECT_ID}")
        print(f"REGION: {REGION}")
        print(f"SERVICE_ACCOUNT: {SERVICE_ACCOUNT}")
        
        # Check gcloud config
        print(f"\nChecking gcloud configuration:")
        subprocess.run(["gcloud", "config", "get-value", "project"])
        subprocess.run(["gcloud", "config", "get-value", "account"])

if __name__ == "__main__":
    main()