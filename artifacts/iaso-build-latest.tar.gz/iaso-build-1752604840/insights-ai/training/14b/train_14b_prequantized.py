#!/usr/bin/env python3
"""
Training script for pre-quantized 14B model
Loads the 4-bit quantized model and trains with LoRA+DoRA
"""

import os
import json
import torch
from datasets import Dataset
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    BitsAndBytesConfig,
)
from trl import SFTTrainer
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class PreQuantizedTrainer:
    def __init__(self):
        # Get configuration from environment
        self.base_model_path = os.environ.get('BASE_MODEL_PATH', '/gcs/nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized')
        self.output_dir = os.environ.get('OUTPUT_DIR', '/gcs/nexuscare-ai-training/models/iasoql-agilimed-healthcare-14b')
        self.dataset_path = os.environ.get('DATASET_PATH', '/gcs/nexuscare-ai-training/datasets/fhir-clickhouse-training-dataset-v8-FINAL.json')
        
        # Training hyperparameters
        self.batch_size = int(os.environ.get('BATCH_SIZE', '1'))
        self.gradient_accumulation = int(os.environ.get('GRADIENT_ACCUMULATION', '16'))
        self.epochs = int(os.environ.get('EPOCHS', '3'))
        self.learning_rate = float(os.environ.get('LEARNING_RATE', '2e-4'))
        
        # LoRA configuration
        self.lora_r = int(os.environ.get('LORA_R', '32'))
        self.lora_alpha = int(os.environ.get('LORA_ALPHA', '64'))
        self.lora_dropout = float(os.environ.get('LORA_DROPOUT', '0.1'))
        self.use_dora = os.environ.get('USE_DORA', 'true').lower() == 'true'
        
        logger.info(f"Initialized trainer with:")
        logger.info(f"  Base model: {self.base_model_path}")
        logger.info(f"  Output dir: {self.output_dir}")
        logger.info(f"  Batch size: {self.batch_size}")
        logger.info(f"  Gradient accumulation: {self.gradient_accumulation}")
        logger.info(f"  Effective batch size: {self.batch_size * self.gradient_accumulation}")
        logger.info(f"  LoRA r: {self.lora_r}, alpha: {self.lora_alpha}")
        logger.info(f"  DoRA: {self.use_dora}")

    def format_training_prompt(self, example):
        """Format the training data"""
        prompt = f"""You are an AI assistant that converts natural language questions about healthcare data into ClickHouse SQL queries.
The database contains FHIR resources stored in ClickHouse tables.

### Question:
{example['question']}

### SQL:
{example['sql']}"""
        return {"text": prompt}

    def load_dataset(self):
        """Load and prepare the dataset"""
        logger.info(f"Loading dataset from {self.dataset_path}")
        
        # Load JSON dataset from GCS or local path
        if self.dataset_path.startswith('gs://'):
            import gcsfs
            fs = gcsfs.GCSFileSystem()
            with fs.open(self.dataset_path, 'r') as f:
                data = json.load(f)
        else:
            with open(self.dataset_path, 'r') as f:
                data = json.load(f)
        
        # Convert to HuggingFace dataset
        dataset = Dataset.from_list(data)
        
        # Format for training
        dataset = dataset.map(self.format_training_prompt)
        
        # Split into train/eval (90/10)
        split_dataset = dataset.train_test_split(test_size=0.1, seed=42)
        
        logger.info(f"Dataset loaded: {len(split_dataset['train'])} train, {len(split_dataset['test'])} eval")
        return split_dataset

    def load_model_and_tokenizer(self):
        """Load the pre-quantized model and tokenizer"""
        logger.info("Loading pre-quantized model and tokenizer...")
        
        # Handle GCS path - download model locally first
        local_model_path = self.base_model_path
        if self.base_model_path.startswith('gs://'):
            import gcsfs
            import tempfile
            import os
            
            logger.info("Downloading model from GCS...")
            local_model_path = "/tmp/quantized_model"
            os.makedirs(local_model_path, exist_ok=True)
            
            fs = gcsfs.GCSFileSystem()
            # Download all model files
            model_files = fs.ls(self.base_model_path)
            for file_path in model_files:
                if fs.isfile(file_path):
                    local_file = os.path.join(local_model_path, os.path.basename(file_path))
                    fs.download(file_path, local_file)
                    logger.info(f"Downloaded {os.path.basename(file_path)}")
        
        # Load tokenizer
        tokenizer = AutoTokenizer.from_pretrained(
            local_model_path,
            trust_remote_code=True,
            padding_side="right"
        )
        
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
            tokenizer.pad_token_id = tokenizer.eos_token_id
        
        # Load pre-quantized model
        # The model is already quantized, so we load it directly
        model = AutoModelForCausalLM.from_pretrained(
            local_model_path,
            trust_remote_code=True,
            device_map="auto",
            torch_dtype=torch.float16,
            # load_in_4bit=True is already applied during quantization
        )
        
        # Prepare model for k-bit training
        model = prepare_model_for_kbit_training(model)
        
        # Apply LoRA
        target_modules = os.environ.get('TARGET_MODULES', 'q_proj,v_proj,k_proj,o_proj,gate_proj,up_proj,down_proj').split(',')
        
        lora_config = LoraConfig(
            r=self.lora_r,
            lora_alpha=self.lora_alpha,
            target_modules=target_modules,
            lora_dropout=self.lora_dropout,
            bias="none",
            task_type="CAUSAL_LM",
            use_dora=self.use_dora,  # Enable DoRA
        )
        
        model = get_peft_model(model, lora_config)
        model.print_trainable_parameters()
        
        return model, tokenizer

    def train(self):
        """Main training function"""
        # Load dataset
        dataset = self.load_dataset()
        
        # Load model and tokenizer
        model, tokenizer = self.load_model_and_tokenizer()
        
        # Training arguments
        training_args = TrainingArguments(
            output_dir=self.output_dir,
            num_train_epochs=self.epochs,
            per_device_train_batch_size=self.batch_size,
            per_device_eval_batch_size=self.batch_size,
            gradient_accumulation_steps=self.gradient_accumulation,
            gradient_checkpointing=True,
            optim="paged_adamw_32bit",
            learning_rate=self.learning_rate,
            warmup_steps=int(os.environ.get('WARMUP_STEPS', '100')),
            logging_steps=10,
            save_strategy="steps",
            save_steps=int(os.environ.get('SAVE_STEPS', '50')),
            evaluation_strategy="steps",
            eval_steps=int(os.environ.get('EVAL_STEPS', '50')),
            do_eval=True,
            fp16=True,
            bf16=False,
            push_to_hub=False,
            report_to="none",  # Disable wandb
            load_best_model_at_end=True,
            metric_for_best_model="eval_loss",
            greater_is_better=False,
        )
        
        # Create trainer
        trainer = SFTTrainer(
            model=model,
            args=training_args,
            train_dataset=dataset["train"],
            eval_dataset=dataset["test"],
            tokenizer=tokenizer,
            dataset_text_field="text",
            max_seq_length=2048,
            packing=False,
        )
        
        # Start training
        logger.info("Starting training...")
        trainer.train()
        
        # Save the final model
        logger.info(f"Saving model to {self.output_dir}")
        trainer.save_model()
        tokenizer.save_pretrained(self.output_dir)
        
        # Save training info
        training_info = {
            "base_model": self.base_model_path,
            "training_completed": str(torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU"),
            "final_loss": trainer.state.best_metric,
            "total_steps": trainer.state.global_step,
            "lora_config": {
                "r": self.lora_r,
                "alpha": self.lora_alpha,
                "dropout": self.lora_dropout,
                "use_dora": self.use_dora
            }
        }
        
        with open(f"{self.output_dir}/training_info.json", "w") as f:
            json.dump(training_info, f, indent=2)
        
        logger.info("Training completed successfully!")
        return trainer

def main():
    """Main entry point"""
    logger.info("Starting IasoQL 14B Healthcare training with pre-quantized model")
    
    trainer = PreQuantizedTrainer()
    trainer.train()
    
    logger.info("All done! Model saved to output directory.")

if __name__ == "__main__":
    main()