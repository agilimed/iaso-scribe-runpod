#!/usr/bin/env python3
"""
Submit only the quantization job (image already built)
"""

import os
from datetime import datetime
from google.cloud import aiplatform

# Initialize Vertex AI
PROJECT_ID = "nexuscare-463413"
REGION = "asia-southeast1"
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = "ai-training@nexuscare-463413.iam.gserviceaccount.com"

aiplatform.init(
    project=PROJECT_ID,
    location=REGION,
    staging_bucket=f"gs://{BUCKET_NAME}"
)

# Submit quantization job
timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
job_name = f"iasoql-14b-quantization-{timestamp}"

# Build container image URI
image_uri = f"gcr.io/{PROJECT_ID}/iasoql-14b-quantization:latest"

# Training job configuration
job = aiplatform.CustomContainerTrainingJob(
    display_name=job_name,
    container_uri=image_uri,
    command=["python", "quantize_base_model_cloud.py"],
)

# Environment variables
env_vars = {
    "OUTPUT_PATH": f"gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized",
}

# Run the quantization job with preemptible GPU
job.run(
    replica_count=1,
    machine_type="g2-standard-16",  # T4 GPU with 16 vCPUs, 64GB RAM
    accelerator_type="NVIDIA_TESLA_T4",
    accelerator_count=1,
    environment_variables=env_vars,
    service_account=SERVICE_ACCOUNT,
    sync=False,
    enable_web_access=True,
)

print(f"Quantization job submitted: {job_name}")
print(f"Job resource name: {job.resource_name}")
print(f"Output will be saved to: gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized")
print(f"Monitor at: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={PROJECT_ID}")
print("\n=== Next Steps ===")
print("1. Monitor the quantization job (~10-15 minutes)")
print("2. Once complete, run: python3 submit_training_14b_prequantized.py")