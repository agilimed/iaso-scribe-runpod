#!/usr/bin/env python3
"""
Submit quantization job with FLEX_START for preemptible A100 GPUs
"""

import os
from datetime import datetime
from google.cloud import aiplatform
from google.cloud.aiplatform import hyperparameter_tuning as hpt

PROJECT_ID = "nexuscare-463413"
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = "vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com"
REGION = "asia-southeast1"

def main():
    print("=== Submitting Quantization Job with FLEX_START ===")
    print(f"Region: {REGION}")
    print("GPU: Preemptible A100 with FLEX_START")
    
    # Initialize Vertex AI
    aiplatform.init(
        project=PROJECT_ID,
        location=REGION,
        staging_bucket=f"gs://{BUCKET_NAME}"
    )
    
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    job_name = f"iasoql-14b-quantization-flex-{timestamp}"
    
    # Create custom training job with FLEX_START
    custom_job = aiplatform.CustomContainerTrainingJob(
        display_name=job_name,
        container_uri=f"gcr.io/{PROJECT_ID}/iasoql-14b-quantization:latest",
        command=["python", "quantize_base_model_cloud.py"],
    )
    
    # Submit with FLEX_START scheduling
    job = custom_job.run(
        replica_count=1,
        machine_type="a2-highgpu-1g",  # A100 machine type
        accelerator_type="NVIDIA_TESLA_A100",
        accelerator_count=1,
        environment_variables={
            "OUTPUT_PATH": f"gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized",
        },
        service_account=SERVICE_ACCOUNT,
        sync=False,
        enable_web_access=True,
        boot_disk_type="pd-standard",
        boot_disk_size_gb=100,
        # FLEX_START configuration
        scheduling={
            "disable_retries": False,
            "restart_job_on_worker_restart": True,
            "strategy": "FLEX_START"  # This enables flexible scheduling
        }
    )
    
    print(f"\n✅ Job submitted with FLEX_START!")
    print(f"Job name: {job_name}")
    print(f"Monitor at: https://console.cloud.google.com/vertex-ai/locations/{REGION}/training/custom-jobs?project={PROJECT_ID}")
    print("\nFLEX_START will automatically schedule the job when preemptible A100 resources become available.")
    print("This may take some time but will use the preemptible quota.")

if __name__ == "__main__":
    main()