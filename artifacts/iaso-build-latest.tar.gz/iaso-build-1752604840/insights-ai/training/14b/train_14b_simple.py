#!/usr/bin/env python3
"""
Simple training script that downloads files first
"""

import os
import subprocess
import json
import torch
from datasets import Dataset
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
)
from trl import SFTTrainer
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def download_files():
    """Download dataset and model files"""
    logger.info("Downloading dataset...")
    subprocess.run([
        "gsutil", "cp", 
        "gs://nexuscare-ai-training/datasets/fhir-clickhouse-training-dataset-v8-FINAL.json",
        "/tmp/dataset.json"
    ], check=True)
    
    logger.info("Downloading quantized model...")
    subprocess.run(["mkdir", "-p", "/tmp/quantized_model"], check=True)
    subprocess.run([
        "gsutil", "-m", "cp", "-r",
        "gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized/*",
        "/tmp/quantized_model/"
    ], check=True)
    
    logger.info("Files downloaded successfully!")

def format_training_prompt(example):
    """Format the training data"""
    prompt = f"""You are an AI assistant that converts natural language questions about healthcare data into ClickHouse SQL queries.
The database contains FHIR resources stored in ClickHouse tables.

### Question:
{example['question']}

### SQL:
{example['sql']}"""
    return {"text": prompt}

def main():
    # Download files first
    download_files()
    
    logger.info("Loading dataset...")
    with open("/tmp/dataset.json", 'r') as f:
        data = json.load(f)
    
    dataset = Dataset.from_list(data)
    dataset = dataset.map(format_training_prompt)
    split_dataset = dataset.train_test_split(test_size=0.1, seed=42)
    
    logger.info("Loading model and tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(
        "/tmp/quantized_model",
        trust_remote_code=True,
        padding_side="right"
    )
    
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        tokenizer.pad_token_id = tokenizer.eos_token_id
    
    model = AutoModelForCausalLM.from_pretrained(
        "/tmp/quantized_model",
        trust_remote_code=True,
        device_map="auto",
        torch_dtype=torch.float16,
    )
    
    model = prepare_model_for_kbit_training(model)
    
    # LoRA config
    lora_config = LoraConfig(
        r=32,
        lora_alpha=64,
        target_modules=["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        lora_dropout=0.1,
        bias="none",
        task_type="CAUSAL_LM",
        use_dora=True,
    )
    
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()
    
    # Training args
    output_dir = os.environ.get('OUTPUT_DIR', '/gcs/nexuscare-ai-training/models/iasoql-agilimed-healthcare-14b')
    
    training_args = TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=3,
        per_device_train_batch_size=1,
        per_device_eval_batch_size=1,
        gradient_accumulation_steps=16,
        gradient_checkpointing=True,
        optim="paged_adamw_32bit",
        learning_rate=2e-4,
        warmup_steps=100,
        logging_steps=10,
        save_strategy="steps",
        save_steps=50,
        evaluation_strategy="steps",
        eval_steps=50,
        do_eval=True,
        fp16=True,
        push_to_hub=False,
        report_to="none",
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",
        greater_is_better=False,
    )
    
    # Create trainer
    trainer = SFTTrainer(
        model=model,
        args=training_args,
        train_dataset=split_dataset["train"],
        eval_dataset=split_dataset["test"],
        tokenizer=tokenizer,
        dataset_text_field="text",
        max_seq_length=2048,
        packing=False,
    )
    
    # Train
    logger.info("Starting training...")
    trainer.train()
    
    # Save
    logger.info(f"Saving model to {output_dir}")
    trainer.save_model()
    tokenizer.save_pretrained(output_dir)
    
    logger.info("Training completed!")

if __name__ == "__main__":
    main()