#!/usr/bin/env python3
"""
Local testing script for IasoQL-14B
Tests both training and inference locally with minimal resources
"""

import json
import requests
import time
from pathlib import Path

def test_training_script():
    """Test if training script loads correctly"""
    print("Testing training script imports...")
    
    try:
        import train_iasoql_14b
        print("✓ Training script imports successfully")
        
        # Test configuration
        config = {
            "base_model": "Qwen/Qwen2.5-14B-Instruct",
            "skip_wandb": True,
            "dataset_path": "../fhir-clickhouse-training-dataset-v8-FINAL.json"
        }
        
        # Just test initialization (not actual training)
        trainer = train_iasoql_14b.IasoQL14BTrainer(config)
        print("✓ Trainer initialized successfully")
        
    except Exception as e:
        print(f"✗ Training script error: {e}")
        return False
    
    return True

def test_serving_script():
    """Test if serving script loads correctly"""
    print("\nTesting serving script imports...")
    
    try:
        import serve_iasoql_14b
        print("✓ Serving script imports successfully")
        
        # Test model server initialization
        server = serve_iasoql_14b.IasoQL14BServer("/tmp/test-model")
        print("✓ Server initialized successfully")
        
    except Exception as e:
        print(f"✗ Serving script error: {e}")
        return False
    
    return True

def test_api_endpoints():
    """Test API endpoints (requires server running)"""
    print("\nTesting API endpoints...")
    
    base_url = "http://localhost:8080"
    
    # Test health endpoint
    try:
        response = requests.get(f"{base_url}/health", timeout=5)
        if response.status_code == 200:
            print("✓ Health endpoint accessible")
            print(f"  Response: {response.json()}")
        else:
            print(f"✗ Health endpoint returned {response.status_code}")
    except requests.exceptions.ConnectionError:
        print("✗ Server not running (this is expected for local testing)")
        return False
    
    # Test generation endpoint
    test_request = {
        "question": "Show all patients with diabetes",
        "max_tokens": 256,
        "temperature": 0.1
    }
    
    try:
        response = requests.post(
            f"{base_url}/generate",
            json=test_request,
            timeout=30
        )
        if response.status_code == 200:
            print("✓ Generation endpoint working")
            result = response.json()
            print(f"  Generated SQL: {result.get('query', 'N/A')}")
            print(f"  Confidence: {result.get('confidence', 0)}")
        else:
            print(f"✗ Generation endpoint returned {response.status_code}")
    except Exception as e:
        print(f"✗ Generation endpoint error: {e}")
    
    return True

def test_dataset_loading():
    """Test dataset loading"""
    print("\nTesting dataset loading...")
    
    dataset_path = Path("../fhir-clickhouse-training-dataset-v8-FINAL.json")
    
    if not dataset_path.exists():
        print(f"✗ Dataset not found at {dataset_path}")
        return False
    
    try:
        with open(dataset_path, 'r') as f:
            data = json.load(f)
        
        print(f"✓ Dataset loaded successfully")
        print(f"  Total SQL queries: {data['metadata']['total_sql_queries']}")
        print(f"  Total function examples: {data['metadata']['total_function_examples']}")
        print(f"  Success rate: {data['metadata']['success_rate']}")
        
        # Test a sample query
        if 'sql_queries' in data and len(data['sql_queries']) > 0:
            sample = data['sql_queries'][0]
            print(f"\nSample query:")
            print(f"  Question: {sample['question']}")
            print(f"  SQL: {sample['query'][:100]}...")
        
    except Exception as e:
        print(f"✗ Dataset loading error: {e}")
        return False
    
    return True

def test_memory_requirements():
    """Estimate memory requirements"""
    print("\nEstimating memory requirements...")
    
    # 14B model with 4-bit quantization
    model_params = 14_000_000_000  # 14B parameters
    bits_per_param = 4  # 4-bit quantization
    
    # Calculate base model size
    model_size_gb = (model_params * bits_per_param) / (8 * 1024**3)
    
    # Add overhead for activations, gradients, optimizer states
    training_overhead = 2.5  # Approximate multiplier
    inference_overhead = 1.2
    
    print(f"✓ Memory estimates:")
    print(f"  Base model size (4-bit): {model_size_gb:.2f} GB")
    print(f"  Training memory: ~{model_size_gb * training_overhead:.2f} GB")
    print(f"  Inference memory: ~{model_size_gb * inference_overhead:.2f} GB")
    print(f"  Recommended GPU: T4 (16GB) or better")
    
    return True

def main():
    """Run all tests"""
    print("=== IasoQL-14B Local Testing ===\n")
    
    tests = [
        ("Training Script", test_training_script),
        ("Serving Script", test_serving_script),
        ("Dataset Loading", test_dataset_loading),
        ("Memory Requirements", test_memory_requirements),
        ("API Endpoints", test_api_endpoints),
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n--- {test_name} ---")
        try:
            success = test_func()
            results.append((test_name, success))
        except Exception as e:
            print(f"✗ Test failed with error: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n=== Test Summary ===")
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    for test_name, success in results:
        status = "✓ PASSED" if success else "✗ FAILED"
        print(f"{test_name}: {status}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed! Ready for deployment.")
    else:
        print("\n⚠️  Some tests failed. Please review the errors above.")

if __name__ == "__main__":
    main()