#!/usr/bin/env python3
"""
Monitor quantization job in us-central1
"""

import time
import subprocess
import json
from datetime import datetime

PROJECT_ID = "nexuscare-463413"
REGION = "us-central1"
OUTPUT_PATH = "gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized"

def check_job_status():
    """Check quantization job status"""
    cmd = [
        "gcloud", "ai", "custom-jobs", "list",
        "--region", REGION,
        "--project", PROJECT_ID,
        "--limit", "10",
        "--format", "json",
        "--sort-by", "~createTime"
    ]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        jobs = json.loads(result.stdout) if result.stdout else []
        
        # Find quantization jobs
        for job in jobs:
            if "quantization" in job.get("displayName", "").lower():
                return job
        
        return None
    except Exception as e:
        print(f"Error checking jobs: {e}")
        return None

def check_output():
    """Check if output exists"""
    cmd = ["gsutil", "ls", "-la", OUTPUT_PATH]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0:
            print("\n📁 Output directory contents:")
            print(result.stdout)
            return True
        return False
    except:
        return False

def main():
    print(f"=== Monitoring Quantization Job in {REGION} ===")
    print(f"Submitted at: ~{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Output path: {OUTPUT_PATH}")
    print("\nChecking status...\n")
    
    attempts = 0
    while attempts < 30:  # Check for 15 minutes
        job = check_job_status()
        
        if job:
            name = job.get("displayName", "Unknown")
            state = job.get("state", "Unknown")
            create_time = job.get("createTime", "")
            
            print(f"\r[{datetime.now().strftime('%H:%M:%S')}] Found job: {name}")
            print(f"  State: {state}")
            
            if state == "JOB_STATE_SUCCEEDED":
                print("\n✅ Quantization completed!")
                check_output()
                print("\n=== Next Step ===")
                print("Run: python3 submit_training_14b_prequantized.py")
                break
                
            elif state in ["JOB_STATE_FAILED", "JOB_STATE_CANCELLED"]:
                print(f"\n❌ Job {state}")
                error = job.get("error", {})
                if error:
                    print(f"Error: {error.get('message', 'Unknown')}")
                break
                
            elif state == "JOB_STATE_RUNNING":
                print("  Status: Running... (this may take 10-15 minutes)")
        else:
            print(f"\r[{datetime.now().strftime('%H:%M:%S')}] No quantization job found yet...", end="")
        
        time.sleep(30)
        attempts += 1
    
    print(f"\n\nMonitor manually at:")
    print(f"https://console.cloud.google.com/vertex-ai/locations/{REGION}/training/custom-jobs?project={PROJECT_ID}")

if __name__ == "__main__":
    main()