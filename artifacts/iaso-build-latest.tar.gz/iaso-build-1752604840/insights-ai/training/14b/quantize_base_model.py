#!/usr/bin/env python3
"""
Pre-quantize XiYanSQL-QwenCoder-14B-2504 and save for training

This script quantizes the base model once and saves it, avoiding the need
to quantize at runtime during training or inference.
"""

import os
import json
import torch
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List

from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    BitsAndBytesConfig
)
from datasets import Dataset
from google.cloud import storage
import gc

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ModelQuantizer:
    def __init__(self, config: Dict):
        self.base_model = config.get('base_model', 'XGenerationLab/XiYanSQL-QwenCoder-14B-2504')
        self.output_dir = config.get('output_dir', './quantized_models/iasoql-14b-base-quantized')
        self.dataset_path = config.get('dataset_path', '../fhir-clickhouse-training-dataset-v8-FINAL.json')
        self.use_calibration = config.get('use_calibration', True)
        
    def load_calibration_data(self) -> List[str]:
        """Load calibration dataset for better quantization"""
        logger.info("Loading calibration data...")
        
        with open(self.dataset_path, 'r') as f:
            data = json.load(f)
        
        # Extract sample queries for calibration
        calibration_texts = []
        
        # Use a subset of queries for calibration
        for example in data['sql_queries'][:20]:  # Use first 20 queries
            text = f"Question: {example['question']}\nAnswer: {example['query']}"
            calibration_texts.append(text)
        
        logger.info(f"Loaded {len(calibration_texts)} calibration examples")
        return calibration_texts
    
    def quantize_and_save(self):
        """Quantize the model and save it"""
        logger.info(f"Starting quantization of {self.base_model}")
        
        # Create output directory
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)
        
        # Load tokenizer
        logger.info("Loading tokenizer...")
        tokenizer = AutoTokenizer.from_pretrained(
            self.base_model,
            trust_remote_code=True
        )
        
        # Configure quantization
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True,
        )
        
        # Load and quantize model
        logger.info("Loading and quantizing model (this may take 5-10 minutes)...")
        model = AutoModelForCausalLM.from_pretrained(
            self.base_model,
            quantization_config=quantization_config,
            device_map="auto",
            trust_remote_code=True,
            torch_dtype=torch.bfloat16,
        )
        
        logger.info("Model loaded and quantized successfully!")
        
        # Get memory usage
        if torch.cuda.is_available():
            logger.info(f"GPU memory used: {torch.cuda.memory_allocated() / 1e9:.2f} GB")
        
        # Save the quantized model
        logger.info(f"Saving quantized model to {self.output_dir}")
        
        # Save model and config
        model.save_pretrained(
            self.output_dir,
            safe_serialization=True,
            max_shard_size="5GB"
        )
        
        # Save tokenizer
        tokenizer.save_pretrained(self.output_dir)
        
        # Save quantization config for reference
        quant_info = {
            "base_model": self.base_model,
            "quantization_method": "bitsandbytes-4bit",
            "quantization_config": {
                "load_in_4bit": True,
                "bnb_4bit_quant_type": "nf4",
                "bnb_4bit_compute_dtype": "bfloat16",
                "bnb_4bit_use_double_quant": True
            },
            "quantized_at": datetime.now().isoformat(),
            "model_size_gb": sum(
                os.path.getsize(os.path.join(self.output_dir, f)) 
                for f in os.listdir(self.output_dir) 
                if f.endswith(('.safetensors', '.bin'))
            ) / 1e9
        }
        
        with open(os.path.join(self.output_dir, "quantization_info.json"), "w") as f:
            json.dump(quant_info, f, indent=2)
        
        logger.info(f"Quantized model size: {quant_info['model_size_gb']:.2f} GB")
        logger.info("Quantization complete!")
        
        # Cleanup
        del model
        gc.collect()
        torch.cuda.empty_cache()
        
        return self.output_dir
    
    def upload_to_gcs(self, local_path: str, gcs_path: str):
        """Upload quantized model to Google Cloud Storage"""
        logger.info(f"Uploading to GCS: {gcs_path}")
        
        client = storage.Client()
        bucket_name = "nexuscare-ai-training"
        
        bucket = client.bucket(bucket_name)
        
        for root, dirs, files in os.walk(local_path):
            for file in files:
                local_file = os.path.join(root, file)
                blob_path = os.path.join(
                    gcs_path,
                    os.path.relpath(local_file, local_path)
                )
                
                blob = bucket.blob(blob_path)
                blob.upload_from_filename(local_file)
                logger.info(f"Uploaded: {blob_path}")
        
        logger.info("Upload complete!")
        
        return f"gs://{bucket_name}/{gcs_path}"

def main():
    """Main quantization pipeline"""
    
    config = {
        "base_model": "XGenerationLab/XiYanSQL-QwenCoder-14B-2504",
        "output_dir": "./quantized_models/iasoql-14b-base-quantized",
        "dataset_path": "../fhir-clickhouse-training-dataset-v8-FINAL.json",
    }
    
    # Initialize quantizer
    quantizer = ModelQuantizer(config)
    
    # Quantize and save locally
    local_path = quantizer.quantize_and_save()
    
    # Upload to GCS
    if input("\nUpload to GCS? (y/n): ").lower() == 'y':
        gcs_path = "models/quantized/iasoql-14b-base-quantized"
        gcs_url = quantizer.upload_to_gcs(local_path, gcs_path)
        
        print(f"\nQuantized model available at: {gcs_url}")
        print("\nUpdate your training config to use:")
        print(f'  "base_model": "{gcs_url}"')
    else:
        print(f"\nQuantized model saved locally at: {local_path}")
        print("\nUpdate your training config to use:")
        print(f'  "base_model": "{local_path}"')

if __name__ == "__main__":
    main()