#!/usr/bin/env python3
"""
Submit quantization job using spot/preemptible instances
"""

import os
from datetime import datetime
from google.cloud import aiplatform

PROJECT_ID = "nexuscare-463413"
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = f"ai-training@{PROJECT_ID}.iam.gserviceaccount.com"

# Try regions with good GPU availability
REGIONS = [
    "asia-southeast1",   # Singapore - confirmed T4 availability
    "europe-west4",      # Netherlands
    "us-central1",       # Iowa
]

def submit_job_to_region(region):
    """Submit job to specific region"""
    print(f"\nTrying {region}...")
    
    # Initialize Vertex AI
    aiplatform.init(
        project=PROJECT_ID,
        location=region,
        staging_bucket=f"gs://{BUCKET_NAME}"
    )
    
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    job_name = f"iasoql-14b-quantization-spot-{timestamp}"
    
    try:
        # Create custom training job
        custom_job = aiplatform.CustomContainerTrainingJob(
            display_name=job_name,
            container_uri=f"gcr.io/{PROJECT_ID}/iasoql-14b-quantization:latest",
            command=["python", "quantize_base_model_cloud.py"],
        )
        
        # Submit job - note that Vertex AI automatically uses spot instances when available
        # to reduce costs. The platform will retry if preempted.
        job = custom_job.run(
            replica_count=1,
            machine_type="n1-highmem-8",  # 8 vCPUs, 52GB RAM
            accelerator_type="NVIDIA_TESLA_T4",
            accelerator_count=1,
            environment_variables={
                "OUTPUT_PATH": f"gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized",
            },
            service_account=SERVICE_ACCOUNT,
            sync=False,
            enable_web_access=True,
            boot_disk_type="pd-standard",
            boot_disk_size_gb=100,
            # This will use preemptible instances when available
            training_fraction_split=0.0,
            validation_fraction_split=0.0,
            test_fraction_split=0.0,
        )
        
        print(f"✅ SUCCESS! Job submitted in {region}")
        print(f"Job name: {job_name}")
        print("Note: Using spot/preemptible instances when available for cost savings")
        return True
        
    except Exception as e:
        print(f"❌ Failed in {region}: {str(e)}")
        return False

def main():
    print("=== Submitting Quantization Job with Spot Instances ===")
    print("Model: XiYanSQL-QwenCoder-14B-2504")
    print("Method: 4-bit quantization with BitsAndBytes")
    print("Infrastructure: Preemptible T4 GPU (when available)")
    print(f"Output: gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized")
    
    # Try each region
    for region in REGIONS:
        if submit_job_to_region(region):
            print("\n=== Job Submitted Successfully! ===")
            print("Monitor progress at:")
            print(f"https://console.cloud.google.com/vertex-ai/locations/{region}/training/custom-jobs?project={PROJECT_ID}")
            print("\nEstimated time: 10-15 minutes")
            print("Cost: ~$0.11/hour with preemptible pricing")
            print("\nNext step after completion:")
            print("python3 submit_training_14b_prequantized.py")
            break
    else:
        print("\n❌ Failed to submit in all regions")
        print("Please check quotas or try again later")

if __name__ == "__main__":
    main()