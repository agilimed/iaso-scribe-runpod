# Current Status: iasoql-agilimed-healthcare-14b

## 🚀 What's Happening Now

### Step 1: Building Docker Image (IN PROGRESS)
- **Build ID**: 854dfe32-5a40-480d-9f9c-8aab9216d574
- **Status**: WORKING
- **Purpose**: Creating container for model quantization
- **Monitor**: https://console.cloud.google.com/cloud-build/builds/854dfe32-5a40-480d-9f9c-8aab9216d574?project=nexuscare-463413

### Step 2: Quantization Job (PENDING)
- **Model**: XiYanSQL-QwenCoder-14B-2504 → 4-bit quantized
- **Output**: gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized
- **Region**: asia-southeast1
- **GPU**: Preemptible T4 with FLEX_START
- **Duration**: ~10-15 minutes

### Step 3: Training Job (NEXT)
- **Input**: Pre-quantized model + 52 FHIR queries
- **Method**: QLoRA + DoRA
- **Output**: LoRA adapters (~3GB)
- **Duration**: ~12-16 hours on preemptible T4

## 🔧 Key Configurations

### No HF Token Needed! ✅
- XiYanSQL-QwenCoder-14B-2504 is public (like 7B)
- Removed all HF_TOKEN requirements

### Using Preemptible GPUs
- **Strategy**: FLEX_START (Dynamic Workload Scheduler)
- **Region**: asia-southeast1 (good availability)
- **Backup regions**: europe-west4, europe-west1
- **Cost**: ~$0.11/hour (vs $0.35/hour on-demand)

## 📊 Timeline

1. **Docker Build**: ~5-10 minutes
2. **Quantization**: ~10-15 minutes  
3. **Training**: ~12-16 hours
4. **Total**: ~13-17 hours

## 🎯 Benefits of Pre-Quantization

- ✅ 10x faster startup (30s vs 5min)
- ✅ No memory spikes (constant 7GB)
- ✅ Consistent quantization
- ✅ Better for production deployment

## 📝 Commands to Run

```bash
# Monitor progress
./monitor_jobs.sh

# After quantization completes:
python3 submit_training_14b_prequantized.py

# After training completes:
python3 deploy_vllm_lora_resolver.py
```