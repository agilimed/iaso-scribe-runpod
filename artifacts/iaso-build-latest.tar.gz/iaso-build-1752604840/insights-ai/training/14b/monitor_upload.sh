#!/bin/bash

echo "=== Monitoring Quantized Model Upload ==="
echo "Location: gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized/"
echo ""

while true; do
  # Count files
  FILE_COUNT=$(gsutil ls gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized/ 2>/dev/null | wc -l)
  
  # Get total size
  TOTAL_SIZE=$(gsutil du -s gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized/ 2>/dev/null | awk '{print $1}')
  
  # Convert to human readable
  if [ -n "$TOTAL_SIZE" ]; then
    HUMAN_SIZE=$(numfmt --to=iec-i --suffix=B $TOTAL_SIZE 2>/dev/null || echo "${TOTAL_SIZE} bytes")
  else
    HUMAN_SIZE="0B"
  fi
  
  # Display status
  echo -ne "\r[$(date +%H:%M:%S)] Files uploaded: $FILE_COUNT | Total size: $HUMAN_SIZE"
  
  # Check for key files that indicate completion
  if gsutil ls gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized/model.safetensors.index.json &>/dev/null; then
    echo -e "\n✅ Model index found - upload likely complete!"
    gsutil ls -la gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized/ | tail -10
    break
  fi
  
  sleep 10
done

echo ""
echo "Upload complete! Ready to start training."