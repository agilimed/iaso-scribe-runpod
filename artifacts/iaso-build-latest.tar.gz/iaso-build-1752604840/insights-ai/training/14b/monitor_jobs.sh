#!/bin/bash

echo "=== Monitoring Jobs ==="
echo

# Check Cloud Build status
echo "📦 Cloud Build Status:"
gcloud builds list --limit=1 --project=nexuscare-463413 --format="table(id,status,createTime)"
echo

# Check Vertex AI jobs
echo "🚀 Vertex AI Training Jobs:"
gcloud ai custom-jobs list --region=asia-southeast1 --limit=5 --format="table(displayName,state,createTime)" 2>/dev/null || echo "No jobs in asia-southeast1"
echo

# Check for completed quantized model in GCS
echo "💾 Checking for quantized model:"
gsutil ls -l gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized/ 2>/dev/null || echo "Quantized model not yet available"
echo

# Instructions
echo "=== Next Steps ==="
echo "1. Once Cloud Build completes, the quantization job will be submitted"
echo "2. Quantization takes ~10-15 minutes on T4 GPU"
echo "3. After quantization, run: python3 submit_training_14b_prequantized.py"
echo
echo "Monitor builds at: https://console.cloud.google.com/cloud-build/builds?project=nexuscare-463413"
echo "Monitor training at: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project=nexuscare-463413"