#!/usr/bin/env python3
"""
Submit 14B training job with tokenizer fix using FLEX_START and preemptible A100
Uses the same approach as successful quantization job
"""

import os
import time
from datetime import datetime
from google.cloud import aiplatform
from google.cloud.aiplatform import CustomJob

PROJECT_ID = "nexuscare-463413"
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = "vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com"
REGION = "asia-southeast1"  # Best A100 availability

def main():
    print("=== Submitting 14B Training with Tokenizer Fix ===")
    print(f"Region: {REGION}")
    print("GPU: Preemptible A100")
    print("Scheduling: FLEX_START (Dynamic Workload Scheduler)")
    print("Fix: Tokenizer compatibility issue resolved")
    
    # Initialize Vertex AI
    aiplatform.init(
        project=PROJECT_ID,
        location=REGION,
        staging_bucket=f"gs://{BUCKET_NAME}"
    )
    
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    job_name = f"iasoql-14b-training-tokenizer-fix-{timestamp}"
    
    # Python script with tokenizer fix
    training_script = '''
import os
import sys
import json
import traceback
import subprocess
from datetime import datetime

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")
    sys.stdout.flush()

try:
    # Fix NumPy version conflict
    log("Fixing NumPy version conflict...")
    subprocess.run(["pip", "install", "numpy<2", "--force-reinstall"], check=True)
    
    # Import libraries after numpy fix
    import torch
    import gcsfs
    from datasets import Dataset
    from transformers import (
        AutoTokenizer, 
        PreTrainedTokenizerFast,
        AutoModelForCausalLM,
        BitsAndBytesConfig,
        TrainingArguments,
        DataCollatorForLanguageModeling
    )
    from trl import SFTTrainer
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
    
    log("\\n=== DOWNLOADING FILES ===")
    fs = gcsfs.GCSFileSystem()
    
    # Download dataset
    dataset_gcs = 'nexuscare-ai-training/datasets/fhir-clickhouse-training-dataset-v8-FINAL.json'
    dataset_local = '/tmp/training-dataset.json'
    log(f"Downloading dataset from gs://{dataset_gcs}")
    fs.get(dataset_gcs, dataset_local)
    log(f"Dataset downloaded: {os.path.getsize(dataset_local)} bytes")
    
    # Download model
    model_gcs = 'nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized'
    model_local = '/tmp/quantized-model'
    log(f"Downloading model from gs://{model_gcs}...")
    fs.get(model_gcs, model_local, recursive=True)
    
    # Load dataset
    log("\\n=== LOADING DATASET ===")
    with open(dataset_local, 'r') as f:
        data = json.load(f)
    
    training_examples = []
    for example in data.get('sql_queries', []):
        training_examples.append({
            'question': example['question'],
            'sql': example['query']
        })
    log(f"Found {len(training_examples)} SQL queries")
    
    log(f"\\nPyTorch version: {torch.__version__}")
    log(f"CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        log(f"GPU: {torch.cuda.get_device_name(0)}")
    
    # Load tokenizer with fallback
    log("\\n=== LOADING TOKENIZER ===")
    try:
        tokenizer = AutoTokenizer.from_pretrained(
            model_local,
            trust_remote_code=True,
            use_fast=True
        )
        log("✓ Loaded tokenizer using AutoTokenizer")
    except Exception as e:
        log(f"AutoTokenizer failed: {e}")
        # Fallback to PreTrainedTokenizerFast
        tokenizer = PreTrainedTokenizerFast.from_pretrained(
            model_local,
            tokenizer_file=os.path.join(model_local, "tokenizer.json")
        )
        log("✓ Loaded tokenizer using PreTrainedTokenizerFast")
    
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    log(f"✓ Tokenizer ready. Vocab size: {len(tokenizer)}")
    
    # Configure quantization
    log("\\n=== CONFIGURING MODEL ===")
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_use_double_quant=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16
    )
    
    # Load model
    log("Loading quantized model...")
    model = AutoModelForCausalLM.from_pretrained(
        model_local,
        trust_remote_code=True,
        device_map="auto",
        torch_dtype=torch.bfloat16,
        quantization_config=bnb_config,
        low_cpu_mem_usage=True,
        attn_implementation="flash_attention_2"
    )
    log("✓ Model loaded successfully")
    
    # Prepare for training
    model = prepare_model_for_kbit_training(model)
    
    # LoRA configuration
    lora_config = LoraConfig(
        r=32,
        lora_alpha=64,
        target_modules=["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        lora_dropout=0.1,
        bias="none",
        task_type="CAUSAL_LM",
        use_dora=True,
    )
    
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()
    
    # Prepare dataset
    log("\\n=== PREPARING DATASET ===")
    
    def format_prompt(example):
        # Simple format for compatibility
        text = f"Question: {example['question']}\\nSQL: {example['sql']}"
        return {"text": text}
    
    dataset = Dataset.from_list(training_examples)
    dataset = dataset.map(format_prompt)
    split_dataset = dataset.train_test_split(test_size=0.1, seed=42)
    log(f"Dataset split: train={len(split_dataset['train'])}, test={len(split_dataset['test'])}")
    
    # Training configuration
    output_dir = '/gcs/nexuscare-ai-training/models/iasoql-agilimed-healthcare-14b'
    log(f"\\nOutput directory: {output_dir}")
    
    training_args = TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=3,
        per_device_train_batch_size=1,
        per_device_eval_batch_size=1,
        gradient_accumulation_steps=16,
        gradient_checkpointing=True,
        optim="paged_adamw_8bit",
        learning_rate=1e-4,
        warmup_steps=100,
        logging_steps=10,
        save_strategy="steps",
        save_steps=50,
        evaluation_strategy="steps",
        eval_steps=50,
        do_eval=True,
        bf16=True,
        tf32=True,
        push_to_hub=False,
        report_to=[],
        load_best_model_at_end=True,
        metric_for_best_model="loss",
        greater_is_better=False,
        gradient_checkpointing_kwargs={"use_reentrant": False},
        ddp_find_unused_parameters=False,
    )
    
    # Create trainer
    log("\\n=== CREATING TRAINER ===")
    trainer = SFTTrainer(
        model=model,
        args=training_args,
        train_dataset=split_dataset["train"],
        eval_dataset=split_dataset["test"],
        tokenizer=tokenizer,
        dataset_text_field="text",
        max_seq_length=2048,
        packing=False,
    )
    
    # Train
    log("\\n=== STARTING TRAINING ===")
    trainer.train()
    
    # Save model
    log("\\n=== SAVING MODEL ===")
    final_output = f"{output_dir}/final"
    trainer.save_model(final_output)
    tokenizer.save_pretrained(final_output)
    
    # Save training info
    training_info = {
        "base_model": "XiYanSQL-QwenCoder-14B-2504-quantized",
        "training_completed": datetime.now().isoformat(),
        "final_loss": trainer.state.log_history[-1].get('loss', 'N/A'),
        "total_steps": trainer.state.global_step,
        "dataset_size": len(training_examples),
    }
    
    with open(f"{final_output}/training_info.json", "w") as f:
        json.dump(training_info, f, indent=2)
    
    log("\\n✅ TRAINING COMPLETED SUCCESSFULLY!")
    
except Exception as e:
    log(f"\\n❌ ERROR: {str(e)}")
    traceback.print_exc()
    sys.exit(1)
'''

    # Create custom job
    custom_job = CustomJob(
        display_name=job_name,
        worker_pool_specs=[
            {
                "machine_spec": {
                    "machine_type": "a2-highgpu-1g",  # 12 vCPUs, 85GB RAM
                    "accelerator_type": "NVIDIA_TESLA_A100",
                    "accelerator_count": 1,
                },
                "replica_count": 1,
                "disk_spec": {
                    "boot_disk_type": "pd-ssd",
                    "boot_disk_size_gb": 500,  # More space for training
                },
                "container_spec": {
                    "image_uri": f"gcr.io/{PROJECT_ID}/iasoql-14b-trainer:latest",
                    "command": ["python", "-c", training_script],
                    "env": [
                        {
                            "name": "PYTHONUNBUFFERED",
                            "value": "1"
                        },
                        {
                            "name": "CUDA_VISIBLE_DEVICES",
                            "value": "0"
                        },
                        {
                            "name": "TRANSFORMERS_CACHE",
                            "value": "/tmp/cache"
                        },
                        {
                            "name": "HF_HOME",
                            "value": "/tmp/hf_home"
                        },
                        {
                            "name": "TORCH_CUDA_ARCH_LIST",
                            "value": "7.0;7.5;8.0;8.6"
                        }
                    ],
                },
            }
        ],
        # Enable FLEX_START with preemptible
        scheduling={
            "strategy": "FLEX_START",  # Dynamic Workload Scheduler
            "disable_retries": False,
            "restart_job_on_worker_restart": True,
            "max_wait_duration": {"seconds": 86400},  # 24 hours max wait
            "max_run_duration": {"seconds": 86400},   # 24 hours max runtime
        },
        service_account=SERVICE_ACCOUNT,
        base_output_dir=f"gs://{BUCKET_NAME}/training-outputs",
    )
    
    # Submit the job
    print("\n📤 Submitting job with FLEX_START...")
    custom_job.run(
        timeout=86400,  # 24 hours for training
        enable_web_access=True,
        sync=False
    )
    
    # Wait for job to be created
    time.sleep(5)
    
    print(f"\n✅ Job submitted successfully!")
    print(f"Job name: {job_name}")
    print(f"Job state: {custom_job.state}")
    print(f"Dashboard: https://console.cloud.google.com/vertex-ai/locations/{REGION}/training/custom-jobs?project={PROJECT_ID}")
    
    print("\n💰 Cost Estimation:")
    print("- Preemptible A100: ~$1.36/hour (vs $3.67 regular)")
    print("- Expected time: 12-16 hours")
    print("- Total cost: ~$16-$22")
    print("- Savings: 63% cheaper than regular A100!")
    
    print("\n⏱️  FLEX_START: Job will start when resources available")
    print("\n📊 Monitor progress:")
    print("   ./monitor_jobs.sh")
    print("\n💡 After training completes:")
    print("   python3 deploy_vllm_lora_resolver.py")

if __name__ == "__main__":
    main()