#!/usr/bin/env python3
"""
Monitor quantization job progress in real-time
"""

import time
import subprocess
import json
from datetime import datetime

PROJECT_ID = "nexuscare-463413"
REGION = "asia-southeast1"
JOB_NAME_PREFIX = "iasoql-14b-quantization"
OUTPUT_PATH = "gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized"

def get_recent_jobs():
    """Get recent quantization jobs"""
    cmd = [
        "gcloud", "ai", "custom-jobs", "list",
        "--region", REGION,
        "--project", PROJECT_ID,
        "--limit", "5",
        "--format", "json",
        "--sort-by", "~createTime"
    ]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        jobs = json.loads(result.stdout)
        
        # Filter for quantization jobs
        quantization_jobs = [
            job for job in jobs 
            if JOB_NAME_PREFIX in job.get("displayName", "")
        ]
        
        return quantization_jobs
    except Exception as e:
        print(f"Error getting jobs: {e}")
        return []

def check_output_exists():
    """Check if quantized model exists"""
    cmd = [
        "gsutil", "ls", "-l", 
        f"{OUTPUT_PATH}/pytorch_model.bin"
    ]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        return result.returncode == 0
    except:
        return False

def format_time_diff(start_time):
    """Format time difference"""
    try:
        start = datetime.fromisoformat(start_time.replace("Z", "+00:00"))
        diff = datetime.now(start.tzinfo) - start
        minutes = int(diff.total_seconds() / 60)
        return f"{minutes} minutes"
    except:
        return "N/A"

def main():
    print("=== Monitoring Quantization Job ===")
    print(f"Region: {REGION}")
    print(f"Output: {OUTPUT_PATH}")
    print("\nChecking every 30 seconds... (Ctrl+C to stop)\n")
    
    while True:
        jobs = get_recent_jobs()
        
        if jobs:
            latest_job = jobs[0]
            name = latest_job.get("displayName", "Unknown")
            state = latest_job.get("state", "Unknown")
            create_time = latest_job.get("createTime", "")
            
            print(f"\r[{datetime.now().strftime('%H:%M:%S')}] Job: {name}")
            print(f"  Status: {state}")
            print(f"  Running for: {format_time_diff(create_time)}")
            
            if state == "JOB_STATE_SUCCEEDED":
                print("\n✅ Quantization completed successfully!")
                
                if check_output_exists():
                    print(f"✅ Model saved at: {OUTPUT_PATH}")
                    print("\n=== Next Step ===")
                    print("Run: python3 submit_training_14b_prequantized.py")
                else:
                    print("⚠️  Job succeeded but output not found yet...")
                
                break
                
            elif state in ["JOB_STATE_FAILED", "JOB_STATE_CANCELLED"]:
                print(f"\n❌ Job {state.lower().replace('job_state_', '')}")
                
                # Try to get error details
                error = latest_job.get("error", {})
                if error:
                    print(f"Error: {error.get('message', 'Unknown error')}")
                
                break
                
            elif state == "JOB_STATE_RUNNING":
                # Check if output is being written
                if check_output_exists():
                    print("  💾 Model is being written...")
        else:
            print(f"\r[{datetime.now().strftime('%H:%M:%S')}] No quantization jobs found...", end="")
        
        # Clear line for next update
        print(" " * 50, end="\r")
        
        try:
            time.sleep(30)
        except KeyboardInterrupt:
            print("\n\nMonitoring stopped.")
            break

if __name__ == "__main__":
    main()