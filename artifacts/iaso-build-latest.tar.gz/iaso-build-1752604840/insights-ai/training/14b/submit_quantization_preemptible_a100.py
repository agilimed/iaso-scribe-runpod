#!/usr/bin/env python3
"""
Submit 14B quantization job with PREEMPTIBLE A100 GPU
Based on successful 7B preemptible A100 configuration
"""

import os
import time
from datetime import datetime
from google.cloud import aiplatform
from google.cloud.aiplatform import CustomJob

PROJECT_ID = "nexuscare-463413"
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = "vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com"
REGION = "asia-southeast1"  # 8 preemptible A100s available

def main():
    print("=== Submitting 14B Quantization with PREEMPTIBLE A100 ===")
    print(f"Region: {REGION}")
    print("GPU: Preemptible A100 (75% cheaper!)")
    print("Based on successful 7B preemptible configuration")
    
    # Initialize Vertex AI
    aiplatform.init(
        project=PROJECT_ID,
        location=REGION,
        staging_bucket=f"gs://{BUCKET_NAME}"
    )
    
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    job_name = f"iasoql-14b-quantization-preemptible-{timestamp}"
    
    # Create custom job with preemptible configuration
    custom_job = CustomJob(
        display_name=job_name,
        worker_pool_specs=[
            {
                "machine_spec": {
                    "machine_type": "a2-highgpu-1g",  # 12 vCPUs, 85GB RAM
                    "accelerator_type": "NVIDIA_TESLA_A100",
                    "accelerator_count": 1,
                },
                "replica_count": 1,
                "disk_spec": {
                    "boot_disk_type": "pd-ssd",
                    "boot_disk_size_gb": 200,
                },
                "container_spec": {
                    "image_uri": f"gcr.io/{PROJECT_ID}/iasoql-14b-quantization:latest",
                    "command": ["python", "quantize_base_model_cloud.py"],
                    "env": [
                        {
                            "name": "OUTPUT_PATH",
                            "value": f"gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized"
                        },
                        {
                            "name": "CUDA_VISIBLE_DEVICES",
                            "value": "0"
                        }
                    ],
                },
            }
        ],
        # Enable preemptible instances - this is the key!
        scheduling={
            "disable_retries": False,
            "restart_job_on_worker_restart": True,
            "max_wait_duration": {"seconds": 86400},  # 24 hours max wait
            "strategy": "ON_DEMAND",  # Will use preemptible if available
        },
        service_account=SERVICE_ACCOUNT,
        base_output_dir=f"gs://{BUCKET_NAME}/quantization-outputs",
    )
    
    # Run the custom job
    print("\nSubmitting job with preemptible A100...")
    custom_job.run(
        timeout=7200,  # 2 hours for quantization
        enable_web_access=True,
        sync=False
    )
    
    # Wait for job to be created
    time.sleep(5)
    
    print(f"\n✅ Job submitted successfully!")
    print(f"Job name: {job_name}")
    print(f"Job state: {custom_job.state}")
    print(f"Dashboard: https://console.cloud.google.com/vertex-ai/locations/{REGION}/training/custom-jobs?project={PROJECT_ID}")
    
    print("\n💰 Cost Estimation:")
    print("- Preemptible A100: ~$1.10/hour (vs $3.67 regular)")
    print("- Expected time: 10-15 minutes")
    print("- Total cost: ~$0.20-$0.30")
    print("- Savings: 75% cheaper than regular A100!")
    
    print("\n⚠️  Note: Job may restart if preempted")
    print("\nNext step after completion:")
    print("python3 submit_training_14b_prequantized.py")

if __name__ == "__main__":
    main()