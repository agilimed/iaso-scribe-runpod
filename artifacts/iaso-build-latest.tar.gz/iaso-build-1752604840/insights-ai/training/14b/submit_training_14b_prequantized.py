#!/usr/bin/env python3
"""
Submit training for pre-quantized 14B model on A100 with FLEX_START
Uses the quantized model from: gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized
"""

import os
from datetime import datetime
from google.cloud import aiplatform

PROJECT_ID = "nexuscare-463413"
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = "vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com"
REGION = "asia-southeast1"  # Using same region for consistency

# Training configuration
DATASET_PATH = "gs://nexuscare-ai-training/datasets/fhir-clickhouse-training-dataset-v8-FINAL.json"
QUANTIZED_MODEL_PATH = "gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized"
OUTPUT_MODEL_NAME = "iasoql-agilimed-healthcare-14b"

def main():
    print("=== Submitting 14B Model Training with Pre-Quantized Base ===")
    print(f"Region: {REGION}")
    print(f"Base Model: {QUANTIZED_MODEL_PATH}")
    print(f"Dataset: {DATASET_PATH}")
    print(f"Output: {OUTPUT_MODEL_NAME}")
    
    # Initialize Vertex AI
    aiplatform.init(
        project=PROJECT_ID,
        location=REGION,
        staging_bucket=f"gs://{BUCKET_NAME}"
    )
    
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    job_name = f"{OUTPUT_MODEL_NAME}-training-{timestamp}"
    
    # Environment variables for training
    env_vars = {
        # Model configuration
        "BASE_MODEL_PATH": QUANTIZED_MODEL_PATH,  # Use pre-quantized model
        "OUTPUT_MODEL_NAME": OUTPUT_MODEL_NAME,
        "OUTPUT_DIR": f"/gcs/{BUCKET_NAME}/models/{OUTPUT_MODEL_NAME}",
        
        # Dataset
        "DATASET_PATH": DATASET_PATH,
        
        # Training hyperparameters optimized for 14B on A100
        "BATCH_SIZE": "1",  # Reduced for 14B model
        "GRADIENT_ACCUMULATION": "16",  # Increased to compensate
        "EPOCHS": "3",
        "LEARNING_RATE": "2e-4",
        "WARMUP_STEPS": "100",
        "SAVE_STEPS": "50",
        "EVAL_STEPS": "50",
        
        # LoRA configuration for 14B
        "LORA_R": "32",  # Reduced from 64 for memory
        "LORA_ALPHA": "64",  # 2x r
        "LORA_DROPOUT": "0.1",
        "TARGET_MODULES": "q_proj,v_proj,k_proj,o_proj,gate_proj,up_proj,down_proj",
        
        # Memory optimizations
        "GRADIENT_CHECKPOINTING": "true",
        "FP16": "true",
        "OPTIM": "paged_adamw_32bit",
        
        # DoRA enhancement
        "USE_DORA": "true",
        
        # System
        "CUDA_VISIBLE_DEVICES": "0",
        "HF_HUB_DISABLE_SYMLINKS": "1",
        "TOKENIZERS_PARALLELISM": "false"
    }
    
    # Create custom training job
    custom_job = aiplatform.CustomContainerTrainingJob(
        display_name=job_name,
        container_uri=f"gcr.io/{PROJECT_ID}/iasoql-14b-trainer:latest",
        command=["python", "train_14b_prequantized.py"],
    )
    
    # Submit with A100 and appropriate configuration
    print("\nSubmitting training job...")
    job = custom_job.run(
        replica_count=1,
        machine_type="a2-highgpu-1g",  # A100 with 40GB VRAM
        accelerator_type="NVIDIA_TESLA_A100",
        accelerator_count=1,
        environment_variables=env_vars,
        service_account=SERVICE_ACCOUNT,
        sync=False,
        enable_web_access=True,
        boot_disk_type="pd-ssd",
        boot_disk_size_gb=500,  # Larger disk for 14B model
        # Use preemptible with retries for cost savings
        scheduling={
            "timeout": "86400s",  # 24 hours
            "restart_job_on_worker_restart": True,
            "max_wait_duration": "86400s",
        }
    )
    
    print(f"\n✅ Training job submitted!")
    print(f"Job name: {job_name}")
    print(f"Dashboard: https://console.cloud.google.com/vertex-ai/locations/{REGION}/training/custom-jobs?project={PROJECT_ID}")
    
    print("\n📊 Training Configuration:")
    print(f"- Pre-quantized 14B model (4-bit)")
    print(f"- Batch size: 1 with gradient accumulation: 16")
    print(f"- LoRA rank: 32 with DoRA enhancement")
    print(f"- Memory optimizations: gradient checkpointing, fp16, paged optimizer")
    
    print("\n💰 Cost Estimation:")
    print(f"- A100 GPU: $3.67/hour")
    print(f"- Expected training time: 12-16 hours")
    print(f"- Total cost: ~$44-59")
    print(f"- Use FLEX_START for preemptible pricing (~$1.10/hour)")
    
    print("\n⏭️  Next Steps:")
    print("1. Monitor training progress")
    print("2. After completion, merge LoRA weights: python3 merge_14b_lora.py")
    print("3. Deploy with vLLM: python3 deploy_14b_vllm.py")

if __name__ == "__main__":
    main()