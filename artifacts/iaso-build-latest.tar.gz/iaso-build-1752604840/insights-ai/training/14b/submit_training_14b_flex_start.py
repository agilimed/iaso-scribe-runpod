#!/usr/bin/env python3
"""
Submit training for pre-quantized 14B model with FLEX_START for preemptible A100
Cost-optimized version using preemptible GPUs
"""

import os
from datetime import datetime
from google.cloud import aiplatform
from google.cloud.aiplatform import CustomJob

PROJECT_ID = "nexuscare-463413"
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = "vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com"
REGION = "asia-southeast1"

# Paths
DATASET_PATH = "gs://nexuscare-ai-training/datasets/fhir-clickhouse-training-dataset-v8-FINAL.json"
QUANTIZED_MODEL_PATH = "gs://nexuscare-ai-training/models/quantized/iasoql-14b-base-quantized"
OUTPUT_MODEL_NAME = "iasoql-agilimed-healthcare-14b"

def main():
    print("=== Submitting 14B Training with FLEX_START (Preemptible A100) ===")
    print(f"Region: {REGION}")
    print(f"Strategy: FLEX_START for 75% cost savings")
    
    # Initialize Vertex AI
    aiplatform.init(
        project=PROJECT_ID,
        location=REGION,
        staging_bucket=f"gs://{BUCKET_NAME}"
    )
    
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    job_name = f"{OUTPUT_MODEL_NAME}-flex-{timestamp}"
    
    # Environment variables
    env_vars = [
        {"name": "BASE_MODEL_PATH", "value": QUANTIZED_MODEL_PATH},
        {"name": "OUTPUT_DIR", "value": f"/gcs/{BUCKET_NAME}/models/{OUTPUT_MODEL_NAME}"},
        {"name": "DATASET_PATH", "value": DATASET_PATH},
        {"name": "BATCH_SIZE", "value": "1"},
        {"name": "GRADIENT_ACCUMULATION", "value": "16"},
        {"name": "EPOCHS", "value": "3"},
        {"name": "LEARNING_RATE", "value": "2e-4"},
        {"name": "LORA_R", "value": "32"},
        {"name": "LORA_ALPHA", "value": "64"},
        {"name": "LORA_DROPOUT", "value": "0.1"},
        {"name": "USE_DORA", "value": "true"},
        {"name": "GRADIENT_CHECKPOINTING", "value": "true"},
        {"name": "FP16", "value": "true"},
        {"name": "TARGET_MODULES", "value": "q_proj,v_proj,k_proj,o_proj,gate_proj,up_proj,down_proj"},
        {"name": "CUDA_VISIBLE_DEVICES", "value": "0"},
    ]
    
    # Create custom job with FLEX_START
    custom_job = CustomJob(
        display_name=job_name,
        worker_pool_specs=[
            {
                "machine_spec": {
                    "machine_type": "a2-highgpu-1g",
                    "accelerator_type": "NVIDIA_TESLA_A100",
                    "accelerator_count": 1,
                },
                "replica_count": 1,
                "disk_spec": {
                    "boot_disk_type": "pd-ssd",
                    "boot_disk_size_gb": 500,
                },
                "container_spec": {
                    "image_uri": f"gcr.io/{PROJECT_ID}/iasoql-14b-trainer:latest",
                    "command": ["python", "train_14b_prequantized.py"],
                    "env": env_vars,
                },
            }
        ],
        # FLEX_START configuration in job spec
        staging_bucket=f"gs://{BUCKET_NAME}",
    )
    
    # Submit with YAML configuration for FLEX_START
    print("\nCreating YAML configuration for FLEX_START...")
    
    # Write YAML config
    yaml_content = f"""workerPoolSpecs:
- machineSpec:
    machineType: a2-highgpu-1g
    acceleratorType: NVIDIA_TESLA_A100
    acceleratorCount: 1
  replicaCount: 1
  diskSpec:
    bootDiskType: pd-ssd
    bootDiskSizeGb: 500
  containerSpec:
    imageUri: gcr.io/{PROJECT_ID}/iasoql-14b-trainer:latest
    command: ["python", "train_14b_prequantized.py"]
    env:
"""
    
    for env in env_vars:
        yaml_content += f"    - name: {env['name']}\n      value: \"{env['value']}\"\n"
    
    yaml_content += f"""scheduling:
  disableRetries: false
  restartJobOnWorkerRestart: true
  maxWaitDuration: 172800s  # 48 hours
  strategy: FLEX_START
serviceAccount: {SERVICE_ACCOUNT}
baseOutputDirectory:
  outputUriPrefix: gs://{BUCKET_NAME}/training-outputs/{OUTPUT_MODEL_NAME}"""
    
    yaml_file = f"training-job-{timestamp}.yaml"
    with open(yaml_file, 'w') as f:
        f.write(yaml_content)
    
    print(f"Created {yaml_file}")
    print(f"\nTo submit the job, run:")
    print(f"gcloud ai custom-jobs create --region={REGION} --project={PROJECT_ID} --config={yaml_file} --display-name={job_name}")
    
    print("\n📊 Configuration Summary:")
    print(f"- Pre-quantized 14B model from: {QUANTIZED_MODEL_PATH}")
    print(f"- Dataset: 52 FHIR ClickHouse queries")
    print(f"- LoRA rank: 32 with DoRA enhancement")
    print(f"- Batch size: 1 × 16 gradient accumulation = 16 effective")
    
    print("\n💰 Cost Estimation with FLEX_START:")
    print(f"- Preemptible A100: ~$1.10/hour (vs $3.67 regular)")
    print(f"- Expected time: 12-16 hours")
    print(f"- Total cost: ~$13-18 (75% savings!)")
    print(f"- Job will start when preemptible A100 is available")

if __name__ == "__main__":
    main()