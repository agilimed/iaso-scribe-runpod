#!/usr/bin/env python3
"""
Submit quantization job to regions with available preemptible T4 GPUs
"""

import os
from datetime import datetime
from google.cloud import aiplatform
import subprocess
import json

PROJECT_ID = "nexuscare-463413"
BUCKET_NAME = "nexuscare-ai-training"
SERVICE_ACCOUNT = f"ai-training@{PROJECT_ID}.iam.gserviceaccount.com"

# Regions to check for T4 availability
REGIONS_TO_CHECK = [
    "us-central1",
    "us-east1", 
    "us-west1",
    "us-west2",
    "us-west4",
    "europe-west1",
    "europe-west2", 
    "europe-west3",
    "europe-west4",
    "asia-east1",
    "asia-northeast1",
    "asia-southeast1",
    "asia-south1",
    "australia-southeast1",
]

def check_gpu_availability(region):
    """Check if T4 GPUs are available in a region"""
    try:
        cmd = [
            "gcloud", "compute", "accelerator-types", "list",
            "--filter", f"name:nvidia-tesla-t4 AND zone:{region}-*",
            "--format", "json",
            "--project", PROJECT_ID
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        accelerators = json.loads(result.stdout)
        
        if accelerators:
            print(f"✅ {region}: T4 GPUs available in {len(accelerators)} zones")
            return True
        else:
            print(f"❌ {region}: No T4 GPUs")
            return False
            
    except Exception as e:
        print(f"⚠️  {region}: Error checking - {str(e)}")
        return False

def submit_job_to_region(region):
    """Submit quantization job to specific region"""
    print(f"\n=== Attempting to submit in {region} ===")
    
    try:
        # Initialize Vertex AI
        aiplatform.init(
            project=PROJECT_ID,
            location=region,
            staging_bucket=f"gs://{BUCKET_NAME}"
        )
        
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        job_name = f"iasoql-14b-quantization-{timestamp}"
        
        # Create custom training job
        custom_job = aiplatform.CustomContainerTrainingJob(
            display_name=job_name,
            container_uri=f"gcr.io/{PROJECT_ID}/iasoql-14b-quantization:latest",
            command=["python", "quantize_base_model_cloud.py"],
        )
        
        # Submit with preemptible configuration
        job = custom_job.run(
            replica_count=1,
            machine_type="n1-highmem-8",
            accelerator_type="NVIDIA_TESLA_T4",
            accelerator_count=1,
            environment_variables={
                "OUTPUT_PATH": f"gs://{BUCKET_NAME}/models/quantized/iasoql-14b-base-quantized",
            },
            service_account=SERVICE_ACCOUNT,
            sync=False,
            enable_web_access=True,
            boot_disk_type="pd-standard",
            boot_disk_size_gb=100,
        )
        
        print(f"✅ Job submitted successfully in {region}!")
        print(f"Job name: {job_name}")
        print(f"Monitor at: https://console.cloud.google.com/vertex-ai/locations/{region}/training/custom-jobs?project={PROJECT_ID}")
        
        # Verify job was created
        print("\nVerifying job submission...")
        subprocess.run([
            "gcloud", "ai", "custom-jobs", "list",
            "--region", region,
            "--limit", "1",
            "--filter", f"displayName:{job_name}",
            "--format", "table(displayName,state,createTime)",
            "--project", PROJECT_ID
        ])
        
        return True
        
    except Exception as e:
        print(f"❌ Failed in {region}: {str(e)}")
        return False

def main():
    print("=== Finding Regions with Available Preemptible T4 GPUs ===")
    print("Checking GPU availability across regions...\n")
    
    # Check GPU availability
    available_regions = []
    for region in REGIONS_TO_CHECK:
        if check_gpu_availability(region):
            available_regions.append(region)
    
    if not available_regions:
        print("\n❌ No regions found with T4 GPUs")
        return
    
    print(f"\n✅ Found {len(available_regions)} regions with T4 GPUs: {', '.join(available_regions)}")
    
    # Try to submit to available regions
    print("\n=== Submitting Quantization Job ===")
    for region in available_regions:
        if submit_job_to_region(region):
            print("\n=== Success! ===")
            print("Job submitted with preemptible T4 GPU")
            print("Estimated time: 10-15 minutes")
            print("\nNext step after completion:")
            print("python3 submit_training_14b_prequantized.py")
            break
    else:
        print("\n❌ Failed to submit in all available regions")

if __name__ == "__main__":
    main()