# IasoQL Integration for Conversational Analytics

## Overview

The conversational analytics module at http://localhost:3000/admin/insights/chat now uses **IasoQL** as its SQL generation engine. IasoQL is our custom-trained model optimized for healthcare FHIR data in ClickHouse.

## Key Features

### 1. Automatic Query Complexity Handling
- Users don't need to specify technical SQL terms like "using CTEs" or "with joins"
- The system automatically detects when complex SQL patterns are needed
- Natural language queries are intelligently analyzed for complexity

### 2. Enhanced Query Analysis
- Semantic understanding of healthcare queries
- Automatic entity extraction (patients, conditions, departments)
- Temporal pattern recognition (trends, time ranges)
- Operation detection (aggregations, comparisons)

### 3. Performance Optimizations
- Query result caching for similar queries
- Reuse of existing metrics when available
- Progressive generation for complex queries
- Token limit handling with intelligent chunking

## Configuration

### Environment Variables
```bash
# IasoQL service endpoint (default shown)
IASOQL_SERVICE_URL=https://iasoql-agilimed-healthcare-kt4atarccq-uc.a.run.app
```

### Service Integration
The service is integrated at multiple levels:
1. **LlamaIndexConversationalService**: Uses IasoQL for SQL generation
2. **EnhancedQueryAnalyzer**: Provides intelligent query analysis
3. **HealthcareRAGEngine**: Leverages Qdrant for semantic search

## Testing

### Run Integration Tests
```bash
# Test the full conversational analytics stack with IasoQL
cd backend
node src/scripts/test-conversational-iasoql.js

# Test enhanced IasoQL features
node src/scripts/test-enhanced-iasoql.js
```

### Test Queries
Try these queries in the chat interface:

**Simple Queries** (automatically handled without CTEs):
- "How many patients do we have?"
- "Show me today's admissions"
- "Count patients by gender"

**Medium Complexity** (system detects need for joins):
- "Show me diabetic patients in cardiology"
- "What's the average length of stay by department?"
- "Find patients with abnormal lab results"

**Complex Queries** (automatic CTE generation):
- "Find diabetic patients who visited emergency more than 3 times last month"
- "Calculate readmission rates for heart failure patients comparing those with and without diabetes"
- "Show me the trend of hospital costs by department over the last 6 months"

## API Endpoints

### Query Processing
```
POST /api/insights/chat/query
{
  "query": "Your natural language question",
  "sessionId": "optional-session-id"
}
```

### Health Check
```
GET /api/insights/chat/health
```

Returns:
```json
{
  "status": "healthy",
  "services": {
    "iasoql": "healthy",
    "llamaIndex": "available",
    "conversationalService": "available"
  },
  "capabilities": [
    "natural_language_query_processing",
    "sql_generation_with_iasoql",
    "intelligent_query_analysis",
    "automatic_cte_generation"
  ]
}
```

## Architecture

```
User Query → Conversational Analytics API
    ↓
LlamaIndexConversationalService
    ↓
EnhancedQueryAnalyzer (if enabled)
    ├── Complexity Detection
    ├── Semantic Analysis
    └── Existing Metric Search
    ↓
IasoQL Service
    ├── Schema Context Injection
    ├── Healthcare-Optimized Generation
    └── Automatic SQL Pattern Selection
    ↓
ClickHouse Execution
    ↓
Results with Insights
```

## Benefits Over Previous SQLCoder

1. **Better Healthcare Understanding**: Trained specifically on FHIR data patterns
2. **No Technical Terms Required**: Users use natural language only
3. **Automatic Optimization**: CTEs, joins, and subqueries added as needed
4. **Performance**: Query caching and metric reuse
5. **Accuracy**: Higher accuracy on healthcare-specific queries

## Troubleshooting

### Common Issues

1. **Authentication Errors**
   - Ensure Google Cloud credentials are configured
   - Check service account permissions

2. **Slow Responses**
   - First query may be slower (cold start)
   - Complex queries take longer but are cached

3. **SQL Errors**
   - Check ClickHouse logs for schema mismatches
   - Verify table names and column availability

### Debug Mode
Enable debug logging:
```bash
DEBUG=iasoql:*,llamaindex:* npm run dev
```

## Future Enhancements

1. **Multi-Turn Reasoning**: Better context retention across queries
2. **Visualization Hints**: Automatic chart type suggestions
3. **Query Explanation**: Natural language explanations of generated SQL
4. **Performance Metrics**: Track and optimize common query patterns