#!/usr/bin/env python3
"""
Debug script to verify dataset structure
"""

import json

# Load the dataset
dataset_path = '../fhir-clickhouse-training-dataset-v8-FINAL.json'

with open(dataset_path, 'r') as f:
    data = json.load(f)

print("Dataset keys:", list(data.keys()))
print("\nMetadata:")
for k, v in data.get('metadata', {}).items():
    if isinstance(v, (str, int, float)):
        print(f"  {k}: {v}")

# Check sql_queries structure
sql_queries = data.get('sql_queries', [])
print(f"\nNumber of sql_queries: {len(sql_queries)}")

if sql_queries:
    print("\nFirst sql_query structure:")
    first_query = sql_queries[0]
    for k, v in first_query.items():
        print(f"  {k}: {v if len(str(v)) < 100 else str(v)[:100] + '...'}")
    
    print("\nField names in sql_queries:")
    print("  Keys:", list(first_query.keys()))

# Check for other potential query locations
for key in data.keys():
    if 'query' in key.lower() or 'sql' in key.lower():
        value = data[key]
        if isinstance(value, list) and value:
            print(f"\nFound list '{key}' with {len(value)} items")
            if isinstance(value[0], dict):
                print(f"  First item keys: {list(value[0].keys())}")