#!/bin/bash

# Run the LoRA merge process on Vertex AI with GPU
# This is needed because merging requires loading the full model

echo "🚀 Running LoRA Merge on Vertex AI Custom Job"

PROJECT_ID="nexuscare-463413"
REGION="us-central1"  # Using US for A100 availability
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
JOB_NAME="iasoql-lora-merge-${TIMESTAMP}"

# Create requirements file
cat > requirements_merge.txt << EOF
torch>=2.0.0
transformers>=4.35.0
peft>=0.5.0
accelerate
google-cloud-storage
safetensors
EOF

# Create the merge job configuration
cat > merge_job_config.yaml << EOF
displayName: ${JOB_NAME}
jobSpec:
  workerPoolSpecs:
  - machineSpec:
      machineType: a2-highgpu-1g
      acceleratorType: NVIDIA_TESLA_A100
      acceleratorCount: 1
    replicaCount: 1
    containerSpec:
      imageUri: pytorch/pytorch:2.0.1-cuda11.7-cudnn8-runtime
      command:
      - bash
      - -c
      - |
        # Install dependencies
        pip install -r requirements_merge.txt
        
        # Run the merge script
        python merge_lora_weights.py
        
        # Upload merged model to GCS
        gsutil -m cp -r ./iasoql-merged-model/* gs://nexuscare-ai-training/models/iasoql-merged-complete/
        
        echo "✅ Merge complete and uploaded to GCS!"
EOF

# Submit the job
echo "📤 Submitting merge job to Vertex AI..."

gcloud ai custom-jobs create \
  --region=${REGION} \
  --display-name="${JOB_NAME}" \
  --config=merge_job_config.yaml \
  --args="--merge-and-upload"

echo ""
echo "✅ Job submitted!"
echo ""
echo "📊 Monitor job at:"
echo "https://console.cloud.google.com/vertex-ai/training/custom-jobs?project=${PROJECT_ID}"
echo ""
echo "⏱️  Estimated time: 20-30 minutes"
echo ""
echo "📂 Output location: gs://nexuscare-ai-training/models/iasoql-merged-complete/"