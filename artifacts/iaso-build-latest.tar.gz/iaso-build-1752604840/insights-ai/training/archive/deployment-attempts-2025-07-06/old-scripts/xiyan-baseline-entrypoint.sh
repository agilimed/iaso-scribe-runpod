#!/bin/bash

# Set environment variables for better debugging
export VLLM_LOGGING_LEVEL=DEBUG
export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:512

# Check shared memory size
echo "Checking shared memory size..."
df -h /dev/shm

# Increase shared memory if possible (this might not work on Cloud Run)
# mount -o remount,size=16G /dev/shm 2>/dev/null || echo "Cannot resize /dev/shm on Cloud Run"

# Try to download model first to avoid timeout during startup
echo "Pre-downloading model if needed..."
python3 -c "from transformers import AutoTokenizer, AutoModelForCausalLM; AutoTokenizer.from_pretrained('XGenerationLab/XiYanSQL-QwenCoder-7B-2504'); print('Model download complete')" || echo "Model already cached"

# Start vLLM with optimized settings for Cloud Run
echo "Starting vLLM server with optimized settings..."
exec python3 -m vllm.entrypoints.openai.api_server \
    --model XGenerationLab/XiYanSQL-QwenCoder-7B-2504 \
    --host 0.0.0.0 \
    --port 8080 \
    --max-model-len 1024 \
    --gpu-memory-utilization 0.85 \
    --api-key token-xiyan-baseline \
    --trust-remote-code \
    --disable-log-requests \
    --served-model-name xiyan-baseline \
    --dtype bfloat16 \
    --enforce-eager \
    --disable-custom-all-reduce