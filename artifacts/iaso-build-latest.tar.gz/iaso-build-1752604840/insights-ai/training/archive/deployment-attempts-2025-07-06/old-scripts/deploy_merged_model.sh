#!/bin/bash

# Deploy merged IASO model to Vertex AI
# This uses a standard vLLM container since LoRA is already merged

echo "🚀 Deploying Merged IASO Model to Vertex AI"

PROJECT_ID="nexuscare-463413"
REGION="asia-southeast1"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

MODEL_NAME="iasoql-merged-healthcare"
MODEL_ID="${MODEL_NAME}_${TIMESTAMP}"
ENDPOINT_NAME="iasoql-healthcare-endpoint"

# Step 1: Upload model to Vertex AI
echo "📤 Uploading merged model to Vertex AI Model Registry..."

# Use standard vLLM container - no LoRA complexity!
gcloud ai models upload \
  --region=${REGION} \
  --display-name="${MODEL_NAME}" \
  --container-image-uri="us-docker.pkg.dev/vertex-ai/vertex-vision-model-garden-dockers/pytorch-vllm-serve:20250130_0916_RC01" \
  --container-args="^;^--model=/model;--port=8080;--host=0.0.0.0;--trust-remote-code;--max-model-len=2048;--dtype=bfloat16;--gpu-memory-utilization=0.9" \
  --container-ports=8080 \
  --container-health-route="/health" \
  --container-predict-route="/v1/completions" \
  --container-env-vars="TRANSFORMERS_CACHE=/tmp,HF_HOME=/tmp" \
  --artifact-uri="gs://nexuscare-ai-training/models/iasoql-merged-complete/" \
  --model-id=${MODEL_ID}

if [ $? -ne 0 ]; then
    echo "❌ Model upload failed"
    exit 1
fi

echo "✅ Model uploaded: ${MODEL_ID}"

# Step 2: Create endpoint
echo "🎯 Creating endpoint..."

gcloud ai endpoints create \
  --region=${REGION} \
  --display-name=${ENDPOINT_NAME} \
  --description="IASO Healthcare SQL Generation - Merged Model"

ENDPOINT_ID=$(gcloud ai endpoints list \
  --region=${REGION} \
  --filter="displayName:${ENDPOINT_NAME}" \
  --format="value(name)" | head -1)

echo "✅ Endpoint created: ${ENDPOINT_ID}"

# Step 3: Deploy model to endpoint
echo "🚀 Deploying model to endpoint..."

# Deploy with T4 GPU (best price/performance for 7B model)
gcloud ai endpoints deploy-model ${ENDPOINT_ID} \
  --region=${REGION} \
  --model=${MODEL_ID} \
  --display-name="${MODEL_NAME}-deployment" \
  --machine-type=n1-highmem-8 \
  --accelerator=count=1,type=nvidia-tesla-t4 \
  --min-replica-count=1 \
  --max-replica-count=2 \
  --enable-autoscaling \
  --enable-access-logging \
  --service-account="vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com" \
  --traffic-split=0=100

echo "✅ Deployment initiated!"

# Save deployment info
cat > deployment_merged_info.json << EOF
{
  "model_id": "${MODEL_ID}",
  "endpoint_id": "${ENDPOINT_ID}",
  "region": "${REGION}",
  "model_type": "merged (base + LoRA)",
  "gpu": "nvidia-tesla-t4",
  "artifact_uri": "gs://nexuscare-ai-training/models/iasoql-merged-complete/",
  "created_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
EOF

echo ""
echo "📝 Deployment info saved to deployment_merged_info.json"
echo ""
echo "⏳ Deployment typically takes 10-15 minutes"
echo ""
echo "📊 To monitor deployment:"
echo "gcloud ai endpoints describe ${ENDPOINT_ID} --region=${REGION}"
echo ""
echo "🧪 Test with:"
echo "python test_vertex_endpoint.py --endpoint-id ${ENDPOINT_ID} --region ${REGION}"
echo ""
echo "💡 Benefits of merged model:"
echo "  ✅ No LoRA loading complexity"
echo "  ✅ Works with standard containers"
echo "  ✅ Faster startup (no adapter download)"
echo "  ✅ Better performance (no LoRA overhead)"