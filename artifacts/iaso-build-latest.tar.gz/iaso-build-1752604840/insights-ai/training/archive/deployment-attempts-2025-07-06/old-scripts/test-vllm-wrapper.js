const http = require('http');
const https = require('https');
const { execSync } = require('child_process');

// Simple wrapper server that handles both Cloud Run and vLLM authentication
const PORT = 8081;
const VLLM_ENDPOINT = 'https://sqlcoder-endpoint-kt4atarccq-uc.a.run.app';
const VLLM_API_KEY = 'token-xiyan-baseline';

async function getCloudRunToken() {
  try {
    const token = execSync(
      'gcloud auth print-identity-token --impersonate-service-account=vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com 2>/dev/null',
      { encoding: 'utf8' }
    ).trim();
    return token;
  } catch (error) {
    console.error('Failed to get Cloud Run token:', error);
    throw error;
  }
}

async function makeRequest(path, method, body) {
  const cloudRunToken = await getCloudRunToken();
  
  return new Promise((resolve, reject) => {
    const url = new URL(path, VLLM_ENDPOINT);
    
    const options = {
      method: method,
      headers: {
        'Authorization': `Bearer ${cloudRunToken}`,
        'Content-Type': 'application/json',
      }
    };

    const req = https.request(url, options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        resolve({
          status: res.statusCode,
          headers: res.headers,
          body: data
        });
      });
    });

    req.on('error', reject);
    
    if (body) {
      // Add the vLLM API key to the request body
      const bodyWithAuth = {
        ...body,
        api_key: VLLM_API_KEY
      };
      req.write(JSON.stringify(bodyWithAuth));
    }
    
    req.end();
  });
}

// Create wrapper server
const server = http.createServer(async (req, res) => {
  console.log(`${req.method} ${req.url}`);
  
  let body = '';
  req.on('data', chunk => body += chunk);
  req.on('end', async () => {
    try {
      const parsedBody = body ? JSON.parse(body) : null;
      
      // Forward the request to vLLM with both authentications
      const response = await makeRequest(req.url, req.method, parsedBody);
      
      // Forward the response
      res.writeHead(response.status, response.headers);
      res.end(response.body);
      
      console.log(`Response: ${response.status}`);
      if (response.status !== 200) {
        console.log('Response body:', response.body);
      }
    } catch (error) {
      console.error('Error:', error);
      res.writeHead(500);
      res.end(JSON.stringify({ error: error.message }));
    }
  });
});

server.listen(PORT, () => {
  console.log(`Wrapper server running on http://localhost:${PORT}`);
  console.log('This wrapper handles both Cloud Run and vLLM authentication');
  console.log('\nTesting the wrapper...\n');
  
  // Run tests
  setTimeout(runTests, 1000);
});

async function runTests() {
  const fetch = (await import('node-fetch')).default;
  
  try {
    // Test 1: Health check
    console.log('1. Testing health endpoint...');
    const healthRes = await fetch(`http://localhost:${PORT}/health`);
    console.log('Health status:', healthRes.status);
    
    // Test 2: Models endpoint
    console.log('\n2. Testing models endpoint...');
    const modelsRes = await fetch(`http://localhost:${PORT}/v1/models`);
    const modelsData = await modelsRes.text();
    console.log('Models status:', modelsRes.status);
    console.log('Models response:', modelsData);
    
    // Test 3: Completion
    console.log('\n3. Testing completion...');
    const completionRes = await fetch(`http://localhost:${PORT}/v1/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'xiyan-baseline',
        prompt: 'SELECT COUNT(*) FROM patients WHERE',
        max_tokens: 30,
        temperature: 0
      })
    });
    const completionData = await completionRes.text();
    console.log('Completion status:', completionRes.status);
    console.log('Completion response:', completionData);
    
    // Try parsing if successful
    if (completionRes.status === 200) {
      try {
        const parsed = JSON.parse(completionData);
        console.log('\nGenerated SQL:', parsed.choices[0].text);
      } catch (e) {
        // Not JSON
      }
    }
    
  } catch (error) {
    console.error('Test error:', error);
  }
}

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('\nShutting down wrapper server...');
  server.close();
  process.exit(0);
});