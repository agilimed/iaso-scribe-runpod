#!/usr/bin/env python3
"""
Verify memory usage for IasoQL training configuration
"""

# LoRA configuration parameters
r = 64  # LoRA rank
num_target_modules = 7  # q_proj, v_proj, k_proj, o_proj, gate_proj, up_proj, down_proj
hidden_size = 4096  # Qwen-7B hidden size

# Calculate LoRA parameters
# Each LoRA adapter has: A matrix (hidden_size × r) + B matrix (r × hidden_size)
lora_params_per_module = (hidden_size * r) + (r * hidden_size)
total_lora_params = lora_params_per_module * num_target_modules

# Convert to millions
total_lora_params_m = total_lora_params / 1_000_000

# Memory calculation
# fp16: 2 bytes per parameter
# Need memory for: parameters + gradients + optimizer states (Adam has 2 states)
bytes_per_param = 2  # fp16
memory_multiplier = 3  # parameters + gradients + optimizer states (simplified)

total_memory_bytes = total_lora_params * bytes_per_param * memory_multiplier
total_memory_gb = total_memory_bytes / (1024**3)

print(f"🔍 IasoQL Training Memory Verification")
print(f"=" * 50)
print(f"LoRA Configuration:")
print(f"  - Rank (r): {r}")
print(f"  - Target modules: {num_target_modules}")
print(f"  - Hidden size: {hidden_size}")
print(f"\nTrainable Parameters:")
print(f"  - LoRA parameters per module: {lora_params_per_module:,}")
print(f"  - Total LoRA parameters: {total_lora_params:,} ({total_lora_params_m:.1f}M)")
print(f"  - Percentage of 7B model: {(total_lora_params / 7_000_000_000) * 100:.2f}%")
print(f"\nMemory Requirements:")
print(f"  - Bytes per parameter: {bytes_per_param} (fp16)")
print(f"  - Memory multiplier: {memory_multiplier}x (params + grads + optimizer)")
print(f"  - Total memory needed: {total_memory_gb:.2f} GB")
print(f"\nA100 GPU Capacity: 40 GB")
print(f"Memory headroom: {40 - total_memory_gb:.2f} GB")
print(f"\n✅ Configuration is {'SAFE' if total_memory_gb < 35 else '⚠️  AT RISK'} for A100 training")

# Additional optimizations applied
print(f"\n🔧 Memory Optimizations:")
print(f"  - Gradient checkpointing: Enabled (trades compute for memory)")
print(f"  - 4-bit quantization: Enabled for base model")
print(f"  - Batch size: 1 (minimal activation memory)")
print(f"  - PYTORCH_CUDA_ALLOC_CONF: expandable_segments:True")
print(f"  - bias='none': Saves memory by not training biases")