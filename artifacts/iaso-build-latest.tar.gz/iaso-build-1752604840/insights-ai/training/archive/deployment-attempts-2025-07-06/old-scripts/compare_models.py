#!/usr/bin/env python3
"""
Compare baseline XiYanSQL vs IasoQL fine-tuned model performance
"""
import json
import time
from google.auth import default
from google.auth.transport.requests import Request
import requests

# Test queries for FHIR healthcare scenarios
TEST_QUERIES = [
    {
        "description": "Count all patients",
        "prompt": "Count all patients in the FHIR database"
    },
    {
        "description": "Diabetic patients",
        "prompt": "Show me all patients with diabetes from the FHIR resources"
    },
    {
        "description": "Recent encounters",
        "prompt": "Find all encounters from the last 30 days"
    },
    {
        "description": "Blood pressure observations",
        "prompt": "Get the latest blood pressure readings for all patients"
    },
    {
        "description": "Active medications",
        "prompt": "List all active medication requests"
    },
    {
        "description": "Patient demographics",
        "prompt": "Show patient names, birth dates, and gender"
    },
    {
        "description": "Lab results",
        "prompt": "Find all lab results with abnormal values"
    },
    {
        "description": "Appointments today",
        "prompt": "Show all appointments scheduled for today"
    }
]

def get_auth_token(audience):
    """Get Google Cloud identity token"""
    credentials, project = default()
    auth_req = Request()
    credentials.refresh(auth_req)
    
    # Get identity token for the specific audience
    from google.oauth2 import service_account
    from google.auth.transport.requests import AuthorizedSession
    from google.auth import impersonated_credentials
    
    target_scopes = ['https://www.googleapis.com/auth/cloud-platform']
    
    # Use impersonated credentials
    source_credentials, project = default()
    target_principal = 'vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com'
    
    impersonated_creds = impersonated_credentials.Credentials(
        source_credentials=source_credentials,
        target_principal=target_principal,
        target_scopes=target_scopes
    )
    
    # Get ID token
    from google.auth import compute_engine
    from google.oauth2 import id_token
    
    request = Request()
    token = id_token.fetch_id_token(request, audience, credentials=impersonated_creds)
    return token

def query_model(endpoint_url, token, prompt, model_name):
    """Query a model endpoint"""
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json'
    }
    
    # Build the full prompt with context
    full_prompt = f"""You are an expert SQL assistant for healthcare data stored in ClickHouse.
The database contains FHIR R4 resources in a table called 'fhir_current'.
Each row has:
- id: unique identifier
- resource_type: FHIR resource type (Patient, Observation, Encounter, etc.)
- resource: full FHIR resource as JSON
- version_id: version number
- last_updated: timestamp

Use JSONExtract functions to query nested JSON fields.

Question: {prompt}

Generate the ClickHouse SQL query:"""
    
    data = {
        'model': model_name,
        'prompt': full_prompt,
        'max_tokens': 200,
        'temperature': 0,
        'stop': ['\n\n', 'Question:', 'Note:']
    }
    
    start_time = time.time()
    response = requests.post(
        f'{endpoint_url}/v1/completions',
        headers=headers,
        json=data,
        timeout=30
    )
    elapsed = time.time() - start_time
    
    if response.status_code == 200:
        result = response.json()
        sql = result['choices'][0]['text'].strip()
        return {
            'success': True,
            'sql': sql,
            'elapsed': elapsed
        }
    else:
        return {
            'success': False,
            'error': f'{response.status_code}: {response.text}',
            'elapsed': elapsed
        }

def main():
    print("🔬 Comparing Baseline XiYanSQL vs IasoQL Fine-tuned Model\n")
    
    baseline_url = 'https://sqlcoder-endpoint-kt4atarccq-uc.a.run.app'
    iasoql_url = 'https://iasoql-endpoint-kt4atarccq-uc.a.run.app'  # Will be available after deployment
    
    # Get auth tokens
    print("🔐 Getting authentication tokens...")
    baseline_token = get_auth_token(baseline_url)
    iasoql_token = get_auth_token(iasoql_url)
    
    results = []
    
    for query in TEST_QUERIES:
        print(f"\n📝 Test: {query['description']}")
        print(f"   Query: {query['prompt']}")
        
        # Test baseline
        print("   🔵 Baseline XiYanSQL:")
        baseline_result = query_model(baseline_url, baseline_token, query['prompt'], 'xiyan-baseline')
        if baseline_result['success']:
            print(f"   SQL: {baseline_result['sql']}")
            print(f"   Time: {baseline_result['elapsed']:.2f}s")
        else:
            print(f"   Error: {baseline_result['error']}")
        
        # Test IasoQL
        print("   🟢 IasoQL Healthcare:")
        iasoql_result = query_model(iasoql_url, iasoql_token, query['prompt'], 'iasoql-healthcare')
        if iasoql_result['success']:
            print(f"   SQL: {iasoql_result['sql']}")
            print(f"   Time: {iasoql_result['elapsed']:.2f}s")
        else:
            print(f"   Error: {iasoql_result['error']}")
        
        results.append({
            'query': query,
            'baseline': baseline_result,
            'iasoql': iasoql_result
        })
    
    # Summary
    print("\n" + "="*60)
    print("📊 SUMMARY")
    print("="*60)
    
    baseline_success = sum(1 for r in results if r['baseline']['success'])
    iasoql_success = sum(1 for r in results if r['iasoql']['success'])
    
    print(f"Baseline Success Rate: {baseline_success}/{len(results)} ({baseline_success/len(results)*100:.0f}%)")
    print(f"IasoQL Success Rate: {iasoql_success}/{len(results)} ({iasoql_success/len(results)*100:.0f}%)")
    
    # Save results
    with open('comparison_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\n💾 Detailed results saved to comparison_results.json")

if __name__ == '__main__':
    main()