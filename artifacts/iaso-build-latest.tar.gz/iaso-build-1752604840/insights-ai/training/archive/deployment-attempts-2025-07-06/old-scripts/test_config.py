#!/usr/bin/env python3
"""
Test training configuration locally to catch issues before cloud deployment
"""

import os
import sys
import tempfile
from unittest.mock import patch, MagicMock

# Mock heavy dependencies to test just the configuration
sys.modules['torch'] = MagicMock()
sys.modules['transformers'] = MagicMock()
sys.modules['datasets'] = MagicMock()
sys.modules['peft'] = MagicMock()
sys.modules['wandb'] = MagicMock()
sys.modules['google.cloud.storage'] = MagicMock()

# Now import our training script
from train_xiyan_sql import IasoQLTrainer

def test_training_arguments():
    """Test that TrainingArguments can be created without errors"""
    print("🧪 Testing TrainingArguments configuration...")
    
    # Mock config
    config = {
        'output_dir': '/tmp/test_output',
        'batch_size': 2,
        'gradient_accumulation': 4,
        'epochs': 1,  # Short for testing
        'learning_rate': 2e-4,
        'wandb_project': 'test',
        'wandb_entity': 'test'
    }
    
    try:
        # Create trainer instance
        trainer = IasoQLTrainer(config)
        
        # Test setup_training_args method
        training_args = trainer.setup_training_args()
        
        print("✅ TrainingArguments created successfully!")
        print(f"  - Output dir: {training_args.output_dir}")
        print(f"  - Batch size: {training_args.per_device_train_batch_size}")
        print(f"  - Load best model: {training_args.load_best_model_at_end}")
        print(f"  - Save steps: {training_args.save_steps}")
        
        return True
        
    except Exception as e:
        print(f"❌ TrainingArguments failed: {e}")
        return False

def test_dataset_format():
    """Test dataset loading and formatting"""
    print("\n🧪 Testing dataset format...")
    
    # Create a small test dataset
    test_data = {
        "training_data": {
            "sql_queries": [
                {
                    "nl_query": "Show me all patients",
                    "sql": "SELECT * FROM fhir_current WHERE resourceType = 'Patient'",
                    "test_status": "PASSED"
                },
                {
                    "nl_query": "Count encounters",
                    "sql": "SELECT COUNT(*) FROM fhir_current WHERE resourceType = 'Encounter'", 
                    "test_status": "PASSED"
                }
            ]
        }
    }
    
    try:
        import json
        
        # Write test dataset
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(test_data, f)
            test_file = f.name
        
        # Mock the trainer
        config = {'output_dir': '/tmp/test'}
        trainer = IasoQLTrainer(config)
        
        # Test dataset loading
        dataset = trainer.load_and_format_dataset(test_file)
        
        print(f"✅ Dataset loaded successfully!")
        print(f"  - Examples: {len(dataset)}")
        print(f"  - First example keys: {list(dataset[0].keys())}")
        
        # Cleanup
        os.unlink(test_file)
        return True
        
    except Exception as e:
        print(f"❌ Dataset loading failed: {e}")
        return False

def main():
    """Run all tests"""
    print("🚀 Testing IasoQL Training Configuration Locally")
    print("=" * 50)
    
    # Set environment variables for testing
    os.environ['FORCE_CPU_TRAINING'] = 'true'
    os.environ['WANDB_MODE'] = 'disabled'
    
    tests = [
        test_training_arguments,
        test_dataset_format
    ]
    
    passed = 0
    for test in tests:
        if test():
            passed += 1
    
    print(f"\n📊 Results: {passed}/{len(tests)} tests passed")
    
    if passed == len(tests):
        print("🎉 All tests passed! Training configuration should work.")
        return True
    else:
        print("⚠️ Some tests failed. Fix issues before deploying.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)