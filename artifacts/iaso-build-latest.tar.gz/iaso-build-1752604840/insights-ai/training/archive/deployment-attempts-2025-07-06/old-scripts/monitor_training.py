#!/usr/bin/env python3
"""
Monitor XiYanSQL-QwenCoder-7B-2504 training job on Vertex AI

This script provides real-time monitoring of the training job including:
- Job status and progress
- Resource utilization
- Cost estimation
- Training metrics from Weights & Biases
"""

import os
import time
import sys
from datetime import datetime, timedelta
from google.cloud import aiplatform
import requests
import json

def check_training_status(project_id: str, location: str, job_name: str = None):
    """Check status of training jobs"""
    
    aiplatform.init(project=project_id, location=location)
    
    if job_name:
        # Check specific job
        try:
            job = aiplatform.CustomTrainingJob.get(job_name)
            return {
                'name': job.display_name,
                'state': job.state,
                'create_time': job.create_time,
                'start_time': job.start_time,
                'end_time': job.end_time,
                'resource_name': job.resource_name
            }
        except Exception as e:
            return {'error': str(e)}
    else:
        # List recent jobs
        jobs = aiplatform.CustomTrainingJob.list(
            filter='display_name="xiyan-sql-nexuscare-training*"',
            order_by='create_time desc'
        )
        
        return [{
            'name': job.display_name,
            'state': job.state,
            'create_time': job.create_time,
            'resource_name': job.resource_name
        } for job in jobs[:5]]

def estimate_cost(start_time: datetime, current_time: datetime = None):
    """Estimate training cost based on runtime"""
    
    if current_time is None:
        current_time = datetime.now()
    
    runtime_hours = (current_time - start_time).total_seconds() / 3600
    
    # Cost breakdown
    costs = {
        'a10g_gpu': runtime_hours * 1.28,  # A10G GPU cost
        'n1_standard_8': runtime_hours * 0.38,  # Compute cost
        'storage': runtime_hours * 0.02,  # Storage cost
        'network': runtime_hours * 0.01   # Network cost
    }
    
    total_cost = sum(costs.values())
    
    return {
        'runtime_hours': round(runtime_hours, 2),
        'costs': {k: round(v, 2) for k, v in costs.items()},
        'total_cost': round(total_cost, 2),
        'estimated_completion_cost': round(total_cost * (12 / runtime_hours) if runtime_hours > 0 else 20.0, 2)
    }

def check_wandb_metrics(project_name: str = 'nexuscare-sql-training'):
    """Check training metrics from Weights & Biases"""
    
    # Note: This would require wandb API key and proper setup
    # For now, return placeholder structure
    return {
        'note': 'Configure WANDB_API_KEY to see real metrics',
        'metrics': {
            'train_loss': 'N/A',
            'learning_rate': 'N/A', 
            'step': 'N/A',
            'epoch': 'N/A'
        }
    }

def monitor_training(project_id: str = 'nexuscare-463413', location: str = 'us-central1', 
                    job_name: str = None, refresh_interval: int = 30):
    """Continuously monitor training job"""
    
    print(f"🚀 Monitoring XiYanSQL-QwenCoder-7B-2504 Training")
    print(f"Project: {project_id}")
    print(f"Location: {location}")
    print(f"Refresh interval: {refresh_interval}s")
    print("=" * 60)
    
    while True:
        try:
            # Clear screen (works on most terminals)
            os.system('clear' if os.name == 'posix' else 'cls')
            
            print(f"🚀 XiYanSQL Training Monitor - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print("=" * 60)
            
            # Get job status
            status = check_training_status(project_id, location, job_name)
            
            if isinstance(status, list):
                print("📋 Recent Training Jobs:")
                for job in status:
                    print(f"  • {job['name']}: {job['state']}")
                    if job['state'] == 'JOB_STATE_RUNNING':
                        job_name = job['resource_name']  # Use this for detailed monitoring
                print()
            else:
                if 'error' in status:
                    print(f"❌ Error: {status['error']}")
                else:
                    print(f"📊 Job Status: {status['name']}")
                    print(f"   State: {status['state']}")
                    print(f"   Created: {status['create_time']}")
                    
                    if status['start_time']:
                        print(f"   Started: {status['start_time']}")
                        
                        # Calculate cost
                        start_time = datetime.fromisoformat(str(status['start_time']).replace('+00:00', ''))
                        cost_info = estimate_cost(start_time)
                        
                        print(f"\n💰 Cost Information:")
                        print(f"   Runtime: {cost_info['runtime_hours']} hours")
                        print(f"   Current cost: ${cost_info['total_cost']}")
                        print(f"   Estimated total: ${cost_info['estimated_completion_cost']}")
                    
                    if status['end_time']:
                        print(f"   Completed: {status['end_time']}")
                        print("✅ Training job completed!")
                        break
            
            # Check Weights & Biases metrics
            wandb_metrics = check_wandb_metrics()
            print(f"\n📈 Training Metrics:")
            for key, value in wandb_metrics['metrics'].items():
                print(f"   {key}: {value}")
            
            if wandb_metrics.get('note'):
                print(f"   Note: {wandb_metrics['note']}")
            
            print(f"\n🔄 Next update in {refresh_interval}s (Ctrl+C to exit)")
            print("=" * 60)
            
            time.sleep(refresh_interval)
            
        except KeyboardInterrupt:
            print("\n👋 Monitoring stopped by user")
            break
        except Exception as e:
            print(f"\n❌ Error during monitoring: {e}")
            time.sleep(refresh_interval)

def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Monitor XiYanSQL training on Vertex AI')
    parser.add_argument('--project', default='nexuscare-463413', help='GCP project ID')
    parser.add_argument('--location', default='us-central1', help='GCP location')
    parser.add_argument('--job-name', help='Specific job name to monitor')
    parser.add_argument('--interval', type=int, default=30, help='Refresh interval in seconds')
    parser.add_argument('--action', choices=['monitor', 'status'], default='monitor')
    
    args = parser.parse_args()
    
    if args.action == 'status':
        # One-time status check
        status = check_training_status(args.project, args.location, args.job_name)
        print(json.dumps(status, indent=2, default=str))
    else:
        # Continuous monitoring
        monitor_training(args.project, args.location, args.job_name, args.interval)

if __name__ == "__main__":
    main()