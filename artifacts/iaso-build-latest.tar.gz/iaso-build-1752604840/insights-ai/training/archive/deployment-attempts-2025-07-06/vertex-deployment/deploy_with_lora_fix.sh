#!/bin/bash

# Deploy IASO with LoRA adapter properly configured

echo "🚀 Deploying IASO with LoRA adapter fix"

PROJECT_ID="nexuscare-463413"
REGION="asia-southeast1"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Step 1: Create a custom container that includes LoRA adapter
echo "📦 Creating custom container with LoRA adapter..."

cat > Dockerfile.lora << 'EOF'
# Use vLLM base image
FROM vllm/vllm-openai:v0.6.4

# Install GCS support
RUN pip install google-cloud-storage

# Create directories
RUN mkdir -p /models/iasoql /app

# Create startup script that downloads LoRA and starts vLLM
RUN cat > /app/start_server.sh << 'SCRIPT'
#!/bin/bash

echo "📁 Downloading LoRA adapter from GCS..."
gsutil -m cp -r gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized/* /models/iasoql/

echo "✅ LoRA files:"
ls -la /models/iasoql/

echo "🚀 Starting vLLM server with LoRA..."
python -m vllm.entrypoints.openai.api_server \
    --model XGenerationLab/XiYanSQL-QwenCoder-7B-2504 \
    --enable-lora \
    --lora-modules iasoql=/models/iasoql \
    --host 0.0.0.0 \
    --port 8080 \
    --max-model-len 2048 \
    --gpu-memory-utilization 0.9 \
    --trust-remote-code \
    --served-model-name iasoql-healthcare \
    --download-dir /tmp/model-cache
SCRIPT

RUN chmod +x /app/start_server.sh

EXPOSE 8080
ENTRYPOINT ["/app/start_server.sh"]
EOF

# Build the container
IMAGE_URI="gcr.io/${PROJECT_ID}/iasoql-lora-vertex:${TIMESTAMP}"

echo "🏗️ Building container..."
gcloud builds submit --tag ${IMAGE_URI} --timeout=20m .

echo "✅ Container built: ${IMAGE_URI}"

# Step 2: Upload model with custom container
MODEL_ID="iasoql_lora_${TIMESTAMP}"

echo "📤 Uploading model to Vertex AI..."

gcloud ai models upload \
  --region=${REGION} \
  --display-name="iasoql-healthcare-lora" \
  --container-image-uri=${IMAGE_URI} \
  --container-health-route="/health" \
  --container-predict-route="/v1/completions" \
  --container-ports=8080 \
  --model-id=${MODEL_ID}

echo "✅ Model uploaded: ${MODEL_ID}"

# Step 3: Create new endpoint
ENDPOINT_NAME="iasoql-lora-endpoint"

echo "🎯 Creating endpoint..."

gcloud ai endpoints create \
  --region=${REGION} \
  --display-name=${ENDPOINT_NAME}

ENDPOINT_ID=$(gcloud ai endpoints list \
  --region=${REGION} \
  --filter="displayName:${ENDPOINT_NAME}" \
  --format="value(name)" | head -1)

echo "✅ Endpoint created: ${ENDPOINT_ID}"

# Step 4: Deploy model
echo "🚀 Deploying model to endpoint..."

gcloud ai endpoints deploy-model ${ENDPOINT_ID} \
  --region=${REGION} \
  --model=${MODEL_ID} \
  --display-name="iasoql-lora-deployment" \
  --machine-type=n1-highmem-8 \
  --accelerator=count=1,type=nvidia-tesla-t4 \
  --min-replica-count=1 \
  --max-replica-count=1 \
  --enable-access-logging \
  --service-account="vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com" \
  --traffic-split=0=100

echo "✅ Deployment initiated!"

# Save info
cat > lora_deployment_info.json << EOF
{
  "model_id": "${MODEL_ID}",
  "endpoint_id": "${ENDPOINT_ID}",
  "container_image": "${IMAGE_URI}",
  "region": "${REGION}",
  "timestamp": "${TIMESTAMP}"
}
EOF

echo "📝 Deployment info saved to lora_deployment_info.json"