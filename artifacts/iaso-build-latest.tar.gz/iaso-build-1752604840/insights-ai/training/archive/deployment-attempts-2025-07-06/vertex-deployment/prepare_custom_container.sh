#!/bin/bash

# Prepare custom container to avoid Hugging Face rate limits

echo "🔧 Preparing custom container for IASO deployment"

# Create Dockerfile that pre-caches the model
cat > Dockerfile.vertex << 'EOF'
FROM us-docker.pkg.dev/vertex-ai/prediction/vllm-gpu.0-6-1:latest

# Install additional dependencies
RUN pip install google-cloud-storage

# Pre-download the base model to avoid rate limits
RUN python3 -c "
from huggingface_hub import snapshot_download
import os
os.makedirs('/models/base', exist_ok=True)
snapshot_download(
    'XGenerationLab/XiYanSQL-QwenCoder-7B-2504',
    local_dir='/models/base',
    local_dir_use_symlinks=False
)
print('✅ Base model downloaded')
"

# Create entrypoint script
RUN cat > /entrypoint.sh << 'SCRIPT'
#!/bin/bash
echo "🚀 Starting IASO with pre-cached model"

# Download LoRA adapter from GCS
echo "📁 Downloading LoRA adapter..."
mkdir -p /models/iasoql
gsutil -m cp -r gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized/* /models/iasoql/

echo "✅ LoRA adapter ready"
ls -la /models/iasoql/

# Start vLLM with local model path
exec python3 -m vllm.entrypoints.openai.api_server \
    --model /models/base \
    --enable-lora \
    --lora-modules iasoql=/models/iasoql \
    --host 0.0.0.0 \
    --port 8080 \
    --max-model-len 2048 \
    --gpu-memory-utilization 0.9 \
    --trust-remote-code \
    --served-model-name iasoql-healthcare \
    --dtype bfloat16
SCRIPT

RUN chmod +x /entrypoint.sh

EXPOSE 8080
ENTRYPOINT ["/entrypoint.sh"]
EOF

# Build and push the container
IMAGE_URI="gcr.io/nexuscare-463413/iasoql-vertex:latest"

echo "🏗️ Building custom container..."
gcloud builds submit --tag ${IMAGE_URI} .

echo "✅ Custom container built and pushed to: ${IMAGE_URI}"
echo ""
echo "📝 Next steps:"
echo "1. Use this container URI in Vertex AI deployment: ${IMAGE_URI}"
echo "2. This avoids Hugging Face rate limits by pre-caching the model"