#!/bin/bash

# Deploy IASO to Vertex AI with preemptible GPU

echo "🚀 Deploying IASO to Vertex AI"

# Configuration
PROJECT_ID="nexuscare-463413"
REGION="asia-southeast1"  # Has T4 GPUs available
MODEL_NAME="iasoql-healthcare"
ENDPOINT_NAME="iasoql-endpoint"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Step 1: Upload model to Model Registry
echo "📦 Uploading model to Vertex AI Model Registry..."

gcloud ai models upload \
  --region=${REGION} \
  --display-name=${MODEL_NAME} \
  --container-image-uri="us-docker.pkg.dev/vertex-ai/prediction/vllm-gpu.0-6-1:latest" \
  --container-env-vars="MODEL_NAME=XGenerationLab/XiYanSQL-QwenCoder-7B-2504" \
  --container-env-vars="ENABLE_LORA=true" \
  --container-env-vars="LORA_MODULES=iasoql=gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized/" \
  --container-env-vars="MAX_MODEL_LEN=2048" \
  --container-env-vars="GPU_MEMORY_UTILIZATION=0.9" \
  --container-env-vars="TRUST_REMOTE_CODE=true" \
  --container-health-route="/health" \
  --container-predict-route="/v1/completions" \
  --container-ports=8080 \
  --model-id=${MODEL_NAME}_${TIMESTAMP}

# Step 2: Create endpoint
echo "🎯 Creating endpoint..."

gcloud ai endpoints create \
  --region=${REGION} \
  --display-name=${ENDPOINT_NAME}

# Get endpoint ID
ENDPOINT_ID=$(gcloud ai endpoints list \
  --region=${REGION} \
  --filter="display_name=${ENDPOINT_NAME}" \
  --format="value(name)" | head -1)

echo "Endpoint ID: ${ENDPOINT_ID}"

# Step 3: Deploy model to endpoint with preemptible T4
echo "🚀 Deploying model to endpoint with preemptible T4 GPU..."

gcloud ai endpoints deploy-model ${ENDPOINT_ID} \
  --region=${REGION} \
  --model=${MODEL_NAME}_${TIMESTAMP} \
  --display-name=${MODEL_NAME}-deployment \
  --machine-type=n1-standard-8 \
  --accelerator=type=nvidia-tesla-t4,count=1 \
  --min-replica-count=0 \
  --max-replica-count=1 \
  --enable-spot \
  --traffic-split=0=100

echo "✅ Deployment complete!"
echo ""
echo "📊 Deployment Details:"
echo "  Region: ${REGION}"
echo "  GPU: NVIDIA Tesla T4 (Preemptible)"
echo "  Endpoint: ${ENDPOINT_ID}"
echo ""
echo "🧪 Test the endpoint:"
echo "curl -X POST \\
  https://${REGION}-aiplatform.googleapis.com/v1/projects/${PROJECT_ID}/locations/${REGION}/endpoints/${ENDPOINT_ID}:predict \\
  -H 'Authorization: Bearer \$(gcloud auth print-access-token)' \\
  -H 'Content-Type: application/json' \\
  -d '{
    \"instances\": [{
      \"prompt\": \"-- ClickHouse SQL to count active patients\\nSELECT\",
      \"max_tokens\": 200,
      \"temperature\": 0
    }]
  }'"