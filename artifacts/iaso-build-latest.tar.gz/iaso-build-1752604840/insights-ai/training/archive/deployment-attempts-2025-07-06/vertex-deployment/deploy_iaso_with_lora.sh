#!/bin/bash

# Deploy IASO with LoRA adapter - Complete Solution

echo "🚀 Deploying IASO with LoRA adapter (Complete Solution)"

PROJECT_ID="nexuscare-463413"
REGION="asia-southeast1"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Step 1: Create proper Dockerfile for LoRA support
echo "📝 Creating Dockerfile with LoRA support..."

cat > Dockerfile << 'EOF'
# Use vLLM base image that supports LoRA
FROM vllm/vllm-openai:v0.6.4

# Install required dependencies
RUN pip install google-cloud-storage

# Create directories
RUN mkdir -p /models/iasoql /app

# Create entrypoint script
COPY entrypoint.sh /app/entrypoint.sh
RUN chmod +x /app/entrypoint.sh

EXPOSE 8080
ENTRYPOINT ["/app/entrypoint.sh"]
EOF

# Step 2: Create entrypoint script
echo "📝 Creating entrypoint script..."

cat > entrypoint.sh << 'EOF'
#!/bin/bash

echo "🚀 IASO Healthcare Model Starting..."
echo "📁 Downloading LoRA adapter from GCS..."

# Download LoRA adapter files
gsutil -m cp gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized/adapter_config.json /models/iasoql/
gsutil -m cp gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized/adapter_model.safetensors /models/iasoql/

echo "✅ LoRA adapter downloaded:"
ls -la /models/iasoql/

echo "🔧 Starting vLLM with LoRA adapter..."

# Start vLLM with LoRA support
exec python -m vllm.entrypoints.openai.api_server \
    --model XGenerationLab/XiYanSQL-QwenCoder-7B-2504 \
    --enable-lora \
    --lora-modules iasoql=/models/iasoql \
    --host 0.0.0.0 \
    --port 8080 \
    --max-model-len 2048 \
    --gpu-memory-utilization 0.9 \
    --trust-remote-code \
    --served-model-name iasoql-healthcare \
    --download-dir /tmp/model-cache \
    --dtype bfloat16
EOF

chmod +x entrypoint.sh

# Step 3: Build container
IMAGE_URI="gcr.io/${PROJECT_ID}/iasoql-vertex-lora:${TIMESTAMP}"

echo "🏗️ Building container image..."
gcloud builds submit . --tag ${IMAGE_URI} --timeout=30m

if [ $? -ne 0 ]; then
    echo "❌ Container build failed"
    exit 1
fi

echo "✅ Container built: ${IMAGE_URI}"

# Step 4: Upload model to Vertex AI
MODEL_ID="iasoql_with_lora_${TIMESTAMP}"

echo "📤 Uploading model to Vertex AI..."

gcloud ai models upload \
  --region=${REGION} \
  --display-name="iasoql-healthcare-with-lora" \
  --container-image-uri=${IMAGE_URI} \
  --container-health-route="/health" \
  --container-predict-route="/v1/completions" \
  --container-ports=8080 \
  --container-env-vars="TRANSFORMERS_CACHE=/tmp/transformers" \
  --model-id=${MODEL_ID}

if [ $? -ne 0 ]; then
    echo "❌ Model upload failed"
    exit 1
fi

echo "✅ Model uploaded: ${MODEL_ID}"

# Step 5: Deploy to endpoint
echo "🚀 Deploying model to endpoint..."

# Use the existing LoRA endpoint we created
ENDPOINT_ID="5266867405233061888"

gcloud ai endpoints deploy-model ${ENDPOINT_ID} \
  --region=${REGION} \
  --model=${MODEL_ID} \
  --display-name="iasoql-with-lora-deployment" \
  --machine-type=n1-highmem-8 \
  --accelerator=count=1,type=nvidia-tesla-t4 \
  --min-replica-count=1 \
  --max-replica-count=1 \
  --enable-access-logging \
  --service-account="vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com" \
  --traffic-split=0=100

echo "✅ Deployment initiated!"

# Save deployment info
cat > deployment_info_lora.json << EOF
{
  "model_id": "${MODEL_ID}",
  "endpoint_id": "${ENDPOINT_ID}",
  "container_image": "${IMAGE_URI}",
  "region": "${REGION}",
  "gpu": "nvidia-tesla-t4",
  "lora_path": "gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized/",
  "timestamp": "${TIMESTAMP}"
}
EOF

echo ""
echo "📝 Deployment info saved to deployment_info_lora.json"
echo ""
echo "⏳ Deployment typically takes 10-15 minutes to complete"
echo ""
echo "📊 Monitor deployment:"
echo "gcloud ai endpoints describe ${ENDPOINT_ID} --region=${REGION}"
echo ""
echo "🧪 Test command will be:"
echo "python test_vertex_endpoint.py --endpoint-id ${ENDPOINT_ID} --region ${REGION}"