#!/bin/bash

# Deploy IASO to Vertex AI following official documentation
# Based on: https://cloud.google.com/vertex-ai/generative-ai/docs/open-models/vllm/use-vllm

echo "🚀 Deploying IASO to Vertex AI (Official Method)"

# Configuration
PROJECT_ID="nexuscare-463413"
REGION="asia-southeast1"
MODEL_NAME="iasoql-healthcare"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Use the official vLLM container from Model Garden
CONTAINER_URI="us-docker.pkg.dev/vertex-ai/vertex-vision-model-garden-dockers/pytorch-vllm-serve:20250130_0916_RC01"

echo "📦 Using official vLLM container: ${CONTAINER_URI}"

# Step 1: Create a custom serving container that downloads LoRA at startup
echo "🔧 Creating custom entrypoint script..."

cat > custom_entrypoint.py << 'EOF'
#!/usr/bin/env python3
import os
import subprocess
import sys

def download_lora_adapter():
    """Download LoRA adapter from GCS"""
    print("📁 Downloading LoRA adapter from GCS...")
    
    os.makedirs("/models/iasoql", exist_ok=True)
    
    # Use gsutil to download
    cmd = [
        "gsutil", "-m", "cp", "-r",
        "gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized/*",
        "/models/iasoql/"
    ]
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"❌ Failed to download LoRA adapter: {result.stderr}")
        sys.exit(1)
    
    print("✅ LoRA adapter downloaded successfully")
    
    # List files
    subprocess.run(["ls", "-la", "/models/iasoql/"])

def start_vllm_server():
    """Start vLLM server with LoRA"""
    print("🚀 Starting vLLM server...")
    
    cmd = [
        "python", "-m", "vllm.entrypoints.openai.api_server",
        "--model", "XGenerationLab/XiYanSQL-QwenCoder-7B-2504",
        "--enable-lora",
        "--lora-modules", "iasoql=/models/iasoql",
        "--host", "0.0.0.0",
        "--port", "8080",
        "--max-model-len", "2048",
        "--gpu-memory-utilization", "0.9",
        "--trust-remote-code",
        "--served-model-name", "iasoql-healthcare",
        "--dtype", "bfloat16"
    ]
    
    # Start the server
    subprocess.run(cmd)

if __name__ == "__main__":
    download_lora_adapter()
    start_vllm_server()
EOF

# Step 2: Upload model to Vertex AI
echo "📤 Uploading model to Vertex AI..."

# First, let's create a custom container that properly handles LoRA
cat > Dockerfile.vertex << 'EOF'
FROM us-docker.pkg.dev/vertex-ai/vertex-vision-model-garden-dockers/pytorch-vllm-serve:20250130_0916_RC01

# Copy custom entrypoint
COPY custom_entrypoint.py /app/custom_entrypoint.py
RUN chmod +x /app/custom_entrypoint.py

# Set custom entrypoint
ENTRYPOINT ["python", "/app/custom_entrypoint.py"]
EOF

# Build and push custom container
CUSTOM_IMAGE="gcr.io/${PROJECT_ID}/iasoql-vllm-vertex:${TIMESTAMP}"

echo "🏗️ Building custom container..."
gcloud builds submit --tag ${CUSTOM_IMAGE} .

# Upload model with custom container
MODEL_ID="${MODEL_NAME}_${TIMESTAMP}"

gcloud ai models upload \
  --region=${REGION} \
  --display-name="${MODEL_NAME}" \
  --container-image-uri=${CUSTOM_IMAGE} \
  --container-health-route="/health" \
  --container-predict-route="/v1/completions" \
  --container-ports=8080 \
  --artifact-uri="gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized" \
  --model-id=${MODEL_ID}

echo "✅ Model uploaded: ${MODEL_ID}"

# Step 3: Create endpoint
echo "🎯 Creating endpoint..."

ENDPOINT_NAME="${MODEL_NAME}-endpoint"

# Check if endpoint exists
EXISTING_ENDPOINT=$(gcloud ai endpoints list \
  --region=${REGION} \
  --filter="displayName:${ENDPOINT_NAME}" \
  --format="value(name)" | head -1)

if [ -z "${EXISTING_ENDPOINT}" ]; then
  gcloud ai endpoints create \
    --region=${REGION} \
    --display-name=${ENDPOINT_NAME}
  
  ENDPOINT_ID=$(gcloud ai endpoints list \
    --region=${REGION} \
    --filter="displayName:${ENDPOINT_NAME}" \
    --format="value(name)" | head -1)
else
  ENDPOINT_ID=${EXISTING_ENDPOINT}
fi

echo "✅ Endpoint: ${ENDPOINT_ID}"

# Step 4: Deploy model to endpoint
echo "🚀 Deploying model to endpoint..."

# For Asia regions, use appropriate machine types
# g2-standard-8 for L4 GPU
# n1-highmem-8 for T4 GPU

gcloud ai endpoints deploy-model ${ENDPOINT_ID} \
  --region=${REGION} \
  --model=${MODEL_ID} \
  --display-name="${MODEL_NAME}-deployment" \
  --machine-type=n1-highmem-8 \
  --accelerator=type=nvidia-tesla-t4,count=1 \
  --min-replica-count=1 \
  --max-replica-count=2 \
  --enable-access-logging \
  --service-account="vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com" \
  --traffic-split=0=100

echo "✅ Deployment complete!"

# Save deployment info
cat > deployment_info.json << EOF
{
  "model_id": "${MODEL_ID}",
  "endpoint_id": "${ENDPOINT_ID}",
  "region": "${REGION}",
  "container_image": "${CUSTOM_IMAGE}",
  "gpu_type": "nvidia-tesla-t4",
  "created_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
EOF

echo "📝 Deployment info saved to deployment_info.json"
echo ""
echo "🧪 Test command:"
echo "python3 test_vertex_endpoint.py --endpoint-id ${ENDPOINT_ID} --region ${REGION}"