# IASO Vertex AI Deployment Guide

## Overview
Deploy IASO (fine-tuned healthcare SQL model) on Google Vertex AI with preemptible GPUs for cost-effective inference.

## GPU Selection Guide

Based on our research for vLLM inference:

### 🏆 Recommended: NVIDIA L4 (Best Price/Performance)
- **Memory**: 24GB GDDR6
- **Cost**: ~$0.70/hour (preemptible)
- **Performance**: 4x faster than T4
- **Power**: 72W (energy efficient)
- **Best for**: Production, high throughput
- **Availability**: Wide (Asia, Europe, US)

### 💰 Budget Option: NVIDIA T4
- **Memory**: 16GB
- **Cost**: ~$0.54/hour (preemptible)
- **Performance**: Good for development
- **Power**: 70W
- **Best for**: Dev/test, lower throughput
- **Availability**: Very wide

### ❌ Not Recommended: P100
- Older generation, less optimized for modern inference
- Better alternatives available

## Deployment Steps

### Option 1: Quick Deployment (May hit HF rate limits)

```bash
cd /Users/vivkris/dev_projects/nexuscare-platform/ai/training/vertex-deployment

# For L4 GPU (recommended)
bash deploy_vertex_ai_optimized.sh

# For T4 GPU (budget)
bash deploy_vertex_ai_optimized.sh budget
```

### Option 2: Custom Container (Avoids HF rate limits)

```bash
# 1. Build custom container with pre-cached model
bash prepare_custom_container.sh

# 2. Deploy using custom container
gcloud ai models upload \
  --region=asia-southeast1 \
  --display-name=iasoql-healthcare \
  --container-image-uri=gcr.io/nexuscare-463413/iasoql-vertex:latest \
  --container-health-route="/health" \
  --container-predict-route="/v1/completions" \
  --container-ports=8080
```

## Testing the Deployment

```bash
# Using Python test script
python3 test_vertex_endpoint.py \
  --endpoint-id YOUR_ENDPOINT_ID \
  --region asia-southeast1

# Using curl
curl -X POST \
  https://asia-southeast1-aiplatform.googleapis.com/v1/projects/nexuscare-463413/locations/asia-southeast1/endpoints/YOUR_ENDPOINT_ID:predict \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "Content-Type: application/json" \
  -d '{
    "instances": [{
      "prompt": "-- Count diabetic patients by age group\nSELECT",
      "max_tokens": 200,
      "temperature": 0
    }]
  }'
```

## Cost Optimization

### Preemptible Instances
- 60-91% cheaper than on-demand
- Can be terminated with 30s notice
- Perfect for dev/test workloads

### Auto-scaling
- Min replicas: 0 (scale to zero)
- Max replicas: 1 (for dev)
- Scales down after inactivity

### Regional Selection
- Asia-Southeast1 (Singapore): Lower costs
- Europe-West4 (Netherlands): Good availability
- Choose based on latency requirements

## Model Details

- **Base Model**: XiYanSQL-QwenCoder-7B-2504
- **LoRA Adapter**: 646MB healthcare-specific weights
- **Training Data**: 52 FHIR/ClickHouse SQL examples
- **Optimization**: bfloat16 precision, 0.9 GPU utilization

## Troubleshooting

### Hugging Face Rate Limits
- Use custom container with pre-cached model
- Wait 1 hour between deployment attempts
- Consider using GCS mirror

### GPU Availability
- Check quotas: `gcloud compute project-info describe`
- Try different regions if quota exhausted
- Request quota increase if needed

### Model Loading Issues
- Ensure vLLM 0.6.x (not latest)
- Set VLLM_ENGINE_VERSION=0 for legacy engine
- Check LoRA adapter path in GCS

## Monitoring

```bash
# View logs
gcloud logging read "resource.type=aiplatform.googleapis.com/Endpoint AND resource.labels.endpoint_id=YOUR_ENDPOINT_ID" --limit=50

# Check metrics
gcloud monitoring metrics list --filter="metric.type:aiplatform.googleapis.com"
```

## Next Steps

1. Deploy with L4 GPU for best performance
2. Test with healthcare SQL queries
3. Monitor costs and usage
4. Scale based on requirements

---

**Estimated Costs** (Preemptible):
- Development: $0.54/hour (T4) × 8 hours/day = $4.32/day
- Production: $0.70/hour (L4) × 24 hours/day = $16.80/day
- With auto-scaling to zero: Much less!