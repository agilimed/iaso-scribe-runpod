#!/bin/bash

# Deploy IASO using Model Garden approach
# This approach uses the official vLLM container directly

echo "🚀 Deploying IASO using Model Garden approach"

# Configuration
PROJECT_ID="nexuscare-463413"
REGION="asia-southeast1"
MODEL_NAME="iasoql-healthcare"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
MODEL_ID="${MODEL_NAME}_${TIMESTAMP}"

# Step 1: Upload model directly with vLLM arguments
echo "📤 Uploading model to Vertex AI..."

# Use the Model Garden vLLM container with proper arguments
gcloud ai models upload \
  --region=${REGION} \
  --display-name="${MODEL_NAME}" \
  --container-image-uri="us-docker.pkg.dev/vertex-ai/vertex-vision-model-garden-dockers/pytorch-vllm-serve:20250130_0916_RC01" \
  --container-args="^;^--model=XGenerationLab/XiYanSQL-QwenCoder-7B-2504;--port=8080;--host=0.0.0.0;--trust-remote-code;--max-model-len=2048;--dtype=bfloat16" \
  --container-ports=8080 \
  --container-health-route="/health" \
  --container-predict-route="/v1/completions" \
  --container-env-vars="HF_TOKEN=none,VLLM_USAGE_SOURCE=vertex-ai" \
  --artifact-uri="gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized" \
  --model-id=${MODEL_ID}

echo "✅ Model uploaded with ID: ${MODEL_ID}"

# Step 2: Create or get endpoint
echo "🎯 Setting up endpoint..."

ENDPOINT_NAME="${MODEL_NAME}-endpoint"

# Check if endpoint exists
ENDPOINT_ID=$(gcloud ai endpoints list \
  --region=${REGION} \
  --filter="displayName:${ENDPOINT_NAME}" \
  --format="value(name)" \
  --limit=1 2>/dev/null | head -1)

if [ -z "${ENDPOINT_ID}" ]; then
  echo "Creating new endpoint..."
  gcloud ai endpoints create \
    --region=${REGION} \
    --display-name=${ENDPOINT_NAME} \
    --description="IASO Healthcare SQL Generation"
  
  # Get the created endpoint ID
  ENDPOINT_ID=$(gcloud ai endpoints list \
    --region=${REGION} \
    --filter="displayName:${ENDPOINT_NAME}" \
    --format="value(name)" \
    --limit=1 | head -1)
fi

echo "✅ Using endpoint: ${ENDPOINT_ID}"

# Step 3: Deploy model to endpoint
echo "🚀 Deploying model to endpoint..."

# Deploy with T4 GPU (available in asia-southeast1)
gcloud ai endpoints deploy-model ${ENDPOINT_ID} \
  --region=${REGION} \
  --model=${MODEL_ID} \
  --display-name="${MODEL_NAME}-t4-deployment" \
  --machine-type=n1-highmem-8 \
  --accelerator=type=nvidia-tesla-t4,count=1 \
  --min-replica-count=1 \
  --max-replica-count=1 \
  --enable-access-logging \
  --traffic-split=0=100

echo "✅ Model deployed successfully!"

# Step 4: Wait for deployment to be ready
echo "⏳ Waiting for deployment to be ready..."
sleep 60

# Step 5: Test the deployment
echo "🧪 Testing deployment..."

cat > test_request.json << EOF
{
  "instances": [{
    "prompt": "-- ClickHouse SQL to count active patients by department\\nSELECT",
    "max_tokens": 200,
    "temperature": 0,
    "top_p": 1.0,
    "top_k": 50
  }]
}
EOF

echo "📝 Test request created in test_request.json"
echo ""
echo "To test the endpoint, run:"
echo ""
echo "curl -X POST \\"
echo "  -H \"Authorization: Bearer \$(gcloud auth print-access-token)\" \\"
echo "  -H \"Content-Type: application/json\" \\"
echo "  https://${REGION}-aiplatform.googleapis.com/v1/projects/${PROJECT_ID}/locations/${REGION}/endpoints/${ENDPOINT_ID}:predict \\"
echo "  -d @test_request.json"
echo ""
echo "Or use the Python test script:"
echo "python3 test_vertex_endpoint.py --endpoint-id ${ENDPOINT_ID} --region ${REGION}"

# Save deployment info
cat > deployment_info_simple.json << EOF
{
  "model_id": "${MODEL_ID}",
  "endpoint_id": "${ENDPOINT_ID}",
  "region": "${REGION}",
  "gpu_type": "nvidia-tesla-t4",
  "machine_type": "n1-highmem-8",
  "deployment_type": "model_garden_vllm",
  "created_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
EOF

echo ""
echo "📝 Deployment info saved to deployment_info_simple.json"