#!/usr/bin/env python3
"""
Prepare IASO model for Vertex AI deployment
"""
import os
import json
from google.cloud import storage

def prepare_vertex_deployment():
    """Prepare model artifacts for Vertex AI"""
    
    # Create deployment config
    config = {
        "model_info": {
            "base_model": "XGenerationLab/XiYanSQL-QwenCoder-7B-2504",
            "adapter_path": "gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized/",
            "model_type": "causal_lm_with_lora"
        },
        "serving_config": {
            "engine": "vllm",
            "gpu_memory_utilization": 0.9,
            "max_model_len": 2048,
            "trust_remote_code": True,
            "enable_lora": True
        },
        "hardware_requirements": {
            "accelerator": "NVIDIA_TESLA_T4",
            "accelerator_count": 1,
            "machine_type": "n1-standard-8",
            "disk_size_gb": 100
        }
    }
    
    # Save config
    with open("vertex_config.json", "w") as f:
        json.dump(config, f, indent=2)
    
    print("✅ Vertex AI deployment config created")
    
    # Create model handler script
    handler_script = '''
import os
import json
from typing import Dict, List
import torch
from transformers import AutoTokenizer
from vllm import LLM, SamplingParams
from vllm.lora.request import LoRARequest

class IASOModelHandler:
    def __init__(self):
        self.model_name = "XGenerationLab/XiYanSQL-QwenCoder-7B-2504"
        self.lora_path = "/models/iasoql"
        self.llm = None
        self.tokenizer = None
        
    def load(self):
        """Load the model with LoRA adapter"""
        print("Loading IASO model...")
        
        # Download LoRA adapter from GCS
        os.system("gsutil -m cp -r gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized/* /models/iasoql/")
        
        # Initialize model
        self.llm = LLM(
            model=self.model_name,
            enable_lora=True,
            max_model_len=2048,
            gpu_memory_utilization=0.9,
            trust_remote_code=True
        )
        
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        print("✅ Model loaded successfully")
        
    def predict(self, instances: List[Dict]) -> List[Dict]:
        """Generate predictions"""
        results = []
        
        for instance in instances:
            prompt = instance.get("prompt", "")
            max_tokens = instance.get("max_tokens", 500)
            temperature = instance.get("temperature", 0)
            
            # Add LoRA request
            lora_request = LoRARequest("iasoql", 1, self.lora_path)
            
            # Generate
            sampling_params = SamplingParams(
                temperature=temperature,
                max_tokens=max_tokens,
                stop=["\\n\\n", "-- End"]
            )
            
            outputs = self.llm.generate(
                [prompt], 
                sampling_params,
                lora_request=lora_request
            )
            
            results.append({
                "generated_sql": outputs[0].outputs[0].text,
                "model": "iasoql-healthcare"
            })
            
        return results
'''
    
    with open("model_handler.py", "w") as f:
        f.write(handler_script)
    
    print("✅ Model handler script created")
    
    # Create requirements.txt
    requirements = """vllm==0.6.4
transformers>=4.35.0
torch>=2.0.0
google-cloud-storage
huggingface-hub"""
    
    with open("requirements.txt", "w") as f:
        f.write(requirements)
    
    print("✅ Requirements file created")

if __name__ == "__main__":
    prepare_vertex_deployment()