#!/bin/bash

# Monitor IASO deployment status

ENDPOINT_ID="${1:-2035534672594731008}"
REGION="${2:-asia-southeast1}"

echo "📊 Monitoring deployment for endpoint: ${ENDPOINT_ID}"
echo "🌍 Region: ${REGION}"
echo ""

while true; do
  # Get deployment status
  DEPLOYED_MODELS=$(gcloud ai endpoints describe ${ENDPOINT_ID} \
    --region=${REGION} \
    --format="json" 2>/dev/null | jq -r '.deployedModels')
  
  if [ "${DEPLOYED_MODELS}" != "null" ] && [ -n "${DEPLOYED_MODELS}" ]; then
    echo "✅ Model deployed successfully!"
    echo ""
    echo "Deployed models:"
    echo "${DEPLOYED_MODELS}" | jq '.'
    break
  else
    echo "⏳ Deployment in progress... ($(date +%H:%M:%S))"
    sleep 30
  fi
done

echo ""
echo "🧪 You can now test the endpoint!"