#!/bin/bash

# Deploy IASO to Vertex AI with optimal GPU configuration
# Based on research: L4 offers best price/performance for inference

echo "🚀 Deploying IASO to Vertex AI with optimized configuration"

# Configuration
PROJECT_ID="nexuscare-463413"
MODEL_NAME="iasoql-healthcare"
ENDPOINT_NAME="iasoql-endpoint"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# GPU Selection based on research:
# L4: Best overall (24GB RAM, 4x faster than T4, only 30% more cost)
# T4: Budget option (16GB RAM, good for dev/test)
# P100: Older, not recommended for modern inference

# Check available regions for L4
echo "🔍 Checking L4 GPU availability in regions..."
REGIONS_WITH_L4=$(gcloud compute accelerator-types list \
  --filter="name=nvidia-l4" \
  --format="value(zone)" | \
  grep -E "asia|europe" | \
  cut -d'-' -f1-2 | sort -u | head -5)

echo "Available regions with L4: ${REGIONS_WITH_L4}"

# Select best region (prefer asia-southeast1 for lower latency)
if echo "${REGIONS_WITH_L4}" | grep -q "asia-southeast1"; then
  REGION="asia-southeast1"
elif echo "${REGIONS_WITH_L4}" | grep -q "europe-west4"; then
  REGION="europe-west4"  
else
  REGION=$(echo "${REGIONS_WITH_L4}" | head -1)
fi

echo "✅ Selected region: ${REGION}"

# Create a custom container with optimizations
echo "📦 Creating optimized container configuration..."

cat > vertex_container_config.json << EOF
{
  "container_spec": {
    "image_uri": "us-docker.pkg.dev/vertex-ai/prediction/vllm-gpu.0-6-1:latest",
    "env": [
      {"name": "MODEL_NAME", "value": "XGenerationLab/XiYanSQL-QwenCoder-7B-2504"},
      {"name": "ENABLE_LORA", "value": "true"},
      {"name": "LORA_MODULES", "value": "iasoql=gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized/"},
      {"name": "MAX_MODEL_LEN", "value": "2048"},
      {"name": "GPU_MEMORY_UTILIZATION", "value": "0.9"},
      {"name": "TRUST_REMOTE_CODE", "value": "true"},
      {"name": "DOWNLOAD_DIR", "value": "/tmp/model-cache"},
      {"name": "HF_HUB_CACHE", "value": "/tmp/hf-cache"},
      {"name": "VLLM_ENGINE_VERSION", "value": "0"},
      {"name": "DTYPE", "value": "bfloat16"}
    ],
    "ports": [{"container_port": 8080}],
    "health_route": "/health",
    "predict_route": "/v1/completions"
  }
}
EOF

# Step 1: Upload model to Model Registry
echo "📤 Uploading model to Vertex AI Model Registry..."

MODEL_ID="${MODEL_NAME}_${TIMESTAMP}"

gcloud ai models upload \
  --region=${REGION} \
  --display-name="${MODEL_NAME}-l4-optimized" \
  --container-image-uri="us-docker.pkg.dev/vertex-ai/prediction/vllm-gpu.0-6-1:latest" \
  --container-env-vars="MODEL_NAME=XGenerationLab/XiYanSQL-QwenCoder-7B-2504" \
  --container-env-vars="ENABLE_LORA=true" \
  --container-env-vars="LORA_MODULES=iasoql=gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized/" \
  --container-env-vars="MAX_MODEL_LEN=2048" \
  --container-env-vars="GPU_MEMORY_UTILIZATION=0.9" \
  --container-env-vars="TRUST_REMOTE_CODE=true" \
  --container-env-vars="VLLM_ENGINE_VERSION=0" \
  --container-env-vars="DTYPE=bfloat16" \
  --container-health-route="/health" \
  --container-predict-route="/v1/completions" \
  --container-ports=8080 \
  --model-id=${MODEL_ID}

# Step 2: Create endpoint if it doesn't exist
echo "🎯 Creating/Getting endpoint..."

EXISTING_ENDPOINT=$(gcloud ai endpoints list \
  --region=${REGION} \
  --filter="display_name=${ENDPOINT_NAME}" \
  --format="value(name)" | head -1)

if [ -z "${EXISTING_ENDPOINT}" ]; then
  gcloud ai endpoints create \
    --region=${REGION} \
    --display-name=${ENDPOINT_NAME} \
    --description="IASO Healthcare SQL Generation Endpoint"
  
  ENDPOINT_ID=$(gcloud ai endpoints list \
    --region=${REGION} \
    --filter="display_name=${ENDPOINT_NAME}" \
    --format="value(name)" | head -1)
else
  ENDPOINT_ID=${EXISTING_ENDPOINT}
  echo "Using existing endpoint: ${ENDPOINT_ID}"
fi

# Step 3: Deploy model with optimal configuration
echo "🚀 Deploying model to endpoint..."

# Deployment options based on GPU choice
if [ "$1" == "budget" ]; then
  echo "💰 Using budget configuration with T4 GPU..."
  GPU_TYPE="nvidia-tesla-t4"
  MACHINE_TYPE="n1-standard-4"
  echo "Cost: ~$0.54/hour (preemptible)"
else
  echo "⚡ Using performance configuration with L4 GPU..."
  GPU_TYPE="nvidia-l4"
  MACHINE_TYPE="g2-standard-8"  # G2 machines are optimized for L4
  echo "Cost: ~$0.70/hour (preemptible), 4x faster than T4"
fi

gcloud ai endpoints deploy-model ${ENDPOINT_ID} \
  --region=${REGION} \
  --model=${MODEL_ID} \
  --display-name="${MODEL_NAME}-${GPU_TYPE}-deployment" \
  --machine-type=${MACHINE_TYPE} \
  --accelerator=type=${GPU_TYPE},count=1 \
  --min-replica-count=0 \
  --max-replica-count=1 \
  --enable-autoscaling \
  --enable-access-logging \
  --traffic-split=0=100

echo "✅ Deployment complete!"
echo ""
echo "📊 Deployment Summary:"
echo "  Region: ${REGION}"
echo "  GPU: ${GPU_TYPE}"
echo "  Machine: ${MACHINE_TYPE}"
echo "  Model: ${MODEL_ID}"
echo "  Endpoint: ${ENDPOINT_ID}"
echo ""
echo "💡 GPU Comparison:"
echo "  - L4 (24GB): Best price/performance, 4x faster than T4"
echo "  - T4 (16GB): Budget option, good for dev/test"
echo "  - P100: Not recommended (older generation)"
echo ""
echo "🧪 Test the endpoint:"
echo "ENDPOINT_ID='${ENDPOINT_ID}'"
echo "REGION='${REGION}'"
echo ""
echo 'curl -X POST \'
echo "  https://${REGION}-aiplatform.googleapis.com/v1/projects/${PROJECT_ID}/locations/${REGION}/endpoints/${ENDPOINT_ID}:predict \\"
echo '  -H "Authorization: Bearer $(gcloud auth print-access-token)" \'
echo '  -H "Content-Type: application/json" \'
echo '  -d '"'"'{
    "instances": [{
      "prompt": "-- ClickHouse SQL to count active patients\nSELECT",
      "max_tokens": 200,
      "temperature": 0
    }]
  }'"'"

# Save endpoint info
cat > endpoint_info.json << EOF
{
  "endpoint_id": "${ENDPOINT_ID}",
  "region": "${REGION}",
  "model_id": "${MODEL_ID}",
  "gpu_type": "${GPU_TYPE}",
  "created_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
EOF

echo ""
echo "📝 Endpoint info saved to endpoint_info.json"