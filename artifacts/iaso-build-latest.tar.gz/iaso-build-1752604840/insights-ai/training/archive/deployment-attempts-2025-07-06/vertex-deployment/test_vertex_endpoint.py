#!/usr/bin/env python3
"""
Test IASO Vertex AI endpoint
"""
import json
import google.auth
from google.auth.transport.requests import Request
import requests
import argparse

def test_vertex_endpoint(endpoint_id, region, project_id=None):
    """Test the Vertex AI endpoint"""
    
    # Get credentials
    credentials, project = google.auth.default()
    if project_id is None:
        project_id = project
    
    # Get access token
    auth_req = Request()
    credentials.refresh(auth_req)
    
    # Construct endpoint URL
    endpoint_url = f"https://{region}-aiplatform.googleapis.com/v1/projects/{project_id}/locations/{region}/endpoints/{endpoint_id}:predict"
    
    # Test queries
    test_queries = [
        {
            "name": "Count active patients",
            "prompt": "-- ClickHouse SQL to count active patients\nSELECT",
            "expected_keywords": ["COUNT", "patients", "active", "status"]
        },
        {
            "name": "Average length of stay",
            "prompt": "-- Calculate average length of stay by department\nSELECT",
            "expected_keywords": ["AVG", "department", "period", "encounters"]
        },
        {
            "name": "Medication adherence",
            "prompt": "-- Find medication adherence rates for diabetes patients\nSELECT",
            "expected_keywords": ["medications", "diabetes", "adherence"]
        }
    ]
    
    headers = {
        "Authorization": f"Bearer {credentials.token}",
        "Content-Type": "application/json"
    }
    
    print("🧪 Testing IASO Vertex AI Endpoint")
    print(f"📍 Endpoint: {endpoint_id}")
    print(f"🌍 Region: {region}")
    print("-" * 50)
    
    for test in test_queries:
        print(f"\n📝 Test: {test['name']}")
        print(f"Prompt: {test['prompt']}")
        
        payload = {
            "instances": [{
                "prompt": test['prompt'],
                "max_tokens": 200,
                "temperature": 0
            }]
        }
        
        try:
            response = requests.post(
                endpoint_url,
                headers=headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                generated_sql = result['predictions'][0]['generated_sql']
                print(f"✅ Generated SQL:\n{generated_sql}")
                
                # Check for expected keywords
                missing_keywords = []
                for keyword in test['expected_keywords']:
                    if keyword.lower() not in generated_sql.lower():
                        missing_keywords.append(keyword)
                
                if missing_keywords:
                    print(f"⚠️  Missing expected keywords: {missing_keywords}")
                else:
                    print("✅ All expected keywords found")
            else:
                print(f"❌ Error: {response.status_code}")
                print(f"Response: {response.text}")
                
        except Exception as e:
            print(f"❌ Exception: {str(e)}")
    
    print("\n" + "-" * 50)
    print("✅ Testing complete!")

def main():
    parser = argparse.ArgumentParser(description="Test IASO Vertex AI endpoint")
    parser.add_argument("--endpoint-id", required=True, help="Vertex AI endpoint ID")
    parser.add_argument("--region", required=True, help="GCP region")
    parser.add_argument("--project-id", help="GCP project ID (optional)")
    
    args = parser.parse_args()
    
    test_vertex_endpoint(args.endpoint_id, args.region, args.project_id)

if __name__ == "__main__":
    main()