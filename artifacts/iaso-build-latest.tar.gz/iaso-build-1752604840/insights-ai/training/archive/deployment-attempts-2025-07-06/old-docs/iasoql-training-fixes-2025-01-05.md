# IasoQL Training Fixes - January 5, 2025

## Issues Identified and Fixed

### 1. Out of Memory (OOM) Error - Root Cause

**Problem**: Training failed with CUDA OOM error showing 1,569,964,032 trainable parameters (22.33% of model)

**Root Cause**: 
- The `modules_to_save=["embed_tokens", "lm_head"]` parameter in LoRA config
- This forces the entire embedding and output layers to be trainable
- These layers are massive in a 7B model (embed_tokens: ~520M params, lm_head: ~520M params)

**Fix Applied**:
```python
# REMOVED these problematic lines:
modules_to_save=["embed_tokens", "lm_head"]  # This caused 1.2B trainable params!

# Also removed from target_modules:
"embed_tokens", "lm_head"  # Don't need LoRA adapters on these
```

### 2. Memory Optimizations Added

1. **Gradient Checkpointing**: Trades compute for memory
   ```python
   self.model.gradient_checkpointing_enable()
   ```

2. **PyTorch Memory Config**: Better allocation strategy
   ```python
   os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True,max_split_size_mb:512"
   ```

3. **Bias Training**: Disabled to save memory
   ```python
   bias="none"  # Changed from "all"
   ```

### 3. Corrected LoRA Configuration

**Final GPU Configuration**:
```python
lora_config = LoraConfig(
    r=64,                    # Higher rank for better capacity
    lora_alpha=128,          # 2×r for optimal learning rate scaling
    target_modules=[
        "q_proj", "v_proj", "k_proj", "o_proj", 
        "gate_proj", "up_proj", "down_proj"
    ],
    lora_dropout=0.1,
    bias="none",
    task_type="CAUSAL_LM"
)
```

**Expected Results**:
- Trainable parameters: ~3.7M (0.05% of 7B model)
- Memory requirement: ~0.02 GB for parameters
- Total with activations: <5 GB (safe for A100 40GB)

### 4. Training Hyperparameters (Optimized)

- **Batch Size**: 1 (to minimize activation memory)
- **Gradient Accumulation**: 16 (effective batch size = 16)
- **Learning Rate**: 1e-4 (higher for larger LoRA rank)
- **Epochs**: 5 (more thorough learning)
- **Warmup**: 10% of steps
- **Scheduler**: Cosine
- **Label Smoothing**: 0.1

### 5. Environment Variables Fixed

Updated submission script to properly pass optimized parameters:
```python
env_vars = [
    {"name": "BATCH_SIZE", "value": "1"},
    {"name": "GRADIENT_ACCUMULATION", "value": "16"},
    {"name": "EPOCHS", "value": "5"},
    {"name": "LEARNING_RATE", "value": "1e-4"},
    {"name": "PYTORCH_CUDA_ALLOC_CONF", "value": "expandable_segments:True,max_split_size_mb:512"}
]
```

## Verification

Memory calculation script confirms safety:
```
Trainable Parameters: 3,670,016 (3.7M)
Percentage of 7B model: 0.05%
Total memory needed: 0.02 GB
A100 GPU Capacity: 40 GB
Memory headroom: 39.98 GB
✅ Configuration is SAFE for A100 training
```

## Next Steps

1. ✅ Fixed LoRA configuration to remove modules_to_save
2. ✅ Added memory optimizations
3. ✅ Updated environment variables
4. 🔄 Rebuilding training container
5. 🔄 Rebuilding baseline container
6. ⏳ Deploy baseline to sqlcoder-endpoint
7. ⏳ Submit corrected training job
8. ⏳ Monitor W&B for proper metrics logging

## Lessons Learned

1. **Never use `modules_to_save` for large layers** - It makes them fully trainable
2. **Always calculate memory requirements** before training
3. **Test configurations locally** if possible before cloud submission
4. **Double-check environment variable propagation** in submission scripts

## Expected Training Time

- DWS wait time: 0-24 hours for GPU availability
- Training time: ~8 hours on A100
- 52 training examples, 5 epochs = 260 optimization steps
- With gradient accumulation 16: 260/16 = 16.25 actual updates