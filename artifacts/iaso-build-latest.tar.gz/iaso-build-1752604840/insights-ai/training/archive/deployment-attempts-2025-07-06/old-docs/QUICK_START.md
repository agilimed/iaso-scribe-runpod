# Quick Start Guide for Training

## Immediate Action (Use Existing Infrastructure)

Since you already have LlamaIndex + Qdrant set up, here's what to do:

### Step 1: Index Your Metrics (Today)

```python
# Use your existing LlamaIndexConversationalService
from backend.src.services.ai.LlamaIndexConversationalService import LlamaIndexConversationalService

service = LlamaIndexConversationalService()

# Index all metrics from metric_definitions
metrics = await clickhouse.query("""
    SELECT metric_id, metric_name, metric_description, calculation_sql, tags
    FROM nexuscare_analytics.metric_definitions
    WHERE is_active = true
""")

for metric in metrics:
    await service.index_document({
        "id": metric.metric_id,
        "content": f"{metric.metric_name} - {metric.metric_description}",
        "metadata": {
            "type": "metric",
            "metric_id": metric.metric_id,
            "sql": metric.calculation_sql,
            "tags": metric.tags
        }
    })
```

### Step 2: Update Your Query Handler

```python
async def handle_analytics_query(query: str, tenant_id: str):
    # Try metric retrieval first
    metric_results = await service.search(
        query=query,
        filter={"type": "metric", "tenant_id": tenant_id},
        top_k=3
    )
    
    if metric_results and metric_results[0].score > 0.8:
        # Use pre-defined metric SQL
        sql = metric_results[0].metadata["sql"]
        return await execute_sql(sql, {"tenant_id": tenant_id})
    else:
        # Fall back to SQL generation
        sql = await generate_sql_from_nl(query)
        return await execute_sql(sql, {"tenant_id": tenant_id})
```

### Step 3: Start Training SQL Generation Model

```bash
# Use the clean dataset for training
python train_model.py \
    --dataset sql-generation/fhir-clickhouse-training-dataset-v8-PASSING.json \
    --model xiyan-sql-qwencoder-7b \
    --output models/nexuscare-sql-generator
```

## What You Get

1. **Immediate**: Metric retrieval working with your existing RAG
2. **Week 1**: SQL generation model trained and deployed
3. **Week 2**: Full hybrid system with both approaches

## Testing

```python
# Test queries that should use metrics
test_metric_queries = [
    "Show me diabetic patient count",
    "What's our bed occupancy rate?",
    "Emergency department wait times"
]

# Test queries that need SQL generation
test_generation_queries = [
    "Find all patients with both diabetes and hypertension diagnosed in the last 30 days",
    "Show me medication adherence rates grouped by age and condition",
    "Complex custom analysis not in metrics"
]
```

## Files to Use

- **For SQL Training**: `sql-generation/fhir-clickhouse-training-dataset-v8-PASSING.json`
- **For Metric Examples**: `metric-retrieval/metric-retrieval-training-dataset.json`
- **For Validation**: `config/enhanced-training-config.yaml`

That's it! You can start immediately with Step 1 using your existing infrastructure.