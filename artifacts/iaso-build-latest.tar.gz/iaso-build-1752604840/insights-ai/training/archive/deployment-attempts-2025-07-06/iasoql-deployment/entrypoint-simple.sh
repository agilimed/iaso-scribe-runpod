#!/bin/bash

echo "🚀 Starting IasoQL Healthcare Model (Simple)"
echo "📁 Downloading LoRA adapter from GCS..."

# Create directory for LoRA adapter
mkdir -p /models/iasoql

# Use gsutil to download (simpler and more reliable)
gsutil -m cp -r gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized/* /models/iasoql/

echo "📁 LoRA adapter files:"
ls -la /models/iasoql/

echo "🔧 Starting vLLM with LoRA..."

# Use environment variables to avoid rate limits
export HF_HUB_ENABLE_HF_TRANSFER=0
export VLLM_ENGINE_VERSION=0  # Force legacy engine

# Start vLLM with LoRA support - using simple configuration
exec python3 -m vllm.entrypoints.openai.api_server \
    --model XGenerationLab/XiYanSQL-QwenCoder-7B-2504 \
    --enable-lora \
    --lora-modules iasoql=/models/iasoql \
    --host 0.0.0.0 \
    --port 8080 \
    --max-model-len 2048 \
    --gpu-memory-utilization 0.9 \
    --trust-remote-code \
    --served-model-name iasoql-healthcare \
    --download-dir /tmp/model-cache \
    --max-lora-rank 64