#!/bin/bash

echo "🚀 Starting IasoQL Healthcare Model with Debug Info"
echo "📊 System Info:"
echo "  Python: $(python3 --version)"
echo "  vLLM: $(python3 -c 'import vllm; print(vllm.__version__)')"
echo "  CUDA: $(nvidia-smi --query-gpu=name,driver_version --format=csv,noheader)"

echo "📁 Downloading LoRA adapter from GCS..."

# Create the directory structure
mkdir -p /models/iasoql

# Use Python to download with service account authentication
python3 << 'EOF'
import os
import sys
from google.cloud import storage
from google.auth import default

try:
    # Use default credentials (Cloud Run service account)
    credentials, project = default()
    client = storage.Client(credentials=credentials, project='nexuscare-463413')
    bucket = client.bucket('nexuscare-ai-training')
    
    files = ['adapter_config.json', 'adapter_model.safetensors']
    for file_name in files:
        print(f"  Downloading {file_name}...")
        blob = bucket.blob(f'models/iasoql-7b-healthcare-optimized/{file_name}')
        blob.download_to_filename(f'/models/iasoql/{file_name}')
        print(f"  ✓ {file_name} downloaded")
    
    print("✅ LoRA adapter downloaded successfully")
except Exception as e:
    print(f"❌ Failed to download LoRA adapter: {e}")
    sys.exit(1)
EOF

if [ $? -ne 0 ]; then
    echo "❌ Failed to download LoRA adapter, exiting..."
    exit 1
fi

echo "📁 LoRA adapter files:"
ls -la /models/iasoql/

echo "🔍 Checking adapter config:"
cat /models/iasoql/adapter_config.json | jq .

echo "🔧 Starting vLLM with LoRA (debug mode)..."

# Set debug environment variables
export VLLM_LOGGING_LEVEL=DEBUG
export CUDA_LAUNCH_BLOCKING=1

# Start vLLM with LoRA support
exec python3 -m vllm.entrypoints.openai.api_server \
    --model XGenerationLab/XiYanSQL-QwenCoder-7B-2504 \
    --enable-lora \
    --lora-modules iasoql=/models/iasoql \
    --host 0.0.0.0 \
    --port 8080 \
    --max-model-len 2048 \
    --gpu-memory-utilization 0.9 \
    --trust-remote-code \
    --served-model-name iasoql-healthcare \
    --max-lora-rank 64 \
    --max-loras 1