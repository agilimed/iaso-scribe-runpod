#!/bin/bash

echo "🚀 Starting IasoQL Healthcare Model"
echo "📁 Checking LoRA adapter files..."
ls -la /models/iasoql/

echo "🔧 Starting vLLM with LoRA..."

# Start vLLM with LoRA support
exec python3 -m vllm.entrypoints.openai.api_server \
    --model XGenerationLab/XiYanSQL-QwenCoder-7B-2504 \
    --enable-lora \
    --lora-modules iasoql=/models/iasoql \
    --host 0.0.0.0 \
    --port 8080 \
    --max-model-len 2048 \
    --gpu-memory-utilization 0.9 \
    --trust-remote-code \
    --disable-log-requests \
    --served-model-name iasoql-healthcare