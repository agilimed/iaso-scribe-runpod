# IasoQL LoRA Deployment Issue Resolution

## Problem Summary
The IasoQL model with LoRA adapter is failing to initialize with the error "Engine core initialization failed" when deployed on Cloud Run with vLLM.

## Root Cause
Based on debugging and research:
1. **vLLM V1 Engine Issue**: The latest vLLM versions (0.9.x) use a new V1 engine that has known issues with LoRA adapter initialization
2. **Engine Process Communication**: The error shows the engine waiting indefinitely for core engine processes to start
3. **Known GitHub Issues**: Multiple open issues (#19002, #17618, #18730) report similar problems with LoRA on the V1 engine

## Solutions

### Solution 1: Use vLLM 0.6.4 (Stable Version)
Deploy with vLLM 0.6.4 which has proven LoRA support:
```bash
# Already built as iasoql-healthcare:stable
gcloud run services replace deploy-stable.yaml --region us-central1
```

### Solution 2: Disable V1 Engine (Force Legacy)
Set environment variable to use the legacy engine:
```yaml
env:
- name: VLLM_ENGINE_VERSION
  value: '0'
```

### Solution 3: Use Baseline Model + Prompt Engineering
As a temporary workaround, use the baseline XiYanSQL model with healthcare-specific prompts:
```bash
curl https://sqlcoder-endpoint-kt4atarccq-uc.a.run.app/v1/completions \
  -H "Authorization: Bearer $(gcloud auth print-identity-token)" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "xiyan-baseline",
    "prompt": "Healthcare context: FHIR R4, ClickHouse database\n\nGenerate SQL for: {user_query}",
    "max_tokens": 500,
    "temperature": 0
  }'
```

### Solution 4: Alternative Deployment Method
Instead of Cloud Run, consider:
1. **GKE with Custom Pod**: More control over environment and debugging
2. **Vertex AI Endpoint**: Native support for LoRA adapters
3. **TGI (Text Generation Inference)**: Alternative to vLLM with better LoRA support

## Recommended Next Steps

1. **Short-term**: Deploy the stable version (0.6.4) which is already built
2. **Medium-term**: Test with TGI or Vertex AI Endpoints for better LoRA support
3. **Long-term**: Wait for vLLM to fix V1 engine LoRA issues or migrate to a different serving framework

## Testing Command
Once deployed, test the IasoQL model:
```bash
# Test IasoQL endpoint
curl https://iasoql-endpoint-kt4atarccq-uc.a.run.app/v1/completions \
  -H "Authorization: Bearer $(gcloud auth print-identity-token)" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "iasoql",
    "prompt": "-- ClickHouse SQL for FHIR data\n-- Get count of active patients\nSELECT",
    "max_tokens": 200,
    "temperature": 0
  }'
```