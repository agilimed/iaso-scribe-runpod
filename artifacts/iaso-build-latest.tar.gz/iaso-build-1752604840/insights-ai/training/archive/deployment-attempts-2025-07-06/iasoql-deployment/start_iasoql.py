#!/usr/bin/env python3
"""
Startup script for IasoQL fine-tuned model with LoRA adapter
"""
import subprocess
import os
import sys
from google.cloud import storage

def download_lora_adapter():
    """Download LoRA adapter from GCS"""
    print("🔽 Downloading IasoQL LoRA adapter from GCS...")
    
    # Use default credentials (will work with Cloud Run service account)
    client = storage.Client(project='nexuscare-463413')
    bucket = client.bucket('nexuscare-ai-training')
    
    # Download all LoRA files
    lora_files = [
        'adapter_config.json',
        'adapter_model.safetensors',
    ]
    
    os.makedirs('/models/iasoql', exist_ok=True)
    
    for file_name in lora_files:
        blob_path = f'models/iasoql-7b-healthcare-optimized/{file_name}'
        local_path = f'/models/iasoql/{file_name}'
        
        print(f"  Downloading {file_name}...")
        blob = bucket.blob(blob_path)
        blob.download_to_filename(local_path)
    
    print("✅ LoRA adapter downloaded successfully")

def start_base_model():
    """Start vLLM without LoRA adapter"""
    model_name = os.getenv("MODEL_NAME", "XGenerationLab/XiYanSQL-QwenCoder-7B-2504")
    port = os.getenv("PORT", "8080")
    
    print(f"🚀 Starting base model {model_name} on port {port}")
    
    cmd = [
        "python3", "-m", "vllm.entrypoints.openai.api_server",
        "--model", model_name,
        "--host", "0.0.0.0",
        "--port", port,
        "--max-model-len", "2048",
        "--gpu-memory-utilization", "0.9",
        "--trust-remote-code",
        "--disable-log-requests",
        "--served-model-name", "iasoql-healthcare"
    ]
    
    subprocess.run(cmd, check=True)

def main():
    try:
        # Download LoRA adapter
        download_lora_adapter()
    except Exception as e:
        print(f"❌ Failed to download LoRA adapter: {e}")
        print("📌 Falling back to base model without LoRA")
        # Start without LoRA if download fails
        start_base_model()
        return
    
    # Get configuration from environment variables
    model_name = os.getenv("MODEL_NAME", "XGenerationLab/XiYanSQL-QwenCoder-7B-2504")
    port = os.getenv("PORT", "8080")
    
    print(f"🚀 Starting IasoQL (fine-tuned {model_name}) on port {port}")
    print(f"🔧 Using LoRA adapter from /models/iasoql")
    
    # Note: vLLM supports LoRA adapters with --lora-modules parameter
    # Format: name=path
    cmd = [
        "python3", "-m", "vllm.entrypoints.openai.api_server",
        "--model", model_name,
        "--enable-lora",
        "--lora-modules", "iasoql=/models/iasoql",
        "--host", "0.0.0.0",
        "--port", port,
        "--max-model-len", "2048",
        "--gpu-memory-utilization", "0.9",
        "--trust-remote-code",
        "--disable-log-requests",
        "--served-model-name", "iasoql-healthcare"
    ]
    
    print(f"🏃 Command: {' '.join(cmd)}")
    
    # Execute the command
    try:
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError as e:
        print(f"❌ vLLM server failed with exit code {e.returncode}")
        sys.exit(e.returncode)
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()