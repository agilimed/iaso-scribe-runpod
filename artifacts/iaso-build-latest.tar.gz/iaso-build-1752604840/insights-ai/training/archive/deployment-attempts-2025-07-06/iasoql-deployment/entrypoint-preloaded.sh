#!/bin/bash

echo "🚀 Starting IasoQL Healthcare Model (Pre-loaded)"
echo "📊 System Info:"
echo "  Python: $(python3 --version)"
echo "  vLLM: $(python3 -c 'import vllm; print(vllm.__version__)')"

echo "📁 LoRA adapter files (pre-loaded):"
ls -la /models/iasoql/

echo "🔧 Starting vLLM with LoRA..."

# Start vLLM with LoRA support
exec python3 -m vllm.entrypoints.openai.api_server \
    --model XGenerationLab/XiYanSQL-QwenCoder-7B-2504 \
    --enable-lora \
    --lora-modules iasoql=/models/iasoql \
    --host 0.0.0.0 \
    --port 8080 \
    --max-model-len 2048 \
    --gpu-memory-utilization 0.9 \
    --trust-remote-code \
    --served-model-name iasoql-healthcare \
    --max-lora-rank 64