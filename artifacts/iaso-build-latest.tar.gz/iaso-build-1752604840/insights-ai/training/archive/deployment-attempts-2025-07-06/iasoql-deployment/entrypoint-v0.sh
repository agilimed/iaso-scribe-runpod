#!/bin/bash

echo "🚀 Starting IasoQL Healthcare Model (V0 Legacy Engine)"
echo "📁 Downloading LoRA adapter from GCS..."

# Use Python to download with service account authentication
python3 << 'EOF'
import os
from google.cloud import storage
from google.auth import default

try:
    # Use default credentials (Cloud Run service account)
    credentials, project = default()
    client = storage.Client(credentials=credentials, project='nexuscare-463413')
    bucket = client.bucket('nexuscare-ai-training')
    
    files = ['adapter_config.json', 'adapter_model.safetensors']
    for file_name in files:
        print(f"  Downloading {file_name}...")
        blob = bucket.blob(f'models/iasoql-7b-healthcare-optimized/{file_name}')
        blob.download_to_filename(f'/models/iasoql/{file_name}')
    
    print("✅ LoRA adapter downloaded successfully")
except Exception as e:
    print(f"❌ Failed to download LoRA adapter: {e}")
    exit(1)
EOF

if [ $? -ne 0 ]; then
    echo "❌ Failed to download LoRA adapter, exiting..."
    exit 1
fi

echo "📁 LoRA adapter files:"
ls -la /models/iasoql/

echo "🔧 Starting vLLM with LoRA (V0 Legacy Engine)..."

# Force V0 legacy engine which has better LoRA support
export VLLM_USE_V1=0
export VLLM_ENGINE_VERSION=0
export VLLM_USE_LEGACY_API=1

# Start vLLM with LoRA support
exec python3 -m vllm.entrypoints.openai.api_server \
    --model XGenerationLab/XiYanSQL-QwenCoder-7B-2504 \
    --enable-lora \
    --lora-modules iasoql=/models/iasoql \
    --host 0.0.0.0 \
    --port 8080 \
    --max-model-len 2048 \
    --gpu-memory-utilization 0.9 \
    --trust-remote-code \
    --disable-log-requests \
    --served-model-name iasoql-healthcare