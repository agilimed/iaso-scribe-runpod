#!/bin/bash

echo "🚀 Starting IasoQL Healthcare Model (Extended from baseline)"
echo "📁 Downloading LoRA adapter from GCS..."

# Download LoRA adapter using service account
gsutil -m cp -r gs://nexuscare-ai-training/models/iasoql-7b-healthcare-optimized/* /models/iasoql/

echo "📁 LoRA adapter files:"
ls -la /models/iasoql/

echo "🔧 Starting vLLM with LoRA (extending baseline)..."

# Start vLLM with same config as baseline but add LoRA
exec python3 -m vllm.entrypoints.openai.api_server \
    --model XGenerationLab/XiYanSQL-QwenCoder-7B-2504 \
    --enable-lora \
    --lora-modules iasoql=/models/iasoql \
    --host 0.0.0.0 \
    --port 8080 \
    --max-model-len 4096 \
    --gpu-memory-utilization 0.9 \
    --trust-remote-code \
    --served-model-name iasoql-healthcare