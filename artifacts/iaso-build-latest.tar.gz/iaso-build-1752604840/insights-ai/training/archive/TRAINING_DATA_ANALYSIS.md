# Training Data vs Implementation Analysis

## Date: 2025-01-05

## Executive Summary
This analysis compares the metric-aware-training-dataset.json with the actual AdvancedSQLGenerator implementation to identify gaps and create an updated training dataset that accurately reflects our current implementation.

## Key Findings

### 1. Fundamental Approach Mismatch

#### Training Dataset Approach:
- **Assumes pre-computed metrics** stored in `metric_values` table
- Uses simple queries: `SELECT metric_value FROM metric_values WHERE metric_id = 'X'`
- Focuses on retrieving pre-calculated results

#### Actual Implementation Approach:
- **Generates complex SQL dynamically** from metric definitions
- Creates joins between FHIR resources directly
- Uses `fhir_current` or `fhir_events` tables based on temporal needs
- No reference to `metric_values` table at all

### 2. Table Usage Differences

#### Training Dataset:
```sql
-- Primary tables referenced:
- metric_values
- metric_definitions
```

#### Actual Implementation:
```sql
-- Primary tables used:
- nexuscare_analytics.fhir_current (for current state queries)
- nexuscare_analytics.fhir_events (for historical/versioned queries)
-- No metric_values table used
```

### 3. Query Pattern Differences

#### Training Dataset Pattern:
```sql
-- Simple metric retrieval
SELECT metric_value, calculated_at 
FROM metric_values 
WHERE metric_id = 'diabetic_patient_count' 
  AND tenant_id = :tenant_id 
ORDER BY calculated_at DESC 
LIMIT 1
```

#### Actual Implementation Pattern:
```sql
-- Complex FHIR resource queries with joins
SELECT 
  JSONExtractString(p.resource, '$.id') AS patient_id,
  JSONExtractString(p.resource, '$.name[0].family') AS last_name,
  JSONExtractFloat(o.resource, '$.valueQuantity.value') AS hba1c_value
FROM nexuscare_analytics.fhir_current AS p
INNER JOIN nexuscare_analytics.fhir_current AS c
  ON JSONExtractString(c.resource, '$.subject.reference') = CONCAT('Patient/', p.resource_id)
  AND c.resource_type = 'Condition'
  AND p.tenant_id = c.tenant_id
WHERE p.tenant_id = 'default'
  AND p.resource_type = 'Patient'
  AND JSONExtractString(c.resource, '$.code.coding[0].code') = 'E11.9'
```

### 4. Feature Support Gaps

#### Training Dataset Features Not in Implementation:
- Direct metric_id lookups
- Pre-computed metric values
- Dimension-based filtering on metric_values
- Metric freshness checking queries

#### Implementation Features Not in Training Dataset:
- Complex JSON extraction with JSONExtractString/Float/Bool
- Multi-table FHIR resource joins
- Temporal pattern selection (current vs historical)
- Window functions and CTEs
- Advanced aggregations and transformations
- Dynamic table selection based on query needs

### 5. SQL Syntax Differences

#### Training Dataset Syntax:
- Simple dimension access: `dimension_values['department']`
- Direct metric value access
- Minimal JSON operations

#### Implementation Syntax:
- Complex JSON path extraction: `JSONExtractString(resource, '$.path.to.field')`
- FHIR reference handling with CONCAT operations
- Sophisticated join conditions
- Sign-based versioning filters

## Recommendations

### 1. Create New Training Dataset Categories

#### A. Direct FHIR Query Examples
```json
{
  "instruction": "Query current diabetic patients directly from FHIR resources",
  "input": "Show me all diabetic patients",
  "output": "SELECT COUNT(DISTINCT JSONExtractString(resource, '$.subject.reference')) as patient_count FROM nexuscare_analytics.fhir_current WHERE tenant_id = :tenant_id AND resource_type = 'Condition' AND JSONExtractString(resource, '$.code.coding[0].code') IN ('E11', 'E10', 'E11.9')",
  "context": {
    "table_used": "fhir_current",
    "resource_types": ["Condition"],
    "temporal_pattern": "current"
  }
}
```

#### B. Complex Join Examples
```json
{
  "instruction": "Join multiple FHIR resources for comprehensive analysis",
  "input": "Show diabetic patients with their latest HbA1c values",
  "output": "[Complex SQL with Patient-Condition-Observation joins]",
  "context": {
    "tables_used": ["fhir_current"],
    "resource_types": ["Patient", "Condition", "Observation"],
    "join_complexity": "multi-resource"
  }
}
```

#### C. Historical Query Examples
```json
{
  "instruction": "Analyze historical trends using fhir_events",
  "input": "Show emergency department visits trend over last 90 days",
  "output": "[SQL using fhir_events with time-based aggregation]",
  "context": {
    "table_used": "fhir_events",
    "temporal_pattern": "historical",
    "aggregation_type": "time-series"
  }
}
```

### 2. Update Training Guidelines

Current guidelines focus on metric_values usage. New guidelines should emphasize:
- JSON extraction patterns for FHIR resources
- Join strategies for related resources
- Table selection based on temporal needs
- Handling FHIR references correctly
- Version filtering with sign = 1

### 3. Bridge the Gap

Consider implementing a hybrid approach:
1. Keep the metric_values concept for frequently-used, pre-computed metrics
2. Use AdvancedSQLGenerator for ad-hoc and complex queries
3. Create a routing layer that decides between cached metrics and dynamic generation

### 4. Training Data Structure Update

Proposed new structure:
```json
{
  "version": "2.0.0",
  "description": "FHIR-native training dataset for direct resource querying",
  "query_categories": {
    "simple_resource_queries": [...],
    "multi_resource_joins": [...],
    "temporal_analysis": [...],
    "aggregation_queries": [...],
    "window_function_queries": [...]
  },
  "sql_patterns": {
    "json_extraction": {...},
    "fhir_reference_handling": {...},
    "temporal_filtering": {...}
  }
}
```

## Next Steps

1. **Create new training dataset** that reflects actual SQL patterns from AdvancedSQLGenerator
2. **Document the decision** on whether to implement metric_values table or remove it from training
3. **Update model training** with accurate SQL patterns
4. **Test model performance** with new training data
5. **Consider hybrid approach** for optimization

## Conclusion

The current training dataset and implementation are fundamentally misaligned. The training data assumes a metric store pattern while the implementation generates complex FHIR queries directly. This mismatch will significantly impact the AI model's ability to generate correct SQL for the NexusCare platform.

Immediate action is needed to either:
1. Update the training data to match the implementation (recommended)
2. Implement the metric_values pattern from the training data
3. Create a hybrid system that uses both approaches

The recommended approach is option 1, as the current implementation is more flexible and doesn't require maintaining pre-computed metrics.