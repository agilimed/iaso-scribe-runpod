#!/bin/bash

# Set environment variables for better debugging
export VLLM_LOGGING_LEVEL=DEBUG
export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:512

# Check shared memory size
echo "Checking shared memory size..."
df -h /dev/shm

# Start vLLM with optimized settings for Cloud Run + GPU
echo "Starting vLLM server with IasoQL merged model..."
exec python3 -m vllm.entrypoints.openai.api_server \
    --model /app/model \
    --host 0.0.0.0 \
    --port 8080 \
    --max-model-len 4096 \
    --gpu-memory-utilization 0.85 \
    --api-key token-iasoql-agilimed \
    --trust-remote-code \
    --disable-log-requests \
    --served-model-name iasoql-agilimed-healthcare \
    --dtype bfloat16 \
    --enforce-eager \
    --disable-custom-all-reduce