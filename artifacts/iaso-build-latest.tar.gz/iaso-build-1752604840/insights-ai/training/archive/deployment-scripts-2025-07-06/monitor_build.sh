#!/bin/bash

# Monitor Cloud Build with automatic retry on failure
BUILD_ID="e5aca57c-4d9a-4d91-926e-18a37e74f4e6"
PROJECT_ID="nexuscare-463413"
MAX_RETRIES=3
RETRY_COUNT=0

monitor_and_retry() {
    while true; do
        echo "🕐 $(date): Checking build status..."
        
        # Get build status
        STATUS=$(gcloud builds describe $BUILD_ID --format="value(status)" 2>/dev/null)
        
        if [ $? -ne 0 ]; then
            echo "❌ Error getting build status"
            return 1
        fi
        
        echo "📊 Build $BUILD_ID: $STATUS"
        
        case $STATUS in
            "WORKING" | "QUEUED")
                echo "⏳ Build in progress..."
                # Show latest logs
                echo "📝 Latest logs:"
                gcloud builds log $BUILD_ID | tail -3
                echo "---"
                ;;
            "SUCCESS")
                echo "✅ Build completed successfully!"
                
                # Check if Cloud Run service was deployed
                echo "🚀 Checking Cloud Run deployment..."
                SERVICE_URL=$(gcloud run services describe iasoql-agilimed-healthcare --region=us-central1 --format="value(status.url)" 2>/dev/null)
                
                if [ -n "$SERVICE_URL" ]; then
                    echo "✅ Cloud Run service deployed!"
                    echo "🔗 Service URL: $SERVICE_URL"
                    echo "📊 API Endpoint: $SERVICE_URL/v1/completions"
                    
                    # Test the service
                    echo "🧪 Testing service health..."
                    sleep 30  # Give it time to start
                    curl -s "$SERVICE_URL/health" && echo "✅ Service is healthy!" || echo "⚠️ Service not responding yet"
                else
                    echo "⚠️ Build succeeded but Cloud Run deployment might have failed"
                fi
                return 0
                ;;
            "FAILURE" | "CANCELLED" | "TIMEOUT")
                echo "❌ Build failed with status: $STATUS"
                
                # Show error logs
                echo "📜 Error logs:"
                gcloud builds log $BUILD_ID | tail -10
                
                # Retry if we haven't exceeded max retries
                if [ $RETRY_COUNT -lt $MAX_RETRIES ]; then
                    RETRY_COUNT=$((RETRY_COUNT + 1))
                    echo "🔄 Attempting retry $RETRY_COUNT of $MAX_RETRIES..."
                    
                    # Analyze and fix the issue
                    fix_and_retry
                    return $?
                else
                    echo "❌ Max retries ($MAX_RETRIES) exceeded. Manual intervention required."
                    return 1
                fi
                ;;
            *)
                echo "❓ Unknown status: $STATUS"
                ;;
        esac
        
        # Wait 5 minutes before next check
        echo "⏰ Waiting 5 minutes before next check..."
        sleep 300
    done
}

fix_and_retry() {
    echo "🔧 Analyzing failure and attempting fix..."
    
    # Get the full error log
    ERROR_LOG=$(gcloud builds log $BUILD_ID | tail -20)
    
    # Check for common errors and apply fixes
    if echo "$ERROR_LOG" | grep -q "manifest.*not found"; then
        echo "🔧 Fix: Base image issue detected. Updating Dockerfile..."
        # Update to use a more stable base image
        sed -i 's/FROM vllm\/vllm-openai:v0.6.4.post1/FROM vllm\/vllm-openai:latest/' Dockerfile.iasoql
        
    elif echo "$ERROR_LOG" | grep -q "No space left on device"; then
        echo "🔧 Fix: Disk space issue. Using larger machine..."
        # Update Cloud Build to use larger disk
        sed -i 's/diskSizeGb: .*/diskSizeGb: 200/' cloudbuild_iasoql.yaml
        
    elif echo "$ERROR_LOG" | grep -q "timeout"; then
        echo "🔧 Fix: Timeout issue. Increasing timeout..."
        # Increase timeout
        sed -i 's/timeout: .*/timeout: 7200s/' cloudbuild_iasoql.yaml
        
    elif echo "$ERROR_LOG" | grep -q "gpu"; then
        echo "🔧 Fix: GPU deployment issue. Adjusting GPU settings..."
        # Simplify GPU configuration
        sed -i 's/--gpu-type=nvidia-l4/--gpu-type=nvidia-t4/' cloudbuild_iasoql.yaml
        
    else
        echo "🔧 Fix: General retry with clean build..."
        # Clean retry - no specific fix identified
    fi
    
    # Submit new build
    echo "🚀 Submitting fixed build..."
    NEW_BUILD_OUTPUT=$(gcloud builds submit --config=cloudbuild_iasoql.yaml . 2>&1)
    
    if [ $? -eq 0 ]; then
        # Extract new build ID
        BUILD_ID=$(echo "$NEW_BUILD_OUTPUT" | grep -o 'builds/[a-z0-9-]*' | cut -d'/' -f2 | head -1)
        echo "✅ New build submitted: $BUILD_ID"
        echo "🔗 Logs: https://console.cloud.google.com/cloud-build/builds/$BUILD_ID?project=$PROJECT_ID"
        return 0
    else
        echo "❌ Failed to submit new build"
        echo "$NEW_BUILD_OUTPUT"
        return 1
    fi
}

# Main execution
echo "🚀 Starting Cloud Build Monitor"
echo "================================"
echo "Build ID: $BUILD_ID"
echo "Project: $PROJECT_ID"
echo "Max Retries: $MAX_RETRIES"
echo ""

# Start monitoring
monitor_and_retry

if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 SUCCESS! IasoQL is deployed and ready!"
    echo "=================================="
    
    # Update todo list
    echo "✅ Updating todo list..."
    # Mark build task as completed
    
else
    echo ""
    echo "❌ FAILED! Manual intervention required"
    echo "=================================="
    echo "Check the logs and try manual fixes"
fi