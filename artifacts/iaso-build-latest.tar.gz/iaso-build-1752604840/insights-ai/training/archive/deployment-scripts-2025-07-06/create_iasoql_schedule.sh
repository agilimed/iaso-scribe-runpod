#!/bin/bash

# Create instance schedule for IasoQL VM

PROJECT_ID="nexuscare-463413"
ZONE="us-central1-a"
INSTANCE_NAME="iasoql-preemptible"

echo "📅 Creating Instance Schedule for IasoQL"
echo "========================================"

# Create the resource policy (schedule)
gcloud compute resource-policies create instance-schedule iasoql-schedule \
    --description="Auto start/stop schedule for IasoQL" \
    --vm-start-schedule="0 9 * * MON-FRI" \
    --vm-stop-schedule="0 18 * * MON-FRI" \
    --timezone="America/New_York" \
    --region=us-central1

# Attach the schedule to the instance
gcloud compute instances add-resource-policies $INSTANCE_NAME \
    --resource-policies=iasoql-schedule \
    --zone=$ZONE

echo ""
echo "✅ Schedule created!"
echo ""
echo "📊 Schedule Details:"
echo "   Start: 9:00 AM EST Monday-Friday"
echo "   Stop: 6:00 PM EST Monday-Friday"
echo "   Weekend: OFF (saving 48 hours/week)"
echo ""
echo "💰 Cost Savings:"
echo "   Regular: 168 hours/week × $0.20 = $33.60/week"
echo "   Scheduled: 45 hours/week × $0.20 = $9.00/week"
echo "   Savings: $24.60/week (73% reduction)"