#!/bin/bash

# Startup script for IasoQL VM

echo "🚀 Starting IasoQL setup..." | tee /var/log/iasoql-setup.log

# Update system
apt-get update
apt-get install -y python3-pip git curl

# Install NVIDIA drivers
echo "📦 Installing NVIDIA drivers..." | tee -a /var/log/iasoql-setup.log
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
  sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
  sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

apt-get update
apt-get install -y nvidia-driver-535 nvidia-container-toolkit

# Install Docker
echo "🐳 Installing Docker..." | tee -a /var/log/iasoql-setup.log
apt-get install -y docker.io
systemctl start docker
systemctl enable docker

# Install gcloud CLI and authenticate
echo "☁️ Setting up Google Cloud SDK..." | tee -a /var/log/iasoql-setup.log
snap install google-cloud-cli --classic

# Create directory for model
mkdir -p /model

# Download model from GCS
echo "📥 Downloading IasoQL merged model..." | tee -a /var/log/iasoql-setup.log
gsutil -m cp -r gs://nexuscare-ai-training/models/iasoql-merged-complete/* /model/
echo "✅ Model downloaded" | tee -a /var/log/iasoql-setup.log

# Create Docker container for vLLM
echo "🐳 Creating vLLM container..." | tee -a /var/log/iasoql-setup.log

# Run vLLM container
docker run -d \
  --name iasoql-server \
  --runtime nvidia \
  --gpus all \
  -v /model:/model \
  -p 8080:8080 \
  --restart unless-stopped \
  vllm/vllm-openai:latest \
  --model /model \
  --host 0.0.0.0 \
  --port 8080 \
  --dtype bfloat16 \
  --max-model-len 8192 \
  --gpu-memory-utilization 0.95 \
  --trust-remote-code

echo "✅ vLLM server started" | tee -a /var/log/iasoql-setup.log

# Create health check script
cat > /usr/local/bin/health_check.sh << 'EOF'
#!/bin/bash
curl -s http://localhost:8080/health || exit 1
EOF
chmod +x /usr/local/bin/health_check.sh

# Add cron job for health monitoring
(crontab -l 2>/dev/null; echo "*/5 * * * * /usr/local/bin/health_check.sh || docker restart iasoql-server") | crontab -

echo "🎉 IasoQL setup complete!" | tee -a /var/log/iasoql-setup.log
echo "📊 Server is starting on port 8080" | tee -a /var/log/iasoql-setup.log