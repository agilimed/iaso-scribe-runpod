#!/usr/bin/env python3
import os
import logging
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn
from vllm import LLM, SamplingParams

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Request/Response models
class CompletionRequest(BaseModel):
    model: str = "iasoql"
    prompt: str
    max_tokens: int = 100
    temperature: float = 0.1
    top_p: float = 0.9
    stop: Optional[List[str]] = None

class CompletionResponse(BaseModel):
    choices: List[dict]
    model: str
    usage: dict

# Initialize vLLM
logger.info("🚀 Initializing IasoQL model...")
model_path = "/app/model"

try:
    llm = LLM(
        model=model_path,
        dtype="bfloat16",
        max_model_len=8192,
        gpu_memory_utilization=0.95,
        trust_remote_code=True
    )
    logger.info("✅ Model loaded successfully")
except Exception as e:
    logger.error(f"❌ Model loading failed: {e}")
    raise

# FastAPI app
app = FastAPI(title="IasoQL AgiliMed Healthcare API")

@app.get("/health")
def health_check():
    return {"status": "healthy", "model": "iasoql-agilimed-healthcare"}

@app.get("/v1/models")
def list_models():
    return {
        "data": [
            {
                "id": "iasoql-agilimed-healthcare",
                "object": "model",
                "created": 1640995200,
                "owned_by": "nexuscare"
            }
        ]
    }

@app.post("/v1/completions", response_model=CompletionResponse)
def create_completion(request: CompletionRequest):
    try:
        # Create sampling parameters
        sampling_params = SamplingParams(
            temperature=request.temperature,
            top_p=request.top_p,
            max_tokens=request.max_tokens,
            stop=request.stop
        )
        
        # Generate completion
        outputs = llm.generate([request.prompt], sampling_params)
        output = outputs[0]
        
        # Format response
        response = CompletionResponse(
            choices=[
                {
                    "text": output.outputs[0].text,
                    "index": 0,
                    "finish_reason": output.outputs[0].finish_reason
                }
            ],
            model=request.model,
            usage={
                "prompt_tokens": len(output.prompt_token_ids),
                "completion_tokens": len(output.outputs[0].token_ids),
                "total_tokens": len(output.prompt_token_ids) + len(output.outputs[0].token_ids)
            }
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Completion failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    logger.info(f"🚀 Starting IasoQL server on port {port}")
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=port,
        log_level="info"
    )