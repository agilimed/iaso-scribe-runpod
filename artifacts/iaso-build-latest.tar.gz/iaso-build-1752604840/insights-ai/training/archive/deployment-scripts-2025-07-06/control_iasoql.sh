#!/bin/bash
# Local control script for IasoQL VM

PROJECT_ID="nexuscare-463413"
ZONE="us-central1-a"
INSTANCE_NAME="iasoql-inference-vm"
EXTERNAL_IP=""

case "$1" in
    start)
        echo "🚀 Starting IasoQL container..."
        gcloud compute ssh $INSTANCE_NAME --zone=$ZONE --command="sudo iasoql-control start"
        echo "🔗 Access at: http://$EXTERNAL_IP:8080"
        ;;
    stop)
        echo "🛑 Stopping IasoQL container..."
        gcloud compute ssh $INSTANCE_NAME --zone=$ZONE --command="sudo iasoql-control stop"
        ;;
    status)
        gcloud compute ssh $INSTANCE_NAME --zone=$ZONE --command="sudo iasoql-control status"
        ;;
    logs)
        gcloud compute ssh $INSTANCE_NAME --zone=$ZONE --command="sudo iasoql-control logs"
        ;;
    ssh)
        gcloud compute ssh $INSTANCE_NAME --zone=$ZONE
        ;;
    test)
        echo "🧪 Testing IasoQL endpoint..."
        curl -X POST http://$EXTERNAL_IP:8080/v1/completions             -H "Content-Type: application/json"             -d '{
                "model": "/model",
                "prompt": "SELECT * FROM Patient WHERE active = true",
                "max_tokens": 100,
                "temperature": 0.1
            }' | jq
        ;;
    setup-logs)
        echo "📜 Viewing setup logs..."
        gcloud compute ssh $INSTANCE_NAME --zone=$ZONE --command="sudo tail -f /var/log/iasoql-setup.log"
        ;;
    cost)
        gcloud compute ssh $INSTANCE_NAME --zone=$ZONE --command="sudo iasoql-cost"
        ;;
    *)
        echo "Usage: $0 {start|stop|status|logs|ssh|test|setup-logs|cost}"
        echo ""
        echo "Commands:"
        echo "  start       - Start the IasoQL container"
        echo "  stop        - Stop the container (save GPU costs)"  
        echo "  status      - Check container and GPU status"
        echo "  logs        - View container logs"
        echo "  ssh         - SSH into the VM"
        echo "  test        - Test the API endpoint"
        echo "  setup-logs  - View initial setup progress"
        echo "  cost        - View cost information"
        ;;
esac
