#!/usr/bin/env python3
"""
Deploy IasoQL merged model to Vertex AI with custom serving container
"""

import os
import sys
from google.cloud import aiplatform
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def deploy_model():
    """Deploy the merged IasoQL model to Vertex AI"""
    
    # Configuration
    project_id = "nexuscare-463413"
    location = "us-central1"
    model_name = "iasoql-agilimed-healthcare-baseline"
    model_description = "IasoQL Healthcare SQL model - Fine-tuned XiYanSQL for FHIR R4 ClickHouse queries"
    
    # Model artifact location
    artifact_uri = "gs://nexuscare-ai-training/models/iasoql-merged-complete/"
    
    # Use our existing container that has vLLM
    serving_container_image = "gcr.io/nexuscare-463413/xiyan-baseline:latest"
    
    logger.info(f"🚀 Deploying {model_name} to Vertex AI")
    logger.info(f"📍 Location: {location}")
    logger.info(f"📦 Model artifacts: {artifact_uri}")
    logger.info(f"🖥️  Using Custom Model Serving with NVIDIA L4 GPU")
    
    try:
        # Initialize Vertex AI
        aiplatform.init(project=project_id, location=location)
        
        # Step 1: Upload model to Model Registry
        logger.info("\n📤 Uploading model to Vertex AI Model Registry...")
        
        model = aiplatform.Model.upload(
            display_name=model_name,
            description=model_description,
            artifact_uri=artifact_uri,
            serving_container_image_uri=serving_container_image,
            serving_container_command=["bash", "-c"],
            serving_container_args=[
                "gsutil -m cp -r /gcs/model/* /tmp/model/ && python -m vllm.entrypoints.openai.api_server --model /tmp/model --host 0.0.0.0 --port 8080 --dtype bfloat16 --max-model-len 8192 --gpu-memory-utilization 0.95 --trust-remote-code"
            ],
            serving_container_predict_route="/v1/completions",
            serving_container_health_route="/health",
            serving_container_ports=[8080],
            serving_container_environment_variables={
                "MODEL_NAME": model_name,
                "CUDA_VISIBLE_DEVICES": "0"
            },
            labels={
                "model_type": "text-to-sql",
                "base_model": "xiyan-sql-qwencoder-7b",
                "fine_tuned": "true",
                "serving_framework": "vllm"
            }
        )
        
        logger.info(f"✅ Model uploaded!")
        logger.info(f"   Model ID: {model.name}")
        
        # Step 2: Create or get endpoint
        endpoint_name = f"{model_name}-endpoint"
        logger.info(f"\n🎯 Setting up endpoint: {endpoint_name}")
        
        # Check for existing endpoint
        endpoints = aiplatform.Endpoint.list(
            filter=f'display_name="{endpoint_name}"'
        )
        
        if endpoints:
            endpoint = endpoints[0]
            logger.info(f"   Using existing endpoint: {endpoint.name}")
            # Undeploy existing models
            if endpoint.traffic_split:
                logger.info("   Undeploying existing models...")
                endpoint.undeploy_all()
        else:
            endpoint = aiplatform.Endpoint.create(
                display_name=endpoint_name,
                description=f"vLLM endpoint for {model_name}"
            )
            logger.info(f"✅ New endpoint created!")
        
        # Step 3: Deploy model to endpoint
        logger.info("\n🚀 Deploying model to endpoint...")
        logger.info("   Machine: g2-standard-8 (with NVIDIA L4 GPU)")
        logger.info("   This will take 10-15 minutes...")
        
        deployed_model = endpoint.deploy(
            model=model,
            deployed_model_display_name=f"{model_name}-deployment",
            machine_type="g2-standard-8",  # L4 GPU machine type
            traffic_percentage=100,
            min_replica_count=1,
            max_replica_count=2,
            enable_access_logging=True,
            service_account=f"vanna-sqlcoder-sa@{project_id}.iam.gserviceaccount.com"
        )
        
        logger.info(f"\n✅ Deployment complete!")
        logger.info(f"\n📊 Deployment Summary:")
        logger.info(f"   Model: {model_name}")
        logger.info(f"   Endpoint ID: {endpoint.name}")
        logger.info(f"   Machine: g2-standard-8 with NVIDIA L4 GPU")
        logger.info(f"   API: OpenAI-compatible (/v1/completions)")
        logger.info(f"   Status: Ready for predictions")
        
        # Get endpoint details
        endpoint_id = endpoint.name.split('/')[-1]
        logger.info(f"\n🔗 Endpoint Details:")
        logger.info(f"   Endpoint ID: {endpoint_id}")
        logger.info(f"   Prediction URL: https://{location}-aiplatform.googleapis.com/v1/{endpoint.resource_name}:predict")
        
        return model, endpoint
        
    except Exception as e:
        logger.error(f"❌ Deployment failed: {e}")
        import traceback
        traceback.print_exc()
        raise

def main():
    """Main function"""
    logger.info("🏥 IasoQL AgiliMed Healthcare Baseline - Vertex AI Deployment")
    logger.info("=" * 70)
    
    try:
        model, endpoint = deploy_model()
        
        print(f"\n🎉 SUCCESS! Model deployed to Vertex AI")
        print(f"\n📋 How to test:")
        print(f"   1. Get an access token:")
        print(f"      export TOKEN=$(gcloud auth print-access-token)")
        print(f"\n   2. Send a test request:")
        print(f"      curl -X POST \\")
        print(f"        https://{endpoint.location}-aiplatform.googleapis.com/v1/{endpoint.resource_name}:predict \\")
        print(f"        -H 'Authorization: Bearer $TOKEN' \\")
        print(f"        -H 'Content-Type: application/json' \\")
        print(f"        -d '{{\"instances\": [{{\"prompt\": \"List all patients\", \"max_tokens\": 100}}]}}'")
        
    except Exception as e:
        print(f"\n❌ Deployment failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()