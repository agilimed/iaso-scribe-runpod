#!/bin/bash

# Management script for IasoQL VM

PROJECT_ID="nexuscare-463413"
ZONE="us-central1-a"
INSTANCE_NAME="iasoql-preemptible"

case "$1" in
    start)
        echo "🚀 Starting IasoQL VM..."
        gcloud compute instances start $INSTANCE_NAME --zone=$ZONE
        
        # Wait for external IP
        sleep 10
        EXTERNAL_IP=$(gcloud compute instances describe $INSTANCE_NAME --zone=$ZONE --format='get(networkInterfaces[0].accessConfigs[0].natIP)')
        echo "✅ VM started at: http://$EXTERNAL_IP:8080"
        ;;
        
    stop)
        echo "🛑 Stopping IasoQL VM..."
        gcloud compute instances stop $INSTANCE_NAME --zone=$ZONE
        echo "✅ VM stopped (no charges while stopped)"
        ;;
        
    status)
        echo "📊 Checking IasoQL VM status..."
        gcloud compute instances describe $INSTANCE_NAME --zone=$ZONE --format="table(name,status,machineType.scope(machineTypes),networkInterfaces[0].accessConfigs[0].natIP:label=EXTERNAL_IP)"
        ;;
        
    restart)
        echo "🔄 Restarting IasoQL VM..."
        gcloud compute instances reset $INSTANCE_NAME --zone=$ZONE
        ;;
        
    ssh)
        echo "🔐 Connecting to IasoQL VM..."
        gcloud compute ssh $INSTANCE_NAME --zone=$ZONE
        ;;
        
    logs)
        echo "📜 Viewing IasoQL setup logs..."
        gcloud compute ssh $INSTANCE_NAME --zone=$ZONE --command="tail -f /var/log/iasoql-setup.log"
        ;;
        
    cost)
        echo "💰 Cost Analysis:"
        STATUS=$(gcloud compute instances describe $INSTANCE_NAME --zone=$ZONE --format="value(status)" 2>/dev/null || echo "NOT_FOUND")
        
        if [ "$STATUS" = "RUNNING" ]; then
            echo "   Status: RUNNING (💵 $0.20/hour)"
            echo "   Daily cost if left running: $4.80"
        elif [ "$STATUS" = "TERMINATED" ]; then
            echo "   Status: STOPPED (💵 $0.00/hour)"
            echo "   Only paying for 100GB disk: ~$4/month"
        else
            echo "   Status: $STATUS"
        fi
        ;;
        
    *)
        echo "Usage: $0 {start|stop|status|restart|ssh|logs|cost}"
        echo ""
        echo "Commands:"
        echo "  start   - Start the VM and show endpoint"
        echo "  stop    - Stop the VM (no GPU charges)"
        echo "  status  - Check current VM status"
        echo "  restart - Restart the VM"
        echo "  ssh     - Connect to the VM"
        echo "  logs    - View setup/runtime logs"
        echo "  cost    - Show current cost status"
        exit 1
        ;;
esac