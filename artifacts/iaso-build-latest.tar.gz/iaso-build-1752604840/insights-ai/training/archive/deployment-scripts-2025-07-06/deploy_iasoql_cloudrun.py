#!/usr/bin/env python3
"""
Deploy IasoQL merged model to Cloud Run
Using the same approach as the baseline model
"""

import os
import subprocess
import json
from datetime import datetime

def run_command(cmd, description):
    """Run command and handle output"""
    print(f"\n{description}...")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"❌ Error: {result.stderr}")
        raise Exception(f"Command failed: {cmd}")
    print(f"✅ {description} - Success")
    return result.stdout

def main():
    print("🏥 IasoQL AgiliMed Healthcare Baseline - Cloud Run Deployment")
    print("=" * 70)
    
    # Configuration
    project_id = "nexuscare-463413"
    region = "us-central1"
    service_name = "iasoql-agilimed-healthcare"
    model_path = "gs://nexuscare-ai-training/models/iasoql-merged-complete/"
    
    # Step 1: Create Dockerfile
    print("\n📄 Creating Dockerfile...")
    
    dockerfile_content = '''FROM nvidia/cuda:12.1.0-runtime-ubuntu22.04

# Install Python and system dependencies
RUN apt-get update && apt-get install -y \\
    python3 python3-pip git curl \\
    && rm -rf /var/lib/apt/lists/*

# Install Python packages
RUN pip3 install --no-cache-dir \\
    torch==2.1.0 \\
    transformers>=4.37.0 \\
    accelerate \\
    vllm==0.6.2 \\
    sentencepiece \\
    protobuf \\
    einops \\
    fastapi \\
    uvicorn

# Set working directory
WORKDIR /app

# Create model directory
RUN mkdir -p /model

# Copy model from GCS (will be done at runtime)
ENV MODEL_NAME="iasoql-agilimed-healthcare-baseline"
ENV MODEL_PATH="/model"

# Create startup script
RUN echo '#!/bin/bash\\n\\
echo "🚀 Starting IasoQL AgiliMed Healthcare model server..."\\n\\
echo "📥 Downloading model from GCS..."\\n\\
gsutil -m cp -r gs://nexuscare-ai-training/models/iasoql-merged-complete/* /model/\\n\\
echo "✅ Model downloaded"\\n\\
echo "🔧 Starting vLLM server..."\\n\\
python3 -m vllm.entrypoints.openai.api_server \\\\\\
    --model /model \\\\\\
    --host 0.0.0.0 \\\\\\
    --port 8080 \\\\\\
    --dtype bfloat16 \\\\\\
    --max-model-len 8192 \\\\\\
    --gpu-memory-utilization 0.95 \\\\\\
    --disable-log-requests \\\\\\
    --trust-remote-code' > /app/start.sh && \\
    chmod +x /app/start.sh

# Install gsutil
RUN pip3 install gsutil

EXPOSE 8080

CMD ["/app/start.sh"]
'''
    
    # Write Dockerfile
    with open("Dockerfile", "w") as f:
        f.write(dockerfile_content)
    
    # Step 2: Create Cloud Run service configuration
    print("\n📝 Creating service configuration...")
    
    service_yaml = f'''apiVersion: serving.knative.dev/v1
kind: Service
metadata:
  name: {service_name}
  annotations:
    run.googleapis.com/launch-stage: BETA
spec:
  template:
    metadata:
      annotations:
        run.googleapis.com/execution-environment: gen2
        run.googleapis.com/gpu: "1"
        run.googleapis.com/cpu-throttling: "false"
        autoscaling.knative.dev/minScale: "1"
        autoscaling.knative.dev/maxScale: "3"
    spec:
      containerConcurrency: 1
      timeoutSeconds: 600
      serviceAccountName: vanna-sqlcoder-sa@{project_id}.iam.gserviceaccount.com
      containers:
      - image: gcr.io/{project_id}/{service_name}:latest
        name: {service_name}
        ports:
        - containerPort: 8080
        resources:
          limits:
            cpu: "8"
            memory: 32Gi
            nvidia.com/gpu: "1"
        env:
        - name: CUDA_VISIBLE_DEVICES
          value: "0"
        - name: MODEL_NAME
          value: "iasoql-agilimed-healthcare-baseline"
        startupProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 600
          periodSeconds: 30
          timeoutSeconds: 10
          failureThreshold: 30
'''
    
    with open("service.yaml", "w") as f:
        f.write(service_yaml)
    
    # Step 3: Build container
    print(f"\n🏗️  Building container image...")
    
    build_cmd = f"""gcloud builds submit . \\
        --tag gcr.io/{project_id}/{service_name}:latest \\
        --timeout=30m \\
        --machine-type=e2-highcpu-8"""
    
    run_command(build_cmd, "Container build")
    
    # Step 4: Deploy to Cloud Run
    print(f"\n🚀 Deploying to Cloud Run...")
    
    deploy_cmd = f"""gcloud run services replace service.yaml \\
        --region {region} \\
        --platform managed"""
    
    run_command(deploy_cmd, "Cloud Run deployment")
    
    # Step 5: Get service URL
    print(f"\n🔗 Getting service URL...")
    
    url_cmd = f"""gcloud run services describe {service_name} \\
        --region {region} \\
        --format 'value(status.url)'"""
    
    service_url = run_command(url_cmd, "Get service URL").strip()
    
    # Print summary
    print("\n" + "=" * 70)
    print("🎉 DEPLOYMENT SUCCESSFUL!")
    print("=" * 70)
    print(f"\n📋 Deployment Summary:")
    print(f"   Service Name: {service_name}")
    print(f"   Model: iasoql-agilimed-healthcare-baseline")
    print(f"   Region: {region}")
    print(f"   URL: {service_url}")
    print(f"   GPU: NVIDIA L4")
    print(f"   API: OpenAI-compatible")
    print(f"\n💡 Test the endpoint:")
    print(f"   curl -X POST {service_url}/v1/completions \\")
    print(f"     -H 'Authorization: Bearer YOUR_TOKEN' \\")
    print(f"     -H 'Content-Type: application/json' \\")
    print(f"     -d '{{\"model\": \"iasoql-agilimed-healthcare-baseline\", \"prompt\": \"Your SQL query\", \"max_tokens\": 500}}'")
    
    # Cleanup
    os.remove("Dockerfile")
    os.remove("service.yaml")

if __name__ == "__main__":
    main()