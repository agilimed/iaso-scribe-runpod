#!/bin/bash

echo "🚀 Starting IasoQL AgiliMed Healthcare model server..."
echo "📥 Downloading model from GCS..."
gsutil -m cp -r gs://nexuscare-ai-training/models/iasoql-merged-complete/* /model/
echo "✅ Model downloaded"
echo "🔧 Starting vLLM server..."

python3 -m vllm.entrypoints.openai.api_server \
    --model /model \
    --host 0.0.0.0 \
    --port 8080 \
    --dtype bfloat16 \
    --max-model-len 8192 \
    --gpu-memory-utilization 0.95 \
    --disable-log-requests \
    --trust-remote-code