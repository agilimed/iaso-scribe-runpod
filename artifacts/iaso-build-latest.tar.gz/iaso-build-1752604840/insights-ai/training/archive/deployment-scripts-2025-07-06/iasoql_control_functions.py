#!/usr/bin/env python3
"""
Cloud Functions for on-demand IasoQL VM control
Deploy these as HTTP-triggered Cloud Functions
"""

import functions_framework
from google.cloud import compute_v1
import json

PROJECT_ID = "nexuscare-463413"
ZONE = "us-central1-a"
INSTANCE_NAME = "iasoql-preemptible"

@functions_framework.http
def start_iasoql(request):
    """Start the IasoQL VM"""
    instances_client = compute_v1.InstancesClient()
    
    try:
        operation = instances_client.start(
            project=PROJECT_ID,
            zone=ZONE,
            instance=INSTANCE_NAME
        )
        
        return json.dumps({
            "status": "success",
            "message": f"Starting {INSTANCE_NAME}",
            "operation": operation.name
        })
    except Exception as e:
        return json.dumps({
            "status": "error",
            "message": str(e)
        }), 500

@functions_framework.http
def stop_iasoql(request):
    """Stop the IasoQL VM"""
    instances_client = compute_v1.InstancesClient()
    
    try:
        operation = instances_client.stop(
            project=PROJECT_ID,
            zone=ZONE,
            instance=INSTANCE_NAME
        )
        
        return json.dumps({
            "status": "success",
            "message": f"Stopping {INSTANCE_NAME}",
            "operation": operation.name
        })
    except Exception as e:
        return json.dumps({
            "status": "error",
            "message": str(e)
        }), 500

@functions_framework.http
def status_iasoql(request):
    """Check IasoQL VM status"""
    instances_client = compute_v1.InstancesClient()
    
    try:
        instance = instances_client.get(
            project=PROJECT_ID,
            zone=ZONE,
            instance=INSTANCE_NAME
        )
        
        return json.dumps({
            "status": instance.status,
            "machine_type": instance.machine_type.split('/')[-1],
            "external_ip": instance.network_interfaces[0].access_configs[0].nat_i_p if instance.network_interfaces else None,
            "is_running": instance.status == "RUNNING"
        })
    except Exception as e:
        return json.dumps({
            "status": "NOT_FOUND",
            "message": str(e)
        }), 404