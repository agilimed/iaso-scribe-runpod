#!/bin/bash

# Deploy IasoQL merged model to Cloud Run (following xiyan baseline pattern)

echo "🚀 Deploying IasoQL to Cloud Run"
echo "================================"

# Configuration
PROJECT_ID="nexuscare-463413"
REGION="us-central1"
SERVICE_NAME="iasoql-agilimed-healthcare"
IMAGE_TAG="iasoql-merged:latest"
IMAGE_URI="gcr.io/${PROJECT_ID}/${IMAGE_TAG}"

# Step 1: Create Dockerfile
echo "📝 Creating Dockerfile..."
cat > /tmp/Dockerfile.iasoql << 'DOCKERFILE'
FROM python:3.9-slim

# Install system dependencies
RUN apt-get update && apt-get install -y \
    curl \
    git \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
RUN pip install --no-cache-dir \
    vllm==0.2.6 \
    transformers \
    torch \
    fastapi \
    uvicorn \
    google-cloud-storage

# Create app directory
WORKDIR /app

# Create model directory
ENV MODEL_PATH=/app/model
RUN mkdir -p $MODEL_PATH

# Copy startup script
COPY start_server.py /app/

# Download model at runtime (better for caching)
COPY download_model.sh /app/
RUN chmod +x /app/download_model.sh

# Expose port
EXPOSE 8080

# Start command
CMD ["/app/download_model.sh"]
DOCKERFILE

# Step 2: Create startup script
echo "📝 Creating startup script..."
cat > /tmp/start_server.py << 'PYTHON_SCRIPT'
#!/usr/bin/env python3
import os
import subprocess
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    model_path = "/app/model"
    port = int(os.environ.get("PORT", 8080))
    
    logger.info(f"🚀 Starting IasoQL on port {port}")
    logger.info(f"📦 Model path: {model_path}")
    
    # Start vLLM server
    cmd = [
        "python", "-m", "vllm.entrypoints.openai.api_server",
        "--model", model_path,
        "--host", "0.0.0.0",
        "--port", str(port),
        "--dtype", "bfloat16",
        "--max-model-len", "4096",  # Reduced for Cloud Run
        "--trust-remote-code",
        "--disable-log-requests"
    ]
    
    logger.info("🎯 Starting vLLM server...")
    subprocess.run(cmd)

if __name__ == "__main__":
    main()
PYTHON_SCRIPT

# Step 3: Create model download script
echo "📝 Creating model download script..."
cat > /tmp/download_model.sh << 'DOWNLOAD_SCRIPT'
#!/bin/bash
set -e

echo "📥 Downloading IasoQL model if not exists..."

# Check if model already exists (for container reuse)
if [ ! -f "/app/model/config.json" ]; then
    echo "📦 Downloading model from GCS..."
    gsutil -m cp -r gs://nexuscare-ai-training/models/iasoql-merged-complete/* /app/model/
    echo "✅ Model downloaded"
else
    echo "✅ Model already exists, skipping download"
fi

echo "🚀 Starting IasoQL server..."
python /app/start_server.py
DOWNLOAD_SCRIPT

# Step 4: Build Docker image
echo "🔨 Building Docker image..."
cd /tmp
docker build -f Dockerfile.iasoql -t $IMAGE_URI .

# Step 5: Push to Container Registry
echo "📤 Pushing to Container Registry..."
docker push $IMAGE_URI

# Step 6: Deploy to Cloud Run
echo "🚀 Deploying to Cloud Run..."
gcloud run deploy $SERVICE_NAME \
    --image $IMAGE_URI \
    --region $REGION \
    --platform managed \
    --allow-unauthenticated \
    --memory 16Gi \
    --cpu 8 \
    --timeout 3600 \
    --concurrency 5 \
    --max-instances 2 \
    --min-instances 0 \
    --port 8080 \
    --set-env-vars MODEL_NAME=iasoql-agilimed-healthcare

# Get service URL
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region=$REGION --format="value(status.url)")

echo ""
echo "✅ Deployment Complete!"
echo "======================"
echo ""
echo "🔗 Service URL: $SERVICE_URL"
echo "📊 API Endpoint: $SERVICE_URL/v1/completions"
echo ""
echo "💰 Cost Structure:"
echo "   - Scales to 0 when not in use (no cost)"
echo "   - Pay per request: ~$0.10-0.20 per request"
echo "   - Cold start: 30-60 seconds"
echo ""
echo "🧪 Test the deployment:"
echo "curl -X POST $SERVICE_URL/v1/completions \\"
echo "  -H 'Content-Type: application/json' \\"
echo "  -d '{\"model\": \"iasoql\", \"prompt\": \"SELECT * FROM Patient\", \"max_tokens\": 100}'"
echo ""
echo "📊 Monitor logs:"
echo "gcloud run logs tail $SERVICE_NAME --region=$REGION"