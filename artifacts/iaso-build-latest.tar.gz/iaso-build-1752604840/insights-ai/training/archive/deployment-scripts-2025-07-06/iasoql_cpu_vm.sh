#!/bin/bash

# Deploy CPU-only version for testing while waiting for GPU quota

echo "🚀 Setting up IasoQL VM (CPU-only for testing)"
echo "============================================="

# Configuration
PROJECT_ID="nexuscare-463413"
ZONE="us-central1-a"
INSTANCE_NAME="iasoql-cpu-test"
MACHINE_TYPE="n1-standard-8"
BOOT_DISK_SIZE="50"  # Smaller disk

# Create startup script for CPU version
cat > /tmp/iasoql_cpu_startup.sh << 'STARTUP_SCRIPT'
#!/bin/bash
set -e

LOG_FILE="/var/log/iasoql-setup.log"
echo "🚀 Starting IasoQL CPU setup at $(date)" | tee $LOG_FILE

# Update system
apt-get update
apt-get install -y curl git python3-pip jq docker.io

# Create model directory
mkdir -p /model
chmod 777 /model

# Download model
echo "📥 Downloading IasoQL model..." | tee -a $LOG_FILE
gsutil -m cp -r gs://nexuscare-ai-training/models/iasoql-merged-complete/* /model/

# Pull vLLM CPU image
echo "🐳 Pulling vLLM CPU image..." | tee -a $LOG_FILE
docker pull vllm/vllm-openai:latest

# Create control script
cat > /usr/local/bin/iasoql-control << 'CONTROL_SCRIPT'
#!/bin/bash

CONTAINER_NAME="iasoql-server"
MODEL_PATH="/model"

case "$1" in
    start)
        echo "🚀 Starting IasoQL container (CPU mode)..."
        docker run -d \
            --name $CONTAINER_NAME \
            -v $MODEL_PATH:/model \
            -p 8080:8080 \
            --restart unless-stopped \
            vllm/vllm-openai:latest \
            --model /model \
            --host 0.0.0.0 \
            --port 8080 \
            --dtype float16 \
            --max-model-len 2048 \
            --trust-remote-code
        echo "✅ CPU container starting (slower inference)..."
        ;;
    *)
        echo "Usage: $0 {start|stop|status|logs}"
        ;;
esac
CONTROL_SCRIPT

chmod +x /usr/local/bin/iasoql-control

echo "✅ CPU setup complete!" | tee -a $LOG_FILE
STARTUP_SCRIPT

# Create the VM (CPU only)
gcloud compute instances create $INSTANCE_NAME \
    --project=$PROJECT_ID \
    --zone=$ZONE \
    --machine-type=$MACHINE_TYPE \
    --preemptible \
    --image-family=ubuntu-2204-lts \
    --image-project=ubuntu-os-cloud \
    --boot-disk-size=$BOOT_DISK_SIZE \
    --boot-disk-type=pd-standard \
    --metadata-from-file startup-script=/tmp/iasoql_cpu_startup.sh \
    --scopes=https://www.googleapis.com/auth/cloud-platform \
    --tags=iasoql

echo ""
echo "✅ CPU VM Created!"
echo "=================="
echo ""
echo "💡 This is a CPU-only test version while we wait for GPU quota."
echo "   Performance will be slower but you can test the model."
echo ""
echo "📝 To request GPU quota increase:"
echo "   1. Go to: https://console.cloud.google.com/iam-admin/quotas"
echo "   2. Search for 'GPUS_ALL_REGIONS'"
echo "   3. Request increase to 1"
echo ""
echo "⏱️ Setup takes ~5-10 minutes"