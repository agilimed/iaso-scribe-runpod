#!/usr/bin/env python3
"""
Deploy IasoQL model to Vertex AI using pre-built vLLM container
"""

import os
import sys
from google.cloud import aiplatform
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def deploy_model():
    """Deploy the merged IasoQL model to Vertex AI"""
    
    # Configuration
    project_id = "nexuscare-463413"
    location = "us-central1"
    model_name = "iasoql-agilimed-healthcare-baseline"
    model_description = "IasoQL Healthcare SQL model - Fine-tuned XiYanSQL for FHIR R4 ClickHouse queries"
    
    # Model artifact location
    artifact_uri = "gs://nexuscare-ai-training/models/iasoql-merged-complete/"
    
    # Use pre-built vLLM container from Google
    serving_container_image = "us-docker.pkg.dev/vertex-ai/vertex-vision-model-garden-dockers/pytorch-vllm-serve:20241016_0933_RC00"
    
    logger.info(f"🚀 Deploying {model_name} to Vertex AI")
    logger.info(f"📍 Location: {location}")
    logger.info(f"📦 Model artifacts: {artifact_uri}")
    
    try:
        # Initialize Vertex AI
        aiplatform.init(project=project_id, location=location)
        
        # Upload model to Model Registry
        logger.info("\n📤 Uploading model to Vertex AI Model Registry...")
        
        model = aiplatform.Model.upload(
            display_name=model_name,
            description=model_description,
            artifact_uri=artifact_uri,
            serving_container_image_uri=serving_container_image,
            serving_container_environment_variables={
                "MODEL_ID": artifact_uri,
                "DEPLOY_SOURCE": "model_garden"
            },
            labels={
                "model_type": "text-to-sql",
                "base_model": "xiyan-sql-qwencoder-7b",
                "fine_tuned": "true"
            }
        )
        
        logger.info(f"✅ Model uploaded!")
        logger.info(f"   Model ID: {model.name}")
        
        # Create endpoint
        endpoint_name = f"{model_name}-endpoint-v2"
        logger.info(f"\n🎯 Creating endpoint: {endpoint_name}")
        
        endpoint = aiplatform.Endpoint.create(
            display_name=endpoint_name,
            description=f"vLLM endpoint for {model_name}"
        )
        logger.info(f"✅ Endpoint created: {endpoint.name}")
        
        # Deploy model to endpoint
        logger.info("\n🚀 Deploying model to endpoint...")
        logger.info("   Machine: g2-standard-8 (with NVIDIA L4 GPU)")
        logger.info("   This will take 15-20 minutes...")
        
        deployed_model = endpoint.deploy(
            model=model,
            deployed_model_display_name=f"{model_name}-deployment",
            machine_type="g2-standard-8",
            accelerator_type="NVIDIA_L4",
            accelerator_count=1,
            traffic_percentage=100,
            min_replica_count=1,
            max_replica_count=1,
            enable_access_logging=True,
            service_account=f"vanna-sqlcoder-sa@{project_id}.iam.gserviceaccount.com"
        )
        
        logger.info(f"\n✅ Deployment complete!")
        logger.info(f"\n📊 Deployment Summary:")
        logger.info(f"   Model: {model_name}")
        logger.info(f"   Endpoint ID: {endpoint.name}")
        logger.info(f"   Machine: g2-standard-8 with NVIDIA L4 GPU")
        
        # Get endpoint details
        endpoint_id = endpoint.name.split('/')[-1]
        logger.info(f"\n🔗 Endpoint Details:")
        logger.info(f"   Endpoint ID: {endpoint_id}")
        logger.info(f"   Prediction URL: https://{location}-aiplatform.googleapis.com/v1/{endpoint.resource_name}:predict")
        
        return model, endpoint
        
    except Exception as e:
        logger.error(f"❌ Deployment failed: {e}")
        import traceback
        traceback.print_exc()
        raise

def main():
    """Main function"""
    logger.info("🏥 IasoQL AgiliMed Healthcare - Vertex AI Deployment")
    logger.info("=" * 70)
    
    try:
        model, endpoint = deploy_model()
        
        print(f"\n🎉 SUCCESS! Model deployed to Vertex AI")
        print(f"\n📋 Model Console:")
        print(f"   https://console.cloud.google.com/vertex-ai/models/{model.name.split('/')[-1]}?project={project_id}")
        print(f"\n📋 Endpoint Console:")
        print(f"   https://console.cloud.google.com/vertex-ai/endpoints/{endpoint.name.split('/')[-1]}?project={project_id}")
        
    except Exception as e:
        print(f"\n❌ Deployment failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    project_id = "nexuscare-463413"
    main()