#!/bin/bash

# Auto-shutdown script for IasoQL VM when idle
# Add this to the VM's crontab to run every 5 minutes

IDLE_THRESHOLD=300  # 5 minutes in seconds
LOG_FILE="/var/log/iasoql-idle-monitor.log"

# Check if vLLM server is receiving requests
check_activity() {
    # Check nginx/vllm access logs for recent activity
    if [ -f /var/log/vllm-access.log ]; then
        last_request=$(stat -c %Y /var/log/vllm-access.log)
        current_time=$(date +%s)
        idle_time=$((current_time - last_request))
        return $idle_time
    fi
    
    # Alternative: Check network connections to port 8080
    active_connections=$(netstat -an | grep :8080 | grep ESTABLISHED | wc -l)
    if [ $active_connections -gt 0 ]; then
        return 0  # Active
    fi
    
    return 999999  # No activity detected
}

# Main logic
check_activity
idle_seconds=$?

echo "$(date): Idle for $idle_seconds seconds" >> $LOG_FILE

if [ $idle_seconds -gt $IDLE_THRESHOLD ]; then
    echo "$(date): Shutting down due to inactivity" >> $LOG_FILE
    # Grace period announcement
    wall "System will shutdown in 2 minutes due to inactivity"
    sleep 120
    shutdown -h now
fi