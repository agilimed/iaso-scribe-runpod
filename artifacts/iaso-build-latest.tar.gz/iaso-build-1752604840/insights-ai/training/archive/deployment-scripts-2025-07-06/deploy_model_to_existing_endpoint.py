#!/usr/bin/env python3
"""
Deploy model to existing endpoint
"""

import os
import sys
from google.cloud import aiplatform
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def deploy_model():
    """Deploy model to existing endpoint"""
    
    # Configuration
    project_id = "nexuscare-463413"
    location = "us-central1"
    model_id = "5953357385639657472"
    endpoint_id = "5853655870256185344"
    
    logger.info(f"🚀 Deploying model to existing endpoint")
    logger.info(f"📍 Location: {location}")
    logger.info(f"📦 Model ID: {model_id}")
    logger.info(f"🎯 Endpoint ID: {endpoint_id}")
    
    try:
        # Initialize Vertex AI
        aiplatform.init(project=project_id, location=location)
        
        # Get the model and endpoint
        model = aiplatform.Model(model_name=model_id)
        endpoint = aiplatform.Endpoint(endpoint_name=endpoint_id)
        
        logger.info(f"✅ Found model: {model.display_name}")
        logger.info(f"✅ Found endpoint: {endpoint.display_name}")
        
        # Deploy model to endpoint
        logger.info("\n🚀 Deploying model to endpoint...")
        logger.info("   Machine: g2-standard-8 (with NVIDIA L4 GPU)")
        logger.info("   This will take 10-15 minutes...")
        
        deployed_model = endpoint.deploy(
            model=model,
            deployed_model_display_name="iasoql-agilimed-healthcare",
            machine_type="g2-standard-8",
            accelerator_type="NVIDIA_L4",
            accelerator_count=1,
            traffic_percentage=100,
            min_replica_count=1,
            max_replica_count=2,
            enable_access_logging=True,
            service_account=f"vanna-sqlcoder-sa@{project_id}.iam.gserviceaccount.com"
        )
        
        logger.info(f"\n✅ Deployment complete!")
        logger.info(f"\n📊 Deployment Summary:")
        logger.info(f"   Model: {model.display_name}")
        logger.info(f"   Endpoint: {endpoint.display_name}")
        logger.info(f"   Endpoint URL: https://{location}-aiplatform.googleapis.com/v1/{endpoint.resource_name}:predict")
        
        return endpoint
        
    except Exception as e:
        logger.error(f"❌ Deployment failed: {e}")
        import traceback
        traceback.print_exc()
        raise

def main():
    """Main function"""
    logger.info("🏥 Deploying IasoQL to Existing Endpoint")
    logger.info("=" * 70)
    
    try:
        endpoint = deploy_model()
        
        print(f"\n🎉 SUCCESS! Model deployed")
        print(f"\n📋 Endpoint is ready at:")
        print(f"   https://us-central1-aiplatform.googleapis.com/v1/{endpoint.resource_name}:predict")
        print(f"\n💡 The model will take 10-15 minutes to initialize")
        
    except Exception as e:
        print(f"\n❌ Deployment failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()