#!/bin/bash

# Complete setup script for IasoQL VM with container control

echo "🚀 Setting up IasoQL VM with Container Control"
echo "============================================="

# Configuration
PROJECT_ID="nexuscare-463413"
ZONE="us-central1-a"
INSTANCE_NAME="iasoql-inference-vm"
MACHINE_TYPE="n1-standard-8"
GPU_TYPE="nvidia-tesla-t4"
BOOT_DISK_SIZE="150"  # Extra space for model

# Create comprehensive startup script
cat > /tmp/iasoql_startup_complete.sh << 'STARTUP_SCRIPT'
#!/bin/bash
set -e

LOG_FILE="/var/log/iasoql-setup.log"
echo "🚀 Starting IasoQL VM setup at $(date)" | tee $LOG_FILE

# Update system
echo "📦 Updating system packages..." | tee -a $LOG_FILE
apt-get update
apt-get install -y curl git python3-pip jq

# Install Docker
echo "🐳 Installing Docker..." | tee -a $LOG_FILE
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh
usermod -aG docker $USER

# Install NVIDIA drivers and container toolkit
echo "🎮 Installing NVIDIA drivers..." | tee -a $LOG_FILE
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
  sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
  tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
apt-get update
apt-get install -y cuda-drivers nvidia-container-toolkit
nvidia-ctk runtime configure --runtime=docker
systemctl restart docker

# Wait for Docker to be ready
sleep 10

# Create model directory
echo "📁 Creating model directory..." | tee -a $LOG_FILE
mkdir -p /model
chmod 777 /model

# Download model from GCS
echo "📥 Downloading IasoQL model (14.2GB)..." | tee -a $LOG_FILE
gsutil -m cp -r gs://nexuscare-ai-training/models/iasoql-merged-complete/* /model/
echo "✅ Model downloaded successfully" | tee -a $LOG_FILE

# Pull vLLM image
echo "🐳 Pulling vLLM Docker image..." | tee -a $LOG_FILE
docker pull vllm/vllm-openai:latest

# Create container control script
cat > /usr/local/bin/iasoql-control << 'CONTROL_SCRIPT'
#!/bin/bash

CONTAINER_NAME="iasoql-server"
MODEL_PATH="/model"
LOG_FILE="/var/log/iasoql-container.log"

case "$1" in
    start)
        echo "🚀 Starting IasoQL container..."
        
        # Check if container exists
        if docker ps -a --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
            docker start $CONTAINER_NAME
            echo "✅ Container starting (existing)..."
        else
            # Create new container
            docker run -d \
                --name $CONTAINER_NAME \
                --gpus all \
                -v $MODEL_PATH:/model \
                -p 8080:8080 \
                --restart unless-stopped \
                --log-driver json-file \
                --log-opt max-size=10m \
                --log-opt max-file=3 \
                vllm/vllm-openai:latest \
                --model /model \
                --host 0.0.0.0 \
                --port 8080 \
                --dtype bfloat16 \
                --max-model-len 8192 \
                --gpu-memory-utilization 0.95 \
                --trust-remote-code
            echo "✅ Container created and starting..."
        fi
        
        # Wait for health check
        echo "⏳ Waiting for model to load..."
        for i in {1..60}; do
            if curl -s http://localhost:8080/health > /dev/null 2>&1; then
                echo "✅ IasoQL is ready!"
                echo "📊 Model info:"
                curl -s http://localhost:8080/v1/models | jq
                break
            fi
            sleep 5
            echo "   Still loading... ($i/60)"
        done
        ;;
        
    stop)
        echo "🛑 Stopping IasoQL container..."
        docker stop $CONTAINER_NAME
        echo "✅ Container stopped (GPU released)"
        ;;
        
    restart)
        $0 stop
        sleep 2
        $0 start
        ;;
        
    status)
        echo "📊 IasoQL Status:"
        if docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
            echo "✅ Container: RUNNING"
            echo "🔗 Endpoint: http://$(curl -s ifconfig.me):8080"
            echo "📈 GPU Usage:"
            nvidia-smi --query-gpu=name,memory.used,memory.total,utilization.gpu --format=csv
        else
            echo "❌ Container: STOPPED"
        fi
        ;;
        
    logs)
        docker logs -f $CONTAINER_NAME
        ;;
        
    test)
        echo "🧪 Testing IasoQL..."
        curl -X POST http://localhost:8080/v1/completions \
            -H "Content-Type: application/json" \
            -d '{
                "model": "/model",
                "prompt": "SELECT * FROM Patient",
                "max_tokens": 100,
                "temperature": 0.1
            }' | jq
        ;;
        
    *)
        echo "Usage: $0 {start|stop|restart|status|logs|test}"
        exit 1
        ;;
esac
CONTROL_SCRIPT

chmod +x /usr/local/bin/iasoql-control

# Create systemd service for auto-start (optional)
cat > /etc/systemd/system/iasoql.service << 'SERVICE_FILE'
[Unit]
Description=IasoQL Inference Server
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/local/bin/iasoql-control start
ExecStop=/usr/local/bin/iasoql-control stop

[Install]
WantedBy=multi-user.target
SERVICE_FILE

# Create cost monitoring script
cat > /usr/local/bin/iasoql-cost << 'COST_SCRIPT'
#!/bin/bash

echo "💰 IasoQL Cost Monitor"
echo "===================="

# Check if container is running
if docker ps --format '{{.Names}}' | grep -q "iasoql-server"; then
    CONTAINER_STATUS="RUNNING"
    HOURLY_COST="0.20"
else
    CONTAINER_STATUS="STOPPED"
    HOURLY_COST="0.08"
fi

echo "📊 Current Status: $CONTAINER_STATUS"
echo "💵 Current Cost: \$$HOURLY_COST/hour"
echo ""
echo "📈 Cost Projections:"
echo "   Daily: \$$(echo "$HOURLY_COST * 24" | bc)"
echo "   Weekly: \$$(echo "$HOURLY_COST * 168" | bc)"
echo "   Monthly: \$$(echo "$HOURLY_COST * 730" | bc)"
echo ""
echo "💡 Tips:"
echo "   - Stop container when not in use: iasoql-control stop"
echo "   - Container startup time: ~2-3 minutes"
echo "   - VM startup time (if stopped): ~5-7 minutes"
COST_SCRIPT

chmod +x /usr/local/bin/iasoql-cost

# Enable and start the service
systemctl daemon-reload
# Don't auto-start on boot to save costs
# systemctl enable iasoql

echo "✅ IasoQL VM setup complete!" | tee -a $LOG_FILE
echo "📝 Available commands:" | tee -a $LOG_FILE
echo "   iasoql-control {start|stop|status|logs|test}" | tee -a $LOG_FILE
echo "   iasoql-cost - View cost information" | tee -a $LOG_FILE

STARTUP_SCRIPT

# Create the VM
echo "📦 Creating preemptible GPU VM..."
gcloud compute instances create $INSTANCE_NAME \
    --project=$PROJECT_ID \
    --zone=$ZONE \
    --machine-type=$MACHINE_TYPE \
    --accelerator="type=$GPU_TYPE,count=1" \
    --preemptible \
    --maintenance-policy=TERMINATE \
    --image-family=ubuntu-2204-lts \
    --image-project=ubuntu-os-cloud \
    --boot-disk-size=$BOOT_DISK_SIZE \
    --boot-disk-type=pd-balanced \
    --metadata-from-file startup-script=/tmp/iasoql_startup_complete.sh \
    --scopes=https://www.googleapis.com/auth/cloud-platform \
    --tags=http-server,iasoql \
    --labels=purpose=inference,model=iasoql

# Create firewall rule
echo "🔥 Setting up firewall..."
gcloud compute firewall-rules create allow-iasoql-inference \
    --allow tcp:8080 \
    --source-ranges 0.0.0.0/0 \
    --target-tags iasoql \
    --description "Allow IasoQL inference on port 8080" \
    2>/dev/null || echo "Firewall rule already exists"

# Wait and get details
sleep 10
EXTERNAL_IP=$(gcloud compute instances describe $INSTANCE_NAME --zone=$ZONE --format='get(networkInterfaces[0].accessConfigs[0].natIP)')
INTERNAL_IP=$(gcloud compute instances describe $INSTANCE_NAME --zone=$ZONE --format='get(networkInterfaces[0].networkIP)')

# Create local control script
cat > ./control_iasoql.sh << LOCAL_SCRIPT
#!/bin/bash
# Local control script for IasoQL VM

PROJECT_ID="$PROJECT_ID"
ZONE="$ZONE"
INSTANCE_NAME="$INSTANCE_NAME"
EXTERNAL_IP="$EXTERNAL_IP"

case "\$1" in
    start)
        echo "🚀 Starting IasoQL container..."
        gcloud compute ssh \$INSTANCE_NAME --zone=\$ZONE --command="sudo iasoql-control start"
        echo "🔗 Access at: http://\$EXTERNAL_IP:8080"
        ;;
    stop)
        echo "🛑 Stopping IasoQL container..."
        gcloud compute ssh \$INSTANCE_NAME --zone=\$ZONE --command="sudo iasoql-control stop"
        ;;
    status)
        gcloud compute ssh \$INSTANCE_NAME --zone=\$ZONE --command="sudo iasoql-control status"
        ;;
    logs)
        gcloud compute ssh \$INSTANCE_NAME --zone=\$ZONE --command="sudo iasoql-control logs"
        ;;
    ssh)
        gcloud compute ssh \$INSTANCE_NAME --zone=\$ZONE
        ;;
    test)
        echo "🧪 Testing IasoQL endpoint..."
        curl -X POST http://\$EXTERNAL_IP:8080/v1/completions \
            -H "Content-Type: application/json" \
            -d '{
                "model": "/model",
                "prompt": "SELECT * FROM Patient WHERE active = true",
                "max_tokens": 100,
                "temperature": 0.1
            }' | jq
        ;;
    setup-logs)
        echo "📜 Viewing setup logs..."
        gcloud compute ssh \$INSTANCE_NAME --zone=\$ZONE --command="sudo tail -f /var/log/iasoql-setup.log"
        ;;
    cost)
        gcloud compute ssh \$INSTANCE_NAME --zone=\$ZONE --command="sudo iasoql-cost"
        ;;
    *)
        echo "Usage: \$0 {start|stop|status|logs|ssh|test|setup-logs|cost}"
        echo ""
        echo "Commands:"
        echo "  start       - Start the IasoQL container"
        echo "  stop        - Stop the container (save GPU costs)"  
        echo "  status      - Check container and GPU status"
        echo "  logs        - View container logs"
        echo "  ssh         - SSH into the VM"
        echo "  test        - Test the API endpoint"
        echo "  setup-logs  - View initial setup progress"
        echo "  cost        - View cost information"
        ;;
esac
LOCAL_SCRIPT

chmod +x ./control_iasoql.sh

# Display summary
echo ""
echo "✅ Deployment Initiated!"
echo "======================="
echo ""
echo "📊 VM Details:"
echo "   Name: $INSTANCE_NAME"
echo "   Zone: $ZONE"
echo "   Type: Preemptible (max 24h)"
echo "   GPU: NVIDIA Tesla T4"
echo "   External IP: $EXTERNAL_IP"
echo "   Internal IP: $INTERNAL_IP"
echo ""
echo "💰 Cost Structure:"
echo "   Container Running: \$0.20/hour"
echo "   Container Stopped: \$0.08/hour"
echo "   VM Stopped: \$0.005/hour (disk only)"
echo ""
echo "⏱️ Setup Progress:"
echo "   The VM is now installing dependencies and downloading the model."
echo "   This will take ~10-15 minutes."
echo ""
echo "📝 Monitor setup progress:"
echo "   ./control_iasoql.sh setup-logs"
echo ""
echo "🚀 Once ready, start the container:"
echo "   ./control_iasoql.sh start"
echo ""
echo "🛠️ Other commands:"
echo "   ./control_iasoql.sh status"
echo "   ./control_iasoql.sh stop"
echo "   ./control_iasoql.sh test"