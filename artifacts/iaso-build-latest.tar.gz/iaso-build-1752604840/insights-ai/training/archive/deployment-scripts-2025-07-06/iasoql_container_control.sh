#!/bin/bash

# Control just the Docker container, not the VM
# This keeps model cached in memory/disk

case "$1" in
    start)
        echo "🚀 Starting IasoQL container..."
        # Check if container exists
        if docker ps -a | grep -q iasoql-server; then
            docker start iasoql-server
        else
            # First time - create container
            docker run -d \
                --name iasoql-server \
                --gpus all \
                -v /model:/model \
                -p 8080:8080 \
                --restart unless-stopped \
                vllm/vllm-openai:latest \
                --model /model \
                --host 0.0.0.0 \
                --port 8080 \
                --dtype bfloat16 \
                --max-model-len 8192 \
                --gpu-memory-utilization 0.95 \
                --trust-remote-code
        fi
        echo "✅ Container started - ready in 2-3 minutes"
        ;;
        
    stop)
        echo "🛑 Stopping IasoQL container..."
        docker stop iasoql-server
        echo "✅ Container stopped (VM still running at reduced cost)"
        # When container is stopped, GPU is not utilized
        # VM cost drops to just compute: ~$0.08/hour
        ;;
        
    status)
        echo "📊 Container status:"
        docker ps -a --filter name=iasoql-server --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
        ;;
        
    logs)
        docker logs -f iasoql-server
        ;;
esac