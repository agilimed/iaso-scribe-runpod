#!/bin/bash

# Deploy IasoQL merged model on preemptible GPU VM

echo "🚀 Deploying IasoQL AgiliMed Healthcare Baseline on Preemptible GPU VM"
echo "=" | tr ' ' '=' | head -c 70 && echo

# Configuration
PROJECT_ID="nexuscare-463413"
ZONE="europe-west4-a"  # Has preemptible GPUs
INSTANCE_NAME="iasoql-agilimed-healthcare"
MACHINE_TYPE="n1-standard-8"
GPU_TYPE="nvidia-tesla-t4"
BOOT_DISK_SIZE="100"
MODEL_PATH="gs://nexuscare-ai-training/models/iasoql-merged-complete/"

# Step 1: Create the VM instance
echo "📦 Creating preemptible GPU VM instance..."

gcloud compute instances create $INSTANCE_NAME \
    --project=$PROJECT_ID \
    --zone=$ZONE \
    --machine-type=$MACHINE_TYPE \
    --accelerator="type=$GPU_TYPE,count=1" \
    --preemptible \
    --maintenance-policy=TERMINATE \
    --restart-on-failure \
    --image-family=ubuntu-2204-lts \
    --image-project=ubuntu-os-cloud \
    --boot-disk-size=$BOOT_DISK_SIZE \
    --boot-disk-type=pd-ssd \
    --metadata-from-file startup-script=startup_script.sh \
    --scopes=https://www.googleapis.com/auth/cloud-platform \
    --tags=http-server,https-server \
    --network-tier=PREMIUM

# Step 2: Create firewall rule for port 8080
echo "🔥 Creating firewall rule..."
gcloud compute firewall-rules create allow-iasoql-8080 \
    --allow tcp:8080 \
    --source-ranges 0.0.0.0/0 \
    --target-tags http-server \
    --description "Allow access to IasoQL on port 8080" \
    2>/dev/null || echo "Firewall rule already exists"

# Step 3: Get the external IP
echo "🔗 Getting instance details..."
sleep 10  # Wait for instance to get IP

EXTERNAL_IP=$(gcloud compute instances describe $INSTANCE_NAME \
    --zone=$ZONE \
    --format='get(networkInterfaces[0].accessConfigs[0].natIP)')

echo ""
echo "✅ Deployment initiated!"
echo ""
echo "📊 Instance Details:"
echo "   Name: $INSTANCE_NAME"
echo "   Zone: $ZONE"
echo "   Type: Preemptible"
echo "   GPU: 1x NVIDIA Tesla T4"
echo "   External IP: $EXTERNAL_IP"
echo ""
echo "🔄 The instance is now starting up and will:"
echo "   1. Install NVIDIA drivers"
echo "   2. Install CUDA and Docker"
echo "   3. Download the merged model from GCS"
echo "   4. Start vLLM server on port 8080"
echo ""
echo "⏱️  This process takes about 10-15 minutes"
echo ""
echo "📝 Check startup progress:"
echo "   gcloud compute instances get-serial-port-output $INSTANCE_NAME --zone=$ZONE"
echo ""
echo "🔍 SSH into the instance:"
echo "   gcloud compute ssh $INSTANCE_NAME --zone=$ZONE"
echo ""
echo "🌐 Once ready, access the API at:"
echo "   http://$EXTERNAL_IP:8080/v1/completions"
echo ""
echo "💡 Test with:"
echo "   curl -X POST http://$EXTERNAL_IP:8080/v1/completions \\"
echo "     -H 'Content-Type: application/json' \\"
echo "     -d '{\"model\": \"iasoql-agilimed-healthcare-baseline\", \"prompt\": \"SELECT\", \"max_tokens\": 100}'"