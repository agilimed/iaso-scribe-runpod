#!/bin/bash

echo "🚀 Updating IasoQL endpoint with merged model..."

# Update the existing iasoql-endpoint to use the merged model
gcloud run services update iasoql-endpoint \
  --region us-central1 \
  --command="bash,-c" \
  --args='echo "📥 Downloading IasoQL merged model..." && \
mkdir -p /tmp/model && \
gsutil -m cp -r gs://nexuscare-ai-training/models/iasoql-merged-complete/* /tmp/model/ && \
echo "✅ Model downloaded" && \
echo "🚀 Starting vLLM server with merged IasoQL model..." && \
python -m vllm.entrypoints.openai.api_server \
  --model /tmp/model \
  --host 0.0.0.0 \
  --port 8080 \
  --dtype bfloat16 \
  --max-model-len 8192 \
  --gpu-memory-utilization 0.95 \
  --disable-log-requests \
  --trust-remote-code' \
  --set-env-vars="MODEL_NAME=iasoql-agilimed-healthcare-baseline"

echo "✅ Update complete!"
echo ""
echo "📊 Check status:"
echo "   gcloud run services describe iasoql-endpoint --region us-central1"