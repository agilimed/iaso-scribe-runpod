#!/usr/bin/env python3
"""
Deploy IasoQL merged model to Vertex AI
"""

import os
import sys
from google.cloud import aiplatform
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def deploy_model():
    """Deploy the merged IasoQL model to Vertex AI"""
    
    # Configuration
    project_id = "nexuscare-463413"
    location = "us-central1"
    model_name = "iasoql-agilimed-healthcare-baseline"
    model_description = "IasoQL Healthcare SQL model - Fine-tuned XiYanSQL for FHIR R4 ClickHouse queries"
    
    # Model artifact location
    artifact_uri = "gs://nexuscare-ai-training/models/iasoql-merged-complete/"
    
    # Use a pre-built container that supports Hugging Face models
    serving_container_image = "us-docker.pkg.dev/vertex-ai/prediction/pytorch-gpu.2-0:latest"
    
    logger.info(f"🚀 Deploying {model_name} to Vertex AI")
    logger.info(f"📍 Location: {location}")
    logger.info(f"📦 Model artifacts: {artifact_uri}")
    
    try:
        # Initialize Vertex AI
        aiplatform.init(project=project_id, location=location)
        
        # Step 1: Upload model without artifact_uri requirement
        logger.info("\n📤 Uploading model to Vertex AI Model Registry...")
        
        # For custom prediction, we don't need artifact_uri in the traditional sense
        model = aiplatform.Model.upload(
            display_name=model_name,
            description=model_description,
            serving_container_image_uri=serving_container_image,
            serving_container_predict_route="/predictions/transformers",
            serving_container_health_route="/ping",
            serving_container_environment_variables={
                "MODEL_NAME": model_name,
                "MODEL_BASE_PATH": artifact_uri,
                "PROTOCOL": "v2",
                "TRANSFORMERS_CACHE": "/tmp/transformers_cache",
                "PYTORCH_CUDA_ALLOC_CONF": "expandable_segments:True",
                "CUDA_VISIBLE_DEVICES": "0"
            },
            labels={
                "model_type": "text-to-sql",
                "base_model": "xiyan-sql-qwencoder-7b",
                "fine_tuned": "true",
                "training_dataset": "fhir-clickhouse-v8"
            }
        )
        
        logger.info(f"✅ Model uploaded!")
        logger.info(f"   Model ID: {model.name}")
        logger.info(f"   Model resource name: {model.resource_name}")
        
        # Step 2: Create endpoint
        endpoint_name = f"{model_name}-endpoint"
        logger.info(f"\n🎯 Creating endpoint: {endpoint_name}")
        
        # Check if endpoint exists
        endpoints = aiplatform.Endpoint.list(
            filter=f'display_name="{endpoint_name}"',
            order_by="create_time desc"
        )
        
        if endpoints:
            endpoint = endpoints[0]
            logger.info(f"   Found existing endpoint: {endpoint.name}")
            # Undeploy existing models if any
            if endpoint.traffic_split:
                logger.info("   Undeploying existing models...")
                endpoint.undeploy_all()
        else:
            endpoint = aiplatform.Endpoint.create(
                display_name=endpoint_name,
                description=f"Endpoint for {model_name}",
                labels={
                    "model": model_name.lower().replace(" ", "_"),
                    "type": "text-to-sql"
                }
            )
            logger.info(f"✅ New endpoint created!")
        
        logger.info(f"   Endpoint ID: {endpoint.name}")
        
        # Step 3: Deploy model to endpoint
        logger.info("\n🚀 Deploying model to endpoint...")
        logger.info("   Machine: n1-standard-8 with NVIDIA Tesla T4")
        logger.info("   This will take 10-15 minutes...")
        
        deployed_model = endpoint.deploy(
            model=model,
            deployed_model_display_name=model_name,
            machine_type="n1-standard-8",
            accelerator_type="NVIDIA_TESLA_T4",
            accelerator_count=1,
            traffic_percentage=100,
            min_replica_count=1,
            max_replica_count=3,
            enable_access_logging=True,
            service_account=f"vanna-sqlcoder-sa@{project_id}.iam.gserviceaccount.com"
        )
        
        logger.info(f"\n✅ Deployment complete!")
        logger.info(f"\n📊 Deployment Details:")
        logger.info(f"   Model: {model_name}")
        logger.info(f"   Endpoint: {endpoint.display_name}")
        logger.info(f"   Endpoint ID: {endpoint.name}")
        logger.info(f"   Location: {location}")
        logger.info(f"   Machine Type: n1-standard-8 with T4 GPU")
        
        # Get prediction endpoint
        logger.info(f"\n🔗 Prediction endpoint:")
        logger.info(f"   {endpoint.predict_http_uri}")
        
        return model, endpoint
        
    except Exception as e:
        logger.error(f"❌ Deployment failed: {e}")
        import traceback
        traceback.print_exc()
        raise

def main():
    """Main function"""
    logger.info("🏥 IasoQL AgiliMed Healthcare Baseline - Vertex AI Deployment")
    logger.info("=" * 70)
    
    try:
        model, endpoint = deploy_model()
        
        print(f"\n🎉 SUCCESS! Model deployed to Vertex AI")
        print(f"\n📋 Summary:")
        print(f"   Model: iasoql-agilimed-healthcare-baseline")
        print(f"   Endpoint URL: {endpoint.predict_http_uri}")
        print(f"   Status: Ready for predictions")
        
        # Test command
        print(f"\n💡 Test with:")
        print(f"   gcloud ai endpoints predict {endpoint.name.split('/')[-1]} \\")
        print(f"     --region={endpoint.location} \\")
        print(f"     --json-request=test_request.json")
        
    except Exception as e:
        print(f"\n❌ Deployment failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()