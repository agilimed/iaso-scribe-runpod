#!/bin/bash

# Build IasoQL container following xiyan-baseline pattern

echo "🏗️ Building IasoQL Container"
echo "============================"

PROJECT_ID="nexuscare-463413"
IMAGE_NAME="iasoql-merged"
IMAGE_TAG="latest"
FULL_IMAGE="${PROJECT_ID}/${IMAGE_NAME}:${IMAGE_TAG}"

# Create Dockerfile based on xiyan-baseline pattern
cat > /tmp/Dockerfile.iasoql << 'DOCKERFILE'
FROM nvidia/cuda:11.8-devel-ubuntu20.04

# Set environment variables
ENV DEBIAN_FRONTEND=noninteractive
ENV PYTHONUNBUFFERED=1

# Install system dependencies
RUN apt-get update && apt-get install -y \
    python3 \
    python3-pip \
    curl \
    git \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
RUN pip3 install --no-cache-dir \
    vllm==0.2.6 \
    transformers \
    torch \
    fastapi \
    uvicorn \
    pydantic

# Create app directory
WORKDIR /app

# Download the merged model
RUN pip3 install google-cloud-storage
COPY download_model.py /app/
RUN python3 download_model.py

# Copy server script
COPY server.py /app/

# Expose port
EXPOSE 8080

# Start command
CMD ["python3", "server.py"]
DOCKERFILE

# Create model download script
cat > /tmp/download_model.py << 'PYTHON'
#!/usr/bin/env python3
import os
import subprocess

def download_model():
    print("📥 Downloading IasoQL merged model...")
    
    # Create model directory
    os.makedirs("/app/model", exist_ok=True)
    
    # Download from GCS
    cmd = [
        "gsutil", "-m", "cp", "-r",
        "gs://nexuscare-ai-training/models/iasoql-merged-complete/*",
        "/app/model/"
    ]
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        print("✅ Model downloaded successfully")
    else:
        print(f"❌ Download failed: {result.stderr}")
        # Fallback: install gsutil and try again
        subprocess.run(["pip3", "install", "gsutil"])
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise Exception(f"Model download failed: {result.stderr}")

if __name__ == "__main__":
    download_model()
PYTHON

# Create server script (same pattern as xiyan-baseline)
cat > /tmp/server.py << 'SERVER'
#!/usr/bin/env python3
import os
import logging
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn
from vllm import LLM, SamplingParams

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Request/Response models
class CompletionRequest(BaseModel):
    model: str = "iasoql"
    prompt: str
    max_tokens: int = 100
    temperature: float = 0.1
    top_p: float = 0.9
    stop: Optional[List[str]] = None

class CompletionResponse(BaseModel):
    choices: List[dict]
    model: str
    usage: dict

# Initialize vLLM
logger.info("🚀 Initializing IasoQL model...")
model_path = "/app/model"

try:
    llm = LLM(
        model=model_path,
        dtype="bfloat16",
        max_model_len=8192,
        gpu_memory_utilization=0.95,
        trust_remote_code=True
    )
    logger.info("✅ Model loaded successfully")
except Exception as e:
    logger.error(f"❌ Model loading failed: {e}")
    raise

# FastAPI app
app = FastAPI(title="IasoQL AgiliMed Healthcare API")

@app.get("/health")
def health_check():
    return {"status": "healthy", "model": "iasoql-agilimed-healthcare"}

@app.get("/v1/models")
def list_models():
    return {
        "data": [
            {
                "id": "iasoql-agilimed-healthcare",
                "object": "model",
                "created": 1640995200,
                "owned_by": "nexuscare"
            }
        ]
    }

@app.post("/v1/completions", response_model=CompletionResponse)
def create_completion(request: CompletionRequest):
    try:
        # Create sampling parameters
        sampling_params = SamplingParams(
            temperature=request.temperature,
            top_p=request.top_p,
            max_tokens=request.max_tokens,
            stop=request.stop
        )
        
        # Generate completion
        outputs = llm.generate([request.prompt], sampling_params)
        output = outputs[0]
        
        # Format response
        response = CompletionResponse(
            choices=[
                {
                    "text": output.outputs[0].text,
                    "index": 0,
                    "finish_reason": output.outputs[0].finish_reason
                }
            ],
            model=request.model,
            usage={
                "prompt_tokens": len(output.prompt_token_ids),
                "completion_tokens": len(output.outputs[0].token_ids),
                "total_tokens": len(output.prompt_token_ids) + len(output.outputs[0].token_ids)
            }
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Completion failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    logger.info(f"🚀 Starting IasoQL server on port {port}")
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=port,
        log_level="info"
    )
SERVER

# Build the container
echo "🔨 Building container..."
cd /tmp
docker build -f Dockerfile.iasoql -t gcr.io/$FULL_IMAGE .

# Push to Container Registry
echo "📤 Pushing to Container Registry..."
docker push gcr.io/$FULL_IMAGE

echo ""
echo "✅ Container built and pushed!"
echo "🐳 Image: gcr.io/$FULL_IMAGE"
echo ""
echo "🚀 Now deploy with:"
echo "gcloud run deploy iasoql-agilimed-healthcare \\"
echo "  --image gcr.io/$FULL_IMAGE \\"
echo "  --region us-central1 \\"
echo "  --memory 32Gi \\"
echo "  --cpu 8 \\"
echo "  --timeout 3600 \\"
echo "  --allow-unauthenticated"