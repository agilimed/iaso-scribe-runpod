#!/usr/bin/env python3
"""
Deploy existing model to endpoint
"""

import os
import sys
from google.cloud import aiplatform
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def deploy_model():
    """Deploy existing model to endpoint"""
    
    # Configuration
    project_id = "nexuscare-463413"
    location = "us-central1"
    model_id = "5953357385639657472"  # Using the newer model
    endpoint_name = "iasoql-agilimed-healthcare-baseline-endpoint"
    
    logger.info(f"🚀 Deploying existing model to endpoint")
    logger.info(f"📍 Location: {location}")
    logger.info(f"📦 Model ID: {model_id}")
    
    try:
        # Initialize Vertex AI
        aiplatform.init(project=project_id, location=location)
        
        # Get the model
        model = aiplatform.Model(model_name=model_id)
        logger.info(f"✅ Found model: {model.display_name}")
        
        # Create endpoint
        logger.info(f"\n🎯 Creating endpoint: {endpoint_name}")
        endpoint = aiplatform.Endpoint.create(
            display_name=endpoint_name,
            description="Endpoint for IasoQL AgiliMed Healthcare SQL model"
        )
        logger.info(f"✅ Endpoint created: {endpoint.name}")
        
        # Deploy model to endpoint
        logger.info("\n🚀 Deploying model to endpoint...")
        logger.info("   Machine: g2-standard-8 (with NVIDIA L4 GPU)")
        logger.info("   This will take 10-15 minutes...")
        
        deployed_model = endpoint.deploy(
            model=model,
            deployed_model_display_name="iasoql-agilimed-healthcare-deployment",
            machine_type="g2-standard-8",  # L4 GPU machine
            traffic_percentage=100,
            min_replica_count=1,
            max_replica_count=2,
            enable_access_logging=True,
            service_account=f"vanna-sqlcoder-sa@{project_id}.iam.gserviceaccount.com"
        )
        
        logger.info(f"\n✅ Deployment complete!")
        logger.info(f"\n📊 Deployment Summary:")
        logger.info(f"   Model: {model.display_name}")
        logger.info(f"   Endpoint: {endpoint.display_name}")
        logger.info(f"   Endpoint ID: {endpoint.name}")
        logger.info(f"   Status: Ready for predictions")
        
        # Get endpoint details
        endpoint_id = endpoint.name.split('/')[-1]
        logger.info(f"\n🔗 Endpoint URL:")
        logger.info(f"   https://{location}-aiplatform.googleapis.com/v1/{endpoint.resource_name}:predict")
        
        return endpoint
        
    except Exception as e:
        logger.error(f"❌ Deployment failed: {e}")
        import traceback
        traceback.print_exc()
        raise

def main():
    """Main function"""
    logger.info("🏥 Deploying IasoQL Model to Endpoint")
    logger.info("=" * 70)
    
    try:
        endpoint = deploy_model()
        
        print(f"\n🎉 SUCCESS! Model deployed to endpoint")
        print(f"\n📋 Test command:")
        print(f"   curl -X POST \\")
        print(f"     https://us-central1-aiplatform.googleapis.com/v1/{endpoint.resource_name}:predict \\")
        print(f"     -H 'Authorization: Bearer $(gcloud auth print-access-token)' \\")
        print(f"     -H 'Content-Type: application/json' \\")
        print(f"     -d '{{\"instances\": [{{\"prompt\": \"List all patients\", \"max_tokens\": 100}}]}}'")
        
    except Exception as e:
        print(f"\n❌ Deployment failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()