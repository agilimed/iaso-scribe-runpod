#!/bin/bash

# Deploy IasoQL using same pattern as sqlcoder-endpoint

echo "🚀 Deploying IasoQL to Cloud Run (Simple Approach)"
echo "================================================="

# Configuration
PROJECT_ID="nexuscare-463413"
REGION="us-central1"
SERVICE_NAME="iasoql-agilimed-healthcare"

# Step 1: Check if we can modify the existing xiyan container to use our model
echo "📋 Checking existing sqlcoder service..."
gcloud run services describe sqlcoder-endpoint --region=$REGION --format="value(spec.template.spec.containers[0].image)"

# Step 2: Create new service using same container but different model path
echo "🚀 Deploying IasoQL service..."
gcloud run deploy $SERVICE_NAME \
    --image gcr.io/$PROJECT_ID/xiyan-baseline:latest \
    --region $REGION \
    --platform managed \
    --allow-unauthenticated \
    --memory 32Gi \
    --cpu 8 \
    --timeout 3600 \
    --concurrency 1 \
    --max-instances 2 \
    --min-instances 0 \
    --port 8080 \
    --set-env-vars "MODEL_PATH=gs://nexuscare-ai-training/models/iasoql-merged-complete/,MODEL_NAME=iasoql-agilimed-healthcare,GPU_MEMORY_UTILIZATION=0.95" \
    --cpu-throttling \
    --execution-environment gen2

# Get service URL
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region=$REGION --format="value(status.url)")

echo ""
echo "✅ Deployment Complete!"
echo "======================"
echo ""
echo "🔗 Service URL: $SERVICE_URL"
echo "📊 API Endpoint: $SERVICE_URL/v1/completions"
echo ""
echo "🧪 Test the deployment:"
echo "curl -X POST $SERVICE_URL/v1/completions \\"
echo "  -H 'Content-Type: application/json' \\"
echo "  -d '{\"model\": \"iasoql\", \"prompt\": \"SELECT * FROM Patient WHERE active = true\", \"max_tokens\": 100}'"
echo ""
echo "📊 Monitor logs:"
echo "gcloud run logs tail $SERVICE_NAME --region=$REGION"
echo ""
echo "💰 Cost: Same as sqlcoder-endpoint (~$0.10-0.20 per request)"