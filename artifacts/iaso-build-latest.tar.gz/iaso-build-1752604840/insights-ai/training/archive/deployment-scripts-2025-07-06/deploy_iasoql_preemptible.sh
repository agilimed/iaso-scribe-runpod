#!/bin/bash

# Deploy IasoQL on preemptible GPU VM

echo "🚀 Deploying IasoQL on Preemptible GPU VM"
echo "========================================"

# Configuration
PROJECT_ID="nexuscare-463413"
ZONE="us-central1-a"  # Has both T4 and L4
INSTANCE_NAME="iasoql-preemptible"
MACHINE_TYPE="n1-standard-8"
GPU_TYPE="nvidia-tesla-t4"  # Cheaper option
BOOT_DISK_SIZE="100"

# Create startup script
cat > /tmp/iasoql_startup.sh << 'EOF'
#!/bin/bash
echo "🚀 Starting IasoQL setup..." | tee /var/log/iasoql-setup.log

# Install Docker and NVIDIA drivers
apt-get update
apt-get install -y docker.io
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
apt-get update
apt-get install -y cuda-drivers nvidia-container-toolkit
systemctl restart docker

# Create directory and download model
mkdir -p /model
gsutil -m cp -r gs://nexuscare-ai-training/models/iasoql-merged-complete/* /model/
echo "✅ Model downloaded" | tee -a /var/log/iasoql-setup.log

# Run vLLM container
docker run -d \
  --name iasoql-server \
  --gpus all \
  -v /model:/model \
  -p 8080:8080 \
  --restart unless-stopped \
  vllm/vllm-openai:latest \
  --model /model \
  --host 0.0.0.0 \
  --port 8080 \
  --dtype bfloat16 \
  --max-model-len 8192 \
  --gpu-memory-utilization 0.95 \
  --trust-remote-code

echo "🎉 IasoQL setup complete!" | tee -a /var/log/iasoql-setup.log
EOF

# Create the VM
echo "📦 Creating preemptible GPU VM..."
gcloud compute instances create $INSTANCE_NAME \
    --project=$PROJECT_ID \
    --zone=$ZONE \
    --machine-type=$MACHINE_TYPE \
    --accelerator="type=$GPU_TYPE,count=1" \
    --preemptible \
    --maintenance-policy=TERMINATE \
    --image-family=ubuntu-2204-lts \
    --image-project=ubuntu-os-cloud \
    --boot-disk-size=$BOOT_DISK_SIZE \
    --boot-disk-type=pd-ssd \
    --metadata-from-file startup-script=/tmp/iasoql_startup.sh \
    --scopes=https://www.googleapis.com/auth/cloud-platform \
    --tags=http-server \
    --network-tier=STANDARD

# Create firewall rule
gcloud compute firewall-rules create allow-iasoql-8080 \
    --allow tcp:8080 \
    --source-ranges 0.0.0.0/0 \
    --target-tags http-server \
    2>/dev/null || echo "Firewall rule exists"

# Get external IP
sleep 5
EXTERNAL_IP=$(gcloud compute instances describe $INSTANCE_NAME --zone=$ZONE --format='get(networkInterfaces[0].accessConfigs[0].natIP)')

echo ""
echo "✅ Deployment initiated!"
echo ""
echo "📊 Instance Details:"
echo "   Name: $INSTANCE_NAME"
echo "   Zone: $ZONE"
echo "   Type: Preemptible (auto-terminates after 24h)"
echo "   GPU: 1x NVIDIA Tesla T4"
echo "   Cost: ~\$0.20/hour"
echo "   External IP: $EXTERNAL_IP"
echo ""
echo "⏱️  Setup takes 10-15 minutes. Check progress:"
echo "   gcloud compute ssh $INSTANCE_NAME --zone=$ZONE --command='tail -f /var/log/iasoql-setup.log'"
echo ""
echo "🌐 Once ready, test at:"
echo "   curl http://$EXTERNAL_IP:8080/v1/models"