#!/usr/bin/env python3
"""
Submit IasoQL-7B-Healthcare training job to us-west1 region

Try different region for better GPU quota availability.
"""

import os
import sys
from google.cloud import aiplatform
import logging
import time

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def submit_training_job():
    """Submit training job to us-west1 with T4 GPU"""
    
    # Configuration - different region
    project_id = "nexuscare-463413"
    location = "us-west1"  # Different region
    staging_bucket = "gs://nexuscare-ai-training"
    container_uri = "gcr.io/nexuscare-463413/xiyan-sql-trainer:latest"
    service_account = "vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com"
    
    logger.info(f"Trying us-west1 region for better GPU quota availability")
    logger.info(f"Submitting IasoQL-7B-Healthcare training job to: {location}")
    
    try:
        # Initialize AI Platform with different region
        aiplatform.init(
            project=project_id,
            location=location,
            staging_bucket=staging_bucket
        )
        
        # Environment variables for training
        env_vars = {
            'WANDB_PROJECT': 'iasoql-healthcare-training',
            'WANDB_ENTITY': 'iaso-agilimed',
            'DATASET_PATH': 'gs://nexuscare-ai-training/datasets/fhir-clickhouse-training-dataset-v8-FINAL.json',
            'BATCH_SIZE': '1',  # Conservative for T4
            'GRADIENT_ACCUMULATION': '8',
            'EPOCHS': '3',
            'LEARNING_RATE': '2e-4',
            'WANDB_API_KEY': '323fd63ce2cc1ef969e76fb51f3e1a2ad42d1556',
            'CUDA_VISIBLE_DEVICES': '0'
        }
        
        # Create custom container training job
        job = aiplatform.CustomContainerTrainingJob(
            display_name="iasoql-7b-healthcare-uswest1-v1",
            container_uri=container_uri,
            command=["python", "train_xiyan_sql.py"]
        )
        
        logger.info("Submitting to us-west1 with T4 GPU...")
        
        # Submit job with T4 GPU
        job.submit(
            replica_count=1,
            machine_type="n1-standard-4",
            accelerator_type="NVIDIA_TESLA_T4",
            accelerator_count=1,
            boot_disk_type="pd-ssd",
            boot_disk_size_gb=200,
            
            service_account=service_account,
            base_output_dir=staging_bucket + "/iasoql-7b-healthcare",
            environment_variables=env_vars,
            timeout=43200,  # 12 hours
            restart_job_on_worker_restart=True,
            enable_web_access=True,
            sync=False
        )
        
        time.sleep(5)
        
        logger.info("✅ Training job submitted to us-west1!")
        logger.info(f"Job Name: {job.display_name}")
        logger.info(f"Monitor at: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={project_id}")
        
        return job
        
    except Exception as e:
        logger.error(f"❌ us-west1 also failed: {e}")
        raise

def main():
    """Try multiple regions for GPU availability"""
    
    regions_to_try = ["us-west1", "us-east1", "europe-west1"]
    
    for region in regions_to_try:
        try:
            logger.info(f"🌍 Trying region: {region}")
            # Update the region in the function and try
            job = submit_training_job()
            print(f"✅ Success in {region}!")
            return
        except Exception as e:
            logger.error(f"❌ {region} failed: {e}")
            continue
    
    print("\n🚨 All regions failed. You need to request GPU quota increase:")
    print("1. Visit: https://console.cloud.google.com/iam-admin/quotas?project=nexuscare-463413")
    print("2. Search for 'Custom model training Nvidia T4 GPUs'")
    print("3. Request quota increase to 2-4 units")
    print("4. Justification: 'Healthcare AI model training for research'")

if __name__ == "__main__":
    main()