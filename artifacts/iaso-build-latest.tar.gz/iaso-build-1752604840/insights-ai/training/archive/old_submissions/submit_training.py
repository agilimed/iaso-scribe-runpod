#!/usr/bin/env python3
"""
Submit XiYanSQL-QwenCoder-7B-2504 training job to Google Cloud Vertex AI

This script submits a custom container training job to Vertex AI with optimized
hardware configuration for fine-tuning the 7B parameter model.
"""

import os
import sys
from google.cloud import aiplatform
from google.cloud.aiplatform import gapic as aip
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def check_build_status():
    """Check if the container build is complete"""
    import subprocess
    
    try:
        result = subprocess.run([
            'gcloud', 'builds', 'list', 
            '--filter=source.repoSource.repoName=github_agilimed_nexuscare-platform',
            '--limit=1', 
            '--format=value(status)'
        ], capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0:
            status = result.stdout.strip()
            logger.info(f"Latest build status: {status}")
            return status == 'SUCCESS'
        else:
            logger.warning("Could not check build status, proceeding anyway")
            return True
    except Exception as e:
        logger.warning(f"Build status check failed: {e}, proceeding anyway")
        return True

def submit_training_job():
    """Submit training job to Vertex AI"""
    
    # Configuration
    project_id = "nexuscare-463413"
    location = "us-central1"
    staging_bucket = "gs://nexuscare-ai-training"
    container_uri = "gcr.io/nexuscare-463413/xiyan-sql-trainer:latest"
    service_account = "vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com"
    
    logger.info(f"Submitting training job to project: {project_id}")
    
    # Check build status
    if not check_build_status():
        logger.warning("Container build may still be in progress, but proceeding with job submission")
    
    try:
        # Initialize AI Platform
        aiplatform.init(
            project=project_id,
            location=location,
            staging_bucket=staging_bucket
        )
        
        # Create custom container training job
        job = aiplatform.CustomContainerTrainingJob(
            display_name="iasoql-7b-healthcare-training-v1",
            container_uri=container_uri,
            command=["python", "train_xiyan_sql.py"]
        )
        
        # Environment variables for training
        env_vars = {
            'WANDB_PROJECT': 'iasoql-healthcare-training',
            'WANDB_ENTITY': 'agilimed',
            'DATASET_PATH': 'gs://nexuscare-ai-training/datasets/fhir-clickhouse-training-dataset-v8-FINAL.json',
            'BATCH_SIZE': '2',
            'GRADIENT_ACCUMULATION': '4',
            'EPOCHS': '3',
            'LEARNING_RATE': '2e-4',
            'WANDB_API_KEY': os.getenv('WANDB_API_KEY', '323fd63ce2cc1ef969e76fb51f3e1a2ad42d1556'),
            'CUDA_VISIBLE_DEVICES': '0'
        }
        
        # Submit job with A100 GPU configuration
        logger.info("Submitting training job to Vertex AI...")
        try:
            model = job.run(
                # Hardware configuration optimized for 7B model
                replica_count=1,
                machine_type="n1-standard-8",  # 8 vCPUs, 30GB RAM
                accelerator_type="NVIDIA_TESLA_A100",  # 40GB VRAM - better for 7B model
                accelerator_count=1,
                boot_disk_type="pd-ssd",
                boot_disk_size_gb=200,  # Larger disk for model + data
                
                # Training configuration
                sync=False,  # Don't wait for completion
                service_account=service_account,
                environment_variables=env_vars,
                base_output_dir=staging_bucket + "/iasoql-7b-healthcare",
                
                # Timeout and restart policy
                timeout=28800,  # 8 hours max training time
                restart_job_on_worker_restart=True,
                enable_web_access=True,  # For debugging
            )
            logger.info("Job submission successful!")
        except Exception as e:
            logger.error(f"Job submission failed: {e}")
            logger.error(f"Error type: {type(e)}")
            raise
        
        logger.info(f"Training job submitted successfully!")
        logger.info(f"Training Output directory:")
        logger.info(f"{staging_bucket}/training-output")
        logger.info(f"Monitor progress at: https://console.cloud.google.com/vertex-ai/training/custom-jobs")
        
        # Print cost estimation
        logger.info("Cost Estimation:")
        logger.info("- A100 GPU: ~$3.67/hour")
        logger.info("- n1-standard-8: ~$0.38/hour") 
        logger.info("- Total: ~$4.05/hour")
        logger.info("- Expected 8-hour training: ~$32")
        
        return job
        
    except Exception as e:
        logger.error(f"Failed to submit training job: {e}")
        raise

def check_job_status(job_name: str):
    """Check the status of a training job"""
    
    project_id = "nexuscare-463413"
    location = "us-central1"
    
    aiplatform.init(project=project_id, location=location)
    
    try:
        job = aiplatform.CustomTrainingJob.get(job_name)
        logger.info(f"Job status: {job.state}")
        logger.info(f"Job details: {job.gca_resource}")
        return job
    except Exception as e:
        logger.error(f"Failed to get job status: {e}")
        raise

def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Submit XiYanSQL training job to Vertex AI')
    parser.add_argument('--action', choices=['submit', 'status'], default='submit',
                       help='Action to perform')
    parser.add_argument('--job-name', type=str, 
                       help='Job name for status check')
    
    args = parser.parse_args()
    
    if args.action == 'submit':
        job = submit_training_job()
        print(f"\n✅ Training job submitted: {job.resource_name}")
        print(f"Monitor at: https://console.cloud.google.com/vertex-ai/training/custom-jobs")
        
    elif args.action == 'status':
        if not args.job_name:
            print("Error: --job-name required for status check")
            sys.exit(1)
        check_job_status(args.job_name)

if __name__ == "__main__":
    main()