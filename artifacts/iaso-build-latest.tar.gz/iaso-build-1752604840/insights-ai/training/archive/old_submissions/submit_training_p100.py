#!/usr/bin/env python3
"""
Submit IasoQL-7B-Healthcare training job with P100 GPU (available quota!)

P100 provides good balance of performance and cost for 7B model training.
"""

import os
import sys
from google.cloud import aiplatform
import logging
import time

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def submit_training_job():
    """Submit training job to Vertex AI with P100 GPU"""
    
    # Configuration
    project_id = "nexuscare-463413"
    location = "us-central1"  # P100 available here
    staging_bucket = "gs://nexuscare-ai-training"
    container_uri = "gcr.io/nexuscare-463413/xiyan-sql-trainer:latest"
    service_account = "vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com"
    
    logger.info(f"🚀 Submitting IasoQL-7B-Healthcare training with P100 GPU")
    logger.info(f"Location: {location} (P100 quota available)")
    
    try:
        # Initialize AI Platform
        aiplatform.init(
            project=project_id,
            location=location,
            staging_bucket=staging_bucket
        )
        
        # Environment variables for training
        env_vars = {
            'WANDB_PROJECT': 'iasoql-healthcare-training',
            'WANDB_ENTITY': 'iaso-agilimed',
            'DATASET_PATH': 'gs://nexuscare-ai-training/datasets/fhir-clickhouse-training-dataset-v8-FINAL.json',
            'BATCH_SIZE': '2',  # Good for P100's 16GB VRAM
            'GRADIENT_ACCUMULATION': '4',
            'EPOCHS': '3',
            'LEARNING_RATE': '2e-4',
            'WANDB_API_KEY': '323fd63ce2cc1ef969e76fb51f3e1a2ad42d1556',
            'CUDA_VISIBLE_DEVICES': '0'
        }
        
        # Create custom container training job
        job = aiplatform.CustomContainerTrainingJob(
            display_name="iasoql-7b-healthcare-p100-v1",
            container_uri=container_uri,
            command=["python", "train_xiyan_sql.py"]
        )
        
        logger.info("Submitting job with P100 GPU configuration...")
        
        # Submit job with P100 GPU
        job.submit(
            # Hardware configuration for P100
            replica_count=1,
            machine_type="n1-standard-8",  # 8 vCPUs, 30GB RAM
            accelerator_type="NVIDIA_TESLA_P100",  # 16GB VRAM
            accelerator_count=1,
            boot_disk_type="pd-ssd",
            boot_disk_size_gb=200,
            
            # Training configuration
            service_account=service_account,
            base_output_dir=staging_bucket + "/iasoql-7b-healthcare",
            environment_variables=env_vars,
            
            # Timeout and restart policy
            timeout=43200,  # 12 hours max training time
            restart_job_on_worker_restart=True,
            enable_web_access=True,
            
            # Don't wait for completion
            sync=False
        )
        
        # Wait a moment for the job to be created
        time.sleep(5)
        
        logger.info("✅ Training job submitted successfully!")
        logger.info(f"Job Name: {job.display_name}")
        logger.info(f"Job Resource Name: {job.resource_name}")
        logger.info(f"Job State: {job.state}")
        logger.info(f"Output Directory: {staging_bucket}/iasoql-7b-healthcare")
        logger.info(f"Monitor at: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={project_id}")
        
        # Print cost estimation for P100
        logger.info("\n💰 P100 GPU Cost Estimation:")
        logger.info("- P100 GPU: ~$1.46/hour")
        logger.info("- n1-standard-8: ~$0.38/hour") 
        logger.info("- Storage & network: ~$0.05/hour")
        logger.info("- Total: ~$1.89/hour")
        logger.info("- Expected 12-hour training: ~$23")
        logger.info("✨ Good balance of speed and cost!")
        
        return job
        
    except Exception as e:
        logger.error(f"❌ Failed to submit training job: {e}")
        logger.error(f"Error type: {type(e)}")
        import traceback
        traceback.print_exc()
        raise

def main():
    """Main function"""
    logger.info("🏛️ IasoQL-7B-Healthcare Training Job Submission")
    logger.info("Named after Iaso, Greek goddess of healing and recovery")
    logger.info("Using P100 GPU - Best balance of performance and cost")
    logger.info("=" * 60)
    
    try:
        job = submit_training_job()
        print(f"\n✅ Training job submitted successfully!")
        print(f"🏛️ IasoQL-7B-Healthcare training is now running on P100 GPU!")
        print(f"📊 Monitor at: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project=nexuscare-463413")
        print(f"📈 W&B Dashboard: https://wandb.ai/iaso-agilimed/iasoql-healthcare-training")
        print(f"⏱️ Expected completion: ~12 hours")
        print(f"💰 Total cost: ~$23")
        
    except Exception as e:
        print(f"\n❌ Training job submission failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()