#!/usr/bin/env python3
"""
Wait for Docker build to complete and then submit training job
"""

import time
import subprocess
import sys
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def check_build_status(build_id: str):
    """Check if the build is complete"""
    try:
        result = subprocess.run([
            'gcloud', 'builds', 'describe', build_id,
            '--format=value(status)'
        ], capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0:
            status = result.stdout.strip()
            return status
        else:
            logger.error(f"Failed to check build status: {result.stderr}")
            return None
    except Exception as e:
        logger.error(f"Error checking build status: {e}")
        return None

def wait_for_build_completion(build_id: str, max_wait_minutes: int = 60):
    """Wait for build to complete"""
    
    logger.info(f"Waiting for build {build_id} to complete...")
    logger.info(f"Maximum wait time: {max_wait_minutes} minutes")
    
    start_time = datetime.now()
    
    while True:
        status = check_build_status(build_id)
        
        if status == 'SUCCESS':
            logger.info("✅ Build completed successfully!")
            return True
        elif status == 'FAILURE':
            logger.error("❌ Build failed!")
            return False
        elif status == 'CANCELLED':
            logger.error("❌ Build was cancelled!")
            return False
        elif status == 'TIMEOUT':
            logger.error("❌ Build timed out!")
            return False
        elif status in ['WORKING', 'QUEUED']:
            elapsed = (datetime.now() - start_time).total_seconds() / 60
            logger.info(f"🔄 Build status: {status} (elapsed: {elapsed:.1f} minutes)")
            
            if elapsed > max_wait_minutes:
                logger.error(f"❌ Timeout: Build took longer than {max_wait_minutes} minutes")
                return False
        else:
            logger.warning(f"⚠️ Unknown build status: {status}")
        
        # Wait 30 seconds before checking again
        time.sleep(30)

def submit_training_job():
    """Submit the training job"""
    logger.info("🚀 Submitting training job...")
    
    try:
        result = subprocess.run([
            'python3', 'submit_training.py', '--action', 'submit'
        ], check=True, capture_output=True, text=True)
        
        logger.info("✅ Training job submitted successfully!")
        logger.info(result.stdout)
        return True
        
    except subprocess.CalledProcessError as e:
        logger.error(f"❌ Failed to submit training job: {e}")
        logger.error(f"Error output: {e.stderr}")
        return False

def main():
    """Main function"""
    
    # The build ID from the previous build
    build_id = "66f34dc0-031b-45a2-b3fa-d3adf24772c8"
    
    logger.info("🔧 XiYanSQL-QwenCoder-7B-2504 Training Pipeline")
    logger.info("=" * 60)
    
    # Step 1: Wait for build completion
    build_success = wait_for_build_completion(build_id, max_wait_minutes=60)
    
    if not build_success:
        logger.error("Build failed or timed out. Cannot proceed with training.")
        sys.exit(1)
    
    # Step 2: Submit training job
    training_success = submit_training_job()
    
    if training_success:
        logger.info("🎉 Training pipeline initiated successfully!")
        logger.info("📊 Monitor training progress:")
        logger.info("- Vertex AI Console: https://console.cloud.google.com/vertex-ai/training/custom-jobs")
        logger.info("- Weights & Biases: https://wandb.ai/nexuscare/nexuscare-sql-training")
        logger.info("💰 Expected cost: ~$32 for 8-hour training")
    else:
        logger.error("Failed to submit training job.")
        sys.exit(1)

if __name__ == "__main__":
    main()