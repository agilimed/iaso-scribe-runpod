#!/usr/bin/env python3
"""
Submit IasoQL-7B-Healthcare training job with CPU-only (immediate execution)

CPU training will be slower but same quality. No GPU quota needed.
"""

import os
import sys
from google.cloud import aiplatform
import logging
import time

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def submit_cpu_training_job():
    """Submit CPU-only training job - works immediately"""
    
    # Configuration
    project_id = "nexuscare-463413"
    location = "us-central1"
    staging_bucket = "gs://nexuscare-ai-training"
    container_uri = "gcr.io/nexuscare-463413/xiyan-sql-trainer:latest"
    service_account = "vanna-sqlcoder-sa@nexuscare-463413.iam.gserviceaccount.com"
    
    logger.info(f"🚀 Submitting IasoQL-7B-Healthcare CPU training (no quota limits)")
    
    try:
        # Initialize AI Platform
        aiplatform.init(
            project=project_id,
            location=location,
            staging_bucket=staging_bucket
        )
        
        # Environment variables for CPU training (optimized)
        env_vars = {
            'WANDB_PROJECT': 'iasoql-healthcare-training',
            'WANDB_ENTITY': 'iaso-agilimed',
            'DATASET_PATH': 'gs://nexuscare-ai-training/datasets/fhir-clickhouse-training-dataset-v8-FINAL.json',
            'BATCH_SIZE': '1',  # Small batch for CPU
            'GRADIENT_ACCUMULATION': '16',  # More accumulation for effective batch size
            'EPOCHS': '3',
            'LEARNING_RATE': '2e-4',
            'WANDB_API_KEY': '323fd63ce2cc1ef969e76fb51f3e1a2ad42d1556',
            'FORCE_CPU_TRAINING': 'true',  # Force CPU mode
        }
        
        # Create custom container training job
        job = aiplatform.CustomContainerTrainingJob(
            display_name="iasoql-7b-healthcare-cpu-v1",
            container_uri=container_uri,
            command=["python", "train_xiyan_sql.py"]
        )
        
        logger.info("Submitting CPU training job (no GPU quota required)...")
        
        # Submit job with high-memory CPU configuration
        job.submit(
            replica_count=1,
            machine_type="n1-highmem-16",  # 16 vCPUs, 104GB RAM - good for 7B model
            # No accelerator needed
            boot_disk_type="pd-ssd",
            boot_disk_size_gb=200,
            
            service_account=service_account,
            base_output_dir=staging_bucket + "/iasoql-7b-healthcare",
            environment_variables=env_vars,
            timeout=86400,  # 24 hours for CPU training
            restart_job_on_worker_restart=True,
            enable_web_access=True,
            sync=False
        )
        
        time.sleep(5)
        
        logger.info("✅ CPU training job submitted successfully!")
        logger.info(f"Job Name: {job.display_name}")
        logger.info(f"Job Resource Name: {job.resource_name}")
        logger.info(f"Job State: {job.state}")
        logger.info(f"Monitor at: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project={project_id}")
        
        # Cost estimation for CPU
        logger.info("\n💰 CPU Training Cost Estimation:")
        logger.info("- n1-highmem-16: ~$0.95/hour")
        logger.info("- Storage & network: ~$0.05/hour")
        logger.info("- Total: ~$1.00/hour")
        logger.info("- Expected 20-24 hour training: ~$24")
        logger.info("- Same quality as GPU, just slower!")
        
        return job
        
    except Exception as e:
        logger.error(f"❌ CPU training failed: {e}")
        import traceback
        traceback.print_exc()
        raise

def request_gpu_quota():
    """Request GPU quota increase via gcloud"""
    logger.info("🔧 Requesting GPU quota increase in parallel...")
    
    # This opens the quota page - manual action needed
    quota_url = "https://console.cloud.google.com/iam-admin/quotas?project=nexuscare-463413&pageState=(%22allQuotasTable%22:(%22f%22:%22%255B%257B_22k_22_3A_22Service_22_2C_22t_22_3A10_2C_22v_22_3A_22_5C_22Vertex%2520AI%2520API_5C_22_22%257D%255D%22))"
    
    print(f"\n🔗 GPU Quota Request URL:")
    print(f"{quota_url}")
    print(f"\n📋 Search for: 'Custom model training Nvidia T4 GPUs'")
    print(f"📋 Request: 4 units")
    print(f"📋 Justification: 'Healthcare AI model training for FHIR data analysis research'")

def main():
    """Submit CPU training and request GPU quota"""
    logger.info("🏛️ IasoQL-7B-Healthcare Training - CPU Version")
    logger.info("Named after Iaso, Greek goddess of healing and recovery")
    logger.info("CPU training: Same quality, longer time, no quota limits")
    logger.info("=" * 60)
    
    try:
        # Start CPU training immediately
        job = submit_cpu_training_job()
        
        print(f"\n✅ IasoQL-7B-Healthcare CPU training started!")
        print(f"🏛️ Training on 16 vCPUs, 104GB RAM")
        print(f"📊 Monitor: https://console.cloud.google.com/vertex-ai/training/custom-jobs?project=nexuscare-463413")
        print(f"📈 W&B: https://wandb.ai/iaso-agilimed/iasoql-healthcare-training")
        print(f"⏱️ Expected: 20-24 hours")
        print(f"💰 Cost: ~$24 total")
        
        # Also request GPU quota for future runs
        request_gpu_quota()
        
        print(f"\n🎯 Action Items:")
        print(f"1. ✅ CPU training started (running now)")
        print(f"2. 🔧 Request GPU quota via the URL above")
        print(f"3. 📊 Monitor progress in W&B dashboard")
        
    except Exception as e:
        print(f"\n❌ Training submission failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()