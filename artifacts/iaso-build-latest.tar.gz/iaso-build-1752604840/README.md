# IASO ECR Build Package

This package contains everything needed to build and push IASO Docker images to ECR.

## Prerequisites

- Docker installed and running
- AWS CLI configured with appropriate credentials
- Access to ECR in us-west-2 region

## Quick Start

### Option 1: Using AWS Cloud Shell (Recommended)

1. Upload this package to AWS Cloud Shell:
   - Open AWS Cloud Shell in your browser
   - Click "Actions" → "Upload file"
   - Upload the iaso-build.tar.gz file

2. Extract and run:
   ```bash
   tar xzf iaso-build.tar.gz
   cd iaso-build
   ./cloud-build.sh
   ```

### Option 2: Using EC2 Instance

1. Launch an Amazon Linux 2 instance with:
   - Instance type: t3.large or larger
   - IAM role with ECR access
   - Security group allowing SSH

2. Install Docker:
   ```bash
   sudo yum update -y
   sudo amazon-linux-extras install docker -y
   sudo service docker start
   sudo usermod -a -G docker ec2-user
   # Log out and back in for group changes
   ```

3. Upload and run:
   ```bash
   # Upload iaso-build.tar.gz to the instance
   tar xzf iaso-build.tar.gz
   cd iaso-build
   ./cloud-build.sh
   ```

### Option 3: Using GitHub Codespaces or GitPod

If you have access to GitHub Codespaces or GitPod, you can:

1. Upload this package
2. Install AWS CLI
3. Configure AWS credentials
4. Run `./cloud-build.sh`

## Build Options

- Build with default tag (latest):
  ```bash
  ./cloud-build.sh
  ```

- Build with custom tag:
  ```bash
  ./cloud-build.sh v1.0.0
  ```

## Troubleshooting

1. **Permission Denied**: Make sure to run Docker commands with appropriate permissions
2. **ECR Login Failed**: Ensure your AWS credentials have ECR access
3. **Build Failed**: Check Dockerfile paths and build context

## Next Steps

After successful build, deploy to EKS using:
```bash
cd infrastructure/terraform
./deploy.sh -e dev -a apply
```
