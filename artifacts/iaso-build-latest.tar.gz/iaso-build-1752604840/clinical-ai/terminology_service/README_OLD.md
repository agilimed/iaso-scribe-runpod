# NexusCare Terminology Service

**Version:** 0.1.0

## Overview

The Terminology Service is a high-performance search and matching service for clinical terminologies. It provides fast and accurate concept matching, pattern matching, and terminology lookup capabilities using MeiliSearch as its core search engine.

## Key Features

1. **Concept Search**
   - Fast full-text search across clinical terminologies
   - Support for multiple vocabulary sources
   - Relevance-based ranking
   - Fuzzy matching capabilities

2. **Pattern Matching**
   - Efficient pattern matching using trie data structure
   - Support for common medical terms
   - Fast lookup of standardized concepts
   - Caching for improved performance

3. **Terminology Integration**
   - Integration with MeiliSearch
   - Support for multiple terminology sources
   - Standardized concept representation
   - Cross-vocabulary mapping

## Dependencies

### Core Dependencies
- Python 3.10+
- FastAPI
- Uvicorn
- MeiliSearch
- Python-dotenv
- Pydantic
- httpx

## Configuration

The service requires the following environment variables:

```env
# Service Configuration
TERMINOLOGY_SERVICE_PORT=8006

# MeiliSearch Configuration
MEILISEARCH_URL=http://localhost:7700
MEILISEARCH_MASTER_KEY=your_master_key

# Cache Configuration
CACHE_TTL=3600  # in seconds
```

## Setup and Installation

1. **Prerequisites**
   - Python 3.10 or higher
   - MeiliSearch server
   - Required terminology data

2. **Installation**
   ```bash
   # Create and activate virtual environment
   python -m venv venv
   source venv/bin/activate  # or `venv\Scripts\activate` on Windows

   # Install dependencies
   pip install -r requirements.txt
   ```

3. **Running the Service**
   ```bash
   uvicorn main:app --host 0.0.0.0 --port 8006
   ```

## API Endpoints

All endpoints are prefixed with `/api/v1`.

### Health Check
- `GET /health`
  - Checks service status and MeiliSearch connection
  - Returns detailed connection status

### Search Endpoints
- `GET /search`
  - Search for concepts across terminologies
  - Supports query parameters for filtering
  - Returns ranked search results

- `POST /pattern-match`
  - Match patterns against medical terms
  - Uses trie-based matching
  - Returns matched concepts

- `GET /concepts/{concept_id}`
  - Retrieve detailed concept information
  - Returns concept metadata and relationships

## Data Structure

The service uses several key data structures:

1. **Search Index**
   - MeiliSearch index for fast full-text search
   - Optimized for clinical terminology
   - Supports multiple fields and attributes

2. **Pattern Trie**
   - Trie data structure for pattern matching
   - Efficient prefix matching
   - Supports common medical terms

3. **Concept Cache**
   - In-memory cache for frequent concepts
   - Configurable TTL
   - LRU eviction policy

## Integration

The service integrates with other NexusCare components:

1. **AI Processing Service**
   - Provides concept matching for NER
   - Supports entity linking
   - Enables terminology validation

2. **Knowledge Service**
   - Complements detailed concept lookups
   - Provides fast initial matching
   - Supports hierarchical relationships

## Performance Considerations

- Efficient search indexing
- Pattern matching optimization
- Response caching
- Connection pooling

## Error Handling

- Comprehensive error logging
- HTTP status codes for different error types
- Detailed error messages
- MeiliSearch connection error handling

## Security

- CORS configuration
- Environment variable based configuration
- MeiliSearch authentication
- Input validation

## Monitoring

- Health check endpoint
- MeiliSearch connection monitoring
- Search performance tracking
- Error logging

## Future Enhancements

1. **Planned Features**
   - Advanced pattern matching algorithms
   - Support for more terminology sources
   - Improved relevance ranking
   - Custom search filters

2. **Technical Improvements**
   - Implement proper connection pooling
   - Convert to async operations
   - Add authentication/authorization
   - Add comprehensive testing

## Contributing

Please refer to the main project documentation for contribution guidelines.

## License

This service is part of the NexusCare AI backend and is subject to the project's license terms.
