#!/usr/bin/env python3
"""
NexusCare Terminology Service - main.py

Version: 0.4.1 (Fixed f-string SyntaxError, refined filter building)

Overview:
This FastAPI application serves as a high-performance search and matching service
for clinical terminologies. It leverages MeiliSearch as its core search engine.

Key Endpoints:
- GET /health: Checks service health and MeiliSearch connectivity.
- GET /search: Searches for concepts with various filtering options.
- POST /pattern_match: Identifies known clinical terms and patterns in input text.
- GET /concepts/{cui}/codes: Retrieves basic info for a CUI.

Setup:
1. Ensure MeiliSearch is running and accessible.
2. Populate the MeiliSearch index (default: 'concepts_umls_v2') using the
   `load_terminology_to_meili_from_umls_v2.py` script or similar.
3. Set environment variables (see below or in .env file):
   - MEILISEARCH_HOST
   - MEILISEARCH_MASTER_KEY (matches MEILI_API_KEY used by client)
   - MEILISEARCH_INDEX_NAME
"""

import os
import logging
import time
import re
import asyncio
from typing import List, Optional, Dict, Any, Tuple
from functools import lru_cache
import hashlib
import json # For robust cache key generation with dicts
from collections import defaultdict

import meilisearch
import uvicorn
from meilisearch.index import Index as MeiliIndex

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query, Body, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from shared.security import setup_security, verify_token, limiter
from pydantic import BaseModel, Field, ConfigDict
from meilisearch.errors import MeilisearchApiError, MeilisearchCommunicationError, MeilisearchError
# --- Configuration & Setup ---
load_dotenv()

MEILI_HOST = os.getenv("MEILISEARCH_HOST", "http://localhost:7700")
MEILI_API_KEY = os.getenv("MEILISEARCH_API_KEY")
MEILI_INDEX_NAME = os.getenv("MEILISEARCH_INDEX_NAME", "concepts_umls_v2")

ENABLE_CACHE = os.getenv("ENABLE_CACHE", "true").lower() == "true"
CACHE_SIZE = int(os.getenv("CACHE_SIZE", "10240"))
CACHE_TTL = int(os.getenv('CACHE_TTL', 3600))
PARALLEL_CHUNK_SIZE = int(os.getenv("PARALLEL_CHUNK_SIZE", "5000"))

# Configure logging
logger = logging.getLogger("terminology_service")
if not logger.hasHandlers():
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

# --- Global Meilisearch Client & Index ---
meili_client: Optional[meilisearch.Client] = None
concepts_index: Optional[MeiliIndex] = None

# --- Pydantic Models ---
class ConceptHit(BaseModel):
    id: str
    name: str
    source: str
    pretty_name: Optional[str] = None
    tuis: Optional[List[str]] = None
    semantic_types: Optional[List[str]] = None
    definition: Optional[str] = None
    codes_by_sab: Optional[Dict[str, List[str]]] = None
    sabs: Optional[List[str]] = None
    code: Optional[str] = None # Primary code from source if applicable
    vocabulary: Optional[str] = None # Primary vocabulary from source if applicable
    _rankingScore: Optional[float] = None # Changed from ranking_score to match MeiliSearch field name

    model_config = ConfigDict(populate_by_name=True)

class SearchResponse(BaseModel):
    query: str
    filters_applied: Optional[List[str]] = None
    limit: int
    estimated_total_hits: int
    processing_time_ms: Optional[float] = None
    results: List[ConceptHit]

class PatternMatchRequest(BaseModel):
    text: str
    min_term_length: int = Field(3, ge=1)
    max_ngram_size: int = Field(6, ge=1)
    score_threshold: float = Field(0.6, ge=0.1, le=1.0)
    semantic_types: Optional[List[str]] = None
    tuis: Optional[List[str]] = None

class ConceptMatch(BaseModel):
    text: str
    start_char: int
    end_char: int
    concepts: List[ConceptHit]
    score: float

class PatternMatchResponse(BaseModel):
    matches: List[ConceptMatch]
    query_time_ms: float

# --- Caching ---
_search_cache: Dict[str, Tuple[Any, float]] = {}

def get_cache_key(*args, **kwargs) -> str:
    # Sort kwargs by key to ensure stability
    # Convert all args and kwarg values to string to handle various types
    key_parts = [str(arg) for arg in args]
    sorted_kwargs = sorted(kwargs.items())
    for k, v in sorted_kwargs:
        key_parts.append(str(k))
        key_parts.append(str(v)) # Ensure complex objects like lists are consistently stringified
    
    key_string = ":".join(key_parts)
    return hashlib.md5(key_string.encode('utf-8')).hexdigest()

# --- FastAPI App Initialization & Events ---
app = FastAPI(
    title="NexusCare Terminology Service",
    description="Provides search and pattern matching for clinical terminologies.",
    version="0.4.1",
)

# Apply comprehensive security middleware
setup_security(
    app,
    allowed_origins=["http://localhost:3000", "http://localhost:8080"],
    enable_auth=True,
    rate_limit="200/minute",
    trusted_hosts=["localhost", "terminology-service", "*.nexuscare.ai"]
)

@app.on_event("startup")
async def startup_event():
    global meili_client, concepts_index
    logger.info("Terminology Service starting up...")
    if not MEILI_HOST or not MEILI_API_KEY:
        logger.error("Meilisearch Host or API Key not configured. Service will be unhealthy.")
        return
    try:
        meili_client = meilisearch.Client(MEILI_HOST, MEILI_API_KEY)
        if not meili_client.is_healthy():
            logger.warning("Meilisearch initially unhealthy, retrying check after 2s...")
            time.sleep(2)
            meili_client.health()
        concepts_index = meili_client.index(MEILI_INDEX_NAME)
        logger.info(f"Successfully connected to Meilisearch and got index '{MEILI_INDEX_NAME}'.")
    except Exception as e:
        logger.error(f"FATAL: Failed to connect to Meilisearch or get index '{MEILI_INDEX_NAME}': {e}", exc_info=True)
        meili_client = None; concepts_index = None

@app.on_event("shutdown")
async def shutdown_event(): logger.info("Terminology Service shutting down.")

# --- Helper Functions ---
def build_meili_filters_from_params(
    vocabulary: Optional[str] = None,
    source: Optional[str] = None, 
    semantic_types: Optional[List[str]] = None, 
    tuis: Optional[List[str]] = None, 
    sabs: Optional[List[str]] = None,
) -> List[str]:
    filters = []
    # Assuming vocabulary, source, STYs, TUIs, SABs themselves don't contain double quotes.
    # If they could, more complex escaping (e.g., value.replace('"', '\\"')) would be needed inside the f-string.
    if vocabulary: filters.append(f'vocabulary = "{vocabulary}"') # Use the MeiliSearch field name
    if source: filters.append(f'source = "{source}"')
    if semantic_types:
        quoted_types = [f'"{st}"' for st in semantic_types]
        filters.append(f"semantic_types IN [{','.join(quoted_types)}]")
    if tuis:
        quoted_tuis = [f'"{t}"' for t in tuis]
        filters.append(f"tuis IN [{','.join(quoted_tuis)}]")
    if sabs:
        quoted_sabs = [f'"{s}"' for s in sabs]
        filters.append(f"sabs IN [{','.join(quoted_sabs)}]")
    return filters

async def search_term_async(term: str, span: Tuple[int, int], params: Dict[str, Any], cache_key: str) -> Optional[ConceptMatch]:
    """Asynchronously search for a term and create a ConceptMatch if found."""
    if ENABLE_CACHE and cache_key in _search_cache:
        cached_hits, timestamp = _search_cache[cache_key]
        if time.time() - timestamp < CACHE_TTL:
            logger.debug(f"Cache hit for term: {term}")
            hits = cached_hits
        else:
            hits = None
    else:
        hits = None

    if hits is None:
        try:
            meili_results = await asyncio.to_thread(concepts_index.search, term, params)
            hits = [_convert_meili_hit_to_concept_hit(hit) for hit in meili_results.get('hits', [])]
            if ENABLE_CACHE:
                _search_cache[cache_key] = (hits, time.time())
        except Exception as e:
            logger.error(f"Error searching for term '{term}': {e}", exc_info=True)
            return None

    if not hits:
        return None

    # Get the best match (highest score)
    best_hit = max(hits, key=lambda x: x._rankingScore if x._rankingScore is not None else 0)
    score = best_hit._rankingScore if best_hit._rankingScore is not None else 0

    return ConceptMatch(
        text=term,
        start_char=span[0],
        end_char=span[1],
        concepts=hits,
        score=score
    )

def _convert_meili_hit_to_concept_hit(hit_dict: Dict[str, Any]) -> ConceptHit:
    return ConceptHit(
        id=hit_dict.get('id', 'UNKNOWN_ID'),
        name=hit_dict.get('name', 'Unknown Name'),
        source=hit_dict.get('source'), # Let it be None if not present, or set a default if your service logic expects it
        synonyms=hit_dict.get('synonyms', []), # Add this
        semantic_types=hit_dict.get('semantic_types', []),
        tuis=hit_dict.get('tuis', []),
        definition=hit_dict.get('definition'),
        codes_by_sab=hit_dict.get('codes_by_sab', {}),
        sabs=hit_dict.get('sabs', []),
        primary_code_sab=hit_dict.get('primary_code_sab'), # Add this
        primary_code_val=hit_dict.get('primary_code_val'), # Add this
        pretty_name=hit_dict.get('pretty_name', hit_dict.get('name')), # Keep this fallback
        _rankingScore=hit_dict.get('_rankingScore')
        # Remove 'code' and 'vocabulary' if they are fully replaced by primary_code_sab/val
    )

# --- API Endpoints ---
@app.get("/health", summary="Check Service Health", tags=["Health"])
async def health_check():
    # ... (same as before) ...
    if meili_client and meili_client.is_healthy():
        try:
            if concepts_index: concepts_index.fetch_info()
            else: raise Exception("concepts_index not initialized")
            return {"status": "ok", "meilisearch_connection": "healthy", "index_accessible": True, "index_name": MEILI_INDEX_NAME}
        except Exception as e:
            logger.warning(f"Health check: Meilisearch index '{MEILI_INDEX_NAME}' issue: {e}")
            return {"status": "degraded", "meilisearch_connection": "healthy", "index_accessible": False, "detail": str(e)}
    else:
        logger.error("Health check: Meilisearch connection failed or client not initialized.")
        return {"status": "unhealthy", "meilisearch_connection": "failed"}

@app.get("/search", response_model=SearchResponse, summary="Search Clinical Concepts", tags=["Terminology"])
@limiter.limit("100/minute")
async def search_concepts_endpoint(
    request: Request,
    term: str = Query(..., min_length=1, description="The search term."),
    limit: int = Query(10, ge=1, le=100, description="Max number of results."),
    semantic_types: Optional[List[str]] = Query(None, description="Filter: semantic_types array INCLUDES STY name(s)."),
    tuis: Optional[List[str]] = Query(None, description="Filter: tuis array INCLUDES TUI code(s)."),
    sabs: Optional[List[str]] = Query(None, description="Filter: sabs array INCLUDES SAB code(s)."),
    source: Optional[str] = Query(None, description="Filter by source (e.g., 'UMLS', 'ATHENA')."),
    raw_filter: Optional[str] = Query(None, alias="filter", description="Apply a raw Meilisearch filter string."),
    token_payload: dict = Depends(verify_token)
):
    if not concepts_index:
        raise HTTPException(status_code=503, detail="Terminology service index unavailable.")
    start_time = time.time()
    filter_list = build_meili_filters_from_params(
        source=source, semantic_types=semantic_types, tuis=tuis, sabs=sabs
    )
    if raw_filter: filter_list.append(raw_filter)

    search_params = {'limit': limit, 'showRankingScore': True}
    if filter_list: search_params['filter'] = filter_list
    
    cache_key = get_cache_key(term, **search_params) 

    if ENABLE_CACHE and cache_key in _search_cache:
        cached_payload, timestamp = _search_cache[cache_key]
        if time.time() - timestamp < CACHE_TTL:
            logger.debug(f"Cache hit for /search: {term} with filters {filter_list}")
            if isinstance(cached_payload, SearchResponse):
                return cached_payload
            # If cached data is not a SearchResponse, convert it
            return SearchResponse(
                query=term,
                filters_applied=filter_list,
                limit=limit,
                estimated_total_hits=len(cached_payload),
                processing_time_ms=0,
                results=cached_payload
            )

    try:
        logger.info(f"Meili Searching for: '{term}', Params: {search_params}")
        meili_results = concepts_index.search(term, search_params)
        processed_hits = [_convert_meili_hit_to_concept_hit(hit) for hit in meili_results.get('hits', [])]
        
        response = SearchResponse(
            query=term,
            filters_applied=filter_list,
            limit=limit,
            estimated_total_hits=meili_results.get('estimatedTotalHits', 0),
            processing_time_ms=(time.time() - start_time) * 1000,
            results=processed_hits
        )
        
        if ENABLE_CACHE:
            _search_cache[cache_key] = (response, time.time())
            
        return response
    except Exception as e:
        logger.error(f"Error during MeiliSearch for '{term}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Search error: {str(e)}")

def robust_get_ngrams_with_spans(text: str, max_n: int, min_len: int) -> List[Tuple[str, int, int]]:
    """A more robust n-gram generator that handles offsets correctly."""
    results = []
    # Split by sequences of non-word characters, keeping them for offset calculation
    # A word character here is alphanumeric or hyphen (common in medical terms)
    tokens_and_delimiters = re.split(r"([^\w'-]+)", text)
    
    current_offset = 0
    word_items = [] # List of (word_text, start_offset, end_offset)

    for part in tokens_and_delimiters:
        if part is None or part == '':
            continue
        if re.match(r"[\w'-]+", part): # It's a "word"
            word_items.append((part, current_offset, current_offset + len(part)))
        current_offset += len(part)

    for n_val in range(1, max_n + 1):
        for i in range(len(word_items) - n_val + 1):
            ngram_word_list = [word_items[j][0] for j in range(i, i + n_val)]
            ngram_str = " ".join(ngram_word_list)

            if len(ngram_str) < min_len:
                continue

            start_char = word_items[i][1]
            end_char = word_items[i + n_val - 1][2]
            results.append((ngram_str, start_char, end_char))
    return results


@app.post("/pattern_match", response_model=PatternMatchResponse, summary="Identify Clinical Terms in Text", tags=["NLP"])
async def pattern_match_text_endpoint(request: PatternMatchRequest = Body(...)):
    start_time = time.time()
    if not concepts_index:
        raise HTTPException(status_code=503, detail="Meilisearch index not available")

    text_to_search = request.text
    logger.debug(f"Pattern matching request for text (len {len(text_to_search)}): '{text_to_search[:100]}...'")

    # 1. Generate N-grams with Spans
    # Ensure robust_get_ngrams_with_spans is defined correctly in your script
    ngrams_with_spans: List[Tuple[str, int, int]] = robust_get_ngrams_with_spans(
        text_to_search,
        request.max_ngram_size,
        request.min_term_length
    )
    logger.info(f"Generated {len(ngrams_with_spans)} n-grams. First 10: {ngrams_with_spans[:10]}")

    # 2. Deduplicate n-grams (by text) but keep all their original spans
    terms_to_lookup_in_meili = defaultdict(list)
    for term_text, start_char, end_char in ngrams_with_spans:
        # Store original case text for display, but search with lowercase
        terms_to_lookup_in_meili[term_text.lower()].append({
            "original_text": term_text, # Keep original case for the match response
            "start": start_char,
            "end": end_char
        })
    
    logger.info(f"{len(terms_to_lookup_in_meili)} unique (lowercase) terms to search in MeiliSearch.")
    if terms_to_lookup_in_meili:
         logger.debug(f"Sample terms to search: {list(terms_to_lookup_in_meili.keys())[:10]}")


    # 3. Build MeiliSearch filters
    meili_filters = build_meili_filters_from_params(
        semantic_types=request.semantic_types,
        tuis=request.tuis
    )
    
    all_found_concept_matches: List[ConceptMatch] = []
    search_params = {'limit': 3, 'showRankingScore': True} # Get top 3 concepts per term
    if meili_filters:
        search_params['filter'] = meili_filters

    # 4. Search for each unique term in MeiliSearch (sequentially for easier debugging first)
    for term_lower, list_of_spans_for_term in terms_to_lookup_in_meili.items():
        if not term_lower.strip(): # Skip empty terms if any were generated
            continue

        cache_key = get_cache_key(term_lower, **search_params)
        concept_hits_for_term: Optional[List[ConceptHit]] = None

        if ENABLE_CACHE and cache_key in _search_cache:
            cached_data, timestamp = _search_cache[cache_key]
            if time.time() - timestamp < CACHE_TTL:
                logger.debug(f"Pattern_match CACHE HIT for term: '{term_lower}'")
                concept_hits_for_term = cached_data
        
        if concept_hits_for_term is None: # Not in cache or expired
            try:
                logger.debug(f"Pattern_match MEILI SEARCH for term: '{term_lower}', params: {search_params}")
                # Use asyncio.to_thread for the blocking MeiliSearch SDK call
                meili_results = await asyncio.to_thread(concepts_index.search, term_lower, search_params)
                logger.debug(f"RAW MeiliSearch results for '{term_lower}': {meili_results}") # <<< ADD THIS LINE
                raw_hits = meili_results.get('hits', [])
                concept_hits_for_term = [_convert_meili_hit_to_concept_hit(hit) for hit in raw_hits]
                if ENABLE_CACHE:
                    _search_cache[cache_key] = (concept_hits_for_term, time.time())
                logger.debug(f"MeiliSearch for '{term_lower}' returned {len(concept_hits_for_term)} hits.")
            except Exception as e_meili_search:
                logger.error(f"Error during MeiliSearch for term '{term_lower}': {e_meili_search}", exc_info=True)
                concept_hits_for_term = [] # Ensure it's a list

        if concept_hits_for_term:
            best_score_for_this_term = 0.0
            # Find the highest ranking_score among the hits for this term
            for ch in concept_hits_for_term:
                if ch._rankingScore is not None and ch._rankingScore > best_score_for_this_term:
                    best_score_for_this_term = ch._rankingScore
            
            logger.debug(f"Term '{term_lower}' best Meili score: {best_score_for_this_term} (threshold: {request.score_threshold})")

            if best_score_for_this_term >= request.score_threshold:
                for span_info in list_of_spans_for_term:
                    all_found_concept_matches.append(ConceptMatch(
                        text=span_info['original_text'], # Use the original cased text
                        start_char=span_info['start'],
                        end_char=span_info['end'],
                        concepts=concept_hits_for_term, # All top concepts for this term
                        score=best_score_for_this_term 
                    ))
            # else: # Optional: log why a term was discarded due to score
                # logger.debug(f"Term '{term_lower}' discarded, score {best_score_for_this_term} < threshold {request.score_threshold}")


    # 5. Filter for non-overlapping matches, prioritizing higher scores and longer text
    sorted_matches = sorted(all_found_concept_matches, key=lambda x: (x.score, len(x.text)), reverse=True)
    final_matches: List[ConceptMatch] = []
    covered_spans: List[Tuple[int,int]] = []

    for match in sorted_matches:
        is_overlapping = any(max(match.start_char, s_start) < min(match.end_char, s_end) for s_start, s_end in covered_spans)
        if not is_overlapping:
            final_matches.append(match)
            covered_spans.append((match.start_char, match.end_char))
        # else: # Optional: log discarded overlapping matches
            # logger.debug(f"Discarding overlapping match: '{match.text}' ({match.start_char}-{match.end_char}), score: {match.score}")


    query_time_ms = (time.time() - start_time) * 1000
    logger.info(f"Pattern matching for text (len {len(text_to_search)}) done in {query_time_ms:.2f}ms. Found {len(final_matches)} non-overlapping matches.")
    return PatternMatchResponse(matches=final_matches, query_time_ms=query_time_ms)

# In Terminology Service main.py
@app.get("/concepts/{cui}", response_model=ConceptHit, summary="Get Full Concept Details by CUI", tags=["Terminology"])
async def get_concept_by_cui(cui: str):
    if not concepts_index:
        logger.error(f"/concepts/{cui} called but concepts_index is not initialized.")
        raise HTTPException(status_code=503, detail="Terminology service index unavailable.")
    try:
        logger.debug(f"Fetching document from MeiliSearch for CUI: {cui}")
        document = await asyncio.to_thread(concepts_index.get_document, cui)
        
        # Convert the document to a dictionary before processing
        if hasattr(document, '__dict__'):
            document_dict = document.__dict__
        elif hasattr(document, 'model_dump'):
            document_dict = document.model_dump()
        else:
            # Fallback - convert to dict if possible
            document_dict = dict(document)
            
        logger.debug(f"Successfully fetched document for CUI {cui}")
        return _convert_meili_hit_to_concept_hit(document_dict)
        
    except (MeilisearchApiError, meilisearch.errors.MeilisearchApiError) as e:
        # Handle both possible casing variants of the exception
        error_code = getattr(e, 'code', getattr(e, 'error_code', ''))
        http_status = getattr(e, 'http_status', 500)
        
        if error_code == "document_not_found" or http_status == 404:
            logger.warning(f"Concept CUI '{cui}' not found in MeiliSearch.")
            raise HTTPException(status_code=404, detail=f"Concept CUI '{cui}' not found.")
        
        logger.error(f"MeiliSearch API error fetching document {cui}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error fetching concept from MeiliSearch: {str(e)}")
        
    except (MeilisearchCommunicationError, meilisearch.errors.MeilisearchCommunicationError) as e:
        logger.error(f"MeiliSearch communication error while fetching CUI {cui}: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail=f"Communication error with MeiliSearch service: {str(e)}")
        
    except (MeilisearchError, meilisearch.errors.MeilisearchError) as e:
        logger.error(f"General MeiliSearch error while fetching CUI {cui}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"A MeiliSearch error occurred: {str(e)}")
        
    except Exception as e:
        logger.error(f"Unexpected error fetching concept {cui}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Unexpected error fetching concept details: {str(e)}")


if __name__ == "__main__":
    SERVICE_PORT = int(os.getenv("TERMINOLOGY_SERVICE_PORT", 8001))
    logger.info(f"Starting Terminology Service on port {SERVICE_PORT} with reload...")
    uvicorn.run("main:app", host="0.0.0.0", port=SERVICE_PORT, reload=True) # Ensure main:app matches your filename if not main.py