# clinicalai_service/concurrent_processor.py
"""
FIXED: Lightweight concurrent processing for CPU-intensive NLP operations
Uses thread pool instead of process pool to avoid expensive model re-initialization
"""

import asyncio
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Any, Optional, Tuple
import logging
import time
from dataclasses import dataclass
import queue

from .models import NLPEntity, EnrichedEntity
from . import config as app_config

logger = logging.getLogger(__name__)

@dataclass
class ProcessingTask:
    """Task container for thread pool"""
    task_id: str
    text: str
    enable_clinical_bert: bool
    enable_intelligent_fallback: bool
    task_type: str = "full_nlp"

@dataclass
class ProcessingResult:
    """Result container from thread pool"""
    task_id: str
    success: bool
    entities: List[NLPEntity]
    processing_time: float
    error: Optional[str] = None
    metadata: Dict[str, Any] = None

class ConcurrentNLPProcessor:
    """
    FIXED: Manages concurrent NLP processing using thread pools
    Avoids expensive process creation and model re-initialization
    """
    
    def __init__(self, max_workers: int = None):
        # Use fewer workers to avoid resource contention
        self.max_workers = max_workers or min(2, app_config.ASYNC_MAX_WORKERS)
        self.thread_pool: Optional[ThreadPoolExecutor] = None
        self.active_tasks: Dict[str, asyncio.Future] = {}
        self._lock = threading.Lock()
        
    async def start(self):
        """Initialize the thread pool"""
        if self.thread_pool is None:
            self.thread_pool = ThreadPoolExecutor(
                max_workers=self.max_workers,
                thread_name_prefix="nlp-worker-"
            )
            logger.info(f"Started concurrent NLP processor with {self.max_workers} thread workers")
    
    async def stop(self):
        """Shutdown the thread pool"""
        if self.thread_pool:
            self.thread_pool.shutdown(wait=True)
            self.thread_pool = None
            logger.info("Stopped concurrent NLP processor")
    
    async def process_text_concurrent(
        self,
        task_id: str,
        text: str,
        enable_clinical_bert: bool = True,
        enable_intelligent_fallback: bool = True
    ) -> ProcessingResult:
        """
        FIXED: Process text concurrently using thread pool (not process pool)
        This avoids the expensive model re-initialization
        """
        if not self.thread_pool:
            await self.start()
        
        task = ProcessingTask(
            task_id=task_id,
            text=text,
            enable_clinical_bert=enable_clinical_bert,
            enable_intelligent_fallback=enable_intelligent_fallback
        )
        
        try:
            # Submit to thread pool (not process pool)
            loop = asyncio.get_event_loop()
            future = loop.run_in_executor(
                self.thread_pool,
                _process_text_in_thread,
                task
            )
            
            # Store the future for potential cancellation
            with self._lock:
                self.active_tasks[task_id] = future
            
            # Wait for completion with timeout
            result = await asyncio.wait_for(
                future,
                timeout=app_config.ASYNC_TIMEOUT_SECONDS
            )
            
            return result
            
        except asyncio.TimeoutError:
            logger.error(f"Task {task_id} timed out")
            return ProcessingResult(
                task_id=task_id,
                success=False,
                entities=[],
                processing_time=0,
                error="Processing timed out"
            )
        except Exception as e:
            logger.error(f"Task {task_id} failed: {e}")
            return ProcessingResult(
                task_id=task_id,
                success=False,
                entities=[],
                processing_time=0,
                error=str(e)
            )
        finally:
            # Clean up
            with self._lock:
                self.active_tasks.pop(task_id, None)

# Global processor instance
_concurrent_processor: Optional[ConcurrentNLPProcessor] = None

def get_concurrent_processor() -> ConcurrentNLPProcessor:
    """Get the global concurrent processor instance"""
    global _concurrent_processor
    if _concurrent_processor is None:
        _concurrent_processor = ConcurrentNLPProcessor()
    return _concurrent_processor
def _process_text_in_thread(task: ProcessingTask) -> ProcessingResult:
    """
    FIXED: Worker function that runs in a thread (not separate process)
    Uses the already-initialized NLP pipeline from the main process
    """
    start_time = time.time()
    
    try:
        # Import the processor - this should use the already-initialized pipeline
        from .nlp_engine import processor as nlp_processor
        
        # Check if NLP pipeline is available (should be from main process)
        if nlp_processor.NLP_SPACY is None:
            raise RuntimeError("NLP pipeline not initialized in main process")
            
        # Process the text using the existing processor (synchronous version)
        doc, entities = _process_text_sync_thread(
            task.text,
            task.enable_clinical_bert,
            task.enable_intelligent_fallback
        )
        
        processing_time = time.time() - start_time
        
        return ProcessingResult(
            task_id=task.task_id,
            success=True,
            entities=entities,
            processing_time=processing_time,
            metadata={
                "entity_count": len(entities),
                "text_length": len(task.text),
                "clinical_bert_enabled": task.enable_clinical_bert,
                "fallback_enabled": task.enable_intelligent_fallback,
                "processing_mode": "thread_pool"
            }
        )
        
    except Exception as e:
        processing_time = time.time() - start_time
        logger.error(f"Thread worker failed for task {task.task_id}: {e}")
        
        return ProcessingResult(
            task_id=task.task_id,
            success=False,
            entities=[],
            processing_time=processing_time,
            error=str(e)
        )

def _process_text_sync_thread(
    text: str,
    enable_clinical_bert: bool,
    enable_intelligent_fallback: bool
) -> Tuple[Any, List[NLPEntity]]:
    """
    FIXED: Synchronous text processing for thread workers
    Uses the already-initialized pipeline from main process
    """
    from .nlp_engine import processor as nlp_processor
    
    if not nlp_processor.NLP_SPACY:
        raise RuntimeError("NLP pipeline not initialized")
    
    # Set ClinicalBERT control for this thread
    nlp_processor.set_clinical_bert_enabled(enable_clinical_bert)
    
    # Process with conditional pipeline (using existing initialized models)
    if enable_clinical_bert:
        doc = nlp_processor.NLP_SPACY(text)
    else:
        doc = nlp_processor._process_without_clinical_bert(text)
    
    # Convert spaCy entities (using existing pipeline)
    medcat_entities = nlp_processor._convert_spacy_entities(doc)
    
    # Intelligent fallback (synchronous version)
    fallback_entities = []
    if enable_intelligent_fallback:
        try:
            fallback_entities = nlp_processor.get_intelligent_fallback_entities_sync(
                text, medcat_entities, enable_clinical_bert
            )
        except Exception as e:
            logger.warning(f"Fallback failed in thread: {e}")
            fallback_entities = []
    
    # Combine entities
    all_entities = medcat_entities + fallback_entities
    
    # Basic deduplication
    deduplicated_entities = nlp_processor._deduplicate_entities(all_entities)
    
    return doc, deduplicated_entities
