# Clinical AI Service: User Guide

## Introduction

The Clinical AI Service is designed to extract meaningful information from unstructured clinical notes and convert them into structured, FHIR-compliant data. It also offers summarization capabilities to condense lengthy notes into concise overviews.

## Getting Started

### Prerequisites

Before using the Clinical AI Service, ensure you have:

- Access credentials if required by your API gateway
- FHIR template IDs for structuring data (if needed)
- Access to the service endpoint URL

### Base URL

The service is accessible at:
```
http://<host>:8002/
```

Replace `<host>` with your actual deployment hostname.

## Using the Service

### Processing Clinical Notes

To process a clinical note, send a POST request to the `/process` endpoint:

```bash
curl -X POST "http://<host>:8002/process" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Patient presents with fever and cough...",
    "template_id": "soap-note-general",
    "patient_ref": "Patient/123",
    "encounter_ref": "Encounter/456",
    "author_ref": "Practitioner/789",
    "perform_summarization": true,
    "perform_structuring": true
  }'
```

#### Request Parameters

| Parameter | Type | Description | Required |
|-----------|------|-------------|----------|
| text | string | The clinical note text to process | Yes |
| template_id | string | ID of the FHIR Questionnaire template | No |
| patient_ref | string | FHIR Patient reference | No |
| encounter_ref | string | FHIR Encounter reference | No |
| author_ref | string | FHIR Practitioner reference | No |
| perform_summarization | boolean | Generate note summary with LLM | No (default: false) |
| perform_structuring | boolean | Generate structured FHIR data | No (default: true) |

#### Response Format

The service returns a JSON object with the following structure:

```json
{
  "request_id": "1a2b3c4d-5e6f-7g8h-9i0j",
  "enriched_entities": [
    {
      "text": "fever",
      "label": "SIGN_SYMPTOM",
      "start_char": 120,
      "end_char": 125,
      "primary_cui": "C0015967",
      "section": "CHIEF COMPLAINT",
      "modifiers": {
        "negated": false,
        "historical": false
      },
      "preferred_name_ks": "Fever",
      "backend_category": "symptom",
      "standard_codes": [
        {
          "code": "386661006",
          "vocabulary": "SNOMEDCT_US",
          "display": "Fever"
        }
      ]
    }
  ],
  "fhir_payload": {
    "fhir_qr": {
      "resourceType": "QuestionnaireResponse",
      "questionnaire": "http://example.org/Questionnaire/soap-note-general",
      "status": "completed",
      "item": [...]
    },
    "template_used": "soap-note-general",
    "placeholders_filled": 12
  },
  "summary_payload": {
    "summary_text": "45-year-old female with 3-day history of fever, chills, and productive cough. History of hypertension and T2DM. No SOB or chest pain. Assessment: Likely viral bronchitis."
  },
  "timing_metrics_ms": {
    "nlp_engine_ms": 234.56,
    "template_mapping_ms": 45.67,
    "llm_summary_ms": 789.01,
    "total_pipeline_ms": 1069.24
  },
  "errors": [],
  "warnings": []
}
```

### Key Response Elements

- **enriched_entities**: List of clinical entities found in the text with terminology links
- **fhir_payload**: Structured FHIR QuestionnaireResponse (when template_id is provided)
- **summary_payload**: AI-generated summary of the clinical note (when perform_summarization=true)
- **timing_metrics_ms**: Performance metrics for each processing stage
- **errors/warnings**: Any issues encountered during processing

### Health Check

To verify the service is running:

```bash
curl -X GET "http://<host>:8002/health"
```

Expected response when healthy:
```json
{
  "status": "ok",
  "version": "0.1.0",
  "nlp_engine_loaded": true,
  "medcat_model_loaded": true,
  "dependencies": {
    "terminology_service": "ok",
    "template_service": "ok",
    "llm_service": "ok",
    "database": "ok" 
  }
}
```

## Understanding the Results

### Entity Categories

Entities are classified into these main categories:

- **diagnoses**: Medical conditions and diagnoses
- **symptoms**: Signs and symptoms reported by the patient
- **medications**: Drugs and therapeutic substances
- **procedures**: Medical procedures and interventions
- **labs**: Laboratory tests and results
- **vitals**: Vital signs measurements
- **anatomy**: Anatomical structures
- **other**: Other medical concepts

### Modifiers

Entities may include contextual modifiers:

- **negated**: Entity is explicitly denied or ruled out
- **historical**: Entity occurred in the past
- **hypothetical**: Entity is presented as a possibility
- **family**: Entity relates to family history
- **uncertain**: Entity is described with uncertainty

### Section Context

The "section" field indicates which part of the clinical note contained the entity, such as:
- CHIEF COMPLAINT
- HISTORY OF PRESENT ILLNESS
- PAST MEDICAL HISTORY
- ASSESSMENT
- PLAN

## Tips and Best Practices

1. **For better entity recognition**:
   - Use standard medical terminology
   - Ensure proper punctuation and formatting
   - Include relevant section headers

2. **For optimal summarization**:
   - Include complete patient information
   - Structure notes with clear sections
   - Provide adequate clinical context

3. **For FHIR template mapping**:
   - Ensure template_id matches an existing FHIR Questionnaire
   - Include relevant patient and encounter references
   - Check if specific templates need specific content sections

## Troubleshooting

### Common Issues

| Issue | Possible Solution |
|-------|------------------|
| No entities found | Check text formatting, ensure clinical content is present |
| FHIR mapping incomplete | Verify template_id is correct and supported |
| Slow processing time | Check timing_metrics_ms to identify bottlenecks |
| Missing summary | Ensure LLM service is available and perform_summarization=true |

### Support

For technical issues, please contact your system administrator or IT support team.

---

*This documentation is intended for clinical users and developers integrating with the Clinical AI Service.* 