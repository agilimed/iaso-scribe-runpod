# Clinical AI Service Technical Documentation

## Overview

The Clinical AI Service is a microservice designed to process unstructured clinical notes using advanced NLP techniques. It extracts clinical entities, enriches them with terminology details, and optionally structures the data into FHIR-compliant resources. It supports summarization through integration with language models.

## System Architecture

### Core Components

1. **NLP Engine** - Dual engine processing utilizing:
   - **MedCAT** - CDB/Vocab based medical concept annotation tool (primary)
   - **spaCy** - Using en_core_sci_lg for scientific/medical text processing (fallback)
   - **MedSpaCy** - Extensions for section detection and contextual analysis

2. **Entity Enrichment System** - Enhances NLP entities with:
   - Terminology lookups (UMLS, SNOMED, RxNorm, etc.)
   - Entity categorization
   - Standard code mapping

3. **FHIR Templating Module** - Config-driven mapping:
   - PostgreSQL-backed configuration
   - Template-specific mapping rules
   - FHIR QuestionnaireResponse generation

4. **External Service Clients** - Integrations with:
   - Terminology Service - For code enrichment and translations
   - Template Service - For FHIR Questionnaire templates
   - LLM Service - For summarization and text generation

### Data Flow

1. Clinical note is received via API
2. NLP processing extracts entities
3. Entities are enriched via terminology service (async)
4. If requested, clinical note is summarized via LLM
5. If template ID is provided, entities are mapped to FHIR structure
6. All processed data is returned in a single response

## Technical Specifications

### Dependencies

- **Python**: 3.10+
- **NLP Packages**:
  - spaCy 3.7.x
  - MedCAT 1.16.0
  - MedSpaCy 1.0.0+
  - en_core_sci_lg model 0.5.4
- **Web Framework**: FastAPI
- **ASGI Server**: Uvicorn
- **Database**: PostgreSQL
- **HTTP Client**: httpx

### Installation Requirements

Key Installation Notes:
- MedCAT installed directly from GitHub with `--no-deps` flag
- spaCy model en_core_sci_lg installed from local path
- Virtualenv recommended for dependency isolation

### Model Files

Located in `installs/` directory:
- en_core_sci_lg-0.5.4.tar.gz.tar (507MB)
- en_core_web_md-1.2.0.tar.gz (1.0GB)

## API Documentation

### Endpoints

#### POST /process

Processes a clinical note and returns extracted information:

```json
Request:
{
  "text": "Clinical note content...",
  "template_id": "template-identifier",
  "patient_ref": "Patient/id",
  "encounter_ref": "Encounter/id",
  "author_ref": "Practitioner/id",
  "perform_summarization": true,
  "perform_structuring": true
}

Response:
{
  "request_id": "uuid",
  "enriched_entities": [...],
  "fhir_payload": { ... },
  "summary_payload": { ... },
  "timing_metrics_ms": { ... },
  "errors": [],
  "warnings": []
}
```

#### GET /health

Health check endpoint returning service status.

## Database Architecture

The service uses PostgreSQL for storing mapping configurations:

- **Tables** (clinical_consolidated schema):
  - nlp_answer_configs - Defines how to format FHIR answers
  - template_nlp_mappings - Links templates to mapping rules
  - nlp_mapping_rules - Core mapping rules
  - nlp_rule_criteria - Criteria for selecting entities

## Component Details

### NLP Engine Module

The NLP engine (nlp_engine/processor.py) orchestrates the text processing:

1. **MedCAT Integration**:
   - Custom spaCy component (MedCATComponent)
   - Loads CDB, Vocab, and configuration from file system
   - Can be used standalone or within spaCy pipeline

2. **Processing Pipeline**:
   - Tokenization
   - Sentence segmentation
   - Section detection
   - Named entity recognition (NER)
   - Contextual analysis
   - Entity filtering

3. **Entity Processing**:
   - Classification by type (diagnoses, medications, etc.)
   - Context detection (negation, hypothetical, etc.)
   - Section assignment

### FHIR Templating

The FHIR templating system (fhir_templating/config_driven_mapper.py):

1. Loads template definition from Template Service
2. Retrieves mapping rules from PostgreSQL
3. Applies rules to match entities to questionnaire items
4. Formats entities into appropriate FHIR resource structure
5. Supports complex answer types (string, coding, reference, etc.)

### Client Integrations

The service integrates with external services via dedicated clients:

1. **Terminology Client**: Resolves CUIs to standard medical codes
2. **Template Client**: Retrieves FHIR Questionnaires
3. **LLM Client**: Sends requests to language models for summarization
4. **Knowledge Client**: Used for additional entity enrichment (optional)

## Performance Considerations

- **Async Processing**: Entity enrichment uses asyncio for parallel processing
- **Timing Metrics**: Each processing stage is timed for performance monitoring
- **Custom Middleware**: Request logging and timing via FastAPI middleware

## Error Handling

The service implements robust error handling:

- Component initialization failures are gracefully managed
- Entity extraction errors don't block processing
- Service connection issues are reported in response
- Detailed error logging with exception details

## Security Considerations

- No direct authentication in service (intended for API gateway integration)
- Environmental variable configuration for sensitive information
- No PHI stored within the service

## Testing

Testing capability provided via:

- test_medcat_google.py script for testing the NLP components
- Unit tests for individual components
- Manual API testing via client tools

## Support and Maintenance

For support issues:

1. Check logs at the configured LOG_FILE_PATH
2. Examine timing metrics in API responses for bottlenecks
3. Verify MedCAT model loading if entity extraction is failing
4. Check external service connections if enrichment fails

## Configuration

All configuration managed through environment variables or .env file:

- Service ports and logging
- NLP engine preferences
- Model paths
- External service URLs
- Database connection details

---

*This documentation is intended for technical audiences responsible for deploying, maintaining, or extending the Clinical AI Service.* 