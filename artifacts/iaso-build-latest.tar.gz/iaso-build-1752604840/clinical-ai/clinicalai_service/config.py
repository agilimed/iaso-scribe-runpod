# clinicalai_service/config.py
import os
from dotenv import load_dotenv
from pathlib import Path
import torch

# Determine the base directory of the project
BASE_DIR = Path(__file__).resolve().parent.parent

# Load .env file
dotenv_path = BASE_DIR / ".env"
if dotenv_path.exists():
    load_dotenv(dotenv_path=dotenv_path, override=True)
    print(f"Loaded .env from: {dotenv_path}")
else:
    package_dotenv_path = Path(__file__).resolve().parent / ".env"
    if package_dotenv_path.exists():
        load_dotenv(dotenv_path=package_dotenv_path, override=True)
        print(f"Loaded .env from: {package_dotenv_path}")
    else:
        print(f"Warning: .env file not found. Using environment variables.")

# Service Configuration
APP_PORT = int(os.getenv("CLINICAL_AI_SERVICE_PORT", 8002))
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
LOG_FILE_PATH = os.getenv("LOG_FILE_PATH", "logs/clinicalai_service.log")
UVICORN_RELOAD = os.getenv("UVICORN_RELOAD", "false").lower() == "true"
SERVICE_VERSION = "1.1.0"  # UPDATED: Version with optimizations

# CORS Configuration
CORS_ORIGINS = [origin.strip() for origin in os.getenv("CORS_ORIGINS", "*").split(",")]

# Enhanced NLP Engine Configuration
SPACY_MODEL_NAME = os.getenv("SPACY_MODEL", "en_core_sci_lg")
SPACY_MODEL = os.getenv("SPACY_MODEL", "en_core_sci_lg")

# MedCAT 1.16 Configuration
_medcat_model_relative_path_str = os.getenv("MEDCAT_MODEL_PACK_ROOT", "clinicalai_service/models/trained_medcat_model")
MEDCAT_MODEL_PACK_DIR = (BASE_DIR / _medcat_model_relative_path_str).resolve()

if not MEDCAT_MODEL_PACK_DIR.exists() or not MEDCAT_MODEL_PACK_DIR.is_dir():
    print(f"CRITICAL: MedCAT model directory not found: {MEDCAT_MODEL_PACK_DIR}")
    print(f"  Base directory: {BASE_DIR}")
    print(f"  Relative path: '{_medcat_model_relative_path_str}'")
else:
    print(f"MedCAT model directory found: {MEDCAT_MODEL_PACK_DIR}")

# MedCAT file paths
MEDCAT_CDB_PATH = MEDCAT_MODEL_PACK_DIR / "cdb.dat"
MEDCAT_VOCAB_PATH = MEDCAT_MODEL_PACK_DIR / "vocab.dat"
MEDCAT_CONFIG_PATH = MEDCAT_MODEL_PACK_DIR / "config.json"
TUI_MAPPING_FILE_PATH = MEDCAT_MODEL_PACK_DIR / "tui2name.tsv"

# MedCAT 1.16 specific settings
MEDCAT_VERSION = "1.16.0"
MEDCAT_FORCE_CPU = os.getenv("MEDCAT_FORCE_CPU", "true").lower() == "true"
MEDCAT_DISABLE_TRAINING = os.getenv("MEDCAT_DISABLE_TRAINING", "true").lower() == "true"
MEDCAT_SIMILARITY_THRESHOLD = float(os.getenv("MEDCAT_SIMILARITY_THRESHOLD", "0.25"))
MEDCAT_MIN_NAME_LENGTH = int(os.getenv("MEDCAT_MIN_NAME_LENGTH", "3"))
MEDCAT_MAX_NAME_LENGTH = int(os.getenv("MEDCAT_MAX_NAME_LENGTH", "10"))
PREFER_LONGER_MATCHES = os.getenv("PREFER_LONGER_MATCHES", "true").lower() == "true"

# OPTIMIZED: ClinicalBERT Configuration with Performance Tuning
ENABLE_CLINICAL_BERT = os.getenv("ENABLE_CLINICAL_BERT", "true").lower() == "true"
CLINICAL_BERT_MODEL_NAME = os.getenv("CLINICAL_BERT_MODEL_NAME", "emilyalsentzer/Bio_ClinicalBERT")

# OPTIMIZED: Reduced batch size for better memory management and concurrency
CLINICAL_BERT_BATCH_SIZE = int(os.getenv("CLINICAL_BERT_BATCH_SIZE", "2"))  # CHANGED: From 8 to 2

# OPTIMIZED: CPU/GPU configuration
CLINICAL_BERT_FORCE_CPU = os.getenv("CLINICAL_BERT_FORCE_CPU", "false").lower() == "true"
ENABLE_CLINICAL_BERT_ENHANCEMENT = os.getenv("ENABLE_CLINICAL_BERT_ENHANCEMENT", "true").lower() == "true"

# OPTIMIZED: Conservative chunking configuration for better performance
CLINICAL_BERT_MAX_LENGTH = int(os.getenv("CLINICAL_BERT_MAX_LENGTH", "384"))  # Better balance
CLINICAL_BERT_CHUNK_OVERLAP = int(os.getenv("CLINICAL_BERT_CHUNK_OVERLAP", "15"))  # Further reduce overlap
CLINICAL_BERT_MIN_CHUNK_SIZE = int(os.getenv("CLINICAL_BERT_MIN_CHUNK_SIZE", "75"))  # Avoid tiny chunks
CLINICAL_BERT_AGGREGATION_METHOD = os.getenv("CLINICAL_BERT_AGGREGATION_METHOD", "simple_average")  # CHANGED: From weighted_average to simple_average (faster)

# OPTIMIZED: Performance filtering - more aggressive filtering
CLINICAL_BERT_MIN_TEXT_LENGTH = int(os.getenv("CLINICAL_BERT_MIN_TEXT_LENGTH", "10"))  # CHANGED: From 50 to 10
CLINICAL_BERT_MAX_TEXT_LENGTH = int(os.getenv("CLINICAL_BERT_MAX_TEXT_LENGTH", "50000"))  # CHANGED: From 100000 to 50000
CLINICAL_BERT_MIN_ENTITY_LENGTH = int(os.getenv("CLINICAL_BERT_MIN_ENTITY_LENGTH", "3"))

# OPTIMIZED: Performance modes - enable all optimizations
CLINICAL_BERT_FAST_MODE = os.getenv("CLINICAL_BERT_FAST_MODE", "true").lower() == "true"
CLINICAL_BERT_SKIP_SHORT_ENTITIES = os.getenv("CLINICAL_BERT_SKIP_SHORT_ENTITIES", "true").lower() == "true"
CLINICAL_BERT_SKIP_DOCUMENT_EMBEDDINGS = os.getenv("CLINICAL_BERT_SKIP_DOCUMENT_EMBEDDINGS", "true").lower() == "true"

# NEW: Thread pool configuration for async processing
CLINICAL_BERT_MAX_WORKERS = int(os.getenv("CLINICAL_BERT_MAX_WORKERS", "4"))  # CHANGED: From 2 to 4
ASYNC_MAX_WORKERS = int(os.getenv("ASYNC_MAX_WORKERS", "8"))  # NEW: General async thread pool
CLINICAL_BERT_CACHE_SIZE = int(os.getenv("CLINICAL_BERT_CACHE_SIZE", "2"))  # NEW: Reduce cache size

# Auto-detect GPU availability
CUDA_AVAILABLE = torch.cuda.is_available()
DEVICE = "cuda" if CUDA_AVAILABLE and not CLINICAL_BERT_FORCE_CPU else "cpu"

print(f"GPU Available: {CUDA_AVAILABLE}, Using Device: {DEVICE}")
print(f"OPTIMIZED: ClinicalBERT configured for {'GPU' if DEVICE == 'cuda' else 'CPU'} with aggressive optimizations")

# Default NER Engine
DEFAULT_NER_ENGINE = os.getenv("DEFAULT_NER_ENGINE", "medcat").lower()

# Enhanced Pipeline Configuration
ENABLE_ENTITY_RULER = os.getenv("ENABLE_ENTITY_RULER", "true").lower() == "true"
ENABLE_SECTION_DETECTION = os.getenv("ENABLE_SECTION_DETECTION", "true").lower() == "true"
ENABLE_CONTEXT_ANALYSIS = os.getenv("ENABLE_CONTEXT_ANALYSIS", "true").lower() == "true"
ENABLE_MEDSPACY = os.getenv("ENABLE_MEDSPACY", "true").lower() == "true"
ENABLE_ENTITY_FILTERING = True
ENABLE_COMPOUND_EXTRACTION = True
MIN_ENTITY_LENGTH = 3
MIN_CONFIDENCE_THRESHOLD = 0.7
FILTER_IGNORE_ENTITIES = True
FILTER_UNKNOWN_LOW_CONFIDENCE = True

# OPTIMIZED: Performance Configuration - more conservative limits
MAX_TEXT_LENGTH = int(os.getenv("MAX_TEXT_LENGTH", "35000"))
ENTITY_ENRICHMENT_BATCH_SIZE = int(os.getenv("ENTITY_ENRICHMENT_BATCH_SIZE", "8"))  # Increase back up for better throughput
ASYNC_TIMEOUT_SECONDS = int(os.getenv("ASYNC_TIMEOUT_SECONDS", "45"))

# Database Configuration (for template mapping)
PG_HOST_SRC = os.getenv('PG_HOST_SRC', 'localhost')
PG_PORT = int(os.getenv('PG_PORT', '5432'))
POSTGRES_DB = os.getenv('POSTGRES_DB', 'nexus_care')
POSTGRES_USER = os.getenv('POSTGRES_USER', 'postgres')
POSTGRES_PASSWORD = os.getenv('POSTGRES_PASSWORD')

# External Service URLs
TERMINOLOGY_SERVICE_URL = os.getenv("TERMINOLOGY_SERVICE_URL")
KNOWLEDGE_SERVICE_URL = os.getenv("KNOWLEDGE_SERVICE_URL")
TEMPLATE_SERVICE_URL = os.getenv("TEMPLATE_SERVICE_URL")
LLM_SERVICE_URL = os.getenv("LLM_SERVICE_URL")

# LLM Service Configuration
RUNPOD_API_BASE = os.getenv("RUNPOD_API_BASE")
RUNPOD_ENDPOINT_ID = os.getenv("RUNPOD_ENDPOINT_ID")
RUNPOD_API_KEY = os.getenv("RUNPOD_API_KEY")
LLM_TIMEOUT_SECONDS = int(os.getenv("LLM_TIMEOUT", "120"))
LLM_MAX_RETRIES = int(os.getenv("LLM_MAX_RETRIES", "3"))

# Enhanced FHIR System URIs
FHIR_SYSTEM_URIS = {
    # Core medical vocabularies
    "UMLS": os.getenv("FHIR_SYS_URI_UMLS", "urn:oid:2.16.840.1.113883.6.86"),
    "SNOMEDCT_US": os.getenv("FHIR_SYS_URI_SNOMEDCT_US", "http://snomed.info/sct"),
    "SNOMEDCT": os.getenv("FHIR_SYS_URI_SNOMEDCT", "http://snomed.info/sct"),
    "SNOMED": os.getenv("FHIR_SYS_URI_SNOMED", "http://snomed.info/sct"),
    "RXNORM": os.getenv("FHIR_SYS_URI_RXNORM", "http://www.nlm.nih.gov/research/umls/rxnorm"),
    "LOINC": os.getenv("FHIR_SYS_URI_LOINC", "http://loinc.org"),
    "LNC": os.getenv("FHIR_SYS_URI_LNC", "http://loinc.org"),
    
    # ICD codes
    "ICD10CM": os.getenv("FHIR_SYS_URI_ICD10CM", "http://hl7.org/fhir/sid/icd-10-cm"),
    "ICD10": os.getenv("FHIR_SYS_URI_ICD10", "http://hl7.org/fhir/sid/icd-10"),
    "ICD9CM": os.getenv("FHIR_SYS_URI_ICD9CM", "http://hl7.org/fhir/sid/icd-9-cm"),
    "MTHICD9": os.getenv("FHIR_SYS_URI_MTHICD9", "http://hl7.org/fhir/sid/icd-9-cm"),
    
    # Procedure codes
    "CPT": os.getenv("FHIR_SYS_URI_CPT", "http://www.ama-assn.org/go/cpt"),
    "HCPCS": os.getenv("FHIR_SYS_URI_HCPCS", "urn:oid:2.16.840.1.113883.6.285"),
    
    # Other vocabularies
    "NCI": os.getenv("FHIR_SYS_URI_NCI", "http://ncit.nci.nih.gov"),
    "MSH": os.getenv("FHIR_SYS_URI_MSH", "http://www.nlm.nih.gov/mesh"),
    "MEDDRA": os.getenv("FHIR_SYS_URI_MEDDRA", "urn:oid:2.16.840.1.113883.6.163"),
    "ATC": os.getenv("FHIR_SYS_URI_ATC", "http://www.whocc.no/atc"),
    "DRUGBANK": os.getenv("FHIR_SYS_URI_DRUGBANK", "http://www.drugbank.ca"),
    "OMIM": os.getenv("FHIR_SYS_URI_OMIM", "urn:oid:2.16.840.1.113883.6.101"),
    "HPO": os.getenv("FHIR_SYS_URI_HPO", "http://purl.obolibrary.org/obo/hp.owl"),
    "CHV": os.getenv("FHIR_SYS_URI_CHV", "urn:oid:2.16.840.1.113883.6.59"),
    "CVX": os.getenv("FHIR_SYS_URI_CVX", "http://hl7.org/fhir/sid/cvx"),
    "UNII": os.getenv("FHIR_SYS_URI_UNII", "http://fdasis.nlm.nih.gov"),
}

# Logging configuration
LOGS_DIR = Path(os.path.dirname(LOG_FILE_PATH)).resolve()

# Clinical Categories Configuration
CLINICAL_CATEGORIES = {
    "CONDITION": ["diagnosis", "disease", "disorder", "syndrome", "condition"],
    "DRUG": ["medication", "drug", "pharmaceutical", "substance"],
    "PROCEDURE": ["procedure", "intervention", "surgery", "operation"],
    "LAB_RESULT": ["lab", "laboratory", "test", "result"],
    "VITAL_SIGN": ["vital", "vitals", "measurement"],
    "SYMPTOM": ["symptom", "sign", "complaint"],
    "ANATOMY": ["anatomy", "anatomical", "body part"],
    "DEVICE": ["device", "equipment", "instrument"],
    "OBSERVATION": ["observation", "finding", "assessment"],
    "IGNORE": ["ignore", "exclude", "skip"]
}

CLINICAL_ABBREVIATIONS = {
    "tsh", "cbc", "bp", "hr", "rr", "t3", "t4", "mi", "copd", 
    "ecg", "ekg", "a1c", "bun", "ldl", "hdl", "ct", "mri","spo2", "fio2","ckd",
    "hba1c","aki","hiv"
}

# Entity Enhancement Configuration
ENTITY_CONFIDENCE_THRESHOLD = float(os.getenv("ENTITY_CONFIDENCE_THRESHOLD", "0.5"))
ENABLE_ENTITY_LINKING = os.getenv("ENABLE_ENTITY_LINKING", "true").lower() == "true"

# OPTIMIZED: Cache Configuration - reduced cache sizes for better memory management
ENABLE_ENTITY_CACHE = os.getenv("ENABLE_ENTITY_CACHE", "true").lower() == "true"
ENTITY_CACHE_SIZE = int(os.getenv("ENTITY_CACHE_SIZE", "500"))  # CHANGED: From 1000 to 500
ENTITY_CACHE_TTL_HOURS = int(os.getenv("ENTITY_CACHE_TTL_HOURS", "12"))  # CHANGED: From 24 to 12

ENABLE_CONCURRENT_ENTITY_PROCESSING = os.getenv("ENABLE_CONCURRENT_ENTITY_PROCESSING", "true").lower() == "true"
FALLBACK_TIMEOUT_SECONDS = int(os.getenv("FALLBACK_TIMEOUT_SECONDS", "5"))  # Quick timeout for fallback
CLINICAL_BERT_TIMEOUT_SECONDS = int(os.getenv("CLINICAL_BERT_TIMEOUT_SECONDS", "10"))  # Timeout for BERT operations

# API Rate Limiting
ENABLE_RATE_LIMITING = os.getenv("ENABLE_RATE_LIMITING", "false").lower() == "true"
RATE_LIMIT_REQUESTS_PER_MINUTE = int(os.getenv("RATE_LIMIT_REQUESTS_PER_MINUTE", "60"))

# Development and Testing
DEBUG_MODE = os.getenv("DEBUG_MODE", "false").lower() == "true"
ENABLE_PROFILING = os.getenv("ENABLE_PROFILING", "false").lower() == "true"
TEST_MODE = os.getenv("TEST_MODE", "false").lower() == "true"

# NEW: Print optimization summary
print("=" * 60)
print("🚀 OPTIMIZED CLINICAL AI SERVICE CONFIGURATION")
print("=" * 60)
print(f"📊 ClinicalBERT Optimizations:")
print(f"   • Max Length: {CLINICAL_BERT_MAX_LENGTH} (optimized for performance)")
print(f"   • Batch Size: {CLINICAL_BERT_BATCH_SIZE} (reduced for memory)")
print(f"   • Chunk Overlap: {CLINICAL_BERT_CHUNK_OVERLAP} (minimized)")
print(f"   • Min Chunk Size: {CLINICAL_BERT_MIN_CHUNK_SIZE} (avoid tiny chunks)")
print(f"   • Max Workers: {CLINICAL_BERT_MAX_WORKERS}")
print(f"   • Async Workers: {ASYNC_MAX_WORKERS}")  # NEW

print(f"\n⚡ Performance Optimizations:")
print(f"   • Max Text Length: {MAX_TEXT_LENGTH} (reduced)")
print(f"   • Entity Batch Size: {ENTITY_ENRICHMENT_BATCH_SIZE} (smaller batches)")
print(f"   • Entity Cache Size: {ENTITY_CACHE_SIZE} (optimized)")
print(f"   • Cache TTL: {ENTITY_CACHE_TTL_HOURS}h (reduced)")
print(f"   • Async Timeout: {ASYNC_TIMEOUT_SECONDS}s (increased)")

print(f"\n🖥️  Hardware Configuration:")
print(f"   • Device: {DEVICE}")
print(f"   • CUDA Available: {CUDA_AVAILABLE}")
print(f"   • Force CPU: {CLINICAL_BERT_FORCE_CPU}")

print("=" * 60)

# Validation
def validate_configuration():
    """Validate critical configuration settings"""
    errors = []
    warnings = []
    
    # Check MedCAT model files
    if DEFAULT_NER_ENGINE == "medcat":
        if not MEDCAT_CDB_PATH.exists():
            errors.append(f"MedCAT CDB file not found: {MEDCAT_CDB_PATH}")
        if not MEDCAT_VOCAB_PATH.exists():
            errors.append(f"MedCAT Vocab file not found: {MEDCAT_VOCAB_PATH}")
        if not MEDCAT_CONFIG_PATH.exists():
            warnings.append(f"MedCAT config file not found: {MEDCAT_CONFIG_PATH} (will use defaults)")
    
    # Check database configuration
    if not POSTGRES_PASSWORD:
        warnings.append("PostgreSQL password not set - template mapping may fail")
    
    # Check external services
    if not TERMINOLOGY_SERVICE_URL:
        warnings.append("Terminology service URL not configured")
    if not TEMPLATE_SERVICE_URL:
        warnings.append("Template service URL not configured")
    
    # Check ClinicalBERT
    if ENABLE_CLINICAL_BERT and not CUDA_AVAILABLE and not CLINICAL_BERT_FORCE_CPU:
        warnings.append("ClinicalBERT enabled but no GPU available - will use CPU")
    
    return errors, warnings

# Validate on import
if __name__ == "__main__":
    errors, warnings = validate_configuration()
    
    print("Configuration Validation:")
    print("=" * 40)
    
    if errors:
        print("ERRORS:")
        for error in errors:
            print(f"  ❌ {error}")
    
    if warnings:
        print("WARNINGS:")
        for warning in warnings:
            print(f"  ⚠️  {warning}")
    
    if not errors and not warnings:
        print("✅ Configuration is valid")
    
    print(f"\nConfiguration Summary:")
    print(f"  Service Version: {SERVICE_VERSION}")
    print(f"  NER Engine: {DEFAULT_NER_ENGINE}")
    print(f"  spaCy Model: {SPACY_MODEL}")
    print(f"  ClinicalBERT: {'Enabled' if ENABLE_CLINICAL_BERT else 'Disabled'}")
    print(f"  Device: {DEVICE}")
    print(f"  MedCAT Version: {MEDCAT_VERSION}")
    print(f"  Debug Mode: {DEBUG_MODE}")