# clinicalai_service/models.py
"""
Pydantic models for the Clinical AI Service
Production-grade models with proper validation and clinical standards
"""

from typing import List, Dict, Any, Optional, Literal, Union
from pydantic import BaseModel, Field, validator, ConfigDict
from datetime import datetime
from enum import Enum
import uuid
from . import config

# =============================================================================
# ENUMS AND TYPE DEFINITIONS
# =============================================================================

class ClinicalBERTModelOption(str, Enum):
    """Available ClinicalBERT models for API selection"""
    CLINICAL_BERT = "emilyalsentzer/Bio_ClinicalBERT"
    DISCHARGE_SUMMARY_BERT = "emilyalsentzer/Bio_Discharge_Summary_BERT"
    PUBMED_BERT = "microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract-fulltext"
    BIO_BERT = "dmis-lab/biobert-base-cased-v1.1"

# Source engines for audit trail
NEREngineSource = Literal[
    "medcat", 
    "spacy_ner", 
    "llm_ner", 
    "terminology_service",           
    "terminology_zero_maintenance",  
    "compound_term_fallback",       
    "clinicalbert_consolidation",    # FIXED: Added missing source
    "family_social_linker",
    "lab_exam_allergy_linker"
]

# Audit trail sources (expanded)
AuditTrailSource = Literal[
    "medcat", 
    "spacy_ner", 
    "llm_ner", 
    "llm_ner_gap_fill",
    "terminology_lookup", 
    "knowledge_enrichment", 
    "llm_summary", 
    "categorization_rules",
    "enrich_single_entity_completion",
    "terminology_enrichment_error",
    "entity_processing_step",
    "clinicalbert_consolidation",
    "intelligent_fallback",
    "context_analysis",
    "section_detection",
    "family_social_linker",
    "lab_exam_allergy_linker"
]

# Clinical categories (production standard)
ClinicalCategory = Literal[
    "CONDITION",
    "SYMPTOM", 
    "FINDING",
    "DRUG",
    "PROCEDURE",
    "LAB_RESULT",
    "VITAL_SIGN",
    "ANATOMY",
    "DEVICE",
    "OBSERVATION",
    "SUBSTANCE",
    "MEASUREMENT",
    "IGNORE",
    "UNKNOWN_CATEGORY"
]

# Document types for model selection
DocumentType = Literal[
    "consultation",
    "progress_note", 
    "discharge_summary",
    "procedure_note",
    "operative_note",
    "pathology_report",
    "radiology_report",
    "laboratory_report",
    "nursing_note",
    "therapy_note",
    "general"
]

# =============================================================================
# CORE DATA MODELS
# =============================================================================

class AuditTrailEntry(BaseModel):
    """Audit trail entry for tracking entity processing steps"""
    source_service: AuditTrailSource
    confidence_score: Optional[float] = Field(None, ge=0.0, le=1.0)
    original_matched_text: Optional[str] = Field(None, description="Original text if different from final")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    details: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional processing details")
    
    model_config = ConfigDict(extra='forbid')

class StandardCode(BaseModel):
    """Standard medical coding (SNOMED, ICD-10, etc.)"""
    code: str = Field(..., min_length=1, description="The actual code value")
    vocabulary: str = Field(..., min_length=1, description="Code vocabulary (SNOMED, ICD10CM, etc.)")
    display: Optional[str] = Field(None, description="Human-readable display name")
    version: Optional[str] = Field(None, description="Vocabulary version")
    
    model_config = ConfigDict(extra='forbid')

class Concept(BaseModel):
    """Clinical concept with comprehensive metadata"""
    id: str = Field(..., description="CUI or primary identifier")
    name: str = Field(..., min_length=1, description="Preferred name of the concept")
    
    # Source vocabulary information
    source: Optional[str] = Field(None, description="Primary source vocabulary (e.g., UMLS)")
    
    # Synonyms and alternative names
    synonyms: List[str] = Field(default_factory=list, description="List of synonym terms")
    
    # Semantic classification
    semantic_types: List[str] = Field(default_factory=list, description="UMLS semantic type names (STY)")
    tuis: List[str] = Field(default_factory=list, description="UMLS type unique identifiers (TUI)")
    
    # Definitions and descriptions
    definition: Optional[str] = Field(None, description="Textual definition of the concept")
    
    # Cross-vocabulary codes
    codes_by_sab: Dict[str, List[str]] = Field(
        default_factory=dict, 
        description="Standard codes grouped by source abbreviation (SAB)"
    )
    sabs: List[str] = Field(default_factory=list, description="List of source vocabularies")
    
    # Primary code information
    primary_code_sab: Optional[str] = Field(None, description="Primary code source abbreviation")
    primary_code_val: Optional[str] = Field(None, description="Primary code value")
    
    # Display names
    pretty_name: Optional[str] = Field(None, description="Display-friendly name for UI")
    
    # Search metadata
    ranking_score: Optional[float] = Field(None, alias="_rankingScore", description="Search ranking score")
    
    model_config = ConfigDict(
        populate_by_name=True, 
        extra='ignore',
        str_strip_whitespace=True
    )

# =============================================================================
# ENTITY MODELS (HIERARCHICAL)
# =============================================================================

class BaseEntity(BaseModel):
    """Base entity model with core NLP information"""
    # Identity and position
    id: str = Field(default_factory=lambda: str(uuid.uuid4()), description="Unique entity identifier")
    text: str = Field(..., min_length=1, description="The exact text span extracted")
    start_char: int = Field(..., ge=0, description="Start character position in source text")
    end_char: int = Field(..., gt=0, description="End character position in source text")
    label: str = Field(..., description="Raw label assigned by NER engine")
    
    # Context modifiers (clinical critical)
    negated: bool = Field(False, description="Entity is negated (patient denies chest pain)")
    historical: bool = Field(False, description="Entity refers to past condition (history of MI)")
    hypothetical: bool = Field(False, description="Entity is uncertain (possible pneumonia)")
    family_history: bool = Field(False, description="Entity is part of family history")
    social_history: bool = Field(False, description="Entity is part of social history")
    
    # Processing metadata
    source_ner_engine: NEREngineSource = Field(..., description="Which NER engine detected this entity")
    ner_confidence: Optional[float] = Field(None, ge=0.0, le=1.0, description="Confidence from NER engine")
    section_title: Optional[str] = Field(None, description="Document section where entity was found")
    
    # Validation
    @validator('end_char')
    def end_char_must_be_greater_than_start(cls, v, values):
        if 'start_char' in values and v <= values['start_char']:
            raise ValueError('end_char must be greater than start_char')
        return v
    
    @validator('text')
    def text_cannot_be_empty(cls, v):
        if not v or not v.strip():
            raise ValueError('Entity text cannot be empty or whitespace only')
        return v.strip()
    
    model_config = ConfigDict(
        from_attributes=True, 
        extra='forbid',
        str_strip_whitespace=True,
        validate_assignment=True
    )

class NLPEntity(BaseEntity):
    """Entity with NLP-specific medical coding"""
    # Medical coding
    primary_cui: Optional[str] = Field(None, description="Primary UMLS Concept Unique Identifier")
    type_ids: List[str] = Field(default_factory=list, description="UMLS Type Unique Identifiers (TUIs)")
    type_names: List[str] = Field(default_factory=list, description="UMLS Semantic Type Names (STYs)")
    
    # Additional metadata
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional NLP processing metadata")
    
    model_config = ConfigDict(extra='forbid')

class EnrichedEntity(NLPEntity):
    """Fully enriched entity with terminology and FHIR mapping"""
    # Rich concept linking
    linked_concepts: List[Concept] = Field(
        default_factory=list, 
        description="Related concepts from terminology services"
    )
    standard_codes: List[StandardCode] = Field(
        default_factory=list, 
        description="Standard medical codes (SNOMED, ICD-10, etc.)"
    )
    preferred_name_ks: Optional[str] = Field(
        None, 
        description="Best available preferred name from knowledge services"
    )
    
    # Clinical categorization
    backend_category: Optional[ClinicalCategory] = Field(
        None, 
        description="Standardized clinical category for processing"
    )
    
    # Processing audit trail
    audit_trail: List[AuditTrailEntry] = Field(
        default_factory=list, 
        description="Complete processing history for this entity"
    )
    
    # FHIR compliance
    fhir_codeable_concept: Optional[Dict[str, Any]] = Field(
        None, 
        description="FHIR CodeableConcept representation"
    )
    
    # Quality metrics
    enrichment_confidence: Optional[float] = Field(
        None, 
        ge=0.0, 
        le=1.0, 
        description="Overall confidence in entity enrichment quality"
    )
    
    model_config = ConfigDict(extra='forbid')

# =============================================================================
# FHIR AND TEMPLATE MODELS
# =============================================================================

class FHIRQuestionnaireResponsePayload(BaseModel):
    """FHIR QuestionnaireResponse with metadata"""
    fhir_qr: Optional[Dict[str, Any]] = Field(
        None, 
        description="Complete FHIR QuestionnaireResponse resource"
    )
    template_used: Optional[str] = Field(None, description="Template identifier used for generation")
    placeholders_filled: int = Field(0, ge=0, description="Number of template placeholders populated")
    template_version: Optional[str] = Field(None, description="Version of template used")
    generation_timestamp: datetime = Field(default_factory=datetime.utcnow)
    
    model_config = ConfigDict(extra='forbid')

class SummaryPayload(BaseModel):
    """Clinical summary with generation metadata"""
    summary_text: Optional[str] = Field(None, description="Generated clinical summary text")
    summary_type: Optional[str] = Field("general", description="Type of summary generated")
    llm_model_used: Optional[str] = Field(None, description="LLM model used for generation")
    generation_timestamp: datetime = Field(default_factory=datetime.utcnow)
    llm_audit_info: Optional[AuditTrailEntry] = Field(None, description="LLM processing audit information")
    
    model_config = ConfigDict(extra='forbid')

# =============================================================================
# INPUT MODELS
# =============================================================================

class ClinicalNoteInput(BaseModel):
    """Input model for clinical note processing with comprehensive options"""
    # Core input
    text: str = Field(
        ..., 
        min_length=1, 
        max_length=50000,  # Reasonable limit for clinical notes
        description="The clinical note text to process"
    )
    
    # FHIR context
    template_id: Optional[str] = Field(None, description="FHIR Questionnaire template ID")
    patient_ref: Optional[str] = Field(None, description="FHIR Patient reference")
    encounter_ref: Optional[str] = Field(None, description="FHIR Encounter reference")
    author_ref: Optional[str] = Field(None, description="FHIR Practitioner reference")
    
    # Processing control flags
    perform_summarization: bool = Field(True, description="Generate LLM clinical summary")
    perform_structuring: bool = Field(True, description="Generate FHIR QuestionnaireResponse")
    use_llm_for_gap_filling: bool = Field(True, description="Use LLM for additional entity detection")
    enable_context_analysis: bool = Field(True, description="Enable negation/temporal context analysis")
    enable_intelligent_fallback: bool = Field(True, description="Enable intelligent entity fallback system")
    
    # ClinicalBERT configuration
    clinical_bert_model: Optional[Union[ClinicalBERTModelOption, str]] = Field(
        None, 
        description="Specific ClinicalBERT model to use"
    )
    enable_clinical_bert: Optional[bool] = Field(
        None, 
        description="Enable/disable ClinicalBERT processing"
    )
    
    # Document context for model selection
    document_type: Optional[DocumentType] = Field(
        None, 
        description="Type of clinical document for automatic model selection"
    )
    
    # Quality control
    confidence_threshold: Optional[float] = Field(
        None, 
        ge=0.0, 
        le=1.0, 
        description="Minimum confidence threshold for entity inclusion"
    )
    
    # Processing hints
    priority_terms: Optional[List[str]] = Field(
        None, 
        description="High-priority terms to ensure detection"
    )
    ignore_terms: Optional[List[str]] = Field(
        None, 
        description="Terms to explicitly ignore in this processing"
    )
    
    model_config = ConfigDict(
        extra='forbid', 
        use_enum_values=True,
        str_strip_whitespace=True
    )
    
    @validator('clinical_bert_model', pre=True)
    def validate_clinical_bert_model(cls, v):
        """Validate and normalize ClinicalBERT model input"""
        if v is None:
            return v
        
        if isinstance(v, str):
            # Try exact enum match first
            for model_option in ClinicalBERTModelOption:
                if v == model_option.value or v == model_option.name:
                    return model_option.value
            
            # Partial matching for convenience
            v_lower = v.lower()
            if 'discharge' in v_lower:
                return ClinicalBERTModelOption.DISCHARGE_SUMMARY_BERT.value
            elif 'clinical' in v_lower:
                return ClinicalBERTModelOption.CLINICAL_BERT.value
            elif 'pubmed' in v_lower:
                return ClinicalBERTModelOption.PUBMED_BERT.value
            elif 'biobert' in v_lower or 'bio_bert' in v_lower:
                return ClinicalBERTModelOption.BIO_BERT.value
            
            # Return as-is if it looks like a valid model path
            if '/' in v and len(v) > 10:
                return v
                
        return v

# =============================================================================
# OUTPUT MODELS
# =============================================================================

class ProcessingMetrics(BaseModel):
    """Detailed processing performance metrics"""
    total_processing_time_ms: float = Field(..., ge=0.0)
    nlp_engine_time_ms: float = Field(0.0, ge=0.0)
    fallback_processing_time_ms: float = Field(0.0, ge=0.0)
    terminology_enhancement_time_ms: float = Field(0.0, ge=0.0)
    template_mapping_time_ms: float = Field(0.0, ge=0.0)
    llm_summary_time_ms: float = Field(0.0, ge=0.0)
    entity_enrichment_time_ms: float = Field(0.0, ge=0.0)
    
    model_config = ConfigDict(extra='forbid')

class ModelsUsedInfo(BaseModel):
    """Information about models used in processing"""
    nlp_engine: str = Field(..., description="Primary NLP engine used")
    spacy_model: str = Field(..., description="spaCy model used")
    clinical_bert_enabled: bool = Field(False, description="Whether ClinicalBERT was used")
    clinical_bert_model: Optional[str] = Field(None, description="Specific ClinicalBERT model used")
    medcat_model_version: Optional[str] = Field(None, description="MedCAT model version if used")
    
    model_config = ConfigDict(extra='forbid')

class ProcessingOutput(BaseModel):
    """Comprehensive processing output with quality metrics"""
    # Request tracking
    request_id: str = Field(..., description="Unique request identifier")
    processing_timestamp: datetime = Field(default_factory=datetime.utcnow)
    original_text_char_count: int = Field(..., ge=0)
    
    # Core results
    enriched_entities: List[EnrichedEntity] = Field(
        default_factory=list, 
        description="Fully processed and enriched clinical entities"
    )
    
    # Optional outputs
    fhir_payload: Optional[FHIRQuestionnaireResponsePayload] = Field(
        None, 
        description="FHIR QuestionnaireResponse if requested"
    )
    summary_payload: Optional[SummaryPayload] = Field(
        None, 
        description="Clinical summary if requested"
    )
    
    # Quality and debugging
    errors: List[str] = Field(default_factory=list, description="Processing errors encountered")
    warnings: List[str] = Field(default_factory=list, description="Processing warnings")
    
    # Performance metrics
    timing_metrics_ms: Dict[str, float] = Field(
        default_factory=dict, 
        description="Detailed timing metrics for pipeline stages"
    )
    
    # Model information
    models_used: Optional[ModelsUsedInfo] = Field(
        None, 
        description="Information about models used in processing"
    )
    clinical_bert_info: Optional[Dict[str, Any]] = Field(
        None, 
        description="ClinicalBERT processing details if used"
    )
    
    # Quality metrics
    overall_confidence: Optional[float] = Field(
        None, 
        ge=0.0, 
        le=1.0, 
        description="Overall confidence in processing quality"
    )
    entity_coverage: Optional[float] = Field(
        None, 
        ge=0.0, 
        le=1.0, 
        description="Estimated percentage of clinical entities detected"
    )
    
    model_config = ConfigDict(extra='forbid')

# =============================================================================
# CLINICAL BERT SPECIFIC MODELS
# =============================================================================

class EmbeddingRequest(BaseModel):
    """Request for text embeddings"""
    text: str = Field(..., min_length=1, max_length=5000, description="Text to embed")
    model_name: Optional[Union[ClinicalBERTModelOption, str]] = Field(
        None, 
        description="Specific model to use"
    )
    
    model_config = ConfigDict(use_enum_values=True)

class EmbeddingResponse(BaseModel):
    """Response with text embeddings"""
    text: str
    model_used: str
    embeddings: List[float]
    embedding_magnitude: float
    processing_time_ms: float
    embedding_dimension: int
    
    model_config = ConfigDict(extra='forbid')

class SimilarityRequest(BaseModel):
    """Request for text similarity calculation"""
    text1: str = Field(..., min_length=1, max_length=5000)
    text2: str = Field(..., min_length=1, max_length=5000)
    model_name: Optional[Union[ClinicalBERTModelOption, str]] = Field(None)
    
    model_config = ConfigDict(use_enum_values=True)

class SimilarityResponse(BaseModel):
    """Response with similarity score"""
    text1: str
    text2: str
    model_used: str
    similarity_score: float = Field(..., ge=-1.0, le=1.0)
    processing_time_ms: float
    
    model_config = ConfigDict(extra='forbid')

class ModelComparisonRequest(BaseModel):
    """Request for comparing multiple models"""
    text: str = Field(..., min_length=1, max_length=5000)
    models: List[Union[ClinicalBERTModelOption, str]] = Field(
        ..., 
        min_items=2, 
        max_items=4, 
        description="Models to compare (2-4)"
    )
    
    model_config = ConfigDict(use_enum_values=True)

class ModelComparisonResponse(BaseModel):
    """Response with model comparison results"""
    text: str
    models_compared: List[str]
    embeddings_comparison: Dict[str, Dict[str, Any]]
    similarity_matrix: Dict[str, float]
    analysis_comparison: Dict[str, Dict[str, Any]]
    recommendation: Optional[str] = Field(None, description="Best model recommendation for this text")
    processing_time_ms: float
    
    model_config = ConfigDict(extra='forbid')

class ClinicalBERTStatusResponse(BaseModel):
    """ClinicalBERT service status"""
    enabled: bool
    available_models: List[str]
    default_model: str
    cached_models: List[str]
    cache_utilization: str
    device: str
    transformers_available: bool
    memory_usage_mb: Optional[float] = None
    
    model_config = ConfigDict(extra='forbid')

# =============================================================================
# HEALTH AND STATUS MODELS
# =============================================================================

class HealthStatusResponse(BaseModel):
    """Comprehensive service health status"""
    # Basic service info
    service_name: str = Field("ClinicalAIService", description="Service identifier")
    status: Literal["healthy", "degraded", "unhealthy"] = Field(..., description="Overall service status")
    version: str = Field(default=config.SERVICE_VERSION, description="Service version")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    
    # Component status
    dependencies: Dict[str, Literal["ok", "error", "not_configured", "not_applicable"]] = Field(
        default_factory=dict, 
        description="Status of external dependencies"
    )
    
    # NLP engine status
    active_nlp_engine: Optional[str] = Field(None, description="Currently active NLP engine")
    medcat_model_loaded: bool = Field(False, description="Whether MedCAT model is loaded")
    spacy_model_loaded: bool = Field(False, description="Whether spaCy model is loaded")
    
    # ClinicalBERT detailed status
    clinical_bert_status: Optional[Dict[str, Any]] = Field(
        None, 
        description="Detailed ClinicalBERT service status"
    )
    
    # PRODUCTION: Concurrent processor status
    concurrent_processor_status: Optional[Dict[str, Any]] = Field(
        None,
        description="Production concurrent processor status and statistics"
    )
    
    # System resources
    memory_usage_mb: Optional[float] = Field(None, ge=0.0)
    cpu_usage_percent: Optional[float] = Field(None, ge=0.0, le=100.0)
    
    # Processing statistics
    requests_processed: Optional[int] = Field(None, ge=0, description="Total requests processed since startup")
    average_processing_time_ms: Optional[float] = Field(None, ge=0.0)
    
    model_config = ConfigDict(extra='forbid')

# =============================================================================
# VALIDATION AND UTILITY FUNCTIONS
# =============================================================================

def validate_clinical_category(category: str) -> bool:
    """Validate if a category is a valid clinical category"""
    valid_categories = {
        "CONDITION", "SYMPTOM", "FINDING", "DRUG", "PROCEDURE", 
        "LAB_RESULT", "VITAL_SIGN", "ANATOMY", "DEVICE", 
        "OBSERVATION", "SUBSTANCE", "MEASUREMENT", "IGNORE", "UNKNOWN_CATEGORY"
    }
    return category in valid_categories

def validate_cui_format(cui: str) -> bool:
    """Validate UMLS CUI format (C followed by 7-8 digits)"""
    import re
    return bool(re.match(r'^C\d{7,8}$', cui)) if cui else False

def validate_tui_format(tui: str) -> bool:
    """Validate UMLS TUI format (T followed by 3 digits)"""
    import re
    return bool(re.match(r'^T\d{3}$', tui)) if tui else False

# =============================================================================
# MODEL EXPORT
# =============================================================================

__all__ = [
    # Enums
    'ClinicalBERTModelOption', 'DocumentType', 'ClinicalCategory',
    
    # Core models
    'AuditTrailEntry', 'StandardCode', 'Concept',
    'BaseEntity', 'NLPEntity', 'EnrichedEntity',
    
    # FHIR models
    'FHIRQuestionnaireResponsePayload', 'SummaryPayload',
    
    # Input/Output models
    'ClinicalNoteInput', 'ProcessingOutput', 'ProcessingMetrics', 'ModelsUsedInfo',
    
    # ClinicalBERT models
    'EmbeddingRequest', 'EmbeddingResponse', 
    'SimilarityRequest', 'SimilarityResponse',
    'ModelComparisonRequest', 'ModelComparisonResponse',
    'ClinicalBERTStatusResponse',
    
    # Status models
    'HealthStatusResponse',
    
    # Validation functions
    'validate_clinical_category', 'validate_cui_format', 'validate_tui_format'
]
