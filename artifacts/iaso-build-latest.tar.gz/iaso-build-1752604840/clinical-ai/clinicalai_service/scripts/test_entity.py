import asyncio
import json
import logging
import os
import sys
import io
from datetime import datetime
from pathlib import Path
from typing import Optional

# Setup logging
log_dir = Path("logs")
log_dir.mkdir(exist_ok=True)
log_file = log_dir / f"entity_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

# Create unbuffered file handler
file_handler = logging.FileHandler(log_file, mode='w', encoding='utf-8')
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))

# Create console handler
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setLevel(logging.DEBUG)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))

# Configure root logger
logging.basicConfig(level=logging.DEBUG, handlers=[file_handler, console_handler])

# Get logger for this module
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# Custom log function that ensures flushing
def log_and_flush(level, msg):
    if level == "DEBUG":
        logger.debug(msg)
    elif level == "INFO":
        logger.info(msg)
    elif level == "WARNING":
        logger.warning(msg)
    elif level == "ERROR":
        logger.error(msg)
    elif level == "CRITICAL":
        logger.critical(msg)
    
    # Force flush after each log
    for handler in logger.handlers:
        handler.flush()
    
    # Also write directly to file as a backup approach
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S,%f')[:-3]} - DIRECT - {level} - {msg}\n")
        f.flush()
        os.fsync(f.fileno())

# Test log message
log_and_flush("DEBUG", "Logger initialized with direct file writing")
log_and_flush("INFO", "Starting test script")

# Adjust the import path if your project structure is different
# This assumes clinicalai_service is a package in the current working directory's parent
# or in PYTHONPATH
try:
    from clinicalai_service.main import enrich_single_entity 
    from clinicalai_service.clients.terminology_client import TerminologyServiceClient
    from clinicalai_service.models import NLPEntity, EnrichedEntity, Concept, StandardCode, AuditTrailEntry
    from clinicalai_service.utils import FHIR_CODING_SYSTEM_MAP # Ensure this is accessible
    from clinicalai_service import config as app_config # For TERMINOLOGY_SERVICE_URL
except ImportError as e:
    print(f"ImportError: {e}. Please ensure the script is run from the project root ")
    print("or clinicalai_service is in your PYTHONPATH.")
    print("Example: If script is in 'NEXUS-CARE-AI-BACKEND/', and service is 'NEXUS-CARE-AI-BACKEND/clinicalai_service/', it should work.")
    exit(1)

# --- Global instance for the test ---
# In a real FastAPI app, this is managed by lifespan. Here, we create it directly.
# This also means your ClinicalAIService/main.py might need a slight refactor
# if `enrich_single_entity` directly uses a global `terminology_service` variable
# that is only set by the lifespan.
# For this test, we will pass it explicitly or set it if the function expects a global.

# Option 1: If enrich_single_entity can accept terminology_service as an argument (preferred for testing)
# async def enrich_single_entity(entity: EnrichedEntity, request_id: str, term_service: TerminologyServiceClient) -> EnrichedEntity:

# Option 2: If enrich_single_entity uses a global `terminology_service` from its own module (main.py)
# We need to set it in that module's scope. This is a bit hacky for standalone tests.
# from clinicalai_service import main as clinical_ai_main_module
# clinical_ai_main_module.terminology_service = TerminologyServiceClient()

# For now, let's assume `enrich_single_entity` in your main.py is structured like:
# async def enrich_single_entity(entity: EnrichedEntity, request_id: str) -> EnrichedEntity:
#     # global terminology_service # or it's just available in module scope
#     # ... uses terminology_service ...
# And that the global `terminology_service` is set by the lifespan.
# For this standalone script, we will *temporarily assign* it if the function relies on a global
# from its own module.

# --- Test Data: CUIs ---
TEST_CUIS = {
    "diabetes": "C0011849",  # Diabetes Mellitus (Expect SNOMED, ICD10)
    "lisinopril": "C0023889", # Lisinopril (Expect RxNorm)
    "appendectomy": "C0003609", # Appendectomy (Expect SNOMED, CPT)
    "hemoglobin_a1c": "C0019020", # Hemoglobin A1c Measurement (Expect LOINC)
    "thyroid_function_test_CORRECT": "C0040130", # Assuming this is the correct CUI for Thyroid Function Test
    "carotene_measurement_MISLINKED": "C0373568", # The CUI that was mislinked
    "fma_concept_example": "C0015431", # Example: Femur (to test FMA if codes exist)
    "non_existent_cui": "C9999999", # A CUI that should not exist
    "entity_with_many_tuis": "C0027051", # Myocardial Infarction (has multiple TUIs/STYs)
    "aspirin": "C0004057" # Aspirin
}

# This global is needed if enrich_single_entity in main.py directly accesses it
# without it being passed as an argument.
# This is a common pattern in FastAPI apps where lifespan sets globals.
# We are simulating that here for the test.
terminology_service_instance: Optional[TerminologyServiceClient] = None

async def initialize_services_for_test():
    """Initialize services needed for the test, similar to lifespan."""
    global terminology_service_instance
    
    log_and_flush("INFO", "Initializing services for test...")
    
    if not app_config.TERMINOLOGY_SERVICE_URL:
        log_and_flush("ERROR", "ERROR: TERMINOLOGY_SERVICE_URL is not set in your .env or config.")
        log_and_flush("ERROR", "The TerminologyServiceClient cannot be initialized.")
        exit(1)
        
    log_and_flush("INFO", f"Using TERMINOLOGY_SERVICE_URL: {app_config.TERMINOLOGY_SERVICE_URL}")
    terminology_service_instance = TerminologyServiceClient(base_url=app_config.TERMINOLOGY_SERVICE_URL)
    log_and_flush("INFO", "TerminologyServiceClient initialized successfully")
    
    try:
        from clinicalai_service import main as clinical_ai_main_module
        clinical_ai_main_module.terminology_service = terminology_service_instance
        log_and_flush("INFO", "Patched clinicalai_service.main.terminology_service for standalone test.")
    except Exception as e:
        log_and_flush("ERROR", f"Could not patch global terminology_service in main.py: {e}")
        log_and_flush("ERROR", "Ensure enrich_single_entity can access TerminologyServiceClient, or modify this script.")
        raise

async def run_single_test(entity_name: str, cui: str, text_mention: Optional[str] = None):
    """
    Tests the enrich_single_entity function for a given CUI.
    """
    global terminology_service_instance

    if not terminology_service_instance:
        log_and_flush("ERROR", "terminology_service_instance not initialized. Call initialize_services_for_test() first.")
        return

    log_and_flush("INFO", f"--- Testing Enrichment for: {entity_name} (CUI: {cui}) ---")

    # 1. Create a base NLPEntity (as if MedCAT found it)
    # We'll make up some char offsets and a basic label.
    # The `text` field of BaseEntity should be the actual text span from the note.
    # If `text_mention` is not provided, use entity_name.
    actual_text = text_mention if text_mention else entity_name.replace("_", " ")

    nlp_entity = NLPEntity(
        text=actual_text, # This should be the text as it appeared in the note
        start_char=0,     # Placeholder
        end_char=len(actual_text), # Placeholder
        label="PLACEHOLDER_LABEL", # Placeholder, not used by enrich_single_entity directly if CUI is present
        primary_cui=cui,
        source_ner_engine="medcat", # Assuming it came from MedCAT for CUI presence
        ner_confidence=0.95 # Placeholder
        # type_ids and type_names might be pre-populated by MedCAT sometimes
    )

    # 2. Convert to EnrichedEntity shell
    enriched_entity_shell = EnrichedEntity(**nlp_entity.model_dump())
    enriched_entity_shell.backend_category = "TEST_CATEGORY" # Placeholder

    # 3. Call enrich_single_entity
    # Ensure the global terminology_service in main.py is set if that's what enrich_single_entity uses.
    # This was handled by initialize_services_for_test patching.
    request_id = f"test_{entity_name.lower()}"
    
    try:
        log_and_flush("INFO", f"Calling enrich_single_entity for CUI: {cui}...")
        result_entity = await enrich_single_entity(enriched_entity_shell, request_id)

        log_and_flush("INFO", f"Enrichment complete for {entity_name}. Output:")
        log_and_flush("INFO", result_entity.model_dump_json(exclude_none=True, indent=2))
        
        if result_entity.preferred_name_ks:
            log_and_flush("INFO", f"  Preferred Name (KS): {result_entity.preferred_name_ks}")
        else:
            log_and_flush("WARNING", f"  No preferred_name_ks populated for {cui}")

        if result_entity.standard_codes:
            log_and_flush("INFO", f"  Standard Codes Found ({len(result_entity.standard_codes)}):")
            for sc in result_entity.standard_codes:
                log_and_flush("INFO", f"    - Vocab: {sc.vocabulary}, Code: {sc.code}, Display: {sc.display}")
        else:
            log_and_flush("INFO", f"  No standard_codes populated for {cui}")
        
        if result_entity.fhir_codeable_concept:
            log_and_flush("INFO", f"  FHIR CodeableConcept Text: {result_entity.fhir_codeable_concept.get('text')}")
            log_and_flush("INFO", f"  FHIR CodeableConcept Codings ({len(result_entity.fhir_codeable_concept.get('coding',[]))}):")
            for coding in result_entity.fhir_codeable_concept.get('coding',[]):
                log_and_flush("INFO", f"    - System: {coding.get('system')}, Code: {coding.get('code')}, Display: {coding.get('display')}")
        else:
            log_and_flush("WARNING", f"  No fhir_codeable_concept generated for {cui}")

    except Exception as e:
        log_and_flush("ERROR", f"ERROR during enrichment test for {entity_name} (CUI: {cui}): {e}")
        import traceback
        log_and_flush("ERROR", traceback.format_exc())

async def main_test_runner():
    log_and_flush("INFO", "Starting main_test_runner...")
    try:
        await initialize_services_for_test()
        log_and_flush("INFO", "Services initialized successfully")

        # Test specific CUIs
        log_and_flush("INFO", "Starting test cases...")
        await run_single_test("Diabetes Mellitus", TEST_CUIS["diabetes"], text_mention="diabetes")
        await run_single_test("Lisinopril", TEST_CUIS["lisinopril"], text_mention="Lisinopril")
        await run_single_test("Appendectomy", TEST_CUIS["appendectomy"], text_mention="appendectomy")
        await run_single_test("Hemoglobin A1c", TEST_CUIS["hemoglobin_a1c"], text_mention="HbA1c test")
        await run_single_test("Thyroid Function Test (Correct CUI)", TEST_CUIS["thyroid_function_test_CORRECT"], text_mention="thyroid function tests")
        await run_single_test("Carotene Measurement (The mislinked CUI)", TEST_CUIS["carotene_measurement_MISLINKED"], text_mention="carotene test")
        await run_single_test("Femur (FMA example)", TEST_CUIS["fma_concept_example"], text_mention="femur")
        await run_single_test("Myocardial Infarction (Many TUIs)", TEST_CUIS["entity_with_many_tuis"], text_mention="heart attack")
        await run_single_test("Aspirin", TEST_CUIS["aspirin"], text_mention="aspirin")
        
        log_and_flush("INFO", "Testing Non-Existent CUI...")
        await run_single_test("Non Existent Concept", TEST_CUIS["non_existent_cui"])
        log_and_flush("INFO", "All test cases completed")
    except Exception as e:
        log_and_flush("ERROR", f"Error in main_test_runner: {e}")
        import traceback
        log_and_flush("ERROR", traceback.format_exc())
        raise

if __name__ == "__main__":
    log_and_flush("INFO", "Starting standalone enrichment test script...")
    try:
        asyncio.run(main_test_runner())
        log_and_flush("INFO", "Standalone enrichment test script finished successfully.")
    except Exception as e:
        log_and_flush("ERROR", f"Script failed with error: {e}")
        import traceback
        log_and_flush("ERROR", traceback.format_exc())
        sys.exit(1)