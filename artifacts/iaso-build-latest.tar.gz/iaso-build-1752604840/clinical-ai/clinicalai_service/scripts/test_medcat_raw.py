# Create a simple test script: test_medcat_raw.py
from pathlib import Path
from medcat.cat import CAT
from medcat.cdb import CDB  
from medcat.vocab import Vocab

def test_raw_medcat():
    # Load your MedCAT model directly
    cdb_path = Path("clinicalai_service/models/trained_medcat_model/cdb.dat")
    vocab_path = Path("clinicalai_service/models/trained_medcat_model/vocab.dat")
    
    cdb = CDB.load(str(cdb_path))
    vocab = Vocab.load(str(vocab_path))
    
    # Create minimal CAT instance
    cat = CAT(cdb=cdb, vocab=vocab)
    
    # Test simple text
    text = "levothyroxine"
    print(f"Testing: '{text}'")
    
    result = cat.get_entities(text)
    entities = result.get('entities', {})
    
    print(f"Entities found: {len(entities)}")
    for ent_id, ent_data in entities.items():
        print(f"  - {ent_data}")

if __name__ == "__main__":
    test_raw_medcat()