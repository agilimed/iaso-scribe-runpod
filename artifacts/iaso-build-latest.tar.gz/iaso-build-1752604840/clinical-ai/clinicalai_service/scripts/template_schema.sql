-- Ensure the schema exists
CREATE SCHEMA IF NOT EXISTS clinical_consolidated;

-- Drop tables if they exist (for idempotency during development)
DROP TABLE IF EXISTS clinical_consolidated.nlp_rule_criteria CASCADE;
DROP TABLE IF EXISTS clinical_consolidated.nlp_mapping_rules CASCADE;
DROP TABLE IF EXISTS clinical_consolidated.nlp_answer_configs CASCADE;
DROP TABLE IF EXISTS clinical_consolidated.template_nlp_mappings CASCADE;


-- 1. nlp_answer_configs: Defines how answers are formatted
CREATE TABLE clinical_consolidated.nlp_answer_configs (
    id SERIAL PRIMARY KEY,
    config_name VARCHAR(255) UNIQUE NOT NULL,
    fhir_answer_type VARCHAR(50) NOT NULL 
        CHECK (fhir_answer_type IN ('valueString', 'valueCoding', 'valueCodeableConcept', 'valueBoolean', 'valueDate', 'valueDateTime', 'valueInteger', 'valueDecimal', 'valueQuantity', 'valueReference')),
    value_source_field VARCHAR(100) NULL, -- e.g., 'text', 'preferred_name_ks', 'primary_cui', 'first_snomed_code', 'negated' (for boolean)
    coding_system_priority TEXT NULL, -- Comma-separated: SNOMEDCT_US,RXNORM,LOINC
    codeable_concept_text_source VARCHAR(100) NULL, -- e.g., 'text', 'preferred_name_ks'
    default_boolean_value BOOLEAN NULL, -- Used if fhir_answer_type is valueBoolean
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
COMMENT ON COLUMN clinical_consolidated.nlp_answer_configs.value_source_field IS 'Which field from EnrichedEntity to use for the value (e.g., text, preferred_name_ks, primary_cui). Specific logic might be needed if complex source.';
COMMENT ON COLUMN clinical_consolidated.nlp_answer_configs.coding_system_priority IS 'For valueCoding/CodeableConcept: comma-separated list of preferred system keys (e.g., SNOMEDCT_US,RXNORM).';


-- 2. template_nlp_mappings: Links Questionnaire items to NLP mapping configurations
CREATE TABLE clinical_consolidated.template_nlp_mappings (
    id SERIAL PRIMARY KEY,
    template_id VARCHAR(255) NOT NULL, -- Corresponds to questionnaires.id
    item_link_id VARCHAR(255) NOT NULL,
    description TEXT NULL,
    priority INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_template_item_link UNIQUE (template_id, item_link_id)
);
COMMENT ON COLUMN clinical_consolidated.template_nlp_mappings.template_id IS 'Logical ID of the FHIR Questionnaire template.';
COMMENT ON COLUMN clinical_consolidated.template_nlp_mappings.item_link_id IS 'The linkId of the item in the Questionnaire.';


-- 3. nlp_mapping_rules: Defines a set of criteria and an answer format for a mapping
CREATE TABLE clinical_consolidated.nlp_mapping_rules (
    id SERIAL PRIMARY KEY,
    mapping_id INTEGER NOT NULL REFERENCES clinical_consolidated.template_nlp_mappings(id) ON DELETE CASCADE,
    rule_name VARCHAR(255) NULL,
    match_logic VARCHAR(50) DEFAULT 'ALL_CRITERIA_MET' CHECK (match_logic IN ('ALL_CRITERIA_MET', 'ANY_CRITERION_MET')),
    answer_config_id INTEGER NOT NULL REFERENCES clinical_consolidated.nlp_answer_configs(id),
    max_answers INTEGER DEFAULT 1, -- -1 for unlimited/all matches
    priority INTEGER DEFAULT 0, -- Evaluation order for rules under the same mapping_id
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
COMMENT ON COLUMN clinical_consolidated.nlp_mapping_rules.mapping_id IS 'FK to template_nlp_mappings.id.';
COMMENT ON COLUMN clinical_consolidated.nlp_mapping_rules.answer_config_id IS 'FK to nlp_answer_configs.id, defining how to format the answer.';
COMMENT ON COLUMN clinical_consolidated.nlp_mapping_rules.max_answers IS 'Maximum number of entities this rule can populate for the item. -1 for all matches.';


-- 4. nlp_rule_criteria: Specific conditions for an NLP entity to match a rule
CREATE TABLE clinical_consolidated.nlp_rule_criteria (
    id SERIAL PRIMARY KEY,
    rule_id INTEGER NOT NULL REFERENCES clinical_consolidated.nlp_mapping_rules(id) ON DELETE CASCADE,
    criterion_type VARCHAR(100) NOT NULL 
        CHECK (criterion_type IN (
            'BACKEND_CATEGORY',    -- Matches EnrichedEntity.backend_category
            'SECTION_KEYWORD',     -- Substring match in EnrichedEntity.section_title (case-insensitive)
            'TUI_CODE',            -- Matches one of EnrichedEntity.type_ids
            'STY_NAME',            -- Matches one of EnrichedEntity.type_names
            'ENTITY_TEXT_REGEX',   -- Regex match on EnrichedEntity.text
            'NEGATION_STATUS',     -- Matches EnrichedEntity.negated (value "true" or "false")
            'HISTORICAL_STATUS',   -- Matches EnrichedEntity.historical (value "true" or "false")
            'HYPOTHETICAL_STATUS', -- Matches EnrichedEntity.hypothetical (value "true" or "false")
            'FAMILY_HISTORY_STATUS',-- Matches EnrichedEntity.family_history (value "true" or "false")
            'NER_CONFIDENCE',      -- Matches EnrichedEntity.ner_confidence
            'SOURCE_NER_ENGINE'    -- Matches EnrichedEntity.source_ner_engine ('medcat', 'spacy_ner')
            -- Add more as needed
        )),
    operator VARCHAR(50) DEFAULT 'EQUALS' 
        CHECK (operator IN ('EQUALS', 'NOT_EQUALS', 'CONTAINS', 'IN_LIST', 'NOT_IN_LIST', 'REGEX_MATCH', 'GREATER_THAN', 'LESS_THAN', 'GREATER_THAN_OR_EQUAL', 'LESS_THAN_OR_EQUAL', 'IS_TRUE', 'IS_FALSE', 'IS_NULL', 'IS_NOT_NULL')),
    criterion_value TEXT NULL, -- Value for comparison. For IN_LIST, use comma-separated. For IS_TRUE/FALSE/NULL, this can be NULL.
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
COMMENT ON COLUMN clinical_consolidated.nlp_rule_criteria.rule_id IS 'FK to nlp_mapping_rules.id.';
COMMENT ON COLUMN clinical_consolidated.nlp_rule_criteria.criterion_value IS 'Value for comparison. For IN_LIST, use comma-separated. For boolean status checks (IS_TRUE/FALSE), this can be NULL.';

-- Example Data (Illustrative - adapt to your exact needs)

-- Ensure schema exists (if not already done by table creation script)
CREATE SCHEMA IF NOT EXISTS clinical_consolidated;

-- Clear existing mapping data for "soap-note-general" to avoid conflicts if re-running
-- This is aggressive for production but useful during development.
-- Make sure to adjust if you have other templates mapped.
DELETE FROM clinical_consolidated.nlp_rule_criteria 
WHERE rule_id IN (
    SELECT r.id FROM clinical_consolidated.nlp_mapping_rules r
    JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
    WHERE m.template_id = 'soap-note-general'
);

DELETE FROM clinical_consolidated.nlp_mapping_rules 
WHERE mapping_id IN (
    SELECT id FROM clinical_consolidated.template_nlp_mappings WHERE template_id = 'soap-note-general'
);

DELETE FROM clinical_consolidated.template_nlp_mappings WHERE template_id = 'soap-note-general';

-- It's generally safer to not delete from nlp_answer_configs unless you're sure,
-- as they are meant to be reusable. If you need to reset them:
-- DELETE FROM clinical_consolidated.nlp_answer_configs WHERE config_name LIKE 'SOAP_%';


----------------------------------------------------
-- 1. Populate nlp_answer_configs (Reusable)
----------------------------------------------------
-- These should ideally be populated once and reused across different template mappings.
-- If they exist from previous scripts, you might not need to re-insert.
-- Using ON CONFLICT DO NOTHING to avoid errors if they already exist by config_name.

INSERT INTO clinical_consolidated.nlp_answer_configs 
    (config_name, fhir_answer_type, value_source_field, codeable_concept_text_source, coding_system_priority)
VALUES 
    ('SOAP_DefaultString_EntityText', 'valueString', 'text', NULL, NULL)
ON CONFLICT (config_name) DO NOTHING;

INSERT INTO clinical_consolidated.nlp_answer_configs 
    (config_name, fhir_answer_type, value_source_field, codeable_concept_text_source, coding_system_priority)
VALUES 
    ('SOAP_DefaultCodeableConcept_PreferredName', 'valueCodeableConcept', 'text', 'preferred_name_ks', 'SNOMEDCT_US,RXNORM,LOINC,ICD10CM,UMLS')
ON CONFLICT (config_name) DO NOTHING;

INSERT INTO clinical_consolidated.nlp_answer_configs 
    (config_name, fhir_answer_type, value_source_field, codeable_concept_text_source, coding_system_priority)
VALUES 
    ('SOAP_Medication_CodeableConcept', 'valueCodeableConcept', 'text', 'preferred_name_ks', 'RXNORM,SNOMEDCT_US,UMLS')
ON CONFLICT (config_name) DO NOTHING;

-- For the "nlp-notes-summary" which is usually a direct string from LLM summary
INSERT INTO clinical_consolidated.nlp_answer_configs 
    (config_name, fhir_answer_type, value_source_field)
VALUES 
    ('SOAP_SummaryString', 'valueString', NULL) -- value_source_field is NULL because it's not from an entity property
ON CONFLICT (config_name) DO NOTHING;


----------------------------------------------------
-- 2. Populate template_nlp_mappings for "soap-note-general"
----------------------------------------------------
-- Get IDs for answer configs (adjust if your IDs are different or names change)
-- These SELECTs are for illustration; in a script, you'd use the actual IDs.
-- For simplicity in this static script, we'll assume some IDs or re-query them if needed in a more dynamic setup.
-- Let's assume:
-- ID for 'SOAP_DefaultCodeableConcept_PreferredName' is, say, 1 (after insert)
-- ID for 'SOAP_Medication_CodeableConcept' is, say, 2
-- ID for 'SOAP_SummaryString' is, say, 3

INSERT INTO clinical_consolidated.template_nlp_mappings (template_id, item_link_id, description) VALUES
    ('soap-note-general', 'subjective', 'Maps NLP entities to Subjective findings section'),
    ('soap-note-general', 'objective', 'Maps NLP entities to Objective findings section'),
    ('soap-note-general', 'assessment', 'Maps NLP entities to Assessment/Diagnosis section'),
    ('soap-note-general', 'plan', 'Maps NLP entities to Plan section'),
    ('soap-note-general', 'nlp-notes-summary', 'Placeholder for LLM generated summary');

-- To make the rest of the script runnable, let's find the actual IDs:
-- (This is a bit clunky for a static script but shows the intent)
-- In a real ETL/seeding script, you'd capture RETURNING id or query them more robustly.

----------------------------------------------------
-- 3. Populate nlp_mapping_rules 
----------------------------------------------------
-- For 'subjective' item (assuming its template_nlp_mappings.id is X)
-- Rule: Conditions/Symptoms from HPI/CC
INSERT INTO clinical_consolidated.nlp_mapping_rules (mapping_id, rule_name, answer_config_id, max_answers, priority)
SELECT 
    m.id, 
    'Subjective_ConditionsSymptoms', 
    ac.id, 
    -1, -- All matching entities
    10
FROM clinical_consolidated.template_nlp_mappings m, clinical_consolidated.nlp_answer_configs ac
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'subjective'
  AND ac.config_name = 'SOAP_DefaultCodeableConcept_PreferredName';

-- Rule: Patient-reported Observations from HPI/CC
INSERT INTO clinical_consolidated.nlp_mapping_rules (mapping_id, rule_name, answer_config_id, max_answers, priority)
SELECT 
    m.id, 
    'Subjective_Observations', 
    ac.id, 
    -1, 
    20
FROM clinical_consolidated.template_nlp_mappings m, clinical_consolidated.nlp_answer_configs ac
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'subjective'
  AND ac.config_name = 'SOAP_DefaultCodeableConcept_PreferredName';


-- For 'objective' item (assuming its template_nlp_mappings.id is Y)
-- Rule: Objective Vitals/Labs/Exam findings
INSERT INTO clinical_consolidated.nlp_mapping_rules (mapping_id, rule_name, answer_config_id, max_answers, priority)
SELECT 
    m.id, 
    'Objective_Observations', 
    ac.id, 
    -1, 
    10
FROM clinical_consolidated.template_nlp_mappings m, clinical_consolidated.nlp_answer_configs ac
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'objective'
  AND ac.config_name = 'SOAP_DefaultCodeableConcept_PreferredName';


-- For 'assessment' item (assuming its template_nlp_mappings.id is Z)
-- Rule: Diagnoses/Conditions from Assessment section
INSERT INTO clinical_consolidated.nlp_mapping_rules (mapping_id, rule_name, answer_config_id, max_answers, priority)
SELECT 
    m.id, 
    'Assessment_Diagnoses', 
    ac.id, 
    -1, 
    10
FROM clinical_consolidated.template_nlp_mappings m, clinical_consolidated.nlp_answer_configs ac
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'assessment'
  AND ac.config_name = 'SOAP_DefaultCodeableConcept_PreferredName';


-- For 'plan' item (assuming its template_nlp_mappings.id is A)
-- Rule: Medications from Plan section
INSERT INTO clinical_consolidated.nlp_mapping_rules (mapping_id, rule_name, answer_config_id, max_answers, priority)
SELECT 
    m.id, 
    'Plan_Medications', 
    ac.id, 
    -1, 
    10
FROM clinical_consolidated.template_nlp_mappings m, clinical_consolidated.nlp_answer_configs ac
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'plan'
  AND ac.config_name = 'SOAP_Medication_CodeableConcept';

-- Rule: Procedures from Plan section
INSERT INTO clinical_consolidated.nlp_mapping_rules (mapping_id, rule_name, answer_config_id, max_answers, priority)
SELECT 
    m.id, 
    'Plan_Procedures', 
    ac.id, 
    -1, 
    20
FROM clinical_consolidated.template_nlp_mappings m, clinical_consolidated.nlp_answer_configs ac
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'plan'
  AND ac.config_name = 'SOAP_DefaultCodeableConcept_PreferredName';

-- For 'nlp-notes-summary' item: This item is special.
-- It's typically filled directly by the LLM summary, not by entity matching rules.
-- However, we might still create a mapping entry for it if, for example, we want to control its answer type.
-- If no entity matching is intended, it won't have nlp_mapping_rules or criteria entries.
-- The python code in config_driven_mapper.py has special handling for linkId 'nlp-notes-summary'.
-- Alternatively, we could define an answer_config for it and an empty rule.
INSERT INTO clinical_consolidated.nlp_mapping_rules (mapping_id, rule_name, answer_config_id, max_answers, priority)
SELECT 
    m.id, 
    'Summary_Note_Direct_Text', 
    ac.id, 
    1, -- Only one summary string
    10
FROM clinical_consolidated.template_nlp_mappings m, clinical_consolidated.nlp_answer_configs ac
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'nlp-notes-summary'
  AND ac.config_name = 'SOAP_SummaryString';
-- This rule for 'nlp-notes-summary' will likely NOT have criteria, as the text comes from LLM.
-- The mapper python code needs to handle this special case if `summary_text` is provided.


----------------------------------------------------
-- 4. Populate nlp_rule_criteria
----------------------------------------------------
-- Criteria for 'Subjective_ConditionsSymptoms' (Rule ID will vary, assume it's the one linked to subjective mapping)
INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT 
    r.id, 'BACKEND_CATEGORY', 'IN_LIST', 'CONDITION,SYMPTOM'
FROM clinical_consolidated.nlp_mapping_rules r
JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'subjective' AND r.rule_name = 'Subjective_ConditionsSymptoms';

INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT 
    r.id, 'SECTION_KEYWORD', 'IN_LIST', 'chief complaint,history of present illness,hpi,subjective'
FROM clinical_consolidated.nlp_mapping_rules r
JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'subjective' AND r.rule_name = 'Subjective_ConditionsSymptoms';

INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT 
    r.id, 'NEGATION_STATUS', 'IS_FALSE', NULL
FROM clinical_consolidated.nlp_mapping_rules r
JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'subjective' AND r.rule_name = 'Subjective_ConditionsSymptoms';


-- Criteria for 'Subjective_Observations'
INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'BACKEND_CATEGORY', 'EQUALS', 'OBSERVATION'
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'subjective' AND r.rule_name = 'Subjective_Observations';

INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'SECTION_KEYWORD', 'IN_LIST', 'chief complaint,history of present illness,hpi,subjective'
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'subjective' AND r.rule_name = 'Subjective_Observations';

INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'NEGATION_STATUS', 'IS_FALSE', NULL
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'subjective' AND r.rule_name = 'Subjective_Observations';


-- Criteria for 'Objective_Observations'
INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'BACKEND_CATEGORY', 'IN_LIST', 'OBSERVATION,LAB_RESULT,VITAL_SIGN,PHYSICAL_FINDING'
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'objective' AND r.rule_name = 'Objective_Observations';

INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'SECTION_KEYWORD', 'IN_LIST', 'physical exam,physical examination,exam,pe,vital signs,vitals,laboratory data,labs,results,imaging,radiology,objective'
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'objective' AND r.rule_name = 'Objective_Observations';

INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'NEGATION_STATUS', 'IS_FALSE', NULL
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'objective' AND r.rule_name = 'Objective_Observations';


-- Criteria for 'Assessment_Diagnoses'
INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'BACKEND_CATEGORY', 'IN_LIST', 'CONDITION,DIAGNOSIS,PROBLEM'
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'assessment' AND r.rule_name = 'Assessment_Diagnoses';

INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'SECTION_KEYWORD', 'IN_LIST', 'assessment,impression,problem list,assessment and plan'
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'assessment' AND r.rule_name = 'Assessment_Diagnoses';

INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'NEGATION_STATUS', 'IS_FALSE', NULL
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'assessment' AND r.rule_name = 'Assessment_Diagnoses';


-- Criteria for 'Plan_Medications'
INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'BACKEND_CATEGORY', 'EQUALS', 'DRUG'
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'plan' AND r.rule_name = 'Plan_Medications';

INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'SECTION_KEYWORD', 'IN_LIST', 'plan,medications,orders,treatment,assessment and plan'
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'plan' AND r.rule_name = 'Plan_Medications';

INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'NEGATION_STATUS', 'IS_FALSE', NULL
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'plan' AND r.rule_name = 'Plan_Medications';


-- Criteria for 'Plan_Procedures'
INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'BACKEND_CATEGORY', 'EQUALS', 'PROCEDURE'
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'plan' AND r.rule_name = 'Plan_Procedures';

INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'SECTION_KEYWORD', 'IN_LIST', 'plan,orders,treatment,assessment and plan'
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'plan' AND r.rule_name = 'Plan_Procedures';

INSERT INTO clinical_consolidated.nlp_rule_criteria (rule_id, criterion_type, operator, criterion_value)
SELECT r.id, 'NEGATION_STATUS', 'IS_FALSE', NULL
FROM clinical_consolidated.nlp_mapping_rules r JOIN clinical_consolidated.template_nlp_mappings m ON r.mapping_id = m.id
WHERE m.template_id = 'soap-note-general' AND m.item_link_id = 'plan' AND r.rule_name = 'Plan_Procedures';


-- For 'Summary_Note_Direct_Text' rule for 'nlp-notes-summary':
-- No criteria needed, as this is handled by direct summary text insertion in Python.
-- The rule is mostly a placeholder to associate an answer_config.
-- The python mapper will specifically look for linkId 'nlp-notes-summary' (or a similar placeholder)
-- and use the LLM summary text directly, bypassing entity-rule matching for this item.

SELECT 'Finished populating mapping data for soap-note-general';