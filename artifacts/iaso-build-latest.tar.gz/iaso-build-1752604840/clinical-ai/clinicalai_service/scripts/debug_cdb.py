# debug_cdb.py
from pathlib import Path
from medcat.cdb import CDB

def check_cdb_terms():
    cdb_path = Path("clinicalai_service/models/trained_medcat_model/cdb.dat")
    
    if not cdb_path.exists():
        print(f"❌ CDB not found: {cdb_path}")
        return
    
    cdb = CDB.load(str(cdb_path))
    
    target_terms = ["levothyroxine", "amlodipine", "hypothyroidism"]
    
    print("=== CDB TERM CHECK ===")
    for term in target_terms:
        variations = [term, term.lower(), term.upper(), term.capitalize()]
        found = False
        
        for var in variations:
            if hasattr(cdb, 'name2cuis') and var in cdb.name2cuis:
                cuis = list(cdb.name2cuis[var])[:3]
                print(f"✅ '{var}' -> {cuis}")
                found = True
                break
        
        if not found:
            print(f"❌ '{term}' not found in any variation")
    
    print(f"\nTotal names in CDB: {len(cdb.name2cuis) if hasattr(cdb, 'name2cuis') else 'Unknown'}")

if __name__ == "__main__":
    check_cdb_terms()