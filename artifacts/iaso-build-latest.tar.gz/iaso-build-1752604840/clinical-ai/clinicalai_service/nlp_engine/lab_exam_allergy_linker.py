import os
import re
import logging
from typing import List, Dict, Any, Optional
import asyncio

import spacy

try:
    from config import SPACY_MODEL_NAME, ENABLE_LAB_EXAM_ALLERGY_LINKER
except ImportError:
    SPACY_MODEL_NAME = os.getenv("SPACY_MODEL_NAME", "en_core_sci_lg")
    ENABLE_LAB_EXAM_ALLERGY_LINKER = os.getenv("ENABLE_LAB_EXAM_ALLERGY_LINKER", "true").lower() in ("1", "true", "yes")

try:
    from .rules import (
        LAB_RESULT_PATTERNS_MAP, VITAL_PATTERNS_MAP, ALLERGY_PATTERNS_MAP,
        is_valid_lab_name, is_valid_vital_name, is_valid_allergy_substance,
        validate_numeric_range, validate_with_terminology_service,
        validate_with_terminology_service_sync
    )
    from ..clients.terminology_client import TerminologyServiceClient
except ImportError:
    raise ImportError("Pattern maps, validation functions, and terminology client must be available.")

logger = logging.getLogger("lab_exam_allergy_linker")
logger.setLevel(logging.INFO)

class SpacyModelSingleton:
    _instance = None
    @classmethod
    def get_model(cls):
        if cls._instance is None:
            try:
                cls._instance = spacy.load(SPACY_MODEL_NAME)
                logger.info(f"Loaded spaCy model: {SPACY_MODEL_NAME}")
            except Exception as e:
                logger.warning(f"Could not load spaCy model '{SPACY_MODEL_NAME}': {e}")
                cls._instance = spacy.blank("en")
        return cls._instance

async def extract_lab_exam_allergy_with_terminology(text: str, terminology_client: Optional[TerminologyServiceClient] = None) -> List[Dict[str, Any]]:
    """
    Extract lab results, vitals, and allergies with clinical validation and terminology service verification.
    """
    results = []

    # LABS - with enhanced validation
    for lab_def in LAB_RESULT_PATTERNS_MAP:
        for match in re.finditer(lab_def["pattern"], text, flags=re.IGNORECASE):
            # Extract basic information
            lab_name = lab_def["name"] if lab_def["name"] else (match.group(1).strip() if match.lastindex >= 1 else None)
            
            # Skip if no valid lab name
            if not lab_name:
                continue
            
            # First-level validation (local)
            if not is_valid_lab_name(lab_name):
                logger.debug(f"Rejected invalid lab name (local): '{lab_name}'")
                continue
            
            # Extract field values first
            res = {
                "type": "LAB_RESULT",
                "name": lab_name,
                "span": [match.start(0), match.end(0)],
                "confidence": lab_def.get("confidence", 0.8),
                "validation_method": "local"
            }
            
            for i, field in enumerate(lab_def.get("fields", [])):
                if field:  # skip None
                    group_idx = i + 1
                    # Adjust for named patterns
                    if lab_def["name"] is None and field == "name":
                        group_idx = 1
                    elif lab_def["name"] is not None and field == "value":
                        group_idx = 2  # Skip the name group
                    
                    if match.lastindex and group_idx <= match.lastindex:
                        value = match.group(group_idx)
                        if value:
                            res[field] = value.strip()
            
            # Validate numeric values if present
            if "value" in res:
                if not validate_numeric_range(res["value"], lab_name):
                    logger.debug(f"Rejected lab '{lab_name}' with invalid value: {res['value']}")
                    continue
            
            # Enhanced validation with terminology service
            if terminology_client:
                try:
                    is_valid, term_confidence, cui_or_reason = await validate_with_terminology_service(
                        lab_name, "LAB_RESULT", terminology_client
                    )
                    
                    if is_valid:
                        res["confidence"] = min(1.0, res["confidence"] + 0.2)  # Boost confidence
                        res["validation_method"] = "terminology_service"
                        res["cui"] = cui_or_reason if cui_or_reason.startswith("C") else None
                        res["terminology_confidence"] = term_confidence
                        logger.debug(f"✅ Terminology validated lab: '{lab_name}' -> {cui_or_reason}")
                    else:
                        # If terminology service says it's not a lab, reduce confidence but don't reject
                        if "wrong_category" in cui_or_reason:
                            res["confidence"] = max(0.3, res["confidence"] - 0.3)
                            res["validation_warning"] = cui_or_reason
                            logger.debug(f"⚠️ Terminology mismatch for lab: '{lab_name}' -> {cui_or_reason}")
                        elif "not_found" in cui_or_reason:
                            res["confidence"] = max(0.4, res["confidence"] - 0.2)
                            res["validation_warning"] = "not_in_umls"
                            logger.debug(f"⚠️ Lab not found in UMLS: '{lab_name}'")
                        else:
                            # Terminology service error - keep local validation
                            logger.debug(f"Terminology service error for '{lab_name}': {cui_or_reason}")
                            
                except Exception as e:
                    logger.debug(f"Terminology validation error for '{lab_name}': {e}")
            else:
                # Fallback to synchronous validation
                is_valid, term_confidence, reason = validate_with_terminology_service_sync(lab_name, "LAB_RESULT")
                if is_valid:
                    res["confidence"] = min(1.0, res["confidence"] + 0.1)
                    res["validation_method"] = "local_enhanced"
            
            # Set unit
            if "unit" in lab_def and lab_def["unit"]:
                res["unit"] = lab_def["unit"]
            elif "unit" in lab_def.get("fields", []):
                unit_idx = lab_def["fields"].index("unit") + 1
                if match.lastindex and unit_idx <= match.lastindex:
                    unit_value = match.group(unit_idx)
                    if unit_value:
                        res["unit"] = unit_value.strip()
            
            results.append(res)

    # VITALS - with enhanced validation
    for vital_def in VITAL_PATTERNS_MAP:
        for match in re.finditer(vital_def["pattern"], text, flags=re.IGNORECASE):
            vital_name = vital_def["name"]
            
            # Local validation
            if not is_valid_vital_name(vital_name):
                logger.debug(f"Rejected invalid vital name (local): '{vital_name}'")
                continue
            
            res = {
                "type": "VITAL",
                "name": vital_name,
                "span": [match.start(0), match.end(0)],
                "confidence": vital_def.get("confidence", 0.8),
                "validation_method": "local"
            }
            
            # Extract field values
            for i, field in enumerate(vital_def.get("fields", [])):
                if field:
                    group_idx = i + 2  # Skip the name group which is group 1
                    if match.lastindex and group_idx <= match.lastindex:
                        value = match.group(group_idx)
                        if value:
                            res[field] = value.strip()
            
            # Validate vital sign values
            if "value" in res:
                vital_type = vital_name.lower().replace(" ", "_")
                if not validate_numeric_range(res["value"], vital_type):
                    logger.debug(f"Rejected vital '{vital_name}' with invalid value: {res['value']}")
                    continue
            
            # Validate blood pressure values
            if "systolic" in res and "diastolic" in res:
                if not (validate_numeric_range(res["systolic"], "systolic_bp") and 
                        validate_numeric_range(res["diastolic"], "diastolic_bp")):
                    logger.debug(f"Rejected BP with invalid values: {res['systolic']}/{res['diastolic']}")
                    continue
            
            # Enhanced validation with terminology service
            if terminology_client:
                try:
                    is_valid, term_confidence, cui_or_reason = await validate_with_terminology_service(
                        vital_name, "VITAL_SIGN", terminology_client
                    )
                    
                    if is_valid:
                        res["confidence"] = min(1.0, res["confidence"] + 0.15)
                        res["validation_method"] = "terminology_service"
                        res["cui"] = cui_or_reason if cui_or_reason.startswith("C") else None
                        res["terminology_confidence"] = term_confidence
                        logger.debug(f"✅ Terminology validated vital: '{vital_name}' -> {cui_or_reason}")
                        
                except Exception as e:
                    logger.debug(f"Terminology validation error for vital '{vital_name}': {e}")
            else:
                # Fallback validation
                is_valid, term_confidence, reason = validate_with_terminology_service_sync(vital_name, "VITAL_SIGN")
                if is_valid:
                    res["confidence"] = min(1.0, res["confidence"] + 0.1)
                    res["validation_method"] = "local_enhanced"
            
            results.append(res)

    # ALLERGIES - with enhanced validation
    for allergy_def in ALLERGY_PATTERNS_MAP:
        for match in re.finditer(allergy_def["pattern"], text, flags=re.IGNORECASE):
            # Handle special case for "no allergies"
            if allergy_def.get("special") == "no_allergies":
                res = {
                    "type": "ALLERGY",
                    "substance": "NKDA",
                    "span": [match.start(0), match.end(0)],
                    "confidence": allergy_def.get("confidence", 0.95),
                    "validation_method": "special_case"
                }
                results.append(res)
                continue
            
            res = {
                "type": "ALLERGY",
                "span": [match.start(0), match.end(0)],
                "confidence": allergy_def.get("confidence", 0.8),
                "validation_method": "local"
            }
            
            # Extract substance
            for i, field in enumerate(allergy_def.get("fields", [])):
                if field == "substance":
                    group_idx = i + 2  # Skip the trigger phrase group
                    if match.lastindex and group_idx <= match.lastindex:
                        substance = match.group(group_idx)
                        if substance:
                            substance = substance.strip()
                            
                            # Local validation
                            if not is_valid_allergy_substance(substance):
                                logger.debug(f"Rejected invalid allergy substance (local): '{substance}'")
                                break
                            
                            res[field] = substance
                            
                            # Enhanced validation with terminology service
                            if terminology_client:
                                try:
                                    is_valid, term_confidence, cui_or_reason = await validate_with_terminology_service(
                                        substance, "ALLERGY", terminology_client
                                    )
                                    
                                    if is_valid:
                                        res["confidence"] = min(1.0, res["confidence"] + 0.2)
                                        res["validation_method"] = "terminology_service"
                                        res["cui"] = cui_or_reason if cui_or_reason.startswith("C") else None
                                        res["terminology_confidence"] = term_confidence
                                        logger.debug(f"✅ Terminology validated allergy: '{substance}' -> {cui_or_reason}")
                                        
                                except Exception as e:
                                    logger.debug(f"Terminology validation error for allergy '{substance}': {e}")
                            else:
                                # Fallback validation
                                is_valid, term_confidence, reason = validate_with_terminology_service_sync(substance, "ALLERGY")
                                if is_valid:
                                    res["confidence"] = min(1.0, res["confidence"] + 0.1)
                                    res["validation_method"] = "local_enhanced"
            
            # Only add if we have a valid substance
            if "substance" in res:
                results.append(res)

    # Remove duplicates based on span overlap
    results = remove_overlapping_results(results)
    
    logger.info(f"Extracted {len(results)} validated lab/vital/allergy entities with terminology service")
    return results

def extract_lab_exam_allergy(text: str) -> List[Dict[str, Any]]:
    """
    Synchronous wrapper for backward compatibility.
    Uses local validation only.
    """
    # Run the async version with no terminology client
    try:
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(extract_lab_exam_allergy_with_terminology(text, None))
    except RuntimeError:
        # If no event loop, create one
        return asyncio.run(extract_lab_exam_allergy_with_terminology(text, None))

def remove_overlapping_results(results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Remove overlapping results, keeping the one with higher confidence."""
    if not results:
        return results
    
    # Sort by confidence (highest first)
    sorted_results = sorted(results, key=lambda x: x.get("confidence", 0.5), reverse=True)
    
    filtered_results = []
    for result in sorted_results:
        span = result["span"]
        overlaps = False
        
        for existing in filtered_results:
            existing_span = existing["span"]
            # Check for overlap
            if not (span[1] <= existing_span[0] or span[0] >= existing_span[1]):
                overlaps = True
                break
        
        if not overlaps:
            filtered_results.append(result)
    
    return filtered_results

async def lab_exam_allergy_linker_pipeline_async(text: str, config: Optional[dict] = None, terminology_client: Optional[TerminologyServiceClient] = None) -> List[Dict[str, Any]]:
    """
    Async pipeline function for extracting validated lab/vital/allergy entities with terminology service.
    """
    enabled = ENABLE_LAB_EXAM_ALLERGY_LINKER
    if config and "ENABLE_LAB_EXAM_ALLERGY_LINKER" in config:
        enabled = config["ENABLE_LAB_EXAM_ALLERGY_LINKER"]
    
    if not enabled:
        logger.info("Lab/Exam/Allergy linker disabled by config/env.")
        return []
    
    try:
        return await extract_lab_exam_allergy_with_terminology(text, terminology_client)
    except Exception as e:
        logger.error(f"Error in lab_exam_allergy_linker_pipeline_async: {e}")
        return []

def lab_exam_allergy_linker_pipeline(text: str, config: Optional[dict]=None) -> List[Dict[str, Any]]:
    """
    Main pipeline function for extracting validated lab/vital/allergy entities.
    Synchronous version for backward compatibility.
    """
    enabled = ENABLE_LAB_EXAM_ALLERGY_LINKER
    if config and "ENABLE_LAB_EXAM_ALLERGY_LINKER" in config:
        enabled = config["ENABLE_LAB_EXAM_ALLERGY_LINKER"]
    
    if not enabled:
        logger.info("Lab/Exam/Allergy linker disabled by config/env.")
        return []
    
    try:
        return extract_lab_exam_allergy(text)
    except Exception as e:
        logger.error(f"Error in lab_exam_allergy_linker_pipeline: {e}")
        return []
