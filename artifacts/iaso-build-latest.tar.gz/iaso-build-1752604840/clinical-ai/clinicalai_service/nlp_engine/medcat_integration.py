# clinicalai_service/nlp_engine/medcat_integration.py
"""
MedCAT 1.16 Integration Module
Proper integration of MedCAT with fixes for version 1.16 issues
"""

import logging
from typing import Optional, Dict, Any, List
from pathlib import Path

# MedCAT imports
try:
    from medcat.cat import CAT
    from medcat.cdb import CDB
    from medcat.vocab import Vocab
    from medcat.config import Config as MedCATConfig
    MEDCAT_AVAILABLE = True
except ImportError as e:
    CAT = CDB = Vocab = MedCATConfig = None
    MEDCAT_AVAILABLE = False

logger = logging.getLogger(__name__)


class MedCATProcessor:
    """
    MedCAT processor with 1.16 compatibility fixes
    """
    
    def __init__(
        self,
        cdb_path: Path,
        vocab_path: Path,
        config_path: Optional[Path] = None,
        spacy_model: str = "en_core_sci_lg"
    ):
        self.cdb_path = cdb_path
        self.vocab_path = vocab_path
        self.config_path = config_path
        self.spacy_model = spacy_model
        
        self.cat = None
        self.cdb = None
        self.vocab = None
        self.config = None
        self._is_loaded = False
        
        # Load MedCAT
        self._load_medcat()
    
    def _create_safe_config(self) -> MedCATConfig:
        """Create MedCAT configuration using environment variables"""
        from .. import config as app_config  # Import your config
        
        config = MedCATConfig()
        
        # General settings from environment
        config.general.spacy_model = self.spacy_model
        config.general.spacy_cat_mode = False
        config.general.device = 'cpu' if app_config.MEDCAT_FORCE_CPU else 'auto'
        config.general.spell_check = True
        
        # Linking settings - USE ENVIRONMENT VALUES
        config.linking.train = not app_config.MEDCAT_DISABLE_TRAINING  # Use env setting
        config.linking.calculate_dynamic_threshold = False
        config.linking.always_calculate_similarity = False
        config.linking.disambiguate = True
        config.linking.similarity_threshold = app_config.MEDCAT_SIMILARITY_THRESHOLD  # Use env: 0.2
        config.linking.context_similarity_threshold = app_config.MEDCAT_SIMILARITY_THRESHOLD
        
        # NER settings - USE ENVIRONMENT VALUES  
        config.ner.min_name_len = app_config.MEDCAT_MIN_NAME_LENGTH  # Use env: 2
        config.ner.max_name_len = app_config.MEDCAT_MAX_NAME_LENGTH  # Use env: 2
        config.prefer_longer_matches = app_config.PREFER_LONGER_MATCHES
        config.linking.prefer_longer_spans = True
        config.ner.upper_case_limit_len = 10
        config.ner.check_upper_case_names = True
        
        # Preprocessing
        config.preprocessing.do_spell_check = False
        config.preprocessing.spell_check_len_limit = 0
        
        logger.info(f"MedCAT Config: similarity_threshold={config.linking.similarity_threshold}, min_name_len={config.ner.min_name_len}")
    
        return config


def _fix_cdb_confidence_mapping(self, cdb: CDB) -> None:
    """Enhanced fix for CDB confidence mapping"""
    try:
        # Initialize if missing
        if not hasattr(cdb, 'cui2average_confidence'):
            cdb.cui2average_confidence = {}

        # Fix the specific problem CUIs
        problem_cuis = ['C0040165', 'C1881373']  # levothyroxine CUIs
        
        for cui in problem_cuis:
            if cui not in cdb.cui2average_confidence:
                cdb.cui2average_confidence[cui] = 0.8  # High confidence
                logger.info(f"Fixed confidence for problematic CUI: {cui}")
        
        # Get all CUIs and add missing ones
        all_cuis = set()
        if hasattr(cdb, 'cui2names') and cdb.cui2names:
            all_cuis.update(cdb.cui2names.keys())
        
        # Add default confidence for any missing CUIs
        default_confidence = 0.7
        added_count = 0
        
        for cui in all_cuis:
            if cui not in cdb.cui2average_confidence:
                cdb.cui2average_confidence[cui] = default_confidence
                added_count += 1
        
        logger.info(f"CDB confidence fix: added {added_count} missing confidence scores")
        
        # CRITICAL: Also check if vector context model exists
        if hasattr(cdb, 'addl_info') and 'context_model' in cdb.addl_info:
            logger.info("Context model found in CDB")
        else:
            logger.warning("⚠️  No context model in CDB - this explains the -1 similarities")
            # Disable context-based linking since we don't have the model
            
    except Exception as e:
        logger.error(f"Error fixing CDB confidence mapping: {e}")
    
    def _load_medcat(self) -> None:
        """Load MedCAT with proper error handling and fixes"""
        if not MEDCAT_AVAILABLE:
            logger.error("MedCAT library not available")
            return
        
        # Check required files
        if not self.cdb_path.exists():
            logger.error(f"CDB file not found: {self.cdb_path}")
            return
        
        if not self.vocab_path.exists():
            logger.error(f"Vocab file not found: {self.vocab_path}")
            return
        
        try:
            logger.info("Loading MedCAT components...")
            
            # Load CDB
            logger.info(f"Loading CDB from: {self.cdb_path}")
            self.cdb = CDB.load(str(self.cdb_path))
            logger.info(f"CDB loaded successfully")
            
            # Load Vocab
            logger.info(f"Loading Vocab from: {self.vocab_path}")
            self.vocab = Vocab.load(str(self.vocab_path))
            logger.info(f"Vocab loaded successfully")
            
            # Fix CDB confidence mapping (critical for 1.16)
            logger.info("Applying MedCAT 1.16 fixes...")
            self._fix_cdb_confidence_mapping(self.cdb)
            
            # Create configuration
            self.config = self._create_safe_config()
            
            # Load custom config if available
            if self.config_path and self.config_path.exists():
                try:
                    custom_config = MedCATConfig.load(str(self.config_path))
                    # Safely copy some settings
                    self.config.ner.min_name_len = custom_config.ner.get('min_name_len', 2)
                    self.config.ner.max_name_len = custom_config.ner.get('max_name_len', 2)
                    self.config.ner.upper_case_limit_len = custom_config.ner.get('upper_case_limit_len', 5)
                    # Keep safe linking settings
                    logger.info(f"Loaded safe settings from: {self.config_path}")
                except Exception as e:
                    logger.warning(f"Could not load custom config: {e}")
            
            # Create CAT instance
            logger.info("Creating MedCAT instance...")
            self.cat = CAT(cdb=self.cdb, vocab=self.vocab, config=self.config)
            
            # Test the instance
            logger.info("Testing MedCAT instance...")
            test_result = self._test_medcat()
            
            if test_result["success"]:
                self._is_loaded = True
                logger.info("MedCAT loaded and tested successfully")
            else:
                logger.error(f"MedCAT test failed: {test_result['error']}")
                self.cat = None
            
        except Exception as e:
            logger.error(f"Failed to load MedCAT: {e}", exc_info=True)
            self.cat = None
            self._is_loaded = False
    
    def _test_medcat(self) -> Dict[str, Any]:
        """Test MedCAT with progressively complex texts"""
        if not self.cat:
            return {"success": False, "error": "CAT instance not available"}
        
        test_texts = [
            "test",
            "patient", 
            "chest pain",
            "diabetes",
            "patient has chest pain"
        ]
        
        results = []
        
        for text in test_texts:
            try:
                result = self.cat.get_entities(text)
                entities = result.get('entities', {}) if isinstance(result, dict) else {}
                results.append({
                    "text": text,
                    "success": True,
                    "entity_count": len(entities)
                })
                logger.debug(f"✅ MedCAT test '{text}' -> {len(entities)} entities")
            except Exception as e:
                results.append({
                    "text": text,
                    "success": False,
                    "error": str(e)
                })
                logger.warning(f"❌ MedCAT test '{text}' -> Error: {e}")
        
        success_count = sum(1 for r in results if r["success"])
        success_rate = success_count / len(results)
        
        return {
            "success": success_rate > 0.5,  # At least 50% success rate
            "success_rate": success_rate,
            "results": results,
            "error": None if success_rate > 0.5 else "Low success rate"
        }
    
    def is_available(self) -> bool:
        """Check if MedCAT is loaded and available"""
        return self._is_loaded and self.cat is not None
    
    def get_entities(self, text: str) -> Dict[str, Any]:
        """
        Extract entities from text using MedCAT
        
        Args:
            text: Input text
            
        Returns:
            Dictionary with entities or error information
        """
        if not self.is_available():
            return {"error": "MedCAT not available", "entities": {}}
        
        try:
            result = self.cat.get_entities(text)
            return result if isinstance(result, dict) else {"entities": {}}
        except Exception as e:
            logger.error(f"Error extracting entities: {e}")
            return {"error": str(e), "entities": {}}
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get information about the loaded MedCAT model"""
        info = {
            "medcat_available": MEDCAT_AVAILABLE,
            "is_loaded": self._is_loaded,
            "cdb_path": str(self.cdb_path),
            "vocab_path": str(self.vocab_path),
            "config_path": str(self.config_path) if self.config_path else None,
            "spacy_model": self.spacy_model
        }
        
        if self.is_available():
            info.update({
                "cdb_concepts": len(self.cdb.cui2names) if self.cdb and hasattr(self.cdb, 'cui2names') else 0,
                "confidence_mappings": len(self.cdb.cui2average_confidence) if self.cdb and hasattr(self.cdb, 'cui2average_confidence') else 0,
                "vocab_size": len(self.vocab.vocab) if self.vocab and hasattr(self.vocab, 'vocab') else 0
            })
            
            if self.config:
                info["config"] = {
                    "similarity_threshold": self.config.linking.get('similarity_threshold'),
                    "min_name_len": self.config.ner.get('min_name_len'),
                    "max_name_len": self.config.ner.get('max_name_len'),
                    "disambiguate": self.config.linking.get('disambiguate'),
                    "train_mode": self.config.linking.get('train')
                }
        
        return info


# Singleton instance
_medcat_instance: Optional[MedCATProcessor] = None

def get_medcat_processor(
    cdb_path: Path,
    vocab_path: Path,
    config_path: Optional[Path] = None,
    spacy_model: str = "en_core_web_md"
) -> MedCATProcessor:
    """
    Get or create MedCAT processor singleton
    
    Args:
        cdb_path: Path to CDB file
        vocab_path: Path to vocab file
        config_path: Optional path to config file
        spacy_model: spaCy model name
        
    Returns:
        MedCATProcessor instance
    """
    global _medcat_instance
    
    if _medcat_instance is None:
        _medcat_instance = MedCATProcessor(
            cdb_path=cdb_path,
            vocab_path=vocab_path,
            config_path=config_path,
            spacy_model=spacy_model
        )
    
    return _medcat_instance


# spaCy integration
from spacy.language import Language
from spacy.tokens import Doc, Span

class MedCATSpacyComponent:
    """spaCy component for MedCAT integration"""
    
    def __init__(self, nlp: Language, medcat_processor: MedCATProcessor, name: str = "medcat"):
        self.name = name
        self.medcat = medcat_processor
        self._ensure_extensions()
    
    def _ensure_extensions(self):
        """Ensure spaCy extensions are available"""
        extensions = [
            ("cui", None),
            ("tuis", []),
            ("snames", []),
            ("pretty_name", None),
            ("score", None),
            ("detected_name", None),
            ("medcat_id", None),
            ("meta_anns", {}),
            ("medcat_confidence", None)
        ]
        
        for ext_name, default_val in extensions:
            if not Span.has_extension(ext_name):
                Span.set_extension(ext_name, default=default_val)
        
        if not Doc.has_extension("medcat_entities"):
            Doc.set_extension("medcat_entities", default={})
    
    def __call__(self, doc: Doc) -> Doc:
        """Process document with MedCAT"""
        if not self.medcat.is_available():
            logger.warning("MedCAT not available, skipping processing")
            return doc
        
        try:
            # Get entities from MedCAT
            medcat_result = self.medcat.get_entities(doc.text)
            
            if "error" in medcat_result:
                logger.warning(f"MedCAT processing error: {medcat_result['error']}")
                return doc
            
            entities = medcat_result.get("entities", {})
            if not entities:
                logger.debug("No entities found by MedCAT")
                return doc
            
            # Store raw MedCAT output
            doc._.medcat_entities = entities
            
            # Convert MedCAT entities to spaCy spans
            new_spans = []
            existing_spans = set((ent.start_char, ent.end_char) for ent in doc.ents)
            
            for ent_id, ent_data in entities.items():
                start = ent_data.get('start')
                end = ent_data.get('end')
                
                if start is None or end is None:
                    continue
                
                # Skip if span already exists (from other NER)
                if (start, end) in existing_spans:
                    continue
                
                try:
                    # Determine entity label
                    label = self._get_entity_label(ent_data)
                    
                    # Create spaCy span
                    span = doc.char_span(start, end, label=label, alignment_mode="contract")
                    
                    if span is not None:
                        # Set MedCAT attributes
                        span._.cui = ent_data.get('cui')
                        span._.tuis = ent_data.get('type_ids', [])
                        span._.snames = ent_data.get('snames', [])
                        span._.score = ent_data.get('acc', 0.0)
                        span._.detected_name = ent_data.get('detected_name')
                        span._.pretty_name = ent_data.get('pretty_name')
                        span._.medcat_id = ent_id
                        span._.meta_anns = ent_data.get('meta_anns', {})
                        span._.medcat_confidence = ent_data.get('acc', 0.0)
                        
                        new_spans.append(span)
                        existing_spans.add((start, end))
                
                except Exception as e:
                    logger.warning(f"Error creating span for MedCAT entity {ent_id}: {e}")
            
            # Add new spans to document
            if new_spans:
                all_ents = list(doc.ents) + new_spans
                # Sort by start position and remove duplicates
                unique_ents = {}
                for ent in sorted(all_ents, key=lambda e: (e.start_char, -e.end_char)):
                    key = (ent.start_char, ent.end_char)
                    if key not in unique_ents:
                        unique_ents[key] = ent
                
                doc.ents = tuple(sorted(unique_ents.values(), key=lambda e: e.start_char))
                logger.debug(f"Added {len(new_spans)} MedCAT entities to document")
        
        except Exception as e:
            logger.error(f"Error in MedCAT spaCy component: {e}")
        
        return doc
    
    def _get_entity_label(self, ent_data: Dict[str, Any]) -> str:
        """Determine appropriate spaCy label for MedCAT entity"""
        # Prefer semantic names
        if ent_data.get('snames') and len(ent_data['snames']) > 0:
            return ent_data['snames'][0]
        
        # Fallback to pretty name
        if ent_data.get('pretty_name'):
            return ent_data['pretty_name']
        
        # Fallback to detected name
        if ent_data.get('detected_name'):
            return ent_data['detected_name']
        
        # Default label
        return "MEDICAL_CONCEPT"


# Factory function for spaCy
@Language.factory("medcat")
def create_medcat_component(nlp: Language, name: str, medcat_processor: MedCATProcessor):
    """Factory function for MedCAT spaCy component"""
    return MedCATSpacyComponent(nlp, medcat_processor, name)


# Utility functions
def test_medcat_integration(
    cdb_path: Path,
    vocab_path: Path,
    config_path: Optional[Path] = None
) -> Dict[str, Any]:
    """Test MedCAT integration thoroughly"""
    logger.info("Testing MedCAT integration...")
    
    # Test processor
    processor = get_medcat_processor(cdb_path, vocab_path, config_path)
    
    test_results = {
        "processor_available": processor.is_available(),
        "model_info": processor.get_model_info(),
        "entity_extraction_test": [],
        "spacy_integration_test": None
    }
    
    if not processor.is_available():
        test_results["error"] = "MedCAT processor not available"
        return test_results
    
    # Test entity extraction
    test_texts = [
        "Patient has chest pain and dyspnea",
        "History of diabetes mellitus type 2",
        "Prescribed aspirin 325mg daily",
        "Blood pressure 140/90 mmHg"
    ]
    
    for text in test_texts:
        result = processor.get_entities(text)
        entities = result.get("entities", {})
        
        test_results["entity_extraction_test"].append({
            "text": text,
            "entity_count": len(entities),
            "has_error": "error" in result,
            "sample_entities": list(entities.keys())[:3] if entities else []
        })
    
    # Test spaCy integration
    try:
        import spacy
        nlp = spacy.blank("en")
        nlp.add_pipe("medcat", config={"medcat_processor": processor})
        
        doc = nlp("Patient has chest pain")
        
        test_results["spacy_integration_test"] = {
            "success": True,
            "entity_count": len(doc.ents),
            "medcat_entities_count": len(doc._.medcat_entities) if hasattr(doc._, "medcat_entities") else 0,
            "sample_entities": [{"text": ent.text, "label": ent.label_, "cui": ent._.cui} for ent in doc.ents[:3]]
        }
        
    except Exception as e:
        test_results["spacy_integration_test"] = {
            "success": False,
            "error": str(e)
        }
    
    return test_results