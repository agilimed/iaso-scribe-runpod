# clinicalai_service/nlp_engine/medcat_fixes.py
"""
MedCAT 1.16 Integration Fixes
Addresses the E109 linker initialization error and CUI missing issues
"""

import logging
from typing import Optional, Dict, Any
from pathlib import Path

# MedCAT imports
try:
    from medcat.cat import CAT
    from medcat.cdb import CDB
    from medcat.vocab import Vocab
    from medcat.config import Config as MedCATConfig
    from medcat.linking.context_based_linker import Linker
    MEDCAT_AVAILABLE = True
except ImportError:
    CAT = CDB = Vocab = MedCATConfig = Linker = None
    MEDCAT_AVAILABLE = False

logger = logging.getLogger(__name__)


def create_safe_medcat_config() -> MedCATConfig:
    """Create a safe MedCAT configuration for 1.16"""
    config = MedCATConfig()
    
    # Critical fixes for 1.16
    config.general.spacy_cat_mode = False
    config.general.device = 'cpu'  # Force CPU for stability
    config.general.spell_check = True  # Disable to avoid issues
    
    # Linking configuration - these are the key fixes
    config.linking.train = False  # CRITICAL: Must be False for inference
    config.linking.calculate_dynamic_threshold = False  # Disable dynamic thresholds
    config.linking.always_calculate_similarity = False  # Disable always calc
    config.linking.disambiguate = False  # Disable disambiguation to avoid CUI errors
    config.linking.similarity_threshold = 0.2  # Lower threshold to be more permissive
    config.linking.context_similarity_threshold = 0.2  # Lower context threshold
    
    # NER configuration
    config.ner.min_name_len = 2  # Allow shorter names
    config.ner.upper_case_limit_len = 5
    config.ner.check_upper_case_names = False
    
    # Preprocessing
    config.preprocessing.do_spell_check = False
    config.preprocessing.spell_check_len_limit = 0
    
    logger.info("Created safe MedCAT 1.16 configuration")
    return config


def fix_cdb_cui_confidence(cdb: CDB) -> None:
    """Fix missing CUIs in cui2average_confidence"""
    try:
        if not hasattr(cdb, 'cui2average_confidence'):
            cdb.cui2average_confidence = {}
            logger.info("Initialized empty cui2average_confidence")
        
        # Get all CUIs from the CDB
        all_cuis = set()
        if hasattr(cdb, 'cui2names') and cdb.cui2names:
            all_cuis.update(cdb.cui2names.keys())
        if hasattr(cdb, 'cui2snames') and cdb.cui2snames:
            all_cuis.update(cdb.cui2snames.keys())
        if hasattr(cdb, 'cui2type_ids') and cdb.cui2type_ids:
            all_cuis.update(cdb.cui2type_ids.keys())
        
        # Add missing CUIs with default confidence
        default_confidence = 0.5
        missing_cuis = []
        
        for cui in all_cuis:
            if cui not in cdb.cui2average_confidence:
                cdb.cui2average_confidence[cui] = default_confidence
                missing_cuis.append(cui)
        
        if missing_cuis:
            logger.info(f"Added default confidence for {len(missing_cuis)} missing CUIs")
            # Log a few examples
            for cui in missing_cuis[:5]:
                logger.debug(f"Added default confidence for CUI: {cui}")
        
        logger.info(f"CDB now has confidence scores for {len(cdb.cui2average_confidence)} CUIs")
        
    except Exception as e:
        logger.error(f"Error fixing CDB CUI confidence: {e}")


def create_working_medcat_instance(
    cdb_path: Path, 
    vocab_path: Path, 
    config_path: Optional[Path] = None
) -> Optional[CAT]:
    """Create a working MedCAT instance with all 1.16 fixes applied"""
    
    if not MEDCAT_AVAILABLE:
        logger.error("MedCAT not available")
        return None
    
    try:
        logger.info("Loading MedCAT components with 1.16 fixes...")
        
        # Load CDB and Vocab
        logger.info(f"Loading CDB from: {cdb_path}")
        cdb = CDB.load(str(cdb_path))
        logger.info(f"CDB loaded with {len(cdb.cui2names if hasattr(cdb, 'cui2names') else {})} concepts")
        
        logger.info(f"Loading Vocab from: {vocab_path}")
        vocab = Vocab.load(str(vocab_path))
        logger.info(f"Vocab loaded")
        
        # Fix CDB confidence issues
        fix_cdb_cui_confidence(cdb)
        
        # Create safe config
        config = create_safe_medcat_config()
        
        # Load custom config if available
        if config_path and config_path.exists():
            try:
                custom_config = MedCATConfig.load(str(config_path))
                # Only copy safe settings from custom config
                config.ner.min_name_len = custom_config.ner.get('min_name_len', 2)
                config.ner.upper_case_limit_len = custom_config.ner.get('upper_case_limit_len', 5)
                config.linking.similarity_threshold = max(0.1, custom_config.linking.get('similarity_threshold', 0.1))
                logger.info(f"Loaded safe settings from custom config: {config_path}")
            except Exception as e:
                logger.warning(f"Could not load custom config, using safe defaults: {e}")
        
        # Method 1: Try creating CAT with minimal linking
        logger.info("Method 1: Creating CAT with safe config...")
        try:
            cat = CAT(cdb=cdb, vocab=vocab, config=config)
            
            # Test with simple text first
            simple_test = "test"
            result = cat.get_entities(simple_test)
            logger.info("Method 1: Simple test successful")
            
            # Test with slightly more complex text
            complex_test = "patient"
            result = cat.get_entities(complex_test)
            logger.info("Method 1: Complex test successful")
            
            return cat
            
        except Exception as e1:
            logger.warning(f"Method 1 failed: {e1}")
        
        # Method 2: Create CAT with completely disabled linking
        logger.info("Method 2: Creating CAT with disabled linking...")
        try:
            # Even more restrictive config
            safe_config = MedCATConfig()
            safe_config.general.spacy_cat_mode = False
            safe_config.general.device = 'cpu'
            safe_config.linking.train = False
            safe_config.linking.calculate_dynamic_threshold = False
            safe_config.linking.always_calculate_similarity = False
            safe_config.linking.disambiguate = False
            safe_config.linking.similarity_threshold = 0.0  # Effectively disable
            safe_config.ner.min_name_len = 1
            
            cat = CAT(cdb=cdb, vocab=vocab, config=safe_config)
            
            # Minimal test
            result = cat.get_entities("test")
            logger.info("Method 2: Test successful")
            
            return cat
            
        except Exception as e2:
            logger.warning(f"Method 2 failed: {e2}")
        
        # Method 3: Manual pipeline creation
        logger.info("Method 3: Manual pipeline creation...")
        try:
            import spacy
            from spacy import Language
            
            # Create minimal spacy pipeline
            nlp = spacy.blank("en")
            
            # Add only essential components
            nlp.add_pipe("sentencizer")
            
            # Create a minimal CAT-like processor
            class MinimalMedCAT:
                def __init__(self, cdb, vocab):
                    self.cdb = cdb
                    self.vocab = vocab
                    self.nlp = nlp
                
                def get_entities(self, text: str) -> Dict[str, Any]:
                    """Minimal entity extraction without linking"""
                    # Very basic entity detection
                    doc = self.nlp(text)
                    entities = {}
                    
                    # Simple name matching from CDB
                    if hasattr(self.cdb, 'name2cuis') and self.cdb.name2cuis:
                        for i, token in enumerate(doc):
                            token_text = token.text.lower()
                            if token_text in self.cdb.name2cuis:
                                cuis = self.cdb.name2cuis[token_text]
                                if cuis:
                                    cui = list(cuis)[0]  # Take first CUI
                                    entity_id = f"ent_{i}"
                                    entities[entity_id] = {
                                        'cui': cui,
                                        'source_value': token.text,
                                        'detected_name': token.text,
                                        'pretty_name': token.text,
                                        'acc': 0.8,
                                        'start': token.idx,
                                        'end': token.idx + len(token.text),
                                        'snames': [],
                                        'type_ids': self.cdb.cui2type_ids.get(cui, []) if hasattr(self.cdb, 'cui2type_ids') else []
                                    }
                    
                    return {'entities': entities}
                
                def __call__(self, text: str):
                    """For compatibility"""
                    return self.nlp(text)
            
            minimal_cat = MinimalMedCAT(cdb, vocab)
            result = minimal_cat.get_entities("patient has chest pain")
            logger.info(f"Method 3: Minimal CAT successful - found {len(result['entities'])} entities")
            
            return minimal_cat
            
        except Exception as e3:
            logger.error(f"Method 3 failed: {e3}")
        
        logger.error("All MedCAT initialization methods failed")
        return None
        
    except Exception as e:
        logger.error(f"Critical error creating MedCAT instance: {e}", exc_info=True)
        return None


def test_medcat_instance(cat: Any, test_texts: list = None) -> Dict[str, Any]:
    """Test a MedCAT instance with various texts"""
    if test_texts is None:
        test_texts = [
            "patient",
            "chest pain",
            "diabetes",
            "patient has chest pain",
            "diabetes mellitus type 2",
            "levothyroxine"
        ]
    
    results = {
        'successful_tests': 0,
        'failed_tests': 0,
        'total_entities': 0,
        'test_results': []
    }
    
    for text in test_texts:
        try:
            result = cat.get_entities(text)
            entities = result.get('entities', {}) if isinstance(result, dict) else {}
            entity_count = len(entities)
            
            results['successful_tests'] += 1
            results['total_entities'] += entity_count
            results['test_results'].append({
                'text': text,
                'success': True,
                'entity_count': entity_count,
                'sample_entities': list(entities.keys())[:3]
            })
            
            logger.info(f"✅ '{text}' -> {entity_count} entities")
            
        except Exception as e:
            results['failed_tests'] += 1
            results['test_results'].append({
                'text': text,
                'success': False,
                'error': str(e)
            })
            
            logger.error(f"❌ '{text}' -> Error: {e}")
    
    success_rate = results['successful_tests'] / len(test_texts) * 100
    logger.info(f"MedCAT Test Results: {success_rate:.1f}% success rate, {results['total_entities']} total entities")
    
    return results


def get_medcat_info(cat: Any) -> Dict[str, Any]:
    """Get information about a MedCAT instance"""
    info = {
        'type': str(type(cat)),
        'has_cdb': hasattr(cat, 'cdb'),
        'has_vocab': hasattr(cat, 'vocab'),
        'has_config': hasattr(cat, 'config'),
        'is_minimal': 'MinimalMedCAT' in str(type(cat))
    }
    
    if hasattr(cat, 'cdb') and cat.cdb:
        cdb = cat.cdb
        info['cdb_info'] = {
            'cui_count': len(cdb.cui2names) if hasattr(cdb, 'cui2names') and cdb.cui2names else 0,
            'name_count': len(cdb.name2cuis) if hasattr(cdb, 'name2cuis') and cdb.name2cuis else 0,
            'has_confidence': hasattr(cdb, 'cui2average_confidence') and bool(cdb.cui2average_confidence)
        }
    
    if hasattr(cat, 'config') and cat.config:
        config = cat.config
        info['config_info'] = {
            'train_mode': config.linking.get('train', 'unknown'),
            'disambiguate': config.linking.get('disambiguate', 'unknown'),
            'similarity_threshold': config.linking.get('similarity_threshold', 'unknown')
        }
    
    return info


# Utility function for easy integration
def load_medcat_with_fixes(model_dir: Path) -> Optional[Any]:
    """Main function to load MedCAT with all fixes applied"""
    cdb_path = model_dir / "cdb.dat"
    vocab_path = model_dir / "vocab.dat"
    config_path = model_dir / "config.json"
    
    if not cdb_path.exists():
        logger.error(f"CDB not found: {cdb_path}")
        return None
    
    if not vocab_path.exists():
        logger.error(f"Vocab not found: {vocab_path}")
        return None
    
    logger.info(f"Loading MedCAT from: {model_dir}")
    cat = create_working_medcat_instance(cdb_path, vocab_path, config_path)
    
    if cat:
        logger.info("Testing MedCAT instance...")
        test_results = test_medcat_instance(cat)
        info = get_medcat_info(cat)
        
        logger.info("MedCAT Information:")
        logger.info(f"  Type: {info['type']}")
        logger.info(f"  CDB Concepts: {info.get('cdb_info', {}).get('cui_count', 'unknown')}")
        logger.info(f"  Success Rate: {test_results['successful_tests']}/{len(test_results['test_results'])}")
        
        return cat
    
    return None