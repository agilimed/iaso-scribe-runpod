# clinicalai_service/nlp_engine/clinical_bert.py
"""
Dynamic ClinicalBERT Integration Module
Supports multiple models and per-request model switching
Fixed serialization issues
"""

import logging
import numpy as np
import torch
from typing import Dict, List, Any, Optional, Tuple, Union
from pathlib import Path
from enum import Enum
import threading

# Import config from parent package
from .. import config as app_config

# Transformers imports
try:
    from transformers import AutoTokenizer, AutoModel
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    AutoTokenizer = AutoModel = None
    TRANSFORMERS_AVAILABLE = False

# spaCy imports for component
try:
    from spacy.language import Language
    from spacy.tokens import Doc, Span
    SPACY_AVAILABLE = True
except ImportError:
    Language = Doc = Span = None
    SPACY_AVAILABLE = False

logger = logging.getLogger(__name__)

class ClinicalBERTModel(Enum):
    """Available ClinicalBERT model types"""
    CLINICAL_BERT = "emilyalsentzer/Bio_ClinicalBERT"
    DISCHARGE_SUMMARY_BERT = "emilyalsentzer/Bio_Discharge_Summary_BERT"
    CLINICAL_PUBMED_BERT = "microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract-fulltext"
    CLINICAL_BIOBERT = "dmis-lab/biobert-base-cased-v1.1"
    
    @classmethod
    def from_string(cls, model_name: str) -> 'ClinicalBERTModel':
        """Get enum from string, fallback to default"""
        for model in cls:
            if model.value == model_name:
                return model
        # Return default from config
        return cls.from_string(app_config.CLINICAL_BERT_MODEL_NAME)
    
    @classmethod
    def get_default(cls) -> 'ClinicalBERTModel':
        """Get default model from config"""
        return cls.from_string(app_config.CLINICAL_BERT_MODEL_NAME)


class ModelInstance:
    """Container for a loaded model instance"""
    def __init__(self, model_name: str, model, tokenizer, device):
        self.model_name = model_name
        self.model = model
        self.tokenizer = tokenizer
        self.device = device
        self.load_time = None
    
    def is_valid(self) -> bool:
        """Check if model instance is still valid"""
        return self.model is not None and self.tokenizer is not None


class DynamicClinicalBERT:
    """
    Dynamic ClinicalBERT that can switch models per request
    Maintains a cache of loaded models for performance
    """
    
    def __init__(
        self,
        max_cached_models: int = 3,
        max_length: Optional[int] = None,
        batch_size: Optional[int] = None,
        force_cpu: Optional[bool] = None,
        cache_dir: Optional[str] = None,
        chunk_overlap: Optional[int] = None,
        min_chunk_size: Optional[int] = None,
        aggregation_method: Optional[str] = None
    ):
        # Configuration
        self.max_length = max_length or app_config.CLINICAL_BERT_MAX_LENGTH
        self.batch_size = batch_size or app_config.CLINICAL_BERT_BATCH_SIZE
        self.force_cpu = force_cpu if force_cpu is not None else app_config.CLINICAL_BERT_FORCE_CPU
        self.cache_dir = cache_dir
        self.max_cached_models = max_cached_models
        
        # Chunking configuration
        self.chunk_overlap = chunk_overlap or app_config.CLINICAL_BERT_CHUNK_OVERLAP
        self.min_chunk_size = min_chunk_size or app_config.CLINICAL_BERT_MIN_CHUNK_SIZE
        self.aggregation_method = aggregation_method or app_config.CLINICAL_BERT_AGGREGATION_METHOD
        
        # Model cache
        self._model_cache: Dict[str, ModelInstance] = {}
        self._cache_lock = threading.Lock()
        
        # Device setup
        self.device = self._setup_device()
        
        # Load default model if enabled
        if app_config.ENABLE_CLINICAL_BERT:
            self._preload_default_model()
    
    def _setup_device(self) -> torch.device:
        """Setup device (CPU/GPU) based on config"""
        if self.force_cpu or not torch.cuda.is_available():
            device = torch.device("cpu")
            logger.info(f"ClinicalBERT using CPU (force_cpu={self.force_cpu}, cuda_available={torch.cuda.is_available()})")
        else:
            device = torch.device("cuda")
            logger.info("ClinicalBERT using GPU")
        return device
    
    def _preload_default_model(self):
        """Preload the default model from config"""
        try:
            default_model = app_config.CLINICAL_BERT_MODEL_NAME
            logger.info(f"Preloading default ClinicalBERT model: {default_model}")
            self._load_model(default_model)
        except Exception as e:
            logger.warning(f"Failed to preload default model: {e}")
    
    def _load_model(self, model_name: str) -> Optional[ModelInstance]:
        """Load a specific model and add to cache"""
        if not TRANSFORMERS_AVAILABLE:
            logger.error("Transformers library not available")
            return None
        
        # Check if already cached
        with self._cache_lock:
            if model_name in self._model_cache:
                instance = self._model_cache[model_name]
                if instance.is_valid():
                    logger.debug(f"Using cached model: {model_name}")
                    return instance
                else:
                    # Remove invalid instance
                    del self._model_cache[model_name]
        
        try:
            logger.info(f"Loading ClinicalBERT model: {model_name}")
            
            # Load tokenizer and model
            tokenizer = AutoTokenizer.from_pretrained(model_name, cache_dir=self.cache_dir)
            model = AutoModel.from_pretrained(model_name, cache_dir=self.cache_dir)
            
            # Move to device and set eval mode
            model.to(self.device)
            model.eval()
            
            # Create model instance
            instance = ModelInstance(model_name, model, tokenizer, self.device)
            
            # Add to cache with LRU eviction
            with self._cache_lock:
                self._add_to_cache(model_name, instance)
            
            logger.info(f"Successfully loaded model: {model_name}")
            return instance
            
        except Exception as e:
            logger.error(f"Failed to load model {model_name}: {e}")
            return None
    
    def _add_to_cache(self, model_name: str, instance: ModelInstance):
        """Add model to cache with LRU eviction"""
        # Remove oldest models if cache is full
        while len(self._model_cache) >= self.max_cached_models:
            # Remove the first item (oldest)
            oldest_key = next(iter(self._model_cache))
            old_instance = self._model_cache.pop(oldest_key)
            logger.info(f"Evicted model from cache: {oldest_key}")
            
            # Clean up GPU memory if possible
            if hasattr(old_instance.model, 'cpu'):
                old_instance.model.cpu()
            del old_instance
        
        self._model_cache[model_name] = instance
        logger.debug(f"Added model to cache: {model_name} (cache size: {len(self._model_cache)})")
    
    def get_model_instance(self, model_name: Optional[str] = None) -> Optional[ModelInstance]:
        """Get model instance, loading if necessary"""
        if not app_config.ENABLE_CLINICAL_BERT:
            return None
        
        # Use default if not specified
        if not model_name:
            model_name = app_config.CLINICAL_BERT_MODEL_NAME
        
        # Handle enum
        if isinstance(model_name, ClinicalBERTModel):
            model_name = model_name.value
        
        return self._load_model(model_name)
    
    def get_embeddings(self, text: str, model_name: Optional[str] = None) -> Optional[np.ndarray]:
        """
        Get ClinicalBERT embeddings for text with automatic chunking for long texts
        
        Args:
            text: Input text
            model_name: Optional specific model to use
            
        Returns:
            numpy array of embeddings or None if failed
        """
        instance = self.get_model_instance(model_name)
        if not instance:
            return None
        
        try:
            # Check if text needs chunking
            tokens = instance.tokenizer.tokenize(text)
            logger.debug(f"Text tokenized to {len(tokens)} tokens (max_length: {self.max_length})")
            
            if len(tokens) <= (self.max_length - 2) * 2:
                # Text is short enough, process normally
                logger.debug(f"Text is short enough ({len(tokens)} <= {self.max_length - 2}), processing normally")
                return self._get_single_embedding(text, instance)
            else:
                # Text is too long, use chunking strategy
                logger.info(f"Text too long ({len(tokens)} tokens > {self.max_length - 2}), using chunking strategy")
                return self._get_chunked_embeddings(text, instance)
                
        except Exception as e:
            logger.error(f"Error getting embeddings with model {instance.model_name}: {e}")
            return None
    
   
    def _get_single_embedding_emergency_fallback(self, text: str, instance: ModelInstance, recursion_depth: int) -> Optional[np.ndarray]:
        """Emergency fallback with very conservative token limits"""
        try:
            # Use very conservative limits
            emergency_max_length = min(384, self.max_length)
            
            logger.warning(f"Emergency fallback: using max_length={emergency_max_length}")
            
            # Tokenize and truncate aggressively
            tokens = instance.tokenizer.tokenize(text)
            if len(tokens) > emergency_max_length - 2:
                tokens = tokens[:emergency_max_length - 2]
                text = instance.tokenizer.convert_tokens_to_string(tokens)
            
            # Tokenize with emergency settings
            inputs = instance.tokenizer(
                text,
                return_tensors="pt",
                max_length=emergency_max_length,
                truncation=True,
                padding=True,
                add_special_tokens=True
            )
            
            # Final safety check
            if inputs['input_ids'].shape[1] > emergency_max_length:
                for key in inputs:
                    if len(inputs[key].shape) > 1:
                        inputs[key] = inputs[key][:, :emergency_max_length]
            
            logger.debug(f"Emergency fallback tensor shape: {inputs['input_ids'].shape}")
            
            # Move to device and get embeddings
            inputs = {k: v.to(instance.device) for k, v in inputs.items()}
            
            with torch.no_grad():
                outputs = instance.model(**inputs)
                if hasattr(outputs, 'pooler_output') and outputs.pooler_output is not None:
                    embeddings = outputs.pooler_output.cpu().numpy()
                else:
                    embeddings = outputs.last_hidden_state[:, 0, :].cpu().numpy()
                
                logger.info(f"Emergency fallback successful: {embeddings.shape}")
                return embeddings[0]
                
        except Exception as e:
            logger.error(f"Emergency fallback also failed: {e}")
            return None
        
    def _get_single_embedding(self, text: str, instance: ModelInstance, recursion_depth: int = 0) -> Optional[np.ndarray]:
        """Get embedding for a single text that fits within token limits"""
        try:
            # FIXED: Use model-specific max length, not config max length
            model_max_length = getattr(instance.tokenizer, 'model_max_length', 512)
            if model_max_length > 10000:  # Some tokenizers return very large defaults
                model_max_length = 512  # Safe default for BERT models
            
            logger.debug(f"Model max length: {model_max_length}, config max length: {self.max_length}")
            
            # Use the smaller of the two to be safe
            effective_max_length = min(model_max_length, self.max_length)
            
            logger.debug(f"Using effective max length: {effective_max_length}")
            
            # First, check if we need to truncate
            preliminary_tokens = instance.tokenizer.tokenize(text)
            if len(preliminary_tokens) > effective_max_length - 2:  # Account for [CLS] and [SEP]
                logger.debug(f"Text too long ({len(preliminary_tokens)} tokens), truncating to {effective_max_length - 2}")
                # Truncate at token level for better control
                truncated_tokens = preliminary_tokens[:effective_max_length - 2]
                text = instance.tokenizer.convert_tokens_to_string(truncated_tokens)
                logger.debug(f"Truncated text length: {len(text)} characters")
            
            # Now tokenize with strict limits
            inputs = instance.tokenizer(
                text,
                return_tensors="pt",
                max_length=effective_max_length,
                truncation=True,
                padding=True,
                add_special_tokens=True
            )
            
            # CRITICAL: Double-check tensor size before sending to model
            actual_length = inputs['input_ids'].shape[1]
            if actual_length > effective_max_length:
                logger.error(f"CRITICAL: Tensor still too long ({actual_length} > {effective_max_length})")
                # Force truncation
                for key in inputs:
                    if len(inputs[key].shape) > 1 and inputs[key].shape[1] > effective_max_length:
                        inputs[key] = inputs[key][:, :effective_max_length]
                        logger.debug(f"Force-truncated {key} to {effective_max_length}")
            
            logger.debug(f"Final tensor shape: {inputs['input_ids'].shape}")
            
            # Move to device
            inputs = {k: v.to(instance.device) for k, v in inputs.items()}
            
            # Get embeddings with error handling
            with torch.no_grad():
                try:
                    outputs = instance.model(**inputs)
                    if hasattr(outputs, 'pooler_output') and outputs.pooler_output is not None:
                        embeddings = outputs.pooler_output.cpu().numpy()
                    elif hasattr(outputs, 'last_hidden_state'):
                        # Fallback: use [CLS] token from last hidden state
                        embeddings = outputs.last_hidden_state[:, 0, :].cpu().numpy()
                    else:
                        logger.error("Model output doesn't have expected pooler_output or last_hidden_state")
                        return None
                    
                    logger.debug(f"Generated embeddings shape: {embeddings.shape}")
                    return embeddings[0]  # Return first (and only) embedding
                    
                except RuntimeError as e:
                    if "size mismatch" in str(e) or "size of tensor" in str(e):
                        logger.error(f"Tensor size mismatch error: {e}")
                        logger.error(f"Input tensor shape: {inputs['input_ids'].shape}")
                        logger.error(f"Expected max length: {effective_max_length}")
                        
                        # Emergency fallback: try with even smaller length
                        if recursion_depth < 2:
                            logger.warning("Attempting emergency fallback with smaller length")
                            return self._get_single_embedding_emergency_fallback(text, instance, recursion_depth + 1)
                        else:
                            logger.error("Emergency fallback also failed")
                            return None
                    else:
                        raise e
            
        except Exception as e:
            logger.error(f"Error getting single embedding: {e}")
            if recursion_depth < 2:
                logger.warning("Attempting emergency fallback due to error")
                return self._get_single_embedding_emergency_fallback(text, instance, recursion_depth + 1)
            return None
    
    def _get_chunked_embeddings(self, text: str, instance: ModelInstance, recursion_depth: int = 0) -> Optional[np.ndarray]:
        """
        Get embeddings for long text using chunking strategy
        Supports multiple aggregation methods
        """
        try:
            # Chunk the text
            chunks = self.chunk_text(text, instance.tokenizer, self.max_length)
            
            if not chunks:
                logger.warning("No chunks created, returning None")
                return None
            
            logger.info(f"Processing {len(chunks)} chunks (recursion_depth: {recursion_depth})")
            
            chunk_embeddings = []
            chunk_weights = []
            
            for i, chunk in enumerate(chunks):
                # Debug: check chunk token count before processing
                chunk_tokens = instance.tokenizer.tokenize(chunk)
                logger.debug(f"Processing chunk {i+1}/{len(chunks)}: {len(chunk_tokens)} tokens, {len(chunk)} chars")
                
                chunk_emb = self._get_single_embedding(chunk, instance, recursion_depth)
                if chunk_emb is not None:
                    chunk_embeddings.append(chunk_emb)
                    # Weight by chunk length (longer chunks get more weight)
                    weight = len(chunk.split())
                    chunk_weights.append(weight)
                    logger.debug(f"Chunk {i+1}/{len(chunks)} processed successfully: weight={weight}")
                else:
                    logger.warning(f"Failed to get embedding for chunk {i+1}")
            
            if not chunk_embeddings:
                logger.error("No valid chunk embeddings obtained")
                return None
            
            # Convert to numpy arrays
            chunk_embeddings = np.array(chunk_embeddings)
            chunk_weights = np.array(chunk_weights)
            
            # Apply aggregation method
            if self.aggregation_method == "weighted_average":
                # Normalize weights
                chunk_weights = chunk_weights / np.sum(chunk_weights)
                aggregated_embedding = np.average(chunk_embeddings, axis=0, weights=chunk_weights)
                logger.info(f"Aggregated {len(chunk_embeddings)} chunks using weighted average")
                
            elif self.aggregation_method == "simple_average":
                aggregated_embedding = np.mean(chunk_embeddings, axis=0)
                logger.info(f"Aggregated {len(chunk_embeddings)} chunks using simple average")
                
            elif self.aggregation_method == "max_pooling":
                aggregated_embedding = np.max(chunk_embeddings, axis=0)
                logger.info(f"Aggregated {len(chunk_embeddings)} chunks using max pooling")
                
            else:
                logger.warning(f"Unknown aggregation method '{self.aggregation_method}', using weighted average")
                chunk_weights = chunk_weights / np.sum(chunk_weights)
                aggregated_embedding = np.average(chunk_embeddings, axis=0, weights=chunk_weights)
            
            return aggregated_embedding
            
        except Exception as e:
            logger.error(f"Error getting chunked embeddings: {e}")
            return None
    
    def get_similarity(self, text1: str, text2: str, model_name: Optional[str] = None) -> float:
        """Calculate cosine similarity between two texts"""
        emb1 = self.get_embeddings(text1, model_name)
        emb2 = self.get_embeddings(text2, model_name)
        
        if emb1 is None or emb2 is None:
            return 0.0
        
        try:
            similarity = np.dot(emb1, emb2) / (np.linalg.norm(emb1) * np.linalg.norm(emb2))
            return float(similarity)
        except Exception as e:
            logger.error(f"Error calculating similarity: {e}")
            return 0.0
    
    async def get_embeddings_async(self, text: str, model_name: Optional[str] = None) -> Optional[np.ndarray]:
        """Async wrapper for get_embeddings to prevent blocking"""
        import asyncio
        loop = asyncio.get_event_loop()
        # Use a dedicated thread pool for ClinicalBERT operations
        return await loop.run_in_executor(None, self._get_embeddings_sync, text, model_name)

    def _get_embeddings_sync(self, text: str, model_name: Optional[str] = None) -> Optional[np.ndarray]:
        """Thread-safe synchronous wrapper"""
        return self.get_embeddings(text, model_name)

    async def get_similarity_async(self, text1: str, text2: str, model_name: Optional[str] = None) -> float:
        """Async wrapper for get_similarity"""
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._get_similarity_sync, text1, text2, model_name)

    def _get_similarity_sync(self, text1: str, text2: str, model_name: Optional[str] = None) -> float:
        """Thread-safe synchronous wrapper"""
        return self.get_similarity(text1, text2, model_name)
    
    def analyze_text(self, text: str, model_name: Optional[str] = None) -> Dict[str, Any]:
        """Comprehensive analysis of clinical text with chunking support"""
        embeddings = self.get_embeddings(text, model_name)
        
        if embeddings is None:
            return {"error": "Could not generate embeddings"}
        
        try:
            # Check if text was chunked
            instance = self.get_model_instance(model_name)
            if instance:
                tokens = instance.tokenizer.tokenize(text)
                was_chunked = len(tokens) > self.max_length - 2
            else:
                was_chunked = False
            
            analysis = {
                "model_used": model_name or app_config.CLINICAL_BERT_MODEL_NAME,
                "text_length": len(text),
                "text_tokens": len(tokens) if instance else "unknown",
                "was_chunked": was_chunked,
                "embedding_shape": list(embeddings.shape),  # Convert to list for JSON serialization
                "embedding_magnitude": float(np.linalg.norm(embeddings)),
                "clinical_complexity": float(np.std(embeddings)),
                "dominant_features": embeddings.argsort()[-5:][::-1].tolist(),
                "embedding_stats": {
                    "mean": float(np.mean(embeddings)),
                    "std": float(np.std(embeddings)),
                    "min": float(np.min(embeddings)),
                    "max": float(np.max(embeddings)),
                    "median": float(np.median(embeddings))
                },
                "clinical_confidence": min(1.0, float(np.linalg.norm(embeddings)) / 100.0)
            }
            
            # Add chunking-specific information if text was chunked
            if was_chunked and instance:
                chunks = self.chunk_text(text, instance.tokenizer, self.max_length)
                analysis["chunking_info"] = {
                    "total_chunks": len(chunks),
                    "chunk_sizes": [len(chunk) for chunk in chunks],
                    "avg_chunk_size": sum(len(chunk) for chunk in chunks) / len(chunks) if chunks else 0
                }
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing text: {e}")
            return {"error": str(e)}
    
    def batch_embeddings(self, texts: List[str], model_name: Optional[str] = None) -> List[Optional[np.ndarray]]:
        """Get embeddings for multiple texts efficiently with chunking support"""
        instance = self.get_model_instance(model_name)
        if not instance:
            return [None] * len(texts)
        
        results = []
        
        try:
            for text in texts:
                # Use the main get_embeddings method which handles chunking automatically
                embedding = self.get_embeddings(text, model_name)
                results.append(embedding)
            
            logger.info(f"Processed batch of {len(texts)} texts with chunking support")
            return results
            
        except Exception as e:
            logger.error(f"Error in batch embeddings: {e}")
            return [None] * len(texts)
    
    def compare_models(self, text: str, models: List[str]) -> Dict[str, Any]:
        """Compare how different models represent the same text"""
        results = {
            "text": text,
            "models_compared": [],
            "embeddings_comparison": {},
            "similarity_matrix": {},
            "analysis_comparison": {}
        }
        
        embeddings = {}
        
        # Get embeddings from each model
        for model_name in models:
            try:
                emb = self.get_embeddings(text, model_name)
                analysis = self.analyze_text(text, model_name)
                
                if emb is not None:
                    embeddings[model_name] = emb
                    results["models_compared"].append(model_name)
                    results["embeddings_comparison"][model_name] = {
                        "magnitude": float(np.linalg.norm(emb)),
                        "shape": list(emb.shape)  # Convert to list for JSON serialization
                    }
                    results["analysis_comparison"][model_name] = analysis
                    
            except Exception as e:
                logger.error(f"Error comparing model {model_name}: {e}")
        
        # Calculate similarity matrix between models
        model_names = list(embeddings.keys())
        if len(model_names) > 1:
            similarity_matrix = {}
            for i, model1 in enumerate(model_names):
                for j, model2 in enumerate(model_names):
                    if i != j:
                        sim = np.dot(embeddings[model1], embeddings[model2]) / (
                            np.linalg.norm(embeddings[model1]) * 
                            np.linalg.norm(embeddings[model2])
                        )
                        similarity_matrix[f"{model1}_vs_{model2}"] = float(sim)
            
            results["similarity_matrix"] = similarity_matrix
        
        return results
    
    def get_cache_info(self) -> Dict[str, Any]:
        """Get information about the model cache"""
        with self._cache_lock:
            return {
                "cached_models": list(self._model_cache.keys()),
                "cache_size": len(self._model_cache),
                "max_cache_size": self.max_cached_models,
                "cache_utilization": f"{len(self._model_cache)}/{self.max_cached_models}"
            }
    
    def clear_cache(self, model_name: Optional[str] = None):
        """Clear model cache"""
        with self._cache_lock:
            if model_name:
                if model_name in self._model_cache:
                    instance = self._model_cache.pop(model_name)
                    if hasattr(instance.model, 'cpu'):
                        instance.model.cpu()
                    del instance
                    logger.info(f"Cleared model from cache: {model_name}")
            else:
                for instance in self._model_cache.values():
                    if hasattr(instance.model, 'cpu'):
                        instance.model.cpu()
                self._model_cache.clear()
                logger.info("Cleared all models from cache")
    
    def is_available(self) -> bool:
        """Check if ClinicalBERT is available"""
        return (
            app_config.ENABLE_CLINICAL_BERT and 
            TRANSFORMERS_AVAILABLE
        )
    
    def get_model_info(self, model_name: Optional[str] = None) -> Dict[str, Any]:
        """Get information about a specific model or the system"""
        info = {
            "enabled_in_config": app_config.ENABLE_CLINICAL_BERT,
            "transformers_available": TRANSFORMERS_AVAILABLE,
            "device": str(self.device),  # Convert to string for JSON serialization
            "max_length": self.max_length,
            "batch_size": self.batch_size,
            "force_cpu": self.force_cpu,
            "default_model": app_config.CLINICAL_BERT_MODEL_NAME,
            "available_models": [model.value for model in ClinicalBERTModel],
            "cache_info": self.get_cache_info(),
            "chunking_config": {
                "chunk_overlap": self.chunk_overlap,
                "min_chunk_size": self.min_chunk_size,
                "aggregation_method": self.aggregation_method,
                "max_tokens_per_chunk": self.max_length - 2  # Account for special tokens
            }
        }
        
        # Get specific model info if requested
        if model_name:
            instance = self.get_model_instance(model_name)
            if instance:
                info["specific_model"] = {
                    "model_name": instance.model_name,
                    "model_type": type(instance.model).__name__,
                    "tokenizer_type": type(instance.tokenizer).__name__,
                    "vocab_size": len(instance.tokenizer),
                    "embedding_dim": instance.model.config.hidden_size if hasattr(instance.model, 'config') else None,
                    "is_cached": True
                }
        
        return info

    def chunk_text(self, text: str, tokenizer, max_length: int = None, overlap: int = None) -> List[str]:
        """
        FIXED: Chunk text with model-aware token limits
        """
        # Get model-specific max length
        model_max_length = getattr(tokenizer, 'model_max_length', 512)
        if model_max_length > 10000:
            model_max_length = 512
        
        # Use provided max_length or fall back to safe model limit
        if max_length is None:
            max_length = min(model_max_length, self.max_length, 512)  # Triple safety check
        else:
            max_length = min(max_length, model_max_length, 768)  # Ensure we don't exceed model limits
        
        # Use configured overlap or default
        overlap = overlap or self.chunk_overlap
        
        logger.info(f"Chunking with max_length={max_length}, overlap={overlap}")
        
        try:
            # Tokenize the full text
            tokens = tokenizer.tokenize(text)
            
            # If text is short enough, return as single chunk
            if len(tokens) <= max_length - 2 or len(text) < 1500:  # Skip chunking for shorter texts
                return [text]
            
            logger.info(f"Text has {len(tokens)} tokens, chunking into segments of {max_length - 2} tokens with {overlap} token overlap")
            
            chunks = []
            chunk_size = max_length - 2  # Reserve space for special tokens
            
            for i in range(0, len(tokens), chunk_size - overlap):
                # Get chunk tokens
                chunk_tokens = tokens[i:i + chunk_size]
                
                # Skip chunks that are too small (unless it's the last chunk)
                if len(chunk_tokens) < self.min_chunk_size and i + chunk_size < len(tokens):
                    continue
                
                # Convert back to text
                chunk_text = tokenizer.convert_tokens_to_string(chunk_tokens)
                chunk_text = chunk_text.strip()
                
                if chunk_text:  # Only add non-empty chunks
                    # Validate that the chunk is actually within token limits
                    validation_tokens = tokenizer.tokenize(chunk_text)
                    if len(validation_tokens) > chunk_size:
                        logger.warning(f"Chunk validation failed: {len(validation_tokens)} tokens > {chunk_size}, truncating")
                        # Truncate the chunk to fit
                        truncated_tokens = validation_tokens[:chunk_size]
                        chunk_text = tokenizer.convert_tokens_to_string(truncated_tokens).strip()
                    
                    chunks.append(chunk_text)
                
                # Break if we've covered all tokens
                if i + chunk_size >= len(tokens):
                    break
            
            logger.info(f"Created {len(chunks)} chunks from {len(tokens)} tokens")
            return chunks
            
        except Exception as e:
            logger.error(f"Error chunking text: {e}")
            # Fallback: simple sentence-based chunking with character limits
            return self._fallback_sentence_chunking(text, max_chars=1000)  # Very conservative
    
    def _fallback_sentence_chunking(self, text: str, max_chars: int = 2000) -> List[str]:
        """
        Fallback chunking strategy using sentence boundaries
        """
        try:
            import re
            
            # Split by sentences (simple approach)
            sentences = re.split(r'[.!?]+', text)
            
            chunks = []
            current_chunk = ""
            
            for sentence in sentences:
                sentence = sentence.strip()
                if not sentence:
                    continue
                
                # If adding this sentence would exceed limit, start new chunk
                if len(current_chunk) + len(sentence) > max_chars and current_chunk:
                    chunks.append(current_chunk.strip())
                    current_chunk = sentence
                else:
                    current_chunk += (" " + sentence if current_chunk else sentence)
            
            # Add final chunk
            if current_chunk.strip():
                chunks.append(current_chunk.strip())
            
            logger.info(f"Fallback chunking created {len(chunks)} chunks")
            return chunks if chunks else [text]  # Return original if chunking fails
            
        except Exception as e:
            logger.error(f"Fallback chunking failed: {e}")
            return [text]  # Return original text as last resort


# Global instance
_dynamic_clinical_bert: Optional[DynamicClinicalBERT] = None

def get_dynamic_clinical_bert() -> DynamicClinicalBERT:
    """Get or create the global dynamic ClinicalBERT instance"""
    global _dynamic_clinical_bert
    
    if _dynamic_clinical_bert is None:
        _dynamic_clinical_bert = DynamicClinicalBERT()
    
    return _dynamic_clinical_bert

# Backward compatibility functions
def get_clinical_bert() -> DynamicClinicalBERT:
    """Backward compatibility - returns dynamic instance"""
    return get_dynamic_clinical_bert()

def get_embeddings(text: str, model_name: Optional[str] = None) -> Optional[np.ndarray]:
    """Convenience function for getting embeddings"""
    return get_dynamic_clinical_bert().get_embeddings(text, model_name)

# spaCy integration
class DynamicClinicalBERTSpacyComponent:
    """Enhanced spaCy component with dynamic model support"""
    
    def __init__(self, nlp: Language, name: str = "clinical_bert"):
        self.name = name
        self.clinical_bert = get_dynamic_clinical_bert()
        self._ensure_extensions()
    
    def _ensure_extensions(self):
        """Ensure spaCy extensions are available"""
        extensions = [
            ("clinical_embeddings", None),
            ("clinical_similarity", None),
            ("clinical_confidence", None),
            ("enhanced_by_bert", False),
            ("clinical_analysis", None),
            ("bert_model_used", None)
        ]
        
        for ext_name, default_val in extensions:
            if not Span.has_extension(ext_name):
                Span.set_extension(ext_name, default=default_val)
            if not Doc.has_extension(ext_name):
                Doc.set_extension(ext_name, default=default_val)
    
    def __call__(self, doc: Doc, model_name: Optional[str] = None) -> Doc:
        """Process document with ClinicalBERT - now with per-request control"""
        
        # NEW: Check thread-local ClinicalBERT control first
        try:
            from ..processor import get_clinical_bert_enabled
            if not get_clinical_bert_enabled():
                logger.debug(f"🚫 ClinicalBERT disabled via thread-local control")
                return doc
        except ImportError:
            pass  # Fallback to doc extensions if import fails
        
        # NEW: Check if ClinicalBERT is disabled for this request
        if hasattr(doc._, 'disable_clinical_bert') and doc._.disable_clinical_bert:
            logger.debug(f"🚫 ClinicalBERT disabled for this request")
            return doc
            
        if hasattr(doc._, 'request_clinical_bert_enabled') and not doc._.request_clinical_bert_enabled:
            logger.debug(f"🚫 ClinicalBERT disabled via request parameter")  
            return doc
        
        logger.debug(f"🤖 ClinicalBERT processing enabled")
        
        # Continue with existing ClinicalBERT logic...
        if not self.clinical_bert.is_available():
            logger.warning("ClinicalBERT not available, skipping enhancement")
            return doc
        
        # Allow model selection via doc metadata
        if hasattr(doc._, 'clinical_bert_model'):
            model_name = doc._.clinical_bert_model
        
        try:
            # Get document embeddings and analysis
            doc_embeddings = self.clinical_bert.get_embeddings(doc.text, model_name)
            doc_analysis = self.clinical_bert.analyze_text(doc.text, model_name)
            
            if doc_embeddings is not None:
                doc._.clinical_embeddings = doc_embeddings
                doc._.clinical_analysis = doc_analysis
                doc._.enhanced_by_bert = True
                doc._.clinical_confidence = doc_analysis.get("clinical_confidence", 0.0)
                doc._.bert_model_used = model_name or app_config.CLINICAL_BERT_MODEL_NAME
            
            # Enhance entities
            enhanced_count = 0
            for ent in doc.ents:
                ent_embeddings = self.clinical_bert.get_embeddings(ent.text, model_name)
                if ent_embeddings is not None:
                    ent._.clinical_embeddings = ent_embeddings
                    ent._.enhanced_by_bert = True
                    ent._.bert_model_used = model_name or app_config.CLINICAL_BERT_MODEL_NAME
                    
                    # Calculate similarity with document
                    if doc_embeddings is not None:
                        similarity = self.clinical_bert.get_similarity(ent.text, doc.text, model_name)
                        ent._.clinical_similarity = similarity
                    
                    # Entity-specific analysis
                    ent_analysis = self.clinical_bert.analyze_text(ent.text, model_name)
                    ent._.clinical_analysis = ent_analysis
                    ent._.clinical_confidence = ent_analysis.get("clinical_confidence", 0.0)
                    
                    enhanced_count += 1
            
            logger.debug(f"ClinicalBERT enhanced {enhanced_count} entities with model: {model_name or 'default'}")
            
        except Exception as e:
            logger.error(f"Error in ClinicalBERT spaCy component: {e}")
        
        return doc


# Register spaCy factory with dynamic support (only if spaCy is available)
if SPACY_AVAILABLE:
    @Language.factory("clinical_bert")
    def create_dynamic_clinical_bert_component(nlp: Language, name: str):
        """Factory function for dynamic spaCy integration"""
        return DynamicClinicalBERTSpacyComponent(nlp, name)
else:
    # Placeholder function if spaCy is not available
    def create_dynamic_clinical_bert_component(nlp, name: str):
        """Placeholder factory function when spaCy is not available"""
        raise ImportError("spaCy is not available for ClinicalBERT integration")