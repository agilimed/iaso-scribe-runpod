# clinicalai_service/nlp_engine/processor.py
"""
Clean NLP Processor
Main orchestrator for clinical NLP pipeline with proper modular architecture
Fixed spaCy factory registration and pipeline building issues
"""

import spacy
from spacy.language import Language
from spacy.tokens import Doc as SpacyDoc, Span as SpacySpan
from pathlib import Path
from typing import List, Dict, Any, Optional as TypingOptional, Tuple, Union
import logging
import re
import itertools
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import time
import asyncio
import json
import threading
# Local imports
from .. import config as app_config
from ..utils import logger
from . import rules

from ..models import NLPEntity, BaseEntity,EnrichedEntity, AuditTrailEntry
# MedSpaCy imports
try:
    import medspacy
    from medspacy.context import ConText
    from medspacy.section_detection import Sectionizer
    MEDSPACY_AVAILABLE = True
    logger.info("✅ MedSpaCy imported successfully")
except ImportError as e:
    logger.error(f"❌ MedSpaCy import failed: {e}")
    medspacy = ConText = Sectionizer = None
    MEDSPACY_AVAILABLE = False



# Global resources
NLP_SPACY: TypingOptional[Language] = None
MEDCAT_PROCESSOR = None
CLINICAL_BERT = None
TUI_NAME_MAP: Dict[str, str] = {}

# Enhanced entity patterns for EntityRuler
ENHANCED_ENTITY_PATTERNS = [
    # Common conditions
    {"label": "CONDITION", "pattern": [{"LOWER": "hypertension"}]},
    {"label": "CONDITION", "pattern": [{"LOWER": "diabetes"}, {"LOWER": {"IN": ["mellitus", "type"]}, "OP": "?"}, {"TEXT": {"REGEX": r"[12]"}, "OP": "?"}]},
    {"label": "CONDITION", "pattern": [{"LOWER": "myocardial"}, {"LOWER": "infarction"}]},
    {"label": "CONDITION", "pattern": [{"LOWER": "copd"}]},
    {"label": "CONDITION", "pattern": [{"LOWER": "pneumonia"}]},
    {"label": "CONDITION", "pattern": [{"LOWER": "stroke"}]},
    
    # Vital signs with values
    {"label": "VITAL_SIGN", "pattern": [{"LOWER": {"IN": ["bp", "blood"]}}, {"LOWER": {"IN": ["pressure", ""]}, "OP": "?"}, {"TEXT": {"REGEX": r"\d+/\d+"}}]},
    {"label": "VITAL_SIGN", "pattern": [{"LOWER": {"IN": ["hr", "heart", "pulse"]}}, {"LOWER": {"IN": ["rate", ""]}, "OP": "?"}, {"IS_DIGIT": True}, {"LOWER": {"IN": ["bpm", ""]}, "OP": "?"}]},
    {"label": "VITAL_SIGN", "pattern": [{"LOWER": {"IN": ["temp", "temperature"]}}, {"TEXT": {"REGEX": r"\d+\.?\d*"}}, {"LOWER": {"IN": ["c", "f", "celsius", "fahrenheit"]}, "OP": "?"}]},
    
    # Common medications
    {"label": "DRUG", "pattern": [{"LOWER": "aspirin"}]},
    {"label": "DRUG", "pattern": [{"LOWER": "metoprolol"}]},
    {"label": "DRUG", "pattern": [{"LOWER": "lisinopril"}]},
    {"label": "DRUG", "pattern": [{"LOWER": "metformin"}]},
    {"label": "DRUG", "pattern": [{"LOWER": "insulin"}]},
    
    # Common procedures
    {"label": "PROCEDURE", "pattern": [{"LOWER": {"IN": ["ecg", "ekg"]}}]},
    {"label": "PROCEDURE", "pattern": [{"LOWER": "chest"}, {"LOWER": {"IN": ["x-ray", "xray"]}}]},
    {"label": "PROCEDURE", "pattern": [{"LOWER": "ct"}, {"LOWER": "scan"}]},
    
    # Lab results
    {"label": "LAB_RESULT", "pattern": [{"LOWER": {"IN": ["hba1c", "a1c"]}}]},
    {"label": "LAB_RESULT", "pattern": [{"LOWER": "glucose"}]},
    {"label": "LAB_RESULT", "pattern": [{"LOWER": "creatinine"}]},
]


def _load_tui_mapping(file_path: Path) -> Dict[str, str]:
    """Load TUI to semantic type name mapping"""
    mapping = {}
    if not file_path.exists():
        logger.warning(f"TUI mapping file not found: {file_path}")
        return mapping
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split('\t')
                if len(parts) == 2:
                    tui, name = parts[0].strip().upper(), parts[1].strip()
                    if tui.startswith("T"):
                        mapping[tui] = name
        logger.info(f"Loaded {len(mapping)} TUI mappings")
    except Exception as e:
        logger.error(f"Error loading TUI mapping: {e}")
    
    return mapping


def initialize_nlp_engine(ner_engine_preference: str = app_config.DEFAULT_NER_ENGINE):
    """
    Initialize the NLP engine with modular components
    FIXED: Use existing MedCAT integration properly
    """
    global NLP_SPACY, MEDCAT_PROCESSOR, CLINICAL_BERT, TUI_NAME_MAP
    
    logger.info(f"Initializing NLP Engine...")
    logger.info(f"spaCy Model: {app_config.SPACY_MODEL}")
    logger.info(f"NER Engine: {ner_engine_preference}")
    
    # Load TUI mapping
    TUI_NAME_MAP = _load_tui_mapping(app_config.TUI_MAPPING_FILE_PATH)
    
    # Initialize ClinicalBERT
    if app_config.ENABLE_CLINICAL_BERT:
        try:
            from .clinical_bert import get_dynamic_clinical_bert
            CLINICAL_BERT = get_dynamic_clinical_bert()
            if CLINICAL_BERT.is_available():
                logger.info("ClinicalBERT initialized successfully")
            else:
                logger.warning("ClinicalBERT initialization failed")
        except Exception as e:
            logger.error(f"ClinicalBERT initialization error: {e}")
    
    # FIXED: Initialize MedCAT using your existing integration
    if ner_engine_preference in ["medcat", "hybrid"]:
        try:
            # Use your existing MedCAT integration
            from .medcat_integration import get_medcat_processor
            
            MEDCAT_PROCESSOR = get_medcat_processor(
                cdb_path=app_config.MEDCAT_CDB_PATH,
                vocab_path=app_config.MEDCAT_VOCAB_PATH,
                config_path=app_config.MEDCAT_CONFIG_PATH,
                spacy_model=app_config.SPACY_MODEL
            )
            
            if MEDCAT_PROCESSOR and MEDCAT_PROCESSOR.is_available():
                logger.info("✅ MedCAT initialized successfully using existing integration")
                
                # Get some stats
                model_info = MEDCAT_PROCESSOR.get_model_info()
                logger.info(f"MedCAT Concepts: {model_info.get('cdb_concepts', 'unknown')}")
                logger.info(f"Confidence Mappings: {model_info.get('confidence_mappings', 'unknown')}")
            else:
                logger.warning("❌ MedCAT initialization failed")
                if ner_engine_preference == "medcat":
                    logger.info("🔄 Falling back to spaCy NER")
                    ner_engine_preference = "spacy"
                MEDCAT_PROCESSOR = None
                
        except Exception as e:
            logger.error(f"❌ MedCAT initialization error: {e}")
            
            # Try the medcat_fixes version as fallback
            try:
                logger.info("🔄 Trying MedCAT with fixes...")
                from .medcat_fixes import load_medcat_with_fixes
                from pathlib import Path
                
                model_dir = Path(app_config.MEDCAT_CDB_PATH).parent
                cat_instance = load_medcat_with_fixes(model_dir)
                
                if cat_instance:
                    # Wrap in a compatible processor
                    class FixedMedCATProcessor:
                        def __init__(self, cat_instance):
                            self.cat = cat_instance
                            self._available = True
                        
                        def is_available(self):
                            return self._available and self.cat is not None
                        
                        def get_entities(self, text):
                            return self.cat.get_entities(text)
                        
                        def get_model_info(self):
                            from .medcat_fixes import get_medcat_info
                            return get_medcat_info(self.cat)
                    
                    MEDCAT_PROCESSOR = FixedMedCATProcessor(cat_instance)
                    logger.info("✅ MedCAT loaded using fixes module")
                else:
                    logger.error("❌ MedCAT fixes also failed")
                    if ner_engine_preference == "medcat":
                        ner_engine_preference = "spacy"
                    MEDCAT_PROCESSOR = None
                    
            except Exception as e2:
                logger.error(f"❌ MedCAT fixes error: {e2}")
                if ner_engine_preference == "medcat":
                    ner_engine_preference = "spacy"
                MEDCAT_PROCESSOR = None
    
    # Load base spaCy model
    try:
        disable_pipes = []
        # Only disable NER if we have a working MedCAT instance
        if (ner_engine_preference == "medcat" and 
            MEDCAT_PROCESSOR and 
            MEDCAT_PROCESSOR.is_available()):
            disable_pipes.append('ner')
            logger.info("Disabling spaCy NER (using MedCAT)")
        
        NLP_SPACY = spacy.load(app_config.SPACY_MODEL, disable=disable_pipes)
        logger.info(f"Loaded spaCy model with pipes: {NLP_SPACY.pipe_names}")
        
    except Exception as e:
        logger.critical(f"Failed to load spaCy model: {e}")
        NLP_SPACY = None
        return
    
    # Build processing pipeline
    _build_pipeline(ner_engine_preference)
    
    logger.info(f"NLP Engine initialized successfully")
    logger.info(f"Final pipeline: {NLP_SPACY.pipe_names}")


def _build_pipeline(ner_engine: str):
    """Build the NLP processing pipeline with proper MedCAT integration"""
    global NLP_SPACY, MEDCAT_PROCESSOR, CLINICAL_BERT
    
    if not NLP_SPACY:
        return
    
    # 1. Section detection first
    if MEDSPACY_AVAILABLE and app_config.ENABLE_SECTION_DETECTION:
        try:
            if not NLP_SPACY.has_pipe("sectionizer"):
                NLP_SPACY.add_pipe("medspacy_sectionizer", name="sectionizer")
                sectionizer = NLP_SPACY.get_pipe("sectionizer")
                
                # Use the new section rules name
                for rule in rules.CLINICAL_SECTION_RULES:
                    try:
                        sectionizer.add(rule)
                    except Exception as e:
                        logger.warning(f"Error adding section rule: {e}")
                        
                logger.info(f"✅ Added sectionizer with {len(rules.CLINICAL_SECTION_RULES)} rules")
        except Exception as e:
            logger.warning(f"Could not add MedSpaCy sectionizer: {e}")
    
    # 2. PRIMARY NER - FIXED to use your existing MedCAT component
    ner_added = False
    
    if (ner_engine == "medcat" and 
        MEDCAT_PROCESSOR and 
        MEDCAT_PROCESSOR.is_available()):
        
        try:
            # FIXED: Use your existing MedCATSpacyComponent
            from .medcat_integration import MedCATSpacyComponent
            
            # Method 1: Try using the existing factory (if it exists)
            if Language.has_factory("medcat"):
                try:
                    # Your existing factory expects medcat_processor in config
                    NLP_SPACY.add_pipe("medcat", config={"medcat_processor": MEDCAT_PROCESSOR})
                    logger.info("✅ Added MedCAT using existing factory")
                    ner_added = True
                except Exception as e:
                    logger.warning(f"Existing factory failed: {e}")
            
            # Method 2: Register new factory with your component
            if not ner_added:
                # Register factory if it doesn't exist
                if not Language.has_factory("medcat_custom"):
                    @Language.factory("medcat_custom")
                    def create_medcat_custom(nlp: Language, name: str):
                        return MedCATSpacyComponent(nlp, MEDCAT_PROCESSOR, name)
                
                NLP_SPACY.add_pipe("medcat_custom", name="medcat")
                logger.info("✅ Added MedCAT using custom factory")
                ner_added = True
            
        except Exception as e:
            logger.error(f"❌ MedCAT component addition failed: {e}")
            logger.info("🔄 Falling back to spaCy NER")
    
    # 3. Fallback to spaCy NER if MedCAT failed
    if not ner_added:
        if "ner" not in NLP_SPACY.pipe_names:
            try:
                NLP_SPACY.add_pipe("ner")
                logger.info("✅ Added spaCy NER as fallback")
                ner_added = True
            except Exception as e:
                logger.error(f"❌ Failed to add spaCy NER: {e}")
        else:
            logger.info("✅ Using existing spaCy NER")
            ner_added = True
    
    # 4. EntityRuler for additional coverage (only if we have some NER)
    if app_config.ENABLE_ENTITY_RULER and ner_added:
        try:
            if not NLP_SPACY.has_pipe("entity_ruler"):
                NLP_SPACY.add_pipe("entity_ruler", name="clinical_ruler", 
                                 config={"overwrite_ents": False})
                
                ruler = NLP_SPACY.get_pipe("clinical_ruler")
                
                # Simple, effective patterns
                clinical_patterns = [
                    {"label": "CONDITION", "pattern": "diabetes"},
                    {"label": "CONDITION", "pattern": "hypertension"},  
                    {"label": "CONDITION", "pattern": "chest pain"},
                    {"label": "CONDITION", "pattern": "pneumonia"},
                    {"label": "DRUG", "pattern": "aspirin"},
                    {"label": "DRUG", "pattern": "metformin"},
                    {"label": "DRUG", "pattern": "lisinopril"},
                    {"label": "VITAL_SIGN", "pattern": [{"LOWER": "blood"}, {"LOWER": "pressure"}]},
                    {"label": "VITAL_SIGN", "pattern": [{"LOWER": "heart"}, {"LOWER": "rate"}]},
                ]
                
                ruler.add_patterns(clinical_patterns)
                logger.info(f"✅ Added clinical EntityRuler with {len(clinical_patterns)} patterns")
        except Exception as e:
            logger.warning(f"EntityRuler addition failed: {e}")
    
    # 5. ClinicalBERT enhancement
    if (CLINICAL_BERT and 
        CLINICAL_BERT.is_available() and 
        app_config.ENABLE_CLINICAL_BERT_ENHANCEMENT):
        try:
            if not NLP_SPACY.has_pipe("clinical_bert"):
                NLP_SPACY.add_pipe("clinical_bert")
                logger.info("✅ Added ClinicalBERT enhancement")
        except Exception as e:
            logger.warning(f"ClinicalBERT addition failed: {e}")
    
    # 6. Context analysis
    if MEDSPACY_AVAILABLE and app_config.ENABLE_CONTEXT_ANALYSIS:
        try:
            logger.info("🔄 Attempting to add MedSpaCy context component...")
            logger.info(f"MEDSPACY_AVAILABLE: {MEDSPACY_AVAILABLE}")
            logger.info(f"ENABLE_CONTEXT_ANALYSIS: {app_config.ENABLE_CONTEXT_ANALYSIS}")
            
            if not NLP_SPACY.has_pipe("context"):
                logger.info("Adding medspacy_context component...")
                NLP_SPACY.add_pipe("medspacy_context", name="context")
                logger.info("✅ medspacy_context component added successfully")
                
                context = NLP_SPACY.get_pipe("context")
                logger.info(f"Got context component: {type(context)}")
                
                logger.info(f"About to add {len(rules.CONTEXT_RULES_LIST)} rules...")
                context.add(rules.CONTEXT_RULES_LIST)
                logger.info("✅ Rules added to context component")
                
                # Count termination rules
                termination_rules = [r for r in rules.CONTEXT_RULES_LIST if r.category == "TERMINATE"]
                logger.info(f"📋 Total rules: {len(rules.CONTEXT_RULES_LIST)}")
                logger.info(f"📋 TERMINATE rules: {len(termination_rules)}")
                
                # Log first few termination rules
                for i, rule in enumerate(termination_rules[:3]):
                    logger.info(f"  TERMINATE Rule {i+1}: '{rule.literal}' -> {rule.category}")
                    
            else:
                logger.info("Context component already exists in pipeline")
                
        except Exception as e:
            logger.error(f"❌ Failed to add context component: {e}", exc_info=True)
    else:
        logger.warning(f"❌ Context not added. MEDSPACY_AVAILABLE: {MEDSPACY_AVAILABLE}, ENABLE_CONTEXT_ANALYSIS: {app_config.ENABLE_CONTEXT_ANALYSIS}")


async def get_intelligent_fallback_entities_async(
    text: str, 
    medcat_entities: List[NLPEntity],
    enable_clinical_bert: bool = True,
    timeout: float = None
) -> List[NLPEntity]:
    """Intelligent fallback with timeout support"""
    if timeout is None:
        timeout = app_config.FALLBACK_TIMEOUT_SECONDS
    """
    FIXED: Synchronous version of intelligent fallback with parameter control
    """
    if not NLP_SPACY:
        return []
    
    logger.info(f"Starting intelligent fallback detection... (ClinicalBERT: {enable_clinical_bert})")
    fallback_entities = []
    
    try:
        # Step 1: Get spaCy entities (clinical model should catch medical terms)
        import spacy
        
        try:
            fallback_nlp = spacy.load(app_config.SPACY_MODEL)
        except:
            logger.warning("Could not load separate spaCy for fallback, using main pipeline")
            fallback_nlp = NLP_SPACY
        
        doc = fallback_nlp(text)
        spacy_entities = []
        
        for ent in doc.ents:
            if _is_potentially_clinical(ent.label_, ent.text):
                spacy_entities.append({
                    'text': ent.text,
                    'start': ent.start_char,
                    'end': ent.end_char,
                    'label': ent.label_,
                    'spacy_confidence': _get_spacy_confidence(ent)
                })
        
        # Step 2: Find gaps
        medcat_spans = [(e.start_char, e.end_char, e.text.lower()) for e in medcat_entities]
        
        potential_gaps = []
        for spacy_ent in spacy_entities:
            is_covered = any(
                _spans_overlap(spacy_ent['start'], spacy_ent['end'], mc_start, mc_end)
                for mc_start, mc_end, _ in medcat_spans
            )
            
            if not is_covered:
                potential_gaps.append(spacy_ent)
        
        if not potential_gaps:
            return []
        
        logger.info(f"Found {len(potential_gaps)} potential gaps")
        
        # Step 3: FIXED - Validate gaps with ClinicalBERT parameter
        try:
            validated_gaps = await asyncio.wait_for(
                _validate_clinical_gaps_async(
                    text, 
                    potential_gaps, 
                    enable_clinical_bert=enable_clinical_bert
                ),
                timeout=timeout * 0.8  # Use 80% of total timeout for validation
            )
        except asyncio.TimeoutError:
            logger.warning(f"Clinical gap validation timed out, using basic validation")
            validated_gaps = _validate_gaps_basic(potential_gaps)
        
        # Step 4: Convert to NLPEntity objects
        for gap in validated_gaps:
            if gap.get('clinical_confidence', 0) > 0.6:
                fallback_entity = NLPEntity(
                    text=gap['text'],
                    start_char=gap['start'],
                    end_char=gap['end'],
                    label=gap.get('clinical_category', gap['label']),
                    source_ner_engine="spacy_ner",
                    ner_confidence=gap.get('clinical_confidence', 0.7),
                    primary_cui=gap.get('cui'),
                    type_ids=gap.get('tuis', []),
                    section_title="intelligent_fallback"
                )
                
                fallback_entities.append(fallback_entity)
                logger.info(f"Fallback entity: '{gap['text']}' -> {gap.get('clinical_category', 'UNKNOWN')}")
        
        return fallback_entities
        
    except Exception as e:
        logger.error(f"Intelligent fallback failed: {e}")
        return []


async def _validate_clinical_gaps_async(
    text: str, 
    gaps: List[Dict],
    enable_clinical_bert: bool = True
) -> List[Dict]:
    """
    FIXED: Single validation function with ClinicalBERT parameter control
    """
    validated = []
    
    try:
        for gap in gaps:
            gap_text = gap['text']
            gap_text_lower = gap_text.lower()
            
            # Initialize confidence score
            confidence = 0.0
            
            # 1. Drug Pattern Recognition (High confidence)
            drug_confidence = _get_drug_pattern_confidence(gap_text)
            if drug_confidence > 0:
                confidence = max(confidence, drug_confidence)
            
            # 2. Clinical Pattern Recognition
            clinical_confidence = _get_clinical_pattern_confidence(gap_text)
            if clinical_confidence > 0:
                confidence = max(confidence, clinical_confidence * 0.9)
            
            # 3. FIXED - ClinicalBERT validation (only if enabled)
            if enable_clinical_bert and CLINICAL_BERT and CLINICAL_BERT.is_available():
                try:
                    logger.debug(f"🤖 Running ClinicalBERT validation for '{gap_text}'")
                    similarity = await CLINICAL_BERT.get_similarity_async(gap_text, text)
                    analysis = CLINICAL_BERT.analyze_text(gap_text)  # Keep this sync as it's fast
                    bert_confidence = analysis.get('clinical_confidence', 0.5)
                    
                    # Combine similarity and clinical confidence
                    combined_bert = (similarity * 0.3 + bert_confidence * 0.7)
                    confidence = max(confidence, combined_bert * 0.8)
                    
                    logger.debug(f"ClinicalBERT result for '{gap_text}': sim={similarity:.3f}, clinical={bert_confidence:.3f}")
                    
                except Exception as e:
                    logger.debug(f"ClinicalBERT validation failed for '{gap_text}': {e}")
            else:
                logger.debug(f"⏭️ ClinicalBERT validation skipped for '{gap_text}' (disabled: {not enable_clinical_bert})")
            
            # 4. Basic heuristics for context and length
            if 3 <= len(gap_text) <= 15:
                confidence += 0.1
            elif len(gap_text) < 3:
                confidence -= 0.2
            
            # Medical context boost
            medical_context_words = ['patient', 'takes', 'prescribed', 'medication', 'mg', 'mcg', 'daily', 'symptoms']
            if any(word in text.lower() for word in medical_context_words):
                confidence += 0.1
            
            # Set final confidence and threshold
            gap['clinical_confidence'] = min(1.0, max(0.0, confidence))
            
            # Adaptive threshold based on entity type
            threshold = 0.3 if drug_confidence > 0.8 else 0.5
            
            if gap['clinical_confidence'] > threshold:
                validated.append(gap)
                logger.info(f"Validated: '{gap_text}' (conf: {gap['clinical_confidence']:.3f})")
        
        return validated
        
    except Exception as e:
        logger.error(f"Clinical gap validation failed: {e}")
        return []


def _convert_spacy_entities(doc: SpacyDoc) -> List[NLPEntity]:
    """Convert spaCy entities to NLPEntity objects with enhanced context detection"""
    entities = []
    
    # NEW: Extract context information from the entire document
    context_map = extract_context_from_doc(doc)
    logger.debug(f"Processing {len(doc.ents)} entities with {len(context_map)} context spans")
    
    for ent in doc.ents:
        try:
            # Your existing entity creation logic (keep all of this)
            source_engine = "spacy_ner"  # default
            
            # Check for MedCAT attributes (from your existing code)
            medcat_indicators = [
                hasattr(ent._, 'cui') and ent._.cui,
                hasattr(ent._, 'medcat_id') and ent._.medcat_id,
                hasattr(ent._, 'medcat_confidence') and ent._.medcat_confidence,
                hasattr(ent._, 'tuis') and ent._.tuis,
                ent.label_ == "MEDICAL_CONCEPT"
            ]
            
            if any(medcat_indicators):
                source_engine = "medcat"
            
            # Get CUI (your existing logic)
            cui = None
            if hasattr(ent._, 'cui') and ent._.cui and str(ent._.cui) != "-1":
                cui = str(ent._.cui)
            
            # Get confidence (your existing logic)
            confidence = None
            confidence_sources = [
                ('medcat_confidence', lambda x: float(x) if x else None),
                ('score', lambda x: float(x) if x else None),
                ('acc', lambda x: float(x) if x else None),
            ]
            
            for attr_name, converter in confidence_sources:
                if hasattr(ent._, attr_name):
                    try:
                        conf_val = getattr(ent._, attr_name)
                        confidence = converter(conf_val)
                        if confidence is not None and confidence > 0:
                            break
                    except (ValueError, TypeError):
                        continue
            
            # Get semantic information (your existing logic)
            type_ids = []
            type_names = []
            
            if hasattr(ent._, 'tuis') and ent._.tuis:
                type_ids = [str(tui) for tui in ent._.tuis if tui]
                for tui in type_ids:
                    if tui in TUI_NAME_MAP:
                        type_names.append(TUI_NAME_MAP[tui])
            
            if hasattr(ent._, 'snames') and ent._.snames:
                additional_names = [str(name) for name in ent._.snames if name and str(name) not in type_names]
                type_names.extend(additional_names)
            
            # Create NLPEntity (your existing logic)
            nlp_entity = NLPEntity(
                text=ent.text.strip(),
                start_char=ent.start_char,
                end_char=ent.end_char,
                label=ent.label_,
                source_ner_engine=source_engine,
                ner_confidence=confidence,
                primary_cui=cui,
                type_ids=type_ids,
                type_names=type_names
            )
            
            # Section information (your existing logic)
            if hasattr(ent._, "section_category") and ent._.section_category:
                nlp_entity.section_title = str(ent._.section_category)
            else:
                nlp_entity.section_title = "default_section"
            
            # ENHANCED: Apply hybrid context detection
            nlp_entity = apply_enhanced_context_detection(nlp_entity, doc, ent, context_map)
            
            entities.append(nlp_entity)
            
        except Exception as e:
            logger.warning(f"Error creating NLPEntity for '{ent.text}': {e}")
            # Create minimal entity as fallback (your existing logic)
            try:
                basic_entity = NLPEntity(
                    text=ent.text,
                    start_char=ent.start_char,
                    end_char=ent.end_char,
                    label=ent.label_,
                    source_ner_engine="spacy_ner"
                )
                entities.append(basic_entity)
            except Exception as e2:
                logger.error(f"Failed to create even basic entity: {e2}")
    
    logger.info(f"Converted {len(entities)} entities with enhanced context detection")
    return entities


def get_entity_clinical_category(entity: NLPEntity) -> str:
    """
    Categorize entity into clinical categories using the new rules structure
    
    Args:
        entity: NLPEntity to categorize
        
    Returns:
        Clinical category string
    """
    entity_text_lower = entity.text.lower()
    
    # Use new CLINICAL_TERM_OVERRIDES instead of EXACT_TERM_OVERRIDES
    if entity_text_lower in rules.CLINICAL_TERM_OVERRIDES:
        return rules.CLINICAL_TERM_OVERRIDES[entity_text_lower]
    
    # Pattern-based rules (updated to use CLINICAL_PATTERN_RULES)
    for pattern_text, search_type, section_pattern_re, category_override in rules.CLINICAL_PATTERN_RULES:
        if _pattern_matches(entity_text_lower, pattern_text, search_type):
            if section_pattern_re is None:
                return category_override
            # Check section context if specified
            current_section = entity.section_title or ""
            if section_pattern_re.search(current_section):
                return category_override
    
    # TUI-based categorization (unchanged)
    if entity.type_ids:
        for tui in entity.type_ids:
            category = rules.TUI_TO_CATEGORY.get(tui.upper())
            if category:
                return category
    
    # Semantic type name categorization (unchanged)
    if entity.type_names:
        for sty_name in entity.type_names:
            normalized_sty = sty_name.upper()
            category = rules.STY_NAME_TO_CATEGORY_MAP.get(normalized_sty)
            if category:
                return category
    
    # spaCy label categorization (unchanged)
    if entity.source_ner_engine == 'spacy_ner' and entity.label:
        category = rules.SPACY_LABEL_TO_CATEGORY.get(entity.label.upper())
        if category:
            return category
    
    # EntityRuler label
    if entity.source_ner_engine == 'entity_ruler' and entity.label:
        return entity.label.upper()
    
    return "UNKNOWN_CATEGORY"


def _pattern_matches(text: str, pattern: str, search_type: str) -> bool:
    """Check if text matches pattern based on search type"""
    if search_type == "exact":
        return text == pattern
    elif search_type == "contains":
        return pattern in text
    elif search_type == "startswith":
        return text.startswith(pattern)
    elif search_type == "endswith":
        return text.endswith(pattern)
    elif search_type == "regex":
        import re
        return bool(re.search(pattern, text))
    return False


# Utility functions
def get_pipeline_info() -> Dict[str, Any]:
    """Get information about the current NLP pipeline"""
    info = {
        "spacy_available": NLP_SPACY is not None,
        "spacy_model": app_config.SPACY_MODEL,
        "pipeline_components": NLP_SPACY.pipe_names if NLP_SPACY else [],
        "medcat_available": MEDCAT_PROCESSOR is not None and MEDCAT_PROCESSOR.is_available() if MEDCAT_PROCESSOR else False,
        "clinical_bert_available": CLINICAL_BERT is not None and CLINICAL_BERT.is_available() if CLINICAL_BERT else False,
        "default_ner_engine": app_config.DEFAULT_NER_ENGINE,
        "tui_mappings_loaded": len(TUI_NAME_MAP)
    }
    
    if MEDCAT_PROCESSOR:
        try:
            info["medcat_info"] = MEDCAT_PROCESSOR.get_model_info()
        except Exception as e:
            logger.warning(f"Error getting MedCAT info: {e}")
    
    if CLINICAL_BERT:
        try:
            info["clinical_bert_info"] = CLINICAL_BERT.get_model_info()
        except Exception as e:
            logger.warning(f"Error getting ClinicalBERT info: {e}")
    
    return info


# Backward compatibility - keep old references working
def get_medcat_instance():
    """Get MedCAT instance for backward compatibility"""
    return MEDCAT_PROCESSOR

def get_spacy_nlp():
    """Get spaCy instance for backward compatibility"""
    return NLP_SPACY

def is_clinical_bert_available():
    """Check if ClinicalBERT is available"""
    return CLINICAL_BERT is not None and CLINICAL_BERT.is_available()

# Debugging Medcat
def debug_medcat_detection(text: str, target_terms: List[str] = None):
    """Debug MedCAT entity detection with focused logging"""
    if target_terms is None:
        target_terms = ["levothyroxine", "amlodipine", "hypothyroidism", "TSH"]
    
    logger.info(f"=== MEDCAT DEBUG START ===")
    logger.info(f"Target terms: {target_terms}")
    
    # 1. Test MedCAT availability
    if not MEDCAT_PROCESSOR or not MEDCAT_PROCESSOR.is_available():
        logger.error("MedCAT not available")
        return
    
    # 2. Test direct CDB lookup
    if hasattr(MEDCAT_PROCESSOR, 'cat') and hasattr(MEDCAT_PROCESSOR.cat, 'cdb'):
        cdb = MEDCAT_PROCESSOR.cat.cdb
        logger.info("=== CDB DIRECT LOOKUP ===")
        
        for term in target_terms:
            term_lower = term.lower()
            # Check if term exists in name2cuis
            if hasattr(cdb, 'name2cuis') and term_lower in cdb.name2cuis:
                cuis = cdb.name2cuis[term_lower]
                logger.info(f"✅ '{term}' found in CDB -> CUIs: {list(cuis)[:3]}")
            else:
                logger.warning(f"❌ '{term}' NOT found in name2cuis")
    
    # 3. Test MedCAT processing
    logger.info("=== MEDCAT PROCESSING TEST ===")
    try:
        result = MEDCAT_PROCESSOR.get_entities(text)
        entities = result.get('entities', {})
        
        logger.info(f"Total entities found: {len(entities)}")
        
        # Check for target terms
        found_terms = []
        for ent_id, ent_data in entities.items():
            detected_name = ent_data.get('detected_name', '').lower()
            source_value = ent_data.get('source_value', '').lower()
            
            for target in target_terms:
                if target.lower() in detected_name or target.lower() in source_value:
                    found_terms.append(target)
                    logger.info(f"✅ Found '{target}': {ent_data.get('detected_name')} (CUI: {ent_data.get('cui')}, Conf: {ent_data.get('acc', 'N/A')})")
        
        missing_terms = set(target_terms) - set(found_terms)
        if missing_terms:
            logger.warning(f"❌ Missing terms: {missing_terms}")
        
        # Show first 3 entities for context
        logger.info("=== SAMPLE ENTITIES ===")
        for i, (ent_id, ent_data) in enumerate(list(entities.items())[:3]):
            logger.info(f"Entity {i+1}: '{ent_data.get('detected_name')}' -> {ent_data.get('cui')} (conf: {ent_data.get('acc', 'N/A')})")
            
    except Exception as e:
        logger.error(f"MedCAT processing failed: {e}")
    
    logger.info(f"=== MEDCAT DEBUG END ===")
    
    # Add to clinicalai_service/nlp_engine/processor.py

def debug_medcat_processing(text: str):
    """Debug MedCAT entity extraction step-by-step"""
    logger.info("=== MEDCAT PROCESSING DEBUG ===")
    
    if not MEDCAT_PROCESSOR or not MEDCAT_PROCESSOR.is_available():
        logger.error("❌ MedCAT not available")
        return {}
    
    try:
        # Test with simple text
        logger.info(f"Testing: '{text[:50]}...'")
        result = MEDCAT_PROCESSOR.get_entities(text)
        
        if 'error' in result:
            logger.error(f"❌ MedCAT error: {result['error']}")
            return result
        
        entities = result.get('entities', {})
        logger.info(f"Total entities found: {len(entities)}")
        
        # Show ALL entities with details
        logger.info("=== ALL ENTITIES ===")
        target_terms = ['levothyroxine', 'amlodipine', 'hypothyroidism', 'TSH', 'hypertension']
        
        found_targets = []
        all_entities = []
        
        for ent_id, ent_data in entities.items():
            detected = ent_data.get('detected_name', '')
            cui = ent_data.get('cui', '')
            conf = ent_data.get('acc', 0)
            tuis = ent_data.get('type_ids', [])
            start = ent_data.get('start', 0)
            end = ent_data.get('end', 0)
            
            entity_info = {
                'detected_name': detected,
                'cui': cui,
                'confidence': conf,
                'position': f"{start}-{end}",
                'type_ids': tuis
            }
            all_entities.append(entity_info)
            
            # Check if it's a target term
            detected_lower = detected.lower()
            for target in target_terms:
                if target in detected_lower:
                    found_targets.append(entity_info)
                    logger.info(f"🎯 TARGET FOUND: {detected} -> {cui} (conf: {conf:.3f}, TUIs: {tuis})")
        
        # Show first 10 entities for context
        logger.info("=== FIRST 10 ENTITIES ===")
        for i, ent in enumerate(all_entities[:10]):
            logger.info(f"{i+1:2d}. {ent['detected_name']:<20} -> {ent['cui']:<10} (conf: {ent['confidence']:.3f}, TUIs: {ent['type_ids']})")
        
        # Check if levothyroxine appears anywhere
        logger.info("=== LEVOTHYROXINE SEARCH ===")
        levo_found = []
        for ent in all_entities:
            if 'levothyroxine' in ent['detected_name'].lower() or 'thyroxine' in ent['detected_name'].lower():
                levo_found.append(ent)
                logger.info(f"🔍 LEVO-RELATED: {ent['detected_name']} -> {ent['cui']} (TUIs: {ent['type_ids']})")
        
        if not levo_found:
            logger.warning("❌ NO levothyroxine/thyroxine entities found at all!")
        
        return {
            'total_entities': len(entities),
            'target_entities_found': found_targets,
            'levothyroxine_entities': levo_found,
            'sample_entities': all_entities[:5]
        }
        
    except Exception as e:
        logger.error(f"❌ Debug processing failed: {e}", exc_info=True)
        return {'error': str(e)}
    
    # Add this to the end of processor.py (before the backward compatibility section)

def debug_medcat_tokenization():
    """Debug MedCAT at the tokenization level"""
    logger.info("=== MEDCAT TOKENIZATION DEBUG ===")
    
    if not MEDCAT_PROCESSOR or not hasattr(MEDCAT_PROCESSOR, 'cat'):
        logger.error("❌ MedCAT not available")
        return
    
    # Get the actual MedCAT instance
    cat = MEDCAT_PROCESSOR.cat
    
    # Test simple text with levothyroxine
    test_text = "Patient takes levothyroxine 75 mcg daily"
    logger.info(f"Testing text: '{test_text}'")
    
    try:
        # Check MedCAT structure first
        logger.info("=== MEDCAT STRUCTURE ===")
        logger.info(f"CAT type: {type(cat)}")
        
        # Test minimal cases first
        simple_tests = [
            "levothyroxine",
            "amlodipine", 
            "hypothyroidism"
        ]
        
        logger.info("=== SIMPLE TERM TESTS ===")
        for term in simple_tests:
            logger.info(f"Testing: '{term}'")
            try:
                result = cat.get_entities(term)
                entities = result.get('entities', {})
                logger.info(f"  Found {len(entities)} entities")
                
                if entities:
                    for ent_id, ent_data in list(entities.items())[:2]:
                        logger.info(f"    - {ent_data.get('detected_name')} -> {ent_data.get('cui')}")
                else:
                    logger.warning(f"  ❌ NO entities found for '{term}'")
                    
            except Exception as e:
                logger.error(f"  ❌ Error processing '{term}': {e}")
        
        # Check CDB directly for these terms
        logger.info("=== CDB VERIFICATION ===")
        if hasattr(cat, 'cdb') and hasattr(cat.cdb, 'name2cuis'):
            for term in simple_tests:
                term_lower = term.lower()
                if term_lower in cat.cdb.name2cuis:
                    cuis = list(cat.cdb.name2cuis[term_lower])[:2]
                    logger.info(f"✅ CDB has '{term}': {cuis}")
                    
                    # Check confidence
                    if hasattr(cat.cdb, 'cui2average_confidence') and cuis:
                        conf = cat.cdb.cui2average_confidence.get(cuis[0], 'MISSING')
                        logger.info(f"    Confidence: {conf}")
                else:
                    logger.warning(f"❌ CDB missing '{term}'")
        
    except Exception as e:
        logger.error(f"❌ Debug failed: {e}", exc_info=True)
        
# Add to processor.py

async def get_intelligent_fallback_entities(
    text: str, 
    medcat_entities: List[NLPEntity],
    terminology_service: TypingOptional[Any] = None
) -> List[NLPEntity]:
    """
    Intelligent fallback using ClinicalBERT + Terminology Service
    
    Strategy:
    1. Use ClinicalBERT to identify potential medical spans
    2. Cross-reference with terminology service  
    3. Fill gaps that MedCAT missed
    4. Use confidence scoring to avoid false positives
    """
    if not NLP_SPACY:
        return []
    
    logger.info("🔄 Starting intelligent fallback detection...")
    fallback_entities = []
    
    try:
        # Step 1: Get baseline spaCy entities (clinical model should catch medical terms)
        doc = NLP_SPACY(text)
        spacy_entities = []
        
        for ent in doc.ents:
            # Clinical spaCy model should identify medical concepts
            if _is_potentially_clinical(ent.label_, ent.text):
                spacy_entities.append({
                    'text': ent.text,
                    'start': ent.start_char,
                    'end': ent.end_char,
                    'label': ent.label_,
                    'spacy_confidence': _get_spacy_confidence(ent)
                })
        
        # Step 2: Find gaps - spaCy found it but MedCAT didn't
        medcat_spans = [(e.start_char, e.end_char, e.text.lower()) for e in medcat_entities]
        
        potential_gaps = []
        for spacy_ent in spacy_entities:
            # Check if this span overlaps with any MedCAT entity
            is_covered = any(
                _spans_overlap(spacy_ent['start'], spacy_ent['end'], mc_start, mc_end)
                for mc_start, mc_end, _ in medcat_spans
            )
            
            if not is_covered:
                potential_gaps.append(spacy_ent)
                logger.debug(f"🔍 Gap found: '{spacy_ent['text']}' ({spacy_ent['label']})")
        
        if not potential_gaps:
            logger.info("✅ No gaps found - MedCAT coverage is complete")
            return []
        
        logger.info(f"🔍 Found {len(potential_gaps)} potential gaps to investigate")
        
        # Step 3: Use ClinicalBERT to validate clinical relevance
        if CLINICAL_BERT and CLINICAL_BERT.is_available():
            validated_gaps = await _validate_gaps_with_clinicalbert(text, potential_gaps)
        else:
            # Fallback: use basic heuristics
            validated_gaps = _validate_gaps_basic(potential_gaps)
        
        # Step 4: Enhance with terminology service
        if terminology_service:
            enhanced_gaps = await _enhance_with_terminology_service(validated_gaps, terminology_service)
        else:
            enhanced_gaps = validated_gaps
        
        # Step 5: Convert to NLPEntity objects
        for gap in enhanced_gaps:
            if gap.get('clinical_confidence', 0) > 0.6:  # Configurable threshold
                fallback_entity = NLPEntity(
                    text=gap['text'],
                    start_char=gap['start'],
                    end_char=gap['end'],
                    label=gap.get('clinical_category', gap['label']),
                    source_ner_engine="spacy_ner",  # Mark as fallback
                    ner_confidence=gap.get('clinical_confidence', 0.7),
                    primary_cui=gap.get('cui'),
                    type_ids=gap.get('tuis', []),
                    section_title="intelligent_fallback"
                )
                
                fallback_entities.append(fallback_entity)
                logger.info(f"✅ Intelligent fallback: '{gap['text']}' -> {gap.get('clinical_category', 'UNKNOWN')} (conf: {gap.get('clinical_confidence', 0):.2f})")
        
        logger.info(f"🎯 Intelligent fallback found {len(fallback_entities)} additional entities")
        return fallback_entities
        
    except Exception as e:
        logger.error(f"❌ Intelligent fallback failed: {e}", exc_info=True)
        return []


def _is_potentially_clinical(label: str, text: str) -> bool:
    """Determine if a spaCy entity could be clinically relevant"""
    # Clinical labels from en_core_sci_lg
    clinical_labels = {
        'CHEMICAL', 'DISEASE', 'GENE', 'ENTITY',  # scispacy labels
        'PERSON', 'ORG', 'PRODUCT', 'QUANTITY',   # Standard spaCy that might be clinical
    }
    
    # Text-based heuristics
    clinical_keywords = {
        'syndrome', 'disease', 'disorder', 'condition', 'itis', 'osis', 'emia', 'uria',
        'mg', 'mcg', 'ml', 'tablet', 'daily', 'twice', 'medication', 'drug',
        'pain', 'ache', 'fever', 'nausea', 'fatigue', 'pressure', 'rate'
    }
    
    if label in clinical_labels:
        return True
    
    text_lower = text.lower()
    if any(keyword in text_lower for keyword in clinical_keywords):
        return True
    
    # Length-based filter (medical terms are usually 3+ chars)
    if len(text) >= 3 and text.isalpha():
        return True
    
    return False


def _spans_overlap(start1: int, end1: int, start2: int, end2: int) -> bool:
    """Check if two spans overlap"""
    return not (end1 <= start2 or end2 <= start1)


def _get_spacy_confidence(ent) -> float:
    """Get confidence score for spaCy entity (heuristic-based)"""
    # spaCy doesn't provide confidence directly, so use heuristics
    base_confidence = 0.8
    
    # Boost confidence for clinical models
    if hasattr(ent, 'label_') and ent.label_ in ['CHEMICAL', 'DISEASE']:
        base_confidence = 0.9
    
    # Length-based adjustment
    if len(ent.text) > 10:
        base_confidence += 0.1
    elif len(ent.text) < 4:
        base_confidence -= 0.2
    
    return min(1.0, max(0.1, base_confidence))


async def _validate_gaps_with_clinicalbert(text: str, gaps: List[Dict]) -> List[Dict]:
    """Use ClinicalBERT to validate clinical relevance of gaps"""
    validated = []
    
    try:
        # Get document embeddings
        doc_embeddings = CLINICAL_BERT.get_embeddings(text)
        if doc_embeddings is None:
            logger.warning("ClinicalBERT embeddings failed, using basic validation")
            return _validate_gaps_basic(gaps)
        
        for gap in gaps:
            # Get entity embeddings
            entity_embeddings = CLINICAL_BERT.get_embeddings(gap['text'])
            if entity_embeddings is None:
                continue
            
            # Calculate similarity with document context
            similarity = CLINICAL_BERT.get_similarity(gap['text'], text)
            
            # Get clinical analysis
            analysis = CLINICAL_BERT.analyze_text(gap['text'])
            clinical_confidence = analysis.get('clinical_confidence', 0.5)
            
            # Combine scores
            combined_confidence = (similarity * 0.3 + clinical_confidence * 0.7)
            
            gap['clinical_confidence'] = combined_confidence
            gap['bert_similarity'] = similarity
            gap['bert_analysis'] = analysis
            
            if combined_confidence > 0.4:  # Lower threshold for investigation
                validated.append(gap)
                logger.debug(f"ClinicalBERT validated: '{gap['text']}' (conf: {combined_confidence:.2f})")
        
        return validated
        
    except Exception as e:
        logger.error(f"ClinicalBERT validation failed: {e}")
        return _validate_gaps_basic(gaps)


def _validate_gaps_basic(gaps: List[Dict]) -> List[Dict]:
    """Basic validation without ClinicalBERT"""
    validated = []
    
    for gap in gaps:
        # Simple heuristics
        text = gap['text'].lower()
        confidence = gap.get('spacy_confidence', 0.5)
        
        # Boost confidence for obviously medical terms
        medical_suffixes = ['itis', 'osis', 'emia', 'uria', 'pathy', 'ology']
        if any(text.endswith(suffix) for suffix in medical_suffixes):
            confidence += 0.3
        
        # Boost for drug-like patterns
        if any(pattern in text for pattern in ['mg', 'mcg', 'daily', 'tablet']):
            confidence += 0.2
        
        gap['clinical_confidence'] = min(1.0, confidence)
        
        if confidence > 0.5:
            validated.append(gap)
    
    return validated


async def _enhance_with_terminology_service(gaps: List[Dict], terminology_service) -> List[Dict]:
    """Enhance gaps with terminology service lookups"""
    enhanced = []
    
    try:
        for gap in gaps:
            # Try to resolve via terminology service
            try:
                # This would use your terminology service search
                # Assuming it has a search method
                if hasattr(terminology_service, 'search_concepts'):
                    results = await terminology_service.search_concepts(gap['text'])
                    
                    if results:
                        best_match = results[0]  # Assuming ranked results
                        gap['cui'] = best_match.get('cui') or best_match.get('id')
                        gap['clinical_category'] = _map_tui_to_category(best_match.get('tuis', []))
                        gap['tuis'] = best_match.get('tuis', [])
                        gap['terminology_confidence'] = best_match.get('confidence', 0.8)
                        
                        # Boost overall confidence if terminology service found it
                        gap['clinical_confidence'] = min(1.0, gap.get('clinical_confidence', 0.5) + 0.2)
                        
                        logger.debug(f"Terminology enhanced: '{gap['text']}' -> {gap.get('cui')}")
                
                enhanced.append(gap)
                
            except Exception as e:
                logger.debug(f"Terminology lookup failed for '{gap['text']}': {e}")
                enhanced.append(gap)  # Keep it anyway
        
        return enhanced
        
    except Exception as e:
        logger.error(f"Terminology enhancement failed: {e}")
        return gaps


def _map_tui_to_category(tuis: List[str]) -> str:
    """Map TUIs to clinical categories"""
    if not tuis:
        return "UNKNOWN"
    
    # Use your existing TUI_TO_CATEGORY mapping
    for tui in tuis:
        category = rules.TUI_TO_CATEGORY.get(tui.upper())
        if category and category != "IGNORE":
            return category
    
    return "OBSERVATION"  # Default for unmapped clinical concepts

def filter_non_clinical_entities(entities: List[EnrichedEntity]) -> List[EnrichedEntity]:
    """
    Filter out non-clinical noise entities
    Production-grade filtering for clinical relevance
    """
    filtered = []
    
    for entity in entities:
        # Skip very short entities unless they're known clinical abbreviations
        known_short_terms = {"tsh", "cbc", "bp", "hr", "rr", "t3", "t4", "mi", "copd", "ecg", "ekg"}
        if len(entity.text.strip()) < 3 and entity.text.lower() not in known_short_terms:
            logger.debug(f"Filtered short entity: '{entity.text}'")
            continue
            
        # Skip common noise patterns
        noise_patterns = [
            r"^\d+\.\s*$",                              # Numbers with periods
            r"^(a|an|the|is|are|was|were|has|have|had)$",  # Articles/verbs
            r"^(and|or|but|with|for|to|of|in|on|at)$",     # Prepositions
            r"^(he|she|his|her|him|they|their)$",          # Pronouns
            r"^\d+\s*(years?|months?|days?|weeks?)$",       # Time periods
            r"^(today|yesterday|recently|currently)$",      # Temporal terms
        ]
        
        entity_text_lower = entity.text.lower().strip()
        if any(re.match(pattern, entity_text_lower) for pattern in noise_patterns):
            logger.debug(f"Filtered noise pattern: '{entity.text}'")
            continue
        
        # Skip entities marked as IGNORE unless they have clinical codes
        if (entity.backend_category == "IGNORE" and 
            not entity.primary_cui and 
            not entity.standard_codes):
            logger.debug(f"Filtered IGNORE entity: '{entity.text}'")
            continue
            
        # Skip UNKNOWN_CATEGORY with low confidence
        if (entity.backend_category == "UNKNOWN_CATEGORY" and 
            (entity.ner_confidence or 0) < 0.7):
            logger.debug(f"Filtered low-confidence unknown: '{entity.text}'")
            continue
        
        # Keep all clinical entities
        if entity.backend_category in [
            "CONDITION", "SYMPTOM", "DRUG", "PROCEDURE", "LAB_RESULT", 
            "VITAL_SIGN", "ANATOMY", "DEVICE", "OBSERVATION", "FINDING"
        ]:
            filtered.append(entity)
            logger.debug(f"Kept clinical entity: '{entity.text}' -> {entity.backend_category}")
        
        # Keep high-confidence measurements
        elif (entity.backend_category == "MEASUREMENT" and 
              (entity.ner_confidence or 0) > 0.8):
            filtered.append(entity)
            logger.debug(f"Kept high-confidence measurement: '{entity.text}'")
            
    logger.info(f"Entity filtering: {len(entities)} → {len(filtered)} entities")
    return filtered


def extract_compound_entities(entities: List[EnrichedEntity], original_text: str) -> List[EnrichedEntity]:
    """
    Extract meaningful clinical entities from compound phrases
    """
    enhanced_entities = []
    
    for entity in entities:
        # Check for compound medical phrases that should be decomposed
        compound_patterns = [
            # Pattern: "known history of [CONDITION]"
            (r"known history of (\w+(?:\s+\w+)*)", "CONDITION"),
            # Pattern: "has [CONDITION]"  
            (r"has (\w+(?:\s+\w+)*)", "CONDITION"),
            # Pattern: "takes [MEDICATION]"
            (r"takes (\w+(?:\s+\w+)*)", "DRUG"),
            # Pattern: "[DRUG] [DOSE] mg"
            (r"(\w+)\s+\d+\s*m?cg?", "DRUG"),
        ]
        
        entity_matched = False
        for pattern, category in compound_patterns:
            match = re.search(pattern, entity.text.lower())
            if match:
                extracted_term = match.group(1).strip()
                
                # Validate the extracted term is clinically meaningful
                if _is_clinical_term(extracted_term):
                    # Create new entity for the extracted clinical term
                    clinical_entity = EnrichedEntity(
                        text=extracted_term,
                        start_char=entity.start_char + match.start(1),
                        end_char=entity.start_char + match.end(1),
                        label=f"EXTRACTED_{category}",
                        source_ner_engine="compound_term_fallback",
                        ner_confidence=0.85,  # High confidence for pattern matches
                        backend_category=category,
                        section_title=entity.section_title,
                        audit_trail=[AuditTrailEntry(
                            source_service="compound_term_fallback",
                            details={
                                "original_entity": entity.text,
                                "extraction_pattern": pattern,
                                "extracted_term": extracted_term
                            }
                        )]
                    )
                    enhanced_entities.append(clinical_entity)
                    logger.info(f"Extracted compound: '{extracted_term}' from '{entity.text}'")
                    entity_matched = True
                    break
        
        # Keep original entity if no compound extraction happened
        if not entity_matched:
            enhanced_entities.append(entity)
    
    return enhanced_entities


def _is_clinical_term(term: str) -> bool:
    """Check if a term is clinically relevant"""
    clinical_keywords = {
        # Common conditions
        "diabetes", "hypertension", "hypothyroidism", "hyperthyroidism",
        "pneumonia", "asthma", "copd", "heart failure", "stroke",
        # Common medications  
        "metformin", "insulin", "lisinopril", "amlodipine", "levothyroxine",
        "atorvastatin", "metoprolol", "warfarin", "aspirin",
        # Symptoms
        "pain", "fatigue", "nausea", "dizziness", "fever", "cough"
    }
    
    term_lower = term.lower()
    
    # Direct match
    if term_lower in clinical_keywords:
        return True
    
    # Medical suffix patterns
    medical_suffixes = ["itis", "osis", "emia", "uria", "pathy", "ology", "scopy"]
    if any(term_lower.endswith(suffix) for suffix in medical_suffixes):
        return True
    
    # Drug suffix patterns
    drug_suffixes = ["statin", "pril", "olol", "pine", "mycin", "cillin"]
    if any(term_lower.endswith(suffix) for suffix in drug_suffixes):
        return True
    
    return len(term) >= 4  # Minimum length for clinical relevance

async def process_text_nlp_with_intelligent_fallback(text: str, terminology_service=None) -> Tuple[TypingOptional[SpacyDoc], List[NLPEntity]]:
    """Process text with intelligent fallback system"""
    if not NLP_SPACY:
        logger.error("NLP pipeline not initialized")
        return None, []
    
    try:
        # Step 1: Primary processing with MedCAT
        doc = NLP_SPACY(text)
        
        # Set ClinicalBERT control on the doc
        if hasattr(doc, '_'):
            doc._.disable_clinical_bert = not enable_clinical_bert
            doc._.request_clinical_bert_enabled = enable_clinical_bert
            logger.debug(f"Set ClinicalBERT control: enabled={enable_clinical_bert}")
        
        medcat_entities = _convert_spacy_entities(doc)
        
        logger.info(f"MedCAT found {len(medcat_entities)} entities")
        
        # Step 2: Intelligent fallback
        fallback_entities = await get_intelligent_fallback_entities(
            text, medcat_entities, terminology_service
        )
        
        # Step 3: Combine and deduplicate
        all_entities = medcat_entities + fallback_entities
        deduplicated_entities = _deduplicate_entities(all_entities)
        
        logger.info(f"Total entities: {len(deduplicated_entities)} (MedCAT: {len(medcat_entities)}, Fallback: {len(fallback_entities)})")
        
        return doc, deduplicated_entities
        
    except Exception as e:
        logger.error(f"Error in enhanced NLP pipeline: {e}", exc_info=True)
        return None, []


def _deduplicate_entities(entities: List[NLPEntity]) -> List[NLPEntity]:
    """Remove duplicate entities based on span overlap"""
    if not entities:
        return []
    
    # Sort by start position
    sorted_entities = sorted(entities, key=lambda e: (e.start_char, -e.end_char))
    deduplicated = []
    
    for entity in sorted_entities:
        # Check if this entity overlaps with any already added
        overlaps = any(
            _spans_overlap(entity.start_char, entity.end_char, existing.start_char, existing.end_char)
            for existing in deduplicated
        )
        
        if not overlaps:
            deduplicated.append(entity)
        else:
            # Keep the one with higher confidence
            overlapping = [e for e in deduplicated if _spans_overlap(entity.start_char, entity.end_char, e.start_char, e.end_char)]
            if overlapping:
                existing = overlapping[0]
                if entity.ner_confidence and existing.ner_confidence and entity.ner_confidence > existing.ner_confidence:
                    deduplicated.remove(existing)
                    deduplicated.append(entity)
    
    return sorted(deduplicated, key=lambda e: e.start_char)

def _validate_gaps_with_smart_confidence(text: str, gaps: List[Dict]) -> List[Dict]:
    """DEPRECATED: Use _validate_clinical_gaps instead"""
    return _validate_clinical_gaps(text, gaps)

async def enhance_fallback_with_terminology(fallback_entities: List[NLPEntity], terminology_service=None) -> List[NLPEntity]:
    """Enhance fallback entities with terminology lookups"""
    if not terminology_service:
        return fallback_entities
    
    enhanced = []
    for entity in fallback_entities:
        try:
            # Search for the entity in terminology service
            if hasattr(terminology_service, 'search_concepts'):
                results = await terminology_service.search_concepts(entity.text)
                if results and len(results) > 0:
                    best_match = results[0]
                    
                    # Update entity with terminology info
                    entity.primary_cui = best_match.get('cui') or best_match.get('id')
                    
                    # You might need to adapt this based on your terminology service response format
                    if hasattr(best_match, 'tuis'):
                        entity.type_ids = best_match.tuis
                    
                    logger.info(f"✅ Enhanced fallback entity '{entity.text}' with CUI: {entity.primary_cui}")
            
            enhanced.append(entity)
            
        except Exception as e:
            logger.debug(f"Terminology enhancement failed for '{entity.text}': {e}")
            enhanced.append(entity)  # Keep original
    
    return enhanced

def enhance_fallback_with_terminology_sync(fallback_entities: List[NLPEntity]) -> List[NLPEntity]:
    """
    Synchronous version - uses basic CUI lookup without terminology service
    For now, we'll add basic CUI assignment for known drugs
    """
    enhanced = []
    
    # Basic CUI mapping for common drugs (expandable)
    known_drug_cuis = {
        'levothyroxine': 'C0040165',  # From your CDB debug
        'amlodipine': 'C0051696',
        'metformin': 'C0025598',
        'lisinopril': 'C0065374',
        'atorvastatin': 'C0286651',
        'metoprolol': 'C0025859',
        'insulin': 'C0021641',
        'simvastatin': 'C0074554',
        'omeprazole': 'C0028978',
        'hydrochlorothiazide': 'C0020261',
        'furosemide': 'C0016860',
        'warfarin': 'C0043031',
        'digoxin': 'C0012265',
        'prednisone': 'C0032952',
        'azithromycin': 'C0052796'
    }
    
    # Basic condition CUIs
    known_condition_cuis = {
        'hypothyroidism': 'C0020676',
        'hypertension': 'C0020538', 
        'diabetes': 'C0011847',
        'hyperlipidemia': 'C0020473',
        'pneumonia': 'C0032285',
        'bronchitis': 'C0006277',
        'asthma': 'C0004096',
        'copd': 'C0024117'
    }
    
    for entity in fallback_entities:
        try:
            entity_lower = entity.text.lower()
            clinical_category = get_entity_clinical_category(entity)
            # Check for drug matches
            if entity_lower in known_drug_cuis:
                entity.primary_cui = known_drug_cuis[entity_lower]
                logger.info(f"✅ Enhanced drug '{entity.text}' with CUI: {entity.primary_cui}")
                
                # Add basic type info for drugs
                if clinical_category == "DRUG":
                    entity.type_ids = ["T121"]  # Pharmacologic Substance
                    entity.type_names = ["Pharmacologic Substance"]
            
            # Check for condition matches
            elif entity_lower in known_condition_cuis:
                entity.primary_cui = known_condition_cuis[entity_lower]
                logger.info(f"✅ Enhanced condition '{entity.text}' with CUI: {entity.primary_cui}")
                
                # Add basic type info for conditions
                if clinical_category == "CONDITION":
                    entity.type_ids = ["T047"]  # Disease or Syndrome
                    entity.type_names = ["Disease or Syndrome"]
            
            # Check for partial matches (drug suffixes)
            else:
                drug_suffixes = {
                    'statin': ('C0360714', 'T121'),  # Generic statin
                    'pril': ('C0003015', 'T121'),    # ACE inhibitor
                    'olol': ('C0001645', 'T121'),    # Beta blocker
                    'pine': ('C0006684', 'T121')     # Calcium channel blocker
                }
                
                for suffix, (cui, tui) in drug_suffixes.items():
                    if entity_lower.endswith(suffix) and len(entity.text) > len(suffix):
                        entity.primary_cui = cui
                        entity.type_ids = [tui]
                        entity.type_names = ["Pharmacologic Substance"]
                        logger.info(f"✅ Enhanced '{entity.text}' with suffix pattern CUI: {cui}")
                        break
            
            enhanced.append(entity)
            
        except Exception as e:
            logger.debug(f"Basic enhancement failed for '{entity.text}': {e}")
            enhanced.append(entity)  # Keep original
    
    return enhanced

async def process_text_nlp(
    text: str, 
    enable_intelligent_fallback: bool = None,
    enable_clinical_bert: bool = None
) -> Tuple[TypingOptional[SpacyDoc], List[NLPEntity]]:
    """
    FIXED: Enhanced process text through the NLP pipeline with parameter control
    """
    if not NLP_SPACY:
        logger.error("NLP pipeline not initialized")
        return None, []

    if len(text) > app_config.MAX_TEXT_LENGTH:
        logger.warning(f"Text length ({len(text)}) exceeds maximum ({app_config.MAX_TEXT_LENGTH}), truncating")
        text = text[:app_config.MAX_TEXT_LENGTH]

    # FIXED: Handle parameter defaults properly
    if enable_intelligent_fallback is None:
        enable_intelligent_fallback = True  # Default behavior
    if enable_clinical_bert is None:
        enable_clinical_bert = app_config.ENABLE_CLINICAL_BERT  # Use config default

    logger.info(f"🔧 Processing with parameters: ClinicalBERT={enable_clinical_bert}, Fallback={enable_intelligent_fallback}")

    try:
        # FIXED: Set thread-local ClinicalBERT control BEFORE running pipeline
        set_clinical_bert_enabled(enable_clinical_bert)
        
        # Step 1: FIXED - Conditional pipeline processing
        if enable_clinical_bert:
            # Run full pipeline including ClinicalBERT
            logger.debug("🤖 Running full pipeline with ClinicalBERT")
            doc = NLP_SPACY(text)
        else:
            # Run pipeline WITHOUT ClinicalBERT component
            logger.debug("⏭️ Running pipeline WITHOUT ClinicalBERT")
            doc = _process_without_clinical_bert(text)
        
        # Set ClinicalBERT control on the doc (for backward compatibility)
        if hasattr(doc, '_'):
            doc._.disable_clinical_bert = not enable_clinical_bert
            doc._.request_clinical_bert_enabled = enable_clinical_bert
            logger.debug(f"Set ClinicalBERT control: enabled={enable_clinical_bert}")
        
        medcat_entities = _convert_spacy_entities(doc)
        
        logger.info(f"Primary NLP found {len(medcat_entities)} entities")
        
        # Step 2: FIXED - Intelligent fallback (only if enabled)
        fallback_entities = []
        if enable_intelligent_fallback:
            try:
                logger.info("🔄 Running intelligent fallback (enabled)")
                fallback_entities = await get_intelligent_fallback_entities_async(
                    text, 
                    medcat_entities,
                    enable_clinical_bert=enable_clinical_bert,
                    timeout=app_config.FALLBACK_TIMEOUT_SECONDS
                )
                logger.info(f"Intelligent fallback found {len(fallback_entities)} additional entities")
            except Exception as e:
                logger.error(f"Fallback failed: {e}")
                fallback_entities = []
        else:
            logger.info("⏭️ Intelligent fallback disabled for this request")
        
        # Step 3: Enhanced fallback entities with terminology (existing)
        if fallback_entities:
            try:
                enhanced_fallback = enhance_fallback_with_terminology_sync(fallback_entities)
                logger.info(f"Enhanced {len(enhanced_fallback)} fallback entities with terminology")
                fallback_entities = enhanced_fallback
            except Exception as e:
                logger.error(f"Terminology enhancement failed: {e}")
        
        # Step 4: Combine entities
        all_entities = medcat_entities + fallback_entities
        
        # Step 5: FIXED - ClinicalBERT-based consolidation (only if enabled)
        consolidated_entities = all_entities
        if enable_clinical_bert and CLINICAL_BERT and CLINICAL_BERT.is_available():
            try:
                logger.info("🤖 Starting ClinicalBERT-based entity consolidation...")
                consolidated_entities = await consolidate_entities_with_clinicalbert_async(all_entities, text)
                logger.info(f"ClinicalBERT consolidation: {len(all_entities)} → {len(consolidated_entities)} entities")
            except Exception as e:
                logger.error(f"ClinicalBERT consolidation failed: {e}")
                consolidated_entities = all_entities
        else:
            logger.info("⏭️ ClinicalBERT consolidation disabled for this request")
        
        # Step 6: Final deduplication (existing)
        deduplicated_entities = _deduplicate_entities(consolidated_entities)
        
        logger.info(f"Final: {len(deduplicated_entities)} entities (before filtering)")
        return doc, deduplicated_entities
        
    except Exception as e:
        logger.error(f"Error in enhanced NLP pipeline: {e}", exc_info=True)
        return None, []
    
def get_intelligent_fallback_entities_sync(
    text: str, 
    medcat_entities: List[NLPEntity],
    enable_clinical_bert: bool = True
) -> List[NLPEntity]:
    """
    Synchronous version of intelligent fallback for worker processes
    """
    if not NLP_SPACY:
        return []
    
    logger.info(f"Starting synchronous intelligent fallback detection... (ClinicalBERT: {enable_clinical_bert})")
    fallback_entities = []
    
    try:
        # Use separate spaCy instance to avoid threading issues
        import spacy
        try:
            fallback_nlp = spacy.load(app_config.SPACY_MODEL)
        except:
            logger.warning("Could not load separate spaCy for fallback, using main pipeline")
            fallback_nlp = NLP_SPACY
        
        doc = fallback_nlp(text)
        spacy_entities = []
        
        for ent in doc.ents:
            if _is_potentially_clinical(ent.label_, ent.text):
                spacy_entities.append({
                    'text': ent.text,
                    'start': ent.start_char,
                    'end': ent.end_char,
                    'label': ent.label_,
                    'spacy_confidence': _get_spacy_confidence(ent)
                })
        
        # Find gaps
        medcat_spans = [(e.start_char, e.end_char, e.text.lower()) for e in medcat_entities]
        
        potential_gaps = []
        for spacy_ent in spacy_entities:
            is_covered = any(
                _spans_overlap(spacy_ent['start'], spacy_ent['end'], mc_start, mc_end)
                for mc_start, mc_end, _ in medcat_spans
            )
            
            if not is_covered:
                potential_gaps.append(spacy_ent)
        
        if not potential_gaps:
            return []
        
        logger.info(f"Found {len(potential_gaps)} potential gaps")
        
        # Validate gaps (synchronous version)
        validated_gaps = _validate_clinical_gaps_sync(text, potential_gaps, enable_clinical_bert)
        
        # Convert to NLPEntity objects
        for gap in validated_gaps:
            if gap.get('clinical_confidence', 0) > 0.6:
                fallback_entity = NLPEntity(
                    text=gap['text'],
                    start_char=gap['start'],
                    end_char=gap['end'],
                    label=gap.get('clinical_category', gap['label']),
                    source_ner_engine="spacy_ner",
                    ner_confidence=gap.get('clinical_confidence', 0.7),
                    primary_cui=gap.get('cui'),
                    type_ids=gap.get('tuis', []),
                    section_title="intelligent_fallback"
                )
                
                fallback_entities.append(fallback_entity)
                logger.info(f"Fallback entity: '{gap['text']}' -> {gap.get('clinical_category', 'UNKNOWN')}")
        
        return fallback_entities
        
    except Exception as e:
        logger.error(f"Synchronous intelligent fallback failed: {e}")
        return []

def _validate_clinical_gaps_sync(text: str, gaps: List[Dict], enable_clinical_bert: bool = True) -> List[Dict]:
    """Synchronous version of clinical gap validation"""
    validated = []
    
    try:
        for gap in gaps:
            gap_text = gap['text']
            gap_text_lower = gap_text.lower()
            
            # Initialize confidence score
            confidence = 0.0
            
            # 1. Drug Pattern Recognition
            drug_confidence = _get_drug_pattern_confidence(gap_text)
            if drug_confidence > 0:
                confidence = max(confidence, drug_confidence)
            
            # 2. Clinical Pattern Recognition
            clinical_confidence = _get_clinical_pattern_confidence(gap_text)
            if clinical_confidence > 0:
                confidence = max(confidence, clinical_confidence * 0.9)
            
            # 3. ClinicalBERT validation (synchronous version)
            if enable_clinical_bert and CLINICAL_BERT and CLINICAL_BERT.is_available():
                try:
                    logger.debug(f"🤖 Running synchronous ClinicalBERT validation for '{gap_text}'")
                    similarity = CLINICAL_BERT.get_similarity(gap_text, text)
                    analysis = CLINICAL_BERT.analyze_text(gap_text)
                    bert_confidence = analysis.get('clinical_confidence', 0.5)
                    
                    # Combine similarity and clinical confidence
                    combined_bert = (similarity * 0.3 + bert_confidence * 0.7)
                    confidence = max(confidence, combined_bert * 0.8)
                    
                    logger.debug(f"ClinicalBERT result for '{gap_text}': sim={similarity:.3f}, clinical={bert_confidence:.3f}")
                    
                except Exception as e:
                    logger.debug(f"ClinicalBERT validation failed for '{gap_text}': {e}")
            
            # 4. Basic heuristics
            if 3 <= len(gap_text) <= 15:
                confidence += 0.1
            elif len(gap_text) < 3:
                confidence -= 0.2
            
            # Medical context boost
            medical_context_words = ['patient', 'takes', 'prescribed', 'medication', 'mg', 'mcg', 'daily', 'symptoms']
            if any(word in text.lower() for word in medical_context_words):
                confidence += 0.1
            
            # Set final confidence and threshold
            gap['clinical_confidence'] = min(1.0, max(0.0, confidence))
            
            # Adaptive threshold
            threshold = 0.3 if drug_confidence > 0.8 else 0.5
            
            if gap['clinical_confidence'] > threshold:
                validated.append(gap)
                logger.info(f"Validated: '{gap_text}' (conf: {gap['clinical_confidence']:.3f})")
        
        return validated
        
    except Exception as e:
        logger.error(f"Synchronous clinical gap validation failed: {e}")
        return []

# Thread-local storage for ClinicalBERT control
_thread_local = threading.local()

def set_clinical_bert_enabled(enabled: bool):
    """Set ClinicalBERT enabled state for current thread"""
    _thread_local.clinical_bert_enabled = enabled

def get_clinical_bert_enabled() -> bool:
    """Get ClinicalBERT enabled state for current thread"""
    return getattr(_thread_local, 'clinical_bert_enabled', True)

def _process_without_clinical_bert(text: str) -> SpacyDoc:
    """
    Process text through spaCy pipeline excluding ClinicalBERT component
    Creates a temporary pipeline without the clinical_bert component
    """
    global NLP_SPACY
    
    if not NLP_SPACY:
        raise RuntimeError("NLP pipeline not initialized")
    
    try:
        # Check if clinical_bert component exists in pipeline
        if "clinical_bert" in NLP_SPACY.pipe_names:
            logger.debug("Creating temporary pipeline without ClinicalBERT")
            
            # Get all pipe names except clinical_bert
            pipe_names_without_bert = [name for name in NLP_SPACY.pipe_names if name != "clinical_bert"]
            
            # Process with only the non-ClinicalBERT components
            doc = NLP_SPACY.make_doc(text)
            
            # Run each component except clinical_bert
            for pipe_name in pipe_names_without_bert:
                pipe = NLP_SPACY.get_pipe(pipe_name)
                doc = pipe(doc)
            
            logger.debug(f"Processed without ClinicalBERT using pipes: {pipe_names_without_bert}")
            return doc
        else:
            # No ClinicalBERT component, run normally
            logger.debug("No ClinicalBERT component found, running normal pipeline")
            return NLP_SPACY(text)
            
    except Exception as e:
        logger.error(f"Error processing without ClinicalBERT: {e}")
        # Fallback to normal processing
        logger.warning("Falling back to normal pipeline processing")
        return NLP_SPACY(text)

def extract_context_from_doc(doc: SpacyDoc) -> Dict[str, Dict]:
    """
    Extract all context modifiers detected by spaCy/MedSpaCy
    Returns a mapping of entity spans to their context information
    """
    context_map = {}
    
    try:
        for ent in doc.ents:
            if hasattr(ent._, 'modifiers') and ent._.modifiers:
                span_key = f"{ent.start_char}-{ent.end_char}"
                modifiers_info = []
                
                for modifier in ent._.modifiers:
                    modifiers_info.append({
                        'category': modifier.category,
                        'trigger_text': modifier.text if hasattr(modifier, 'text') else '',
                        'trigger_span': (modifier.start_char, modifier.end_char) if hasattr(modifier, 'start_char') else None
                    })
                
                context_map[span_key] = {
                    'entity_span': (ent.start_char, ent.end_char),
                    'entity_text': ent.text,
                    'modifiers': modifiers_info
                }
        
        logger.debug(f"Extracted context for {len(context_map)} spans from spaCy doc")
        return context_map
        
    except Exception as e:
        logger.warning(f"Error extracting context from doc: {e}")
        return {}


def find_overlapping_context(entity: NLPEntity, context_map: Dict[str, Dict]) -> TypingOptional[Dict]:
    """
    Find any context that overlaps with or contains the entity
    """
    entity_start, entity_end = entity.start_char, entity.end_char
    
    for span_key, context_info in context_map.items():
        context_start, context_end = context_info['entity_span']
        
        # Check for overlap or containment
        if (_spans_overlap(entity_start, entity_end, context_start, context_end) or
            (context_start <= entity_start and entity_end <= context_end)):
            return context_info
    
    return None


def apply_entity_internal_context(entity: NLPEntity) -> NLPEntity:
    """
    Apply context detection using existing rules on entity text itself
    ENHANCED: With detailed debugging
    """
    entity_text = entity.text.lower()
    
    try:
        # Import your existing rules
        from .rules import CONTEXT_RULES_LIST
        
        logger.debug(f"🔍 Checking internal context for entity: '{entity.text}' at {entity.start_char}-{entity.end_char}")
        
        for i, rule in enumerate(CONTEXT_RULES_LIST):
            context_detected = False
            rule_info = f"Rule {i}: '{rule.literal}' -> {rule.category}"
            
            # Check literal patterns
            if hasattr(rule, 'literal') and rule.literal:
                if rule.literal.lower() in entity_text:
                    context_detected = True
                    logger.debug(f"🎯 {rule_info} MATCHED in '{entity.text}'")
            
            # Check regex patterns
            elif hasattr(rule, 'pattern') and rule.pattern:
                try:
                    if re.search(rule.pattern, entity_text, re.IGNORECASE):
                        context_detected = True
                        logger.debug(f"🎯 {rule_info} PATTERN MATCHED in '{entity.text}'")
                except Exception as pattern_error:
                    logger.debug(f"Pattern matching error: {pattern_error}")
                    continue
            
            # Apply the detected context
            if context_detected:
                logger.warning(f"🚨 APPLYING CONTEXT: {rule_info} to '{entity.text}'")
                entity = apply_context_category_to_entity(entity, rule.category)
        
        return entity
        
    except Exception as e:
        logger.warning(f"Error applying entity internal context: {e}")
        return entity


def apply_context_category_to_entity(entity: NLPEntity, category: str) -> NLPEntity:
    """
    Apply context category to entity
    ENHANCED: With detailed step tracking
    """
    try:
        category_upper = category.upper()
        
        logger.debug(f"🔧 Applying category '{category}' to entity '{entity.text}'")
        
        if "NEGAT" in category_upper:
            logger.error(f"🚨 NEGATION DETECTED for '{entity.text}' - triggered by category: {category}")
            
            # CRITICAL: Log the full context to understand why this is happening
            logger.error(f"🔍 NEGATION CONTEXT DEBUG:")
            logger.error(f"   Entity: '{entity.text}' ({entity.start_char}-{entity.end_char})")
            logger.error(f"   Category: {category}")
            logger.error(f"   Source Engine: {entity.source_ner_engine}")
            logger.error(f"   Section: {entity.section_title}")
            
            entity.negated = True
            logger.debug(f"Applied NEGATION to '{entity.text}'")
            
        elif "HISTORICAL" in category_upper:
            entity.historical = True
            logger.debug(f"Applied HISTORICAL to '{entity.text}'")
        elif "HYPOTHETICAL" in category_upper:
            entity.hypothetical = True
            logger.debug(f"Applied HYPOTHETICAL to '{entity.text}'")
        elif "FAMILY" in category_upper:
            entity.family_history = True
            logger.debug(f"Applied FAMILY_HISTORY to '{entity.text}'")
        elif "SOCIAL" in category_upper:
            entity.social_history = True
            logger.debug(f"Applied SOCIAL_HISTORY to '{entity.text}'")
        elif "TERMINATE" in category_upper:
            logger.debug(f"🛑 TERMINATE rule applied to '{entity.text}' - should stop context propagation")
    
    except Exception as e:
        logger.warning(f"Error applying context category {category}: {e}")
    
    return entity


def apply_enhanced_context_detection(entity: NLPEntity, doc: SpacyDoc, spacy_ent, context_map: Dict[str, Dict]) -> NLPEntity:
    """
    Main hybrid context detection function
    FIXED: Override broken MedSpaCy negation
    """
    logger.debug(f"🔍 Enhanced context detection for '{entity.text}' at {entity.start_char}-{entity.end_char}")
    
    try:
        # Get the document text to check for positive context
        doc_text = doc.text.lower()
        entity_start = entity.start_char
        
        # Check for positive assertion context (within 50 chars before entity)
        context_window = doc_text[max(0, entity_start-50):entity_start+50]
        positive_indicators = ["reports", "states", "complains", "presents", "has", "shows", "demonstrates"]
        has_positive_context = any(indicator in context_window for indicator in positive_indicators)
        
        # EMERGENCY OVERRIDE: If positive context detected, skip MedSpaCy modifiers
        if has_positive_context:
            logger.warning(f"⚡ OVERRIDE: Skipping MedSpaCy negation for '{entity.text}' due to positive context: {[ind for ind in positive_indicators if ind in context_window]}")
            
            # Skip Method 1 (spaCy modifiers) completely
            pass
        else:
            # Method 1: Use existing spaCy modifiers (only if no positive context)
            if hasattr(spacy_ent, '_') and hasattr(spacy_ent._, 'modifiers') and spacy_ent._.modifiers:
                logger.debug(f"📋 spaCy found {len(spacy_ent._.modifiers)} modifiers for '{entity.text}'")
                for modifier in spacy_ent._.modifiers:
                    if hasattr(modifier, 'category'):
                        logger.warning(f"🎯 spaCy modifier: '{modifier.category}' for '{entity.text}'")
                        entity = apply_context_category_to_entity(entity, modifier.category)
        
        # Method 2: Check for overlapping context (only if no positive context)
        if not has_positive_context:
            overlapping_context = find_overlapping_context(entity, context_map)
            if overlapping_context:
                logger.debug(f"📋 Found {len(overlapping_context['modifiers'])} overlapping contexts for '{entity.text}'")
                for modifier_info in overlapping_context['modifiers']:
                    logger.warning(f"🎯 Overlapping context: '{modifier_info['category']}' for '{entity.text}'")
                    entity = apply_context_category_to_entity(entity, modifier_info['category'])
        
        # Method 3: Apply entity-internal context using your existing rules
        logger.debug(f"📋 Checking internal context rules for '{entity.text}'")
        entity = apply_entity_internal_context(entity)
        
        logger.debug(f"✅ Final context for '{entity.text}': negated={entity.negated}, historical={entity.historical}")
        return entity
        
    except Exception as e:
        logger.warning(f"Error in enhanced context detection for '{entity.text}': {e}")
        return entity

async def consolidate_entities_with_clinicalbert_async(
    entities: List[NLPEntity], 
    text: str
) -> List[NLPEntity]:
    """
    FIXED: Use ClinicalBERT to dynamically identify clinically meaningful entity combinations
    Only called when ClinicalBERT is enabled
    """
    global CLINICAL_BERT
    
    if not CLINICAL_BERT or not CLINICAL_BERT.is_available():
        logger.warning("ClinicalBERT not available for entity consolidation")
        return entities
    
    logger.info("🤖 ClinicalBERT consolidation running...")
    consolidated = []
    entities_by_position = sorted(entities, key=lambda e: e.start_char)
    skip_indices = set()
    
    for i, entity in enumerate(entities_by_position):
        if i in skip_indices:
            continue
        
        # Look for nearby entities that might form better clinical concepts
        nearby_entities = []
        for j in range(i+1, min(i+4, len(entities_by_position))):
            next_entity = entities_by_position[j]
            # Only consider entities within 50 characters
            if next_entity.start_char - entity.end_char <= 50:
                nearby_entities.append((j, next_entity))
            else:
                break
        
        if nearby_entities:
            best_combination = await find_best_clinical_combination_async(
                entity, nearby_entities, text, CLINICAL_BERT
            )
            
            if best_combination:
                consolidated.append(best_combination['entity'])
                skip_indices.update(best_combination['consumed_indices'])
                logger.info(f"Consolidated: '{entity.text}' → '{best_combination['entity'].text}'")
                continue
        
        # No good combination found, keep original entity
        consolidated.append(entity)
    
    logger.info(f"Consolidation: {len(entities)} → {len(consolidated)} entities")
    return consolidated


async def find_best_clinical_combination_async(
    base_entity: NLPEntity,
    nearby_entities: List[Tuple[int, NLPEntity]], 
    text: str,
    clinical_bert
    ) -> TypingOptional[Dict]:
    """
    Use ClinicalBERT to evaluate if combining entities creates better clinical meaning
    """
    
    base_text = base_entity.text
    base_embedding = await clinical_bert.get_embeddings_async(base_text)
    
    if base_embedding is None:
        return None
    
    best_combination = None
    best_score = 0.6  # Minimum threshold for improvement
    
    # Try combining with 1-2 subsequent entities (most common clinical patterns)
    for combo_size in range(1, min(3, len(nearby_entities) + 1)):
        # Try all combinations of nearby entities
        for combination in itertools.combinations(nearby_entities, combo_size):
            
            entity_indices = [idx for idx, _ in combination]
            entities = [ent for _, ent in combination]
            
            # Check if entities are reasonably adjacent
            if not are_entities_adjacent(base_entity, entities):
                continue
            
            # Create combined text span  
            combined_span = get_combined_span(base_entity, entities, text)
            combined_embedding = await clinical_bert.get_embeddings_async(combined_span['text'])
            
            if combined_embedding is None:
                continue
            
            # Score the clinical coherence
            coherence_score = await calculate_clinical_coherence_async(
                base_embedding, combined_embedding, combined_span['text'], clinical_bert
            )
            
            if coherence_score > best_score:
                best_combination = {
                    'entity': create_combined_entity_from_span(combined_span, base_entity, entities),
                    'consumed_indices': entity_indices,
                    'score': coherence_score
                }
                best_score = coherence_score
    
    return best_combination


def are_entities_adjacent(base_entity: NLPEntity, other_entities: List[NLPEntity]) -> bool:
    """
    Check if entities are adjacent enough to be considered for combination
    """
    all_entities = [base_entity] + other_entities
    all_entities.sort(key=lambda e: e.start_char)
    
    # Check gaps between consecutive entities
    for i in range(len(all_entities) - 1):
        gap = all_entities[i+1].start_char - all_entities[i].end_char
        if gap > 10:  # More than 10 characters apart
            return False
    
    return True


def get_combined_span(base_entity: NLPEntity, other_entities: List[NLPEntity], text: str) -> Dict:
    """
    Get the combined text span covering all entities
    """
    all_entities = [base_entity] + other_entities
    
    min_start = min(e.start_char for e in all_entities)
    max_end = max(e.end_char for e in all_entities)
    
    combined_text = text[min_start:max_end].strip()
    
    return {
        'text': combined_text,
        'start_char': min_start,
        'end_char': max_end,
        'source_entities': all_entities
    }


def create_combined_entity_from_span(
    combined_span: Dict, 
    base_entity: NLPEntity, 
    other_entities: List[NLPEntity]
) -> NLPEntity:
    """
    Create a new NLPEntity from the combined span
    FIXED: Don't add audit_trail to NLPEntity (only EnrichedEntity has it)
    """
    
    # Use base entity as template, update with combined information
    combined_entity = NLPEntity(
        text=combined_span['text'],
        start_char=combined_span['start_char'],
        end_char=combined_span['end_char'],
        label=f"Combined: {base_entity.label}",
        source_ner_engine="clinicalbert_consolidation",
        ner_confidence=max(
            base_entity.ner_confidence or 0,
            max((e.ner_confidence or 0 for e in other_entities), default=0)
        ),
        section_title=base_entity.section_title,
        primary_cui=base_entity.primary_cui,  # Keep base entity's CUI for now
        type_ids=base_entity.type_ids,
        type_names=base_entity.type_names,
        # Add consolidation info to metadata instead of audit_trail
        metadata={
            "consolidation_source": "clinicalbert",
            "base_entity_text": base_entity.text,
            "combined_entities": [e.text for e in other_entities],
            "consolidation_method": "clinicalbert_coherence"
        }
    )
    
    # Don't add audit_trail here - that's only for EnrichedEntity
    return combined_entity


async def calculate_clinical_coherence_async(
    base_embedding: np.ndarray,
    combined_embedding: np.ndarray, 
    combined_text: str,
    clinical_bert
) -> float:
    """
    Calculate if the combined entity is more clinically coherent
    Uses multiple ClinicalBERT-based signals
    """
    
    try:
        # Signal 1: Embedding similarity (should be high for coherent medical concepts)
        # Reshape embeddings for sklearn cosine_similarity
        base_emb_2d = base_embedding.reshape(1, -1)
        combined_emb_2d = combined_embedding.reshape(1, -1)
        similarity = cosine_similarity(base_emb_2d, combined_emb_2d)[0][0]
        
        # Signal 2: Clinical context analysis
        clinical_analysis = clinical_bert.analyze_text(combined_text)
        clinical_confidence = clinical_analysis.get('clinical_confidence', 0)
        
        # Signal 3: Compare with medical phrase patterns
        medical_phrase_score = await compare_with_medical_patterns_async(combined_text, clinical_bert)
        
        # Signal 4: Length and complexity bonus for meaningful combinations
        complexity_bonus = calculate_complexity_bonus(combined_text)
        
        # Weighted combination
        coherence_score = (
            similarity * 0.25 + 
            clinical_confidence * 0.35 + 
            medical_phrase_score * 0.25 +
            complexity_bonus * 0.15
        )
        
        logger.debug(f"Coherence for '{combined_text}': sim={similarity:.3f}, clinical={clinical_confidence:.3f}, medical={medical_phrase_score:.3f}, complexity={complexity_bonus:.3f} → {coherence_score:.3f}")
        
        return coherence_score
        
    except Exception as e:
        logger.warning(f"Error calculating clinical coherence: {e}")
        return 0.0


async def compare_with_medical_patterns_async(text: str, clinical_bert) -> float:
    """
    Compare text against common medical phrase patterns using ClinicalBERT
    Dynamic learning from medical language patterns
    """
    
    try:
        # Get embedding for the text
        text_embedding = await clinical_bert.get_embeddings_async(text)
        if text_embedding is None:
            return 0.0
        
        # Sample of common medical phrase patterns
        # These could be expanded or loaded from medical corpora
        medical_reference_phrases = [
            "chest pain", "shortness of breath", "weight gain", "weight loss",
            "blood pressure", "heart rate", "diabetes mellitus", "thyroid function", 
            "kidney function", "liver function", "muscle pain", "joint pain",
            "abdominal pain", "back pain", "chronic fatigue", "acute onset",
            "free t4", "free t3", "blood sugar", "blood glucose"
        ]
        
        max_similarity = 0.0
        text_embedding_2d = text_embedding.reshape(1, -1)
        
        for phrase in medical_reference_phrases:
            phrase_embedding = await clinical_bert.get_embeddings_async(phrase)
            if phrase_embedding is not None:
                phrase_embedding_2d = phrase_embedding.reshape(1, -1)
                sim = cosine_similarity(text_embedding_2d, phrase_embedding_2d)[0][0]
                max_similarity = max(max_similarity, sim)
        
        return max_similarity
        
    except Exception as e:
        logger.debug(f"Error comparing with medical patterns: {e}")
        return 0.0


def calculate_complexity_bonus(text: str) -> float:
    """
    Calculate bonus for clinically meaningful complexity
    """
    
    words = text.split()
    
    # Bonus for 2-3 word medical terms (most common clinical concepts)
    if 2 <= len(words) <= 3:
        length_bonus = 0.8
    elif len(words) == 4:
        length_bonus = 0.6
    else:
        length_bonus = 0.2
    
    # Bonus for medical morphology
    medical_morphology_bonus = 0.0
    medical_indicators = [
        'itis', 'osis', 'emia', 'uria', 'pathy', 'ology', 'scopy', 'tomy',
        'free', 'total', 'serum', 'blood', 'acute', 'chronic'
    ]
    
    text_lower = text.lower()
    for indicator in medical_indicators:
        if indicator in text_lower:
            medical_morphology_bonus = 0.7
            break
    
    return max(length_bonus, medical_morphology_bonus)

def _get_drug_pattern_confidence(text: str) -> float:
    """
    Calculate confidence that text represents a drug/medication
    """
    text_lower = text.lower()
    confidence = 0.0
    
    # Common drug suffixes
    drug_suffixes = ['statin', 'pril', 'olol', 'pine', 'mycin', 'cillin', 'zole', 'ide']
    for suffix in drug_suffixes:
        if text_lower.endswith(suffix):
            confidence = max(confidence, 0.9)
            break
    
    # Common drug prefixes
    drug_prefixes = ['hydro', 'chloro', 'metro', 'amlodi', 'lisino', 'atorva']
    for prefix in drug_prefixes:
        if text_lower.startswith(prefix):
            confidence = max(confidence, 0.8)
            break
    
    # Exact drug matches
    known_drugs = {
        'levothyroxine', 'amlodipine', 'metformin', 'lisinopril', 'atorvastatin',
        'metoprolol', 'insulin', 'warfarin', 'aspirin', 'omeprazole', 'furosemide'
    }
    if text_lower in known_drugs:
        confidence = 0.95
    
    # Drug-like patterns
    if any(pattern in text_lower for pattern in ['mg', 'mcg', 'tablet', 'capsule']):
        confidence = max(confidence, 0.7)
    
    return confidence


def _get_clinical_pattern_confidence(text: str) -> float:
    """
    Calculate confidence that text represents a clinical concept
    """
    text_lower = text.lower()
    confidence = 0.0
    
    # Medical condition suffixes
    condition_suffixes = ['itis', 'osis', 'emia', 'uria', 'pathy', 'ology']
    for suffix in condition_suffixes:
        if text_lower.endswith(suffix):
            confidence = max(confidence, 0.8)
            break
    
    # Common conditions
    known_conditions = {
        'diabetes', 'hypertension', 'hypothyroidism', 'hyperthyroidism',
        'pneumonia', 'bronchitis', 'asthma', 'copd', 'stroke', 'angina'
    }
    if text_lower in known_conditions:
        confidence = 0.9
    
    # Symptom patterns
    symptom_words = ['pain', 'ache', 'fever', 'nausea', 'fatigue', 'weakness', 'dizziness']
    if any(word in text_lower for word in symptom_words):
        confidence = max(confidence, 0.7)
    
    # Lab/vital patterns
    lab_patterns = ['level', 'count', 'rate', 'pressure', 'function', 'test']
    if any(pattern in text_lower for pattern in lab_patterns):
        confidence = max(confidence, 0.6)
    
    # Anatomy patterns
    anatomy_words = ['heart', 'lung', 'kidney', 'liver', 'brain', 'thyroid']
    if any(word in text_lower for word in anatomy_words):
        confidence = max(confidence, 0.6)
    
    return confidence