import os
import re
import logging
from typing import List, Dict, Any, Optional

import spacy

try:
    from config import SPACY_MODEL_NAME, ENABLE_MODIFIER_LINKER
except ImportError:
    SPACY_MODEL_NAME = os.getenv("SPACY_MODEL_NAME", "en_core_sci_lg")
    ENABLE_MODIFIER_LINKER = os.getenv("ENABLE_MODIFIER_LINKER", "true").lower() in ("1", "true", "yes")

try:
    from .rules import MODIFIER_PATTERNS
except ImportError:
    try:
        from clinicalai_service.nlp_engine.rules import MODIFIER_PATTERNS
    except ImportError:
        raise ImportError("MODIFIER_PATTERNS not found in rules.py. Please define them.")

logger = logging.getLogger("modifier_linker")
logger.setLevel(logging.INFO)

class SpacyModelSingleton:
    _instance = None

    @classmethod
    def get_model(cls):
        if cls._instance is None:
            try:
                cls._instance = spacy.load(SPACY_MODEL_NAME)
                logger.info(f"Loaded spaCy model: {SPACY_MODEL_NAME}")
            except Exception as e:
                logger.warning(f"Could not load spaCy model '{SPACY_MODEL_NAME}': {e}")
                cls._instance = spacy.blank("en")
        return cls._instance

def extract_modifiers(text: str) -> List[Dict[str, Any]]:
    """Extracts modifiers from text using regex patterns from rules.py."""
    modifiers = []
    for mod in MODIFIER_PATTERNS:
        for match in re.finditer(mod["pattern"], text, flags=re.IGNORECASE):
            span = match.span()
            modifiers.append({
                "type": mod["label"],
                "value": match.group().strip(),
                "start": span[0],
                "end": span[1]
            })
    return modifiers

def attach_modifiers(
    entities: List[Dict[str, Any]],
    text: str,
    window: int = 40,
    use_sentence: bool = True
) -> List[Dict[str, Any]]:
    """
    Attaches nearby modifiers to extracted entities.
    """
    if not entities or not text:
        return entities

    nlp = SpacyModelSingleton.get_model()
    try:
        doc = nlp(text)
    except Exception as e:
        logger.warning(f"spaCy NLP failed on text: {e}")
        doc = None

    modifiers = extract_modifiers(text)

    for entity in entities:
        # Handle both dict and Pydantic model entities
        if hasattr(entity, 'start_char'):
            # Pydantic model (EnrichedEntity)
            ent_start = entity.start_char
            ent_end = entity.end_char
        else:
            # Dictionary
            ent_start = entity.get("start_char")
            ent_end = entity.get("end_char")
            
        entity_mods = []
        for mod in modifiers:
            # Proximity match
            if abs(mod["start"] - ent_start) <= window or abs(mod["end"] - ent_end) <= window:
                entity_mods.append(mod)
                continue
            # Sentence match (if enabled and spaCy doc available)
            if use_sentence and doc:
                ent_span = doc.char_span(ent_start, ent_end)
                mod_span = doc.char_span(mod["start"], mod["end"])
                if ent_span and mod_span and ent_span.sent == mod_span.sent:
                    entity_mods.append(mod)
        if entity_mods:
            if hasattr(entity, 'start_char'):
                # For Pydantic models, store modifiers in metadata
                if entity.metadata is None:
                    entity.metadata = {}
                entity.metadata["modifiers"] = entity_mods
            else:
                # Dictionary
                entity["modifiers"] = entity_mods
    return entities

def modifier_linker_pipeline(
    entities: List[Dict[str, Any]],
    text: str,
    config: Optional[dict] = None
) -> List[Dict[str, Any]]:
    """
    Main entry: Optionally applies modifier attachment based on config/env.
    """
    enabled = ENABLE_MODIFIER_LINKER
    if config and "ENABLE_MODIFIER_LINKER" in config:
        enabled = config["ENABLE_MODIFIER_LINKER"]
    if not enabled:
        logger.info("Modifier linker disabled by config/env.")
        return entities
    return attach_modifiers(entities, text)
