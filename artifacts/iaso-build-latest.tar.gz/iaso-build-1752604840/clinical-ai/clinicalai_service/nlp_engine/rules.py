# clinicalai_service/nlp_engine/rules.py
"""
Clinical Production-Grade NLP Rules
Follows healthcare NLP standards and best practices for clinical context detection
"""

from medspacy.context import ConTextRule
from medspacy.section_detection import SectionRule
from typing import Dict, List, Set, Tuple, Optional as TypingOptional, Pattern 
import re

# =============================================================================
# UMLS SEMANTIC TYPE MAPPINGS - CLINICAL PRODUCTION STANDARD
# =============================================================================

# Based on UMLS 2024 Semantic Network - Primary clinical categories
TUI_TO_CATEGORY: Dict[str, str] = {
    # === DISORDERS & CONDITIONS ===
    "T019": "CONDITION",    # Congenital Abnormality
    "T020": "CONDITION",    # Acquired Abnormality  
    "T037": "CONDITION",    # Injury or Poisoning
    "T046": "CONDITION",    # Pathologic Function
    "T047": "CONDITION",    # Disease or Syndrome (PRIMARY)
    "T048": "CONDITION",    # Mental or Behavioral Dysfunction
    "T049": "CONDITION",    # Cell or Molecular Dysfunction
    "T050": "CONDITION",    # Experimental Model of Disease
    "T190": "CONDITION",    # Anatomical Abnormality
    "T191": "CONDITION",    # Neoplastic Process
    
    # === SIGNS & SYMPTOMS ===
    "T184": "SYMPTOM",      # Sign or Symptom (PRIMARY)
    "T033": "FINDING",      # Finding (broader than symptom)
    
    # === PHARMACOLOGIC SUBSTANCES ===
    "T109": "DRUG",         # Organic Chemical (drug context)
    "T121": "DRUG",         # Pharmacologic Substance (PRIMARY)  
    "T123": "DRUG",         # Biologically Active Substance
    "T125": "DRUG",         # Hormone
    "T127": "DRUG",         # Vitamin
    "T129": "DRUG",         # Immunologic Factor
    "T195": "DRUG",         # Antibiotic
    "T197": "DRUG",         # Inorganic Chemical (drug context)
    "T200": "DRUG",         # Clinical Drug
    
    # === PROCEDURES ===
    "T058": "PROCEDURE",    # Health Care Activity (PRIMARY)
    "T059": "PROCEDURE",    # Laboratory Procedure
    "T060": "PROCEDURE",    # Diagnostic Procedure  
    "T061": "PROCEDURE",    # Therapeutic or Preventive Procedure
    "T063": "PROCEDURE",    # Molecular Biology Research Technique
    
    # === LABORATORY & DIAGNOSTICS ===
    "T034": "LAB_RESULT",   # Laboratory or Test Result (PRIMARY)
    "T130": "LAB_RESULT",   # Indicator, Reagent, or Diagnostic Aid
    
    # === ANATOMY ===
    "T017": "ANATOMY",      # Anatomical Structure
    "T021": "ANATOMY",      # Fully Formed Anatomical Structure
    "T022": "ANATOMY",      # Body System
    "T023": "ANATOMY",      # Body Part, Organ, or Organ Component
    "T024": "ANATOMY",      # Tissue
    "T025": "ANATOMY",      # Cell
    "T026": "ANATOMY",      # Cell Component
    "T029": "ANATOMY",      # Body Location or Region
    "T030": "ANATOMY",      # Body Space or Junction
    
    # === MEDICAL DEVICES ===
    "T074": "DEVICE",       # Medical Device
    "T075": "DEVICE",       # Research Device
    "T203": "DEVICE",       # Drug Delivery Device
    
    # === VITAL SIGNS & MEASUREMENTS ===
    "T201": "VITAL_SIGN",   # Clinical Attribute
    "T081": "MEASUREMENT",  # Quantitative Concept (clinical context)
    
    # === OBSERVATIONS ===
    "T040": "OBSERVATION",  # Organism Function
    "T041": "OBSERVATION",  # Mental Process
    "T042": "OBSERVATION",  # Organ or Tissue Function
    "T043": "OBSERVATION",  # Cell Function
    "T044": "OBSERVATION",  # Molecular Function
    "T045": "OBSERVATION",  # Genetic Function
    
    # === SUBSTANCES (NON-DRUG) ===
    "T031": "SUBSTANCE",    # Body Substance
    "T103": "SUBSTANCE",    # Chemical
    "T116": "SUBSTANCE",    # Amino Acid, Peptide, or Protein
    "T120": "SUBSTANCE",    # Chemical Viewed Structurally
    "T122": "SUBSTANCE",    # Biomedical or Dental Material
    "T126": "SUBSTANCE",    # Enzyme
    "T167": "SUBSTANCE",    # Substance (general)
    
    # === NON-CLINICAL (IGNORE) ===
    "T001": "IGNORE",       # Organism
    "T056": "IGNORE",       # Daily or Recreational Activity
    "T065": "IGNORE",       # Educational Activity
    "T067": "IGNORE",       # Phenomenon or Process
    "T073": "IGNORE",       # Manufactured Object (general)
    "T077": "IGNORE",       # Conceptual Entity
    "T078": "IGNORE",       # Idea or Concept
    "T079": "IGNORE",       # Temporal Concept
    "T080": "IGNORE",       # Qualitative Concept
    "T082": "IGNORE",       # Spatial Concept
    "T089": "IGNORE",       # Regulation or Law
    "T090": "IGNORE",       # Occupation or Discipline
    "T091": "IGNORE",       # Biomedical Occupation or Discipline
    "T092": "IGNORE",       # Organization
    "T096": "IGNORE",       # Group
    "T097": "IGNORE",       # Professional or Occupational Group
    "T098": "IGNORE",       # Population Group
    "T099": "IGNORE",       # Family Group
    "T100": "IGNORE",       # Age Group
    "T101": "IGNORE",       # Patient or Disabled Group
    "T168": "IGNORE",       # Food
    "T169": "IGNORE",       # Functional Concept
    "T170": "IGNORE",       # Intellectual Product
}

# Semantic Type Name to Category Mapping
STY_NAME_TO_CATEGORY_MAP: Dict[str, str] = {
    # Primary conditions (highest confidence)
    "DISEASE OR SYNDROME": "CONDITION",
    "MENTAL OR BEHAVIORAL DYSFUNCTION": "CONDITION", 
    "NEOPLASTIC PROCESS": "CONDITION",
    "PATHOLOGIC FUNCTION": "CONDITION",
    "CONGENITAL ABNORMALITY": "CONDITION",
    "ACQUIRED ABNORMALITY": "CONDITION",
    "ANATOMICAL ABNORMALITY": "CONDITION",
    "INJURY OR POISONING": "CONDITION",
    
    # Signs and symptoms
    "SIGN OR SYMPTOM": "SYMPTOM",
    "FINDING": "FINDING",
    
    # Pharmacologic substances  
    "PHARMACOLOGIC SUBSTANCE": "DRUG",
    "CLINICAL DRUG": "DRUG",
    "BIOLOGICALLY ACTIVE SUBSTANCE": "DRUG",
    "ANTIBIOTIC": "DRUG",
    "HORMONE": "DRUG",
    "VITAMIN": "DRUG",
    "IMMUNOLOGIC FACTOR": "DRUG",
    
    # Procedures
    "THERAPEUTIC OR PREVENTIVE PROCEDURE": "PROCEDURE",
    "DIAGNOSTIC PROCEDURE": "PROCEDURE", 
    "LABORATORY PROCEDURE": "PROCEDURE",
    "HEALTH CARE ACTIVITY": "PROCEDURE",
    
    # Laboratory results
    "LABORATORY OR TEST RESULT": "LAB_RESULT",
    "CLINICAL ATTRIBUTE": "VITAL_SIGN",
    
    # Anatomy
    "ANATOMICAL STRUCTURE": "ANATOMY",
    "BODY PART, ORGAN, OR ORGAN COMPONENT": "ANATOMY",
    "BODY LOCATION OR REGION": "ANATOMY", 
    "BODY SPACE OR JUNCTION": "ANATOMY",
    "TISSUE": "ANATOMY",
    "CELL": "ANATOMY",
    "CELL COMPONENT": "ANATOMY",
    
    # Devices
    "MEDICAL DEVICE": "DEVICE",
    "DRUG DELIVERY DEVICE": "DEVICE",
    
    # Observations
    "ORGAN OR TISSUE FUNCTION": "OBSERVATION",
    "ORGANISM FUNCTION": "OBSERVATION",
    
    # Substances
    "BODY SUBSTANCE": "SUBSTANCE",
    "CHEMICAL": "SUBSTANCE",
    "ORGANIC CHEMICAL": "SUBSTANCE", 
    "INORGANIC CHEMICAL": "SUBSTANCE",
    "AMINO ACID, PEPTIDE, OR PROTEIN": "SUBSTANCE",
    "ENZYME": "SUBSTANCE",
    "INDICATOR, REAGENT, OR DIAGNOSTIC AID": "SUBSTANCE",
    
    # Non-clinical (ignore)
    "CONCEPTUAL ENTITY": "IGNORE",
    "INTELLECTUAL PRODUCT": "IGNORE",
    "QUALITATIVE CONCEPT": "IGNORE",
    "QUANTITATIVE CONCEPT": "IGNORE", 
    "TEMPORAL CONCEPT": "IGNORE",
    "SPATIAL CONCEPT": "IGNORE",
    "ACTIVITY": "IGNORE",
    "ORGANIZATION": "IGNORE",
    "PERSON": "IGNORE",
    "GROUP": "IGNORE",
    "OCCUPATION OR DISCIPLINE": "IGNORE",
    "PHENOMENON OR PROCESS": "IGNORE",
    "IDEA OR CONCEPT": "IGNORE",
    "FUNCTIONAL CONCEPT": "IGNORE",
}

# =============================================================================
# MODIFIER PATTERN for MODIFIER_LINKER
# =============================================================================

MODIFIER_PATTERNS = [
    # Duration
    {"label": "DURATION", "pattern": r"\b(for|over|since|during|x|×)\s+[\w\d\s/.,-]{0,30}?(days?|weeks?|months?|years?)\b"},
    {"label": "DURATION", "pattern": r"\b(\d+\s*-\s*\d+\s*(days?|weeks?|months?|years?))\b"},
    {"label": "DURATION", "pattern": r"\b(\d{1,2}/\d{1,2}/\d{2,4})\b"},
    {"label": "DURATION", "pattern": r"\b(chronic|longstanding|acute|subacute|recent onset|history of)\b"},
    # Frequency
    {"label": "FREQUENCY", "pattern": r"\b(daily|every\s+\d+\s*(minutes?|hours?|days?|weeks?|months?)|once\s+a\s+(day|week)|twice\s+a\s+(day|week)|three\s+times\s+a\s+(day|week)|q\d{1,2}h|qhs|bid|tid|qid|prn|as needed|stat|nocte|mane)\b"},
    # Severity
    {"label": "SEVERITY", "pattern": r"\b(mild|moderate|marked|severe|profound|slight|significant|insignificant|massive|extreme|minimal|subtle|intense|tolerable|intolerable|intermittent|persistent|occasional|chronic|acute|exacerbated|unremitting)\b"},
    # Temporal
    {"label": "TEMPORAL", "pattern": r"\b(today|tonight|tomorrow|yesterday|this\s+(morning|afternoon|evening|week|month|year)|last\s+(night|week|month|year)|next\s+(week|month|year)|previous(ly)?|recent(ly)?|currently|presently|in the past|before|after)\b"},
    # Laterality
    {"label": "LATERALITY", "pattern": r"\b(left|right|bilateral|unilateral|left-sided|right-sided|midline|contralateral|ipsilateral)\b"},
    # Position
    {"label": "POSITION", "pattern": r"\b(supine|prone|sitting|standing|recumbent|upright|lateral decubitus)\b"},
    # Route
    {"label": "ROUTE", "pattern": r"\b(oral(ly)?|po|iv|intravenous(ly)?|im|intramuscular(ly)?|subcutaneous(ly)?|sc|sq|topical(ly)?|sublingual(ly)?|buccal(ly)?|rectal(ly)?|inhaled|intranasal|transdermal|intrathecal)\b"},
    # Dosage (numbers and units)
    {"label": "DOSE", "pattern": r"\b(\d+(\.\d+)?\s*(mg|g|mcg|ug|kg|ml|l|units|tablets?|capsules?|puffs?|drops?|cc|meq))\b"},
    # Amount (numeric + quantity)
    {"label": "AMOUNT", "pattern": r"\b(\d+(\.\d+)?\s*(mL|ml|L|cc|units|IU|oz|tbsp|tsp|teaspoons?|tablespoons?|liters?|milliliters?))\b"},
    # Response
    {"label": "RESPONSE", "pattern": r"\b(improved|improving|worse|worsening|resolved|resolving|unchanged|stable|exacerbated|progressed|progressing|relieved|persistent)\b"},
    # Risk / Uncertainty
    {"label": "UNCERTAINTY", "pattern": r"\b(possible|probable|suspected|uncertain|maybe|unlikely|likely|presumed|suggestive of|consistent with|cannot rule out|ruled out)\b"},
    # Qualifiers
    {"label": "QUALIFIER", "pattern": r"\b(acute-on-chronic|sudden|progressive|rapid|abrupt|insidious|recurrent|paroxysmal|transient|episodic|persistent|intermittent)\b"},
]



# =============================================================================
# HIGH-PRECISION CLINICAL TERM MAPPINGS
# =============================================================================

# Exact clinical term overrides - Production validated
CLINICAL_TERM_OVERRIDES: Dict[str, str] = {
    # === CRITICAL SYMPTOMS (never ignore) ===
    "chest pain": "SYMPTOM",
    "shortness of breath": "SYMPTOM", 
    "weight gain": "SYMPTOM",
    "weight loss": "SYMPTOM",
    "abdominal pain": "SYMPTOM",
    "back pain": "SYMPTOM",
    "joint pain": "SYMPTOM",
    "muscle pain": "SYMPTOM",
    "fatigue": "SYMPTOM",
    "nausea": "SYMPTOM",
    "vomiting": "SYMPTOM",
    "dizziness": "SYMPTOM",
    "headache": "SYMPTOM",
    "palpitations": "SYMPTOM",
    "cold intolerance": "SYMPTOM",
    "heat intolerance": "SYMPTOM",
    "dry skin": "SYMPTOM",
    "mood changes": "SYMPTOM",
    
    # === CRITICAL CONDITIONS ===
    "myocardial infarction": "CONDITION",
    "mi": "CONDITION",
    "heart attack": "CONDITION",
    "stroke": "CONDITION",
    "diabetes": "CONDITION",
    "diabetes mellitus": "CONDITION",
    "type 1 diabetes": "CONDITION",
    "type 2 diabetes": "CONDITION",
    "hypertension": "CONDITION",
    "high blood pressure": "CONDITION",
    "hypothyroidism": "CONDITION", 
    "hyperthyroidism": "CONDITION",
    "thyroid disease": "CONDITION",
    "copd": "CONDITION",
    "asthma": "CONDITION",
    "pneumonia": "CONDITION",
    "bronchitis": "CONDITION",
    "heart failure": "CONDITION",
    "atrial fibrillation": "CONDITION",
    "coronary artery disease": "CONDITION",
    "hyperlipidemia": "CONDITION",
    "high cholesterol": "CONDITION",
    
    # === LABORATORY TESTS ===
    "tsh": "LAB_RESULT",
    "thyroid stimulating hormone": "LAB_RESULT",
    "free t4": "LAB_RESULT",
    "free t3": "LAB_RESULT",
    "t4": "LAB_RESULT",
    "t3": "LAB_RESULT",
    "glucose": "LAB_RESULT",
    "blood sugar": "LAB_RESULT",
    "a1c": "LAB_RESULT",
    "hba1c": "LAB_RESULT",
    "hemoglobin a1c": "LAB_RESULT",
    "cbc": "LAB_RESULT",
    "complete blood count": "LAB_RESULT",
    "bmp": "LAB_RESULT",
    "basic metabolic panel": "LAB_RESULT",
    "cmp": "LAB_RESULT",
    "comprehensive metabolic panel": "LAB_RESULT",
    "lipid panel": "LAB_RESULT",
    "cholesterol": "LAB_RESULT",
    "ldl": "LAB_RESULT",
    "hdl": "LAB_RESULT",
    "triglycerides": "LAB_RESULT",
    "creatinine": "LAB_RESULT",
    "bun": "LAB_RESULT",
    "egfr": "LAB_RESULT",
    "troponin": "LAB_RESULT",
    "ck-mb": "LAB_RESULT",
    "bnp": "LAB_RESULT",
    "nt-probnp": "LAB_RESULT",
    
    # === VITAL SIGNS ===
    "blood pressure": "VITAL_SIGN",
    "bp": "VITAL_SIGN",
    "heart rate": "VITAL_SIGN",
    "pulse": "VITAL_SIGN",
    "temperature": "VITAL_SIGN",
    "temp": "VITAL_SIGN",
    "respiratory rate": "VITAL_SIGN",
    "respiration": "VITAL_SIGN",
    "oxygen saturation": "VITAL_SIGN",
    "o2 sat": "VITAL_SIGN",
    "pulse ox": "VITAL_SIGN",
    "weight": "VITAL_SIGN",
    "height": "VITAL_SIGN",
    "bmi": "VITAL_SIGN",
    
    # === COMMON MEDICATIONS ===
    "levothyroxine": "DRUG",
    "synthroid": "DRUG",
    "lisinopril": "DRUG",
    "amlodipine": "DRUG",
    "metformin": "DRUG",
    "metoprolol": "DRUG",
    "atorvastatin": "DRUG",
    "simvastatin": "DRUG",
    "aspirin": "DRUG",
    "insulin": "DRUG",
    "warfarin": "DRUG",
    "furosemide": "DRUG",
    "hydrochlorothiazide": "DRUG",
    "omeprazole": "DRUG",
    "prednisone": "DRUG",
    
    # === PROCEDURES ===
    "ecg": "PROCEDURE",
    "ekg": "PROCEDURE",
    "electrocardiogram": "PROCEDURE",
    "chest x-ray": "PROCEDURE",
    "ct scan": "PROCEDURE", 
    "mri": "PROCEDURE",
    "ultrasound": "PROCEDURE",
    "cardiac catheterization": "PROCEDURE",
    "stress test": "PROCEDURE",
    "colonoscopy": "PROCEDURE",
    "endoscopy": "PROCEDURE",
    "biopsy": "PROCEDURE",
    "surgery": "PROCEDURE",
    "thyroid function test": "PROCEDURE",
    
    # === ANATOMY (key structures) ===
    "heart": "ANATOMY",
    "lungs": "ANATOMY", 
    "liver": "ANATOMY",
    "kidney": "ANATOMY",
    "kidneys": "ANATOMY",
    "thyroid": "ANATOMY",
    "thyroid gland": "ANATOMY",
    "abdomen": "ANATOMY",
    "chest": "ANATOMY",
    "extremities": "ANATOMY",
    
    # === NON-CLINICAL TERMS (ignore) ===
    "patient": "IGNORE",
    "patient states": "IGNORE",
    "patient reports": "IGNORE", 
    "patient denies": "IGNORE",
    "history": "IGNORE",
    "presents": "IGNORE",
    "reports": "IGNORE",
    "states": "IGNORE",
    "denies": "IGNORE",
    "normal": "IGNORE",
    "stable": "IGNORE",
    "unchanged": "IGNORE",
    "clear": "IGNORE",
    "soft": "IGNORE",
    "non-tender": "IGNORE",
    "today": "IGNORE",
    "yesterday": "IGNORE",
    "daily": "IGNORE",
    "weekly": "IGNORE",
    "monthly": "IGNORE",
    "times": "IGNORE",
    "week": "IGNORE",
    "weeks": "IGNORE",
    "month": "IGNORE", 
    "months": "IGNORE",
    "year": "IGNORE",
    "years": "IGNORE",
    "age": "IGNORE",
    "doctor": "IGNORE",
    "physician": "IGNORE",
    "nurse": "IGNORE",
    "clinic": "IGNORE",
    "hospital": "IGNORE",
    "office": "IGNORE",
    "visit": "IGNORE",
    "appointment": "IGNORE",
    "follow up": "IGNORE",
    "follow-up": "IGNORE",
    "return": "IGNORE",
    "plan": "IGNORE",
    "assessment": "IGNORE",
    "impression": "IGNORE",
    "diagnosis": "IGNORE",
    "condition": "IGNORE",
    "problem": "IGNORE",
    "issue": "IGNORE",
    "medication": "IGNORE",
    "medications": "IGNORE",
    "drug": "IGNORE",
    "drugs": "IGNORE",
    "therapy": "IGNORE",
    "treatment": "IGNORE",
    "procedure": "IGNORE",
    "procedures": "IGNORE",
    "test": "IGNORE",
    "tests": "IGNORE",
    "lab": "IGNORE",
    "labs": "IGNORE",
    "study": "IGNORE",
    "studies": "IGNORE",
    "exam": "IGNORE",
    "examination": "IGNORE",
    "finding": "IGNORE",
    "findings": "IGNORE",
    "result": "IGNORE",
    "results": "IGNORE",
    "value": "IGNORE",
    "values": "IGNORE",
    "level": "IGNORE",
    "levels": "IGNORE",
}

# =============================================================================
# CLINICAL PATTERN MATCHING RULES
# =============================================================================

# High-confidence clinical patterns for fallback detection
CLINICAL_PATTERN_RULES: List[Tuple[str, str, TypingOptional[Pattern], str]] = [
    # === VITAL SIGN PATTERNS ===
    (r"\bbp\s+\d+/\d+", "regex", None, "VITAL_SIGN"),
    (r"\bhr\s+\d+", "regex", None, "VITAL_SIGN"),
    (r"\bpulse\s+\d+", "regex", None, "VITAL_SIGN"),
    (r"\btemp\s+\d+\.?\d*", "regex", None, "VITAL_SIGN"),
    (r"\brr\s+\d+", "regex", None, "VITAL_SIGN"),
    (r"\bo2\s+sat\s+\d+", "regex", None, "VITAL_SIGN"),
    (r"\bweight\s+\d+", "regex", None, "VITAL_SIGN"),
    
    # === MEDICATION DOSAGE PATTERNS ===
    (r"\b\w+\s+\d+\s*m?cg?\b", "regex", None, "DRUG"),
    (r"\b\w+\s+\d+\s*mg\b", "regex", None, "DRUG"),
    (r"\b\w+\s+\d+\s*units?\b", "regex", None, "DRUG"),
    
    # === LAB VALUE PATTERNS ===
    (r"\b[a-z]+\s+\d+\.?\d*", "regex", None, "LAB_RESULT"),
    (r"\b[a-z]+\s+elevated?", "regex", None, "LAB_RESULT"),
    (r"\b[a-z]+\s+low", "regex", None, "LAB_RESULT"),
    (r"\b[a-z]+\s+normal", "regex", None, "LAB_RESULT"),
    
    # === SPECIFIC HIGH-VALUE TERMS ===
    ("chest pain", "exact", None, "SYMPTOM"),
    ("shortness of breath", "exact", None, "SYMPTOM"),
    ("myocardial infarction", "exact", None, "CONDITION"),
    ("thyroid function", "contains", None, "OBSERVATION"),
]

# =============================================================================
# CLINICAL CONTEXT RULES - PRODUCTION GRADE
# =============================================================================

# Primary negation patterns (most restrictive scopes)
NEGATION_RULES: List[ConTextRule] = [
    # Strong negation (definitive)
    ConTextRule(literal="no evidence of", category="NEGATED_EXISTENCE", direction="FORWARD", max_scope=3),
    ConTextRule(literal="negative for", category="NEGATED_EXISTENCE", direction="FORWARD", max_scope=3),
    ConTextRule(literal="absent", category="NEGATED_EXISTENCE", direction="FORWARD", max_scope=2),
    ConTextRule(literal="denies", category="NEGATED_EXISTENCE", direction="FORWARD", max_scope=4),
    ConTextRule(literal="patient denies", category="NEGATED_EXISTENCE", direction="FORWARD", max_scope=5),
    ConTextRule(literal="no complaints of", category="NEGATED_EXISTENCE", direction="FORWARD", max_scope=4),
    ConTextRule(literal="no signs of", category="NEGATED_EXISTENCE", direction="FORWARD", max_scope=3),
    ConTextRule(literal="no symptoms of", category="NEGATED_EXISTENCE", direction="FORWARD", max_scope=3),
    ConTextRule(literal="without", category="NEGATED_EXISTENCE", direction="FORWARD", max_scope=2),
    ConTextRule(literal="ruled out", category="NEGATED_EXISTENCE", direction="BACKWARD", max_scope=3),
    ConTextRule(literal="rules out", category="NEGATED_EXISTENCE", direction="FORWARD", max_scope=3),
    
    # Weaker negation (broader but still controlled)
    ConTextRule(literal="not", category="NEGATED_EXISTENCE", direction="FORWARD", max_scope=2),
    ConTextRule(literal="no", category="NEGATED_EXISTENCE", direction="FORWARD", max_scope=2),
]

# Historical context rules
HISTORICAL_RULES: List[ConTextRule] = [
    ConTextRule(literal="history of", category="HISTORICAL", direction="FORWARD", max_scope=5),
    ConTextRule(literal="h/o", category="HISTORICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="hx of", category="HISTORICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="past medical history", category="HISTORICAL", direction="FORWARD", max_scope=8),
    ConTextRule(literal="pmh", category="HISTORICAL", direction="FORWARD", max_scope=8),
    ConTextRule(literal="previous", category="HISTORICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="prior", category="HISTORICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="chronic", category="HISTORICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="longstanding", category="HISTORICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="established", category="HISTORICAL", direction="FORWARD", max_scope=3),
]

# Hypothetical/uncertain context rules  
HYPOTHETICAL_RULES: List[ConTextRule] = [
    ConTextRule(literal="possible", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="possibly", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="probable", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="probably", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="likely", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="unlikely", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="potential", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="consider", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="considering", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="suspected", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="suspicion", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="question", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="questionable", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="r/o", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="rule out", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="differential", category="HYPOTHETICAL", direction="FORWARD", max_scope=5),
    ConTextRule(literal="concern for", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="suggestive of", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="consistent with", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="appears", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="seems", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="may", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="might", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
    ConTextRule(literal="could", category="HYPOTHETICAL", direction="FORWARD", max_scope=3),
]

# Family history context rules
FAMILY_HISTORY_RULES: List[ConTextRule] = [
    ConTextRule(literal="family history", category="FAMILY_HISTORY", direction="FORWARD", max_scope=8),
    ConTextRule(literal="fh", category="FAMILY_HISTORY", direction="FORWARD", max_scope=8),
    ConTextRule(literal="fhx", category="FAMILY_HISTORY", direction="FORWARD", max_scope=8),
    ConTextRule(literal="father", category="FAMILY_HISTORY", direction="FORWARD", max_scope=5),
    ConTextRule(literal="mother", category="FAMILY_HISTORY", direction="FORWARD", max_scope=5),
    ConTextRule(literal="parents", category="FAMILY_HISTORY", direction="FORWARD", max_scope=5),
    ConTextRule(literal="parent", category="FAMILY_HISTORY", direction="FORWARD", max_scope=5),
    ConTextRule(literal="brother", category="FAMILY_HISTORY", direction="FORWARD", max_scope=5),
    ConTextRule(literal="sister", category="FAMILY_HISTORY", direction="FORWARD", max_scope=5),
    ConTextRule(literal="sibling", category="FAMILY_HISTORY", direction="FORWARD", max_scope=5),
    ConTextRule(literal="grandparent", category="FAMILY_HISTORY", direction="FORWARD", max_scope=5),
    ConTextRule(literal="grandmother", category="FAMILY_HISTORY", direction="FORWARD", max_scope=5),
    ConTextRule(literal="grandfather", category="FAMILY_HISTORY", direction="FORWARD", max_scope=5),
    ConTextRule(literal="uncle", category="FAMILY_HISTORY", direction="FORWARD", max_scope=5),
    ConTextRule(literal="aunt", category="FAMILY_HISTORY", direction="FORWARD", max_scope=5),
    ConTextRule(literal="cousin", category="FAMILY_HISTORY", direction="FORWARD", max_scope=5),
]

# Social history context rules
SOCIAL_HISTORY_RULES: List[ConTextRule] = [
    ConTextRule(literal="social history", category="SOCIAL_HISTORY", direction="FORWARD", max_scope=10),
    ConTextRule(literal="sh", category="SOCIAL_HISTORY", direction="FORWARD", max_scope=10),
    ConTextRule(literal="shx", category="SOCIAL_HISTORY", direction="FORWARD", max_scope=10),
    ConTextRule(literal="tobacco", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=5),
    ConTextRule(literal="smoking", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=5),
    ConTextRule(literal="smoker", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=5),
    ConTextRule(literal="alcohol", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=5),
    ConTextRule(literal="drinking", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=5),
    ConTextRule(literal="drinker", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=5),
    ConTextRule(literal="drug use", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=5),
    ConTextRule(literal="substance", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=5),
    ConTextRule(literal="occupation", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=8),
    ConTextRule(literal="works", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=8),
    ConTextRule(literal="employed", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=8),
    ConTextRule(literal="retired", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=5),
    ConTextRule(literal="married", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=5),
    ConTextRule(literal="single", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=5),
    ConTextRule(literal="divorced", category="SOCIAL_HISTORY", direction="BIDIRECTIONAL", max_scope=5),
]

# =============================================================================
# TERMINATION RULES - PREVENT CONTEXT BLEEDING
# =============================================================================

# Critical: These rules STOP context propagation, preventing bleeding
TERMINATION_RULES: List[ConTextRule] = [
    # Primary terminators (punctuation and conjunctions)
    ConTextRule(literal=".", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal=";", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal=",", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="and", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="but", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="however", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="although", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="though", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="while", category="TERMINATE", direction="TERMINATE"),
    
    # Section boundaries (strong terminators)
    ConTextRule(literal="assessment", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="plan", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="impression", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="diagnosis", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="physical exam", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="review of systems", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="medications", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="allergies", category="TERMINATE", direction="TERMINATE"),
    
    # Clinical value boundaries (prevent context from crossing measurements)
    ConTextRule(literal="shows", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="reveals", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="demonstrates", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="indicates", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="measures", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="reads", category="TERMINATE", direction="TERMINATE"),
    
    # Temporal boundaries
    ConTextRule(literal="now", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="currently", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="today", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="yesterday", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="recently", category="TERMINATE", direction="TERMINATE"),
    
    # Positive assertion boundaries (prevent negation bleeding into positive statements)
    ConTextRule(literal="reports", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="presents with", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="complains of", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="has", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="demonstrates", category="TERMINATE", direction="TERMINATE"),
    ConTextRule(literal="exhibits", category="TERMINATE", direction="TERMINATE"),
]

# =============================================================================
# COMPLETE CONTEXT RULES LIST
# =============================================================================

# Combine all context rules in proper order (terminators first to take precedence)
CONTEXT_RULES_LIST: List[ConTextRule] = (
    TERMINATION_RULES +           # Highest priority - prevent bleeding
    NEGATION_RULES +              # High priority - explicit negation
    HISTORICAL_RULES +            # Medium priority - temporal context
    HYPOTHETICAL_RULES +          # Medium priority - uncertainty
    FAMILY_HISTORY_RULES +        # Medium priority - attribution context
    SOCIAL_HISTORY_RULES          # Lower priority - social context
)

# Context modifier categories for processing
CONTEXT_MODIFIER_CATEGORIES: Set[str] = {
    "NEGATED_EXISTENCE", 
    "HISTORICAL", 
    "HYPOTHETICAL", 
    "FAMILY_HISTORY", 
    "SOCIAL_HISTORY", 
    "TERMINATE"
}

# =============================================================================
# CLINICAL SECTION DETECTION RULES
# =============================================================================

# Production-grade section patterns for clinical notes
CLINICAL_SECTION_RULES: List[SectionRule] = [
    # Chief complaint and HPI
    SectionRule("chief_complaint", r"(?i)^\s*(CHIEF\s+COMPLAINT|CC)\s*[:\-]"),
    SectionRule("history_present_illness", r"(?i)^\s*(HISTORY\s+OF\s+PRESENT\s+ILLNESS|HPI)\s*[:\-]"),
    SectionRule("subjective", r"(?i)^\s*(SUBJECTIVE)\s*[:\-]"),
    
    # Past medical history
    SectionRule("past_medical_history", r"(?i)^\s*(PAST\s+MEDICAL\s+HISTORY|PMH|PMHX)\s*[:\-]"),
    SectionRule("medical_history", r"(?i)^\s*(MEDICAL\s+HISTORY)\s*[:\-]"),
    
    # Medications and allergies
    SectionRule("medications", r"(?i)^\s*(MEDICATIONS|CURRENT\s+MEDICATIONS|MEDS)\s*[:\-]"),
    SectionRule("allergies", r"(?i)^\s*(ALLERGIES|ADVERSE\s+REACTIONS|NKDA)\s*[:\-]"),
    
    # Family and social history
    SectionRule("family_history", r"(?i)^\s*(FAMILY\s+HISTORY|FH|FHX)\s*[:\-]"),
    SectionRule("social_history", r"(?i)^\s*(SOCIAL\s+HISTORY|SH|SHX)\s*[:\-]"),
    
    # Review of systems
    SectionRule("review_of_systems", r"(?i)^\s*(REVIEW\s+OF\s+SYSTEMS|ROS)\s*[:\-]"),
    
    # Physical examination
    SectionRule("physical_exam", r"(?i)^\s*(PHYSICAL\s+EXAM|PHYSICAL\s+EXAMINATION|PE)\s*[:\-]"),
    SectionRule("objective", r"(?i)^\s*(OBJECTIVE)\s*[:\-]"),
    SectionRule("vital_signs", r"(?i)^\s*(VITAL\s+SIGNS|VITALS|VS)\s*[:\-]"),
    
    # Diagnostics
    SectionRule("laboratory", r"(?i)^\s*(LABORATORY|LABS|LAB\s+RESULTS)\s*[:\-]"),
    SectionRule("imaging", r"(?i)^\s*(IMAGING|RADIOLOGY|STUDIES)\s*[:\-]"),
    SectionRule("diagnostics", r"(?i)^\s*(DIAGNOSTIC\s+STUDIES|DIAGNOSTICS)\s*[:\-]"),
    
    # Assessment and plan
    SectionRule("assessment", r"(?i)^\s*(ASSESSMENT|IMPRESSION)\s*[:\-]"),
    SectionRule("plan", r"(?i)^\s*(PLAN|TREATMENT\s+PLAN)\s*[:\-]"),
    SectionRule("assessment_plan", r"(?i)^\s*(ASSESSMENT\s+AND\s+PLAN|A\s*[&/]\s*P)\s*[:\-]"),
    
    # Procedure notes
    SectionRule("procedure", r"(?i)^\s*(PROCEDURE|TECHNIQUE)\s*[:\-]"),
    SectionRule("findings", r"(?i)^\s*(FINDINGS|RESULTS)\s*[:\-]"),
    SectionRule("complications", r"(?i)^\s*(COMPLICATIONS)\s*[:\-]"),
    
    # Discharge planning
    SectionRule("discharge_plan", r"(?i)^\s*(DISCHARGE\s+PLAN|DISPOSITION)\s*[:\-]"),
    SectionRule("follow_up", r"(?i)^\s*(FOLLOW\s*UP|FOLLOW-UP)\s*[:\-]"),
    
    # General catch-all (lowest priority)
    SectionRule("general", r".*")
]

# =============================================================================
# SPACY LABEL TO CLINICAL CATEGORY MAPPING
# =============================================================================

# Standard spaCy NER labels to clinical categories
SPACY_LABEL_TO_CATEGORY: Dict[str, str] = {
    # Clinical entities (from scispacy models)
    "DISEASE": "CONDITION",
    "CHEMICAL": "DRUG", 
    "ENTITY": "OBSERVATION",  # Generic clinical entity
    
    # Standard spaCy entities
    "PERSON": "IGNORE",
    "ORG": "IGNORE",
    "GPE": "IGNORE",        # Geopolitical entity
    "LOC": "IGNORE",        # Location
    "DATE": "IGNORE",
    "TIME": "IGNORE",
    "MONEY": "IGNORE",
    "PERCENT": "IGNORE",
    "QUANTITY": "MEASUREMENT",
    "ORDINAL": "IGNORE",
    "CARDINAL": "MEASUREMENT",
    
    # Product/device related
    "PRODUCT": "DEVICE",
    
    # Events and concepts
    "EVENT": "IGNORE",
    "FAC": "IGNORE",        # Facility
    "NORP": "IGNORE",       # Nationalities/groups
    "LANGUAGE": "IGNORE",
    "LAW": "IGNORE",
    "WORK_OF_ART": "IGNORE",
}

# =============================================================================
# LAB Mapping - IMPROVED WITH CLINICAL VALIDATION
# =============================================================================

# Known clinical lab names for validation
VALID_LAB_NAMES = {
    # Common chemistry panel
    "glucose", "blood glucose", "blood sugar", "bg", "fasting glucose",
    "sodium", "na", "potassium", "k", "chloride", "cl", "co2", "bicarbonate",
    "bun", "blood urea nitrogen", "creatinine", "cr", "egfr", "gfr",
    
    # Lipid panel
    "cholesterol", "total cholesterol", "ldl", "hdl", "triglycerides", "trig",
    
    # Liver function
    "alt", "sgpt", "ast", "sgot", "alkaline phosphatase", "alk phos", "alp",
    "bilirubin", "total bilirubin", "direct bilirubin", "albumin",
    
    # Cardiac markers
    "troponin", "troponin i", "troponin t", "ck", "ck-mb", "cpk",
    "bnp", "nt-probnp", "pro-bnp", "myoglobin",
    
    # Hematology
    "hemoglobin", "hgb", "hb", "hematocrit", "hct", "wbc", "white blood cell",
    "rbc", "red blood cell", "platelet", "plt", "mcv", "mch", "mchc",
    
    # Endocrine
    "tsh", "thyroid stimulating hormone", "t3", "t4", "free t3", "free t4",
    "hba1c", "hemoglobin a1c", "a1c", "insulin", "c-peptide",
    
    # Coagulation
    "pt", "ptt", "inr", "fibrinogen", "d-dimer",
    
    # Inflammatory markers
    "esr", "sed rate", "crp", "c-reactive protein",
    
    # Vitamins/minerals
    "vitamin d", "25-oh vitamin d", "b12", "folate", "iron", "ferritin",
    "calcium", "magnesium", "phosphorus", "zinc"
}

# Known vital sign names
VALID_VITAL_NAMES = {
    "blood pressure", "bp", "systolic", "diastolic",
    "heart rate", "hr", "pulse", "pulse rate",
    "respiratory rate", "rr", "respiration", "breathing rate",
    "temperature", "temp", "fever",
    "oxygen saturation", "o2 sat", "spo2", "pulse ox",
    "weight", "height", "bmi", "body mass index"
}

# Known allergy triggers
VALID_ALLERGY_SUBSTANCES = {
    # Common drug allergies
    "penicillin", "amoxicillin", "sulfa", "sulfamethoxazole", "codeine",
    "morphine", "aspirin", "ibuprofen", "latex", "iodine", "contrast",
    
    # Food allergies
    "peanuts", "tree nuts", "shellfish", "fish", "eggs", "milk", "soy", "wheat",
    
    # Environmental
    "pollen", "dust", "mold", "pet dander", "cats", "dogs"
}

LAB_RESULT_PATTERNS_MAP = [
    # Specific high-confidence patterns with exact lab names
    {
        "pattern": r"\b(HbA1c|hemoglobin a1c|a1c)\s*[:=]?\s*(-?\d+(\.\d+)?)\s*%?\b",
        "name": "HbA1c",
        "fields": ["value"],
        "unit": "%",
        "confidence": 0.95
    },
    {
        "pattern": r"\b(glucose|blood glucose|blood sugar|bg)\s*[:=]?\s*(-?\d+(\.\d+)?)\s*(mg/dL|mmol/L)?\b",
        "name": "Glucose",
        "fields": ["value"],
        "unit": "mg/dL",
        "confidence": 0.9
    },
    {
        "pattern": r"\b(sodium|na)\s*[:=]?\s*(-?\d+(\.\d+)?)\s*(mmol/L|meq/L)?\b",
        "name": "Sodium",
        "fields": ["value"],
        "unit": "mmol/L",
        "confidence": 0.9
    },
    {
        "pattern": r"\b(potassium|k)\s*[:=]?\s*(-?\d+(\.\d+)?)\s*(mmol/L|meq/L)?\b",
        "name": "Potassium",
        "fields": ["value"],
        "unit": "mmol/L",
        "confidence": 0.9
    },
    {
        "pattern": r"\b(creatinine|cr)\s*[:=]?\s*(-?\d+(\.\d+)?)\s*(mg/dL|μmol/L)?\b",
        "name": "Creatinine",
        "fields": ["value"],
        "unit": "mg/dL",
        "confidence": 0.9
    },
    {
        "pattern": r"\b(hemoglobin|hgb|hb)\s*[:=]?\s*(-?\d+(\.\d+)?)\s*(g/dL|g/L)?\b",
        "name": "Hemoglobin",
        "fields": ["value"],
        "unit": "g/dL",
        "confidence": 0.9
    },
    {
        "pattern": r"\b(wbc|white blood cell count)\s*[:=]?\s*(-?\d+(\.\d+)?)\s*(k/uL|x10\^3/uL)?\b",
        "name": "WBC",
        "fields": ["value"],
        "unit": "k/uL",
        "confidence": 0.9
    },
    {
        "pattern": r"\b(tsh|thyroid stimulating hormone)\s*[:=]?\s*(-?\d+(\.\d+)?)\s*(mIU/L|uIU/mL)?\b",
        "name": "TSH",
        "fields": ["value"],
        "unit": "mIU/L",
        "confidence": 0.95
    },
    {
        "pattern": r"\b(troponin|troponin i|troponin t)\s*[:=]?\s*(-?\d+(\.\d+)?)\s*(ng/mL|μg/L)?\b",
        "name": "Troponin",
        "fields": ["value"],
        "unit": "ng/mL",
        "confidence": 0.95
    },
    {
        "pattern": r"\b(bnp|nt-probnp|pro-bnp)\s*[:=]?\s*(-?\d+(\.\d+)?)\s*(pg/mL|ng/L)?\b",
        "name": "BNP",
        "fields": ["value"],
        "unit": "pg/mL",
        "confidence": 0.95
    },
    # REMOVED: The overly broad catch-all pattern that was causing false positives
]

# =============================================================================
# VITALS PATTERN MAPPING - IMPROVED
# =============================================================================

VITAL_PATTERNS_MAP = [
    {
        "pattern": r"\b(blood pressure|bp)\s*[:=]?\s*(\d{2,3})[\/\-](\d{2,3})\b",
        "name": "Blood Pressure",
        "fields": ["systolic", "diastolic"],
        "confidence": 0.95
    },
    {
        "pattern": r"\b(heart rate|hr|pulse rate|pulse)\s*[:=]?\s*(\d{2,3})\s*(bpm)?\b",
        "name": "Heart Rate",
        "fields": ["value"],
        "confidence": 0.9
    },
    {
        "pattern": r"\b(respiratory rate|rr|respiration)\s*[:=]?\s*(\d{1,2})\s*(breaths per minute|bpm)?\b",
        "name": "Respiratory Rate",
        "fields": ["value"],
        "confidence": 0.9
    },
    {
        "pattern": r"\b(temperature|temp)\s*[:=]?\s*(\d{2,3}(\.\d+)?)\s*([fc]|degrees?)?\b",
        "name": "Temperature",
        "fields": ["value", "unit"],
        "confidence": 0.9
    },
    {
        "pattern": r"\b(oxygen saturation|o2 sat|spo2|pulse ox)\s*[:=]?\s*(\d{2,3})\s*%?\b",
        "name": "Oxygen Saturation",
        "fields": ["value"],
        "confidence": 0.95
    },
    {
        "pattern": r"\b(weight)\s*[:=]?\s*(\d{2,3}(\.\d+)?)\s*(kg|lbs?|pounds?)?\b",
        "name": "Weight",
        "fields": ["value", "unit"],
        "confidence": 0.85
    },
    {
        "pattern": r"\b(height)\s*[:=]?\s*(\d{1,3}(\.\d+)?)\s*(cm|ft|feet|inches?|in)?\b",
        "name": "Height",
        "fields": ["value", "unit"],
        "confidence": 0.85
    },
    {
        "pattern": r"\b(bmi|body mass index)\s*[:=]?\s*(\d{1,2}(\.\d+)?)\b",
        "name": "BMI",
        "fields": ["value"],
        "confidence": 0.9
    }
]

# =============================================================================
# ALLERGY PATTERN MAPPING - IMPROVED
# =============================================================================

ALLERGY_PATTERNS_MAP = [
    {
        "pattern": r"\b(allergic to|allergy to)\s+([a-zA-Z][a-zA-Z0-9\s\-]{2,20})(?=[.,;]|$|\s+and|\s+or)",
        "fields": ["substance"],
        "confidence": 0.9
    },
    {
        "pattern": r"\b(adverse reaction to|reaction to)\s+([a-zA-Z][a-zA-Z0-9\s\-]{2,20})(?=[.,;]|$|\s+and|\s+or)",
        "fields": ["substance"],
        "confidence": 0.85
    },
    {
        "pattern": r"\b(nkda|no known drug allergies|no known allergies)\b",
        "fields": [],
        "special": "no_allergies",
        "confidence": 0.95
    }
]

# =============================================================================
# CLINICAL VALIDATION FUNCTIONS
# =============================================================================

def is_valid_lab_name(name: str) -> bool:
    """Check if a name is a valid clinical laboratory test"""
    if not name or len(name.strip()) < 2:
        return False
    
    name_clean = name.lower().strip()
    
    # Check against known lab names
    if name_clean in VALID_LAB_NAMES:
        return True
    
    # Check for common lab abbreviations (2-5 characters, mostly letters)
    if len(name_clean) <= 5 and name_clean.isalpha():
        return True
    
    # Reject obvious non-lab terms
    non_lab_terms = {
        "patient", "the", "is", "a", "an", "and", "or", "but", "with", "for",
        "to", "of", "in", "on", "at", "by", "from", "up", "about", "into",
        "through", "during", "before", "after", "above", "below", "between",
        "year", "years", "old", "age", "male", "female", "man", "woman"
    }
    
    if name_clean in non_lab_terms:
        return False
    
    # Reject if it contains common non-medical words
    words = name_clean.split()
    if any(word in non_lab_terms for word in words):
        return False
    
    return False

def is_valid_vital_name(name: str) -> bool:
    """Check if a name is a valid vital sign"""
    if not name or len(name.strip()) < 2:
        return False
    
    name_clean = name.lower().strip()
    return name_clean in VALID_VITAL_NAMES

def is_valid_allergy_substance(substance: str) -> bool:
    """Check if a substance is a valid allergy trigger"""
    if not substance or len(substance.strip()) < 2:
        return False
    
    substance_clean = substance.lower().strip()
    
    # Check against known allergens
    if substance_clean in VALID_ALLERGY_SUBSTANCES:
        return True
    
    # Check for medication names (often end in common suffixes)
    med_suffixes = ["cillin", "mycin", "pril", "olol", "ine", "ide", "ate"]
    if any(substance_clean.endswith(suffix) for suffix in med_suffixes):
        return True
    
    # Reject obvious non-allergens
    non_allergen_terms = {
        "patient", "the", "is", "a", "an", "and", "or", "but", "with",
        "history", "reports", "states", "denies", "normal", "stable"
    }
    
    if substance_clean in non_allergen_terms:
        return False
    
    # Allow if it looks like a reasonable substance name (2-20 chars, mostly letters)
    if 2 <= len(substance_clean) <= 20 and substance_clean.replace(" ", "").replace("-", "").isalpha():
        return True
    
    return False

def validate_numeric_range(value: str, test_type: str) -> bool:
    """Validate that numeric values are in reasonable clinical ranges"""
    try:
        num_val = float(value)
    except (ValueError, TypeError):
        return False
    
    # Define reasonable ranges for common tests
    ranges = {
        "glucose": (50, 500),      # mg/dL
        "sodium": (120, 160),      # mmol/L
        "potassium": (2.0, 7.0),   # mmol/L
        "creatinine": (0.3, 15.0), # mg/dL
        "hemoglobin": (5.0, 20.0), # g/dL
        "wbc": (1.0, 50.0),        # k/uL
        "tsh": (0.1, 100.0),       # mIU/L
        "troponin": (0.0, 50.0),   # ng/mL
        "bnp": (0.0, 5000.0),      # pg/mL
        "hba1c": (4.0, 15.0),      # %
        
        # Vitals
        "heart_rate": (30, 200),   # bpm
        "systolic_bp": (60, 250),  # mmHg
        "diastolic_bp": (30, 150), # mmHg
        "respiratory_rate": (5, 50), # breaths/min
        "temperature": (90, 110),   # F or 32-45 C
        "oxygen_saturation": (70, 100), # %
        "weight": (20, 500),        # kg or lbs
        "height": (50, 250),        # cm or inches
        "bmi": (10, 60)             # kg/m²
    }
    
    test_key = test_type.lower().replace(" ", "_")
    if test_key in ranges:
        min_val, max_val = ranges[test_key]
        return min_val <= num_val <= max_val
    
    # For unknown tests, allow reasonable numeric ranges
    return 0.001 <= num_val <= 10000

# =============================================================================
# TERMINOLOGY SERVICE VALIDATION FUNCTIONS
# =============================================================================

async def validate_with_terminology_service(term: str, expected_category: str, terminology_client=None) -> tuple[bool, float, str]:
    """
    Validate a term against the terminology service to check if it's a valid clinical concept.
    
    Args:
        term: The term to validate
        expected_category: Expected category ('LAB_RESULT', 'VITAL_SIGN', 'ALLERGY')
        terminology_client: TerminologyServiceClient instance
    
    Returns:
        tuple: (is_valid, confidence_score, cui_or_reason)
    """
    if not terminology_client:
        return False, 0.0, "no_terminology_service"
    
    try:
        # Search for the term in UMLS
        concepts = await terminology_client.search_terms(term, limit=3)
        
        if not concepts:
            return False, 0.0, "not_found_in_umls"
        
        # Check if any concept matches the expected category
        for concept in concepts:
            if _is_concept_category_match(concept, expected_category):
                confidence = _calculate_terminology_confidence(concept, term)
                return True, confidence, concept.id
        
        # Found concepts but none match expected category
        return False, 0.3, f"wrong_category_{concepts[0].id}"
        
    except Exception as e:
        return False, 0.0, f"terminology_error_{str(e)[:50]}"

def _is_concept_category_match(concept, expected_category: str) -> bool:
    """Check if a UMLS concept matches the expected clinical category"""
    
    # Map expected categories to UMLS semantic types (TUIs)
    category_tui_mapping = {
        "LAB_RESULT": {
            "T034",  # Laboratory or Test Result
            "T059",  # Laboratory Procedure  
            "T130",  # Indicator, Reagent, or Diagnostic Aid
            "T201",  # Clinical Attribute
        },
        "VITAL_SIGN": {
            "T201",  # Clinical Attribute
            "T033",  # Finding (for vital measurements)
            "T081",  # Quantitative Concept (for measurements)
        },
        "ALLERGY": {
            "T121",  # Pharmacologic Substance (drug allergies)
            "T109",  # Organic Chemical
            "T123",  # Biologically Active Substance
            "T168",  # Food (food allergies)
            "T167",  # Substance (general allergens)
        }
    }
    
    expected_tuis = category_tui_mapping.get(expected_category, set())
    concept_tuis = set(concept.tuis) if hasattr(concept, 'tuis') and concept.tuis else set()
    
    # Check for TUI overlap
    if concept_tuis.intersection(expected_tuis):
        return True
    
    # Additional semantic type name checks
    if hasattr(concept, 'semantic_types') and concept.semantic_types:
        semantic_types_lower = [st.lower() for st in concept.semantic_types]
        
        if expected_category == "LAB_RESULT":
            lab_keywords = ["laboratory", "test result", "clinical attribute", "diagnostic"]
            if any(keyword in " ".join(semantic_types_lower) for keyword in lab_keywords):
                return True
                
        elif expected_category == "VITAL_SIGN":
            vital_keywords = ["clinical attribute", "finding", "quantitative"]
            if any(keyword in " ".join(semantic_types_lower) for keyword in vital_keywords):
                return True
                
        elif expected_category == "ALLERGY":
            allergy_keywords = ["pharmacologic", "substance", "chemical", "food"]
            if any(keyword in " ".join(semantic_types_lower) for keyword in allergy_keywords):
                return True
    
    return False

def _calculate_terminology_confidence(concept, original_term: str) -> float:
    """Calculate confidence score based on terminology service match quality"""
    base_confidence = 0.7
    
    # Boost for exact name match
    if hasattr(concept, 'name') and concept.name.lower() == original_term.lower():
        base_confidence += 0.2
    
    # Boost for synonym match
    if hasattr(concept, 'synonyms') and concept.synonyms:
        synonym_match = any(syn.lower() == original_term.lower() for syn in concept.synonyms)
        if synonym_match:
            base_confidence += 0.15
    
    # Boost for ranking score if available
    if hasattr(concept, 'ranking_score') and concept.ranking_score:
        if concept.ranking_score > 0.8:
            base_confidence += 0.1
        elif concept.ranking_score > 0.6:
            base_confidence += 0.05
    
    # Boost for preferred terms
    if hasattr(concept, 'source') and concept.source == 'UMLS':
        base_confidence += 0.05
    
    return min(1.0, base_confidence)

def validate_with_terminology_service_sync(term: str, expected_category: str) -> tuple[bool, float, str]:
    """
    Synchronous fallback validation using local knowledge.
    Used when terminology service is not available.
    """
    
    # Local validation mappings for common terms
    local_lab_terms = {
        "glucose", "sodium", "potassium", "creatinine", "hemoglobin", "wbc", "tsh", 
        "troponin", "bnp", "hba1c", "cholesterol", "ldl", "hdl", "triglycerides",
        "alt", "ast", "bilirubin", "albumin", "calcium", "magnesium", "phosphorus"
    }
    
    local_vital_terms = {
        "blood pressure", "bp", "heart rate", "hr", "pulse", "temperature", "temp",
        "respiratory rate", "rr", "oxygen saturation", "o2 sat", "spo2", "weight", 
        "height", "bmi"
    }
    
    local_allergy_terms = {
        "penicillin", "amoxicillin", "sulfa", "aspirin", "ibuprofen", "latex", 
        "iodine", "contrast", "peanuts", "shellfish", "eggs", "milk", "soy"
    }
    
    term_lower = term.lower().strip()
    
    if expected_category == "LAB_RESULT" and term_lower in local_lab_terms:
        return True, 0.8, f"local_validation_{term_lower}"
    elif expected_category == "VITAL_SIGN" and term_lower in local_vital_terms:
        return True, 0.8, f"local_validation_{term_lower}"
    elif expected_category == "ALLERGY" and term_lower in local_allergy_terms:
        return True, 0.8, f"local_validation_{term_lower}"
    
    return False, 0.0, "not_in_local_validation"

def validate_clinical_context_rules() -> bool:
    """
    Validate that context rules are properly configured for clinical use.
    Returns True if all rules pass validation.
    """
    validation_errors = []
    
    # Check for overlapping termination and negation patterns
    termination_literals = {rule.literal for rule in TERMINATION_RULES}
    negation_literals = {rule.literal for rule in NEGATION_RULES}
    
    overlaps = termination_literals.intersection(negation_literals)
    if overlaps:
        validation_errors.append(f"Overlap between termination and negation rules: {overlaps}")
    
    # Check for reasonable max_scope values
    for rule in CONTEXT_RULES_LIST:
        if hasattr(rule, 'max_scope') and rule.max_scope:
            if rule.max_scope > 10:
                validation_errors.append(f"Rule '{rule.literal}' has unusually large scope: {rule.max_scope}")
            elif rule.max_scope < 1:
                validation_errors.append(f"Rule '{rule.literal}' has invalid scope: {rule.max_scope}")
    
    # Check for required negation patterns
    required_negation_patterns = ["denies", "no", "not", "negative for", "absent"]
    existing_negation_patterns = {rule.literal for rule in NEGATION_RULES}
    
    missing_patterns = set(required_negation_patterns) - existing_negation_patterns
    if missing_patterns:
        validation_errors.append(f"Missing required negation patterns: {missing_patterns}")
    
    if validation_errors:
        print("Context Rules Validation Errors:")
        for error in validation_errors:
            print(f"  - {error}")
        return False
    
    return True

def get_clinical_categories() -> Set[str]:
    """Return all valid clinical categories."""
    return {
        "CONDITION", "SYMPTOM", "FINDING", "DRUG", "PROCEDURE", 
        "LAB_RESULT", "VITAL_SIGN", "ANATOMY", "DEVICE", 
        "OBSERVATION", "SUBSTANCE", "MEASUREMENT", "IGNORE"
    }

def is_high_value_clinical_term(term: str) -> bool:
    """
    Check if a term is a high-value clinical concept that should never be ignored.
    Used for quality assurance in entity detection.
    """
    high_value_terms = {
        # Critical symptoms
        "chest pain", "shortness of breath", "abdominal pain", "severe pain",
        # Critical conditions  
        "myocardial infarction", "stroke", "heart attack", "cardiac arrest",
        "pulmonary embolism", "sepsis", "pneumonia", "heart failure",
        # Critical lab values
        "troponin", "bnp", "creatinine", "glucose", "a1c", "tsh",
        # Critical medications
        "insulin", "warfarin", "digoxin", "levothyroxine", "metformin"
    }
    
    return term.lower() in high_value_terms

# =============================================================================
# RULE STATISTICS AND MONITORING
# =============================================================================

def get_rule_statistics() -> Dict[str, int]:
    """Get statistics about loaded clinical rules."""
    return {
        "total_context_rules": len(CONTEXT_RULES_LIST),
        "negation_rules": len(NEGATION_RULES),
        "historical_rules": len(HISTORICAL_RULES),
        "hypothetical_rules": len(HYPOTHETICAL_RULES),
        "family_history_rules": len(FAMILY_HISTORY_RULES),
        "social_history_rules": len(SOCIAL_HISTORY_RULES),
        "termination_rules": len(TERMINATION_RULES),
        "section_rules": len(CLINICAL_SECTION_RULES),
        "clinical_term_overrides": len(CLINICAL_TERM_OVERRIDES),
        "tui_mappings": len(TUI_TO_CATEGORY),
        "semantic_type_mappings": len(STY_NAME_TO_CATEGORY_MAP),
        "pattern_rules": len(CLINICAL_PATTERN_RULES),
        "modifier_patterns": len(MODIFIER_PATTERNS),
    }

# Initialize validation on import
if __name__ == "__main__":
    if validate_clinical_context_rules():
        print("✅ Clinical context rules validation passed")
        stats = get_rule_statistics()
        print("📊 Rule Statistics:")
        for key, value in stats.items():
            print(f"  {key}: {value}")
    else:
        print("❌ Clinical context rules validation failed")