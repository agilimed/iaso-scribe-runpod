import os
import logging
from typing import List, Dict, Any, Optional
import re

import spacy

try:
    from config import SPACY_MODEL_NAME, ENABLE_FAMILY_SOCIAL_LINKER
except ImportError:
    SPACY_MODEL_NAME = os.getenv("SPACY_MODEL_NAME", "en_core_sci_lg")
    ENABLE_FAMILY_SOCIAL_LINKER = os.getenv("ENABLE_FAMILY_SOCIAL_LINKER", "true").lower() in ("1", "true", "yes")

from .rules import FAMILY_HISTORY_RULES, SOCIAL_HISTORY_RULES

logger = logging.getLogger("family_social_linker")
logger.setLevel(logging.INFO)

class SpacyModelSingleton:
    _instance = None
    @classmethod
    def get_model(cls):
        if cls._instance is None:
            try:
                cls._instance = spacy.load(SPACY_MODEL_NAME)
                logger.info(f"Loaded spaCy model: {SPACY_MODEL_NAME}")
            except Exception as e:
                logger.warning(f"Could not load spaCy model '{SPACY_MODEL_NAME}': {e}")
                cls._instance = spacy.blank("en")
        return cls._instance

# Helper for extracting numbers/ages in text
def extract_age(text: str) -> Optional[int]:
    # Match "at age 60", "aged 59", "55 years old", etc.
    age_patterns = [
        r'at age\s*(\d{1,3})',
        r'aged?\s*(\d{1,3})',
        r'(\d{1,3})\s*years?\s*old',
    ]
    for pat in age_patterns:
        m = re.search(pat, text, flags=re.IGNORECASE)
        if m:
            for g in m.groups():
                if g and g.isdigit():
                    return int(g)
    return None

def match_contextrule(sentence: str, rules: List) -> Optional[str]:
    """Finds first ConTextRule literal in sentence (case-insensitive). Returns literal or None."""
    for rule in rules:
        if rule.literal.lower() in sentence.lower():
            return rule.literal.lower()
    return None

def extract_condition(sentence: str, relation_literal: str, age: Optional[int]) -> str:
    """Roughly extracts the condition portion from a sentence containing a relation and (optional) age."""
    # Remove relation literal
    if relation_literal:
        sentence = re.sub(re.escape(relation_literal), '', sentence, flags=re.IGNORECASE)
    # Remove age if found
    if age:
        sentence = re.sub(r'(at age|aged?)\s*' + str(age), '', sentence, flags=re.IGNORECASE)
        sentence = re.sub(r'\b' + str(age) + r'\s*years?\s*old\b', '', sentence, flags=re.IGNORECASE)
    # Remove leading "with" / "diagnosed with"/"died of"
    sentence = re.sub(r'(diagnosed with|died of|with|of|from|history of)\s*', '', sentence, flags=re.IGNORECASE)
    return sentence.strip(" ,.-:")

def extract_family_social(text: str) -> List[Dict[str, Any]]:
    """
    Extracts structured family and social history from text using context rules.
    """
    nlp = SpacyModelSingleton.get_model()
    doc = nlp(text)
    results = []

    # FAMILY HISTORY
    for sent in doc.sents:
        sent_text = sent.text
        relation = match_contextrule(sent_text, FAMILY_HISTORY_RULES)
        if relation:
            age = extract_age(sent_text)
            condition = extract_condition(sent_text, relation, age)
            results.append({
                "history_type": "family",
                "relation": relation,
                "condition": condition if condition else None,
                "age": age,
                "span": [sent.start_char, sent.end_char]
            })

    # SOCIAL HISTORY
    for sent in doc.sents:
        sent_text = sent.text
        social_literal = match_contextrule(sent_text, SOCIAL_HISTORY_RULES)
        if social_literal:
            # Simple status extraction: look for "current", "former", "quit", "never", "occasionally", etc.
            status = None
            if re.search(r'current', sent_text, re.IGNORECASE): status = 'current'
            elif re.search(r'former|ex-|quit|previous', sent_text, re.IGNORECASE): status = 'former'
            elif re.search(r'never', sent_text, re.IGNORECASE): status = 'never'
            elif re.search(r'occasionally|social', sent_text, re.IGNORECASE): status = 'occasional'
            # Try to extract social "substance"/"factor" e.g. "smoking", "alcohol", "employed", "married"
            social_factor = social_literal
            # Optionally extract additional context (e.g. amount, years, packs, drinks, etc.)
            amount = None
            m = re.search(r'(\d+\s*(pack[- ]?years?|drinks?|years?))', sent_text, re.IGNORECASE)
            if m: amount = m.group(1)
            results.append({
                "history_type": "social",
                "factor": social_factor,
                "status": status,
                "amount": amount,
                "span": [sent.start_char, sent.end_char]
            })
    return results

def family_social_linker_pipeline(text: str, config: Optional[dict]=None) -> List[Dict[str, Any]]:
    enabled = ENABLE_FAMILY_SOCIAL_LINKER
    if config and "ENABLE_FAMILY_SOCIAL_LINKER" in config:
        enabled = config["ENABLE_FAMILY_SOCIAL_LINKER"]
    if not enabled:
        logger.info("Family/Social linker disabled by config/env.")
        return []
    return extract_family_social(text)
