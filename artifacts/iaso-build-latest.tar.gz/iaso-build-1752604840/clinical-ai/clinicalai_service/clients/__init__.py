# clinicalai_service/clients/__init__.py
from .terminology_client import TerminologyServiceClient
from .knowledge_client import KnowledgeServiceClient
from .template_client import TemplateServiceClient
from .llm_client import LLMServiceClient