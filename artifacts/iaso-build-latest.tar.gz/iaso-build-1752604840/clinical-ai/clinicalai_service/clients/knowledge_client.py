# clinicalai_service/clients/knowledge_client.py
import httpx
from typing import List, Dict, Any, Optional

from .. import config
from ..utils import logger
from ..models import StandardCode # Assuming StandardCode model is defined

class KnowledgeServiceClient:
    def __init__(self, base_url: Optional[str] = None, timeout: float = 10.0):
        self.base_url = base_url or config.KNOWLEDGE_SERVICE_URL
        if not self.base_url:
            logger.warning("KnowledgeService base_url not configured. Client may not function.")
        self.timeout = timeout
        self.client_name = "KnowledgeService"

    async def _request(self, method: str, endpoint: str, params: Optional[Dict] = None, json_data: Optional[Dict] = None) -> Any:
        if not self.base_url:
            logger.error(f"{self.client_name}: Base URL not set. Cannot make request to {endpoint}.")
            return None

        url = f"{self.base_url}{endpoint}"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.request(method, url, params=params, json=json_data)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"{self.client_name} HTTP error for {method} {url}: {e.response.status_code} - {e.response.text[:200]}")
        except httpx.RequestError as e:
            logger.error(f"{self.client_name} request error for {method} {url}: {e}")
        except Exception as e:
            logger.error(f"{self.client_name} generic error for {method} {url}: {e}", exc_info=True)
        return None

    async def get_standard_codes_for_cui(self, cui: str) -> List[StandardCode]:
        """
        Fetch standard codes (SNOMED, LOINC, RxNorm etc.) for a given UMLS CUI.
        """
        endpoint = f"/concepts/{cui}/codes" # Example: /api/v1/concepts/C0011849/codes
        logger.debug(f"{self.client_name}: Fetching standard codes for CUI '{cui}'.")
        response_data = await self._request("GET", endpoint)
        
        codes = []
        if response_data and isinstance(response_data, list): # Assuming KS returns a list of code objects
            for item in response_data:
                try:
                    codes.append(StandardCode(**item))
                except Exception as e:
                    logger.warning(f"{self.client_name}: Failed to parse standard code item: {item}. Error: {e}")
        logger.info(f"{self.client_name}: Found {len(codes)} standard codes for CUI '{cui}'.")
        return codes
        
    async def get_preferred_name_for_cui(self, cui: str) -> Optional[str]:
        """
        Fetch preferred name for a given UMLS CUI.
        This might be part of get_standard_codes_for_cui or a separate endpoint.
        Assuming it might be part of a general concept detail endpoint.
        """
        endpoint = f"/concepts/{cui}/preferred_name" # Example hypothetical endpoint
        # Or it could be: endpoint = f"/concepts/{cui}" and then parse "preferredName" from response
        logger.debug(f"{self.client_name}: Fetching preferred name for CUI '{cui}'.")
        response_data = await self._request("GET", endpoint) # Adjust based on actual KS API
        
        if response_data and isinstance(response_data, dict) and "preferred_name" in response_data:
            pref_name = response_data["preferred_name"]
            logger.info(f"{self.client_name}: Preferred name for CUI '{cui}' is '{pref_name}'.")
            return pref_name
        elif response_data and isinstance(response_data, str): # If endpoint directly returns the string
            logger.info(f"{self.client_name}: Preferred name for CUI '{cui}' is '{response_data}'.")
            return response_data
            
        logger.warning(f"{self.client_name}: Could not retrieve preferred name for CUI '{cui}'.")
        return None

    async def expand_abbreviation(self, abbr: str) -> Optional[str]:
        """
        Get expansion for an abbreviation.
        """
        endpoint = "/abbreviations/expand" # Example endpoint
        params = {"term": abbr}
        logger.debug(f"{self.client_name}: Expanding abbreviation '{abbr}'.")
        response_data = await self._request("GET", endpoint, params=params)

        if response_data and isinstance(response_data, dict) and "expansion" in response_data:
            expansion = response_data["expansion"]
            logger.info(f"{self.client_name}: Abbreviation '{abbr}' expanded to '{expansion}'.")
            return expansion
        logger.warning(f"{self.client_name}: Could not expand abbreviation '{abbr}'.")
        return None

    async def check_health(self) -> bool:
        endpoint = "/health"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                if not self.base_url: return False
                response = await client.get(f"{self.base_url}{endpoint}")
                return response.status_code == 200
        except Exception:
            return False