import httpx
import json
from typing import List, Dict, Any, Optional, Literal

from .. import config
from ..utils import logger
from ..models import BaseEntity

class LLMServiceClient:
    def __init__(self, 
                 base_url: Optional[str] = None, 
                 runpod_endpoint_id: Optional[str] = None,
                 api_key: Optional[str] = None,
                 timeout: float = float(config.LLM_TIMEOUT_SECONDS)):
        
        self.client_name = "LLMService"
        self.timeout = timeout
        self.is_runpod = False

        if config.RUNPOD_API_BASE and (runpod_endpoint_id or config.RUNPOD_ENDPOINT_ID):
            self.base_url = config.RUNPOD_API_BASE
            self.endpoint_id = runpod_endpoint_id or config.RUNPOD_ENDPOINT_ID
            self.api_key = api_key or config.RUNPOD_API_KEY
            if not self.endpoint_id or not self.api_key:
                logger.warning(f"{self.client_name}: RunPod configured but endpoint ID or API key is missing.")
            else:
                self.is_runpod = True
                logger.info(f"{self.client_name}: Configured for RunPod. Endpoint ID starts with: {self.endpoint_id[:10]}")
        elif base_url or config.LLM_SERVICE_URL:
            self.base_url = base_url or config.LLM_SERVICE_URL
            logger.info(f"{self.client_name}: Configured for generic LLM service URL: {self.base_url}")
        else:
            self.base_url = None
            logger.warning(f"{self.client_name}: LLM service URL/RunPod config not provided. Client will be non-functional.")

    async def _make_runpod_request(self, 
                                   # payload_content is the stuff that goes into "input": {"prompt": ..., "max_new_tokens": ...}
                                   payload_content: Dict[str, Any],  
                                   stream: bool = False) -> Optional[Dict[str, Any]]:
        if not self.base_url or not self.endpoint_id or not self.api_key:
            logger.error(f"{self.client_name} (RunPod): Client not fully configured.")
            return None
        run_verb = "runsync" if not stream else "run"
        url = f"{self.base_url.rstrip('/')}/{self.endpoint_id}/{run_verb}"
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        
        # The entire payload_content now goes under the "input" key for RunPod
        final_runpod_payload = {"input": payload_content}

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                logger.debug(f"{self.client_name} (RunPod): POST to {url} with payload: {str(final_runpod_payload)[:500]}...") # Log more
                response = await client.post(url, headers=headers, json=final_runpod_payload) 
                response.raise_for_status()
                response_json = response.json()
                logger.debug(f"{self.client_name} (RunPod): Response status {response.status_code}, Raw JSON: {str(response_json)[:500]}...") 
                return response_json
        except httpx.HTTPStatusError as e:
            logger.error(f"{self.client_name} (RunPod) HTTP error: {e.response.status_code} - {e.response.text[:200]} for URL {url}")
        except httpx.RequestError as e:
            logger.error(f"{self.client_name} (RunPod) request error for URL {url}: {e}")
        except json.JSONDecodeError as e:
            logger.error(f"{self.client_name} (RunPod) JSON decode error for URL {url}: {e}. Response text: {response.text[:200] if 'response' in locals() else 'N/A'}")
        except Exception as e:
            logger.error(f"{self.client_name} (RunPod) generic error for URL {url}: {e}", exc_info=True)
        return None

    async def _make_generic_request(self, endpoint: str, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        # This function remains the same, as generic LLMs might have different payload structures
        if not self.base_url:
            logger.error(f"{self.client_name} (Generic): Base URL not set for request to {endpoint}.")
            return None
        url = f"{self.base_url.rstrip('/')}{endpoint}"
        headers = {"Content-Type": "application/json"}
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                logger.debug(f"{self.client_name} (Generic): POST to {url} with payload: {str(payload)[:200]}...")
                response = await client.post(url, headers=headers, json=payload)
                response.raise_for_status()
                response_json = response.json()
                logger.debug(f"{self.client_name} (Generic): Response status {response.status_code}, JSON: {str(response_json)[:300]}...")
                return response_json
        except httpx.HTTPStatusError as e: logger.error(f"{self.client_name} (Generic) HTTP error: {e.response.status_code} - {e.response.text[:200]} for URL {url}")
        except httpx.RequestError as e: logger.error(f"{self.client_name} (Generic) request error for URL {url}: {e}")
        except json.JSONDecodeError as e: logger.error(f"{self.client_name} (Generic) JSON decode error for URL {url}: {e}. Response text: {response.text[:200] if 'response' in locals() else 'N/A'}")
        except Exception as e: logger.error(f"{self.client_name} (Generic) generic error for URL {url}: {e}", exc_info=True)
        return None


    async def generate_summary(self, text: str, context_entities: Optional[List[BaseEntity]] = None, 
                               # Use a parameter for max_new_tokens directly
                               max_summary_tokens: int = 400) -> Optional[str]: # Default to a reasonable summary length
        task_description = (
            "Generate a concise clinical summary of the following text. Focus on the main problems, findings, and plan. "
            "IMPORTANT: Do NOT include any information, conditions, or entities not explicitly mentioned in the provided 'Clinical Text'. "
            "Avoid speculation or adding external knowledge. The summary must be based SOLELY on the text provided."
        )
        prompt = f"{task_description}\n\nClinical Text:\n\"\"\"\n{text}\n\"\"\""
        if context_entities:
            entities_str = ", ".join(sorted(list(set(e.text.lower() for e in context_entities))))[:500] 
            prompt += f"\n\nKey entities previously identified (for context only, do not infer new information from this list beyond what's in the Clinical Text):\n{entities_str}"
        # Adjusted the desired word count to be more realistic for the token limit
        prompt += f"\n\nConcise Clinical Summary (aim for detailed but focused output, up to ~{int(max_summary_tokens / 1.5)} words, based ONLY on the provided text):"

        # This is the content that will go into RunPod's "input" field
        llm_input_content = {
            "prompt": prompt, 
            "max_output_tokens": max_summary_tokens, # Use the parameter here
            "temperature": 0.3
        }
        logger.debug(f"{self.client_name}: Requesting summary. Prompt (first 200 chars): {prompt[:200]}... Max new tokens: {max_summary_tokens}")
        
        raw_llm_response: Optional[Dict[str, Any]] = None
        if self.is_runpod:
            raw_llm_response = await self._make_runpod_request(llm_input_content)
        else:
            # For generic, the payload structure might be flat
            raw_llm_response = await self._make_generic_request("/summarize", llm_input_content)

        # ... (rest of summary parsing logic remains the same) ...
        if not raw_llm_response:
            logger.warning(f"{self.client_name}: No response received from LLM for summary.")
            return None
        summary_text = None
        try:
            if "output" in raw_llm_response:
                output_content = raw_llm_response["output"]
                if isinstance(output_content, str): summary_text = output_content
                elif isinstance(output_content, list) and len(output_content) > 0:
                    first_item = output_content[0]
                    if isinstance(first_item, dict):
                        if "generated_text" in first_item: summary_text = first_item["generated_text"]
                        elif "text" in first_item: summary_text = first_item["text"]
                        elif "choices" in first_item and isinstance(first_item["choices"], list) and len(first_item["choices"]) > 0:
                            choice = first_item["choices"][0]
                            if isinstance(choice, dict):
                                if "text" in choice: summary_text = choice["text"]
                                elif "message" in choice and isinstance(choice["message"], dict) and "content" in choice["message"]: summary_text = choice["message"]["content"]
                                elif "tokens" in choice and isinstance(choice["tokens"], list): summary_text = "".join(choice["tokens"])
            elif "summary_text" in raw_llm_response: summary_text = raw_llm_response["summary_text"]
            elif "generated_text" in raw_llm_response: summary_text = raw_llm_response["generated_text"]
        except Exception as e_parse:
            logger.warning(f"{self.client_name}: Error parsing summary from LLM response: {e_parse}. Raw: {str(raw_llm_response)[:300]}", exc_info=True)
            return None
        if summary_text:
            summary_text = summary_text.strip()
            common_prefixes = ["Summary:", "Here is a summary:", "Clinical Summary:", "Output:", "Answer:"]
            for prefix in common_prefixes:
                if summary_text.lower().startswith(prefix.lower()): summary_text = summary_text[len(prefix):].lstrip()
            if summary_text.startswith("```json"): summary_text = summary_text[len("```json"):].strip()
            if summary_text.startswith("```"): summary_text = summary_text[3:].strip()
            if summary_text.endswith("```"): summary_text = summary_text[:-3].strip()
            logger.info(f"{self.client_name}: Summary generated. Length: {len(summary_text)}")
            return summary_text
        else:
            logger.warning(f"{self.client_name}: Could not extract summary text from LLM response: {str(raw_llm_response)[:300]}")
            return None


    async def enhance_text_or_fill_gaps(self, 
                                        original_text: str, 
                                        task: Literal["fill_entities", "narrative_smoothing", "custom_prompt"],
                                        pre_detected_entities: Optional[List[BaseEntity]] = None,
                                        custom_prompt_template: Optional[str] = None,
                                        temperature: float = 0.05, 
                                        # Use a parameter for max_new_tokens directly
                                        max_fill_tokens: int = 700 # Default for entity lists, can be overridden
                                        ) -> Optional[Any]: 
        prompt_parts = []
        # Using the prompt that sends pre_detected_entities, as it's generally better if token limits allow
        if custom_prompt_template:
            # ... (custom prompt logic as before, ensure it builds `prompt`)
            prompt = custom_prompt_template.replace("{{original_text}}", original_text)
            if pre_detected_entities:
                entities_json_list = [
                    e.model_dump(include={'text', 'label', 'start_char', 'end_char', 
                                          'negated', 'historical', 'family_history', 'hypothetical', 
                                          'source_ner_engine', 'ner_confidence'}) 
                    for e in pre_detected_entities[:10] # Limit for prompt, can adjust
                ]
                prompt = prompt.replace("{{pre_detected_entities_json}}", json.dumps(entities_json_list, indent=2))
            else:
                prompt = prompt.replace("{{pre_detected_entities_json}}", "[]")
        else: 
            if task == "fill_entities":
                # Using the more robust prompt that includes pre_detected_entities context
                instruction = (
                    "You are an expert clinical entity extractor. Your task is to identify any additional clinical entities "
                    "(specifically: conditions, symptoms, findings, drugs, procedures, observations) from the 'Original Text' "
                    "that are NOT present in the 'Pre-detected Entities' list. "
                    "For each new entity you find, you MUST provide its exact 'entity_text', "
                    "a 'category' from the allowed list [CONDITION, DRUG, PROCEDURE, SYMPTOM, FINDING, OBSERVATION], "
                    "its 'start_char' and 'end_char' character offsets within the 'Original Text' (ensure these are accurate and zero-indexed), "
                    "and 'modifiers' as a dictionary with boolean keys: 'negated', 'historical', 'hypothetical', 'family_history'. "
                    "\nIMPORTANT: Output ONLY a single, valid JSON list of these newly identified entity objects. "
                    "If no additional entities are found, or if all entities in the text are already in 'Pre-detected Entities', "
                    "you MUST output an empty JSON list: []. "
                    "Do NOT include any explanations, apologies, conversational text, or any characters outside of the JSON list itself. "
                    "Ensure the JSON is well-formed (e.g., no trailing commas). YOUR RESPONSE MUST START WITH '[' AND END WITH ']'. DO NOT ADD ANY OTHER TEXT."
                )
                examples = """
Here are examples of the expected input and output format:

Example 1 (New entity):
Input:
Original Text:
\"\"\"
Patient c/o intermittent headache. Denies fever. Hx of T2DM.
\"\"\"
Pre-detected Entities (JSON):
[
  {
    "text": "fever",
    "label": "SYMPTOM",
    "start_char": 27,
    "end_char": 32,
    "negated": true,
    "historical": false,
    "family_history": false,
    "hypothetical": false,
    "source_ner_engine": "medcat",
    "ner_confidence": 0.9
  },
  {
    "text": "T2DM",
    "label": "CONDITION",
    "start_char": 43,
    "end_char": 47,
    "negated": false,
    "historical": true,
    "family_history": false,
    "hypothetical": false,
    "source_ner_engine": "medcat",
    "ner_confidence": 0.95
  }
]
Output (Additional Entities - JSON list or empty list []):
[
  {
    "entity_text": "headache",
    "category": "SYMPTOM",
    "start_char": 20,
    "end_char": 28,
    "modifiers": {"negated": false, "historical": false, "hypothetical": false, "family_history": false}
  }
]
---
Example 2 (No new entities):
Input:
Original Text:
\"\"\"
No signs of infection. Continue current meds.
\"\"\"
Pre-detected Entities (JSON):
[
  {
    "text": "infection",
    "label": "CONDITION",
    "start_char": 12,
    "end_char": 21,
    "negated": true,
    "historical": false,
    "family_history": false,
    "hypothetical": false,
    "source_ner_engine": "medcat",
    "ner_confidence": 0.88
  },
  {
    "text": "current meds",
    "label": "DRUG",
    "start_char": 31,
    "end_char": 43,
    "negated": false,
    "historical": false,
    "family_history": false,
    "hypothetical": false,
    "source_ner_engine": "spacy_ner",
    "ner_confidence": 0.7
  }
]
Output (Additional Entities - JSON list or empty list []):
[]
---
END OF EXAMPLES.

Now, process the following input and provide ONLY the JSON list as the output.

Input:
"""
                prompt_parts.append(instruction)
                prompt_parts.append(examples)

            elif task == "narrative_smoothing":
                prompt_parts.append("Rewrite the following clinical text segments into a coherent narrative, incorporating the listed entities naturally. Output only the smoothed narrative.")
            
            prompt_parts.append(f"Original Text:\n\"\"\"\n{original_text}\n\"\"\"")
            
            if task == "fill_entities" and pre_detected_entities: # Only add pre_detected_entities for fill_entities
                pre_detected_entities_for_prompt = []
                for e in pre_detected_entities[:15]: # Limit for prompt length
                    entity_dict = e.model_dump(include={'text', 'label', 'start_char', 'end_char', 'negated', 
                                                        'historical', 'family_history', 'hypothetical', 
                                                        'source_ner_engine', 'ner_confidence'})
                    pre_detected_entities_for_prompt.append(entity_dict)
                prompt_parts.append(f"\nPre-detected Entities (JSON):\n{json.dumps(pre_detected_entities_for_prompt, indent=2)}")
            
            prompt = "\n".join(prompt_parts)
            if task == "fill_entities":
                prompt += "\n\nOutput (Additional Entities - JSON list or empty list []):"
        
        # This is the content that will go into RunPod's "input" field
        llm_input_content = {
            "prompt": prompt, 
            "max_output_tokens": max_fill_tokens, # Use the parameter here
            "temperature": temperature
            # If other sampling params are needed, add them here, e.g. "top_p": 0.9
        }
        
        log_prompt_chars = 1500 if task == "fill_entities" else 500
        logger.debug(f"{self.client_name}: Requesting LLM for task '{task}'. Prompt (first {log_prompt_chars} chars): {prompt[:log_prompt_chars]}... Max new tokens: {max_fill_tokens}")
        if len(prompt) > log_prompt_chars:
            logger.debug(f"{self.client_name}: ... (prompt continues, total length: {len(prompt)})")

        raw_llm_response: Optional[Dict[str, Any]] = None
        if self.is_runpod:
            raw_llm_response = await self._make_runpod_request(llm_input_content)
        else: 
            # For generic, the payload structure might be flat
            generic_endpoint = f"/{task.replace('_', '-')}" 
            raw_llm_response = await self._make_generic_request(generic_endpoint, llm_input_content)

        # ... (rest of response parsing logic, same as before) ...
        if not raw_llm_response:
            logger.warning(f"{self.client_name}: No response received from LLM for task '{task}'.")
            return None
        parsed_output: Optional[Any] = None
        try:
            if "output" in raw_llm_response: 
                output_content = raw_llm_response["output"]
                if isinstance(output_content, str): parsed_output = output_content 
                elif isinstance(output_content, list) and output_content: 
                    first_item_output = output_content[0]
                    if isinstance(first_item_output, dict) and "choices" in first_item_output:
                        try:
                            full_token_string = "".join(first_item_output["choices"][0]["tokens"])
                            parsed_output = full_token_string
                            logger.debug(f"{self.client_name}: Extracted token string from RunPod choices: '{full_token_string[:200]}...'")
                        except (IndexError, KeyError, TypeError) as e_tok: logger.warning(f"{self.client_name}: Error accessing tokens from RunPod choices: {e_tok}. Content: {str(first_item_output)[:200]}")
                    elif task == "fill_entities" and all(isinstance(item, dict) for item in output_content): parsed_output = output_content
                    else: parsed_output = output_content 
                elif isinstance(output_content, dict): parsed_output = output_content
                else: logger.warning(f"{self.client_name}: Unexpected 'output' type for '{task}': {type(output_content)}. Content: {str(output_content)[:200]}")
            elif task == "fill_entities" and isinstance(raw_llm_response.get("entities"), list): parsed_output = raw_llm_response["entities"]
            elif (task == "narrative_smoothing" or task == "custom_prompt") and raw_llm_response.get("generated_text"): parsed_output = {"generated_text": raw_llm_response["generated_text"]}
            else: 
                if task == "fill_entities" and not (isinstance(raw_llm_response, str) or (isinstance(raw_llm_response, list) and all(isinstance(i,dict) for i in raw_llm_response))): logger.warning(f"{self.client_name}: For fill_entities, raw_llm_response is not string or list of dicts. Type: {type(raw_llm_response)}. Content: {str(raw_llm_response)[:200]}")
                else: parsed_output = raw_llm_response
        except Exception as e_parse: logger.warning(f"{self.client_name}: Error processing LLM response structure for task '{task}': {e_parse}. Raw: {str(raw_llm_response)[:300]}", exc_info=True)
        if parsed_output is not None:
            logger.info(f"{self.client_name}: LLM task '{task}' processed by client. Output type to main: {type(parsed_output)}, Content preview: {str(parsed_output)[:200]}")
            return parsed_output
        else:
            logger.warning(f"{self.client_name}: Could not effectively parse LLM response for task '{task}'. Raw: {str(raw_llm_response)[:300]}")
            return None

    async def check_health(self) -> bool:
        if not self.base_url: return False
        if self.is_runpod: return bool(self.endpoint_id and self.api_key) 
        else: 
            try:
                async with httpx.AsyncClient(timeout=5.0) as client:
                    response = await client.get(self.base_url.rstrip('/')) 
                    if response.status_code < 400: return True # Allow any 2xx or 3xx
                    
                    # Optional: try a specific health endpoint if the root fails
                    # response = await client.get(f"{self.base_url.rstrip('/')}/health") 
                    # return response.status_code == 200
                    return False 
            except Exception: 
                return False