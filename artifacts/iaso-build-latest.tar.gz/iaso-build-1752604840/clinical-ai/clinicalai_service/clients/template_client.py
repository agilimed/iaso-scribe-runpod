# clinicalai_service/clients/template_client.py
"""
Template Service Client
Handles communication with the template service for FHIR questionnaire definitions
"""

import httpx
from typing import Dict, Any, Optional
from .. import config
from ..utils import logger


class TemplateServiceClient:
    """
    Client for template service operations
    """
    
    def __init__(self, base_url: Optional[str] = None, timeout: float = 10.0):
        self.base_url = base_url or config.TEMPLATE_SERVICE_URL
        if not self.base_url:
            logger.warning("TemplateService base_url not configured.")
        self.timeout = timeout

    async def _request(self, method: str, endpoint: str, params: Optional[Dict] = None, json_data: Optional[Dict] = None) -> Any:
        """Make HTTP request to template service"""
        if not self.base_url:
            logger.error(f"TemplateService: Base URL not set. Cannot make request to {endpoint}.")
            return None

        url = f"{self.base_url}{endpoint}"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.request(method, url, params=params, json=json_data)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"TemplateService HTTP error for {method} {url}: {e.response.status_code}")
        except httpx.RequestError as e:
            logger.error(f"TemplateService request error for {method} {url}: {e}")
        except Exception as e:
            logger.error(f"TemplateService error for {method} {url}: {e}")
        return None

    async def get_template_definition(self, template_id: str) -> Optional[Dict[str, Any]]:
        """Get template definition by ID"""
        endpoint = f"/templates/{template_id}"
        logger.debug(f"Getting template definition for '{template_id}'")
        response_data = await self._request("GET", endpoint)
        
        if response_data:
            logger.debug(f"Retrieved template definition for '{template_id}'")
            return response_data
        else:
            logger.warning(f"Template definition not found for '{template_id}'")
            return None

    async def list_templates(self) -> Optional[Dict[str, Any]]:
        """List available templates"""
        endpoint = "/templates"
        logger.debug("Listing available templates")
        response_data = await self._request("GET", endpoint)
        
        if response_data:
            logger.debug(f"Retrieved {len(response_data.get('templates', []))} templates")
            return response_data
        return None

    async def check_health(self) -> bool:
        """Check template service health"""
        try:
            if not self.base_url:
                return False
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(f"{self.base_url}/health")
                return response.status_code == 200
        except Exception:
            return False