# clinicalai_service/clients/terminology_client.py
"""
Terminology Service Client - Production Version
Focused on core UMLS concept lookup and basic entity enhancement
Removed experimental semantic discovery features
"""

import httpx
import re
from typing import List, Dict, Any, Optional
from .. import config
from ..utils import logger
from ..models import Concept, NLPEntity


class TerminologyServiceClient:
    """
    Clean terminology service client for UMLS concept lookup
    """
    
    def __init__(self, base_url: Optional[str] = None, timeout: float = 10.0):
        self.base_url = base_url or config.TERMINOLOGY_SERVICE_URL
        if not self.base_url:
            logger.warning("TerminologyService base_url not configured.")
        self.timeout = timeout

    async def _request(self, method: str, endpoint: str, params: Optional[Dict] = None, json_data: Optional[Dict] = None) -> Any:
        """Make HTTP request to terminology service"""
        if not self.base_url:
            logger.error(f"TerminologyService: Base URL not set. Cannot make request to {endpoint}.")
            return None

        url = f"{self.base_url}{endpoint}"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.request(method, url, params=params, json=json_data)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"TerminologyService HTTP error for {method} {url}: {e.response.status_code}")
        except httpx.RequestError as e:
            logger.error(f"TerminologyService request error for {method} {url}: {e}")
        except Exception as e:
            logger.error(f"TerminologyService error for {method} {url}: {e}")
        return None

    # =================== CORE TERMINOLOGY METHODS ===================

    async def search_terms(self, term: str, limit: int = 5) -> List[Concept]:
        """Search for clinical terms in UMLS"""
        endpoint = "/search"
        params = {"term": term, "limit": limit, "source": "UMLS"}
        
        logger.debug(f"Searching for term '{term}'")
        response_data = await self._request("GET", endpoint, params=params)
        
        concepts = []
        if response_data and isinstance(response_data.get("results"), list):
            for item in response_data["results"]:
                try:
                    # Filter for UMLS concepts only
                    if item.get('source') == 'UMLS':
                        concepts.append(Concept(**item))
                except Exception as e:
                    logger.warning(f"Failed to parse concept: {e}")
                    
        logger.debug(f"Found {len(concepts)} UMLS concepts for '{term}'")
        return concepts

    async def resolve_cui(self, cui: str) -> Optional[Concept]:
        """Resolve a CUI to get detailed concept information"""
        endpoint = f"/concepts/{cui}"
        logger.debug(f"Resolving CUI '{cui}'")
        response_data = await self._request("GET", endpoint)
        
        if response_data:
            try:
                concept = Concept(**response_data)
                # Verify UMLS source
                if hasattr(concept, 'source') and concept.source == 'UMLS':
                    logger.debug(f"Resolved CUI '{cui}' to '{concept.name}'")
                    return concept
                else:
                    logger.debug(f"CUI '{cui}' source is not UMLS, skipping")
            except Exception as e:
                logger.warning(f"Failed to parse CUI resolution for '{cui}': {e}")
        return None

    async def check_health(self) -> bool:
        """Check terminology service health"""
        try:
            if not self.base_url:
                return False
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(f"{self.base_url}/health")
                return response.status_code == 200
        except Exception:
            return False

    # =================== BASIC ENTITY ENHANCEMENT ===================

    async def enhance_entities_with_terminology(
        self, 
        text: str, 
        basic_entities: List[NLPEntity]
    ) -> List[NLPEntity]:
        """
        Basic entity enhancement - looks for obvious clinical terms that were missed
        Simplified approach focused on high-precision pattern matching
        """
        logger.info(f"Starting basic terminology enhancement for {len(basic_entities)} entities")
        
        try:
            # Step 1: Find obvious clinical terms that were missed
            missed_terms = await self._find_missed_clinical_terms(text, basic_entities)
            
            # Step 2: Validate and create new entities
            new_entities = await self._create_validated_entities(missed_terms)
            
            total_entities = len(basic_entities) + len(new_entities)
            logger.info(f"Terminology enhancement: {len(basic_entities)} existing + {len(new_entities)} new = {total_entities} total")
            
            return basic_entities + new_entities
            
        except Exception as e:
            logger.error(f"Terminology enhancement failed: {e}")
            return basic_entities

    async def _find_missed_clinical_terms(self, text: str, existing_entities: List[NLPEntity]) -> List[Dict]:
        """Find obvious clinical terms using simple pattern matching"""
        existing_spans = {(e.start_char, e.end_char) for e in existing_entities}
        missed_terms = []
        
        # High-confidence clinical patterns
        clinical_patterns = [
            # Common symptoms (compound terms)
            r'\b(weight\s+(?:gain|loss))\b',
            r'\b(chest\s+pain)\b', 
            r'\b(shortness\s+of\s+breath)\b',
            r'\b(abdominal\s+pain)\b',
            r'\b(back\s+pain)\b',
            r'\b(joint\s+pain)\b',
            
            # Common lab tests
            r'\b(free\s+t4)\b',
            r'\b(free\s+t3)\b', 
            r'\b(blood\s+pressure)\b',
            r'\b(heart\s+rate)\b',
            
            # Common conditions
            r'\b(type\s+2\s+diabetes)\b',
            r'\b(high\s+blood\s+pressure)\b',
        ]
        logger.info(f"Testing pattern on text: '{text}'")
        for pattern in clinical_patterns:
            matches = list(re.finditer(pattern, text, re.IGNORECASE))
            logger.info(f"Pattern '{pattern}' found {len(matches)} matches: {[m.group(1) for m in matches]}")
            for match in re.finditer(pattern, text, re.IGNORECASE):
                start_pos, end_pos = match.span()
                
                # Skip if overlaps with existing entities
                if not any(self._spans_overlap(start_pos, end_pos, ex_start, ex_end) 
                          for ex_start, ex_end in existing_spans):
                    
                    term_text = match.group(1)
                    missed_terms.append({
                        "text": term_text,
                        "start_char": start_pos,
                        "end_char": end_pos,
                        "pattern_matched": True,
                        "confidence": 0.9  # High confidence for pattern matches
                    })
        logger.debug(f"Found {len(missed_terms)} missed clinical terms via patterns")
        return missed_terms

    async def _create_validated_entities(self, missed_terms: List[Dict]) -> List[NLPEntity]:
        """Create and validate new entities from missed terms"""
        new_entities = []
        
        for term_info in missed_terms:
            try:
                # Search for the term in terminology service
                concepts = await self.search_terms(term_info["text"], limit=1)
                
                if concepts:
                    concept = concepts[0]
                    
                    # Create new entity
                    entity = NLPEntity(
                        text=term_info["text"],
                        start_char=term_info["start_char"],
                        end_char=term_info["end_char"],
                        label="TERMINOLOGY_ENHANCED",
                        source_ner_engine="terminology_service",
                        ner_confidence=term_info.get("confidence", 0.8),
                        primary_cui=concept.id,
                        type_ids=concept.tuis if hasattr(concept, 'tuis') else [],
                        type_names=concept.semantic_types if hasattr(concept, 'semantic_types') else [],
                        section_title="terminology_enhancement"
                    )
                    
                    new_entities.append(entity)
                    logger.info(f"✅ Enhanced: '{term_info['text']}' -> {concept.id}")
                else:
                    logger.debug(f"No concept found for '{term_info['text']}'")
                    
            except Exception as e:
                logger.error(f"Error creating entity for '{term_info['text']}': {e}")
                continue
        
        return new_entities

    def _spans_overlap(self, start1: int, end1: int, start2: int, end2: int) -> bool:
        """Check if two spans overlap"""
        return not (end1 <= start2 or end2 <= start1)