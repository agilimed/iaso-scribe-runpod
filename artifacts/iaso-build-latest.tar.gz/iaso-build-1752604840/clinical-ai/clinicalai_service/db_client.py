# clinicalai_service/db_client.py
from typing import List, Any, Optional # Removed Dict as it wasn't used in function signatures
import os
import asyncpg

from .utils import logger # Assuming logger from utils is fine here

DB_POOL: Optional[asyncpg.Pool] = None

async def connect_db():
    global DB_POOL
    if DB_POOL and not DB_POOL._closed: # Check if already connected and not closed
        logger.info("Database connection pool already exists and is open.")
        return

    try:
        db_user = os.getenv("POSTGRES_USER") # Removed defaults, rely on .env
        db_password = os.getenv("POSTGRES_PASSWORD")
        db_name = os.getenv("POSTGRES_DB")
        db_host = os.getenv("PG_HOST_SRC") # Using your .env key
        db_port = os.getenv("PG_PORT")

        if not all([db_user, db_password, db_name, db_host, db_port]):
            logger.error("Database connection parameters missing in environment variables.")
            DB_POOL = None
            return

        logger.info(f"Attempting to connect to PostgreSQL: User '{db_user}', DB '{db_name}', Host '{db_host}', Port '{db_port}'")
        
        DB_POOL = await asyncpg.create_pool(
            user=db_user,
            password=db_password,
            database=db_name,
            host=db_host,
            port=db_port,
            min_size=1,
            max_size=10,
            timeout=10, # Connection timeout
            command_timeout=5 # Timeout for individual commands
        )
        # Test connection
        async with DB_POOL.acquire() as conn:
            await conn.execute("SELECT 1")
        logger.info("Database connection pool created and tested successfully for mapper.")

    except Exception as e:
        logger.error(f"Failed to create or test database connection pool: {e}", exc_info=True)
        DB_POOL = None # Ensure DB_POOL is None on any failure

async def close_db():
    global DB_POOL
    if DB_POOL and not DB_POOL._closed: # Check if pool exists and not already closed
        logger.info("Closing database connection pool...")
        try:
            await DB_POOL.close()
            logger.info("Database connection pool closed.")
        except Exception as e:
            logger.error(f"Error closing database connection pool: {e}", exc_info=True)
        finally:
            DB_POOL = None # Set to None after attempting to close
    elif DB_POOL and DB_POOL._closed:
        logger.info("Database connection pool was already closed.")
        DB_POOL = None
    else:
        logger.info("No active database connection pool to close.")


async def fetch_rows(query: str, *args) -> List[asyncpg.Record]:
    if not DB_POOL or DB_POOL._closed: # Check if pool is valid and open
        logger.error("DB_POOL not initialized or closed. Cannot fetch rows.")
        return []
    try:
        async with DB_POOL.acquire() as connection:
            rows = await connection.fetch(query, *args)
            return rows
    except Exception as e:
        logger.error(f"Database query failed: {query} with args {args}. Error: {e}", exc_info=True)
        return []