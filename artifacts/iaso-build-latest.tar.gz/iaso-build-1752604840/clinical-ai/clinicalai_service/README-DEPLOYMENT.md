# Clinical AI Service: Deployment Guide

## System Requirements

### Hardware Requirements

- **CPU**: 4+ cores recommended (2 minimum)
- **RAM**: 8GB+ recommended (4GB minimum)
- **Storage**: 
  - 2GB for application code
  - 2GB+ for logs
  - 2GB+ for model files
  - Total: 6GB+ recommended

### Software Requirements

- **Operating System**: Linux (Ubuntu 20.04+ recommended), macOS, or Windows
- **Python**: 3.10 or higher
- **PostgreSQL**: 13+ (for mapping configuration)
- **External Dependencies**:
  - Access to Terminology Service
  - Access to Template Service (optional)
  - Access to LLM Service (optional)

## Installation Guide

### Setting Up the Environment

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/your-organization/nexus-care-ai-backend.git
   cd nexus-care-ai-backend
   ```

2. **Create Python Virtual Environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Linux/macOS
   # venv\Scripts\activate    # On Windows
   ```

3. **Install Dependencies**:
   ```bash
   pip install -r clinicalai_service/requirements.txt
   ```

4. **Install spaCy Model**:
   The en_core_sci_lg model should be installed from the local file:
   ```bash
   pip install clinicalai_service/installs/en_core_sci_lg-0.5.4.tar.gz.tar
   ```

5. **Install MedCAT**:
   ```bash
   pip install git+https://github.com/CogStack/MedCAT.git@v1.16.0 --no-deps
   ```

### Configuration

Create a `.env` file in the root directory with the following settings:

```dotenv
# Service Configuration
CLINICAL_AI_SERVICE_PORT=8002
LOG_LEVEL=INFO
LOG_FILE_PATH=logs/clinicalai_service.log
UVICORN_RELOAD=false

# NLP Engine Configuration
SPACY_MODEL=en_core_sci_lg
DEFAULT_NER_ENGINE=medcat
MEDCAT_MODEL_PACK_ROOT=/path/to/medcat_model_pack

# External Service URLs
TERMINOLOGY_SERVICE_URL=http://localhost:8001
TEMPLATE_SERVICE_URL=http://localhost:8003
LLM_SERVICE_URL=http://localhost:8004

# Database Configuration
PG_HOST_MAPPER=localhost
PG_PORT_MAPPER=5432
PG_DATABASE_MAPPER=nexus_care
PG_USER_MAPPER=postgres
PG_PASSWORD_MAPPER=your_password

# FHIR System URIs
FHIR_SYS_URI_SNOMED=http://snomed.info/sct
FHIR_SYS_URI_RXNORM=http://www.nlm.nih.gov/research/umls/rxnorm
FHIR_SYS_URI_LOINC=http://loinc.org
```

### MedCAT Model Setup

MedCAT requires these model files in a dedicated directory:

1. **Create the model directory**:
   ```bash
   mkdir -p /path/to/medcat_model_pack
   ```

2. **Required MedCAT files**:
   - `cdb.dat` - Concept Database
   - `vocab.dat` - Vocabulary
   - `config.json` - Configuration
   - `tui2name.tsv` - TUI to name mapping

3. **Copy these files to the model directory**:
   Ensure these files are available from your model provider or training process.

### Database Setup

1. **Create the PostgreSQL database**:
   ```sql
   CREATE DATABASE nexus_care;
   ```

2. **Create the schema**:
   ```sql
   \c nexus_care
   CREATE SCHEMA clinical_consolidated;
   ```

3. **Create the tables**:
   ```sql
   CREATE TABLE clinical_consolidated.nlp_answer_configs (
     id SERIAL PRIMARY KEY,
     answer_type VARCHAR(50) NOT NULL,
     format_template JSONB NOT NULL,
     description TEXT
   );

   CREATE TABLE clinical_consolidated.template_nlp_mappings (
     id SERIAL PRIMARY KEY,
     template_id VARCHAR(100) NOT NULL,
     mapping_name VARCHAR(100) NOT NULL,
     description TEXT,
     active BOOLEAN DEFAULT TRUE
   );

   CREATE TABLE clinical_consolidated.nlp_mapping_rules (
     id SERIAL PRIMARY KEY,
     mapping_id INTEGER REFERENCES clinical_consolidated.template_nlp_mappings(id),
     questionnaire_item_linkid VARCHAR(100) NOT NULL,
     answer_config_id INTEGER REFERENCES clinical_consolidated.nlp_answer_configs(id),
     rule_priority INTEGER DEFAULT 100,
     active BOOLEAN DEFAULT TRUE
   );

   CREATE TABLE clinical_consolidated.nlp_rule_criteria (
     id SERIAL PRIMARY KEY,
     rule_id INTEGER REFERENCES clinical_consolidated.nlp_mapping_rules(id),
     criterion_type VARCHAR(50) NOT NULL,
     criterion_value TEXT NOT NULL
   );
   ```

4. **Insert basic answer configurations**:
   ```sql
   INSERT INTO clinical_consolidated.nlp_answer_configs 
   (answer_type, format_template, description)
   VALUES 
   ('string', '{"answer": [{"value": "{{entity.text}}"}]}', 'Basic string answer'),
   ('coding', '{"answer": [{"valueCoding": {"code": "{{entity.standard_codes[0].code}}", "system": "{{entity.standard_codes[0].vocabulary_uri}}", "display": "{{entity.standard_codes[0].display}}"}}]}', 'Standard coding answer');
   ```

## Deployment Options

### Option 1: Standalone Service

1. **Run with Uvicorn**:
   ```bash
   cd nexus-care-ai-backend
   source venv/bin/activate
   uvicorn clinicalai_service.main:app --host 0.0.0.0 --port 8002
   ```

2. **Run as a systemd service** (Linux):
   Create a systemd service file:
   ```
   [Unit]
   Description=Clinical AI Service
   After=network.target

   [Service]
   User=your_user
   WorkingDirectory=/path/to/nexus-care-ai-backend
   Environment="PATH=/path/to/nexus-care-ai-backend/venv/bin"
   ExecStart=/path/to/nexus-care-ai-backend/venv/bin/uvicorn clinicalai_service.main:app --host 0.0.0.0 --port 8002

   [Install]
   WantedBy=multi-user.target
   ```

   Then enable and start the service:
   ```bash
   sudo systemctl enable clinicalai_service
   sudo systemctl start clinicalai_service
   ```

### Option 2: Docker Container

1. **Create a Dockerfile**:
   ```dockerfile
   FROM python:3.10-slim

   WORKDIR /app

   COPY requirements.txt .
   RUN pip install --no-cache-dir -r requirements.txt

   COPY clinicalai_service ./clinicalai_service

   # Install MedCAT separately
   RUN pip install git+https://github.com/CogStack/MedCAT.git@v1.16.0 --no-deps

   # Create directories for models and logs
   RUN mkdir -p /app/logs /app/models

   # Copy model files
   COPY clinicalai_service/installs/en_core_sci_lg-0.5.4.tar.gz.tar /app/models/
   RUN pip install /app/models/en_core_sci_lg-0.5.4.tar.gz.tar

   # Set environment variables
   ENV CLINICAL_AI_SERVICE_PORT=8002
   ENV LOG_LEVEL=INFO
   ENV LOG_FILE_PATH=/app/logs/clinicalai_service.log
   ENV SPACY_MODEL=en_core_sci_lg
   ENV DEFAULT_NER_ENGINE=medcat
   ENV MEDCAT_MODEL_PACK_ROOT=/app/models/medcat_model_pack

   EXPOSE 8002

   CMD ["uvicorn", "clinicalai_service.main:app", "--host", "0.0.0.0", "--port", "8002"]
   ```

2. **Build and run the Docker container**:
   ```bash
   docker build -t clinicalai-service:latest .
   docker run -d -p 8002:8002 \
     -v /path/to/medcat_model_pack:/app/models/medcat_model_pack \
     -v /path/to/logs:/app/logs \
     --env-file .env \
     --name clinicalai-service clinicalai-service:latest
   ```

### Option 3: Kubernetes Deployment

1. **Create a Kubernetes deployment YAML**:
   ```yaml
   apiVersion: apps/v1
   kind: Deployment
   metadata:
     name: clinicalai-service
     labels:
       app: clinicalai-service
   spec:
     replicas: 1
     selector:
       matchLabels:
         app: clinicalai-service
     template:
       metadata:
         labels:
           app: clinicalai-service
       spec:
         containers:
         - name: clinicalai-service
           image: clinicalai-service:latest
           ports:
           - containerPort: 8002
           env:
           - name: CLINICAL_AI_SERVICE_PORT
             value: "8002"
           - name: LOG_LEVEL
             value: "INFO"
           # Add other environment variables from ConfigMap or Secrets
           volumeMounts:
           - name: model-volume
             mountPath: /app/models/medcat_model_pack
           - name: logs-volume
             mountPath: /app/logs
         volumes:
         - name: model-volume
           persistentVolumeClaim:
             claimName: model-volume-claim
         - name: logs-volume
           persistentVolumeClaim:
             claimName: logs-volume-claim
   ```

2. **Create a Kubernetes service YAML**:
   ```yaml
   apiVersion: v1
   kind: Service
   metadata:
     name: clinicalai-service
   spec:
     selector:
       app: clinicalai-service
     ports:
     - port: 8002
       targetPort: 8002
     type: ClusterIP
   ```

## Health Monitoring

### Logging

- Logs are written to the path specified in `LOG_FILE_PATH`
- Use `logrotate` for log rotation in production

### Health Check Endpoint

- The `/health` endpoint provides service status
- Set up monitoring to check this endpoint regularly

### Performance Metrics

- Response timing metrics are included in every API response
- Consider adding Prometheus metrics for more detailed monitoring

## Security Considerations

1. **API Security**:
   - Deploy behind an API Gateway with authentication
   - Use HTTPS/TLS for all communications

2. **Sensitive Data**:
   - No PHI is stored within the service
   - Use environment variables or secure vaults for credentials

3. **Database Security**:
   - Use strong PostgreSQL passwords
   - Consider database connection encryption

## Scaling Considerations

1. **Horizontal Scaling**:
   - The service is stateless and can be scaled horizontally
   - Ensure each instance has access to model files

2. **Database Scaling**:
   - Consider connection pooling for PostgreSQL
   - Monitor database performance under load

3. **Memory Management**:
   - NLP models require significant memory
   - Monitor memory usage and adjust container resources accordingly

## Troubleshooting

### Common Deployment Issues

| Issue | Possible Solution |
|-------|------------------|
| Service fails to start | Check Python version and module dependencies |
| MedCAT model not found | Verify MEDCAT_MODEL_PACK_ROOT path and file permissions |
| Database connection issues | Check PostgreSQL credentials and network connectivity |
| High memory usage | Increase container memory limits or reduce concurrency |

### Log Files

Important log messages to watch for:
- "ClinicalAIService startup complete" - Successful initialization
- "CRITICAL from config.py: MEDCAT_MODEL_PACK_DIR does not exist" - Model path issues
- "Error loading MedCAT model" - Model loading failures

---

*For additional support, contact the development team.* 