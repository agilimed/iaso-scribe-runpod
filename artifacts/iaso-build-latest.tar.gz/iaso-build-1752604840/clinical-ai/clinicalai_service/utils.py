# clinicalai_service/utils.py
import logging
import os
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from . import config # Uses the config.py from the same package
from typing import Optional, List, Dict, Any # Ensure these are present
from .models import StandardCode # Assuming StandardCode is in models.py

def setup_logging():
    # Ensure logs directory exists
    config.LOGS_DIR.mkdir(parents=True, exist_ok=True)

    # Create timestamped log file name
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base_log_name = Path(config.LOG_FILE_PATH).stem  # Get filename without extension
    log_extension = Path(config.LOG_FILE_PATH).suffix or ".log"
    
    # Create new log file with timestamp: clinicalai_service_20241201_143022.log
    timestamped_log_name = f"{base_log_name}_{timestamp}{log_extension}"
    timestamped_log_path = config.LOGS_DIR / timestamped_log_name
    
    # Also create a symlink to the latest log for easy access
    latest_log_path = config.LOGS_DIR / f"{base_log_name}_latest{log_extension}"
    
    # Configure logging to timestamped file with rotation
    file_handler = RotatingFileHandler(
        timestamped_log_path,
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(module)s:%(lineno)d - %(message)s'
    ))

    # Configure console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    ))

    # Configure root logger
    root_logger = logging.getLogger()
    log_level_numeric = getattr(logging, config.LOG_LEVEL, logging.INFO)
    root_logger.setLevel(log_level_numeric)

    # Clear existing handlers (important if uvicorn/FastAPI adds its own)
    if root_logger.hasHandlers():
        root_logger.handlers.clear()

    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    # Set levels for noisy libraries
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.error").setLevel(logging.INFO)

    # Create/update symlink to latest log file (for easy access)
    try:
        if latest_log_path.exists() or latest_log_path.is_symlink():
            latest_log_path.unlink()  # Remove existing symlink
        latest_log_path.symlink_to(timestamped_log_path.name)  # Create new symlink
    except Exception as e:
        # Symlink creation might fail on some systems, but it's not critical
        pass

    logger_instance = logging.getLogger(__name__) # Get logger for this module
    logger_instance.info("=" * 80)
    logger_instance.info(f"🚀 CLINICAL AI SERVICE STARTED - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger_instance.info("=" * 80)
    logger_instance.info(f"📝 Log Level: {config.LOG_LEVEL}")
    logger_instance.info(f"📁 Log File: {timestamped_log_path}")
    logger_instance.info(f"🔗 Latest Log: {latest_log_path}")
    logger_instance.info(f"🏥 Service Version: {getattr(config, 'SERVICE_VERSION', 'Unknown')}")
    logger_instance.info(f"🧠 NLP Engine: {getattr(config, 'DEFAULT_NER_ENGINE', 'Unknown')}")
    logger_instance.info(f"🤖 ClinicalBERT: {'Enabled' if getattr(config, 'ENABLE_CLINICAL_BERT', False) else 'Disabled'}")
    logger_instance.info("=" * 80)
    
    return logger_instance

logger = setup_logging()

def generate_request_id() -> str:
    """Generates a unique request ID."""
    import uuid
    return str(uuid.uuid4())

def get_fhir_system_uri(vocabulary_key: str) -> Optional[str]:
    """Gets FHIR system URI for a given vocabulary key."""
    return config.FHIR_SYSTEM_URIS.get(vocabulary_key.upper())

FHIR_CODING_SYSTEM_MAP = {
    # Clinical Coding Standards
    "SNOMEDCT_US": "http://snomed.info/sct",
    "SNOMED": "http://snomed.info/sct",
    "RXNORM": "http://www.nlm.nih.gov/research/umls/rxnorm",
    "LOINC": "http://loinc.org",
    "ICD10CM": "http://hl7.org/fhir/sid/icd-10-cm",
    "ICD10": "http://hl7.org/fhir/sid/icd-10",
    "ICD9CM": "http://hl7.org/fhir/sid/icd-9-cm",
    "MTHICD9": "http://hl7.org/fhir/sid/icd-9-cm",
    "CPT": "http://www.ama-assn.org/go/cpt",
    "HCPCS": "http://www.cms.gov/Medicare/Coding/HCPCSReleaseCodeSets",
    "UMLS": "urn:oid:2.16.840.1.113883.6.86",

    # Ontologies and Biomedical Vocabularies
    "FMA": "http://purl.org/sig/ont/fma.owl",
    "LNC": "http://loinc.org",
    "MESH": "http://www.nlm.nih.gov/mesh",
    "MSH": "http://www.nlm.nih.gov/mesh",
    "NCI": "http://ncit.nci.nih.gov",
    "CHV": "urn:oid:2.16.840.1.113883.6.59",  # Consumer Health Vocabulary
    "HPO": "http://purl.obolibrary.org/obo/hp.owl",
    "OMIM": "https://omim.org",
    "ATC": "http://www.whocc.no/atc",
    "DRUGBANK": "http://www.drugbank.ca",
    "MEDDRA": "http://www.meddra.org",
    "NDFRT": "http://www.nlm.nih.gov/research/umls/ndfrt",
    "SNOMEDCT_VET": "http://snomed.info/sct/11000146104",  # Veterinary extension
    "HL7V3.0": "urn:oid:2.16.840.1.113883.5.1",
    "NDFRT_FDA": "http://fdasis.nlm.nih.gov",
    "SCTSPA": "http://snomed.info/sct",  # Spanish SNOMEDCT
    "ICPC2P": "http://www.who.int/classifications/icd/adaptations/icpc2",
    "CVX": "http://hl7.org/fhir/sid/cvx",
    "UNII": "http://fdasis.nlm.nih.gov",
    "NUBC": "http://www.nubc.org/patient-discharge",
    "MTH": "urn:oid:2.16.840.1.113883.6.233",  # MetaThesaurus internal codes
    "SCT": "http://snomed.info/sct",  # Alias
}

FHIR_CODING_SYSTEM_MAP.update({k: v for k, v in config.FHIR_SYSTEM_URIS.items() if v})


def create_fhir_coding(code: str, system_key: str, display: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """
    Creates a FHIR Coding dictionary.
    system_key is a short key like 'SNOMEDCT_US', 'LOINC', etc.
    """
    system_uri = FHIR_CODING_SYSTEM_MAP.get(system_key.upper())
    if not system_uri:
        logger.warning(f"No FHIR system URI found for system key: {system_key}. Cannot create FHIR Coding.")
        # Fallback: try to use the key as URI if it looks like one
        if "http" in system_key or "urn:" in system_key:
            system_uri = system_key
        else:
            return None
            
    coding = {"system": system_uri, "code": code}
    if display:
        coding["display"] = display
    return coding

def create_fhir_codeable_concept(
    text: Optional[str] = None, 
    codings: Optional[List[Dict[str, Any]]] = None
) -> Optional[Dict[str, Any]]:
    """
    Creates a FHIR CodeableConcept dictionary.
    'codings' should be a list of FHIR Coding dictionaries.
    """
    if not text and not codings:
        return None
        
    codeable_concept = {}
    if codings:
        codeable_concept["coding"] = [c for c in codings if c is not None] # Filter out None codings
    if text:
        codeable_concept["text"] = text
    
    # Ensure there's at least one coding or text for it to be valid
    if not codeable_concept.get("coding") and not codeable_concept.get("text"):
        return None
        
    return codeable_concept

def get_standard_code_for_systems(
    standard_codes: List[StandardCode], 
    system_priority: List[str]
) -> Optional[StandardCode]:
    """
    Selects a StandardCode based on a priority list of vocabulary systems.
    system_priority: e.g., ["SNOMEDCT_US", "ICD10CM", "RXNORM"]
    """
    if not standard_codes or not system_priority:
        return None
    
    for system_key in system_priority:
        for sc in standard_codes:
            if sc.vocabulary.upper() == system_key.upper():
                return sc
    return None # Or return the first available if no priority match