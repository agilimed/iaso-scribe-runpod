# Clinical AI Service (`clinicalai_service`)

**Version:** 0.1.0 <!-- Update this version as you iterate -->

---

## 🧠 Overview

The **Clinical AI Service** is a Python-based microservice that processes unstructured clinical notes, extracts meaningful clinical information, and structures it into **FHIR-compliant** documentation. It combines MedCAT and spaCy NLP engines with a terminology enrichment layer and a data-driven template mapping engine for generating `QuestionnaireResponse` resources.

---

## ✨ Core Features

- **NLP Engine**
  - Named Entity Recognition using UMLS-trained MedCAT and/or spaCy (`en_core_sci_lg`)
  - Contextual analysis (negation, temporality, section detection) via MedSpaCy
- **Entity Enrichment**
  - Link entities to SNOMED CT, RxNorm, LOINC, ICD-10, and UMLS using a Meilisearch-backed Terminology Service
- **FHIR Structuring**
  - Generate `QuestionnaireResponse` using templates and config-based entity mappings stored in PostgreSQL
- **Summarisation (Optional)**
  - Invoke a Small Language Model (e.g., Phi-3 Mini) to generate summaries of the note
- **Modular Design**
  - All components are built for easy replacement and standalone testing

---

## 🧱 Architecture & Processing Pipeline

1. **Input**: Unstructured clinical note (and optional `template_id`)
2. **NLP Processing**: Entity recognition, context detection, section parsing
3. **Terminology Enrichment**: Retrieve preferred names and codes via external service
4. **Template Mapping** (if `template_id` provided):
   - Fetch FHIR `Questionnaire` from Template Service
   - Query mapping rules from PostgreSQL
   - Populate answers using `config_driven_mapper`
5. **LLM Summarisation** (optional): Generate a summary of the clinical note
6. **Output**: JSON containing entities, FHIR `QuestionnaireResponse`, summary, and diagnostics

---

## 📁 Project Structure

```bash
clinicalai_service/
├── __init__.py
├── config.py                # Loads .env and config variables
├── main.py                  # FastAPI app entry point
├── models.py                # Pydantic models
├── utils.py                 # Utilities and helpers
├── db_client.py             # PostgreSQL interface
├── clients/                 # External services
│   ├── terminology_client.py
│   ├── template_client.py
│   └── llm_client.py
├── nlp_engine/
│   ├── processor.py         # NLP pipeline orchestration
│   └── rules.py             # MedSpaCy rules and mappings
└── fhir_templating/
    ├── config_models.py     # Pydantic DB models
    └── config_driven_mapper.py
```

---

## ⚙️ Setup and Installation

### ✅ Prerequisites

- Python 3.10+
- PostgreSQL
- Meilisearch
- MedCAT model pack (optional, for full functionality)
- Access to LLM, Template, and Terminology services

### 📦 Installation Steps

```bash
git clone <your-repo>
cd NEXUS-CARE-AI-BACKEND/
python -m venv venv
source venv/bin/activate  # For Linux/macOS
# venv\Scriptsctivate   # For Windows

pip install -r requirements.txt
python -m spacy download en_core_sci_lg
```

---

## 🌍 Environment Variables

Create a `.env` file in the root with:

```dotenv
CLINICAL_AI_SERVICE_PORT=8002
LOG_LEVEL=INFO
LOG_FILE_PATH=logs/clinicalai_service.log

# CORS configuration (comma-separated list of allowed origins, or "*" for all)
CORS_ORIGINS="http://localhost:3000,https://example.com"

SPACY_MODEL="en_core_sci_lg"
DEFAULT_NER_ENGINE="medcat"
MEDCAT_MODEL_PACK_FOLDER_NAME="medcat_model_pack_custom"

TERMINOLOGY_SERVICE_URL="http://localhost:8001"
TEMPLATE_SERVICE_URL="http://localhost:XXXX"
LLM_SERVICE_URL="http://localhost:YYYY"

PG_USER_MAPPER="your_user"
PG_PASSWORD_MAPPER="your_pass"
PG_DATABASE_MAPPER="your_db"
PG_HOST_MAPPER="localhost"
PG_PORT_MAPPER="5432"
```

---

## 🚀 Running the Service

```bash
uvicorn clinicalai_service.main:app --host 0.0.0.0 --port 8002 --reload
```

The service will be available at `http://localhost:8002`.

---

## 🔌 API Endpoints

### `POST /process`

Processes a clinical note.

#### Request

```json
{
  "text": "Patient presents with fever and cough...",
  "template_id": "soap-note-general",
  "patient_ref": "Patient/123",
  "encounter_ref": "Encounter/456",
  "author_ref": "Practitioner/789",
  "perform_summarization": true,
  "perform_structuring": true,
  "use_llm_for_gap_filling": false
}
```

#### Response

```json
{
  "request_id": "uuid",
  "enriched_entities": [...],
  "fhir_qr": {...},
  "summary_text": "Summary...",
  "errors": [],
  "warnings": [],
  "timing_metrics_ms": {...}
}
```

---

### `GET /health`

Returns status of service and dependencies.

---

## 🗃️ Mapping Rules Database Schema (PostgreSQL)

Located under schema: `clinical_consolidated`

- `nlp_answer_configs`
- `template_nlp_mappings`
- `nlp_mapping_rules`
- `nlp_rule_criteria`

See SQL setup file or sample insert scripts in this README for setup.

---

## 🧪 Development & Testing

- Unit tests: Recommended for `config_driven_mapper.py`
- Integration tests for `/process` with various templates
- Scripts:
  - `test_medcat_google.py` for MedCAT + spaCy testing
- Logs:
  - Available at path set by `LOG_FILE_PATH`

---

## 🛠️ Troubleshooting

- **`ModuleNotFoundError`**: Activate your virtual environment
- **MedCAT model not loading**: Check `.env` paths and file permissions
- **Database errors**: Ensure PostgreSQL is accessible with correct credentials
- **LLM/Template/Terminology service errors**: Check service logs and `.env` URLs
- **MedSpaCy section error**: Use `.body_span` or `.title_span`, not `.span`

---

## 📌 Future Enhancements

- Improve de-duplication of entities
- Full support for all criterion types and FHIR answer formats
- Add Redis/TTL caching
- Admin UI for managing rules
- Entity gap filling via LLMs
- Enhanced test coverage

---

## 📄 How to Use This README

1. Save as `README.md` in your repo root.
2. Replace placeholder values.
3. Add SQL scripts or architectural diagrams as needed.
4. Keep it up to date as your service evolves.

---

© AgiliMed — Clinical AI Service | Powered by modular NLP and FHIR
