# clinicalai_service/main.py
import time
import asyncio
import json
import numpy as np
from fastapi import FastAPI, HTTPException, Request, status, Depends
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import sys
import os
# Add parent directory to path for shared modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from shared.security import setup_security, verify_token, limiter
from typing import Optional, List, Dict, Any 
import re
from spacy.tokens import Doc
from . import config as app_config
from . import db_client 
from .nlp_engine.modifier_linker import modifier_linker_pipeline
from .nlp_engine.family_social_linker import family_social_linker_pipeline
from .nlp_engine.lab_exam_allergy_linker import lab_exam_allergy_linker_pipeline, lab_exam_allergy_linker_pipeline_async
from .utils import (
    logger, generate_request_id, 
    create_fhir_coding, create_fhir_codeable_concept, FHIR_CODING_SYSTEM_MAP 
)
from .models import (
    ClinicalNoteInput, ProcessingOutput, HealthStatusResponse, 
    FHIRQuestionnaireResponsePayload, SummaryPayload, BaseEntity,
    EnrichedEntity, StandardCode, Concept, NLPEntity, AuditTrailEntry,
    # New models for ClinicalBERT
    EmbeddingRequest, EmbeddingResponse, SimilarityRequest, SimilarityResponse,
    ModelComparisonRequest, ModelComparisonResponse, ClinicalBERTStatusResponse,
    ClinicalBERTModelOption
)
from .nlp_engine import processor as nlp_processor
from .nlp_engine.clinical_bert import get_dynamic_clinical_bert
from .clients.terminology_client import TerminologyServiceClient
from .clients.template_client import TemplateServiceClient
from .clients.llm_client import LLMServiceClient
from .fhir_templating import config_driven_mapper
from .nlp_engine.processor import (
    get_entity_clinical_category,
    enhance_fallback_with_terminology,
    filter_non_clinical_entities,
    extract_compound_entities
)
from concurrent.futures import ThreadPoolExecutor
from .concurrent_processor import get_concurrent_processor

# Register doc extensions for ClinicalBERT control
if not Doc.has_extension("disable_clinical_bert"):
    Doc.set_extension("disable_clinical_bert", default=False)
if not Doc.has_extension("request_clinical_bert_enabled"):
    Doc.set_extension("request_clinical_bert_enabled", default=True)

# --- Global Service Clients ---
terminology_service: Optional[TerminologyServiceClient] = None
template_service: Optional[TemplateServiceClient] = None
llm_service: Optional[LLMServiceClient] = None 
dynamic_clinical_bert = None
thread_pool_executor: Optional[ThreadPoolExecutor] = None

def quick_filter_entities(entities: List[EnrichedEntity]) -> List[EnrichedEntity]:
    """Quick filter to remove noise entities"""
    filtered = []
    
    for entity in entities:
        # Skip administrative phrases
        admin_phrases = ["patient has", "denies", "takes", "reports", "states"]
        if entity.text.lower() in admin_phrases:
            continue
            
        # Skip IGNORE category entities  
        if entity.backend_category == "IGNORE":
            continue
            
        # Keep all clinical entities
        if entity.backend_category in [
            "CONDITION", "SYMPTOM", "DRUG", "PROCEDURE", "LAB_RESULT", 
            "VITAL_SIGN", "OBSERVATION", "FINDING"
        ]:
            filtered.append(entity)
    
    return filtered

def fix_entity_categories(entities: List[EnrichedEntity]) -> List[EnrichedEntity]:
    """Fix common category mistakes"""
    
    for entity in entities:
        text_lower = entity.text.lower()
        
        # Fix symptoms that are miscategorized
        if ("chest pain" in text_lower or "dyspnea" in text_lower or 
            "shoulder pain" in text_lower or "back pain" in text_lower):
            entity.backend_category = "SYMPTOM"
            
        # Fix conditions that are miscategorized  
        if ("diabetes mellitus" in text_lower or 
            ("diabetes" in text_lower and "type" in text_lower)):
            entity.backend_category = "CONDITION"
            
        # Fix lab results that are miscategorized
        if ("a1c" in text_lower or "hba1c" in text_lower or 
            "hemoglobin a1c" in text_lower):
            entity.backend_category = "LAB_RESULT"
            
        # Fix substances miscategorized as drugs
        if text_lower in ["sugars", "sugar", "blood sugar"]:
            entity.backend_category = "SUBSTANCE"
            
        # Fix vital signs that are miscategorized
        if ("blood pressure" in text_lower or text_lower == "bp" or
            "heart rate" in text_lower or text_lower == "hr"):
            entity.backend_category = "VITAL_SIGN"
            
    return entities

def clean_clinical_entities(entities: List[EnrichedEntity]) -> List[EnrichedEntity]:
    """Clean up noisy entities - production ready filter"""
    filtered = []
    
    for entity in entities:
        text_lower = entity.text.lower().strip()
        
        # Skip administrative noise patterns
        noise_patterns = [
            "follow-up of", "complaint noted", "history is notable", 
            "exam reveals", "described as", "reports", "denies",
            "exacerbated by", "slightly above", "noted above",
            "medical conditions", "including", "he reports", "patient",
            "physical exam", "review of systems", "social history",
            "family history", "impression includes", "plan is"
        ]
        
        if any(noise in text_lower for noise in noise_patterns):
            continue
            
        # Skip very short fragments or single words that aren't clinical abbreviations
        clinical_abbreviations = ["a1c", "bp", "hr", "rr", "tsh", "cbc", "ldl", "hdl"]
        if (len(text_lower) < 3 and 
            text_lower not in clinical_abbreviations):
            continue
            
        # Skip entities that are mostly punctuation or numbers
        if len(text_lower.strip(".,;:()[]{}\"' ")) < 2:
            continue
            
        # Keep high-value clinical entities
        if entity.backend_category in [
            "CONDITION", "SYMPTOM", "DRUG", "LAB_RESULT", 
            "VITAL_SIGN", "OBSERVATION", "PROCEDURE", "FINDING"
        ]:
            # Additional quality check for PROCEDURE category
            if (entity.backend_category == "PROCEDURE" and 
                len(entity.text.split()) > 4):  # Skip very long procedure phrases
                continue
                
            # Additional quality check for FINDING category  
            if (entity.backend_category == "FINDING" and
                any(word in text_lower for word in ["including", "notable", "described"])):
                continue
                
            filtered.append(entity)
            
    return filtered

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("ClinicalAIService starting up...")
    global terminology_service, template_service, llm_service, dynamic_clinical_bert

    # Database connection
    await db_client.connect_db()
    logger.debug(f"DB_POOL object in main.py after connect_db: {db_client.DB_POOL}")

    if db_client.DB_POOL is None or (hasattr(db_client.DB_POOL, '_closed') and db_client.DB_POOL._closed):
        logger.critical("Database connection pool failed to initialize or is closed.")
    else:
        logger.info("Database connection for mapper initialized successfully.")
    
    # NLP Engine initialization
    nlp_processor.initialize_nlp_engine(ner_engine_preference=app_config.DEFAULT_NER_ENGINE)
    if nlp_processor.NLP_SPACY is None: 
        logger.critical("NLP_SPACY failed to initialize.")
    else: 
        logger.info(f"NLP Engine initialized. Pipeline: {nlp_processor.NLP_SPACY.pipe_names}")
    
    # Initialize dynamic ClinicalBERT
    dynamic_clinical_bert = get_dynamic_clinical_bert()
    if dynamic_clinical_bert.is_available():
        logger.info("Dynamic ClinicalBERT initialized successfully")
        cache_info = dynamic_clinical_bert.get_cache_info()
        logger.info(f"ClinicalBERT cache: {cache_info}")
    else:
        logger.warning("Dynamic ClinicalBERT not available")

    # Initialize API clients
    logger.info("Initializing API clients...")
    
    # Initialize thread pool for concurrent processing
    global thread_pool_executor
    thread_pool_executor = ThreadPoolExecutor(
        max_workers=app_config.ASYNC_MAX_WORKERS,
        thread_name_prefix="clinical-ai-"
    )
    logger.info(f"Initialized thread pool with {app_config.ASYNC_MAX_WORKERS} workers")
    
    # PRODUCTION: Initialize concurrent processor for CPU-intensive NLP tasks
    concurrent_processor = get_concurrent_processor()
    await concurrent_processor.start()
    logger.info("Production concurrent NLP processor started")
    
    if app_config.TERMINOLOGY_SERVICE_URL: 
        terminology_service = TerminologyServiceClient()
        logger.info("TerminologyServiceClient initialized.")
    else: 
        logger.warning("TERMINOLOGY_SERVICE_URL not configured.")
    
    if app_config.TEMPLATE_SERVICE_URL: 
        template_service = TemplateServiceClient()
        logger.info("TemplateServiceClient initialized.")
    else: 
        logger.warning("TEMPLATE_SERVICE_URL not configured.")
    
    if app_config.LLM_SERVICE_URL or (app_config.RUNPOD_API_BASE and app_config.RUNPOD_ENDPOINT_ID):
        llm_service = LLMServiceClient()
        logger.info("LLMServiceClient initialized.")
    else: 
        logger.warning("LLM_SERVICE_URL not configured.")
    
    logger.info("ClinicalAIService startup complete.")
    yield
    
    # Shutdown
    logger.info("ClinicalAIService shutting down...")
    if dynamic_clinical_bert:
        dynamic_clinical_bert.clear_cache()
        logger.info("Cleared ClinicalBERT model cache")
    
    await db_client.close_db()
    
    # Shutdown thread pool
    if thread_pool_executor:
        thread_pool_executor.shutdown(wait=True)
        logger.info("Thread pool shutdown complete")
    
    # Shutdown concurrent processor
    try:
        await concurrent_processor.stop()
        logger.info("Concurrent NLP processor stopped")
    except Exception as e:
        logger.warning(f"Error shutting down concurrent processor: {e}")
        
    logger.info("ClinicalAIService shutdown complete.")

# Create FastAPI app
app = FastAPI(
    title="Clinical AI Service",
    description="Advanced NLP processing for clinical notes with dynamic ClinicalBERT support",
    version=app_config.SERVICE_VERSION,
    lifespan=lifespan
)

# Apply comprehensive security middleware
setup_security(
    app,
    allowed_origins=app_config.CORS_ORIGINS if hasattr(app_config, "CORS_ORIGINS") else ["http://localhost:3000", "http://localhost:8080"],
    enable_auth=True,
    rate_limit="100/minute",
    trusted_hosts=["localhost", "clinical-ai-service", "*.nexuscare.ai"]
)

@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    request_id = generate_request_id()
    request.state.request_id = request_id
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    response.headers["X-Request-ID"] = request_id
    logger.info(f"Request {request_id} to {request.url.path} completed in {process_time:.4f}s, Status: {response.status_code}")
    return response

def _determine_clinical_bert_model(note_input: ClinicalNoteInput) -> Optional[str]:
    """Determine which ClinicalBERT model to use based on input"""
    
    # Explicit model selection takes priority
    if note_input.clinical_bert_model:
        return note_input.clinical_bert_model
    
    # Auto-selection based on document type
    if note_input.document_type:
        doc_type = note_input.document_type.lower()
        
        if 'discharge' in doc_type or 'summary' in doc_type:
            return ClinicalBERTModelOption.DISCHARGE_SUMMARY_BERT
        elif 'consultation' in doc_type or 'note' in doc_type:
            return ClinicalBERTModelOption.CLINICAL_BERT
        elif 'research' in doc_type or 'pubmed' in doc_type:
            return ClinicalBERTModelOption.PUBMED_BERT
    
    # Default from config
    return None  # Will use config default

async def enrich_single_entity(entity: EnrichedEntity, request_id: str) -> EnrichedEntity:
              
    """Enrich a single entity with terminology information"""
    if terminology_service and entity.primary_cui and entity.source_ner_engine != "llm_ner":
        try:
            term_details: Optional[Concept] = await terminology_service.resolve_cui(entity.primary_cui)
            if term_details:
                if term_details.name: 
                    entity.preferred_name_ks = term_details.name
                elif term_details.pretty_name: 
                    entity.preferred_name_ks = term_details.pretty_name
                
                # Add concept if not already present
                is_primary_concept_in_linked = any(lc.id == entity.primary_cui for lc in entity.linked_concepts)
                if not is_primary_concept_in_linked:
                    entity.linked_concepts.append(term_details)

                # Add standard codes
                if term_details.codes_by_sab:
                    for sab, codes_list in term_details.codes_by_sab.items():
                        if codes_list:
                            for code_val in codes_list:
                                if not any(sc.code == str(code_val) and sc.vocabulary == sab for sc in entity.standard_codes):
                                    display_for_code = term_details.name or entity.text
                                    entity.standard_codes.append(StandardCode(code=str(code_val), vocabulary=sab, display=display_for_code))
                
                # Update type information
                if term_details.tuis: 
                    entity.type_ids = list(set(entity.type_ids + term_details.tuis))
                if term_details.semantic_types: 
                    entity.type_names = list(set(entity.type_names + term_details.semantic_types))
            else:
                logger.debug(f"[ReqID: {request_id}] No details from Terminology Service for CUI {entity.primary_cui}")
        except Exception as e_term:
            logger.warning(f"[ReqID: {request_id}] Error enriching CUI {entity.primary_cui}: {e_term}", exc_info=True)
            entity.audit_trail.append(AuditTrailEntry(source_service="terminology_enrichment_error", details={"error": str(e_term)}))

    # Create FHIR CodeableConcept
    all_codings_for_fhir_cc: List[Dict[str, Any]] = []
    for sc in entity.standard_codes:
        fhir_coding = create_fhir_coding(code=sc.code, system_key=sc.vocabulary, display=sc.display)
        if fhir_coding: 
            all_codings_for_fhir_cc.append(fhir_coding)
    
    # Add CUI as UMLS coding if present
    if entity.primary_cui:
        umls_system_uri = FHIR_CODING_SYSTEM_MAP.get("UMLS")
        is_cui_present_as_umls = any(
            c.get("code") == entity.primary_cui and c.get("system") == umls_system_uri 
            for c in all_codings_for_fhir_cc
        )
        if not is_cui_present_as_umls and umls_system_uri:
            cui_display = entity.preferred_name_ks or entity.text
            cui_fhir_coding = create_fhir_coding(code=entity.primary_cui, system_key="UMLS", display=cui_display)
            if cui_fhir_coding: 
                all_codings_for_fhir_cc.append(cui_fhir_coding)
    
    cc_text = entity.preferred_name_ks or entity.text
    if all_codings_for_fhir_cc or cc_text:
         entity.fhir_codeable_concept = create_fhir_codeable_concept(text=cc_text, codings=all_codings_for_fhir_cc)
    
    entity.audit_trail.append(AuditTrailEntry(source_service="enrich_single_entity_completion", details={"final_cc_created": bool(entity.fhir_codeable_concept)}))
    return entity

@app.post("/process", response_model=ProcessingOutput, status_code=status.HTTP_200_OK)
@limiter.limit("50/minute")
async def process_clinical_note(
    note_input: ClinicalNoteInput, 
    request: Request,
    token_payload: dict = Depends(verify_token)
):
    request_id = request.state.request_id 
    logger.info(f"[ReqID: {request_id}] Received processing request. Template: {note_input.template_id or 'N/A'}")
    
    output = ProcessingOutput(request_id=request_id, original_text_char_count=len(note_input.text))
    pipeline_start_time = time.time()

    # FIXED: Determine request-specific parameters
    bert_enabled = note_input.enable_clinical_bert if note_input.enable_clinical_bert is not None else app_config.ENABLE_CLINICAL_BERT
    fallback_enabled = note_input.enable_intelligent_fallback if note_input.enable_intelligent_fallback is not None else True
    
    logger.info(f"[ReqID: {request_id}] Processing parameters: ClinicalBERT={bert_enabled}, Fallback={fallback_enabled}")

    # Determine ClinicalBERT model to use
    selected_bert_model = _determine_clinical_bert_model(note_input)
    
    # Track models used (ensure all values are strings for JSON serialization)
    output.models_used = {
        "nlp_engine": str(app_config.DEFAULT_NER_ENGINE),
        "spacy_model": str(app_config.SPACY_MODEL),
        "clinical_bert_enabled": str(bert_enabled),
        "clinical_bert_model": str(selected_bert_model or app_config.CLINICAL_BERT_MODEL_NAME) if bert_enabled else "disabled"
    }

    if nlp_processor.NLP_SPACY is None:
        logger.error(f"[ReqID: {request_id}] NLP Engine (NLP_SPACY) not available.")
        output.errors.append("Core NLP engine not initialized.")
        return output.model_dump(exclude_none=True)

    # PRODUCTION: Use concurrent processing for true scalability
    nlp_start_time = time.time()
    
    try:
        logger.info(f"[ReqID: {request_id}] Starting concurrent NLP processing...")
        
        concurrent_processor = get_concurrent_processor()
        
        processing_result = await concurrent_processor.process_text_concurrent(
            task_id=request_id,
            text=note_input.text,
            enable_clinical_bert=bert_enabled,
            enable_intelligent_fallback=fallback_enabled
        )
        
        if not processing_result.success:
            logger.error(f"[ReqID: {request_id}] Concurrent NLP processing failed: {processing_result.error}")
            output.errors.append(f"NLP processing failed: {processing_result.error}")
            return output.model_dump(exclude_none=True)
        
        # Extract results from concurrent processing
        nlp_entities_initial = processing_result.entities
        doc = None  # We don't return the doc from concurrent processing for memory efficiency
        
        logger.info(f"[ReqID: {request_id}] Concurrent NLP found {len(nlp_entities_initial)} entities in {processing_result.processing_time:.2f}s")
        logger.info(f"[ReqID: {request_id}] Worker PID: {processing_result.metadata.get('worker_pid', 'unknown')}")
        
        # Add processing metadata
        output.timing_metrics_ms["nlp_engine_ms"] = processing_result.processing_time * 1000
        if processing_result.metadata:
            logger.info(f"[ReqID: {request_id}] Processing metadata: {processing_result.metadata}")
        
        # ClinicalBERT status logging
        if bert_enabled:
            logger.info(f"[ReqID: {request_id}] ✅ ClinicalBERT enabled")
        else:
            logger.info(f"[ReqID: {request_id}] 🚫 ClinicalBERT disabled")
        
    except Exception as e:
        logger.error(f"[ReqID: {request_id}] Concurrent NLP processing failed: {e}")
        output.errors.append(f"NLP processing failed: {str(e)}")
        return output.model_dump(exclude_none=True)

    # 2. NEW: Low-Maintenance Terminology Enhancement
    if terminology_service:
        terminology_start_time = time.time()
        try:
            logger.info(f"[ReqID: {request_id}] Starting low-maintenance terminology enhancement")
            
            # Use the new low-maintenance terminology enhancement
            try:
                enhanced_entities = await asyncio.wait_for(
                    terminology_service.enhance_entities_with_terminology(
                        note_input.text, 
                        nlp_entities_initial
                    ),
                    timeout=10.0  # 10 second timeout for terminology service
                )
            except asyncio.TimeoutError:
                logger.warning(f"[ReqID: {request_id}] Terminology enhancement timed out, proceeding without it")
                enhanced_entities = nlp_entities_initial
            
            # Update the entities list
            nlp_entities_initial = enhanced_entities
            
            output.timing_metrics_ms["terminology_enhancement_ms"] = (time.time() - terminology_start_time) * 1000
            logger.info(f"[ReqID: {request_id}] Low-maintenance terminology enhancement completed: "
                       f"found {len(enhanced_entities) - len(nlp_entities_initial)} additional entities")
            
        except Exception as e:
            logger.error(f"[ReqID: {request_id}] Low-maintenance terminology enhancement failed: {e}", exc_info=True)
            output.warnings.append(f"Terminology enhancement error: {str(e)}")
                 
    # 3. Entity Enrichment
    current_enriched_entities: List[EnrichedEntity] = []
    if nlp_entities_initial:
        logger.info(f"[ReqID: {request_id}] NLP found {len(nlp_entities_initial)} initial entities. Starting enrichment...")
        base_batch_size = 3 if bert_enabled else 8
        batch_size = min(base_batch_size, max(1, len(nlp_entities_initial) // 4))
        logger.info(f"[ReqID: {request_id}] Processing {len(nlp_entities_initial)} entities in batches of {batch_size}") 
        enriched_results = []
        
        for i in range(0, len(nlp_entities_initial), batch_size):
            batch = nlp_entities_initial[i:i + batch_size]
            batch_tasks = []
            
            for nlp_e in batch:
                enriched_e_base = EnrichedEntity(**nlp_e.model_dump())
                enriched_e_base.backend_category = nlp_processor.get_entity_clinical_category(nlp_e)
                batch_tasks.append(enrich_single_entity(enriched_e_base, request_id))
            
            if thread_pool_executor and not bert_enabled:
                # For non-BERT processing, use thread pool
                batch_results = await asyncio.gather(*batch_tasks, return_exceptions=True)
            else:
                # For BERT processing, use asyncio to avoid thread overhead
                batch_results = await asyncio.gather(*batch_tasks, return_exceptions=True)
                
            enriched_results.extend(batch_results)
            
            # Small delay between batches to prevent resource exhaustion
            if i + batch_size < len(nlp_entities_initial):
                await asyncio.sleep(0.001)  # Minimal delay, just yield control
                
        for result in enriched_results:
            if isinstance(result, EnrichedEntity): 
                current_enriched_entities.append(result)
            elif isinstance(result, Exception): 
                logger.error(f"[ReqID: {request_id}] Error during entity enrichment: {result}", exc_info=result)
                output.errors.append(f"Entity enrichment failure: {str(result)[:100]}")
    else:
        logger.info(f"[ReqID: {request_id}] No entities found by NLP engine.")

    # Quick filter to remove noise entities
    if current_enriched_entities:
        logger.info(f"[ReqID: {request_id}] Applying quick filter to remove noise entities...")
        pre_filter_count = len(current_enriched_entities)
        current_enriched_entities = quick_filter_entities(current_enriched_entities)
        logger.info(f"[ReqID: {request_id}] Quick filter: {pre_filter_count} → {len(current_enriched_entities)} entities")
    
    try:
        logger.info(f"[ReqID: {request_id}] Applying entity category fixes and filtering...")
        
        # Step 1: Fix common category mistakes
        corrected_entities = fix_entity_categories(current_enriched_entities)
        
        # Step 2: Filter out noisy entities
        filtered_entities = clean_clinical_entities(corrected_entities)
        
        logger.info(f"[ReqID: {request_id}] Entity optimization: {len(current_enriched_entities)} → {len(filtered_entities)} entities")
        current_enriched_entities = filtered_entities
        
    except Exception as e:
        logger.error(f"[ReqID: {request_id}] Entity filtering failed: {e}")
        output.warnings.append(f"Entity filtering error: {str(e)}")

    output.enriched_entities = sorted(current_enriched_entities, key=lambda e: e.start_char)

    # NEW: Apply entity filtering and compound extraction
    try:
        logger.info(f"[ReqID: {request_id}] Applying entity filtering and compound extraction...")
        
        # Extract compound entities first
        enhanced_entities = nlp_processor.extract_compound_entities(current_enriched_entities, note_input.text)
        
        # Then filter non-clinical entities
        filtered_entities = nlp_processor.filter_non_clinical_entities(enhanced_entities)
        
        logger.info(f"[ReqID: {request_id}] Entity optimization: {len(current_enriched_entities)} → {len(filtered_entities)} entities")
        current_enriched_entities = filtered_entities
        
    except Exception as e:
        logger.error(f"[ReqID: {request_id}] Entity filtering failed: {e}")
        output.warnings.append(f"Entity filtering error: {str(e)}")
    
    current_enriched_entities = modifier_linker_pipeline(current_enriched_entities, note_input.text)
    
    # Convert family/social results to EnrichedEntity objects
    family_social_results = family_social_linker_pipeline(note_input.text)
    for fs_result in family_social_results:
        if isinstance(fs_result, dict):
            # Convert dict to EnrichedEntity
            span = fs_result.get("span", [0, 0])
            history_type = fs_result.get("history_type", "unknown")
            
            # Create text from available fields
            if history_type == "family":
                text_parts = []
                if fs_result.get("relation"):
                    text_parts.append(fs_result["relation"])
                if fs_result.get("condition"):
                    text_parts.append(fs_result["condition"])
                text = " ".join(text_parts) if text_parts else "family history"
                label = "FAMILY_HISTORY"
                category = "OBSERVATION"
            else:  # social
                text_parts = []
                if fs_result.get("factor"):
                    text_parts.append(fs_result["factor"])
                if fs_result.get("status"):
                    text_parts.append(fs_result["status"])
                text = " ".join(text_parts) if text_parts else "social history"
                label = "SOCIAL_HISTORY"
                category = "OBSERVATION"
            
            enriched_entity = EnrichedEntity(
                text=text,
                start_char=span[0],
                end_char=span[1],
                label=label,
                source_ner_engine="family_social_linker",
                ner_confidence=0.8,
                backend_category=category,
                section_title="default_section",
                family_history=(history_type == "family"),
                social_history=(history_type == "social"),
                metadata=fs_result,  # Store original data in metadata
                audit_trail=[AuditTrailEntry(
                    source_service="family_social_linker",
                    details=fs_result
                )]
            )
            current_enriched_entities.append(enriched_entity)
    
    # Convert lab/exam/allergy results to EnrichedEntity objects with enhanced validation
    try:
        # Use the enhanced async version with terminology service validation
        labs_exams_allergies = await lab_exam_allergy_linker_pipeline_async(
            note_input.text, 
            terminology_client=terminology_service
        )
    except Exception as e:
        logger.warning(f"[ReqID: {request_id}] Enhanced lab/exam/allergy extraction failed, falling back to basic: {e}")
        # Fallback to basic version
        labs_exams_allergies = lab_exam_allergy_linker_pipeline(note_input.text)
    
    for lea_result in labs_exams_allergies:
        if isinstance(lea_result, dict):
            # Convert dict to EnrichedEntity
            span = lea_result.get("span", [0, 0])
            result_type = lea_result.get("type", "unknown")
            
            # Create text and determine category
            if result_type == "LAB_RESULT":
                name = lea_result.get("name", "lab result")
                value = lea_result.get("value", "")
                unit = lea_result.get("unit", "")
                text = f"{name} {value} {unit}".strip()
                label = "LAB_RESULT"
                category = "LAB_RESULT"
            elif result_type == "VITAL":
                name = lea_result.get("name", "vital sign")
                value = lea_result.get("value", "")
                systolic = lea_result.get("systolic", "")
                diastolic = lea_result.get("diastolic", "")
                if systolic and diastolic:
                    text = f"{name} {systolic}/{diastolic}"
                elif value:
                    text = f"{name} {value}"
                else:
                    text = name
                label = "VITAL_SIGN"
                category = "VITAL_SIGN"
            elif result_type == "ALLERGY":
                substance = lea_result.get("substance", "allergen")
                text = f"allergy to {substance}"
                label = "ALLERGY"
                category = "OBSERVATION"
            else:
                text = str(lea_result)
                label = "UNKNOWN"
                category = "OBSERVATION"
            
            # Enhanced confidence and validation info
            confidence = lea_result.get("confidence", 0.8)
            validation_method = lea_result.get("validation_method", "local")
            
            enriched_entity = EnrichedEntity(
                text=text,
                start_char=span[0],
                end_char=span[1],
                label=label,
                source_ner_engine="lab_exam_allergy_linker",
                ner_confidence=confidence,
                backend_category=category,
                section_title="default_section",
                metadata=lea_result,  # Store original data in metadata
                audit_trail=[AuditTrailEntry(
                    source_service="lab_exam_allergy_linker",
                    confidence_score=confidence,
                    details={
                        **lea_result,
                        "validation_method": validation_method,
                        "terminology_validated": validation_method in ["terminology_service", "local_enhanced"]
                    }
                )]
            )
            
            # Add CUI if available from terminology validation
            if lea_result.get("cui"):
                enriched_entity.primary_cui = lea_result["cui"]
            
            current_enriched_entities.append(enriched_entity)

    output.enriched_entities = sorted(current_enriched_entities, key=lambda e: e.start_char)

    # 4. Template Processing (if requested)
    if note_input.perform_structuring and note_input.template_id and template_service:
        template_start_time = time.time()
        try:
            questionnaire_def = await template_service.get_template_definition(note_input.template_id)
            if questionnaire_def:
                qr_context = {
                     "patient_ref": note_input.patient_ref, 
                     "encounter_ref": note_input.encounter_ref,
                     "author_ref": note_input.author_ref, 
                     "template_id": note_input.template_id,
                }
                try:
                    fhir_qr_dict = await asyncio.wait_for(
                        config_driven_mapper.create_questionnaire_response_from_config(
                            questionnaire_definition=questionnaire_def,
                            enriched_entities=output.enriched_entities, 
                            summary_text=None,
                            context=qr_context
                        ),
                        timeout=15.0  # 15 second timeout for template processing
                    )
                except asyncio.TimeoutError:
                    logger.warning(f"[ReqID: {request_id}] Template processing timed out")
                    fhir_qr_dict = None
                    
                if fhir_qr_dict:
                    # Count filled placeholders
                    def count_answers(items_list):
                        count = 0
                        for item_group in items_list:
                            if item_group.get("answer"):
                                count += len(item_group.get("answer",[]))
                            if item_group.get("item"): 
                                count += count_answers(item_group.get("item", []))
                        return count
                    
                    ph_filled = count_answers(fhir_qr_dict.get("item", [])) if fhir_qr_dict.get("item") else 0
                        
                    output.fhir_payload = FHIRQuestionnaireResponsePayload(
                        fhir_qr=fhir_qr_dict, 
                        template_used=note_input.template_id, 
                        placeholders_filled=ph_filled
                    )
                    logger.info(f"[ReqID: {request_id}] FHIR QuestionnaireResponse generated with {ph_filled} answers.")
                else:
                    output.warnings.append(f"Failed to generate FHIR QR for template '{note_input.template_id}'.")
            else:
                output.warnings.append(f"Template '{note_input.template_id}' not found.")
        except Exception as e:
            logger.error(f"[ReqID: {request_id}] Template processing error: {e}")
            output.errors.append(f"Template processing failed: {str(e)}")
        
        output.timing_metrics_ms["template_mapping_ms"] = (time.time() - template_start_time) * 1000

    # 4. Summary Generation (if requested) 
    if note_input.perform_summarization and llm_service:
        summary_start_time = time.time()
        try:
            # Convert enriched entities to base entities for LLM
            base_entities_for_llm = []
            for e in output.enriched_entities: 
                base_entity_data = {
                    'text': e.text, 'label': e.label, 'start_char': e.start_char, 'end_char': e.end_char,
                    'negated': e.negated, 'historical': e.historical, 'family_history': e.family_history,
                    'hypothetical': e.hypothetical, 'source_ner_engine': e.source_ner_engine,
                    'ner_confidence': e.ner_confidence, 'section_title': e.section_title
                }
                base_entities_for_llm.append(BaseEntity(**base_entity_data))

            try:
                summary_text = await asyncio.wait_for(
                    llm_service.generate_summary(
                        text=note_input.text, 
                        context_entities=base_entities_for_llm
                    ),
                    timeout=30.0  # 30 second timeout for LLM
                )
            except asyncio.TimeoutError:
                logger.warning(f"[ReqID: {request_id}] LLM summary generation timed out")
                summary_text = None
                
            if summary_text:
                output.summary_payload = SummaryPayload(summary_text=summary_text)
                logger.info(f"[ReqID: {request_id}] LLM summary generated.")
            else:
                output.warnings.append("LLM summarization returned no text.")
        except Exception as e:
            logger.error(f"[ReqID: {request_id}] Summary generation error: {e}")
            output.warnings.append(f"Summary generation failed: {str(e)}")
        
        output.timing_metrics_ms["llm_summary_ms"] = (time.time() - summary_start_time) * 1000
    
    output.timing_metrics_ms["total_pipeline_ms"] = (time.time() - pipeline_start_time) * 1000
    logger.info(f"[ReqID: {request_id}] Processing complete. Total: {output.timing_metrics_ms['total_pipeline_ms']:.2f} ms.")
    return output.model_dump(exclude_none=True)

# ClinicalBERT specific endpoints
@app.post("/clinical-bert/embeddings", response_model=EmbeddingResponse)
async def get_clinical_bert_embeddings(request: EmbeddingRequest):
    """Get ClinicalBERT embeddings for text with automatic chunking support"""
    try:
        if not dynamic_clinical_bert or not dynamic_clinical_bert.is_available():
            raise HTTPException(
                status_code=503, 
                detail="ClinicalBERT service not available"
            )
        
        # Run the embedding generation in a thread pool to avoid blocking
        loop = asyncio.get_event_loop()
        
        try:
            embeddings = await asyncio.wait_for(
                dynamic_clinical_bert.get_embeddings_async(
                    request.text, 
                    request.model_name
                ),
                timeout=app_config.CLINICAL_BERT_TIMEOUT_SECONDS
            )
        except asyncio.TimeoutError:
            raise HTTPException(
                status_code=408,
                detail=f"ClinicalBERT embeddings timed out after {app_config.CLINICAL_BERT_TIMEOUT_SECONDS} seconds"
            )
        
        if embeddings is None:
            raise HTTPException(
                status_code=500,
                detail="Failed to generate embeddings"
            )
        
        return EmbeddingResponse(
            embeddings=embeddings.tolist(),
            model_used=request.model_name or app_config.CLINICAL_BERT_MODEL_NAME,
            text_length=len(request.text),
            embedding_dimension=len(embeddings)
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in ClinicalBERT embeddings: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/clinical-bert/similarity", response_model=SimilarityResponse)
async def get_clinical_bert_similarity(request: SimilarityRequest):
    """Calculate semantic similarity between two texts using ClinicalBERT"""
    try:
        if not dynamic_clinical_bert or not dynamic_clinical_bert.is_available():
            raise HTTPException(
                status_code=503, 
                detail="ClinicalBERT service not available"
            )
        
        # Run the similarity calculation in a thread pool to avoid blocking
        loop = asyncio.get_event_loop()
        
        try:
            similarity = await asyncio.wait_for(
                dynamic_clinical_bert.get_similarity_async(
                    request.text1,
                    request.text2,
                    request.model_name
                ),
                timeout=app_config.CLINICAL_BERT_TIMEOUT_SECONDS
            )
        except asyncio.TimeoutError:
            raise HTTPException(
                status_code=408,
                detail=f"ClinicalBERT similarity timed out after {app_config.CLINICAL_BERT_TIMEOUT_SECONDS} seconds"
            )
        
        return SimilarityResponse(
            text1=request.text1,
            text2=request.text2,
            similarity_score=similarity,
            model_used=request.model_name or app_config.CLINICAL_BERT_MODEL_NAME
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in ClinicalBERT similarity: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/clinical-bert/compare-models", response_model=ModelComparisonResponse)
async def compare_clinical_bert_models(request: ModelComparisonRequest):
    """Compare how different ClinicalBERT models represent the same text"""
    
    if not dynamic_clinical_bert or not dynamic_clinical_bert.is_available():
        raise HTTPException(status_code=503, detail="ClinicalBERT not available")
    
    try:
        comparison = dynamic_clinical_bert.compare_models(
            request.text, 
            [model.value if isinstance(model, ClinicalBERTModelOption) else model for model in request.models]
        )
        
        # Add recommendation based on analysis
        recommendation = None
        if len(comparison["models_compared"]) > 1:
            # Simple heuristic: recommend model with highest magnitude for clinical text
            best_model = max(
                comparison["embeddings_comparison"].items(),
                key=lambda x: x[1]["magnitude"]
            )[0]
            
            doc_type = "clinical document"
            if any(word in request.text.lower() for word in ["discharge", "summary"]):
                doc_type = "discharge summary"
            elif any(word in request.text.lower() for word in ["consultation", "visit"]):
                doc_type = "consultation note"
            
            recommendation = f"For this {doc_type}, {best_model} shows strongest representation"
        
        return ModelComparisonResponse(
            text=comparison["text"],
            models_compared=comparison["models_compared"],
            embeddings_comparison=comparison["embeddings_comparison"],
            similarity_matrix=comparison.get("similarity_matrix", {}),
            analysis_comparison=comparison["analysis_comparison"],
            recommendation=recommendation
        )
        
    except Exception as e:
        logger.error(f"Error comparing models: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/clinical-bert/status", response_model=ClinicalBERTStatusResponse)
async def get_clinical_bert_status():
    """Get status and information about ClinicalBERT"""
    
    if not dynamic_clinical_bert:
        return ClinicalBERTStatusResponse(
            enabled=False,
            available_models=[],
            default_model="",
            cached_models=[],
            cache_utilization="0/0",
            device="unknown",
            transformers_available=False
        )
    
    info = dynamic_clinical_bert.get_model_info()
    cache_info = dynamic_clinical_bert.get_cache_info()
    
    return ClinicalBERTStatusResponse(
        enabled=app_config.ENABLE_CLINICAL_BERT,
        available_models=info["available_models"],
        default_model=info["default_model"],
        cached_models=cache_info["cached_models"],
        cache_utilization=cache_info["cache_utilization"],
        device=info["device"],  # Already converted to string in get_model_info
        transformers_available=info["transformers_available"]
    )

@app.delete("/clinical-bert/cache")
async def clear_clinical_bert_cache(model_name: Optional[str] = None):
    """Clear ClinicalBERT model cache"""
    
    if not dynamic_clinical_bert:
        raise HTTPException(status_code=503, detail="ClinicalBERT not available")
    
    try:
        dynamic_clinical_bert.clear_cache(model_name)
        
        return {
            "message": f"Cache cleared for model: {model_name}" if model_name else "All model cache cleared",
            "cache_info": dynamic_clinical_bert.get_cache_info()
        }
        
    except Exception as e:
        logger.error(f"Error clearing cache: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health", response_model=HealthStatusResponse)
async def health_check():
    status_response = HealthStatusResponse(status="degraded", dependencies={})
    all_ok = True

    # Database check
    if db_client.DB_POOL and not db_client.DB_POOL.is_closing(): 
        status_response.dependencies["template_mapper_db"] = "ok"
    else: 
        status_response.dependencies["template_mapper_db"] = "error"
        all_ok = False

    # NLP Engine checks
    if nlp_processor.NLP_SPACY: 
        status_response.dependencies["nlp_spacy_model"] = "ok"
        status_response.spacy_model_loaded = True
        status_response.active_nlp_engine = app_config.SPACY_MODEL
    else: 
        status_response.dependencies["nlp_spacy_model"] = "error"
        all_ok = False
    
    # MedCAT check (if configured)
    if app_config.DEFAULT_NER_ENGINE == "medcat":
        medcat_processor = nlp_processor.get_medcat_instance()
        if medcat_processor and medcat_processor.is_available(): 
            status_response.dependencies["nlp_medcat_model"] = "ok"
            status_response.medcat_model_loaded = True
        else: 
            status_response.dependencies["nlp_medcat_model"] = "error"
            all_ok = False

    # Enhanced ClinicalBERT status
    if dynamic_clinical_bert:
        bert_available = dynamic_clinical_bert.is_available()
        status_response.dependencies["clinical_bert"] = "ok" if bert_available else "error"
        
        if not bert_available:
            all_ok = False
        
        # Detailed ClinicalBERT info (ensure all values are JSON serializable)
        cache_info = dynamic_clinical_bert.get_cache_info() if bert_available else None
        device_str = str(dynamic_clinical_bert.device) if hasattr(dynamic_clinical_bert, 'device') else "unknown"
        
        status_response.clinical_bert_status = {
            "enabled": app_config.ENABLE_CLINICAL_BERT,
            "available": bert_available,
            "default_model": app_config.CLINICAL_BERT_MODEL_NAME,
            "cache_info": cache_info,
            "device": device_str
        }
    else:
        status_response.dependencies["clinical_bert"] = "not_configured"
        status_response.clinical_bert_status = {
            "enabled": False,
            "available": False,
            "error": "Dynamic ClinicalBERT not initialized"
        }

    # PRODUCTION: Check concurrent processor status
    try:
        concurrent_processor = get_concurrent_processor()
        processor_stats = concurrent_processor.get_stats()
        
        if processor_stats["initialized"] and processor_stats["pool_available"]:
            status_response.dependencies["concurrent_processor"] = "ok"
            status_response.concurrent_processor_status = {
                "initialized": processor_stats["initialized"],
                "max_workers": processor_stats["max_workers"],
                "active_tasks": processor_stats["active_tasks"],
                "pool_available": processor_stats["pool_available"]
            }
        else:
            status_response.dependencies["concurrent_processor"] = "error"
            all_ok = False
            status_response.concurrent_processor_status = {
                "error": "Concurrent processor not properly initialized",
                "stats": processor_stats
            }
    except Exception as e:
        status_response.dependencies["concurrent_processor"] = "error"
        all_ok = False
        status_response.concurrent_processor_status = {
            "error": f"Concurrent processor check failed: {str(e)}"
        }

    # Check external service clients
    client_checks = {
        "terminology_service": terminology_service,
        "template_service": template_service,
        "llm_service": llm_service,
    }
    
    for name, client_instance in client_checks.items():
        if client_instance:
            try:
                is_healthy = hasattr(client_instance, "check_health") and await client_instance.check_health()
                status_response.dependencies[name] = "ok" if is_healthy else "error"
                if not is_healthy: 
                    all_ok = False
            except Exception as e:
                logger.warning(f"Health check failed for {name}: {e}")
                status_response.dependencies[name] = "error"
                all_ok = False
        else: 
            status_response.dependencies[name] = "not_configured"

    # Determine overall status
    if all_ok: 
        status_response.status = "healthy"
    elif any(dep_status == "ok" for dep_status in status_response.dependencies.values()): 
        status_response.status = "degraded"
    else: 
        status_response.status = "unhealthy"

    return status_response

# Additional utility endpoints
@app.get("/")
async def root():
    """Root endpoint with service information"""
    return {
        "service": "Clinical AI Service",
        "version": app_config.SERVICE_VERSION,
        "status": "running",
        "endpoints": {
            "health": "/health",
            "process": "/process",
            "clinical_bert_embeddings": "/clinical-bert/embeddings",
            "clinical_bert_similarity": "/clinical-bert/similarity",
            "clinical_bert_compare": "/clinical-bert/compare-models",
            "clinical_bert_status": "/clinical-bert/status",
            "docs": "/docs"
        }
    }

# Error handlers
@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle unexpected exceptions"""
    request_id = getattr(request.state, 'request_id', 'unknown')
    logger.error(f"[ReqID: {request_id}] Unhandled exception: {exc}", exc_info=True)
    
    return JSONResponse(
        status_code=500,
        content={
            "request_id": request_id,
            "error": "Internal server error",
            "detail": str(exc) if app_config.DEBUG_MODE else "An unexpected error occurred"
        }
    )

# Run with: uvicorn clinicalai_service.main:app --host 0.0.0.0 --port 8002 --reload