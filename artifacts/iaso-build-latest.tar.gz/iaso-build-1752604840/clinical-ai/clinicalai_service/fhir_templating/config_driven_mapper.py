# clinicalai_service/fhir_templating/config_driven_mapper.py
import uuid
import re
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional, Set, Union

# Assuming EnrichedEntity and StandardCode are correctly imported from your models.py
from ..models import EnrichedEntity, StandardCode 
from ..utils import logger, create_fhir_coding, create_fhir_codeable_concept, get_standard_code_for_systems, FHIR_CODING_SYSTEM_MAP
from ..db_client import fetch_rows # To fetch rules from DB
from .config_models import (
    AnswerConfigModel, RuleCriterionModel, MappingRuleModel, 
    TemplateItemMappingModel, TemplateMappingConfigModel
)

# --- Cache for loaded template mapping configurations ---
TEMPLATE_CONFIG_CACHE: Dict[str, TemplateMappingConfigModel] = {}

async def _load_answer_config_from_db(answer_config_id: int) -> Optional[AnswerConfigModel]:
    """Helper to load a single answer config from the database."""
    query = """
        SELECT id, config_name, fhir_answer_type, value_source_field, 
               coding_system_priority, codeable_concept_text_source, default_boolean_value 
        FROM clinical_consolidated.nlp_answer_configs 
        WHERE id = $1 AND is_active = TRUE
    """
    # In your provided code, value_source_field is singular. 
    # If it can be a list (e.g. ["text", "preferred_name_ks"] for fallback),
    # this loading and AnswerConfigModel would need adjustment. Assuming it's a single string field.
    rows = await fetch_rows(query, answer_config_id)
    if rows and rows[0]:
        row = rows[0]
        # Ensure coding_system_priority is handled as a list of strings
        priority_list = [item.strip() for item in row['coding_system_priority'].split(',') if item.strip()] if row['coding_system_priority'] else []
        
        return AnswerConfigModel(
            id=row['id'],
            config_name=row['config_name'],
            fhir_answer_type=row['fhir_answer_type'],
            value_source_field=row['value_source_field'], # This is a single string
            coding_system_priority=priority_list,
            codeable_concept_text_source=row['codeable_concept_text_source'],
            default_boolean_value=row['default_boolean_value']
        )
    logger.warning(f"No active answer config found for ID: {answer_config_id}")
    return None

async def load_mapping_config_for_template(template_id: str) -> Optional[TemplateMappingConfigModel]:
    """
    Loads the complete NLP mapping configuration for a given template_id from the database.
    Caches the configuration to avoid repeated database calls.
    """
    if template_id in TEMPLATE_CONFIG_CACHE:
        logger.debug(f"Returning cached mapping config for template_id: {template_id}")
        return TEMPLATE_CONFIG_CACHE[template_id]

    logger.info(f"Loading mapping configuration from DB for template_id: {template_id}")
    
    # 1. Load TemplateItemMappings (corresponds to Questionnaire linkIds)
    mappings_query = """
        SELECT id, item_link_id, description 
        FROM clinical_consolidated.template_nlp_mappings 
        WHERE template_id = $1 AND is_active = TRUE ORDER BY priority ASC
    """
    mapping_rows = await fetch_rows(mappings_query, template_id)
    if not mapping_rows:
        logger.warning(f"No active template NLP mappings found for template_id: {template_id}")
        empty_config = TemplateMappingConfigModel(template_id=template_id, item_mappings={})
        TEMPLATE_CONFIG_CACHE[template_id] = empty_config # Cache empty to prevent re-query
        return empty_config

    item_mappings_dict: Dict[str, TemplateItemMappingModel] = {}
    for m_row in mapping_rows:
        mapping_id = m_row['id'] # This is template_nlp_mappings.id
        item_link_id = m_row['item_link_id']
        logger.debug(f"[{template_id}] Processing item_link_id: {item_link_id} (mapping_id: {mapping_id})")
        
        # 2. For each mapping, load its associated MappingRules
        rules_query = """
            SELECT id, rule_name, match_logic, answer_config_id, max_answers, priority 
            FROM clinical_consolidated.nlp_mapping_rules 
            WHERE mapping_id = $1 AND is_active = TRUE ORDER BY priority ASC
        """
        rule_rows = await fetch_rows(rules_query, mapping_id)
        logger.debug(f"[{template_id}] Found {len(rule_rows)} active rules for {item_link_id}.")
        
        rules_for_item: List[MappingRuleModel] = []
        for r_row in rule_rows:
            rule_id = r_row['id'] # This is nlp_mapping_rules.id
            logger.debug(f"[{template_id}]   Processing rule: {r_row['rule_name']} (rule_id: {rule_id})")
            answer_config_id = r_row['answer_config_id']
            
            # 3. Load AnswerConfig for each rule
            answer_config_obj = await _load_answer_config_from_db(answer_config_id)
            if not answer_config_obj:
                logger.error(f"Critical: Could not load active answer_config_id {answer_config_id} for rule_id {rule_id} (template '{template_id}', item_link_id '{item_link_id}'). Skipping this rule.")
                continue

            # 4. Load RuleCriteria for each rule
            criteria_query = """
                SELECT id, criterion_type, operator, criterion_value 
                FROM clinical_consolidated.nlp_rule_criteria 
                WHERE rule_id = $1 AND is_active = TRUE
            """
            criteria_rows = await fetch_rows(criteria_query, rule_id)
            logger.debug(f"[{template_id}]     Found {len(criteria_rows)} active criteria for rule {rule_id}.")
            criteria_for_rule: List[RuleCriterionModel] = [
                RuleCriterionModel(
                    id=c_row['id'], 
                    criterion_type=c_row['criterion_type'], 
                    operator=c_row['operator'], 
                    criterion_value=c_row['criterion_value']
                ) for c_row in criteria_rows
            ]
            
            rules_for_item.append(MappingRuleModel(
                id=rule_id, 
                rule_name=r_row['rule_name'], 
                match_logic=r_row['match_logic'],
                answer_config=answer_config_obj, 
                max_answers=r_row['max_answers'],
                priority=r_row['priority'], 
                criteria=criteria_for_rule
            ))
        
        if item_link_id in item_mappings_dict:
            # This case handles if multiple template_nlp_mappings point to the same item_link_id,
            # though typically item_link_id would be unique per template_id in template_nlp_mappings.
            item_mappings_dict[item_link_id].rules.extend(rules_for_item)
            item_mappings_dict[item_link_id].rules.sort(key=lambda r: r.priority)
        else:
            item_mappings_dict[item_link_id] = TemplateItemMappingModel(
                id=mapping_id, 
                item_link_id=item_link_id, 
                description=m_row['description'], 
                rules=rules_for_item
            )

    template_config = TemplateMappingConfigModel(template_id=template_id, item_mappings=item_mappings_dict)
    TEMPLATE_CONFIG_CACHE[template_id] = template_config
    logger.info(f"Successfully loaded and cached mapping config for template_id: {template_id} with {len(item_mappings_dict)} item mappings.")
    return template_config


def _parse_criterion_value(criterion: RuleCriterionModel) -> Any:
    """
    Helper to parse criterion_value from string to its intended type based on operator or type.
    Handles lists for 'IN_LIST', floats for numeric comparisons, booleans, and lowercase strings.
    """
    value_str = criterion.criterion_value
    op = criterion.operator
    crit_type = criterion.criterion_type

    if value_str is None: # For operators like IS_NULL, IS_NOT_NULL, IS_TRUE, IS_FALSE
        return None 
    
    if op in ['IN_LIST', 'NOT_IN_LIST']:
        # Ensure values are stripped and lowercased for consistent comparison
        return [v.strip().lower() for v in value_str.split(',') if v.strip()]

    if crit_type == 'NER_CONFIDENCE' or op in ['GREATER_THAN', 'LESS_THAN', 'GREATER_THAN_OR_EQUAL', 'LESS_THAN_OR_EQUAL']:
        try:
            return float(value_str)
        except ValueError:
            logger.warning(f"Could not parse '{value_str}' as float for criterion ID {criterion.id} (type: {crit_type}, op: {op}).")
            return None # Indicate parsing failure to prevent comparison errors
            
    # For boolean status checks if value is explicitly "true" or "false", e.g. SOME_STATUS EQUALS true
    if (crit_type.endswith('_STATUS') or crit_type in ["NEGATED", "HISTORICAL", "HYPOTHETICAL", "FAMILY_HISTORY"]) and \
       op == 'EQUALS' and value_str.lower() in ['true', 'false']:
        return value_str.lower() == 'true'
    
    # Default to lowercase string for other string comparisons
    return value_str.lower()


def _evaluate_criterion(entity: EnrichedEntity, criterion: RuleCriterionModel) -> bool:
    """
    Evaluates a single criterion against an entity.
    Uses EnrichedEntity fields as defined in models.py.
    """
    entity_value: Any = None
    # Parse the criterion's value string into its expected type
    crit_value_parsed = _parse_criterion_value(criterion)

    # 1. Get the value from the entity based on criterion_type
    # Ensure entity field access is safe (e.g., checking for None) and lowercased for strings
    if criterion.criterion_type == "BACKEND_CATEGORY":
        entity_value = entity.backend_category.lower() if entity.backend_category else None
    elif criterion.criterion_type == "SECTION_KEYWORD": # Uses entity.section_title
        entity_value = entity.section_title.lower() if entity.section_title else None
    elif criterion.criterion_type == "TUI_CODE": # TUIs are typically uppercase, ensure comparison is consistent
        entity_value = [tui.lower() for tui in entity.type_ids] if entity.type_ids else []
    elif criterion.criterion_type == "STY_NAME": # STY names might have mixed case
        entity_value = [sty.lower() for sty in entity.type_names] if entity.type_names else []
    elif criterion.criterion_type == "ENTITY_TEXT_REGEX": # Regex applied to raw entity text
        entity_value = entity.text 
    elif criterion.criterion_type == "NEGATION_STATUS":
        entity_value = entity.negated # This is a boolean
    elif criterion.criterion_type == "HISTORICAL_STATUS":
        entity_value = entity.historical # Boolean
    elif criterion.criterion_type == "HYPOTHETICAL_STATUS":
        entity_value = entity.hypothetical # Boolean
    elif criterion.criterion_type == "FAMILY_HISTORY_STATUS":
        entity_value = entity.family_history # Boolean
    elif criterion.criterion_type == "SOCIAL_HISTORY_STATUS":
        entity_value = entity.social_history # Boolean, assuming EnrichedEntity has this attribute
    elif criterion.criterion_type == "NER_CONFIDENCE":
        entity_value = entity.ner_confidence # Optional[float]
    elif criterion.criterion_type == "SOURCE_NER_ENGINE":
        entity_value = entity.source_ner_engine.lower() if entity.source_ner_engine else None
    # Add more entity field handlers here if new criterion_types are introduced
    else:
        logger.warning(f"Unknown criterion_type: {criterion.criterion_type} for criterion ID {criterion.id}. Evaluation fails.")
        return False

    # 2. Apply the operator
    op = criterion.operator
    
    # Operators not requiring crit_value_parsed (or where it's implicitly None)
    if op == "IS_TRUE": return entity_value is True
    if op == "IS_FALSE": return entity_value is False
    if op == "IS_NULL": return entity_value is None
    if op == "IS_NOT_NULL": return entity_value is not None

    # For operators requiring crit_value_parsed from here onwards.
    # If crit_value_parsed is None due to a parsing error for a non-null DB value, fail the criterion.
    if crit_value_parsed is None and criterion.criterion_value is not None:
        logger.debug(f"Criterion value '{criterion.criterion_value}' (ID: {criterion.id}) resulted in None after parsing for op '{op}'. Evaluation fails.")
        return False

    if op == "EQUALS": return entity_value == crit_value_parsed
    if op == "NOT_EQUALS": return entity_value != crit_value_parsed
    
    if op == "CONTAINS": # String contains
        return isinstance(entity_value, str) and isinstance(crit_value_parsed, str) and crit_value_parsed in entity_value
    
    if op == "IN_LIST": # crit_value_parsed is a list of lowercase strings
        if not isinstance(crit_value_parsed, list): 
            logger.warning(f"IN_LIST operator expects a list, got {type(crit_value_parsed)} for crit ID {criterion.id}. Eval fails."); return False
        if isinstance(entity_value, list): # e.g., entity TUIs (all lowercased) vs list of target TUIs
            return any(item in crit_value_parsed for item in entity_value)
        # e.g., entity category (lowercased string) vs list of target categories
        return entity_value in crit_value_parsed 
            
    if op == "NOT_IN_LIST": # crit_value_parsed is a list of lowercase strings
        if not isinstance(crit_value_parsed, list): 
            logger.warning(f"NOT_IN_LIST operator expects a list, got {type(crit_value_parsed)} for crit ID {criterion.id}. Eval fails."); return False
        if isinstance(entity_value, list):
            return all(item not in crit_value_parsed for item in entity_value)
        return entity_value not in crit_value_parsed
            
    if op == "REGEX_MATCH": # entity_value is entity.text (original case)
        if isinstance(entity_value, str) and isinstance(crit_value_parsed, str): # crit_value_parsed is the regex string
            try: 
                # Perform case-insensitive regex match by default unless regex pattern specifies otherwise
                return bool(re.search(crit_value_parsed, entity_value, re.IGNORECASE))
            except re.error: 
                logger.warning(f"Invalid regex pattern '{crit_value_parsed}' in criterion ID {criterion.id}. Eval fails."); return False
        return False

    # Numeric comparisons (ensure entity_value is also numeric)
    if op in ['GREATER_THAN', 'LESS_THAN', 'GREATER_THAN_OR_EQUAL', 'LESS_THAN_OR_EQUAL']:
        if not isinstance(entity_value, (int, float)) or not isinstance(crit_value_parsed, (int, float)):
            logger.debug(f"Numeric comparison op '{op}' failed: non-numeric types. EntityVal: {type(entity_value)}, CritValParsed: {type(crit_value_parsed)}. CritID: {criterion.id}")
            return False
        if op == "GREATER_THAN": return entity_value > crit_value_parsed
        if op == "LESS_THAN": return entity_value < crit_value_parsed
        if op == "GREATER_THAN_OR_EQUAL": return entity_value >= crit_value_parsed
        if op == "LESS_THAN_OR_EQUAL": return entity_value <= crit_value_parsed

    logger.warning(f"Operator '{op}' not handled for criterion_type '{criterion.criterion_type}' (ID: {criterion.id}). Evaluation fails.")
    return False


def _evaluate_mapping_rule(entity: EnrichedEntity, rule: MappingRuleModel) -> bool:
    """Evaluates if an entity matches all/any criteria of a rule based on rule.match_logic."""
    if not rule.criteria:
        logger.debug(f"Rule ID {rule.id} ('{rule.rule_name}') has no criteria, defaulting to match.")
        return True # A rule with no criteria matches all entities

    eval_results = [_evaluate_criterion(entity, crit) for crit in rule.criteria]

    if rule.match_logic == "ALL_CRITERIA_MET":
        return all(eval_results)
    elif rule.match_logic == "ANY_CRITERION_MET":
        return any(eval_results)
    
    logger.warning(f"Unknown match_logic '{rule.match_logic}' for rule ID {rule.id}. Defaulting to false (no match).")
    return False


def _format_answer_from_config(entity: EnrichedEntity, answer_config: AnswerConfigModel) -> Optional[Dict[str, Any]]:
    """
    Formats a FHIR answer value (e.g., {"valueString": "text"}) based on the answer_config and entity.
    Uses EnrichedEntity fields and FHIR helper utilities.
    """
    answer: Dict[str, Any] = {}
    
    # Determine a primary string value from entity, often used for valueString or display text
    primary_display_text: Optional[str] = None
    # value_source_field from AnswerConfigModel determines which entity field to use for the *main value*
    src_field_name = answer_config.value_source_field
    
    if src_field_name == 'text': primary_display_text = entity.text
    elif src_field_name == 'preferred_name_ks' and entity.preferred_name_ks: primary_display_text = entity.preferred_name_ks
    elif src_field_name == 'primary_cui' and entity.primary_cui: primary_display_text = entity.primary_cui
    # Add other direct string fields from EnrichedEntity as needed for value_source_field
    elif not src_field_name: # If no specific source field, default to entity.text for string-based answers
        primary_display_text = entity.text
    elif hasattr(entity, src_field_name): # Generic catch-all for other string fields
        val = getattr(entity, src_field_name)
        if isinstance(val, str): primary_display_text = val
        # If val is not a string but source field matched, specific handlers below should take over (e.g. boolean)

    # --- Format based on fhir_answer_type ---
    if answer_config.fhir_answer_type == "valueString":
        if primary_display_text is not None:
            answer["valueString"] = primary_display_text
        # else: an explicit valueString type could not be formed
            
    elif answer_config.fhir_answer_type == "valueBoolean":
        bool_val_to_set: Optional[bool] = None
        # value_source_field determines which boolean attribute of entity to use
        if src_field_name == 'negated': bool_val_to_set = entity.negated
        elif src_field_name == 'historical': bool_val_to_set = entity.historical
        elif src_field_name == 'hypothetical': bool_val_to_set = entity.hypothetical
        elif src_field_name == 'family_history': bool_val_to_set = entity.family_history
        # If value_source_field doesn't match a boolean attribute, use default_boolean_value from config
        elif answer_config.default_boolean_value is not None:
            bool_val_to_set = answer_config.default_boolean_value
        else: 
            # Fallback: if an entity matches a rule configured for valueBoolean and no specific source/default,
            # it implies the presence/match itself is "true".
            bool_val_to_set = True 
        
        if bool_val_to_set is not None: # Ensure it's explicitly True or False
            answer["valueBoolean"] = bool_val_to_set

    elif answer_config.fhir_answer_type == "valueCoding":
        selected_sc: Optional[StandardCode] = None
        # Use coding_system_priority from AnswerConfigModel to pick the best StandardCode
        if answer_config.coding_system_priority and entity.standard_codes:
            selected_sc = get_standard_code_for_systems(entity.standard_codes, answer_config.coding_system_priority)
        
        if not selected_sc and entity.standard_codes: # Fallback to first available standard code if no priority match
            selected_sc = entity.standard_codes[0]

        final_coding = None
        if selected_sc:
            # create_fhir_coding should handle SAB lookup via FHIR_CODING_SYSTEM_MAP if selected_sc.vocabulary is SAB
            final_coding = create_fhir_coding(
                code=selected_sc.code, 
                system=selected_sc.vocabulary, # Assumes StandardCode.vocabulary holds the SAB like "SNOMEDCT_US"
                display=selected_sc.display or primary_display_text # Use standard code display, fallback to general text
            )
        elif entity.primary_cui: # Fallback to UMLS CUI if no other standard code found/selected
             final_coding = create_fhir_coding(
                 code=entity.primary_cui, 
                 system="UMLS", # Standard SAB for UMLS CUIs
                 display=entity.preferred_name_ks or primary_display_text
            )
        
        if final_coding:
            answer["valueCoding"] = final_coding
        # else: valueCoding could not be formed

    elif answer_config.fhir_answer_type == "valueCodeableConcept":
        codings_for_cc: List[Dict[str, Any]] = []
        # Add all available standard codes
        if entity.standard_codes:
            for sc in entity.standard_codes:
                fhir_coding = create_fhir_coding(
                code=sc.code, 
                system_key=sc.vocabulary, 
                display=sc.display or primary_display_text
                )
                if fhir_coding: codings_for_cc.append(fhir_coding)
        
        # Optionally, ensure primary CUI is included if not already present via a standard code mapping
        if entity.primary_cui:
            cui_system_uri = FHIR_CODING_SYSTEM_MAP.get("UMLS", "urn:oid:2.16.840.1.113883.6.86") # Default UMLS OID if map missing
            is_cui_already_present = any(
                c.get("code") == entity.primary_cui and c.get("system") == cui_system_uri 
                for c in codings_for_cc
            )
            if not is_cui_already_present:
                cui_coding = create_fhir_coding(
                code=entity.primary_cui, 
                system_key="UMLS", 
                display=entity.preferred_name_ks or primary_display_text
            )
                if cui_coding: codings_for_cc.append(cui_coding)
        
        # Determine text for the CodeableConcept
        cc_text = primary_display_text # Default
        if answer_config.codeable_concept_text_source == 'preferred_name_ks' and entity.preferred_name_ks:
            cc_text = entity.preferred_name_ks
        elif answer_config.codeable_concept_text_source == 'text' and entity.text: # Explicitly from entity.text
            cc_text = entity.text
        # If codeable_concept_text_source is None or unhandled, cc_text uses primary_display_text logic
            
        if codings_for_cc or cc_text: # A CodeableConcept needs at least one coding or text
            codeable_concept = create_fhir_codeable_concept(
                text=cc_text, 
                codings=codings_for_cc if codings_for_cc else None
            )
            if codeable_concept: 
                answer["valueCodeableConcept"] = codeable_concept
        # else: valueCodeableConcept could not be formed

    # TODO: Implement other fhir_answer_types as needed:
    # valueDate, valueDateTime, valueTime, valueInteger, valueDecimal, valueQuantity, valueReference, valueAttachment, etc.
    # Example for valueInteger (if value_source_field points to an int field in EnrichedEntity or can be parsed)
    # elif answer_config.fhir_answer_type == "valueInteger":
    #     try:
    #         # Assuming primary_display_text might hold a string representation of the integer
    #         # or value_source_field directly points to an integer field on the entity
    #         int_value = None
    #         if src_field_name and hasattr(entity, src_field_name):
    #             val = getattr(entity, src_field_name)
    #             if isinstance(val, int): int_value = val
    #             elif isinstance(val, str): int_value = int(val)
    #         elif primary_display_text:
    #             int_value = int(primary_display_text)
            
    #         if int_value is not None: answer["valueInteger"] = int_value
    #     except (ValueError, TypeError):
    #         logger.warning(f"Could not format valueInteger from '{primary_display_text or src_field_name}' for config '{answer_config.config_name}'.")

    return answer if answer else None # Return None if no valid answer part was constructed


def _process_questionnaire_item_from_config(
    item_definition: Dict[str, Any], # A single item from the FHIR Questionnaire definition
    template_mapping_config: TemplateMappingConfigModel, # The full config for the current template
    available_entities: List[EnrichedEntity],
    globally_used_entity_ids: Set[str] # Tracks entity IDs used by single-answer rules across the QR
) -> Optional[Dict[str, Any]]:
    """
    Processes a single Questionnaire item (and its sub-items recursively).
    Finds matching entities based on rules and formats answers.
    Returns a FHIR QuestionnaireResponse item dictionary, or None if no content.
    """
    qr_item_shell = {"linkId": item_definition["linkId"]}
    if "text" in item_definition: # Preserve original item text
        qr_item_shell["text"] = item_definition["text"]
    
    item_has_content = False # Flag to track if this item or its children get any answer/content
    
    # Check if there's a specific mapping configuration for this item's linkId
    item_specific_mapping = template_mapping_config.item_mappings.get(item_definition["linkId"])

    if item_specific_mapping:
        answers_for_this_item: List[Dict[str, Any]] = []
        # Iterate through rules for this item (rules are pre-sorted by priority)
        for rule in item_specific_mapping.rules:
            num_answers_from_this_rule = 0
            
            # Track CUIs added by THIS rule for THIS item, if it's a designated medication rule
            # Initialize as None, becomes a set if the condition is met
            added_cuis_for_this_rule: Optional[Set[str]] = None
            is_medication_rule_for_deduplication = False # Flag to simplify checks later

            # Define the condition for a medication rule that needs CUI deduplication
            # Example: rule.id == 8 or (hasattr(rule, 'rule_name') and rule.rule_name == 'Plan_Medications')
            # Adjust this condition as per your actual rule identification logic.
            # For this example, let's assume rule.id == 8 is the identifier.
            if rule.id == 8: # Replace with your actual condition
                is_medication_rule_for_deduplication = True
                added_cuis_for_this_rule = set()

            for entity in available_entities:
                # Stop if max_answers for this specific rule is reached (if > 0)
                if rule.max_answers > 0 and num_answers_from_this_rule >= rule.max_answers:
                    break 

                # Critical: If this rule is a "single-answer" type (max_answers == 1),
                # and the entity has already been used by *any other* single-answer rule globally, skip it.
                if rule.max_answers == 1 and entity.id in globally_used_entity_ids:
                    continue 

                if _evaluate_mapping_rule(entity, rule):
                    # If this is a medication rule requiring CUI deduplication, check if CUI already processed
                    if is_medication_rule_for_deduplication and added_cuis_for_this_rule is not None:
                        if entity.primary_cui and entity.primary_cui in added_cuis_for_this_rule:
                            continue # Already added this CUI by this rule for this item

                    answer = _format_answer_from_config(entity, rule.answer_config)
                    if answer:
                        answers_for_this_item.append(answer)
                        num_answers_from_this_rule += 1
                        item_has_content = True
                        
                        # If this rule is a single-answer rule, mark the entity as used globally for such rules.
                        if rule.max_answers == 1:
                            globally_used_entity_ids.add(entity.id)
                        
                        # If this was a medication rule and a CUI exists, add it to the tracking set for this rule
                        if is_medication_rule_for_deduplication and added_cuis_for_this_rule is not None and entity.primary_cui:
                            added_cuis_for_this_rule.add(entity.primary_cui)
            
            # If the Questionnaire item does not repeat (repeats=false) and we've found answers from this rule,
            # we can stop processing further (lower priority) rules for this item.
            if answers_for_this_item and not item_definition.get("repeats", False):
                break 
        
        if answers_for_this_item:
            qr_item_shell["answer"] = answers_for_this_item

    # Process sub-items recursively (for group items)
    if "item" in item_definition and isinstance(item_definition["item"], list):
        processed_sub_items = []
        for sub_item_def in item_definition["item"]:
            processed_sub_item = _process_questionnaire_item_from_config(
                sub_item_def, 
                template_mapping_config, # Pass the same top-level template config
                available_entities, 
                globally_used_entity_ids # Pass the same set to track usage across all items
            )
            if processed_sub_item: # Only add if sub-item has content
                processed_sub_items.append(processed_sub_item)
                item_has_content = True # Mark parent as having content if any child does
        
        if processed_sub_items:
            qr_item_shell["item"] = processed_sub_items
            
    # Only return the item shell if it or its children actually got content (answers)
    return qr_item_shell if item_has_content else None


async def create_questionnaire_response_from_config(
    questionnaire_definition: Dict[str, Any], # The FHIR Questionnaire resource
    enriched_entities: List[EnrichedEntity], 
    summary_text: Optional[str], # Optional overall summary from LLM
    context: Dict[str, Any] # Contains template_id, patient_ref, etc.
) -> Optional[Dict[str, Any]]:
    """
    Orchestrates the creation of a FHIR QuestionnaireResponse based on a Questionnaire definition,
    enriched entities, and database-driven mapping rules.
    """
    template_id = context.get("template_id")
    if not template_id:
        logger.error("`template_id` missing in context. Cannot load mapping configuration for QuestionnaireResponse.")
        return None

    # Load the comprehensive mapping configuration for this template
    mapping_config = await load_mapping_config_for_template(template_id)
    if not mapping_config: 
        logger.error(f"Failed to load mapping configuration for template_id: {template_id}. Cannot create QuestionnaireResponse.")
        return None
    if not mapping_config.item_mappings:
         logger.warning(f"No NLP item mapping rules found in DB for template_id: {template_id}. QuestionnaireResponse will not have NLP-derived answers beyond a potential summary.")

    logger.info(f"Creating QuestionnaireResponse for template '{template_id}' using config-driven mapper with {len(enriched_entities)} entities.")

    # Basic QuestionnaireResponse structure
    qr_id = str(uuid.uuid4())
    authored_time = datetime.now(timezone.utc).isoformat()
    
    questionnaire_response = {
        "resourceType": "QuestionnaireResponse", "id": qr_id,
        "status": "completed", # Or "in-progress" depending on workflow
        "authored": authored_time,
    }
    
    # Link to the source Questionnaire
    if questionnaire_definition.get("url"):
        qr_questionnaire_ref = questionnaire_definition["url"]
        if questionnaire_definition.get("version"):
             qr_questionnaire_ref += f"|{questionnaire_definition['version']}"
        questionnaire_response["questionnaire"] = qr_questionnaire_ref
    elif template_id: # Fallback to logical ID if URL not in definition
        questionnaire_response["questionnaire"] = f"Questionnaire/{template_id}" # Or construct a canonical URL if possible

    # Contextual references
    if context.get("patient_ref"): questionnaire_response["subject"] = {"reference": context["patient_ref"]}
    if context.get("encounter_ref"): questionnaire_response["encounter"] = {"reference": context["encounter_ref"]}
    # Author: default to service if not provided
    questionnaire_response["author"] = {"reference": context["author_ref"]} if context.get("author_ref") else {"type": "Device", "display": "Clinical AI Service"}

    qr_top_level_items: List[Dict[str, Any]] = []
    # This set tracks entity IDs used by rules with max_answers=1 *across the entire QR*
    # to prevent using the same entity for multiple exclusive-choice answers.
    globally_used_entity_ids_for_single_answer_rules: Set[str] = set() 

    if "item" in questionnaire_definition and isinstance(questionnaire_definition["item"], list):
        for item_def in questionnaire_definition["item"]: # Iterate through top-level items of Questionnaire
            item_link_id = item_def["linkId"]
            
            # Special handling for a designated summary item (e.g., linkId "nlp-notes-summary")
            # This could be made more generic by defining a rule for it in the database.
            if item_link_id == "nlp-notes-summary" and summary_text:
                summary_qr_item_ans = {"linkId": item_link_id}
                if "text" in item_def: summary_qr_item_ans["text"] = item_def["text"]
                summary_qr_item_ans["answer"] = [{"valueString": summary_text}]
                qr_top_level_items.append(summary_qr_item_ans)
                continue # Move to next top-level item

            # For all other items, use the recursive, config-driven processing
            processed_item = _process_questionnaire_item_from_config(
                item_def,
                mapping_config, 
                enriched_entities,
                globally_used_entity_ids_for_single_answer_rules
            )
            if processed_item: # Only add if the item (or its children) got answers
                qr_top_level_items.append(processed_item)
    
    if qr_top_level_items: # Only add 'item' array if there's content
        questionnaire_response["item"] = qr_top_level_items
    else:
        logger.info(f"No items in QuestionnaireResponse for template '{template_id}' after processing. May indicate no matching entities or rules yielded answers.")
        if not qr_top_level_items:
            logger.info(f"No items matched database rules. Attempting direct category-based mapping.")
            
            # Group entities by backend_category
            section_content = {"subjective": [], "objective": [], "assessment": [], "plan": []}
            
            for entity in enriched_entities:
                backend_cat = entity.backend_category
                if backend_cat in ["SYMPTOM", "SIGN"]:
                    section_content["subjective"].append(entity)
                elif backend_cat in ["OBSERVATION", "VITAL_SIGN", "LAB_RESULT", "ANATOMY"]:
                    section_content["objective"].append(entity)
                elif backend_cat in ["CONDITION", "PROBLEM", "DIAGNOSIS"]:
                    section_content["assessment"].append(entity)
                elif backend_cat in ["DRUG", "PROCEDURE", "TREATMENT"]:
                    section_content["plan"].append(entity)
            
            # Format each section's content
            for section_id, entities_list in section_content.items():
                if entities_list:
                    entity_strings = []
                    for entity in entities_list:
                        display_text = entity.preferred_name_ks or entity.text
                        entity_strings.append(f"- {display_text}")
                    
                    if entity_strings:
                        section_item = {
                            "linkId": section_id,
                            "answer": [{"valueString": "\n".join(entity_strings)}]
                        }
                        qr_top_level_items.append(section_item)
                        
            if qr_top_level_items:
                logger.info(f"Direct category mapping added {len(qr_top_level_items)} items to QR for template '{template_id}'")
                # Depending on requirements, you might still return the QR shell or None.
                # For now, returning it with an empty 'item' list is also valid FHIR.
                questionnaire_response["item"] = []


    return questionnaire_response