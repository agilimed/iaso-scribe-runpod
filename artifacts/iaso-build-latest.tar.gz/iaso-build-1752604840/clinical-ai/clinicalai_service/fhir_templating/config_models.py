# clinicalai_service/fhir_templating/config_models.py
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field

class AnswerConfigModel(BaseModel):
    id: int
    config_name: str
    fhir_answer_type: str
    value_source_field: Optional[str] = None
    coding_system_priority: Optional[List[str]] = Field(default_factory=list)
    codeable_concept_text_source: Optional[str] = None
    default_boolean_value: Optional[bool] = None

class RuleCriterionModel(BaseModel):
    id: int
    criterion_type: str
    operator: str
    criterion_value: Optional[str] = None # Can be None for operators like IS_NULL, IS_TRUE

class MappingRuleModel(BaseModel):
    id: int
    rule_name: Optional[str] = None
    match_logic: str # 'ALL_CRITERIA_MET' or 'ANY_CRITERION_MET'
    answer_config: AnswerConfigModel # Nested AnswerConfigModel
    max_answers: int
    priority: int
    criteria: List[RuleCriterionModel] = Field(default_factory=list)

class TemplateItemMappingModel(BaseModel):
    id: int
    item_link_id: str
    description: Optional[str] = None
    rules: List[MappingRuleModel] = Field(default_factory=list)

class TemplateMappingConfigModel(BaseModel):
    template_id: str
    item_mappings: Dict[str, TemplateItemMappingModel] = Field(default_factory=dict) # Keyed by item_link_id