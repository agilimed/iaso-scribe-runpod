# clinicalai_service/fhir_templating/questionnaire_mapper.py
import uuid
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional, Set

from ..models import EnrichedEntity, StandardCode
from ..utils import logger, create_fhir_coding, create_fhir_codeable_concept, get_standard_code_for_systems

# Define URL for your custom NLP placeholder extension
NLP_PLACEHOLDER_EXTENSION_URL = "http://agilimed.ai/nlp-placeholder" # As per your template

# Mapping from NLP placeholder values to the backend categories they might primarily represent
# This is a heuristic and might need refinement based on how you categorize NLP entities.
PLACEHOLDER_TO_PRIMARY_CATEGORIES: Dict[str, List[str]] = {
    "nlp_subjective": ["CONDITION", "SYMPTOM", "OBSERVATION"], # Symptoms, patient-reported history
    "nlp_objective": ["OBSERVATION", "LAB_RESULT", "VITAL_SIGN", "PHYSICAL_FINDING"], # Exam findings, vitals, labs
    "nlp_assessment": ["CONDITION", "DIAGNOSIS", "PROBLEM"], # Diagnoses
    "nlp_plan": ["DRUG", "PROCEDURE", "ORDER", "THERAPY"], # Medications, treatments
    "nlp_notes": [], # Special case for summary or uncategorized text
}

# Mapping from placeholder to the sections of the clinical note they might correspond to.
# This helps filter entities by section for more relevance. Case-insensitive matching for section titles.
# The keys are the placeholder values (e.g., "nlp_subjective").
# The values are lists of section titles (or regex patterns for titles) that map to that placeholder.
# Use lowercase for matching against `entity.section_title.lower()`.
PLACEHOLDER_TO_SECTION_KEYWORDS: Dict[str, List[str]] = {
    "nlp_subjective": [
        "chief complaint", "history of present illness", "hpi", 
        "review of systems", "ros", "subjective"
    ],
    "nlp_objective": [
        "physical exam", "physical examination", "exam", "pe", 
        "vital signs", "vitals", "laboratory data", "labs", "results", 
        "imaging", "radiology", "objective"
    ],
    "nlp_assessment": ["assessment", "impression", "diagnosis", "problem list", "assessment and plan"],
    "nlp_plan": ["plan", "recommendations", "orders", "treatment", "medications", "assessment and plan"],
    "nlp_notes": [] # Typically filled by LLM summary or general text
}


def _get_nlp_placeholder_value(item_extensions: List[Dict[str, Any]]) -> Optional[str]:
    """Extracts the NLP placeholder valueString from item extensions."""
    if not item_extensions:
        return None
    for extension in item_extensions:
        if extension.get("url") == NLP_PLACEHOLDER_EXTENSION_URL and "valueString" in extension:
            return extension["valueString"]
    return None

def _create_default_answer_for_entity(entity: EnrichedEntity) -> Optional[Dict[str, Any]]:
    """
    Creates a default FHIR answer (CodeableConcept or Coding) for an entity.
    Prioritizes SNOMED, then RxNorm, then LOINC, then first available standard code, then CUI.
    """
    answer = {}
    
    # Try to create a CodeableConcept first
    codings = []
    if entity.standard_codes:
        # Prioritize specific systems for the CodeableConcept's primary display/coding
        priority_systems = ["SNOMEDCT_US", "SNOMED", "RXNORM", "LOINC", "ICD10CM"] # Example priority
        
        # Add all standard codes
        for sc in entity.standard_codes:
            fhir_coding = create_fhir_coding(sc.code, sc.vocabulary, sc.display)
            if fhir_coding:
                codings.append(fhir_coding)
        
    # Ensure UMLS CUI is present if available and not redundant
    if entity.primary_cui:
        # Check if a coding for this CUI (from UMLS system) is already there from standard_codes if one of them was UMLS
        cui_system_uri = FHIR_CODING_SYSTEM_MAP.get("UMLS")
        is_cui_already_coded = any(
            c.get("code") == entity.primary_cui and c.get("system") == cui_system_uri
            for c in codings
        )
        if not is_cui_already_coded:
            cui_display_name = entity.preferred_name_ks or entity.text
            cui_fhir_coding = create_fhir_coding(entity.primary_cui, "UMLS", cui_display_name)
            if cui_fhir_coding:
                codings.append(cui_fhir_coding)

    # Text for the CodeableConcept
    cc_text = entity.preferred_name_ks or entity.text # Use preferred name if available, else original text

    if codings:
        codeable_concept = create_fhir_codeable_concept(text=cc_text, codings=codings)
        if codeable_concept:
            answer["valueCodeableConcept"] = codeable_concept
    elif cc_text: # If no codings, but we have text, use valueString
        answer["valueString"] = cc_text
        
    return answer if answer else None


def _filter_entities_for_placeholder(
    placeholder_value: str,
    available_entities: List[EnrichedEntity]
) -> List[EnrichedEntity]:
    """Filters entities based on the placeholder type (subjective, objective, etc.)."""
    relevant_entities = []
    
    primary_categories = PLACEHOLDER_TO_PRIMARY_CATEGORIES.get(placeholder_value, [])
    section_keywords = PLACEHOLDER_TO_SECTION_KEYWORDS.get(placeholder_value, [])

    for entity in available_entities:
        # Skip ignored or very generic entities unless placeholder is 'nlp_notes'
        if entity.backend_category in ["IGNORE", "OTHER_CONCEPT", "UNKNOWN_CATEGORY"] and placeholder_value != "nlp_notes":
            continue
        
        # Simple filter: entity must not be negated if we're filling a positive assertion
        if entity.negated and placeholder_value not in ["nlp_notes"]: # Could allow negated for nlp_notes
            continue # This is a very basic filter for negation

        category_match = False
        if not primary_categories: # If no primary categories defined, consider it a match (e.g., for 'nlp_notes')
            category_match = True
        elif entity.backend_category in primary_categories:
            category_match = True

        section_match = False
        if not section_keywords: # If no section keywords, consider it a match (e.g. for 'nlp_notes')
            section_match = True
        elif entity.section_title:
            entity_section_lower = entity.section_title.lower()
            for keyword in section_keywords:
                if keyword in entity_section_lower: # Simple substring match
                    section_match = True
                    break
        
        # For now, require both category (if specified) and section (if specified) to match
        # Or, if it's 'nlp_notes', it might take more things.
        if placeholder_value == "nlp_notes" or (category_match and section_match):
            relevant_entities.append(entity)
            
    logger.debug(f"For placeholder '{placeholder_value}', filtered {len(available_entities)} down to {len(relevant_entities)} relevant entities.")
    return relevant_entities


def _process_single_qr_item_with_placeholder(
    item_def: Dict[str, Any],
    placeholder_value: str,
    available_entities: List[EnrichedEntity],
    used_entity_ids: Set[str] # Keep track of entities used
) -> Optional[Dict[str, Any]]:
    """Processes a Questionnaire item that has an NLP placeholder."""
    
    qr_item = {"linkId": item_def["linkId"]}
    if "text" in item_def:
        qr_item["text"] = item_def["text"]
    
    answers = []
    
    # Filter entities relevant to this placeholder (e.g., "nlp_subjective")
    relevant_entities = _filter_entities_for_placeholder(placeholder_value, available_entities)
    
    # Your template has "repeats": true, so we can add multiple answers
    # For simplicity, let's add all relevant, non-used entities as answers
    for entity in relevant_entities:
        if entity.id in used_entity_ids: # Basic check to avoid reusing same entity for different top-level placeholders
            continue                 # This might need more nuanced logic depending on desired output

        answer_value = _create_default_answer_for_entity(entity)
        if answer_value:
            answers.append(answer_value)
            used_entity_ids.add(entity.id) # Mark as used globally across placeholders for now

    if answers:
        qr_item["answer"] = answers
        return qr_item
    
    return None # Return None if no answers were generated for this item

def _process_item_recursive(
    item_def: Dict[str, Any],
    enriched_entities: List[EnrichedEntity],
    used_entity_ids: Set[str] # Track used entities globally
) -> Optional[Dict[str, Any]]:
    """Recursively processes questionnaire items."""
    qr_item_shell = {"linkId": item_def["linkId"]}
    if "text" in item_def:
        qr_item_shell["text"] = item_def["text"]
    
    # Check for NLP placeholder at this item level
    placeholder_value = _get_nlp_placeholder_value(item_def.get("extension", []))
    
    item_has_content = False
    
    if placeholder_value:
        # This item directly maps to an NLP placeholder
        # We create answers based on entities matching this placeholder
        
        # Special case for "nlp_notes" which might be filled by a summary later, not entities directly here
        if placeholder_value == "nlp_notes":
            # We will handle this specifically after the loop, or it could take a summary string
            # For now, let's not populate it with individual entities.
            pass
        else:
            relevant_entities_for_placeholder = _filter_entities_for_placeholder(placeholder_value, enriched_entities)
            item_answers = []
            for entity in relevant_entities_for_placeholder:
                if entity.id in used_entity_ids and not item_def.get("repeats", False):
                    continue # Skip if entity used and item doesn't repeat (though your template uses repeats=true)
                
                answer = _create_default_answer_for_entity(entity)
                if answer:
                    item_answers.append(answer)
                    used_entity_ids.add(entity.id) # Mark as used

            if item_answers:
                qr_item_shell["answer"] = item_answers
                item_has_content = True
    
    # Process sub-items, if any
    if "item" in item_def and isinstance(item_def["item"], list):
        processed_sub_items = []
        for sub_item_def in item_def["item"]:
            processed_sub = _process_item_recursive(sub_item_def, enriched_entities, used_entity_ids)
            if processed_sub:
                processed_sub_items.append(processed_sub)
                item_has_content = True # If any sub-item has content, the parent group has content
        if processed_sub_items:
            qr_item_shell["item"] = processed_sub_items
            
    return qr_item_shell if item_has_content else None


def create_questionnaire_response(
    questionnaire_definition: Dict[str, Any], 
    enriched_entities: List[EnrichedEntity], 
    summary_text: Optional[str], # Added for nlp_notes placeholder
    context: Dict[str, Any]
) -> Optional[Dict[str, Any]]:
    if not questionnaire_definition:
        logger.warning("Questionnaire definition missing, cannot create QuestionnaireResponse.")
        return None

    logger.info(f"Starting QuestionnaireResponse creation for template '{context.get('template_id', 'N/A')}'.")

    qr_id = str(uuid.uuid4())
    authored_time = datetime.now(timezone.utc).isoformat()
    
    questionnaire_response = {
        "resourceType": "QuestionnaireResponse",
        "id": qr_id,
        "status": "completed",
        "authored": authored_time,
    }
    
    if questionnaire_definition.get("url"):
        questionnaire_response["questionnaire"] = questionnaire_definition["url"]
        if questionnaire_definition.get("version"):
             questionnaire_response["questionnaire"] += f"|{questionnaire_definition['version']}"
    elif context.get("template_id"):
        questionnaire_response["questionnaire"] = f"Questionnaire/{context['template_id']}"

    if context.get("patient_ref"):
        questionnaire_response["subject"] = {"reference": context["patient_ref"]}
    if context.get("encounter_ref"):
        questionnaire_response["encounter"] = {"reference": context["encounter_ref"]}
    if context.get("author_ref"):
        questionnaire_response["author"] = {"reference": context["author_ref"]}
    else:
        questionnaire_response["author"] = {"type": "Device", "display": "Clinical AI Service"}

    qr_top_level_items = []
    # Keep track of entities used to avoid over-populating across different placeholders
    # if an entity could fit multiple. A more sophisticated approach might be needed.
    globally_used_entity_ids: Set[str] = set() 

    if "item" in questionnaire_definition and isinstance(questionnaire_definition["item"], list):
        for item_def in questionnaire_definition["item"]:
            placeholder_value = _get_nlp_placeholder_value(item_def.get("extension", []))
            
            processed_item_content = None
            if placeholder_value == "nlp_notes" and summary_text:
                # Handle the summary placeholder specifically
                processed_item_content = {
                    "linkId": item_def["linkId"],
                    "text": item_def.get("text", "Summary Notes"),
                    "answer": [{"valueString": summary_text}]
                }
            elif placeholder_value: # Other placeholders like nlp_subjective, nlp_objective etc.
                 processed_item_content = _process_single_qr_item_with_placeholder(
                     item_def, 
                     placeholder_value, 
                     enriched_entities, 
                     globally_used_entity_ids
                 )
            else: # Item without a direct NLP placeholder, process recursively for sub-items
                processed_item_content = _process_item_recursive(
                    item_def, 
                    enriched_entities, 
                    globally_used_entity_ids
                )

            if processed_item_content:
                qr_top_level_items.append(processed_item_content)
    
    if not qr_top_level_items:
        logger.info(f"No items were populated in QuestionnaireResponse for template '{context.get('template_id', 'N/A')}'.")
    
    questionnaire_response["item"] = qr_top_level_items
    
    return questionnaire_response