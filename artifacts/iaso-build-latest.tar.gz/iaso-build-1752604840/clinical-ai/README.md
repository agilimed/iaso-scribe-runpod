# NexusCare AI Backend

A healthcare AI platform providing clinical text processing, terminology management, knowledge services, and intelligent document templating.

## 🏗️ Architecture Overview

The NexusCare AI Backend consists of 6 microservices that work together to provide advanced clinical AI capabilities:

```
┌─────────────────────────────────────────────────────────────────┐
│                    NexusCare AI Backend                         │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐  │
│  │ Clinical AI     │  │ Terminology     │  │ Knowledge       │  │
│  │ Service         │  │ Service         │  │ Service         │  │
│  │ Port: 8002      │  │ Port: 8001      │  │ Port: 8004      │  │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘  │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐  │
│  │ Template        │  │ SLM Service     │  │ SLM Local       │  │
│  │ Service         │  │ (Remote LLM)    │  │ (Local Models)  │  │
│  │ Port: 8003      │  │ Port: 8007      │  │ Standalone      │  │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

## 🚀 Quick Start

### Prerequisites

- Python 3.11+
- PostgreSQL 17
- Redis/KeyDB with RediSearch
- MeiliSearch
- Docker & Docker Compose (optional)

### 1. Environment Setup

```bash
# Clone the repository
git clone <repository-url>
cd nexus-care-ai-backend

# Create and activate virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Environment Configuration

Create a `.env` file in the root directory:

```env
# Database Configuration
POSTGRES_DB=nexus_care
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_password
PG_HOST_SRC=localhost
PG_PORT=5432

# MeiliSearch Configuration
MEILISEARCH_HOST=http://localhost:7700
MEILISEARCH_MASTER_KEY=your_master_key
MEILISEARCH_INDEX_NAME=concepts_umls_v2

# Redis Configuration
REDIS_HOST=localhost
REDIS_PORT=6379

# Service URLs
TERMINOLOGY_SERVICE_URL=http://localhost:8001
KNOWLEDGE_SERVICE_URL=http://localhost:8004
TEMPLATE_SERVICE_URL=http://localhost:8003
LLM_SERVICE_URL=http://localhost:8007

# ClinicalBERT Configuration
ENABLE_CLINICAL_BERT=true
CLINICAL_BERT_MODEL_NAME=emilyalsentzer/Bio_ClinicalBERT
CLINICAL_BERT_MAX_LENGTH=512
CLINICAL_BERT_CHUNK_OVERLAP=50
CLINICAL_BERT_AGGREGATION_METHOD=weighted_average

# LLM Configuration (for SLM Service)
RUNPOD_API_BASE=https://api.runpod.ai/v2
RUNPOD_ENDPOINT_ID=your_endpoint_id
RUNPOD_API_KEY=your_api_key
```

### 3. Start Infrastructure Services

```bash
# Start PostgreSQL, Redis, and MeiliSearch
docker-compose up -d keydb meilisearch postgres_templates
```

### 4. Start Application Services

```bash
# Option 1: Use the startup script
chmod +x start_services.sh
./start_services.sh

# Option 2: Start services individually
# Terminal 1 - Terminology Service
cd terminology_service && uvicorn main:app --host 0.0.0.0 --port 8001

# Terminal 2 - Clinical AI Service  
cd clinicalai_service && uvicorn main:app --host 0.0.0.0 --port 8002

# Terminal 3 - Template Service
cd template_service && uvicorn main:app --host 0.0.0.0 --port 8003

# Terminal 4 - Knowledge Service
cd knowledge_service && uvicorn main:app --host 0.0.0.0 --port 8004

# Terminal 5 - SLM Service (optional)
cd slm_service && uvicorn main:app --host 0.0.0.0 --port 8007
```

## 📋 Services Overview

### 1. Clinical AI Service (Port 8002)

**Purpose**: Core NLP processing engine for clinical text analysis

**Key Features**:
- **MedCAT Integration**: Medical concept extraction using trained models
- **ClinicalBERT**: Advanced embeddings with automatic chunking for long texts
- **spaCy NLP Pipeline**: Named entity recognition and linguistic analysis
- **FHIR Integration**: Converts clinical entities to FHIR-compliant formats
- **Multi-model Support**: Dynamic switching between different ClinicalBERT models

**Key Endpoints**:
- `POST /process` - Process clinical notes and extract entities
- `POST /clinical-bert/embeddings` - Generate embeddings for clinical text
- `POST /clinical-bert/similarity` - Calculate semantic similarity
- `GET /clinical-bert/status` - Check ClinicalBERT model status

**Technologies**:
- FastAPI, spaCy, MedCAT, Transformers (ClinicalBERT)
- PostgreSQL for entity caching
- Advanced chunking for handling long clinical documents

### 2. Terminology Service (Port 8001)

**Purpose**: High-performance clinical terminology search and matching

**Key Features**:
- **MeiliSearch Integration**: Lightning-fast full-text search
- **UMLS Support**: Comprehensive medical terminology coverage
- **Pattern Matching**: Intelligent clinical term recognition in text
- **Multi-vocabulary Support**: SNOMED CT, ICD-10, RxNorm, LOINC, etc.
- **Advanced Filtering**: Search by semantic types, vocabularies, sources

**Key Endpoints**:
- `GET /search` - Search clinical concepts with filters
- `POST /pattern_match` - Find clinical terms in unstructured text
- `GET /concepts/{cui}` - Get detailed concept information

**Technologies**:
- FastAPI, MeiliSearch, UMLS terminology data
- Caching layer for performance optimization

### 3. Knowledge Service (Port 8004)

**Purpose**: Detailed medical concept information and relationships

**Key Features**:
- **Concept Enrichment**: Detailed information about medical concepts
- **Code Mappings**: Cross-vocabulary code translations
- **Hierarchical Relationships**: Parent/child concept relationships
- **PostgreSQL Backend**: Robust data storage and querying

**Key Endpoints**:
- `GET /api/v1/concepts/{cui}/codes` - Get all codes for a concept
- `GET /api/v1/concepts/{cui}/relationships` - Get concept relationships
- `GET /health` - Service health check

**Technologies**:
- FastAPI, PostgreSQL, SQLAlchemy
- Optimized queries for large terminology datasets

### 4. Template Service (Port 8003)

**Purpose**: FHIR Questionnaire template management

**Key Features**:
- **FHIR Questionnaire Storage**: Manage clinical questionnaire templates
- **Template Versioning**: Track template changes over time
- **Metadata Management**: Encounter types, tags, and classifications
- **PostgreSQL Storage**: Reliable template persistence

**Key Endpoints**:
- `POST /templates` - Create new questionnaire templates
- `GET /templates` - List templates with filtering
- `GET /templates/{id}` - Get specific template
- `PATCH /templates/{id}/metadata` - Update template metadata
- `DELETE /templates/{id}` - Delete templates

**Technologies**:
- FastAPI, PostgreSQL, SQLAlchemy, Pydantic
- FHIR R4 compliance

### 5. SLM Service (Port 8007)

**Purpose**: Large Language Model orchestration for clinical tasks

**Key Features**:
- **RunPod Integration**: Remote LLM processing via RunPod API
- **Multi-task Support**: Summarization, extraction, Q&A, template conversion
- **Entity Integration**: Combines with Clinical AI Service for enhanced prompts
- **Template Integration**: FHIR questionnaire response generation
- **Streaming Support**: Real-time response streaming

**Key Endpoints**:
- `POST /process` - Process text with LLM for various tasks
- `POST /stream-process` - Streaming LLM responses
- `GET /health` - Check LLM provider connectivity

**Technologies**:
- FastAPI, httpx for async HTTP calls
- RunPod API integration, Phi-3 model support

### 6. SLM Local (Standalone)

**Purpose**: Local small language model inference

**Key Features**:
- **Local Model Execution**: Run models locally without external dependencies
- **Mistral & Phi-3 Support**: Multiple model options
- **GGUF Format**: Optimized quantized models for efficiency
- **Clinical Prompting**: Specialized prompts for medical text processing
- **Retry Logic**: Robust error handling and recovery

**Key Endpoints**:
- `POST /generate` - Generate text using local models
- `GET /health` - Service health check

**Technologies**:
- FastAPI, llama-cpp-python
- GGUF quantized models, local GPU/CPU inference

## 🔧 Configuration

### ClinicalBERT Configuration

The Clinical AI Service includes advanced ClinicalBERT integration with automatic chunking:

```env
# Enable/disable ClinicalBERT
ENABLE_CLINICAL_BERT=true

# Model selection
CLINICAL_BERT_MODEL_NAME=emilyalsentzer/Bio_ClinicalBERT

# Chunking configuration for long texts
CLINICAL_BERT_MAX_LENGTH=512
CLINICAL_BERT_CHUNK_OVERLAP=50
CLINICAL_BERT_MIN_CHUNK_SIZE=100
CLINICAL_BERT_AGGREGATION_METHOD=weighted_average

# Performance settings
CLINICAL_BERT_BATCH_SIZE=8
CLINICAL_BERT_FORCE_CPU=false
```

### MedCAT Configuration

```env
# MedCAT model paths
MEDCAT_MODEL_PACK_ROOT=clinicalai_service/models/trained_medcat_model

# MedCAT settings
MEDCAT_SIMILARITY_THRESHOLD=0.25
MEDCAT_MIN_NAME_LENGTH=3
MEDCAT_MAX_NAME_LENGTH=10
MEDCAT_FORCE_CPU=true
```

## 📊 API Documentation

Each service provides interactive API documentation:

- Clinical AI Service: http://localhost:8002/docs
- Terminology Service: http://localhost:8001/docs
- Knowledge Service: http://localhost:8004/docs
- Template Service: http://localhost:8003/docs
- SLM Service: http://localhost:8007/docs

## 🧪 Testing

### Health Checks

```bash
# Check all services
curl http://localhost:8001/health  # Terminology
curl http://localhost:8002/health  # Clinical AI
curl http://localhost:8003/health  # Template
curl http://localhost:8004/health  # Knowledge
curl http://localhost:8007/health  # SLM Service
```

### Example API Calls

#### Process Clinical Text

```bash
curl -X POST "http://localhost:8002/process" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Patient has diabetes mellitus type 2 and takes metformin 500mg daily.",
    "enable_clinical_bert": true,
    "perform_summarization": false
  }'
```

#### Search Medical Concepts

```bash
curl -X GET "http://localhost:8001/search?term=diabetes&limit=5"
```

#### Generate Clinical Summary

```bash
curl -X POST "http://localhost:8007/process" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Patient presents with chest pain and shortness of breath...",
    "task_type": "clinical_summary",
    "include_medcat_entities": true
  }'
```

## 🔍 Monitoring and Logging

### Log Locations

- Clinical AI Service: `clinicalai_service/logs/`
- SLM Service: `slm_service/logs/`
- SLM Local: `slm_local/logs/`

### Performance Monitoring

Each service includes:
- Request timing middleware
- Health check endpoints
- Detailed error logging
- Performance metrics

## 🛠️ Development

### Adding New Models

#### ClinicalBERT Models

```python
# Add to clinicalai_service/nlp_engine/clinical_bert.py
class ClinicalBERTModel(Enum):
    YOUR_MODEL = "your/model-name"
```

#### Local SLM Models

```python
# Add to slm_local/slm_mistral.py
MODEL_REGISTRY = {
    "your_model": "./models/your-model.gguf"
}
```

### Custom Endpoints

Each service follows FastAPI patterns. Add new endpoints by:

1. Define Pydantic models for request/response
2. Add endpoint functions with proper decorators
3. Include in router if using modular structure
4. Update API documentation

## 🚨 Troubleshooting

### Common Issues

#### ClinicalBERT Tensor Size Errors

The system includes automatic chunking for long texts. If you see tensor size mismatch errors:

```bash
# Check chunking configuration
grep -r "CHUNK" .env

# Verify model loading
curl http://localhost:8002/clinical-bert/status
```

#### MeiliSearch Connection Issues

```bash
# Check MeiliSearch status
curl http://localhost:7700/health

# Verify API key
echo $MEILISEARCH_MASTER_KEY
```

#### Database Connection Problems

```bash
# Test PostgreSQL connection
psql -h localhost -p 5432 -U postgres -d nexus_care

# Check service logs
tail -f knowledge_service/logs/*.log
```

### Performance Optimization

#### For Large Clinical Documents

- Enable ClinicalBERT chunking
- Adjust `CLINICAL_BERT_CHUNK_OVERLAP` for better context preservation
- Use `weighted_average` aggregation for better semantic representation

#### For High-Volume Processing

- Increase `CLINICAL_BERT_BATCH_SIZE`
- Enable Redis caching
- Use connection pooling for databases

## 📈 Scaling

### Horizontal Scaling

Each service can be scaled independently:

```yaml
# docker-compose.yml
clinical-ai-service:
  deploy:
    replicas: 3
  ports:
    - "8002-8004:8002"
```

### Load Balancing

Use nginx or similar for load balancing:

```nginx
upstream clinical_ai {
    server localhost:8002;
    server localhost:8003;
    server localhost:8004;
}
```

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:

- Create an issue in the repository
- Check the API documentation at `/docs` endpoints
- Review service logs for detailed error information

---

**NexusCare AI Backend** - Advancing healthcare through intelligent clinical text processing and AI-powered medical insights. 