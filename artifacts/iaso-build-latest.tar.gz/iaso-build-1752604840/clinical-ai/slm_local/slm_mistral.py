from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, validator
from llama_cpp import Llama
from tenacity import retry, stop_after_attempt, wait_fixed, RetryError
import logging
import os
import traceback

# === CONFIGURATION ===
MODEL_REGISTRY = {
    "mistral": "./models/Asclepius-Mistral-7B-v0.3.Q5_K_M.gguf",
    "phi3": "./models/phi3/Phi-3-medium-128k-instruct-Q4_K_M.gguf"
}
LOG_PATH = "./logs/slm_api.log"
os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)

# === LOGGING ===
logging.basicConfig(
    filename=LOG_PATH,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# === FASTAPI APP ===
app = FastAPI()

# === MODEL CACHE ===
model_cache = {}

def get_llm(model_id: str) -> Llama:
    if model_id not in MODEL_REGISTRY:
        raise HTTPException(status_code=400, detail=f"Unknown model ID: {model_id}")
    if model_id not in model_cache:
        logging.info(f"Loading model: {model_id}")
        if model_id == "phi3":
            # Phi-3 safety overrides to avoid segfaults
            model_cache[model_id] = Llama(
                model_path=MODEL_REGISTRY[model_id],
                n_ctx=2048,           # Reduced context to stay within system memory
                n_threads=4,
                n_batch=64,
                use_mmap=True,
                use_mlock=False,
                n_gpu_layers=0        # Force CPU inference for stability
            )
        else:
            model_cache[model_id] = Llama(
                model_path=MODEL_REGISTRY[model_id],
                n_ctx=4096,
                n_threads=8
            )
    return model_cache[model_id]

# === REQUEST MODEL ===
class PromptRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=16000)
    max_tokens: int = Field(default=256, ge=1, le=1024)
    model_id: str = Field(default="mistral")

    @validator("prompt")
    def clean_prompt(cls, v):
        if not v.strip():
            raise ValueError("Prompt must not be empty or whitespace.")
        return v.strip()

# === RETRY LOGIC ===
@retry(wait=wait_fixed(2), stop=stop_after_attempt(3))
def generate_response(llm: Llama, prompt: str, max_tokens: int):
    logging.info(f"LLM REQUEST: {prompt[:200]}... (max_tokens={max_tokens})")
    response = llm(
        prompt,
        max_tokens=max_tokens,
        stop=["</s>"],
        temperature=0.1,
        top_p=0.8
    )
    text = response["choices"][0]["text"].strip()
    logging.info(f"LLM RESPONSE: {text[:200]}...")
    return text

# === GENERATE ENDPOINT ===
@app.post("/generate")
def generate_text(request: PromptRequest):
    system_prompt = (
        "You are a clinical-grade medical assistant. Extract only **positively affirmed** concepts from the following patient note. "
        "Categorise findings into the following JSON format:\n\n"
        "{\n"
        '  "conditions": [...],\n'
        '  "symptoms": [...],\n'
        '  "family_history": [...],\n'
        '  "lifestyle": [...]\n'
        "}\n\n"
        "Do not include denied, uncertain, or hallucinated items. Only use what is explicitly stated. Do not hallucinate."
    )
    final_prompt = f"{system_prompt}\n\nPatient Note:\n{request.prompt.strip()}\n\nReturn JSON:"

    try:
        llm = get_llm(request.model_id)
        output_text = generate_response(llm, final_prompt, request.max_tokens)
        return {"output": output_text}
    except RetryError as re:
        logging.error(f"LLM RetryError: {str(re)}")
        raise HTTPException(status_code=503, detail="Model temporarily unavailable. Please try again later.")
    except Exception as e:
        logging.error("LLM Error: %s", traceback.format_exc())
        raise HTTPException(status_code=500, detail="Internal server error during model inference.")

# === HEALTH CHECK ===
@app.get("/health")
def health_check():
    return {"status": "ok"}
