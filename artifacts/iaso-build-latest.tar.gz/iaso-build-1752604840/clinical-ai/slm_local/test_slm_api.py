import pytest
from httpx import AsyncClient
from slm_mistral import app

pytestmark = pytest.mark.asyncio

async def test_generate_text():
    async with AsyncClient(app=app, base_url="http://localhost:8008") as ac:
        response = await ac.post("/generate", json={
            "prompt": "Patient has fever and cough. He has hypertension and cognitive heart disease. Also cardioplmonary issues. smkes and drink alchol",
            "max_tokens": 50
        })
        assert response.status_code == 200
        json_data = response.json()
        assert "output" in json_data
        assert isinstance(json_data["output"], str)
        assert len(json_data["output"]) > 0
