# llm_service/main.py

from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks, Request as FastAPIRequest
from fastapi.middleware.cors import CORSMiddleware
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from shared.security import setup_security, verify_token, limiter
from fastapi.responses import StreamingResponse # For potential future streaming
import httpx
import os
import json
import logging
import time # Import time for performance logging
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional, Union
from enum import Enum
import asyncio

# Load environment variables first
from dotenv import load_dotenv

# Try to load from root .env first, then fallback to local if exists
project_root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
root_env_path = os.path.join(project_root_dir, '.env')
local_env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env')

if os.path.exists(root_env_path):
    load_dotenv(root_env_path, override=True)
if os.path.exists(local_env_path):
    load_dotenv(local_env_path, override=True) # Local can override root if specific settings are needed here

# Load environment variables
RUNPOD_API_BASE = os.getenv("RUNPOD_API_BASE", "https://api.runpod.ai/v2")
RUNPOD_ENDPOINT_ID = os.getenv("RUNPOD_ENDPOINT_ID")
RUNPOD_API_KEY = os.getenv("RUNPOD_API_KEY")
LLM_TIMEOUT_SECONDS = int(os.getenv("LLM_TIMEOUT_SECONDS", "120"))  # Increased default timeout for LLM calls
AI_PROCESSING_SERVICE_URL = os.getenv("AI_PROCESSING_SERVICE_URL", "http://localhost:8002")
KNOWLEDGE_SERVICE_URL = os.getenv("KNOWLEDGE_SERVICE_URL", "http://localhost:8004/api/v1")
TEMPLATE_SERVICE_URL = os.getenv("TEMPLATE_SERVICE_URL", "http://localhost:8003")

# LLM logging settings
VERBOSE_LLM_LOGGING = os.getenv("VERBOSE_LLM_LOGGING", "false").lower() == "true"
LLM_LOG_FULL_PROMPTS = os.getenv("LLM_LOG_FULL_PROMPTS", "false").lower() == "true"
LLM_LOG_DIRECTORY = os.getenv("LLM_LOG_DIRECTORY", "logs")

# Configure logging
logging.basicConfig(
    level=logging.INFO, # Set to DEBUG for more verbose output including prompts and raw responses
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)
logger = logging.getLogger("llm_service")

# Set up a dedicated file logger for LLM responses
llm_response_logger = logging.getLogger("llm_response_logger")
llm_response_logger.setLevel(logging.DEBUG)  # Always log LLM responses at DEBUG level

# Create logs directory if it doesn't exist
os.makedirs(LLM_LOG_DIRECTORY, exist_ok=True)

# Create a file handler for the LLM response logger
llm_response_file_handler = logging.FileHandler(os.path.join(LLM_LOG_DIRECTORY, "llm_responses.log"))
llm_response_file_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
llm_response_logger.addHandler(llm_response_file_handler)
llm_response_logger.propagate = False  # Don't propagate to parent loggers

# Add console handler for LLM responses if verbose logging is enabled
if VERBOSE_LLM_LOGGING:
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(logging.Formatter('\033[92m%(asctime)s - LLM RESPONSE - %(message)s\033[0m'))
    llm_response_logger.addHandler(console_handler)
    logger.info(f"Verbose LLM logging enabled - responses will be logged to console and {os.path.join(LLM_LOG_DIRECTORY, 'llm_responses.log')}")
else:
    logger.info(f"Standard LLM logging - responses will be logged to {os.path.join(LLM_LOG_DIRECTORY, 'llm_responses.log')}")

# Pydantic models
class TaskType(str, Enum):
    TEMPLATE_CONVERSION = "template_conversion"
    CLINICAL_SUMMARY = "clinical_summary"
    STRUCTURED_DATA_EXTRACTION = "structured_data_extraction"
    QUESTION_ANSWERING = "question_answering"
    CUSTOM_PROMPT = "custom_prompt"

class LLMRequest(BaseModel):
    text: str
    task_type: TaskType
    template_id: Optional[str] = None
    include_medcat_entities: bool = Field(True, description="If true, this service will call AI Processing service to get entities.")
    temperature: float = Field(0.2, ge=0.0, le=1.0)
    max_tokens: Optional[int] = Field(None, ge=1)
    custom_prompt: Optional[str] = None
    additional_context: Optional[Dict[str, Any]] = Field(None, description="Additional context, e.g., pre-extracted entities.")

class LLMResponse(BaseModel):
    generated_text: str
    entities_used_in_prompt: Optional[List[Dict[str, Any]]] = None
    source_template_id: Optional[str] = None
    fhir_response: Optional[Dict[str, Any]] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

class HealthResponse(BaseModel):
    status: str
    llm_provider_status: str
    details: Dict[str, Any] = Field(default_factory=dict)

# Create FastAPI app
app = FastAPI(
    title="NexusCare LLM Orchestration Service",
    description="Orchestrates calls to an external LLM (e.g., Phi-3 on RunPod) and integrates with other NexusCare AI services.",
    version="0.2.1", # Incremented version
)

# Apply comprehensive security middleware
setup_security(
    app,
    allowed_origins=["http://localhost:3000", "http://localhost:8080"],
    enable_auth=True,
    rate_limit="50/minute",  # Lower rate limit for LLM service
    trusted_hosts=["localhost", "slm-service", "*.nexuscare.ai"]
)

async def get_httpx_client():
    # Timeout for calls *from* this service to *other internal* services
    internal_service_timeout = httpx.Timeout(20.0, connect=5.0) # Slightly increased for internal calls
    async with httpx.AsyncClient(timeout=internal_service_timeout) as client:
        yield client

# --- Helper Functions ---
async def extract_entities_via_ai_processing(text: str, client: httpx.AsyncClient) -> List[Dict[str, Any]]:
    if not AI_PROCESSING_SERVICE_URL:
        logger.warning("AI_PROCESSING_SERVICE_URL not set. Cannot extract MedCAT entities.")
        return []
    try:
        endpoint_to_call = f"{AI_PROCESSING_SERVICE_URL}/debug_entities"
        logger.info(f"Calling AI Processing Service for entity extraction: {endpoint_to_call}")
        response = await client.post(endpoint_to_call, json={"text": text})
        response.raise_for_status()
        data = response.json()
        entities = data.get("pipeline_entities", []) # Assuming this is the desired list
        logger.info(f"Received {len(entities)} entities from AI Processing Service.")
        return entities
    except httpx.HTTPError as e:
        logger.error(f"HTTPError extracting entities: {e.response.status_code if e.response else 'N/A'} - {str(e)}")
        return []
    except Exception as e:
        logger.error(f"Unexpected error extracting entities: {str(e)}", exc_info=True)
        return []

async def enrich_entities_with_knowledge_service(entities: List[Dict[str, Any]], client: httpx.AsyncClient) -> List[Dict[str, Any]]:
    if not KNOWLEDGE_SERVICE_URL:
        logger.warning("KNOWLEDGE_SERVICE_URL not set. Skipping entity enrichment.")
        return entities
    
    enriched_entities_copy = []
    for entity_dict in entities:
        current_entity = entity_dict.copy()
        cui = current_entity.get("cui") or current_entity.get("primary_cui")

        if cui and isinstance(cui, str) and cui.startswith("C"):
            try:
                logger.debug(f"Enriching CUI: {cui} via Knowledge Service.")
                response = await client.get(f"{KNOWLEDGE_SERVICE_URL}/concepts/{cui}/codes")
                if response.status_code == 200:
                    current_entity["codes_from_ks"] = response.json()
                    logger.debug(f"Enriched CUI {cui} with {len(current_entity['codes_from_ks'])} codes.")
                else:
                    logger.warning(f"Knowledge Service returned {response.status_code} for CUI {cui}")
            except Exception as e_enrich: # Catch generic exception for this part
                logger.error(f"Error enriching entity CUI {cui}: {str(e_enrich)}")
        enriched_entities_copy.append(current_entity)
    return enriched_entities_copy

async def generate_llm_prompt_for_task(
    task_type: TaskType,
    text: str,
    entities: Optional[List[Dict[str, Any]]],
    custom_prompt_from_request: Optional[str] = None, # Renamed for clarity
    template_description: Optional[str] = None
) -> tuple[str, Optional[str]]: # Returns: (user_facing_prompt, system_prompt_override)
    """Generate an appropriate user-facing prompt and an optional system prompt override for the LLM."""

    system_prompt_override = None # Default: no override, use standard system prompt
    user_facing_prompt_content = ""

    entity_context_str = ""
    if entities:
        entity_parts = []
        for i, entity in enumerate(entities[:20]):
            name = entity.get("text", "Unknown entity")
            category = entity.get("backend_category", entity.get("label", "Unknown"))
            cui = entity.get("cui", entity.get("primary_cui"))
            modifiers_list = [mod_key for mod_key, mod_val in [ # Changed 'mod' to 'mod_key'
                                ("negated", entity.get("negated")),
                                ("historical", entity.get("historical")),
                                ("hypothetical", entity.get("hypothetical")),
                                ("family context", entity.get("family")) # Consistent naming for the modifier text
                             ] if mod_val]
            modifier_str = f" (Context: {', '.join(modifiers_list)})" if modifiers_list else ""
            cui_str = f" (CUI: {cui})" if cui else ""
            entity_parts.append(f"- {name}{cui_str} (Category: {category}){modifier_str}")
        if entity_parts:
            entity_context_str = "\n\nPre-detected Medical Entities (for context and verification):\n" + "\n".join(entity_parts)
            if len(entities) > 20:
                entity_context_str += f"\n... and {len(entities) - 20} more entities."

    # Handle task-specific instructions
    if task_type == TaskType.CUSTOM_PROMPT:
        if custom_prompt_from_request:
            logger.info("Using provided custom_prompt directly for CUSTOM_PROMPT task.")
            # If the custom prompt is for JSON, we set a specific system prompt override
            if "JSON" in custom_prompt_from_request.upper(): # Simple check
                system_prompt_override = """You are an AI assistant. When the user requests output in JSON format, you MUST:
1.  Return ONLY valid JSON.
2.  Follow the exact schema or list format specified in the user's prompt.
3.  Do not include any explanatory text, apologies, or any characters outside the JSON structure.
4.  If no data matches the criteria for the JSON output, return an empty JSON list `[]` or an empty JSON object `{}` as appropriate to the requested schema.
Your response MUST be parseable by `json.loads()` without any pre-processing."""
                logger.info("JSON output requested in custom_prompt; applying JSON-specific system prompt override.")
            user_facing_prompt_content = custom_prompt_from_request # The custom prompt IS the user prompt
        else:
            user_facing_prompt_content = f"Process the following clinical text:{entity_context_str}\n\nClinical Text:\n\"\"\"\n{text}\n\"\"\""
    else:
        # Build standard prompts for other task types
        base_instruction = ""
        if task_type == TaskType.TEMPLATE_CONVERSION:
            format_instr = template_description or "a standard SOAP note (Subjective, Objective, Assessment, Plan)"
            base_instruction = (
                f"Your task is to convert the following clinical text into a structured format: '{format_instr}'. "
                f"Organize all relevant information from the clinical text into the appropriate sections of this format. "
                f"Be comprehensive and accurate, using only information present in the text."
            )
        elif task_type == TaskType.CLINICAL_SUMMARY:
            base_instruction = (
                "Generate a concise yet comprehensive clinical summary of the following medical text. "
                "Highlight key diagnoses, findings, treatments, and outcomes. "
                "Ensure the summary is neutral, factual, and strictly derived from the provided text."
            )
        elif task_type == TaskType.STRUCTURED_DATA_EXTRACTION:
            base_instruction = (
                "From the clinical text provided below, extract key clinical information. "
                "Focus on identifying and structuring details related to:\n"
                "- Chief Complaint(s)\n- History of Present Illness\n- Active Medical Problems/Diagnoses (with status: active, resolved, historical)\n"
                "- Pertinent Negated Symptoms/Conditions\n- Medications (name, dosage, route, frequency, status: active, discontinued)\n"
                "- Allergies and Adverse Reactions\n- Procedures Performed or Planned\n- Significant Lab Results (name, value, units, interpretation if provided)\n"
                "- Significant Vital Signs\n- Social History (e.g., smoking, alcohol use)\n- Family History\n- Assessment / Impression\n- Plan of Care (including treatments, follow-ups, referrals, patient education)\n\n"
                "For each item, provide the information and its context (e.g., negated, historical, family member, certainty level if specified).\n"
                "Utilize the pre-detected medical entities list as a guide and for verification.\n"
                "Present the output in a clear, structured format (e.g., key-value pairs under relevant headings, or an itemized list)."
            )
        elif task_type == TaskType.QUESTION_ANSWERING:
             # The actual question is expected to be part of custom_prompt_from_request when task_type is QUESTION_ANSWERING
            question_instr = custom_prompt_from_request or "Provide a clinical analysis based on the text."
            base_instruction = f"Using only the information in the following clinical text, {question_instr}"
        
        user_facing_prompt_content = f"{base_instruction}\n\nClinical Text:\n\"\"\"\n{text}\n\"\"\"{entity_context_str}"

    logger.debug(f"Generated user_facing_prompt (first 300 chars): {user_facing_prompt_content[:300]}")
    if system_prompt_override:
        logger.debug(f"Using system_prompt_override (first 100 chars): {system_prompt_override[:100]}")

    return user_facing_prompt_content, system_prompt_override


async def call_phi3_llm_with_timing(
    user_prompt: str,
    temperature: float = 0.2,
    max_tokens: Optional[int] = None,
    client: Optional[httpx.AsyncClient] = None, # Client for calling RunPod
    system_prompt_override: Optional[str] = None
) -> str:
    """Call the Phi-3 LLM via RunPod API (OpenAI compatible path) with timing and error handling."""
    
    call_start_time = time.perf_counter()

    if not RUNPOD_ENDPOINT_ID or RUNPOD_ENDPOINT_ID == "your_endpoint_id" or \
       not RUNPOD_API_KEY or RUNPOD_API_KEY == "your_api_key":
        logger.error("RunPod credentials or endpoint ID not configured properly.")
        raise HTTPException(status_code=503, detail="LLM provider service misconfigured.")

    # Use passed client or create a new one for this specific call to RunPod
    # This ensures the longer LLM_TIMEOUT_SECONDS is used for the external call
    if client is None:
        async with httpx.AsyncClient(timeout=LLM_TIMEOUT_SECONDS) as new_client:
            return await call_phi3_llm_with_timing(user_prompt, temperature, max_tokens, new_client, system_prompt_override)
    
    # Determine system prompt
    final_system_prompt = system_prompt_override or """You are an AI assistant specializing in clinical data extraction and structuring for healthcare applications. Your goal is to process clinical narratives and transform them into formats useful for tasks like coding review, care coordination, and decision support.
                                    Core Instructions:
                                    -   **Strictly Adhere to Source Text:** Extract information *only* from the provided clinical note. Do not introduce external knowledge or assumptions.
                                    -   **Identify Key Clinical Data:** Focus on diagnoses, symptoms, medications, procedures, lab results, patient history, and social determinants.
                                    -   **Recognize Context:** Pay close attention to contextual cues such as negation, certainty, temporality (current, historical), and experiencer (patient, family member).
                                    -   **Follow Formatting Instructions:** When a specific output format or template is requested (e.g., SOAP, discharge summary sections, key-value pairs), conform to it meticulously.
                                    -   **Highlight Actionable Insights (if requested):** If the task involves identifying items for review (e.g., potential coding gaps, follow-up actions), make these clear.
                                    Indicate missing information as 'Not provided' or similar, as appropriate for the output format.
                                    """
    
    request_payload = {
        "model": "microsoft/Phi-3-mini-128k-instruct", # Often optional if endpoint is tied to a model
        "messages": [
            {"role": "system", "content": final_system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": temperature,
        "stream": False
    }
    if max_tokens:
        request_payload["max_tokens"] = max_tokens

    api_url = f"{RUNPOD_API_BASE}/{RUNPOD_ENDPOINT_ID}/openai/v1/chat/completions"

    logger.info(f"Sending request to RunPod LLM: {api_url}. Temp: {temperature}, MaxTokens: {max_tokens}.")
    logger.debug(f"User Prompt to RunPod LLM (first 250 chars): {(user_prompt[:250] + '...') if len(user_prompt) > 250 else user_prompt}")
    if system_prompt_override:
        logger.debug(f"System Prompt Override to RunPod LLM (first 100 chars): {(system_prompt_override[:100] + '...') if len(system_prompt_override) > 100 else system_prompt_override}")
    else:
        logger.debug(f"Default System Prompt to RunPod LLM (first 100 chars): {(final_system_prompt[:100] + '...') if len(final_system_prompt) > 100 else final_system_prompt}")


    response_text_for_log = "" # Initialize for logging in case of early error
    try:
        network_call_start_time = time.perf_counter()
        response = await client.post(api_url, headers={"Authorization": f"Bearer {RUNPOD_API_KEY}"}, json=request_payload, timeout=LLM_TIMEOUT_SECONDS)
        time_to_headers = time.perf_counter() - network_call_start_time
        
        response_text_for_log = response.text # Read text once for logging and parsing
        time_to_full_response = time.perf_counter() - network_call_start_time
        
        logger.info(f"RunPod LLM HTTP Status: {response.status_code}. Time to headers: {time_to_headers:.3f}s. Time to full body: {time_to_full_response:.3f}s.")
        logger.debug(f"Raw RunPod LLM Response Text (first 1000 chars): {response_text_for_log[:1000]}")

        response.raise_for_status() # Raises an exception for 4xx/5xx client/server errors
        
        response_data = json.loads(response_text_for_log)

        # Log the complete raw JSON response for debugging
        logger.debug(f"Complete raw JSON response from LLM: {json.dumps(response_data, indent=2)}")
        
        # Log to dedicated response logger with request/response pair
        llm_request_id = f"req_{int(time.time())}_{hash(user_prompt)%10000:04d}"
        
        # Truncate or include full prompts based on settings
        system_prompt_log = final_system_prompt if LLM_LOG_FULL_PROMPTS else (final_system_prompt[:500] + "..." if len(final_system_prompt) > 500 else final_system_prompt)
        user_prompt_log = user_prompt if LLM_LOG_FULL_PROMPTS else (user_prompt[:500] + "..." if len(user_prompt) > 500 else user_prompt)
        
        llm_response_logger.debug(
            f"REQUEST_ID: {llm_request_id}\n"
            f"REQUEST_TIMESTAMP: {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"REQUEST_TEMP: {temperature}\n" 
            f"REQUEST_MAX_TOKENS: {max_tokens}\n"
            f"REQUEST_SYSTEM: {system_prompt_log}\n"
            f"REQUEST_USER: {user_prompt_log}\n"
            f"RESPONSE_STATUS: {response.status_code}\n"
            f"RESPONSE_TIME: {time_to_full_response:.3f}s\n"
            f"RESPONSE_RAW: {json.dumps(response_data, indent=2)}\n"
            f"RESPONSE_TEXT: {response_data['choices'][0]['message']['content'] if 'choices' in response_data and response_data['choices'] else 'NO_RESPONSE'}\n"
            f"----------END {llm_request_id}----------"
        )

        if "choices" in response_data and len(response_data["choices"]) > 0 and response_data["choices"][0].get("message"):
            generated_text = response_data["choices"][0]["message"]["content"].strip()
            total_processing_duration = time.perf_counter() - call_start_time
            logger.info(f"Successfully extracted text from LLM. Output length: {len(generated_text)}. Total call_phi3_llm_with_timing duration: {total_processing_duration:.3f}s.")
            logger.debug(f"Generated text from LLM: {generated_text}")
            return generated_text
        else:
            logger.error(f"Unexpected LLM response format (missing choices/message): {response_data}")
            raise HTTPException(status_code=500, detail="Unexpected response structure from LLM provider after successful HTTP call.")
    
    except httpx.TimeoutException as e:
        total_time = time.perf_counter() - call_start_time
        logger.error(f"Timeout calling RunPod LLM after {total_time:.3f}s (configured timeout: {LLM_TIMEOUT_SECONDS}s): {str(e)}", exc_info=True)
        raise HTTPException(status_code=504, detail=f"LLM provider request timed out after {total_time:.3f}s.")
    except httpx.HTTPStatusError as e:
        total_time = time.perf_counter() - call_start_time
        logger.error(f"HTTPStatusError from RunPod LLM (status {e.response.status_code}) after {total_time:.3f}s. Response: {e.response.text[:500]}", exc_info=True)
        raise HTTPException(status_code=502, detail=f"LLM provider error {e.response.status_code}: {e.response.text[:200]}.") # Changed 503 to 502 for bad gateway
    except httpx.RequestError as e: # Covers other network issues like ConnectionError
        total_time = time.perf_counter() - call_start_time
        logger.error(f"RequestError calling RunPod LLM after {total_time:.3f}s: {str(e)}", exc_info=True)
        raise HTTPException(status_code=503, detail=f"Network error communicating with LLM provider: {str(e)}.")
    except json.JSONDecodeError as e:
        total_time = time.perf_counter() - call_start_time
        logger.error(f"JSONDecodeError parsing RunPod LLM response after {total_time:.3f}s: {str(e)}. Response text: {response_text_for_log[:1000]}", exc_info=True)
        raise HTTPException(status_code=502, detail=f"Invalid JSON response from LLM provider: {str(e)}.")
    except Exception as e:
        total_time = time.perf_counter() - call_start_time
        logger.error(f"Unexpected error during RunPod LLM call after {total_time:.3f}s: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Unexpected internal error with LLM call: {str(e)}.")


async def get_template_description_from_service(template_id: str, client: httpx.AsyncClient) -> Optional[str]:
    if not TEMPLATE_SERVICE_URL:
        logger.warning("TEMPLATE_SERVICE_URL not set. Cannot fetch template description.")
        return None
    try:
        response = await client.get(f"{TEMPLATE_SERVICE_URL}/api/v1/templates/{template_id}/description")
        response.raise_for_status()
        data = response.json()
        description = data.get("description")
        if description:
            logger.info(f"Fetched description for template_id '{template_id}'.")
            return description
        logger.warning(f"No 'description' field in response for template_id '{template_id}'.")
        return None
    except Exception as e:
        logger.error(f"Error fetching template description for {template_id}: {str(e)}", exc_info=True)
        return None

async def format_fhir_response_via_template_service(template_id: str, entities: List[Dict[str, Any]], generated_text: str, client: httpx.AsyncClient) -> Optional[Dict[str, Any]]:
    if not TEMPLATE_SERVICE_URL:
        logger.warning("TEMPLATE_SERVICE_URL not set. Cannot format FHIR response.")
        return None
    try:
        payload = {
            "extracted_entities": entities or [], # Ensure it's a list, even if empty
            "llm_generated_text": generated_text
        }
        logger.debug(f"Sending to Template Service for FHIR generation (template: {template_id}): {json.dumps(payload, indent=2)[:500]}...") # Log part of payload
        response = await client.post(f"{TEMPLATE_SERVICE_URL}/api/v1/templates/{template_id}/generate-response", json=payload)
        response.raise_for_status()
        logger.info(f"Successfully generated FHIR response via Template Service for template_id '{template_id}'.")
        return response.json()
    except Exception as e:
        logger.error(f"Error formatting FHIR response via Template Service for {template_id}: {str(e)}", exc_info=True)
        return None

# --- Routes ---
@app.on_event("startup")
async def startup_event():
    # Critical configuration check
    if not RUNPOD_ENDPOINT_ID or RUNPOD_ENDPOINT_ID == "your_endpoint_id":
        logger.critical("FATAL: RUNPOD_ENDPOINT_ID is not set or is using a placeholder. LLM service cannot function.")
    if not RUNPOD_API_KEY or RUNPOD_API_KEY == "your_api_key":
        logger.critical("FATAL: RUNPOD_API_KEY is not set or is using a placeholder. LLM service cannot function.")
    logger.info("LLM Service startup sequence initiated and complete.")

@app.get("/health", response_model=HealthResponse)
async def health_check(client: httpx.AsyncClient = Depends(get_httpx_client)):
    """Check the health of the LLM service and its dependencies."""
    details = {"dependent_services": {}}
    llm_provider_status_val = "unknown" # Renamed variable to avoid conflict

    if not RUNPOD_ENDPOINT_ID or RUNPOD_ENDPOINT_ID == "your_endpoint_id" or \
       not RUNPOD_API_KEY or RUNPOD_API_KEY == "your_api_key":
        llm_provider_status_val = "misconfigured"
        details["llm_provider_error"] = "RUNPOD_ENDPOINT_ID or RUNPOD_API_KEY not configured properly."
    else:
        try:
            test_prompt_start_time = time.perf_counter()
            # Pass the client from Depends to call_phi3_llm_with_timing
            test_response = await call_phi3_llm_with_timing(
                prompt="Respond with 'OK' if you are functioning.", 
                client=client # Pass the client from Depends
            )
            test_prompt_duration = time.perf_counter() - test_prompt_start_time
            
            if test_response and "OK" in test_response:
                llm_provider_status_val = "available"
                details["llm_provider_response_time_seconds"] = round(test_prompt_duration, 3)
            else:
                llm_provider_status_val = "degraded"
                details["llm_provider_response"] = test_response[:200] if test_response else "No response content"
        except HTTPException as e:
            llm_provider_status_val = "unavailable"
            details["llm_provider_error"] = f"HTTPException: {e.status_code} - {e.detail}"
        except Exception as e:
            llm_provider_status_val = "error"
            details["llm_provider_error"] = str(e)
    
    # Check dependent services
    for service_name, service_url_env_var, health_path in [
        ("ai_processing_service", AI_PROCESSING_SERVICE_URL, "/health"),
        ("knowledge_service", KNOWLEDGE_SERVICE_URL, "/health"), # Assuming /health for KS
        ("template_service", TEMPLATE_SERVICE_URL, "/api/v1/health") # Specific path for TemplateSvc
    ]:
        if service_url_env_var:
            try:
                response = await client.get(f"{service_url_env_var}{health_path}")
                details["dependent_services"][service_name] = "available" if response.status_code == 200 else f"unavailable ({response.status_code})"
            except Exception: details["dependent_services"][service_name] = "unreachable"
        else:
            details["dependent_services"][service_name] = "not_configured"
            
    overall_status = "healthy"
    if llm_provider_status_val not in ["available", "degraded"]:
        overall_status = "unhealthy"
    elif llm_provider_status_val == "degraded":
        overall_status = "degraded"
    
    return HealthResponse(status=overall_status, llm_provider_status=llm_provider_status_val, details=details)


@app.post("/process", response_model=LLMResponse)
async def process_text_with_llm(
    fastapi_request: FastAPIRequest,
    request: LLMRequest,
    background_tasks: BackgroundTasks,
    client: httpx.AsyncClient = Depends(get_httpx_client)
):
    request_process_start_time = time.perf_counter()
    request_id = fastapi_request.headers.get("X-Request-ID", "N/A")
    client_host = fastapi_request.client.host if fastapi_request.client else "N/A"
    logger.info(f"LLM Service: Received /process RID='{request_id}' from {client_host} for task='{request.task_type}'. Input len: {len(request.text)}.")

    if not RUNPOD_ENDPOINT_ID or RUNPOD_ENDPOINT_ID == "your_endpoint_id" or \
       not RUNPOD_API_KEY or RUNPOD_API_KEY == "your_api_key":
        logger.error("LLM provider (RunPod) is not configured.")
        raise HTTPException(status_code=503, detail="LLM provider service is not configured.")

    entities_for_prompt: Optional[List[Dict[str, Any]]] = None

    if request.additional_context and "pre_extracted_entities" in request.additional_context:
        logger.info("Using pre-extracted entities from request.additional_context.")
        entities_for_prompt = request.additional_context["pre_extracted_entities"]
    elif request.include_medcat_entities:
        logger.info("Flag 'include_medcat_entities' is true. Fetching entities from AI Processing Service.")
        raw_entities = await extract_entities_via_ai_processing(request.text, client)
        if raw_entities:
            entities_for_prompt = await enrich_entities_with_knowledge_service(raw_entities, client)
        else: entities_for_prompt = []
    else:
        logger.info("No MedCAT entities requested or provided for LLM prompt context.")

    template_desc_for_prompt = None
    if request.task_type == TaskType.TEMPLATE_CONVERSION and request.template_id:
        template_desc_for_prompt = await get_template_description_from_service(request.template_id, client)

    user_prompt, system_prompt_override = await generate_llm_prompt_for_task(
        request.task_type,
        request.text,
        entities_for_prompt,
        request.custom_prompt,
        template_description=template_desc_for_prompt
    )
    
    generated_text = await call_phi3_llm_with_timing(
        user_prompt, # Renamed from prompt to user_prompt
        temperature=request.temperature,
        max_tokens=request.max_tokens,
        client=client, # Pass client from Depends, call_phi3_llm_with_timing will make its own for RunPod if this is None
        system_prompt_override=system_prompt_override
    )
    
    fhir_response_content = None
    if request.template_id and generated_text:
        fhir_response_content = await format_fhir_response_via_template_service(
            request.template_id,
            entities_for_prompt if entities_for_prompt else [],
            generated_text,
            client
        )
    
    final_processing_time = time.perf_counter() - request_process_start_time
    response_payload = LLMResponse(
        generated_text=generated_text if generated_text else "Error: LLM did not produce output or call failed.",
        entities_used_in_prompt=entities_for_prompt,
        source_template_id=request.template_id,
        fhir_response=fhir_response_content,
        metadata={
            "task_type": request.task_type.value,
            "input_text_length": len(request.text),
            "prompt_length": len(user_prompt),
            "output_text_length": len(generated_text) if generated_text else 0,
            "entity_count_in_prompt": len(entities_for_prompt) if entities_for_prompt else 0,
            "llm_temperature": request.temperature,
            "llm_max_tokens": request.max_tokens,
            "total_processing_time_seconds": round(final_processing_time, 3)
        }
    )
    
    background_tasks.add_task(
        logger.info,
        (f"LLM Service: Completed RID='{request_id}', task='{request.task_type.value}'. "
         f"Input len: {len(request.text)}, Output len: {len(generated_text) if generated_text else 0}. "
         f"Duration: {final_processing_time:.3f}s")
    )
    
    return response_payload

@app.post("/stream-process")
async def stream_process_endpoint(request: LLMRequest):
    logger.warning("/stream-process is a placeholder and not fully implemented for streaming.")
    raise HTTPException(status_code=501, detail="Streaming is not yet implemented. Please use the /process endpoint.")

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("LLM_SERVICE_PORT", 8007))
    reload_mode = os.getenv("UVICORN_RELOAD", "false").lower() == "true"
    log_level_str = os.getenv("LOG_LEVEL", "INFO").upper()
    
    # Ensure log level is valid
    if log_level_str not in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
        log_level_str = "INFO"
    
    # Reconfigure root logger if needed, or specific loggers
    logging.getLogger().setLevel(log_level_str) # Set root logger level
    logger.setLevel(log_level_str) # Set llm_service logger level
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING) # Quieten uvicorn access logs unless error
    logging.getLogger("httpx").setLevel(logging.WARNING) # Quieten httpx INFO logs unless error/warning

    logger.info(f"Log level set to: {log_level_str}")
    logger.info(f"Starting LLM Service on host 0.0.0.0 port {port} (Reload: {reload_mode})")

    if RUNPOD_ENDPOINT_ID == "your_endpoint_id" or not RUNPOD_ENDPOINT_ID:
        logger.critical("CRITICAL: RUNPOD_ENDPOINT_ID is not set or is using a placeholder value.")
    if RUNPOD_API_KEY == "your_api_key" or not RUNPOD_API_KEY:
        logger.critical("CRITICAL: RUNPOD_API_KEY is not set or is using a placeholder value.")
    if not RUNPOD_ENDPOINT_ID or not RUNPOD_API_KEY or \
       RUNPOD_ENDPOINT_ID == "your_endpoint_id" or RUNPOD_API_KEY == "your_api_key":
        logger.error("LLM service WILL NOT be able to contact the RunPod LLM due to missing/placeholder credentials.")
        # import sys
        # sys.exit("Exiting due to missing RunPod credentials/endpoint ID.") # Optional: force exit

    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=reload_mode, log_level=log_level_str.lower())