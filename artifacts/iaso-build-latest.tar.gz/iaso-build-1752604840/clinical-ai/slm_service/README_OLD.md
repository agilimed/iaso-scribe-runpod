# NexusCare LLM Service

## Overview

The NexusCare LLM Service is a specialized component of the NexusCare AI backend that integrates the Phi-3-mini-128k-instruct large language model with MedCAT's clinical entity recognition capabilities. This service enhances the NLP pipeline by combining precise clinical entity extraction with advanced text generation and transformation.

## Key Features

- **Template Conversion**: Transforms unstructured clinical text into standardized formats (SOAP notes, etc.)
- **Clinical Summarization**: Generates concise summaries of medical documentation
- **Structured Data Extraction**: Extracts structured clinical information from free text
- **FHIR Integration**: Populates FHIR QuestionnaireResponse templates with extracted information
- **Entity-Aware Processing**: Leverages MedCAT-extracted entities to enhance LLM prompts
- **Contextual Analysis**: Preserves negation, historical status, and other important context modifiers

## Architecture

The LLM Service works alongside other NexusCare components:

```
┌─────────────────┐         ┌─────────────────┐         ┌─────────────────┐
│                 │         │                 │         │                 │
│  AI Processing  │────────▶│  LLM Service    │◀────────│  Knowledge      │
│  Service        │         │  (Phi-3-mini)   │         │  Service        │
│                 │         │                 │         │                 │
└─────────────────┘         └─────────────────┘         └─────────────────┘
        ▲                            │                          ▲
        │                            ▼                          │
        │                   ┌─────────────────┐                 │
        │                   │                 │                 │
        └───────────────────│  Template       │─────────────────┘
                            │  Service        │
                            │                 │
                            └─────────────────┘
```

## Prerequisites

- Docker and Docker Compose
- Python 3.10+
- Access to RunPod API with Phi-3-mini-128k-instruct deployment
- MedCAT AI Processing Service
- Knowledge Service for terminology enrichment
- Template Service for FHIR integration

## Configuration

### Environment Variables

The service is configured using the following environment variables:

| Variable | Description | Default |
|----------|-------------|---------|
| `RUNPOD_API_BASE` | Base URL for RunPod API | https://api.runpod.ai/v2 |
| `RUNPOD_ENDPOINT_ID` | Your RunPod endpoint ID | - |
| `RUNPOD_API_KEY` | Your RunPod API key | - |
| `LLM_TIMEOUT` | Timeout for LLM requests (seconds) | 30 |
| `AI_PROCESSING_SERVICE_URL` | URL for the AI Processing Service | http://ai-processing-service:8002 |
| `KNOWLEDGE_SERVICE_URL` | URL for the Knowledge Service | http://knowledge-service:8004/api/v1 |
| `TEMPLATE_SERVICE_URL` | URL for the Template Service | http://template-service:8003 |
| `LOG_LEVEL` | Logging level | INFO |
| `LLM_SERVICE_PORT` | Port for the LLM Service | 8007 |

## Setup and Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/nexus-care-ai-backend.git
   cd nexus-care-ai-backend
   ```

2. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. **Build and start the service**
   ```bash
   docker-compose build llm-service
   docker-compose up -d llm-service
   ```

4. **Verify the service is running**
   ```bash
   curl http://localhost:8007/health
   ```

## API Endpoints

### Health Check
- `GET /health`
  - Checks service health and component status
  - Returns detailed status of LLM, AI Processing, Knowledge, and Template services

### Text Processing
- `POST /process`
  - Main endpoint for processing clinical text
  - Accepts text, task type, and optional parameters
  - Returns generated text, detected entities, and optionally FHIR responses

#### Request Format
```json
{
  "text": "Patient is a 64-year-old female with hypertension and type 2 diabetes, reports intermittent chest pain.",
  "task_type": "template_conversion",
  "include_medcat_entities": true,
  "temperature": 0.3,
  "template_id": "soap-note-template",
  "max_tokens": 1000,
  "custom_prompt": "Convert to SOAP format focusing on cardiovascular findings"
}
```

#### Supported Task Types
- `template_conversion`: Transforms text into structured formats
- `clinical_summary`: Generates concise clinical summaries
- `structured_data_extraction`: Extracts structured information
- `question_answering`: Answers questions based on the provided text
- `custom_prompt`: Processes text using a custom prompt

#### Response Format
```json
{
  "generated_text": "Subjective:\nPatient is a 64-year-old female reporting intermittent chest pain...",
  "detected_entities": [
    {
      "id": 1,
      "cui": "C0020538",
      "type": "condition",
      "name": "hypertension",
      "pretty_name": "Hypertension",
      "negated": false,
      "historical": false,
      "codes": {
        "SNOMEDCT_US": "38341003"
      }
    }
  ],
  "source_template_id": "soap-note-template",
  "fhir_response": { ... },
  "metadata": {
    "task_type": "template_conversion",
    "input_text_length": 95,
    "output_text_length": 452,
    "entity_count": 3
  }
}
```

## Usage Examples

### Converting Clinical Notes to SOAP Format

```bash
curl -X POST http://localhost:8007/process \
  -H "Content-Type: application/json" \
  -d '{
    "text": "The patient is a 68-year-old male presenting for routine follow-up of chronic medical conditions including hypertension, type 2 diabetes, and hyperlipidemia. Blood sugars are stable at 110-140 mg/dL, A1c 6.8%. BP average 135/85. Denies chest pain or SOB. New complaint: 2-week dull aching left shoulder pain radiating to upper arm, worse with overhead movement.",
    "task_type": "template_conversion",
    "include_medcat_entities": true,
    "temperature": 0.2
  }'
```

### Extracting Structured Data

```bash
curl -X POST http://localhost:8007/process \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Patient is a 64-year-old female with hypertension and type 2 diabetes, reports intermittent chest pain. A1c is 7.2%.",
    "task_type": "structured_data_extraction",
    "include_medcat_entities": true,
    "temperature": 0.1
  }'
```

### Using a Custom Prompt

```bash
curl -X POST http://localhost:8007/process \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Patient is a 64-year-old female with hypertension and type 2 diabetes, reports intermittent chest pain.",
    "task_type": "custom_prompt",
    "custom_prompt": "Generate a list of potential differential diagnoses for the patients chest pain, considering their medical history.",
    "include_medcat_entities": true,
    "temperature": 0.4
  }'
```

## Development

### Running Tests

```bash
cd llm_service
python -m pytest tests/
```

### Local Development Setup

For local development without Docker:

```bash
cd llm_service
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8007
```

## Troubleshooting

### Common Issues

1. **LLM Connection Errors**
   - Check your RunPod API key and endpoint ID
   - Verify the RunPod endpoint is running
   - Increase the LLM_TIMEOUT if necessary

2. **Entity Extraction Issues**
   - Ensure the AI Processing Service is running
   - Check the AI_PROCESSING_SERVICE_URL is correct
   - Verify MedCAT models are properly loaded

3. **Docker Networking Issues**
   - Make sure all services are on the same Docker network
   - Use service names as hostnames within the Docker network
   - For local development, use localhost with appropriate ports

## License

This service is part of the NexusCare AI backend and is subject to the project's license terms.

## Contributing

Please refer to the main project documentation for contribution guidelines.