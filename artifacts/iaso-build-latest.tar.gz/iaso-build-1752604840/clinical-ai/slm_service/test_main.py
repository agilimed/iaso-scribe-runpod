import pytest
from fastapi.testclient import TestClient
from unittest.mock import AsyncMock, patch
import json

from main import app, TaskType, LLMRequest

client = TestClient(app)

# Sample test data
SAMPLE_CLINICAL_TEXT = """
The patient is a 68-year-old male presenting for routine follow-up of chronic medical conditions 
including hypertension, type 2 diabetes, and hyperlipidemia. Blood sugars are stable at 110-140 mg/dL, 
A1c 6.8%. BP average 135/85. Denies chest pain or SOB. New complaint: 2-week dull aching left 
shoulder pain radiating to upper arm, worse with overhead movement. Using ibuprofen with partial relief.
"""

SAMPLE_ENTITIES = [
    {
        "id": 1,
        "cui": "C0020538",
        "type": "condition",
        "name": "hypertension",
        "pretty_name": "Hypertension",
        "negated": False,
        "historical": False,
        "hypothetical": False,
        "family": False,
        "start": 96,
        "end": 108
    },
    {
        "id": 2,
        "cui": "C0011849",
        "type": "condition",
        "name": "diabetes mellitus, type 2",
        "pretty_name": "Type 2 Diabetes Mellitus",
        "negated": False,
        "historical": False,
        "hypothetical": False,
        "family": False,
        "start": 110,
        "end": 127
    }
]

SAMPLE_LLM_RESPONSE = """
Subjective:
Patient Chief Complaint: 2-week dull aching left shoulder pain radiating to upper arm, worsened with overhead movement.

Patient History: Has known history of hypertension, type 2 diabetes, and hyperlipidemia.
"""

@pytest.mark.asyncio
@patch('httpx.AsyncClient.post')
@patch('httpx.AsyncClient.get')
async def test_process_endpoint_with_medcat(mock_get, mock_post):
    # Mock entity extraction response
    entity_extraction_response = AsyncMock()
    entity_extraction_response.status_code = 200
    entity_extraction_response.json.return_value = {"entities": SAMPLE_ENTITIES}
    
    # Mock LLM response
    llm_response = AsyncMock()
    llm_response.status_code = 200
    llm_response.json.return_value = {
        "choices": [
            {"message": {"content": SAMPLE_LLM_RESPONSE}}
        ]
    }
    
    # Mock knowledge service response
    knowledge_response = AsyncMock()
    knowledge_response.status_code = 200
    knowledge_response.json.return_value = {"SNOMEDCT_US": "38341003"}
    
    # Set up mocks based on URL
    def mock_post_side_effect(url, **kwargs):
        if "process" in url:
            return entity_extraction_response
        elif "openai" in url:
            return llm_response
        return AsyncMock(status_code=404)
    
    def mock_get_side_effect(url, **kwargs):
        if "health" in url:
            return AsyncMock(status_code=200)
        elif "codes" in url:
            return knowledge_response
        return AsyncMock(status_code=404)
    
    mock_post.side_effect = mock_post_side_effect
    mock_get.side_effect = mock_get_side_effect
    
    # Test request
    request_data = {
        "text": SAMPLE_CLINICAL_TEXT,
        "task_type": TaskType.TEMPLATE_CONVERSION,
        "include_medcat_entities": True,
        "temperature": 0.2
    }
    
    # Make test request - use async_asgi_client for async endpoints
    with patch('fastapi.BackgroundTasks'):  # Mock background tasks
        response = client.post("/process", json=request_data)
    
    # Assert response
    assert response.status_code == 200
    data = response.json()
    assert "generated_text" in data
    assert data["generated_text"] == SAMPLE_LLM_RESPONSE
    assert "detected_entities" in data
    assert len(data["detected_entities"]) == len(SAMPLE_ENTITIES)

@pytest.mark.asyncio
@patch('httpx.AsyncClient.post')
@patch('httpx.AsyncClient.get')
async def test_health_check(mock_get, mock_post):
    # Mock LLM response for health check
    llm_response = AsyncMock()
    llm_response.status_code = 200
    llm_response.json.return_value = {
        "choices": [
            {"message": {"content": "OK"}}
        ]
    }
    mock_post.return_value = llm_response
    
    # Mock service health checks
    mock_get.return_value = AsyncMock(status_code=200)
    
    # Make test request
    response = client.get("/health")
    
    # Assert response
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["llm_status"] == "available"