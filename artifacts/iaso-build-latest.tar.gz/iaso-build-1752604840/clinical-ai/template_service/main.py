# template_service/main.py
import logging
from typing import List, Optional, Dict, Any

import uvicorn
from fastapi import FastAPI, Depends, HTTPException, status, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi.middleware.cors import CORSMiddleware
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from shared.security import setup_security, verify_token, limiter

# Use absolute imports assuming these files are siblings in the template_service dir
import crud     # Changed from relative
import models   # Changed from relative
import database # Changed from relative

# Basic Logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger(__name__)

# --- FastAPI App ---
if database.DATABASE_URL is None: # Check if DB URL loaded correctly
     logger.critical("Database URL not configured. Exiting Template Service.")
     # In a real app, prevent startup properly, maybe via sys.exit(1)
     # For now, FastAPI might raise error later when get_db fails

app = FastAPI(
    title="NexusCare Template Management Service",
    description="API for managing FHIR Questionnaire templates stored in PostgreSQL.",
    version="0.1.2",
)

# Apply comprehensive security middleware
setup_security(
    app,
    allowed_origins=["http://localhost:3000", "http://localhost:8080"],
    enable_auth=True,
    rate_limit="100/minute",
    trusted_hosts=["localhost", "template-service", "*.nexuscare.ai"]
)

# --- Events (Keep as before) ---
@app.on_event("startup")
async def startup_event():
    logger.info("Template Service starting up...")
    if not database.engine or not database.async_session_local:
         logger.error("Database engine or session not initialized on startup!")

@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Template Service shutting down.")

# --- API Endpoints ---

@app.post(
    "/templates",
    response_model=models.TemplateRead, # Use models. prefix
    status_code=status.HTTP_201_CREATED,
    summary="Create a new Questionnaire Template",
    tags=["Templates"],
)
async def create_new_template(
    template_in: models.TemplateCreate, # Use models. prefix
    db: AsyncSession = Depends(database.get_db) # Use database. prefix
):
    """Creates new FHIR Questionnaire template."""
    logger.info(f"Received request to create template with id: {template_in.resource.get('id')}")
    try:
        created_template_db = await crud.create_template(db=db, template_data=template_in) # Use crud. prefix
    except Exception: raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Error creating template.")

    if created_template_db is None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=f"Template id '{template_in.resource.get('id')}' already exists.")
    return models.TemplateRead(**created_template_db.model_dump()) # Use model_dump() instead of dict()


@app.get(
    "/templates",
    response_model=List[models.TemplateSummary], # Use models. prefix
    summary="List all Questionnaire Templates",
    tags=["Templates"],
)
@limiter.limit("50/minute")
async def list_templates(
    request: Request,
    skip: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=1000),
    encounter_type: Optional[str] = Query(None), tags: Optional[List[str]] = Query(None),
    db: AsyncSession = Depends(database.get_db), # Use database. prefix
    token_payload: dict = Depends(verify_token)
):
    """Retrieves list of templates with filtering."""
    logger.info(f"Request to list templates (skip={skip}, limit={limit}, enc={encounter_type}, tags={tags})")
    try:
        templates_db = await crud.get_all_templates( # Use crud. prefix
            db=db, skip=skip, limit=limit, encounter_type=encounter_type, tags=tags
        )
    except Exception: raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Error retrieving templates.")

    return [models.TemplateSummary( # Use models. prefix
                template_id=t.template_id, version=t.version, status=t.status, title=t.title,
                publisher=t.publisher, updated_at=t.updated_at,
                encounter_type=t.encounter_type, tags=t.tags
            ) for t in templates_db]


@app.get(
    "/templates/{template_fhir_id}",
    response_model=models.TemplateRead, # Use models. prefix
    summary="Get a specific Questionnaire Template",
    tags=["Templates"],
)
async def read_template(
    template_fhir_id: str,
    db: AsyncSession = Depends(database.get_db) # Use database. prefix
):
    """Retrieves full FHIR Questionnaire resource."""
    logger.info(f"Request to get template: {template_fhir_id}")
    try:
        template_db = await crud.get_template_by_fhir_id(db=db, template_fhir_id=template_fhir_id) # Use crud. prefix
    except Exception: raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Error retrieving template.")

    if template_db is None:
        logger.warning(f"Template not found: {template_fhir_id}")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Template id '{template_fhir_id}' not found.")
    return models.TemplateRead(**template_db.model_dump()) # Use model_dump() instead of dict()


@app.patch(
    "/templates/{template_fhir_id}/metadata",
    response_model=models.TemplateRead, # Use models. prefix
    summary="Update Template Metadata",
    tags=["Templates"],
)
async def patch_template_metadata(
    template_fhir_id: str,
    update_data: models.TemplateMetadataUpdate, # Use models. prefix
    db: AsyncSession = Depends(database.get_db) # Use database. prefix
):
    """Updates metadata fields (encounter_type, tags)."""
    logger.info(f"Request to update metadata for {template_fhir_id} with: {update_data.model_dump(exclude_unset=True)}")
    try:
        updated_template_db = await crud.update_template_metadata( # Use crud. prefix
            db=db, template_fhir_id=template_fhir_id, update_data=update_data
        )
    except Exception: raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Error updating template metadata.")

    if updated_template_db is None:
        logger.warning(f"Template not found during metadata update: {template_fhir_id}")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Template id '{template_fhir_id}' not found for update.")
    return models.TemplateRead(**updated_template_db.model_dump()) # Use model_dump() instead of dict()


@app.delete(
    "/templates/{template_fhir_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a Questionnaire Template",
    tags=["Templates"],
)
async def delete_existing_template(
    template_fhir_id: str,
    db: AsyncSession = Depends(database.get_db) # Use database. prefix
):
    """Deletes a Questionnaire template by its ID."""
    logger.info(f"Request to delete template: {template_fhir_id}")
    try:
        deleted = await crud.delete_template(db=db, template_fhir_id=template_fhir_id) # Use crud. prefix
    except Exception: raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Error deleting template.")

    if not deleted:
        logger.warning(f"Template not found for deletion: {template_fhir_id}")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Template id '{template_fhir_id}' not found.")
    return # Return None for 204


# --- Health Check ---
@app.get("/health", summary="Health Check", tags=["Health"])
async def health_check(): return {"status": "ok"}

# --- Main execution block (Comment out if using manager) ---
# if __name__ == "__main__":
#     SERVICE_PORT = int(os.getenv("TEMPLATE_SERVICE_PORT", 8003))
#     logger.info(f"Starting Template Service directly on port {SERVICE_PORT}...")
#     uvicorn.run("main:app", host="0.0.0.0", port=SERVICE_PORT, reload=True)