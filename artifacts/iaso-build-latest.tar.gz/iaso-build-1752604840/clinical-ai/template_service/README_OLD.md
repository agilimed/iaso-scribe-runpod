# NexusCare Template Service

**Version:** 0.1.0

## Overview

The Template Service is a dedicated microservice for managing FHIR Questionnaire templates and their responses. It provides a robust API for creating, retrieving, updating, and managing clinical assessment templates and their associated responses.

## Key Features

1. **Template Management**
   - Create and store FHIR Questionnaire templates
   - Retrieve templates by ID or search criteria
   - Update existing templates
   - Delete templates when needed

2. **Response Management**
   - Store and retrieve questionnaire responses
   - Link responses to specific templates
   - Support for FHIR QuestionnaireResponse format
   - Version control for responses

3. **Search and Filtering**
   - Search templates by various criteria
   - Filter responses by template and date
   - Support for pagination and sorting

## Dependencies

### Core Dependencies
- Python 3.10+
- FastAPI
- Uvicorn
- SQLAlchemy
- PostgreSQL (psycopg2-binary)
- Python-dotenv
- Pydantic
- FHIR Resources (fhir.resources)

## Configuration

The service requires the following environment variables:

```env
# Service Configuration
TEMPLATE_SERVICE_PORT=8005

# Database Configuration
POSTGRES_USER=your_user
POSTGRES_PASSWORD=your_password
PG_HOST_SRC=localhost
PG_PORT=5432
POSTGRES_DB=your_db
```

## Setup and Installation

1. **Prerequisites**
   - Python 3.10 or higher
   - PostgreSQL server
   - FHIR Resources package

2. **Installation**
   ```bash
   # Create and activate virtual environment
   python -m venv venv
   source venv/bin/activate  # or `venv\Scripts\activate` on Windows

   # Install dependencies
   pip install -r requirements.txt
   ```

3. **Running the Service**
   ```bash
   uvicorn main:app --host 0.0.0.0 --port 8005
   ```

## API Endpoints

All endpoints are prefixed with `/api/v1`.

### Health Check
- `GET /health`
  - Checks service status and database connection
  - Returns detailed connection status

### Template Management
- `POST /templates`
  - Create a new questionnaire template
  - Accepts FHIR Questionnaire resource
  - Returns created template with ID

- `GET /templates/{template_id}`
  - Retrieve a specific template
  - Returns full template details

- `PUT /templates/{template_id}`
  - Update an existing template
  - Accepts updated FHIR Questionnaire
  - Returns updated template

- `DELETE /templates/{template_id}`
  - Delete a template
  - Returns success status

### Response Management
- `POST /responses`
  - Store a new questionnaire response
  - Links response to template
  - Returns created response

- `GET /responses/{response_id}`
  - Retrieve a specific response
  - Returns full response details

- `GET /templates/{template_id}/responses`
  - Get all responses for a template
  - Supports pagination and filtering

## Database Schema

The service uses two main tables:

1. **questionnaires**
   - Stores FHIR Questionnaire templates
   - Includes version control
   - Supports metadata

2. **questionnaire_responses**
   - Stores FHIR QuestionnaireResponse resources
   - Links to templates
   - Includes timestamps and metadata

## Integration

The service integrates with other NexusCare components:

1. **API Gateway**
   - Provides unified access to template endpoints
   - Handles authentication and routing

2. **AI Processing Service**
   - Can analyze template responses
   - Supports entity extraction from responses

## Performance Considerations

- Efficient database queries
- Connection pooling
- Response caching
- Optimized indexes

## Error Handling

- Comprehensive error logging
- HTTP status codes for different error types
- Detailed error messages
- Database connection error handling

## Security

- CORS configuration
- Environment variable based configuration
- Database credential management
- Input validation

## Monitoring

- Health check endpoint
- Database connection monitoring
- Query performance tracking
- Error logging

## Future Enhancements

1. **Planned Features**
   - Template versioning system
   - Response validation against templates
   - Template categories and tags
   - Advanced search capabilities

2. **Technical Improvements**
   - Implement proper database connection pooling
   - Convert to async database operations
   - Add authentication/authorization
   - Add comprehensive testing

## Contributing

Please refer to the main project documentation for contribution guidelines.

## License

This service is part of the NexusCare AI backend and is subject to the project's license terms. 