# template_service/database.py
import os
import logging
# Import standard SQLAlchemy types too
from sqlalchemy import MetaData, Table, Column, Integer, String, JSON, TIMESTAMP, CheckConstraint, Index, Text # Import Text
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy.schema import CreateSchema
# Import specific PostgreSQL types including ARRAY and UUID
from sqlalchemy.dialects.postgresql import JSONB, VARCHAR, TEXT as PG_TEXT, ARRAY, UUID # Import TEXT as PG_TEXT to avoid naming conflict if needed

from dotenv import load_dotenv, find_dotenv

logger = logging.getLogger(__name__)

# --- Load Root .env File ---
logger.info("Template Service: Loading environment configuration...")
#env_path = find_dotenv(filename='.env', raise_error_if_not_found=False, usecwd=True)
env_path = find_dotenv(filename='.env', raise_error_if_not_found=False)
if env_path:
    logger.info(f"Template Service: Loading environment variables from: {env_path}")
    load_dotenv(dotenv_path=env_path, verbose=True)
else:
    logger.warning("Template Service: Could not find .env file.")

# --- Read Shared DB Credentials ---
logger.info(f"DEBUG: DB_USER={os.getenv('POSTGRES_USER')}, DB_PASSWORD={os.getenv('POSTGRES_PASSWORD')}, DB_HOST={os.getenv('PG_HOST_SRC')}, DB_PORT={os.getenv('PG_PORT')}, DB_NAME={os.getenv('POSTGRES_DB')}")
DB_USER = os.getenv('POSTGRES_USER')
DB_PASSWORD = os.getenv('POSTGRES_PASSWORD')
DB_HOST = os.getenv('PG_HOST_SRC')
DB_PORT = os.getenv('PG_PORT')
DB_NAME = os.getenv('POSTGRES_DB')

# --- Construct Database URL ---
if not all([DB_USER, DB_PASSWORD, DB_HOST, DB_PORT, DB_NAME]):
    logger.critical("FATAL: Missing PostgreSQL connection details for Template Service!")
    DATABASE_URL = None
else:
    DATABASE_URL = f"postgresql+asyncpg://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# --- SQLAlchemy Engine and Session ---
if DATABASE_URL:
    engine = create_async_engine(DATABASE_URL, echo=False, pool_pre_ping=True)
    async_session_local = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
else:
    engine = None; async_session_local = None
    logger.error("Database engine could not be created due to missing configuration.")

# --- Table Definitions ---
SCHEMA_NAME = "clinical_consolidated"
metadata = MetaData()

# Questionnaires Table
questionnaires_table = Table(
    "questionnaires", metadata,
    Column("id", Integer, primary_key=True),
    Column("template_id", VARCHAR(100), nullable=False, unique=True),
    Column("version", VARCHAR(20)),
    Column("status", VARCHAR(20), CheckConstraint("status IN ('draft', 'active', 'retired')")),
    Column("title", VARCHAR(255)), Column("publisher", VARCHAR(255)),
    Column("resource", JSONB, nullable=False),
    Column("encounter_type", VARCHAR(100)),
    # Use standard Text type for ARRAY elements
    Column("tags", ARRAY(Text)),
    # Use standard TIMESTAMP(timezone=True) for TIMESTAMPTZ columns
    Column("created_at", TIMESTAMP(timezone=True), server_default='CURRENT_TIMESTAMP'),
    Column("updated_at", TIMESTAMP(timezone=True), server_default='CURRENT_TIMESTAMP'),
    Index("idx_questionnaires_id", "template_id"),
    Index("idx_questionnaires_jsonb_gin", "resource", postgresql_using="gin"),
    Index("idx_questionnaires_encounter_type", "encounter_type"),
    Index("idx_questionnaires_tags_gin", "tags", postgresql_using="gin"),
    schema=SCHEMA_NAME
)

# QuestionnaireResponses Table
questionnaire_responses_table = Table(
    "questionnaire_responses", metadata,
    Column("id", Integer, primary_key=True),
    # Use PostgreSQL specific UUID type for default value generation compatibility
    Column("response_id", UUID, nullable=False, unique=True, server_default='gen_random_uuid()'),
    Column("questionnaire_ref", VARCHAR(255), nullable=False),
    Column("status", VARCHAR(20), CheckConstraint("status IN ('in-progress', 'completed', 'amended', 'entered-in-error')")),
    Column("subject_ref", VARCHAR(255)), Column("encounter_ref", VARCHAR(255)),
    Column("authored", TIMESTAMP(timezone=True), server_default='CURRENT_TIMESTAMP'), # Use TIMESTAMP(timezone=True)
    Column("author_ref", VARCHAR(255)),
    Column("resource", JSONB, nullable=False),
    Column("created_at", TIMESTAMP(timezone=True), server_default='CURRENT_TIMESTAMP'), # Use TIMESTAMP(timezone=True)
    Column("updated_at", TIMESTAMP(timezone=True), server_default='CURRENT_TIMESTAMP'), # Use TIMESTAMP(timezone=True)
    Index("idx_questionnaire_responses_questionnaire_ref", "questionnaire_ref"),
    Index("idx_questionnaire_responses_subject_ref", "subject_ref"),
    Index("idx_questionnaire_responses_jsonb_gin", "resource", postgresql_using="gin"),
    schema=SCHEMA_NAME
)

# Optional: Function to ensure schema exists
async def ensure_schema_exists():
     if not engine: logger.error("Cannot ensure schema, engine not initialized."); return
     try:
         async with engine.begin() as conn: await conn.execute(CreateSchema(SCHEMA_NAME, if_not_exists=True))
     except Exception as e: logger.error(f"Error ensuring schema '{SCHEMA_NAME}' exists: {e}")

# Dependency to get DB session
async def get_db() -> AsyncSession:
    """Dependency function that yields an AsyncSession."""
    if async_session_local is None: raise HTTPException(status_code=503, detail="DB connection not configured.")
    async with async_session_local() as session:
        try: yield session
        except Exception: await session.rollback(); raise
        finally: await session.close()