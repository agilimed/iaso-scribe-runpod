# template_service/crud.py
import logging
from typing import List, Optional, Dict, Any
from sqlalchemy import select, insert, update, delete
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import IntegrityError, NoResultFound

# Use absolute imports assuming these files are siblings in the template_service dir
import database # Changed from relative
import models   # Changed from relative

logger = logging.getLogger(__name__)

async def create_template(db: AsyncSession, template_data: models.TemplateCreate) -> Optional[models.TemplateDB]: # Use models. prefix
    """Creates a new Questionnaire template in the database."""
    fhir_resource = template_data.resource
    template_fhir_id = fhir_resource.get("id")
    if not template_fhir_id: logger.error("Cannot create: FHIR resource missing 'id'."); return None

    version = fhir_resource.get("version")
    status = fhir_resource.get("status")
    title = fhir_resource.get("title")
    publisher = fhir_resource.get("publisher")
    encounter_type = template_data.encounter_type
    tags = template_data.tags

    insert_stmt = insert(database.questionnaires_table).values( # Use database. prefix
        template_id=template_fhir_id,
        version=version, status=status, title=title, publisher=publisher,
        resource=fhir_resource, encounter_type=encounter_type, tags=tags
    ).returning(database.questionnaires_table) # Use database. prefix

    try:
        result = await db.execute(insert_stmt)
        await db.commit()
        inserted_row = result.fetchone()
        if inserted_row:
            logger.info(f"Successfully created template with template_id: {template_fhir_id}")
            return models.TemplateDB(**inserted_row._mapping) # Use models. prefix
        else: logger.error("Insert executed but no row returned."); return None
    except IntegrityError as e:
        await db.rollback()
        if "duplicate key value violates unique constraint" in str(e).lower() and "questionnaires_template_id_key" in str(e).lower() :
            logger.warning(f"Template with template_id '{template_fhir_id}' already exists.")
            return None # Indicate conflict
        else: logger.error(f"Database integrity error creating template: {e}", exc_info=True); raise
    except Exception as e: await db.rollback(); logger.error(f"Error creating template '{template_fhir_id}': {e}", exc_info=True); raise

async def get_template_by_fhir_id(db: AsyncSession, template_fhir_id: str) -> Optional[models.TemplateDB]: # Use models. prefix
    """Retrieves a template by its FHIR logical ID."""
    select_stmt = select(database.questionnaires_table).where(database.questionnaires_table.c.template_id == template_fhir_id) # Use database. prefix
    result = await db.execute(select_stmt)
    row = result.fetchone()
    return models.TemplateDB(**row._mapping) if row else None # Use models. prefix

async def get_all_templates(
    db: AsyncSession, skip: int = 0, limit: int = 100,
    encounter_type: Optional[str] = None, tags: Optional[List[str]] = None
    ) -> List[models.TemplateDB]: # Use models. prefix
    """Retrieves a list of templates with optional filtering and pagination."""
    select_stmt = select(database.questionnaires_table) # Use database. prefix

    if encounter_type:
        select_stmt = select_stmt.where(database.questionnaires_table.c.encounter_type == encounter_type) # Use database. prefix

    if tags:
        select_stmt = select_stmt.where(database.questionnaires_table.c.tags.overlap(tags)) # Use database. prefix

    select_stmt = select_stmt.offset(skip).limit(limit).order_by(database.questionnaires_table.c.template_id) # Use database. prefix

    result = await db.execute(select_stmt)
    rows = result.fetchall()
    return [models.TemplateDB(**row._mapping) for row in rows] # Use models. prefix

async def update_template_metadata(
    db: AsyncSession, template_fhir_id: str,
    update_data: models.TemplateMetadataUpdate # Use models. prefix
    ) -> Optional[models.TemplateDB]: # Use models. prefix
    """Updates metadata (encounter_type, tags) for a template."""
    values_to_update = update_data.model_dump(exclude_unset=True)
    if not values_to_update:
        logger.warning(f"Update metadata called for {template_fhir_id} with no values to change.")
        return await get_template_by_fhir_id(db, template_fhir_id) # Use get_template_by_fhir_id (already updated)

    update_stmt = update(database.questionnaires_table)\
        .where(database.questionnaires_table.c.template_id == template_fhir_id)\
        .values(**values_to_update)\
        .returning(database.questionnaires_table)

    try:
        result = await db.execute(update_stmt)
        await db.commit()
        updated_row = result.fetchone()
        if updated_row:
             logger.info(f"Updated metadata for template: {template_fhir_id}")
             return models.TemplateDB(**updated_row._mapping) # Use models. prefix
        else: logger.warning(f"Template {template_fhir_id} not found during metadata update attempt."); return None
    except Exception as e: await db.rollback(); logger.error(f"Error updating template metadata for '{template_fhir_id}': {e}", exc_info=True); raise

async def delete_template(db: AsyncSession, template_fhir_id: str) -> bool:
    """Deletes a template by its FHIR logical ID. Returns True if deleted, False otherwise."""
    delete_stmt = delete(database.questionnaires_table)\
        .where(database.questionnaires_table.c.template_id == template_fhir_id) # Use database. prefix

    try:
        result = await db.execute(delete_stmt)
        await db.commit()
        deleted_count = result.rowcount
        if deleted_count > 0: logger.info(f"Deleted template: {template_fhir_id}"); return True
        else: logger.warning(f"Template {template_fhir_id} not found for deletion."); return False
    except Exception as e: await db.rollback(); logger.error(f"Error deleting template '{template_fhir_id}': {e}", exc_info=True); raise