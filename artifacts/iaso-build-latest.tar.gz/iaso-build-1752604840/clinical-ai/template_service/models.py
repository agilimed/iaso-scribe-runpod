# template_service/models.py
from pydantic import BaseModel, Field, field_validator, ConfigDict
from typing import List, Optional, Dict, Any
from datetime import datetime

# For listing templates - Summary view
class TemplateSummary(BaseModel):
    template_id: str
    version: Optional[str] = None
    status: Optional[str] = None
    title: Optional[str] = None
    publisher: Optional[str] = None
    encounter_type: Optional[str] = None
    tags: Optional[List[str]] = None
    updated_at: datetime

# For reading a single template (includes full FHIR resource)
class TemplateRead(BaseModel):
    template_id: str
    version: Optional[str] = None
    status: Optional[str] = None
    title: Optional[str] = None
    publisher: Optional[str] = None
    encounter_type: Optional[str] = None
    tags: Optional[List[str]] = None
    resource: Dict[str, Any] # The full FHIR Questionnaire JSON
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True) # Enable reading data from ORM models

# For creating a template
class TemplateCreate(BaseModel):
    resource: Dict[str, Any] = Field(..., example={"resourceType": "Questionnaire", "id": "example-id", "status": "draft", "item": []})
    # Optional fields if setting during creation is desired
    encounter_type: Optional[str] = None
    tags: Optional[List[str]] = None

    @field_validator('resource')
    @classmethod
    def check_fhir_basics(cls, v):
        if not isinstance(v, dict): raise ValueError('resource must be a dict')
        if v.get("resourceType") != "Questionnaire": raise ValueError('must be Questionnaire')
        if not v.get("id"): raise ValueError('must have an "id"')
        if not v.get("status"): raise ValueError('must have a "status"')
        return v

# For updating metadata
class TemplateMetadataUpdate(BaseModel):
    encounter_type: Optional[str] = Field(None, description="Set or clear the encounter type.")
    tags: Optional[List[str]] = Field(None, description="Set or clear the list of tags.")

# Internal representation matching DB structure
class TemplateDB(TemplateRead):
    id: int # Internal DB primary key