# 🧪 NexusCare AI Service - Complete Testing Guide

## 📋 **Quick Start**

### **Base URL:** `http://localhost:8002`

### **1. Health Check**
```http
GET /health
```

### **2. Available Models**
```http
GET /models
```

---

## 🎯 **Main Processing Endpoint**

### **Basic Processing (No ClinicalBERT)**
```http
POST /process
Content-Type: application/json

{
  "text": "Patient presents with right upper quadrant pain, fever, and nausea for 2 days. Exam shows RUQ tenderness and positive Murphy's sign. Labs show elevated WBC. Suspect cholecystitis.",
  "template_id": "soap-note-general",
  "patient_ref": "Patient/example",
  "encounter_ref": "Encounter/example",
  "author_ref": "Practitioner/example",
  "perform_summarization": false,
  "perform_structuring": true,
  "use_llm_for_gap_filling": false,
  "enable_clinical_bert": false
}
```

### **With Default ClinicalBERT**
```json
{
  "text": "Patient discharged home in stable condition after successful treatment.",
  "enable_clinical_bert": true,
  "perform_summarization": false,
  "perform_structuring": false
}
```

### **With Specific ClinicalBERT Model**
```json
{
  "text": "Patient discharged home in stable condition after successful treatment.",
  "clinical_bert_model": "discharge",
  "document_type": "discharge_summary",
  "enable_clinical_bert": true
}
```

### **Auto Model Selection by Document Type**
```json
{
  "text": "Patient presents with chest pain during office visit.",
  "document_type": "consultation",
  "enable_clinical_bert": true
}
```

---

## 🤖 **ClinicalBERT Model Options**

### **Available Models:**
- `"clinical"` → Bio_ClinicalBERT (general clinical text)
- `"discharge"` → Bio_Discharge_Summary_BERT (discharge summaries)
- `"pubmed"` → PubMedBERT (research/publications)
- `"biobert"` → BioBERT (biomedical text)

### **Full Model Names:**
- `"emilyalsentzer/Bio_ClinicalBERT"`
- `"emilyalsentzer/Bio_Discharge_Summary_BERT"`
- `"microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract-fulltext"`
- `"dmis-lab/biobert-base-cased-v1.1"`

---

## 🧪 **ClinicalBERT Specific Endpoints**

### **1. Get Embeddings**
```http
POST /clinical-bert/embeddings
Content-Type: application/json

{
  "text": "Patient has chest pain",
  "model_name": "clinical"
}
```

### **2. Calculate Similarity**
```http
POST /clinical-bert/similarity
Content-Type: application/json

{
  "text1": "chest pain",
  "text2": "cardiac discomfort",
  "model_name": "clinical"
}
```

### **3. Compare Models**
```http
POST /clinical-bert/compare-models
Content-Type: application/json

{
  "text": "Patient discharged home in stable condition",
  "models": ["clinical", "discharge", "pubmed"]
}
```

### **4. ClinicalBERT Status**
```http
GET /clinical-bert/status
```

### **5. Clear Model Cache**
```http
DELETE /clinical-bert/cache
```

```http
DELETE /clinical-bert/cache?model_name=discharge
```

---

## 📝 **Complete Test Scenarios**

### **Scenario 1: Discharge Summary**
```json
{
  "text": "Patient was admitted with acute appendicitis and underwent laparoscopic appendectomy. Post-operative course was uncomplicated. Patient is being discharged home with oral antibiotics and pain medication. Follow-up in 2 weeks.",
  "document_type": "discharge_summary",
  "clinical_bert_model": "discharge", 
  "enable_clinical_bert": true,
  "template_id": "discharge-summary-template",
  "perform_summarization": true,
  "perform_structuring": true
}
```

### **Scenario 2: Progress Note**
```json
{
  "text": "Patient returns for follow-up of diabetes mellitus type 2. Blood sugar has been well controlled on metformin. A1C is 6.8%. Patient reports no symptoms. Continue current medication.",
  "document_type": "progress_note",
  "clinical_bert_model": "clinical",
  "enable_clinical_bert": true,
  "perform_summarization": false,
  "perform_structuring": true
}
```

### **Scenario 3: Research/Academic Text**
```json
{
  "text": "Recent studies have shown that ACE inhibitors reduce cardiovascular mortality in patients with heart failure. The mechanism involves reduction in afterload and preload.",
  "document_type": "research",
  "clinical_bert_model": "pubmed",
  "enable_clinical_bert": true
}
```

### **Scenario 4: No ClinicalBERT (Fastest)**
```json
{
  "text": "Patient presents with shortness of breath and chest pain. Physical exam reveals bilateral crackles and elevated JVP. Chest X-ray shows pulmonary edema.",
  "enable_clinical_bert": false,
  "template_id": "soap-note-general",
  "perform_summarization": false,
  "perform_structuring": true
}
```

### **Scenario 5: Model Comparison Test**
```json
{
  "text": "Patient experienced myocardial infarction with ST elevation in leads II, III, and aVF indicating inferior wall STEMI.",
  "models": ["clinical", "discharge", "biobert"]
}
```

---

## 🎭 **Document Type Auto-Selection**

| Document Type | Auto-Selected Model |
|---------------|-------------------|
| `"discharge_summary"` | `Bio_Discharge_Summary_BERT` |
| `"discharge"` | `Bio_Discharge_Summary_BERT` |
| `"summary"` | `Bio_Discharge_Summary_BERT` |
| `"consultation"` | `Bio_ClinicalBERT` |
| `"progress_note"` | `Bio_ClinicalBERT` |
| `"note"` | `Bio_ClinicalBERT` |
| `"research"` | `PubMedBERT` |
| `"pubmed"` | `PubMedBERT` |
| Other | Config Default |

---

## ⚡ **Performance Testing**

### **Speed Test (No ClinicalBERT)**
```json
{
  "text": "Quick test for performance measurement.",
  "enable_clinical_bert": false,
  "perform_summarization": false,
  "perform_structuring": false,
  "use_llm_for_gap_filling": false
}
```

### **Full Pipeline Test**
```json
{
  "text": "Patient presents with complex medical history including diabetes, hypertension, and coronary artery disease. Current symptoms include chest pain and shortness of breath.",
  "clinical_bert_model": "clinical",
  "enable_clinical_bert": true,
  "template_id": "comprehensive-assessment",
  "perform_summarization": true,
  "perform_structuring": true,
  "use_llm_for_gap_filling": true
}
```

---

## 🏥 **Sample Clinical Texts for Testing**

### **Cardiology**
```
"Patient presents with chest pain radiating to left arm. ECG shows ST elevation in leads V2-V4. Troponin I elevated at 15.2 ng/mL. Diagnosed with anterior STEMI. Patient taken for emergent cardiac catheterization."
```

### **Emergency Medicine**
```
"23-year-old male presents after motor vehicle accident. Complains of right leg pain. X-ray shows displaced femur fracture. Vitals stable. Administered morphine 4mg IV for pain control."
```

### **Internal Medicine**
```
"67-year-old female with history of diabetes and hypertension presents for routine follow-up. HbA1c is 7.2%, blood pressure 145/92. Discussed medication compliance and dietary modifications."
```

### **Surgery**
```
"Patient underwent laparoscopic cholecystectomy for acute cholecystitis. Procedure completed without complications. Four ports used. Gallbladder removed intact. Patient recovered well from anesthesia."
```

---

## 🔧 **Troubleshooting**

### **Common Issues:**

1. **Service Not Starting**
   ```bash
   # Check logs
   tail -f logs/clinicalai_service.log
   
   # Verify dependencies
   curl http://localhost:8002/health
   ```

2. **ClinicalBERT Not Loading**
   ```json
   {
     "enable_clinical_bert": false
   }
   ```

3. **Template Not Found**
   ```json
   {
     "template_id": null,
     "perform_structuring": false
   }
   ```

### **Response Codes:**
- `200` - Success
- `422` - Validation Error (check JSON format)
- `503` - Service Unavailable (check health endpoint)
- `500` - Internal Server Error (check logs)

---

## 📊 **Expected Response Structure**

```json
{
  "request_id": "uuid-string",
  "original_text_char_count": 123,
  "enriched_entities": [...],
  "fhir_payload": {...},
  "summary_payload": null,
  "errors": [],
  "warnings": [],
  "timing_metrics_ms": {
    "nlp_engine_ms": 45.2,
    "total_pipeline_ms": 67.8
  },
  "models_used": {
    "nlp_engine": "spacy",
    "spacy_model": "en_core_sci_lg",
    "clinical_bert_enabled": "true",
    "clinical_bert_model": "emilyalsentzer/Bio_ClinicalBERT"
  },
  "clinical_bert_info": {
    "model_used": "emilyalsentzer/Bio_ClinicalBERT",
    "model_cached": true,
    "cache_info": {...}
  }
}
```

---

## 🚀 **Quick Test Commands**

### **1. Basic Health Check**
```bash
curl http://localhost:8002/health
```

### **2. Simple Processing**
```bash
curl -X POST http://localhost:8002/process \
  -H "Content-Type: application/json" \
  -d '{"text": "Patient has fever and cough", "enable_clinical_bert": false}'
```

### **3. Model Status**
```bash
curl http://localhost:8002/clinical-bert/status
```

---

## 💡 **Pro Tips**

1. **Start Simple**: Begin with `enable_clinical_bert: false` for fastest responses
2. **Model Selection**: Use `document_type` for automatic model selection
3. **Performance**: Check `timing_metrics_ms` to optimize processing
4. **Caching**: First request loads model, subsequent requests are faster
5. **Debugging**: Always check `/health` endpoint first

---

## 🔄 **Postman Collection**

Import this JSON into Postman for all endpoints:

```json
{
  "info": {
    "name": "NexusCare AI Service",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Health Check",
      "request": {
        "method": "GET",
        "header": [],
        "url": {
          "raw": "{{base_url}}/health",
          "host": ["{{base_url}}"],
          "path": ["health"]
        }
      }
    },
    {
      "name": "Process Clinical Note",
      "request": {
        "method": "POST",
        "header": [
          {
            "key": "Content-Type",
            "value": "application/json"
          }
        ],
        "body": {
          "mode": "raw",
          "raw": "{\n  \"text\": \"Patient presents with chest pain\",\n  \"enable_clinical_bert\": true,\n  \"clinical_bert_model\": \"clinical\"\n}"
        },
        "url": {
          "raw": "{{base_url}}/process",
          "host": ["{{base_url}}"],
          "path": ["process"]
        }
      }
    }
  ],
  "variable": [
    {
      "key": "base_url",
      "value": "http://localhost:8002"
    }
  ]
}
```

Set Environment Variable: `base_url = http://localhost:8002`
