# 🌐 NexusCare AI - Enhanced API Documentation

> **Comprehensive API Reference for Advanced Clinical NLP Processing**

Version: **1.0.0** | Last Updated: **May 2025** | Base URL: `http://localhost:8002`

---

## 📋 **Table of Contents**

- [Authentication](#authentication)
- [Core Processing](#core-processing)
- [ClinicalBERT Operations](#clinicalbert-operations)
- [Debug & Testing](#debug--testing)
- [Health & Monitoring](#health--monitoring)
- [Response Formats](#response-formats)
- [Error Handling](#error-handling)
- [Rate Limiting](#rate-limiting)
- [Examples](#examples)

---

## 🔐 **Authentication**

Currently, the API uses IP-based access control. Future versions will support:
- API Keys
- JWT Tokens  
- OAuth 2.0

```http
# For future API key authentication
Authorization: Bearer your-api-key-here
```

---

## 🧠 **Core Processing**

### **Main Processing Endpoint**

Process clinical text through the enhanced multi-engine NLP pipeline with intelligent fallback system.

```http
POST /process
Content-Type: application/json
```

#### **Request Schema**

```json
{
  "text": "string (required)",
  "clinical_bert_model": "clinical|discharge|pubmed|biobert (optional)",
  "enable_clinical_bert": "boolean (optional)",
  "document_type": "string (optional)",
  "template_id": "string (optional)",
  "perform_summarization": "boolean (optional, default: true)",
  "perform_structuring": "boolean (optional, default: true)",
  "use_llm_for_gap_filling": "boolean (optional, default: true)",
  "patient_ref": "string (optional)",
  "encounter_ref": "string (optional)",
  "author_ref": "string (optional)"
}
```

#### **Request Parameters**

| Parameter | Type | Required | Description | Default |
|-----------|------|----------|-------------|---------|
| `text` | string | ✅ | Clinical text to process (max 50,000 characters) | - |
| `clinical_bert_model` | string | ❌ | Specific ClinicalBERT model to use | `clinical` |
| `enable_clinical_bert` | boolean | ❌ | Enable/disable ClinicalBERT processing | `true` |
| `document_type` | string | ❌ | Document type for automatic model selection | - |
| `template_id` | string | ❌ | FHIR template ID for structured output | - |
| `perform_summarization` | boolean | ❌ | Generate LLM summary | `true` |
| `perform_structuring` | boolean | ❌ | Generate FHIR QuestionnaireResponse | `true` |
| `use_llm_for_gap_filling` | boolean | ❌ | Use LLM for additional entity detection | `true` |
| `patient_ref` | string | ❌ | FHIR Patient reference | - |
| `encounter_ref` | string | ❌ | FHIR Encounter reference | - |
| `author_ref` | string | ❌ | FHIR Practitioner reference | - |

#### **ClinicalBERT Model Options**

| Model | Alias | Best For | Memory |
|-------|-------|----------|---------|
| `emilyalsentzer/Bio_ClinicalBERT` | `clinical` | General clinical notes | ~2GB |
| `emilyalsentzer/Bio_Discharge_Summary_BERT` | `discharge` | Discharge summaries | ~2GB |
| `microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract-fulltext` | `pubmed` | Research/academic text | ~2GB |
| `dmis-lab/biobert-base-cased-v1.1` | `biobert` | Biomedical literature | ~2GB |

#### **Document Type Auto-Selection**

| Document Type | Auto-Selected Model |
|---------------|-------------------|
| `consultation`, `progress_note`, `note` | `Bio_ClinicalBERT` |
| `discharge_summary`, `discharge`, `summary` | `Bio_Discharge_Summary_BERT` |
| `research`, `pubmed`, `academic` | `PubMedBERT` |
| `biomedical`, `literature` | `BioBERT` |

#### **Response Schema**

```json
{
  "request_id": "string",
  "original_text_char_count": "integer",
  "enriched_entities": [
    {
      "id": "string",
      "text": "string",
      "start_char": "integer",
      "end_char": "integer",
      "label": "string",
      "source_ner_engine": "medcat|spacy_ner|llm_ner",
      "section_title": "string",
      "ner_confidence": "float",
      "primary_cui": "string|null",
      "backend_category": "string",
      "type_ids": ["string"],
      "type_names": ["string"],
      "standard_codes": [
        {
          "code": "string",
          "vocabulary": "string", 
          "display": "string"
        }
      ],
      "fhir_codeable_concept": {
        "coding": [
          {
            "system": "string",
            "code": "string",
            "display": "string"
          }
        ],
        "text": "string"
      },
      "negated": "boolean",
      "historical": "boolean",
      "hypothetical": "boolean",
      "family_history": "boolean"
    }
  ],
  "fhir_payload": {
    "fhir_qr": "object|null",
    "template_used": "string|null",
    "placeholders_filled": "integer"
  },
  "summary_payload": {
    "summary_text": "string|null"
  },
  "errors": ["string"],
  "warnings": ["string"],
  "timing_metrics_ms": {
    "nlp_engine_ms": "float",
    "fallback_processing_ms": "float",
    "template_mapping_ms": "float",
    "llm_summary_ms": "float",
    "total_pipeline_ms": "float"
  },
  "models_used": {
    "nlp_engine": "string",
    "spacy_model": "string",
    "clinical_bert_enabled": "string",
    "clinical_bert_model": "string"
  },
  "clinical_bert_info": {
    "model_used": "string",
    "model_cached": "boolean",
    "cache_info": "object"
  }
}
```

#### **Example Request**

```bash
curl -X POST http://localhost:8002/process \
  -H "Content-Type: application/json" \
  -d '{
    "text": "52-year-old female with hypothyroidism on levothyroxine 75 mcg daily. TSH elevated at 8.5. Plan: increase to 88 mcg daily.",
    "clinical_bert_model": "clinical",
    "document_type": "progress_note",
    "template_id": "soap-note-general",
    "perform_summarization": true,
    "perform_structuring": true
  }'
```

#### **Example Response**

```json
{
  "request_id": "uuid-example",
  "original_text_char_count": 125,
  "enriched_entities": [
    {
      "id": "entity-1",
      "text": "levothyroxine",
      "start_char": 45,
      "end_char": 58,
      "label": "ENTITY",
      "source_ner_engine": "spacy_ner",
      "section_title": "intelligent_fallback",
      "ner_confidence": 0.95,
      "primary_cui": "C0040165",
      "backend_category": "DRUG",
      "type_ids": ["T121"],
      "type_names": ["Pharmacologic Substance"],
      "standard_codes": [
        {
          "code": "C0040165",
          "vocabulary": "UMLS",
          "display": "levothyroxine"
        }
      ],
      "fhir_codeable_concept": {
        "coding": [
          {
            "system": "http://snomed.info/sct",
            "code": "387467008",
            "display": "Levothyroxine"
          }
        ],
        "text": "levothyroxine"
      },
      "negated": false,
      "historical": false,
      "hypothetical": false,
      "family_history": false
    }
  ],
  "timing_metrics_ms": {
    "nlp_engine_ms": 8766.2,
    "fallback_processing_ms": 234.5,
    "total_pipeline_ms": 9124.1
  },
  "models_used": {
    "nlp_engine": "medcat",
    "spacy_model": "en_core_sci_lg",
    "clinical_bert_enabled": "true",
    "clinical_bert_model": "emilyalsentzer/Bio_ClinicalBERT"
  }
}
```

---

## 🧠 **ClinicalBERT Operations**

### **Get Text Embeddings**

Generate embeddings for clinical text using specified ClinicalBERT model.

```http
POST /clinical-bert/embeddings
Content-Type: application/json
```

#### **Request Schema**

```json
{
  "text": "string (required)",
  "model_name": "clinical|discharge|pubmed|biobert (optional)"
}
```

#### **Response Schema**

```json
{
  "text": "string",
  "model_used": "string",
  "embeddings": ["float"],
  "embedding_magnitude": "float",
  "processing_time_ms": "float"
}
```

#### **Example**

```bash
curl -X POST http://localhost:8002/clinical-bert/embeddings \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Patient has chest pain and dyspnea",
    "model_name": "clinical"
  }'
```

### **Calculate Text Similarity**

Calculate semantic similarity between two clinical texts.

```http
POST /clinical-bert/similarity
Content-Type: application/json
```

#### **Request Schema**

```json
{
  "text1": "string (required)",
  "text2": "string (required)",
  "model_name": "string (optional)"
}
```

#### **Response Schema**

```json
{
  "text1": "string",
  "text2": "string", 
  "model_used": "string",
  "similarity_score": "float",
  "processing_time_ms": "float"
}
```

#### **Example**

```bash
curl -X POST http://localhost:8002/clinical-bert/similarity \
  -H "Content-Type: application/json" \
  -d '{
    "text1": "chest pain",
    "text2": "cardiac discomfort",
    "model_name": "clinical"
  }'
```

### **Compare Multiple Models**

Compare how different ClinicalBERT models represent the same clinical text.

```http
POST /clinical-bert/compare-models
Content-Type: application/json
```

#### **Request Schema**

```json
{
  "text": "string (required)",
  "models": ["string"] // 2-4 models
}
```

#### **Response Schema**

```json
{
  "text": "string",
  "models_compared": ["string"],
  "embeddings_comparison": {
    "model_name": {
      "magnitude": "float",
      "shape": ["integer"]
    }
  },
  "similarity_matrix": {
    "model1_vs_model2": "float"
  },
  "analysis_comparison": {
    "model_name": "object"
  },
  "recommendation": "string|null"
}
```

#### **Example**

```bash
curl -X POST http://localhost:8002/clinical-bert/compare-models \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Patient discharged home in stable condition",
    "models": ["clinical", "discharge", "pubmed"]
  }'
```

### **ClinicalBERT Status & Management**

#### **Get Model Status**

```http
GET /clinical-bert/status
```

**Response:**
```json
{
  "enabled": "boolean",
  "available_models": ["string"],
  "default_model": "string",
  "cached_models": ["string"],
  "cache_utilization": "string",
  "device": "string",
  "transformers_available": "boolean"
}
```

#### **Clear Model Cache**

```http
DELETE /clinical-bert/cache
Delete /clinical-bert/cache?model_name=discharge
```

**Response:**
```json
{
  "message": "string",
  "cache_info": "object"
}
```

---

## 🔍 **Debug & Testing**

### **Test Intelligent Fallback System**

Debug and test the intelligent fallback system that catches entities missed by primary NER engines.

```http
POST /debug/test-fallback
Content-Type: application/json
```

#### **Request Schema**

```json
{
  "text": "string (required)"
}
```

#### **Response Schema**

```json
{
  "text": "string",
  "medcat_entities": [
    {
      "text": "string",
      "label": "string"
    }
  ],
  "spacy_entities": [
    {
      "text": "string",
      "label": "string",
      "start": "integer",
      "end": "integer"
    }
  ],
  "fallback_entities": [
    {
      "text": "string",
      "label": "string",
      "confidence": "float"
    }
  ],
  "check_logs": "string"
}
```

#### **Example**

```bash
curl -X POST http://localhost:8002/debug/test-fallback \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Patient takes levothyroxine 75 mcg daily"
  }'
```

### **Debug MedCAT Processing**

Detailed debugging of MedCAT entity detection pipeline.

```http
POST /debug/medcat-processing
Content-Type: application/json
```

#### **Request Schema**

```json
{
  "text": "string (required)"
}
```

#### **Response Schema**

```json
{
  "debug_result": {
    "total_entities": "integer",
    "target_entities_found": ["object"],
    "levothyroxine_entities": ["object"],
    "sample_entities": ["object"]
  },
  "message": "string"
}
```

### **Debug MedCAT Tokenization**

Low-level debugging of MedCAT tokenization and entity recognition.

```http
POST /debug/medcat-tokenization
```

**Response:**
```json
{
  "message": "string"
}
```

### **Test spaCy Clinical Model**

Test spaCy clinical model directly without MedCAT processing.

```http
POST /debug/test-spacy-only
Content-Type: application/json
```

#### **Request Schema**

```json
{
  "text": "string (required)"
}
```

#### **Response Schema**

```json
{
  "text": "string",
  "spacy_model": "string",
  "entities_found": "integer",
  "entities": [
    {
      "text": "string",
      "label": "string", 
      "start": "integer",
      "end": "integer"
    }
  ]
}
```

---

## 🏥 **Health & Monitoring**

### **Service Health Check**

Comprehensive health check including all service components and dependencies.

```http
GET /health
```

#### **Response Schema**

```json
{
  "service_name": "string",
  "status": "healthy|degraded|unhealthy",
  "version": "string",
  "timestamp": "string",
  "dependencies": {
    "component_name": "ok|error|not_configured"
  },
  "active_nlp_engine": "string",
  "medcat_model_loaded": "boolean",
  "spacy_model_loaded": "boolean",
  "clinical_bert_status": {
    "enabled": "boolean",
    "available": "boolean",
    "default_model": "string",
    "cache_info": "object",
    "device": "string"
  }
}
```

#### **Health Status Codes**

| Status | Description |
|--------|-------------|
| `healthy` | All components operational |
| `degraded` | Some components have issues but service is functional |
| `unhealthy` | Critical components are failing |

### **Available Models Information**

Get information about available NLP models and their status.

```http
GET /models
```

#### **Response Schema**

```json
{
  "nlp_engine": "string",
  "spacy_model": "string",
  "clinical_bert": {
    "enabled": "boolean",
    "default_model": "string",
    "available_models": ["string"],
    "cache_info": "object"
  }
}
```

### **Service Information**

Get basic service information and available endpoints.

```http
GET /
```

#### **Response Schema**

```json
{
  "service": "string",
  "version": "string",
  "status": "string",
  "endpoints": {
    "endpoint_name": "string"
  }
}
```

---

## 📊 **Response Formats**

### **Entity Object Structure**

All entities returned by the API follow this enhanced structure:

```json
{
  "id": "uuid",
  "text": "extracted text span",
  "start_char": "integer position",
  "end_char": "integer position", 
  "label": "entity type label",
  "source_ner_engine": "medcat|spacy_ner|llm_ner",
  "section_title": "document section|intelligent_fallback",
  "ner_confidence": "float 0.0-1.0",
  "primary_cui": "UMLS CUI or null",
  "backend_category": "DRUG|CONDITION|PROCEDURE|LAB_RESULT|etc",
  "type_ids": ["TUI codes"],
  "type_names": ["semantic type names"],
  "standard_codes": [
    {
      "code": "standard code",
      "vocabulary": "SNOMED|ICD10|RxNorm|etc",
      "display": "human readable"
    }
  ],
  "fhir_codeable_concept": {
    "coding": [
      {
        "system": "FHIR system URI",
        "code": "standard code",
        "display": "display name"
      }
    ],
    "text": "preferred name"
  },
  "negated": "boolean",
  "historical": "boolean", 
  "hypothetical": "boolean",
  "family_history": "boolean",
  "audit_trail": [
    {
      "source_service": "processing step",
      "timestamp": "ISO datetime",
      "confidence_score": "float|null",
      "details": "object"
    }
  ]
}
```

### **Intelligent Fallback Entity Indicators**

Entities detected by the intelligent fallback system have these distinguishing features:

- `"source_ner_engine": "spacy_ner"` - Marked as fallback source
- `"section_title": "intelligent_fallback"` - Special section identifier
- High confidence scores (0.8+) for known drug patterns
- Enhanced with terminology lookups when available

### **Clinical Categories**

The `backend_category` field uses these standardized categories:

| Category | Description | Examples |
|----------|-------------|----------|
| `DRUG` | Medications and pharmaceuticals | levothyroxine, amlodipine |
| `CONDITION` | Diseases and disorders | hypothyroidism, diabetes |
| `PROCEDURE` | Medical procedures | cardiac catheterization, surgery |
| `LAB_RESULT` | Laboratory tests and results | TSH, glucose, CBC |
| `VITAL_SIGN` | Vital signs and measurements | blood pressure, heart rate |
| `SYMPTOM` | Patient-reported symptoms | chest pain, fatigue |
| `ANATOMY` | Anatomical structures | heart, lungs, liver |
| `DEVICE` | Medical devices | pacemaker, stent |
| `OBSERVATION` | Clinical observations | physical exam findings |
| `IGNORE` | Non-clinical entities | patient, doctor, hospital |

---

## ⚠️ **Error Handling**

### **HTTP Status Codes**

| Code | Status | Description |
|------|---------|-------------|
| `200` | OK | Request processed successfully |
| `400` | Bad Request | Invalid request format or parameters |
| `422` | Unprocessable Entity | Valid JSON but invalid data |
| `429` | Too Many Requests | Rate limit exceeded |
| `500` | Internal Server Error | Server processing error |
| `503` | Service Unavailable | Service or dependencies unavailable |

### **Error Response Format**

```json
{
  "request_id": "string",
  "error": "error category",
  "detail": "detailed error message", 
  "errors": ["list of specific errors"],
  "warnings": ["list of warnings"],
  "timestamp": "ISO datetime"
}
```

### **Common Error Scenarios**

#### **400 Bad Request**
```json
{
  "request_id": "uuid",
  "error": "validation_error",
  "detail": "Text field is required",
  "errors": ["Missing required field: text"]
}
```

#### **422 Unprocessable Entity**
```json
{
  "request_id": "uuid", 
  "error": "processing_error",
  "detail": "Text exceeds maximum length",
  "errors": ["Text length 75000 exceeds limit of 50000"]
}
```

#### **503 Service Unavailable**
```json
{
  "request_id": "uuid",
  "error": "service_unavailable", 
  "detail": "NLP engine not available",
  "errors": ["MedCAT model failed to load"]
}
```

---

## 🚦 **Rate Limiting**

### **Default Limits**
- **60 requests per minute** per IP address
- **1000 requests per hour** per IP address
- **Large text processing** (>10k chars) limited to 10 requests per minute

### **Rate Limit Headers**
```http
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1640995200
```

### **Rate Limit Exceeded Response**
```json
{
  "error": "rate_limit_exceeded",
  "detail": "Too many requests",
  "retry_after": 60
}
```

---

## 📚 **Comprehensive Examples**

### **Example 1: Basic Drug Detection**

**Request:**
```bash
curl -X POST http://localhost:8002/process \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Patient takes levothyroxine 75 mcg daily for hypothyroidism",
    "enable_clinical_bert": true,
    "perform_structuring": false,
    "perform_summarization": false
  }'
```

**Response Highlights:**
```json
{
  "enriched_entities": [
    {
      "text": "levothyroxine",
      "source_ner_engine": "spacy_ner",
      "section_title": "intelligent_fallback",
      "ner_confidence": 0.95,
      "backend_category": "DRUG",
      "primary_cui": "C0040165"
    },
    {
      "text": "hypothyroidism", 
      "source_ner_engine": "medcat",
      "ner_confidence": 0.93,
      "backend_category": "CONDITION",
      "primary_cui": "C0020676"
    }
  ],
  "timing_metrics_ms": {
    "fallback_processing_ms": 234.5
  }
}
```

### **Example 2: Complex Clinical Note with Template**

**Request:**
```bash
curl -X POST http://localhost:8002/process \
  -H "Content-Type: application/json" \
  -d '{
    "text": "52-year-old female presents with complaints of fatigue and weight gain. History of hypothyroidism on levothyroxine 75 mcg daily. Also has hypertension on amlodipine 5 mg daily. Recent labs show TSH at 8.5. Plan is to increase levothyroxine to 88 mcg daily.",
    "clinical_bert_model": "clinical",
    "document_type": "progress_note", 
    "template_id": "soap-note-general",
    "perform_structuring": true,
    "perform_summarization": true
  }'
```

**Response Highlights:**
```json
{
  "enriched_entities": [
    {
      "text": "levothyroxine",
      "source_ner_engine": "spacy_ner",
      "section_title": "intelligent_fallback",
      "backend_category": "DRUG"
    },
    {
      "text": "amlodipine",
      "source_ner_engine": "medcat", 
      "backend_category": "DRUG"
    },
    {
      "text": "hypothyroidism",
      "source_ner_engine": "medcat",
      "backend_category": "CONDITION"
    },
    {
      "text": "TSH",
      "source_ner_engine": "medcat",
      "backend_category": "LAB_RESULT"
    }
  ],
  "fhir_payload": {
    "template_used": "soap-note-general",
    "placeholders_filled": 8
  },
  "summary_payload": {
    "summary_text": "Middle-aged female with inadequately controlled hypothyroidism requiring medication adjustment..."
  }
}
```

### **Example 3: ClinicalBERT Model Comparison**

**Request:**
```bash
curl -X POST http://localhost:8002/clinical-bert/compare-models \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Patient discharged home in stable condition after successful cardiac catheterization",
    "models": ["clinical", "discharge", "pubmed"]
  }'
```

**Response:**
```json
{
  "text": "Patient discharged home in stable condition...",
  "models_compared": [
    "emilyalsentzer/Bio_ClinicalBERT",
    "emilyalsentzer/Bio_Discharge_Summary_BERT", 
    "microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract-fulltext"
  ],
  "embeddings_comparison": {
    "emilyalsentzer/Bio_ClinicalBERT": {
      "magnitude": 12.45,
      "shape": [768]
    },
    "emilyalsentzer/Bio_Discharge_Summary_BERT": {
      "magnitude": 14.67,
      "shape": [768] 
    }
  },
  "similarity_matrix": {
    "clinical_vs_discharge": 0.89,
    "clinical_vs_pubmed": 0.76,
    "discharge_vs_pubmed": 0.72
  },
  "recommendation": "For this discharge summary, Bio_Discharge_Summary_BERT shows strongest representation"
}
```

### **Example 4: Debugging Fallback System**

**Request:**
```bash
curl -X POST http://localhost:8002/debug/test-fallback \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Patient prescribed atorvastatin 20mg for hyperlipidemia"
  }'
```

**Response:**
```json
{
  "text": "Patient prescribed atorvastatin 20mg for hyperlipidemia",
  "medcat_entities": [
    {"text": "Patient", "label": "T170"},
    {"text": "prescribed", "label": "T058"},
    {"text": "20mg", "label": "T081"}
  ],
  "spacy_entities": [
    {"text": "Patient", "label": "ENTITY", "start": 0, "end": 7},
    {"text": "atorvastatin", "label": "ENTITY", "start": 18, "end": 30}, 
    {"text": "hyperlipidemia", "label": "ENTITY", "start": 39, "end": 53}
  ],
  "fallback_entities": [
    {"text": "atorvastatin", "label": "ENTITY", "confidence": 0.95},
    {"text": "hyperlipidemia", "label": "ENTITY", "confidence": 0.87}
  ],
  "check_logs": "See logs for detailed debug info"
}
```

---

## 🔧 **Advanced Configuration**

### **Request Headers**

| Header | Description | Example |
|--------|-------------|---------|
| `Content-Type` | Request content type | `application/json` |
| `Accept` | Response format | `application/json` |
| `X-Request-ID` | Custom request tracking | `uuid-string` |
| `User-Agent` | Client identification | `MyApp/1.0.0` |

### **Query Parameters**

Some endpoints support query parameters for additional configuration:

#### **Process Endpoint Query Params**
```http
POST /process?debug=true&verbose=true
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `debug` | boolean | Enable detailed debug logging |
| `verbose` | boolean | Include additional metadata in response |
| `timeout` | integer | Request timeout in seconds (max 300) |

#### **ClinicalBERT Cache Management**
```http
DELETE /clinical-bert/cache?model_name=discharge&force=true
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `model_name` | string | Specific model to clear from cache |
| `force` | boolean | Force cache clear even if model is in use |

---

## 📊 **Performance Optimization**

### **Request Size Limits**

| Parameter | Limit | Notes |
|-----------|-------|-------|
| Request body | 10MB | Total request size |
| Text length | 50,000 chars | Clinical text content |
| Batch size | 10 texts | For future batch processing |

### **Response Time Expectations**

| Configuration | Expected Response Time |
|---------------|----------------------|
| MedCAT only | 2-8 seconds |
| + Intelligent Fallback | 3-9 seconds |
| + ClinicalBERT | 8-15 seconds |
| + Full Pipeline | 10-20 seconds |

### **Optimization Tips**

#### **For Speed**
```json
{
  "enable_clinical_bert": false,
  "perform_summarization": false,
  "perform_structuring": false,
  "use_llm_for_gap_filling": false
}
```

#### **For Accuracy**
```json
{
  "enable_clinical_bert": true,
  "clinical_bert_model": "clinical",
  "perform_structuring": true,
  "document_type": "progress_note"
}
```

---

## 🛡️ **Security Considerations**

### **Data Privacy**
- Clinical text is processed in-memory only
- No persistent storage of PHI
- Configurable logging levels to exclude sensitive data
- Memory cleanup after processing

### **Input Validation**
- Text length limits enforced
- JSON schema validation
- SQL injection prevention
- XSS protection for text fields

### **Network Security**
- CORS configuration for cross-origin requests
- HTTPS support in production
- Rate limiting to prevent abuse
- Request size limits

---

## 🧪 **Testing & Validation**

### **Unit Testing Endpoints**

For development and testing environments, additional endpoints are available:

#### **Test Pipeline Components**
```http
POST /test/medcat-only
POST /test/spacy-only  
POST /test/fallback-only
POST /test/clinical-bert-only
```

#### **Validation Endpoints**
```http
POST /validate/clinical-text
POST /validate/fhir-output
POST /validate/entity-codes
```

### **Load Testing**

The API supports concurrent requests. Recommended load testing approach:

```bash
# Gradual load increase
for concurrent in 1 5 10 20; do
  echo "Testing with $concurrent concurrent requests"
  for i in $(seq 1 $concurrent); do
    curl -X POST http://localhost:8002/process \
      -d '{"text": "Patient takes levothyroxine daily"}' &
  done
  wait
done
```

---

## 📖 **SDK & Client Libraries**

### **Python SDK**
```python
from nexuscare_ai import ClinicalNLPClient

client = ClinicalNLPClient(base_url="http://localhost:8002")

result = client.process_text(
    text="Patient takes levothyroxine daily",  
    enable_clinical_bert=True,
    clinical_bert_model="clinical"
)

for entity in result.entities:
    print(f"Found: {entity.text} -> {entity.backend_category}")
```

### **JavaScript SDK**  
```javascript
import { ClinicalNLPClient } from '@nexuscare/ai-client';

const client = new ClinicalNLPClient({
  baseUrl: 'http://localhost:8002'
});

const result = await client.processText({
  text: 'Patient takes levothyroxine daily',
  enableClinicalBert: true,
  clinicalBertModel: 'clinical'
});

result.entities.forEach(entity => {
  console.log(`Found: ${entity.text} -> ${entity.backendCategory}`);
});
```

### **cURL Examples Collection**

Download our comprehensive cURL examples:
- [Basic Processing Examples](examples/basic-processing.sh)
- [ClinicalBERT Examples](examples/clinical-bert.sh)  
- [Debug Examples](examples/debugging.sh)
- [Load Testing Examples](examples/load-testing.sh)

---

## 🔄 **Webhooks (Future)**

Future versions will support webhook notifications for long-running processing:

```json
{
  "webhook_url": "https://your-app.com/webhook/clinical-processing",
  "events": ["processing.completed", "processing.failed"],
  "secret": "your-webhook-secret"
}
```

---

## 📋 **Changelog**

### **Version 1.0.0** (May 2025)
- ✅ **Added**: Intelligent Fallback System
- ✅ **Added**: Dynamic ClinicalBERT model selection
- ✅ **Added**: Enhanced entity confidence scoring
- ✅ **Added**: Comprehensive debug endpoints
- ✅ **Fixed**: MedCAT 1.16 similarity score issues
- ✅ **Improved**: Performance optimization
- ✅ **Enhanced**: Error handling and monitoring

### **Version 0.9.0** (March 2025)
- Added MedCAT 1.16 integration
- Added ClinicalBERT support
- Added FHIR template mapping
- Added Knowledge Service integration

---

## 🆘 **Support & Resources**

### **Documentation**
- **[Complete README](README.md)** - Full setup and configuration guide
- **[Performance Tuning Guide](docs/performance-tuning.md)** - Optimization strategies
- **[Troubleshooting Guide](docs/troubleshooting.md)** - Common issues and solutions

### **Community**
- **GitHub Issues**: Bug reports and feature requests
- **Discussions**: Technical questions and use cases
- **Discord**: Real-time community support

### **Enterprise Support**
- **Email**: api-support@agilimed.com
- **SLA**: 24/7 support for enterprise customers
- **Professional Services**: Custom integration assistance

---

## 📞 **Contact Information**

**Technical Support**: api-support@agilimed.com  
**Sales & Partnerships**: partnerships@agilimed.com  
**General Inquiries**: info@agilimed.com

**Documentation Issues**: docs@agilimed.com  
**Security Reports**: security@agilimed.com

---

<div align="center">

**API Version**: 1.0.0 | **Last Updated**: May 2025  
**Built with ❤️ by the [Agilimed](https://agilimed.com) Team**

*Empowering Healthcare Through Intelligent Clinical NLP APIs*

</div>