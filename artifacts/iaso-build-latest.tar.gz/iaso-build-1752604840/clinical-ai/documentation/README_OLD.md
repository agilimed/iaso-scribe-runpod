# Nexus Care AI Backend

A sophisticated clinical Natural Language Processing (NLP) backend service that processes medical text to extract, categorize, and structure clinical information using advanced NLP techniques and medical terminology services.

## Problem Statement

Healthcare providers need to efficiently process and structure clinical notes and medical text to:
- Extract meaningful clinical entities (conditions, medications, procedures, etc.)
- Detect temporal expressions and relationships
- Identify contextual modifiers (negation, historical references, family history)
- Map extracted terms to standard medical vocabularies
- Generate structured FHIR-compliant outputs for integration with healthcare systems

## Key Features

- Advanced Clinical Entity Detection using MedCAT and MedSpaCy
- Temporal Expression Processing with SUTime
- Context Analysis (negation, historical, hypothetical, family history)
- Medical Terminology Mapping and Enrichment
- Section Detection and Text Organization
- FHIR QuestionnaireResponse Generation
- Spell Checking and Text Normalization
- Asynchronous Processing Support

## Architecture

### Core Services
1. **NLP Processing Service**
   - Entity Detection and Classification
   - Context Analysis
   - Section Detection
   - Temporal Processing

2. **Knowledge Service**
   - Terminology Mapping
   - Code System Integration
   - Concept Enrichment

3. **Template Service**
   - FHIR Template Management
   - Response Structure Definition

### External Service Integration
- Terminology Service
- Template Service
- PostgreSQL Database
- MeiliSearch for Fast Text Search

## Detailed Service Description

### 1. NLP Processing Service
The core NLP service responsible for processing clinical text and extracting structured information.

**Key Functions:**
- Entity Detection using configurable NER engines (MedCAT/SpaCy)
- Context Analysis (negation, historical, hypothetical)
- Section Detection and Text Organization
- Temporal Expression Processing with SUTime

**Required Environment Variables:**
```
# NLP Engine Configuration
SPACY_MODEL=en_core_web_md
NER_ENGINE=medcat  # or spacy
MEDCAT_MODEL_PACK_DIR=./medcat_model_pack/

# Temporal Processing
SUTIME_ENABLED=true
SUTIME_MAX_CHARS=2500

# Optional Features
PYRUSH_AVAILABLE=true  # For sentence segmentation
```

**Dependencies:**
- MedCAT model pack in specified directory
- Stanford CoreNLP installation for temporal processing
- SpaCy model downloaded and installed

### 2. Knowledge Service
Manages medical terminology, concept mapping, and knowledge enrichment.

**Key Functions:**
- Maps extracted entities to standard medical terminologies
- Provides concept enrichment with additional metadata
- Manages code system integration
- Handles terminology search and lookup

**Required Environment Variables:**
```
# Knowledge Service Database
PG_HOST_SRC=localhost
PG_PORT=5432
POSTGRES_DB=knowledge_db
POSTGRES_USER=db_user
POSTGRES_PASSWORD=db_password

# Terminology Service
TERMINOLOGY_SERVICE_URL=http://terminology-service:8080
TERM_SVC_SEARCH_URL=${TERMINOLOGY_SERVICE_URL}/search
```

**Dependencies:**
- PostgreSQL database with medical terminology data
- Running terminology service instance

### 3. Template Service
Manages FHIR templates and structures responses according to healthcare standards.

**Key Functions:**
- FHIR Template Management
- QuestionnaireResponse Generation
- Response Structure Validation
- Template-based Output Formatting

**Required Environment Variables:**
```
# Template Service Configuration
TEMPLATE_SERVICE_URL=http://template-service:8080
```

**Dependencies:**
- Running template service instance
- FHIR templates stored in the system

### 4. Search Service (MeiliSearch)
Provides fast text search capabilities for medical terminology and concepts.

**Key Functions:**
- Fast concept search
- Terminology lookup
- Synonym matching
- Fuzzy search support

**Required Environment Variables:**
```
# MeiliSearch Configuration
MEILISEARCH_HOST=http://localhost:7700
MEILISEARCH_MASTER_KEY=your_master_key
MEILISEARCH_INDEX_NAME=concepts
LOAD_BATCH_SIZE=2000
```

**Dependencies:**
- Running MeiliSearch instance
- Indexed medical terminology data

### Additional Infrastructure Requirements

**PostgreSQL Database:**
- Stores terminology mappings, configurations, and operational data
- Required for both Knowledge Service and core operations

**Configuration:**
```
# Database Configuration
PG_HOST_SRC=localhost
PG_PORT=5432
POSTGRES_DB=nexus_care_db
POSTGRES_USER=db_user
POSTGRES_PASSWORD=db_password
```

**Logging Configuration:**
```
# Logging Setup
LOG_LEVEL=INFO
LOG_FORMAT=%(asctime)s - %(name)s - %(levelname)s - %(message)s
```

## Technologies Used

### Core Libraries
- FastAPI - Web Framework
- SpaCy - Base NLP Processing
- MedSpaCy - Clinical NLP Extensions
- MedCAT - Medical Concept Annotation
- SUTime - Temporal Expression Processing
- PyRuSH - Clinical Text Segmentation
- Pydantic - Data Validation
- httpx - Async HTTP Client

### Infrastructure
- PostgreSQL - Data Storage
- MeiliSearch - Fast Text Search Engine
- Stanford CoreNLP - Temporal Processing Backend
- Docker - Containerization

### Development Tools
- Python 3.x
- Java (for Stanford CoreNLP)
- Maven (for CoreNLP Dependencies)

## Setup and Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/nexus-care-ai-backend.git
cd nexus-care-ai-backend
```

2. Create and activate a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your configuration
```

5. Install Stanford CoreNLP (for temporal processing):
```bash
# Follow instructions in ai_processing/stanford-corenlp/README.md
```

6. Initialize the database:
```bash
# Run database initialization scripts
```

## Dependencies

### Python Dependencies
```
# Core Dependencies
fastapi>=0.68.0
uvicorn>=0.15.0
pydantic>=1.8.0
httpx>=0.23.0

# NLP Libraries
spacy>=3.4.0
medspacy>=0.2.0
medcat>=1.2.0
PyRuSH>=2.0.0

# Database and Search
psycopg2-binary>=2.9.0
meilisearch>=0.17.0

# Utilities
python-dotenv>=0.19.0
python-multipart>=0.0.5
pyjwt>=2.3.0
```

Install Python dependencies using:
```bash
pip install -r requirements.txt

# Install SpaCy model
python -m spacy download en_core_web_md
```

### Java Dependencies (for Stanford CoreNLP)
Required for temporal expression processing (SUTime):

```xml
<!-- Maven dependencies -->
<dependencies>
    <dependency>
        <groupId>edu.stanford.nlp</groupId>
        <artifactId>stanford-corenlp</artifactId>
        <version>4.0.0</version>
    </dependency>
    <dependency>
        <groupId>edu.stanford.nlp</groupId>
        <artifactId>stanford-corenlp</artifactId>
        <version>4.0.0</version>
        <classifier>models</classifier>
    </dependency>
</dependencies>
```

Install Stanford CoreNLP:
```bash
# Create Stanford CoreNLP directory
mkdir -p ai_processing/stanford-corenlp
cd ai_processing/stanford-corenlp

# Download and extract Stanford CoreNLP
wget https://nlp.stanford.edu/software/stanford-corenlp-4.0.0.zip
unzip stanford-corenlp-4.0.0.zip

# Download models
wget https://nlp.stanford.edu/software/stanford-corenlp-4.0.0-models.jar
```

### System Dependencies

1. **PostgreSQL**
```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install postgresql postgresql-contrib

# macOS with Homebrew
brew install postgresql
```

2. **MeiliSearch**
```bash
# macOS with Homebrew
brew install meilisearch

# Using Docker
docker run -d \
  --name meilisearch \
  -p 7700:7700 \
  -e MEILI_MASTER_KEY='your_master_key' \
  getmeili/meilisearch:latest
```

3. **Java Runtime (JRE) for Stanford CoreNLP**
```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install default-jre

# macOS with Homebrew
brew install java
```

4. **Maven (for building Stanford CoreNLP)**
```bash
# Ubuntu/Debian
sudo apt-get install maven

# macOS with Homebrew
brew install maven
```

### MedCAT Model Setup
1. Download the MedCAT model pack:
```bash
mkdir -p medcat_model_pack
cd medcat_model_pack
# Download your specific MedCAT model pack
# Example:
wget https://your-medcat-model-url/model.zip
unzip model.zip
```

### Database Initialization
```bash
# Create required databases
psql -U postgres -c "CREATE DATABASE nexus_care_db;"
psql -U postgres -c "CREATE DATABASE knowledge_db;"

# Run initialization scripts
python scripts/init_db.py
python scripts/load_terminology_to_meili.py
```

## Configuration

Key environment variables:
- `PG_HOST_SRC` - PostgreSQL host
- `PG_PORT` - PostgreSQL port
- `POSTGRES_DB` - Database name
- `POSTGRES_USER` - Database user
- `POSTGRES_PASSWORD` - Database password
- `TERMINOLOGY_SERVICE_URL` - URL for terminology service
- `TEMPLATE_SERVICE_URL` - URL for template service
- `SPACY_MODEL` - SpaCy model to use
- `NER_ENGINE` - NER engine choice (spacy/medcat)
- `MEDCAT_MODEL_PACK_DIR` - Directory for MedCAT models

## API Documentation

The API documentation is available at `/docs` when running the service (powered by FastAPI's automatic documentation).

## License

This project is licensed under the GNU General Public License v3.0 - see the LICENSE file for details.

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a new Pull Request

## Support

For support, please open an issue in the GitHub repository or contact the development team.