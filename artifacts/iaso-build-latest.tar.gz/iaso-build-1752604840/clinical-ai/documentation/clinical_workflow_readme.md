# NexusCare AI Clinical Workflow - Complete Example

This document demonstrates how the NexusCare AI backend services work together to process clinical text and provide comprehensive clinical intelligence through MedCAT entity extraction, Knowledge Service enrichment, Graph Database relationships, and Terminology Service lookups.

## 🏥 Real-World Clinical Scenario

Let me walk you through a complete example of how your NexusCare AI architecture would work in practice:

### 📝 Input Clinical Text:
```
"Patient presents with chest pain and dyspnea. ECG shows ST elevation. 
Administered aspirin 325mg and metoprolol. Patient has history of diabetes 
and hypertension. Recommend cardiac catheterization."
```

---

## 🔍 Step 1: MedCAT Processing

**MedCAT extracts entities:**
```json
{
  "entities": [
    {"text": "chest pain", "cui": "C0008031", "confidence": 0.95},
    {"text": "dyspnea", "cui": "C0013404", "confidence": 0.92},
    {"text": "ST elevation", "cui": "C0429028", "confidence": 0.88},
    {"text": "aspirin", "cui": "C0004057", "confidence": 0.96},
    {"text": "metoprolol", "cui": "C0025859", "confidence": 0.94},
    {"text": "diabetes", "cui": "C0011847", "confidence": 0.93},
    {"text": "hypertension", "cui": "C0020538", "confidence": 0.91},
    {"text": "cardiac catheterization", "cui": "C0018795", "confidence": 0.89}
  ]
}
```

---

## 🔗 Step 2: Knowledge Service Enrichment

For each CUI, your **Knowledge Service** queries the database:

### Example Query for "chest pain" (C0008031):
```sql
-- Get equivalent codes across vocabularies
SELECT concept_id, vocabulary_id, concept_code, concept_name
FROM clinical_vocab.concept 
WHERE concept_id IN (
    SELECT concept_id_2 FROM clinical_vocab.concept_relationship 
    WHERE concept_id_1 = (
        SELECT concept_id FROM clinical_vocab.concept 
        WHERE concept_code = 'C0008031' AND vocabulary_id = 'UMLS'
    )
    AND relationship_id = 'Maps to'
);
```

**Knowledge Service Response:**
```json
{
  "cui": "C0008031",
  "preferred_name": "Chest Pain",
  "equivalent_codes": {
    "SNOMEDCT_US": "29857009",
    "ICD10CM": "R06.00", 
    "ICD10PCS": null,
    "LOINC": "LA15152-2"
  },
  "semantic_types": ["T184"],
  "definitions": ["An unpleasant sensation characterized by physical discomfort..."]
}
```

---

## 📊 Step 3: Graph Database Relationship Queries

### 3A. Hierarchical Relationships
```cypher
// Neo4j query to find all parent conditions of chest pain
MATCH (chest_pain:Concept {cui: 'C0008031'})-[:IS_A*1..3]->(parent:Concept)
RETURN parent.cui, parent.name, parent.semantic_type
```

**Graph Response:**
```json
{
  "hierarchical_parents": [
    {"cui": "C0030193", "name": "Pain", "semantic_type": "T184"},
    {"cui": "C0683368", "name": "Symptoms", "semantic_type": "T184"},
    {"cui": "C1457887", "name": "Clinical Finding", "semantic_type": "T033"}
  ]
}
```

### 3B. Associated Conditions
```cypher
// Find conditions commonly associated with chest pain
MATCH (chest_pain:Concept {cui: 'C0008031'})-[:ASSOCIATED_WITH]-(related:Concept)
WHERE related.semantic_type IN ['T047', 'T046'] // Diseases & Pathologic Functions
RETURN related.cui, related.name, related.semantic_type
```

**Graph Response:**
```json
{
  "associated_conditions": [
    {"cui": "C0027051", "name": "Myocardial Infarction", "semantic_type": "T047"},
    {"cui": "C0002962", "name": "Angina Pectoris", "semantic_type": "T047"},
    {"cui": "C0034065", "name": "Pulmonary Embolism", "semantic_type": "T047"}
  ]
}
```

---

## 🔍 Step 4: Terminology Service Fast Lookups

### 4A. Drug Interaction Check:
```http
GET /terminology-service/drug-interactions?cui1=C0004057&cui2=C0025859
```

**Response:**
```json
{
  "drug1": {"cui": "C0004057", "name": "Aspirin"},
  "drug2": {"cui": "C0025859", "name": "Metoprolol"},  
  "interaction_level": "moderate",
  "description": "May increase hypotensive effects",
  "clinical_significance": "Monitor blood pressure"
}
```

### 4B. Contraindication Check:
```http
GET /terminology-service/contraindications?procedure=C0018795&conditions=C0011847,C0020538
```

**Response:**
```json
{
  "procedure": {"cui": "C0018795", "name": "Cardiac Catheterization"},
  "patient_conditions": [
    {"cui": "C0011847", "name": "Diabetes", "contraindication_level": "caution"},
    {"cui": "C0020538", "name": "Hypertension", "contraindication_level": "none"}
  ],
  "recommendations": ["Monitor glucose levels", "Ensure adequate hydration"]
}
```

---

## 🎯 Step 5: Clinical Intelligence Integration

### Template Service Population:
```json
{
  "template_id": "cardiac_assessment_v1",
  "populated_sections": {
    "chief_complaint": {
      "symptoms": ["Chest Pain", "Dyspnea"],
      "codes": {"ICD10": ["R06.00", "R06.02"]}
    },
    "medications_administered": {
      "drugs": [
        {"name": "Aspirin", "dose": "325mg", "rxnorm": "1191"},
        {"name": "Metoprolol", "rxnorm": "6918"}
      ]
    },
    "recommendations": {
      "procedures": ["Cardiac Catheterization"],
      "codes": {"CPT": ["93458"]}
    },
    "risk_factors": {
      "conditions": ["Diabetes Mellitus", "Hypertension"],
      "risk_score": "moderate-high"
    }
  }
}
```

---

## 💡 Real-World Clinical Value

### 🚨 Clinical Decision Support:
```json
{
  "alerts": [
    {
      "type": "drug_interaction",
      "severity": "moderate", 
      "message": "Aspirin + Metoprolol may enhance hypotensive effects"
    },
    {
      "type": "differential_diagnosis",
      "message": "ST elevation + chest pain suggests STEMI - urgent intervention needed"
    }
  ],
  "recommendations": [
    {
      "type": "lab_order",
      "tests": ["Troponin I", "CK-MB"],
      "reason": "Rule out myocardial infarction"
    },
    {
      "type": "procedure",
      "name": "Emergency cardiac catheterization",
      "urgency": "stat"
    }
  ]
}
```

### 📊 Revenue Optimization:
```json
{
  "billing_optimization": {
    "primary_diagnosis": {"code": "I21.9", "description": "STEMI", "value": "$15,000"},
    "secondary_diagnoses": [
      {"code": "E11.9", "description": "Type 2 DM", "value": "$2,500"},
      {"code": "I10", "description": "Hypertension", "value": "$1,200"}
    ],
    "procedures": [
      {"code": "93458", "description": "Cardiac cath", "value": "$8,500"}
    ],
    "total_potential_revenue": "$27,200"
  }
}
```

---

## 🏗️ Architecture Flow Summary

```
Clinical Text → MedCAT → Knowledge Service → Graph DB + Terminology Service → Clinical Intelligence

"chest pain" → C0008031 → SNOMED:29857009 → Related:MI,Angina → Decision Support
            → Confidence  → ICD10:R06.00   → Parents:Pain   → Revenue Capture
            → Context     → RxNorm codes   → Drug interactions → Template Population
```

## 🔧 Service Interactions

### AI Processing Service
- **Input**: Raw clinical text
- **Processing**: MedCAT entity recognition and linking
- **Output**: Structured entities with CUIs and confidence scores
- **Integration**: Sends results to Knowledge Service for enrichment

### Knowledge Service
- **Input**: CUIs from AI Processing Service
- **Processing**: Database queries for equivalent codes, definitions, semantic types
- **Output**: Enriched concept information across vocabularies
- **Integration**: Works with Graph DB for relationship queries

### Graph Database
- **Input**: CUIs for relationship traversal
- **Processing**: Hierarchical and associative relationship queries
- **Output**: Parent/child relationships, associated conditions, clinical pathways
- **Integration**: Provides relationship context to Terminology Service

### Terminology Service
- **Input**: Concept pairs for interaction/contraindication checking
- **Processing**: Fast pattern matching and rule-based lookups
- **Output**: Drug interactions, contraindications, clinical rules
- **Integration**: Feeds decision support algorithms

### Template Service
- **Input**: Structured concepts and relationships
- **Processing**: Maps to FHIR templates and clinical forms
- **Output**: Populated questionnaires, structured reports
- **Integration**: Creates final clinical intelligence output

## 🎯 Key Benefits

### Clinical Benefits
- **Comprehensive Entity Recognition**: Identifies all relevant medical concepts
- **Cross-Vocabulary Mapping**: Provides codes for billing, research, interoperability
- **Clinical Decision Support**: Real-time alerts and recommendations
- **Quality Assurance**: Ensures complete documentation and coding

### Technical Benefits
- **Modular Architecture**: Each service handles specific functionality
- **Scalability**: Services can be independently scaled based on demand
- **Maintainability**: Clear separation of concerns
- **Flexibility**: Easy to add new vocabularies, relationships, or rules

### Business Benefits
- **Revenue Optimization**: Ensures complete capture of billable diagnoses and procedures
- **Compliance**: Maintains accurate coding and documentation standards
- **Efficiency**: Reduces manual coding and documentation time
- **Risk Management**: Provides drug interaction and contraindication checking

## 🚀 Implementation Notes

### Data Flow
1. Clinical text enters through AI Processing Service
2. MedCAT extracts and links entities to CUIs
3. Knowledge Service enriches with cross-vocabulary codes
4. Graph DB provides hierarchical and associative relationships
5. Terminology Service adds interaction and contraindication data
6. Template Service structures output for clinical use

### Performance Considerations
- **Caching**: Frequently accessed concepts and relationships should be cached
- **Parallel Processing**: Services can process different aspects simultaneously
- **Database Optimization**: Proper indexing on CUIs, codes, and relationship tables
- **Load Balancing**: Distribute requests across service instances

### Quality Assurance
- **Confidence Thresholds**: Filter low-confidence entity extractions
- **Validation Rules**: Ensure data consistency across services
- **Monitoring**: Track service performance and accuracy metrics
- **Feedback Loops**: Continuous improvement based on clinical outcomes

This architecture gives you **comprehensive clinical intelligence** that goes far beyond what MedCAT alone could provide, while keeping each service focused on what it does best! 🎯
