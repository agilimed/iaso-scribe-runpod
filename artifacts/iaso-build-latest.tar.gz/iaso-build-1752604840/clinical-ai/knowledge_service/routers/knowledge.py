# knowledge_service/routers/knowledge.py
import logging
from typing import List, Optional

from fastapi import APIRouter, HTTPException, Query, Depends # Keep Depends for potential future use

# --- Use relative imports based on the current directory structure ---
from .. import crud
from .. import models
# ---------------------------------------------------------------------

logger = logging.getLogger(__name__)
router = APIRouter() # Create a router instance

# --- Knowledge API Endpoints ---

@router.get(
    "/concepts/{identifier}/codes",
    response_model=List[models.CodeEntry], # Use models. prefix
    summary="Get Equivalent Codes (SNOMED from Athena)",
    tags=["Knowledge Lookup"],
)
async def get_equivalent_codes_endpoint(identifier: str):
    """
    Retrieves equivalent codes for a given concept identifier (UMLS CUI or Athena ID).
    SNOMED codes are sourced from the Athena schema.
    CUI-to-SNOMED mapping is currently a TODO placeholder in the backend CRUD function.
    """
    try:
        # Basic input validation
        is_cui = identifier.startswith('C') and len(identifier) == 8
        is_numeric = identifier.isdigit()
        if not is_cui and not is_numeric:
             raise HTTPException(status_code=400, detail="Identifier format invalid. Must be CUI (Cxxxxxxx) or numeric Athena ID.")

        # Call CRUD function using the imported module name
        codes = crud.fetch_equivalent_codes(identifier=identifier)
        # Note: Further checks for empty results vs invalid ID might be needed depending on CRUD behavior
        return codes
    except HTTPException:
        raise # Reraise specific HTTP errors (like 400 from validation)
    except Exception as e:
        logger.error(f"API Error retrieving codes for {identifier}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal server error retrieving codes.")


@router.get(
    "/concepts/{identifier}/hierarchy",
    response_model=List[models.RelatedConcept], # Use models. prefix
    summary="Get Parent/Child Concepts",
    tags=["Knowledge Lookup"],
)
async def get_hierarchy_endpoint(
    identifier: str,
    direction: str = Query("parents", enum=["parents", "children"], description="Hierarchy direction."),
):
    """
    Retrieves direct parents or children for a concept identifier (UMLS CUI or Athena ID).
    """
    try:
        # Basic input validation
        is_cui = identifier.startswith('C') and len(identifier) == 8
        is_numeric = identifier.isdigit()
        if not is_cui and not is_numeric:
             raise HTTPException(status_code=400, detail="Identifier format invalid.")

        # Call CRUD function using the imported module name
        related = crud.fetch_hierarchy(identifier=identifier, direction=direction)
        return related
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"API Error retrieving hierarchy for {identifier}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal server error retrieving hierarchy.")


@router.get(
    "/relationships",
    response_model=List[models.RelationshipEntry], # Use models. prefix
    summary="Find Relationships Between Concepts",
    tags=["Knowledge Lookup"],
)
async def find_relationships_endpoint(
    identifier1: str = Query(..., description="First concept identifier (CUI or Athena ID)."),
    identifier2: str = Query(..., description="Second concept identifier (CUI or Athena ID)."),
):
    """
    Finds defined relationships between two specific concept identifiers
    in UMLS (MRREL) or Athena (concept_relationship).
    """
    try:
        # Add more input validation if needed (e.g., check format of both identifiers)

        # Call CRUD function using the imported module name
        relations = crud.find_direct_relationships(identifier1=identifier1, identifier2=identifier2)
        return relations
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"API Error retrieving relationships for {identifier1}/{identifier2}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal server error retrieving relationships.")