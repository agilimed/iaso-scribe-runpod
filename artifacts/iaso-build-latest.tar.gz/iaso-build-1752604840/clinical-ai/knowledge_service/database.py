# knowledge_service/database.py
import os
import sys
import logging
import psycopg2
import psycopg2.extras
from contextlib import contextmanager
from dotenv import load_dotenv, find_dotenv
from fastapi import HTTPException # To raise HTTP errors on connection fail

logger = logging.getLogger(__name__)

# --- Load Root .env File ---
logger.info("Knowledge Service: Loading environment configuration...")
env_path = find_dotenv(filename='.env', raise_error_if_not_found=False, usecwd=True)
if env_path:
    logger.info(f"Knowledge Service: Loading environment variables from: {env_path}")
    load_dotenv(dotenv_path=env_path, verbose=True, override=True)
else:
    logger.warning("Knowledge Service: Could not find root .env file.")

# --- Read Shared DB Credentials ---
DB_USER = os.getenv('POSTGRES_USER')
DB_PASSWORD = os.getenv('POSTGRES_PASSWORD')
DB_HOST = os.getenv('PG_HOST_SRC')
DB_PORT = os.getenv('PG_PORT')
DB_NAME = os.getenv('POSTGRES_DB')

# Check if all necessary PG variables were loaded
if not all([DB_USER, DB_PASSWORD, DB_HOST, DB_PORT, DB_NAME]):
    logger.critical("FATAL: Missing PostgreSQL connection details for Knowledge Service!")
    # In a real app you might exit or prevent service start
    DB_CONN_STRING = None
else:
    # Construct connection string (or individual params)
    DB_CONN_STRING = f"dbname='{DB_NAME}' user='{DB_USER}' host='{DB_HOST}' port='{DB_PORT}' password='{DB_PASSWORD}'"
    logger.info("Database connection string configured.")

# Simple connection reuse (NOT a real pool - replace in production)
_db_conn_ks = None

def get_db_connection_sync():
    """Gets a synchronous database connection (simple reuse)."""
    global _db_conn_ks
    if not DB_CONN_STRING:
        logger.error("Database connection string not available.")
        raise HTTPException(status_code=503, detail="Database service not configured.")

    try:
        # Check if connection is closed or None
        # conn.closed: 0=open, 1=closed, 2=really closed
        if _db_conn_ks is None or _db_conn_ks.closed != 0:
             logger.info(f"Connecting to PG for Knowledge Service...")
             _db_conn_ks = psycopg2.connect(DB_CONN_STRING)
             logger.info("PostgreSQL Connection Established.")
        # Simple check to see if connection is alive
        with _db_conn_ks.cursor() as cur:
             cur.execute("SELECT 1;")
        return _db_conn_ks
    except (psycopg2.OperationalError, psycopg2.InterfaceError) as e:
        logger.error(f"Database connection error: {e}", exc_info=True)
        _db_conn_ks = None # Reset on error
        raise HTTPException(status_code=503, detail="Database connection error.")
    except Exception as e:
         logger.error(f"Unexpected DB error: {e}", exc_info=True)
         _db_conn_ks = None
         raise HTTPException(status_code=500, detail="Internal database error.")


@contextmanager
def get_db_cursor(commit=False):
    """Context manager for acquiring and releasing a DB cursor."""
    conn = None
    cursor = None
    try:
        conn = get_db_connection_sync()
        # Use DictCursor to access rows like dictionaries
        cursor = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        logger.info(f"[get_db_cursor] Created cursor of type: {type(cursor)} with factory: {getattr(cursor, 'cursor_factory', None)}")
        yield cursor
        if commit:
            conn.commit()
            logger.debug("DB transaction committed.")
    except Exception:
        if conn:
            conn.rollback()
            logger.error("DB transaction rolled back due to error.")
        raise # Reraise the exception
    finally:
        if cursor:
            cursor.close()