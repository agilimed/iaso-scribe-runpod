# knowledge_service/main.py
import logging
import os # For reading port from environment if needed
import sys # For potential sys.exit on critical errors
from pathlib import Path

# Add the parent directory to Python path
parent_dir = str(Path(__file__).parent.parent)
if parent_dir not in sys.path:
    sys.path.append(parent_dir)

import uvicorn
from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from shared.security import setup_security, verify_token, limiter

# --- Absolute imports for local modules/packages ---
from knowledge_service.routers import knowledge as knowledge_router
from knowledge_service import database

# Setup basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger(__name__)

# --- FastAPI App Initialization ---

# Critical check: Ensure database was configured successfully during import
# The database module will log critical errors if config is missing
# Access the check via the imported database module object
db_configured = bool(database.DB_CONN_STRING or database.DATABASE_URL) # Check if connection string/URL was set
if not db_configured:
    logger.critical("Database configuration failed (check .env and database.py logs). Knowledge Service cannot start reliably.")
    # Force exit if DB connection is absolutely mandatory for the service to function
    sys.exit("Exiting: Database configuration failed.")

app = FastAPI(
    title="NexusCare Knowledge Service",
    description="Provides detailed terminology lookups (codes, hierarchy, relationships) from PostgreSQL.",
    version="0.1.1", # Incremented patch version
    # Add Open API tags metadata if desired
    openapi_tags=[
        {"name": "Knowledge Lookup", "description": "Endpoints for retrieving detailed concept information."},
        {"name": "Health", "description": "Service health check."},
    ]
)

# Apply comprehensive security middleware
setup_security(
    app,
    allowed_origins=["http://localhost:3000", "http://localhost:8080"],
    enable_auth=True,
    rate_limit="100/minute",
    trusted_hosts=["localhost", "knowledge-service", "*.nexuscare.ai"]
)

# Include the router defined in routers/knowledge.py using the alias
# All routes defined in that router will be available under /api/v1
app.include_router(knowledge_router.router, prefix="/api/v1")
logger.info("Knowledge router included with prefix /api/v1")


# --- Root Endpoint / Basic Health Check ---
@app.get("/health", tags=["Health"])
async def health_check():
    """
    Basic health check. Attempts a quick database connection test.
    """
    db_status = "unknown"
    # Use the get_db_cursor from the imported database module
    try:
        with database.get_db_cursor() as cursor:
            cursor.execute("SELECT 1;") # Simple query to check connection
            db_status = "ok"
        logger.debug("Health check DB connection successful.")
    except HTTPException as http_exc:
        # Propagate specific HTTP errors from get_db_cursor
        db_status = f"error (HTTP {http_exc.status_code})"
        logger.error(f"Health check DB connection failed: {http_exc.detail}")
    except Exception as e:
        db_status = "error"
        logger.error(f"Health check DB connection failed unexpectedly: {e}", exc_info=True)

    return {"status": "ok", "database_connection_status": db_status}


# --- Main execution block (for running directly if needed) ---
if __name__ == "__main__":
    # Read port from environment or default to 8004
    SERVICE_PORT = int(os.getenv("KNOWLEDGE_SERVICE_PORT", 8004))
    logger.info(f"Starting Knowledge Service directly using Uvicorn on port {SERVICE_PORT}...")
    # Use reload=False for direct run unless specifically debugging this file
    # Use host="0.0.0.0" to make it accessible outside of localhost if needed
    uvicorn.run("main:app", host="0.0.0.0", port=SERVICE_PORT, reload=False)