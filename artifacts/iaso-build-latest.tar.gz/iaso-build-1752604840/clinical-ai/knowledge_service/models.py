# knowledge_service/models.py
from pydantic import BaseModel, Field
from typing import List, Optional

class CodeEntry(BaseModel):
    vocabulary: str = Field(description="Source vocabulary ID/SAB (e.g., SNOMEDCT_US, ICD10CM, RxNorm)")
    code: str = Field(description="The concept code within the vocabulary.")
    name: Optional[str] = Field(None, description="The preferred name associated with this code in the source.")

class RelatedConcept(BaseModel):
    identifier: str = Field(description="The CUI or Athena ID of the related concept.")
    name: str = Field(description="The preferred name of the related concept.")
    vocabulary: str = Field(description="The primary vocabulary of the related concept.")

class RelationshipEntry(BaseModel):
    relationship_name: str = Field(description="Name or type of the relationship (e.g., 'Parent', 'Child', 'treats', 'Is a').")
    relationship_attribute: Optional[str] = Field(None, description="Specific attribute code for the relationship (e.g., UMLS RELA).")
    related_concept_id: str = Field(description="Identifier of the concept on the other side of the relationship.")
    related_concept_name: Optional[str] = Field(None, description="Name of the related concept.")
    source_vocabulary: str = Field(description="Vocabulary where the relationship is defined (e.g., UMLS MRREL, OMOP CCR).")