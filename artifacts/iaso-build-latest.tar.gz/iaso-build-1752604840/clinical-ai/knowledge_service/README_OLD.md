# NexusCare Knowledge Service

**Version:** 0.1.1

## Overview

The Knowledge Service is a dedicated interface for querying detailed clinical terminology information stored in the project's central PostgreSQL database. It provides deeper insights into concepts initially identified by other services (like the AI Processing Service via the Meilisearch-based Terminology Service).

## Key Features

1. **Equivalent Code Lookup**
   - Finds all known codes (SNOMED CT, ICD-9-CM, ICD-10-CM, RxNorm, LOINC, etc.)
   - Maps between UMLS CUIs and Athena Concept IDs
   - Provides standardized names and codes across vocabularies

2. **Hierarchical Relationships**
   - Finds direct parents or children of concepts
   - Supports both UMLS MRREL and OMOP Concept Relationship hierarchies
   - Provides 'Is a' relationships for concept classification

3. **Concept-to-Concept Relationships**
   - Identifies defined relationships between concepts
   - Supports UMLS MRREL and OMOP Concept Relationship data
   - Includes relationship attributes and types

## Dependencies

### Core Dependencies
- Python 3.10+
- FastAPI
- Uvicorn
- PostgreSQL (psycopg2-binary)
- Python-dotenv
- Pydantic

## Configuration

The service requires the following environment variables:

```env
# Service Configuration
KNOWLEDGE_SERVICE_PORT=8004

# Database Configuration
POSTGRES_USER=your_user
POSTGRES_PASSWORD=your_password
PG_HOST_SRC=localhost
PG_PORT=5432
POSTGRES_DB=your_db
```

## Setup and Installation

1. **Prerequisites**
   - Python 3.10 or higher
   - PostgreSQL server with required schemas:
     - `clinical_consolidated`
     - `clinical_vocab`
     - `clinical_umls`

2. **Installation**
   ```bash
   # Create and activate virtual environment
   python -m venv venv
   source venv/bin/activate  # or `venv\Scripts\activate` on Windows

   # Install dependencies
   pip install -r requirements.txt
   ```

3. **Running the Service**
   ```bash
   uvicorn main:app --host 0.0.0.0 --port 8004
   ```

## API Endpoints

All endpoints are prefixed with `/api/v1`.

### Health Check
- `GET /health`
  - Checks service status and database connection
  - Returns detailed connection status

### Knowledge Lookup
- `GET /concepts/{identifier}/codes`
  - Retrieves equivalent codes for a concept
  - Supports both UMLS CUIs and Athena IDs
  - Returns standardized codes and names

- `GET /concepts/{identifier}/hierarchy`
  - Gets parent/child concepts
  - Supports direction parameter (parents/children)
  - Returns related concepts with names

- `GET /relationships`
  - Finds relationships between two concepts
  - Supports both UMLS and OMOP relationships
  - Returns detailed relationship information

## Database Schema

The service interacts with three main schemas:

1. **clinical_umls**
   - Contains UMLS Metathesaurus data
   - Includes MRCONSO, MRREL, MRSTY tables

2. **clinical_vocab**
   - Contains OMOP/Athena vocabulary data
   - Includes concept and concept_relationship tables

3. **clinical_consolidated**
   - Contains consolidated clinical data
   - Used for cross-vocabulary mappings

## Integration

The service integrates with other NexusCare components:

1. **AI Processing Service**
   - Provides detailed concept information
   - Enriches identified entities
   - Supports entity linking

2. **Terminology Service**
   - Complements fast search with detailed lookups
   - Provides hierarchical and relationship data
   - Supports concept mapping

## Performance Considerations

- Efficient database queries
- Connection pooling
- Caching strategies
- Optimized joins and indexes

## Error Handling

- Comprehensive error logging
- HTTP status codes for different error types
- Detailed error messages
- Database connection error handling

## Security

- CORS configuration
- Environment variable based configuration
- Database credential management
- Input validation

## Monitoring

- Health check endpoint
- Database connection monitoring
- Query performance tracking
- Error logging

## Future Enhancements

1. **Planned Features**
   - Implement robust CUI-to-Athena/SNOMED mapping
   - Add relationship type filtering
   - Implement deeper hierarchy traversal
   - Add endpoints for definitions and attributes

2. **Technical Improvements**
   - Implement proper database connection pooling
   - Convert to async database operations
   - Add authentication/authorization
   - Add comprehensive testing

## Contributing

Please refer to the main project documentation for contribution guidelines.

## License

This service is part of the NexusCare AI backend and is subject to the project's license terms.