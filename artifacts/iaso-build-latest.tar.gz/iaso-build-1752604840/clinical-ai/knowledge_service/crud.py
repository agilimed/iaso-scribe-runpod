# knowledge_service/crud.py
import logging
from typing import List, Dict, Optional

# Use absolute imports
from knowledge_service import database
from knowledge_service import models
import psycopg2 # Import specifically for error handling if needed

logger = logging.getLogger(__name__)

def fetch_equivalent_codes(identifier: str) -> List[models.CodeEntry]:
    print(f"FETCH_EQUIVALENT_CODES CALLED with identifier: {identifier}")
    codes = []
    try:
        with database.get_db_cursor() as cursor:
            if identifier.startswith('C') and len(identifier) == 8:
                # UMLS CUI
                cursor.execute("""
                    SELECT m.cui AS id,
                           'UMLS' AS source,
                           m.str AS name,
                           m.code,
                           m.sab AS vocabulary,
                           NULL AS domain,
                           NULL AS concept_class,
                           st.sty AS semantic_type,
                           CASE WHEN m.ts = 'P' THEN 'S' ELSE NULL END AS is_standard
                    FROM clinical_umls.mrconso m
                    JOIN clinical_umls.mrsty st ON m.cui = st.cui
                    WHERE m.lat = 'ENG' AND m.cui = %s
                """, (identifier,))
            else:
                # Athena/OMOP
                cursor.execute("""
                    SELECT (c.concept_id)::text AS id,
                           'ATHENA' AS source,
                           c.concept_name AS name,
                           c.concept_code AS code,
                           v.vocabulary_id AS vocabulary,
                           d.domain_name AS domain,
                           cc.concept_class_name AS concept_class,
                           NULL AS semantic_type,
                           c.standard_concept AS is_standard
                    FROM clinical_vocab.concept c
                    JOIN clinical_vocab.vocabulary v ON c.vocabulary_id = v.vocabulary_id
                    JOIN clinical_vocab.domain d ON c.domain_id = d.domain_id
                    JOIN clinical_vocab.concept_class cc ON c.concept_class_id = cc.concept_class_id
                    WHERE c.invalid_reason IS NULL AND c.concept_id = %s
                """, (identifier,))
            rows = cursor.fetchall()
            for row in rows:
                codes.append(models.CodeEntry(
                    vocabulary=row['vocabulary'],
                    code=row['code'],
                    name=row['name']
                ))
    except psycopg2.Error as db_err:
        logger.error(f"Database error fetching codes for {identifier}: {db_err}", exc_info=True)
        raise
    except Exception as e:
        logger.error(f"Unexpected error fetching codes for {identifier}: {e}", exc_info=True)
        raise

    logger.info(f"Found {len(codes)} codes for identifier: {identifier}")
    return codes


def fetch_hierarchy(identifier: str, direction: str) -> List[models.RelatedConcept]:
    """Fetches direct parent or child concepts from Postgres."""
    related_concepts = []
    is_cui = identifier.startswith('C') and len(identifier) == 8

    try:
        with database.get_db_cursor() as cursor:
            if is_cui:
                # --- UMLS MRREL ---
                target_col, source_col = ("cui1", "cui2") if direction == "parents" else ("cui2", "cui1")
                # Use standard PAR/CHD for direct hierarchy, RB/RN for broader/narrower semantic links
                # Let's stick to PAR/CHD for 'hierarchy' endpoint for now
                rel_filter = "PAR" if direction == "parents" else "CHD"
                logger.debug(f"Querying MRREL for {direction} of CUI {identifier} (rel={rel_filter})...")
                sql = f"""
                    SELECT DISTINCT
                        r.{target_col} AS related_id,
                        c.str AS related_name,
                        c.sab AS related_vocab
                    FROM clinical_umls.mrrel r
                    JOIN clinical_umls.mrconso c ON r.{target_col} = c.cui
                    WHERE r.{source_col} = %s
                      AND r.rel = %s       -- Find direct parents/children
                      AND c.lat = 'ENG'    -- Get English name
                      AND c.ispref = 'Y' -- Get preferred name for the related concept
                    ORDER BY related_name;
                """
                cursor.execute(sql, (identifier, rel_filter))
                for row in cursor.fetchall():
                    # Ensure data maps correctly to Pydantic model
                    related_concepts.append(models.RelatedConcept(
                        identifier=row['related_id'],
                        name=row['related_name'],
                        vocabulary=row['related_vocab']
                    ))
            else:
                # --- ATHENA concept_relationship ---
                try:
                    athena_id = int(identifier)
                    # Using concept_relationship for direct 'Is a' links
                    target_col, source_col = ("concept_id_1", "concept_id_2") if direction == "parents" else ("concept_id_2", "concept_id_1")
                    rel_id = 'Is a' # OMOP standard relationship for hierarchy
                    logger.debug(f"Querying Athena relationship for {direction} of ID {athena_id} (rel={rel_id})...")
                    sql = f"""
                        SELECT DISTINCT
                            r.{target_col}::text AS related_id,
                            c.concept_name AS related_name,
                            c.vocabulary_id AS related_vocab
                        FROM clinical_vocab.concept_relationship r
                        JOIN clinical_vocab.concept c ON r.{target_col} = c.concept_id
                        WHERE r.{source_col} = %s
                          AND r.relationship_id = %s
                          AND r.invalid_reason IS NULL
                          AND c.invalid_reason IS NULL
                        ORDER BY related_name;
                    """
                    cursor.execute(sql, (athena_id, rel_id))
                    for row in cursor.fetchall():
                        related_concepts.append(models.RelatedConcept(
                            identifier=row['related_id'],
                            name=row['related_name'],
                            vocabulary=row['related_vocab']
                        ))
                except ValueError:
                     logger.error(f"Invalid numeric identifier for Athena hierarchy lookup: {identifier}")
                     raise ValueError("Identifier format invalid.") # Raise error for endpoint
    except psycopg2.Error as db_err:
        logger.error(f"Database error fetching hierarchy for {identifier}: {db_err}", exc_info=True)
        raise
    except Exception as e:
        logger.error(f"Unexpected error fetching hierarchy for {identifier}: {e}", exc_info=True)
        raise

    logger.info(f"Found {len(related_concepts)} {direction} for identifier: {identifier}")
    return related_concepts


def find_direct_relationships(identifier1: str, identifier2: str) -> List[models.RelationshipEntry]:
    """Finds direct relationships between two concepts in Postgres."""
    relationships = []
    is_cui1 = identifier1.startswith('C') and len(identifier1) == 8
    is_cui2 = identifier2.startswith('C') and len(identifier2) == 8

    try:
        with database.get_db_cursor() as cursor:
            # Query UMLS MRREL
            if is_cui1 and is_cui2:
                logger.debug(f"Querying MRREL between CUIs {identifier1} and {identifier2}...")
                cursor.execute("""
                    SELECT rel, rela, sab, cui1, cui2
                    FROM clinical_umls.mrrel
                    WHERE (cui1 = %s AND cui2 = %s) OR (cui1 = %s AND cui2 = %s)
                    ORDER BY sab, rel, rela;
                """, (identifier1, identifier2, identifier2, identifier1))
                for row in cursor.fetchall():
                    related_id = row['cui2'] if row['cui1'] == identifier1 else row['cui1']
                    relationships.append(models.RelationshipEntry(
                        relationship_name=row['rel'],
                        relationship_attribute=row['rela'],
                        related_concept_id=related_id,
                        source_vocabulary=f"UMLS MRREL ({row['sab']})" # Include source SAB
                    ))

            # Query ATHENA concept_relationship
            try:
                athena_id1 = int(identifier1) if not is_cui1 else None
                athena_id2 = int(identifier2) if not is_cui2 else None
                if athena_id1 is not None and athena_id2 is not None:
                     logger.debug(f"Querying Athena relationship between IDs {athena_id1} and {athena_id2}...")
                     cursor.execute("""
                         SELECT relationship_id, concept_id_1, concept_id_2
                         FROM clinical_vocab.concept_relationship
                         WHERE ((concept_id_1 = %s AND concept_id_2 = %s) OR (concept_id_1 = %s AND concept_id_2 = %s))
                           AND invalid_reason IS NULL
                         ORDER BY relationship_id;
                     """, (athena_id1, athena_id2, athena_id2, athena_id1))
                     for row in cursor.fetchall():
                         related_id = str(row['concept_id_2']) if row['concept_id_1'] == athena_id1 else str(row['concept_id_1'])
                         relationships.append(models.RelationshipEntry(
                             relationship_name=row['relationship_id'], # OMOP Relationship ID
                             relationship_attribute=None,
                             related_concept_id=related_id,
                             source_vocabulary="OMOP CCR"
                         ))
            except ValueError: pass # Ignore if IDs aren't numeric for Athena

    except psycopg2.Error as db_err:
        logger.error(f"Database error fetching relationships for {identifier1}/{identifier2}: {db_err}", exc_info=True)
        raise
    except Exception as e:
        logger.error(f"Unexpected error fetching relationships for {identifier1}/{identifier2}: {e}", exc_info=True)
        raise

    logger.info(f"Found {len(relationships)} relationships between {identifier1} and {identifier2}")
    return relationships