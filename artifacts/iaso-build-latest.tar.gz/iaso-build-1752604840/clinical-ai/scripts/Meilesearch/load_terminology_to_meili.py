#!/usr/bin/env python3
"""
Load Terminology to MeiliSearch from UMLS PostgreSQL Database (and optionally Athena)

This script performs the following main functions:
1. Loads medical terminology concepts from two sources:
   - UMLS (Unified Medical Language System) database
   - Athena vocabulary database (optional)

2. For UMLS concepts, it:
   - Fetches concepts based on semantic types (TUIs)
   - Processes preferred names and synonyms
   - Includes semantic types, definitions, and source codes
   - Filters by preferred sources (SNOMED, RxNorm, etc.)

3. For Athena concepts, it:
   - Loads concepts from the clinical vocabulary schema
   - Maps to UMLS CUIs where possible
   - Includes domain and concept class information
   - Merges with existing UMLS concepts when possible

4. Indexes all concepts in MeiliSearch with:
   - Searchable fields (name, synonyms, definitions)
   - Filterable attributes (semantic types, sources)
   - Proper ranking rules for medical terminology
   - Typo tolerance for better search results

The script uses batch processing for efficiency and includes:
- Progress tracking with tqdm
- Comprehensive logging
- Error handling and recovery
- Configurable limits and filters
- Environment-based configuration

Usage:
    python load_terminology_to_meili.py [--index_name NAME] [--limit_concepts N] 
                                       [--skip_umls] [--skip_athena] 
                                       [--filter_semantic_types] 
                                       [--delete_existing_index]

Environment Variables Required:
    - PostgreSQL: PG_HOST_SRC, PG_PORT_SRC, POSTGRES_DB, POSTGRES_USER, POSTGRES_PASSWORD
    - MeiliSearch: MEILISEARCH_HOST, MEILISEARCH_API_KEY
    - Optional: LOAD_CONCEPT_LIMIT, LOAD_BATCH_SIZE_MEILI, LOAD_CUI_BATCH_SIZE_PG
"""

import os
import sys
import time
from datetime import timedelta
import logging
import psycopg2
import psycopg2.extras
from psycopg2.extras import RealDictCursor
import meilisearch
from meilisearch.index import Index as MeiliIndex
from dotenv import load_dotenv
from tqdm import tqdm
from pathlib import Path
import re
from collections import defaultdict
import json
import pandas as pd
import numpy as np
import csv # Not strictly needed if not writing an intermediate CSV for Meili
import argparse

# --- Basic Logging Setup ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("load_to_meili_from_umls_v2.log") # New log file name
    ]
)
logger = logging.getLogger("meili_loader_umls_v2")

# --- Configuration ---
logger.info("Loading environment configuration...")
load_dotenv()

# PostgreSQL Connection Details
# These are used to connect to the database containing UMLS and Athena data
PG_HOST = os.getenv('PG_HOST_SRC', 'localhost')
PG_PORT = int(os.getenv('PG_PORT_SRC', 5434))
PG_DBNAME = os.getenv('POSTGRES_DB')
PG_USER = os.getenv('POSTGRES_USER')
PG_PASSWORD = os.getenv('POSTGRES_PASSWORD')

# Meilisearch Connection Details
# These are used to connect to the MeiliSearch instance where terminology will be indexed
MEILI_HOST = os.getenv('MEILISEARCH_HOST', 'http://localhost:7700')
MEILI_API_KEY = os.getenv('MEILISEARCH_API_KEY')

# Script Parameters
# These control the behavior of the loading process
MEILI_INDEX_NAME = os.getenv('MEILISEARCH_INDEX_NAME_UMLS', "concepts_umls_v2") # New default
BATCH_SIZE_MEILI = int(os.getenv('LOAD_BATCH_SIZE_MEILI', 1000))  # Number of documents to send to MeiliSearch at once
CUI_PROCESSING_BATCH_SIZE_PG = int(os.getenv('LOAD_CUI_BATCH_SIZE_PG', 5000))  # Number of CUIs to process from PostgreSQL at once
CONCEPT_LIMIT = os.getenv('LOAD_CONCEPT_LIMIT')  # Optional limit on total number of concepts to process
if CONCEPT_LIMIT:
    try: CONCEPT_LIMIT = int(CONCEPT_LIMIT); logger.info(f"Limiting to approx {CONCEPT_LIMIT} total concepts.")
    except ValueError: logger.warning(f"Invalid LOAD_CONCEPT_LIMIT. Processing all."); CONCEPT_LIMIT = None

PG_CURSOR_ITERSIZE = CUI_PROCESSING_BATCH_SIZE_PG * 2

# UMLS Data Configuration
# List of semantic type identifiers (TUIs) to include in the terminology
# These represent different categories of medical concepts (e.g., T019 for Anatomical Structure)
SEMANTIC_GROUPS_TUIs_FILTER = [
    'T019', 'T020', 'T037', 'T046', 'T047', 'T048', 'T049', 'T050',
    'T190', 'T191', 'T033', 'T034', 'T184', 'T060', 'T061', 'T074',
    'T109', 'T116', 'T121', 'T122', 'T123', 'T125', 'T129', 'T130',
    'T195', 'T196', 'T197', 'T200', 'T201'
]

# Preferred sources for concept names in order of preference
# These are used to select the best name for each concept
PREFERRED_SOURCES_FOR_NAME = [
    'SNOMEDCT_US', 'RXNORM', 'LNC', 'MSH', 'NCI', 'ICD10CM', 'CPT', 'HCPCS',
    'MTH',              # Good general fallback
    'HGNC',             # Gene Names
    'GO',               # Gene Ontology
    'HPO',              # Human Phenotype Ontology
    'OMIM',             # Genetic Disorders
    'DRUGBANK',         # Drug information
    'CHV',              # Consumer Health Vocab
    'ATC',              # Drug classification
    'MEDCIN',         # High term count, clinical relevance?
    'NCBI'            # Gene/protein names if primary display is desired
]

# All sources to include for synonyms
# This is a broader list than PREFERRED_SOURCES_FOR_NAME to include more variations
TARGET_SABS_FOR_SYNONYMS = list(set(
    PREFERRED_SOURCES_FOR_NAME + [
    'RCD', 'ICD10PCS', 'MTHSPL', 'FMA', 'NDDF', 'MDR', 'ICD10',
    'MTHICD9', 'ICD9CM', 'HL7V3.0', 'MEDLINEPLUS', 'CSP', 'VANDF', 'PDQ',
    # Other SABs from your list if they provide good English synonyms:
    # 'SNMI', 'MMSL', 'UWDA', 'ICPC2ICD10ENG', 'MMX', 'SNM', 'UMD',
    # 'AOD', 'ICPC2P', 'CCPSS', 'NOC', 'NIC', 'RCDAE', 'RCDSY', 'HCPT',
    # 'LCH_NW', 'NEU', 'DXP', 'MED-RT', 'PSY', 'LCH', 'CST', 'USP', 'HL7V2.5',
    # 'SPN', 'ALT', 'WHO', 'NANDA-I', 'COSTAR', 'JABL', 'CPM', 'ICD10AMAE',
    # 'PCDS', 'ICNP', 'MTHMST', 'ICF-CY', 'USPMG', 'CCS', 'ICF', 'DSM-5', 'BI',
    # 'SRC', 'ICD10AE', 'RCDSA', 'CVX', 'CDCREC', 'QMR', 'CDT', 'NUCCHCPT',
    # 'HCDT', 'ICPC', 'ICPC2EENG', 'AIR', 'OMS', 'PNDS', 'AOT', 'CCC', 'PPAC',
    # 'RAM', 'DDB', 'SOP', 'MTHICPC2ICD10AE', 'MVX', 'ULT', 'MCM',
    # 'MTHICPC2EAE', 'MTHCMSFRF'
    ]
))

# Athena Configuration
# Controls whether to load Athena vocabulary data and maps Athena vocab IDs to UMLS SABs
LOAD_ATHENA_DATA = os.getenv('LOAD_ATHENA_DATA', 'true').lower() == 'true'
ATHENA_VOCAB_MAP = {
    'SNOMED': 'SNOMEDCT_US',
    'RxNorm': 'RXNORM',
    'LOINC': 'LNC',
    'ICD10CM': 'ICD10CM',
    'ICD10': 'ICD10',
    'HCPCS': 'HCPCS',
    'CPT4': 'CPT', # Verify if CPT4 concept_count > 0 and if it maps to UMLS SAB 'CPT'
    'MeSH': 'MSH',
    'ICD10PCS': 'ICD10PCS',
    'NCI': 'NCI', # If Athena has 'NCI' vocabulary_id for NCI Thesaurus
    'RxNorm Extension': 'RXNORM', # Or MTHSPL? Needs checking if these codes are in RXNORM SAB or elsewhere
    # Add more mappings here e.g. 'HemOnc': 'NCI' or 'HemOnc_SAB_if_exists'
}

# --- Helper Functions ---
def get_postgres_connection():
    # ... (same as before) ...
    logger.info(f"Connecting to PostgreSQL: host={PG_HOST} port={PG_PORT} dbname={PG_DBNAME} user={PG_USER}")
    if not all([PG_DBNAME, PG_USER, PG_PASSWORD, PG_HOST, PG_PORT]):
        logger.error("Missing PostgreSQL connection details."); sys.exit(1)
    try:
        conn = psycopg2.connect(dbname=PG_DBNAME, user=PG_USER, password=PG_PASSWORD, host=PG_HOST, port=PG_PORT)
        conn.autocommit = False
        logger.info("Successfully connected to PostgreSQL.")
        return conn
    except psycopg2.OperationalError as e:
        logger.error(f"Error connecting to PostgreSQL: {e}", exc_info=True); sys.exit(1)

def my_simple_prepare_name(name_str: str, lower: bool = True, replace_hyphens_with_space: bool = True) -> str:
    # ... (same as before) ...
    if not isinstance(name_str, str): return str(name_str) if name_str is not None else ""
    if lower: name_str = name_str.lower()
    if replace_hyphens_with_space: name_str = name_str.replace('-', ' ')
    name_str = re.sub(r'\s+', ' ', name_str).strip()
    return name_str

def filter_term_for_meili(term_text): # Slightly less aggressive for search
    # ... (same as before) ...
    if term_text is None or len(term_text) < 2: return True
    if re.match(r'^[0-9]+(\.[0-9]+)?$', term_text) and len(term_text) > 4 : return True
    if re.match(r'^[^\w\s\'\-]+$', term_text): return True
    return False

def select_preferred_name_from_list(concept_names_list, preferred_sources_ordered):
    # ... (same as before) ...
    if not concept_names_list: return "Unknown Concept"
    df = pd.DataFrame(concept_names_list);
    if df.empty: return "Unknown Concept"
    df['sab_cat'] = pd.Categorical(df['sab'], categories=preferred_sources_ordered, ordered=True)
    df['sab_rank'] = df['sab_cat'].cat.codes.replace(-1, len(preferred_sources_ordered))
    tty_priority = {'PT':1,'PN':1,'FN':2,'SY':3,'IS':1,'IP':1,'MIN':1,'PIN':1,'SCD':2,'SBD':2,'MH':1,'NM':1,'EP':2,'AB':4}
    df['tty_rank'] = df['tty'].map(tty_priority).fillna(99)
    df['ispref_rank'] = df['ispref'].apply(lambda x: 0 if x == 'Y' else 1)
    df['ts_rank'] = df['ts'].apply(lambda x: 0 if x == 'P' else 1)
    df['stt_rank'] = df['stt'].apply(lambda x: 0 if x == 'PF' else 1)
    df['name_len_rank'] = -df['str'].astype(str).str.len()
    df_sorted = df.sort_values(by=['ispref_rank','ts_rank','stt_rank','sab_rank','tty_rank','name_len_rank','str'])
    return df_sorted.iloc[0]['str']

def fetch_all_relevant_cuis_for_meili(conn, semantic_type_tuis=None, limit=None):
    # ... (similar to CDB builder's, but uses TARGET_SABS_FOR_SYNONYMS) ...
    logger.info("Fetching all relevant UMLS CUIs for MeiliSearch index...")
    base_query = "SELECT DISTINCT c.cui FROM clinical_umls.mrconso c JOIN clinical_umls.mrsty s ON c.cui = s.cui WHERE c.lat = 'ENG' AND c.suppress != 'Y' AND s.tui IS NOT NULL AND s.tui <> '' AND c.sab = ANY(%s)"
    params = [list(TARGET_SABS_FOR_SYNONYMS)] # Use broader list for initial CUI selection
    if semantic_type_tuis:
        base_query += " AND s.tui = ANY(%s)"; params.append(list(semantic_type_tuis))
    base_query += " ORDER BY c.cui"
    if limit:
        try:
            limit_val = int(limit)
            if limit_val > 0: base_query += f" LIMIT {limit_val}"
        except ValueError: logger.warning(f"Invalid limit: {limit}. Ignored.")
    base_query += ";"
    try:
        with conn.cursor() as cursor: cursor.execute(base_query, tuple(params)); results = [r[0] for r in cursor.fetchall()]
        logger.info(f"Fetched {len(results)} relevant CUIs for MeiliSearch.")
        return results
    except Exception as e: logger.error(f"Error fetching CUIs for Meili: {e}", exc_info=True); raise

def fetch_umls_data_for_meili_batch(conn, cui_batch, semantic_type_tuis_filter=None):
    # ... (similar to CDB builder's fetch_data_for_cui_batch, but no MRREL) ...
    logger.debug(f"Fetching UMLS details for MeiliSearch batch of {len(cui_batch)} CUIs (First: {cui_batch[0] if cui_batch else 'N/A'})")
    data = {"names": defaultdict(list), "stys": defaultdict(list), "defs": defaultdict(list)}
    if not cui_batch: return data
    
    # Names
    sql_n = "SELECT cui, sab, code, str, tty, ispref, ts, stt FROM clinical_umls.mrconso WHERE cui = ANY(%s) AND lat = 'ENG' AND suppress != 'Y' AND sab = ANY(%s);"
    with conn.cursor(cursor_factory=RealDictCursor) as c: c.execute(sql_n, (cui_batch, TARGET_SABS_FOR_SYNONYMS)); rows = c.fetchall()
    for r_n in rows: data["names"][r_n['cui']].append(r_n)
    
    # STYs
    sql_s = "SELECT cui, tui, sty FROM clinical_umls.mrsty WHERE cui = ANY(%s)"
    p_s = [cui_batch]
    if semantic_type_tuis_filter: sql_s += " AND tui = ANY(%s)"; p_s.append(semantic_type_tuis_filter)
    with conn.cursor(cursor_factory=RealDictCursor) as c: c.execute(sql_s, tuple(p_s)); rows = c.fetchall()
    for r_s in rows: data["stys"][r_s['cui']].append(r_s)

    # DEFs
    sql_d = "SELECT cui, sab, def FROM clinical_umls.mrdef WHERE cui = ANY(%s) AND suppress != 'Y';"
    with conn.cursor(cursor_factory=RealDictCursor) as c: c.execute(sql_d, (cui_batch,)); rows = c.fetchall()
    for r_d in rows: data["defs"][r_d['cui']].append(r_d)
    return data

def map_athena_to_cui(conn, athena_code, athena_vocab_id):
    # ... (same as before) ...
    umls_sab = ATHENA_VOCAB_MAP.get(athena_vocab_id)
    if not umls_sab: return None
    sql = "SELECT cui FROM clinical_umls.mrconso WHERE code = %s AND sab = %s AND lat = 'ENG' AND suppress != 'Y' ORDER BY ispref DESC, ts DESC LIMIT 1;"
    try:
        with conn.cursor() as cursor:
            cursor.execute(sql, (athena_code, umls_sab))
            result = cursor.fetchone()
            return result[0] if result else None
    except Exception as e:
        logger.warning(f"Error mapping Athena {athena_vocab_id}:{athena_code} to CUI: {e}", exc_info=False)
        return None

# --- MeiliSearch Client and Index Functions ---
def get_meilisearch_client(): # ... (same as before) ...
    if not MEILI_API_KEY or not MEILI_HOST: logger.error("Missing MeiliSearch details."); sys.exit(1)
    try:
        logger.info(f"Connecting to Meilisearch: host={MEILI_HOST}")
        client = meilisearch.Client(MEILI_HOST, MEILI_API_KEY)
        if not client.is_healthy(): time.sleep(2); client.health()
        logger.info("Successfully connected to Meilisearch.")
        return client
    except Exception as e: logger.error(f"Error connecting to Meilisearch: {e}", exc_info=True); sys.exit(1)

def configure_meilisearch_index(client: meilisearch.Client, index_name: str) -> MeiliIndex:
    logger.info(f"Configuring Meilisearch index '{index_name}'...")
    index: MeiliIndex
    try:
        index = client.get_index(index_name)
        logger.info(f"Index '{index_name}' already exists. Will update settings and add/update documents.")
    except meilisearch.errors.MeilisearchApiError as e:
        if e.code == 'index_not_found':
            logger.info(f"Index '{index_name}' not found. Creating it...")
            task = client.create_index(index_name, {'primaryKey': 'id'})
            client.wait_for_task(task.task_uid, timeout_in_ms=20000, interval_in_ms=200) # Wait longer
            index = client.index(index_name)
            logger.info(f"Index '{index_name}' created.")
        else: raise
    
    desired_settings = {
        'searchableAttributes': ['name', 'synonyms', 'id', 'definition', 'codes_by_sab.*'],
        'filterableAttributes': ['id', 'tuis', 'semantic_types', 'sabs', 'source', 'primary_code_sab', 'primary_code_val'],
        'sortableAttributes': ['name'],
        'rankingRules': ["words", "typo", "proximity", "attribute", "sort", "exactness"],
        'typoTolerance': {'enabled': True, 'minWordSizeForTypos': {'oneTypo': 5, 'twoTypos': 9}}
    }
    logger.info(f"Updating settings for index '{index_name}'...")
    task = index.update_settings(desired_settings)
    client.wait_for_task(task.task_uid, timeout_in_ms=60000, interval_in_ms=200)
    logger.info(f"Settings updated. Index '{index_name}' is ready.")
    return index

def send_batch_to_meili(index: MeiliIndex, batch: list, tasks_list: list): # ... (same as before) ...
    if not batch: return
    try:
        task_info = index.add_documents(batch)
        tasks_list.append(task_info.task_uid)
    except Exception as e: logger.error(f"Error sending batch to Meilisearch: {e}", exc_info=True)

# --- Main Loading Logic ---
def main():
    global CONCEPT_LIMIT
    parser = argparse.ArgumentParser(description='Load UMLS & Athena terminology to MeiliSearch.')
    parser.add_argument('--index_name', type=str, default=MEILI_INDEX_NAME, help='MeiliSearch index name.')
    parser.add_argument('--limit_concepts', type=int, default=CONCEPT_LIMIT, help='Approximate total concepts to load.')
    parser.add_argument('--skip_umls', action='store_true', help='Skip UMLS data.')
    parser.add_argument('--skip_athena', action='store_true', help='Skip Athena data.')
    parser.add_argument('--filter_semantic_types', action='store_true', help='Filter UMLS by SEMANTIC_GROUPS_TUIs.')
    parser.add_argument('--delete_existing_index', action='store_true', help='Delete existing MeiliSearch index before loading.')

    args = parser.parse_args()
    CONCEPT_LIMIT = args.limit_concepts # Update global from arg

    overall_start_time = time.time()
    logger.info(f"--- Starting Terminology Load to MeiliSearch Index: '{args.index_name}' ---")
    pg_conn = None; meili_client = None; tasks_submitted = [];
    total_docs_finalized = 0; umls_docs_processed = 0; athena_new_docs = 0; athena_merged_count = 0
    indexed_umls_cuis_in_meili = set()

    try:
        pg_conn = get_postgres_connection()
        meili_client = get_meilisearch_client()

        if args.delete_existing_index:
            try:
                logger.warning(f"Attempting to delete existing index '{args.index_name}' as requested.")
                task = meili_client.delete_index(args.index_name)
                meili_client.wait_for_task(task.task_uid, timeout_in_ms=30000, interval_in_ms=200)
                logger.info(f"Index '{args.index_name}' deleted successfully.")
            except meilisearch.errors.MeilisearchApiError as e:
                if e.code == 'index_not_found': logger.info(f"Index '{args.index_name}' did not exist, no need to delete.")
                else: logger.error(f"Could not delete index '{args.index_name}': {e}. Proceeding might lead to mixed data."); # Decide if to sys.exit(1)
            except Exception as e_del: logger.error(f"Unexpected error during index deletion: {e_del}", exc_info=True)

        concepts_index = configure_meilisearch_index(meili_client, args.index_name)
        meili_batch = []

        # === Process UMLS Concepts ===
        if not args.skip_umls:
            logger.info("--- Processing UMLS concepts for MeiliSearch ---")
            semantic_tui_filter_list = SEMANTIC_GROUPS_TUIs_FILTER if args.filter_semantic_types else None
            
            with pg_conn.cursor() as cur: cur.execute("SET LOCAL work_mem = '2GB';"); logger.info("Set work_mem for UMLS CUI fetch.")
            all_cuis_from_umls = fetch_all_relevant_cuis_for_meili(pg_conn, semantic_tui_filter_list, CONCEPT_LIMIT)
            pg_conn.commit()

            if not all_cuis_from_umls: logger.info("No UMLS CUIs to process.")
            else:
                for i in tqdm(range(0, len(all_cuis_from_umls), CUI_PROCESSING_BATCH_SIZE_PG), desc="UMLS CUI Batches to Meili"):
                    if CONCEPT_LIMIT and total_docs_finalized >= CONCEPT_LIMIT: break
                    cui_pg_batch = all_cuis_from_umls[i : i + CUI_PROCESSING_BATCH_SIZE_PG]
                    if not cui_pg_batch: continue
                    
                    batch_data = fetch_umls_data_for_meili_batch(pg_conn, cui_pg_batch, semantic_tui_filter_list)

                    for cui in cui_pg_batch:
                        if CONCEPT_LIMIT and total_docs_finalized >= CONCEPT_LIMIT: break
                        mrconso = batch_data["names"].get(cui, [])
                        if not mrconso: continue
                        valid_names = [r for r in mrconso if not filter_term_for_meili(r['str'])]
                        if not valid_names: continue

                        syns_prep = {my_simple_prepare_name(r['str']) for r in valid_names}
                        pref_raw = select_preferred_name_from_list(valid_names, PREFERRED_SOURCES_FOR_NAME)
                        pref_prep = my_simple_prepare_name(pref_raw)
                        syns_prep.add(pref_prep)

                        stys = batch_data["stys"].get(cui, [])
                        tuis = sorted(list(set(s['tui'] for s in stys if s.get('tui'))))
                        sem_types = sorted(list(set(s['sty'] for s in stys if s.get('sty'))))
                        
                        defs = batch_data["defs"].get(cui, [])
                        def_txt = ""
                        if defs: p_def = next((d['def'] for d in defs if d['sab'] in PREFERRED_SOURCES_FOR_NAME), None); def_txt = p_def if p_def else defs[0]['def']

                        codes, sabs = defaultdict(set), set()
                        primary_code_sab, primary_code_val = None, None # For potential top-level filtering
                        for r_mc in mrconso:
                            codes[r_mc['sab']].add(r_mc['code']); sabs.add(r_mc['sab'])
                            if r_mc['str'] == pref_raw: # Get code/sab of the raw preferred name
                                primary_code_sab = r_mc['sab']
                                primary_code_val = r_mc['code']

                        meili_doc = {'id': cui, 'name': pref_prep,
                                     'synonyms': [s for s in syns_prep if s != pref_prep],
                                     'semantic_types': sem_types, 'tuis': tuis, 'definition': def_txt,
                                     'codes_by_sab': {k: sorted(list(v)) for k, v in codes.items()},
                                     'sabs': sorted(list(sabs)), 'source': 'UMLS',
                                     'primary_code_sab': primary_code_sab, 'primary_code_val': primary_code_val
                                    }
                        meili_batch.append(meili_doc)
                        indexed_umls_cuis_in_meili.add(cui)
                        total_docs_finalized += 1; umls_docs_processed +=1
                        if len(meili_batch) >= BATCH_SIZE_MEILI: send_batch_to_meili(concepts_index, meili_batch, tasks_submitted); meili_batch = []
                    pg_conn.commit() # Commit after each PG data fetch batch
                if meili_batch: send_batch_to_meili(concepts_index, meili_batch, tasks_submitted); meili_batch = []
            logger.info(f"Finished UMLS. Docs for Meili: {umls_docs_processed}")

        # === Process ATHENA Concepts ===
        if LOAD_ATHENA_DATA and not args.skip_athena:
            if CONCEPT_LIMIT and total_docs_finalized >= CONCEPT_LIMIT: logger.info("Skipping Athena: limit reached.")
            else:
                logger.info("--- Processing ATHENA concepts for MeiliSearch ---")
                q_ath = "SELECT c.concept_id::text AS athena_id, c.concept_name, c.concept_code, c.vocabulary_id, d.domain_name, cc.concept_class_name, c.standard_concept FROM clinical_vocab.concept c LEFT JOIN clinical_vocab.domain d ON c.domain_id = d.domain_id LEFT JOIN clinical_vocab.concept_class cc ON c.concept_class_id = cc.concept_class_id WHERE c.invalid_reason IS NULL AND c.concept_name IS NOT NULL AND trim(c.concept_name) <> '' ORDER BY c.concept_id"
                ath_limit_clause = ""
                if CONCEPT_LIMIT:
                    rem = CONCEPT_LIMIT - total_docs_finalized
                    if rem <=0 : q_ath = None
                    else: ath_limit_clause = f" LIMIT {rem}"
                
                if q_ath:
                    ath_cursor_name = 'athena_meili_cursor'
                    ath_cursor = pg_conn.cursor(ath_cursor_name, cursor_factory=psycopg2.extras.DictCursor)
                    ath_cursor.itersize = PG_CURSOR_ITERSIZE
                    ath_cursor.execute(q_ath + ath_limit_clause)

                    for row in tqdm(ath_cursor, desc="Athena Concepts to Meili"):
                        if CONCEPT_LIMIT and total_docs_finalized >= CONCEPT_LIMIT: break
                        
                        ath_name_prep = my_simple_prepare_name(row['concept_name'])
                        if filter_term_for_meili(ath_name_prep): continue

                        mapped_cui = map_athena_to_cui(pg_conn, row['concept_code'], row['vocabulary_id'])

                        if mapped_cui and mapped_cui in indexed_umls_cuis_in_meili:
                            athena_merged_count +=1
                            logger.debug(f"Athena {row['athena_id']} ({row['vocabulary_id']}:{row['concept_code']}) maps to UMLS CUI {mapped_cui}. Considered merged.")
                            # Future: Implement partial update to add Athena name as synonym to existing Meili doc
                            # For now, prioritize the UMLS version.
                        else:
                            doc_id = f"ATHENA_{row['athena_id']}" if not mapped_cui else mapped_cui # Use CUI if mapped but not in UMLS set
                            
                            # Fetch Athena synonyms if needed (simplified here)
                            # synonyms_athena = fetch_athena_synonyms(pg_conn.cursor(cursor_factory=RealDictCursor), int(row['athena_id']))
                            # synonyms_athena_prepared = [my_simple_prepare_name(s) for s in synonyms_athena if not filter_term_for_meili(s) and my_simple_prepare_name(s) != ath_name_prep]

                            meili_doc = {
                                'id': doc_id, 'name': ath_name_prep,
                                'synonyms': [], # Add prepared Athena synonyms if fetched
                                'semantic_types': [row['concept_class_name']] if row['concept_class_name'] else [], 
                                'tuis': [], # Athena concepts usually don't have TUIs directly this way
                                'definition': None,
                                'codes_by_sab': {row['vocabulary_id']: [row['concept_code']]},
                                'sabs': [row['vocabulary_id']],
                                'source': 'ATHENA',
                                'athena_concept_id': row['athena_id'],
                                'athena_domain': row['domain_name'],
                                'athena_standard_concept': row['standard_concept'],
                                'primary_code_sab': row['vocabulary_id'], 'primary_code_val': row['concept_code']
                            }
                            meili_batch.append(meili_doc)
                            total_docs_finalized += 1; athena_new_docs +=1
                            if mapped_cui and mapped_cui not in indexed_umls_cuis_in_meili: indexed_umls_cuis_in_meili.add(mapped_cui) # Add CUI if it was an Athena-only CUI

                            if len(meili_batch) >= BATCH_SIZE_MEILI: send_batch_to_meili(concepts_index, meili_batch, tasks_submitted); meili_batch = []
                    ath_cursor.close()
                    if meili_batch: send_batch_to_meili(concepts_index, meili_batch, tasks_submitted); meili_batch = []
                pg_conn.commit() # Commit after Athena processing
                logger.info(f"Finished Athena. New docs: {athena_new_docs}, Merged: {athena_merged_count}")

    except (Exception, KeyboardInterrupt) as e:
        logger.error(f"An error occurred: {e}", exc_info=True)
        if pg_conn: pg_conn.rollback()
    finally:
        # Final summary and cleanup
        logger.info(f"\n--- Load Process Summary ---")
        logger.info(f"Total documents finalized for MeiliSearch: {total_docs_finalized}")
        logger.info(f"  UMLS documents processed: {umls_docs_processed}")
        logger.info(f"  New Athena documents created: {athena_new_docs}")
        logger.info(f"  Athena concepts conceptually merged/updated with UMLS: {athena_merged_count}")
        logger.info(f"Total MeiliSearch add_documents tasks submitted: {len(tasks_submitted)}")
        if tasks_submitted: logger.info(f"  Sample Task UIDs: {tasks_submitted[:3]} ... {tasks_submitted[-3:] if len(tasks_submitted) > 3 else ''}")
        
        overall_elapsed = time.time() - overall_start_time
        logger.info(f"Total execution time: {timedelta(seconds=overall_elapsed)}")
        if pg_conn: pg_conn.close(); logger.info("PostgreSQL connection closed.")
        logger.info("Load script finished.")

if __name__ == "__main__":
    main()