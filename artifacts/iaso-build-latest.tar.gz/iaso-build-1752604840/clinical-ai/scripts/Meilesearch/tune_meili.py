import os
import meilisearch
from dotenv import load_dotenv
import json
import time # Import time for potential waits

# Load environment variables (assuming .env is in parent directory)
load_dotenv('../.env')

MEILI_HOST = os.getenv('MEILISEARCH_HOST', 'http://localhost:7700')
MEILI_API_KEY = os.getenv('MEILISEARCH_MASTER_KEY')
MEILI_INDEX_NAME = "concepts"

if not MEILI_API_KEY:
    print("Error: MEILISEARCH_MASTER_KEY not found in .env")
    exit()

client = meilisearch.Client(MEILI_HOST, MEILI_API_KEY)

# Ensure the index exists before trying to get settings
try:
    index = client.get_index(MEILI_INDEX_NAME)
    print(f"Successfully accessed index '{MEILI_INDEX_NAME}'.")
except Exception as e:
     print(f"Error accessing index '{MEILI_INDEX_NAME}': {e}")
     print("Make sure the index has been created (e.g., by the loading script).")
     exit()


try:
    # --- Get ALL Current Settings ---
    print("Getting all current index settings...")
    current_settings = index.get_settings()
    # Print just the typo tolerance part
    print("\nCurrent Typo Tolerance Settings:")
    print(json.dumps(current_settings.get('typoTolerance', {}), indent=2))

    # --- Define New Settings (Example - Use with caution!) ---
    # Uncomment and modify the section below ONLY if you want to change settings

    print("\nUpdating typo tolerance settings...")
    # # Define ONLY the typoTolerance part to update
    # # Using update_settings will merge these changes with existing settings
    new_typo_settings = {
       "enabled": True,
       "minWordSizeForTypos": {
         "oneTypo": 4, # Example: Lower from default 5
         "twoTypos": 8  # Example: Lower from default 9
       },
       "disableOnAttributes": [],
       "disableOnWords": []
    #   # "wordLengthBasedSettings": { ... } # Add if needed
     }

    # # Use update_settings, passing only the setting you want to change
    task = index.update_settings({'typoTolerance': new_typo_settings})
    print(f"Submitted settings update task: {task.task_uid}")
    print("Waiting for task to complete...")
    client.wait_for_task(task.task_uid, timeout_in_ms=20000) # Wait up to 20s
    print("Settings update task completed.")

    # # Verify the update by getting all settings again
    print("\nVerifying new settings...")
    updated_settings_all = index.get_settings()
    print("Updated Typo Tolerance Settings:")
    print(json.dumps(updated_settings_all.get('typoTolerance', {}), indent=2))


except Exception as e:
    print(f"An error occurred: {e}")