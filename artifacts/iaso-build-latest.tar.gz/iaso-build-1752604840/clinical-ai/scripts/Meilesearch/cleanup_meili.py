# scripts/cleanup_meili.py

import os
import sys
import logging
import meilisearch
from dotenv import load_dotenv

# --- Basic Logging Setup ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# --- Configuration ---
logger.info("Loading environment configuration...")
# Load environment variables from .env file in parent directory
# Ensure .env file exists in ../ relative to this script
load_dotenv() 

MEILI_HOST = os.getenv('MEILISEARCH_HOST', 'http://localhost:7700')
MEILI_API_KEY = os.getenv('MEILISEARCH_API_KEY')
MEILI_INDEX_NAME = os.getenv('MEILISEARCH_INDEX_NAME', "concepts")

def main():
    """Connects to Meilisearch and attempts to delete the specified index."""
    logger.info("--- Starting Meilisearch Index Cleanup ---")

    if not MEILI_API_KEY or not MEILI_HOST:
        logger.error("Missing Meilisearch connection details in environment variables (MEILISEARCH_HOST, MEILISEARCH_MASTER_KEY).")
        sys.exit(1)

    try:
        logger.info(f"Connecting to Meilisearch: host={MEILI_HOST}")
        client = meilisearch.Client(MEILI_HOST, MEILI_API_KEY)

        if not client.is_healthy():
            logger.warning("Meilisearch may not be healthy. Attempting delete anyway...")

        logger.info(f"Attempting to delete index: '{MEILI_INDEX_NAME}'...")
        task_info = client.delete_index(MEILI_INDEX_NAME)
        logger.info(f"Deletion task submitted. Task UID: {task_info.task_uid}")

        logger.info("Waiting for deletion task to complete...")
        client.wait_for_task(task_info.task_uid, timeout_in_ms=30000, interval_in_ms=100) # Wait up to 30s
        logger.info(f"Index '{MEILI_INDEX_NAME}' successfully deleted (or task processed).")

    except meilisearch.errors.MeiliSearchApiError as e:
        if e.code == 'index_not_found':
             logger.warning(f"Index '{MEILI_INDEX_NAME}' not found. Assumed already deleted.")
        else:
             logger.error(f"Meilisearch API error during deletion: {e}", exc_info=True)
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}", exc_info=True)
    finally:
        logger.info("--- Meilisearch Index Cleanup Finished ---")

if __name__ == "__main__":
    main()