#!/usr/bin/env python3
"""
Medical Dataset Downloader for MedCAT Training
Downloads public medical text datasets for training MedCAT models.
"""

import requests
import pandas as pd
import json
import time
import random
import logging
from pathlib import Path
from typing import List, Dict
import xml.etree.ElementTree as ET
from urllib.parse import quote
import argparse
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class MedicalDatasetDownloader:
    """Download and prepare medical text datasets for MedCAT training."""
    
    def __init__(self, output_dir: Path = Path("./datasets")):
        self.output_dir = output_dir
        self.output_dir.mkdir(exist_ok=True)
        
        # Setup requests session with retry logic
        self.session = requests.Session()
        retry_strategy = Retry(
            total=5,  # Total number of retries
            backoff_factor=2,  # Wait time between retries (exponential backoff)
            status_forcelist=[429, 500, 502, 503, 504],  # HTTP status codes to retry
            allowed_methods=["HEAD", "GET", "OPTIONS"]  # HTTP methods to retry
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
    
    def download_mtsamples(self, max_samples: int = 5000) -> Path:
        """
        Generate diverse medical transcription samples.
        (MTSamples website would require web scraping for real data)
        """
        logger.info("Generating diverse medical transcription samples...")
        
        # Medical transcription templates by specialty
        transcription_templates = {
            'cardiology': [
                "CHIEF COMPLAINT: {chief_complaint}. HISTORY OF PRESENT ILLNESS: {age}-year-old {gender} with history of {pmh} presents with {symptoms}. PHYSICAL EXAMINATION: {pe_findings}. ASSESSMENT AND PLAN: {diagnosis}. {treatment}.",
                "PROCEDURE: {procedure}. INDICATION: {indication}. TECHNIQUE: {technique}. FINDINGS: {findings}. IMPRESSION: {impression}.",
                "CONSULTATION: Cardiology consultation for {reason}. Patient is a {age}-year-old {gender} with {condition}. Recommendations include {recommendations}."
            ],
            'emergency': [
                "EMERGENCY DEPARTMENT NOTE: {age}-year-old {gender} presents with {chief_complaint}. Triage vital signs: {vitals}. {assessment}. Disposition: {disposition}.",
                "TRAUMA ACTIVATION: {mechanism} resulting in {injuries}. Primary survey: {primary_survey}. Secondary survey: {secondary_survey}. Plan: {trauma_plan}."
            ],
            'surgery': [
                "OPERATIVE REPORT: {procedure}. SURGEON: Staff surgeon. ANESTHESIA: {anesthesia}. FINDINGS: {operative_findings}. PROCEDURE: {operative_technique}. COMPLICATIONS: {complications}.",
                "PREOPERATIVE DIAGNOSIS: {preop_dx}. POSTOPERATIVE DIAGNOSIS: {postop_dx}. PROCEDURE PERFORMED: {procedure}. ESTIMATED BLOOD LOSS: {ebl}."
            ],
            'internal_medicine': [
                "HISTORY AND PHYSICAL: {age}-year-old {gender} admitted for {admission_reason}. PAST MEDICAL HISTORY: {pmh}. MEDICATIONS: {medications}. ASSESSMENT: {assessment}. PLAN: {plan}.",
                "PROGRESS NOTE: Patient is {clinical_status}. Overnight events: {overnight}. Plan: {daily_plan}."
            ],
            'radiology': [
                "IMAGING STUDY: {study_type}. CLINICAL INDICATION: {indication}. TECHNIQUE: {technique}. FINDINGS: {findings}. IMPRESSION: {impression}.",
                "COMPARISON: {comparison}. FINDINGS: {detailed_findings}. CONCLUSION: {conclusion}."
            ],
            'pathology': [
                "SURGICAL PATHOLOGY: {specimen}. CLINICAL HISTORY: {clinical_history}. GROSS DESCRIPTION: {gross}. MICROSCOPIC DESCRIPTION: {microscopic}. DIAGNOSIS: {pathology_diagnosis}."
            ]
        }
        
        # Medical vocabulary for each specialty
        vocab = {
            'ages': [str(age) for age in range(25, 90)],
            'genders': ['male', 'female'],
            'chief_complaints': [
                'chest pain', 'shortness of breath', 'abdominal pain', 'headache',
                'dizziness', 'palpitations', 'syncope', 'weakness', 'fatigue',
                'nausea and vomiting', 'fever and chills', 'joint pain'
            ],
            'pmh': [
                'hypertension', 'diabetes mellitus', 'coronary artery disease',
                'heart failure', 'COPD', 'atrial fibrillation', 'stroke',
                'chronic kidney disease', 'hyperlipidemia', 'obesity'
            ],
            'symptoms': [
                'substernal chest pressure', 'exertional dyspnea', 'sharp abdominal pain',
                'throbbing headache', 'presyncope', 'rapid heart rate',
                'bilateral lower extremity edema', 'orthopnea'
            ],
            'procedures': [
                'cardiac catheterization', 'echocardiogram', 'stress test',
                'colonoscopy', 'upper endoscopy', 'CT scan', 'MRI',
                'appendectomy', 'cholecystectomy', 'coronary angioplasty'
            ],
            'medications': [
                'metoprolol', 'lisinopril', 'atorvastatin', 'aspirin',
                'insulin', 'metformin', 'furosemide', 'warfarin',
                'albuterol', 'prednisone', 'omeprazole'
            ],
            'diagnoses': [
                'acute myocardial infarction', 'congestive heart failure',
                'pneumonia', 'urinary tract infection', 'acute appendicitis',
                'cholangitis', 'diabetic ketoacidosis', 'sepsis',
                'stroke', 'pulmonary embolism'
            ]
        }
        
        sample_texts = []
        
        # Generate samples for each specialty
        for specialty, templates in transcription_templates.items():
            samples_per_specialty = max_samples // len(transcription_templates)
            
            for _ in range(samples_per_specialty):
                template = random.choice(templates)
                
                # Fill template with appropriate medical terms
                sample = template.format(
                    age=random.choice(vocab['ages']),
                    gender=random.choice(vocab['genders']),
                    chief_complaint=random.choice(vocab['chief_complaints']),
                    pmh=', '.join(random.sample(vocab['pmh'], random.randint(1, 3))),
                    symptoms=random.choice(vocab['symptoms']),
                    pe_findings=f"notable for {random.choice(['tachycardia', 'hypertension', 'murmur', 'rales', 'edema'])}",
                    diagnosis=random.choice(vocab['diagnoses']),
                    treatment=f"started on {random.choice(vocab['medications'])}",
                    procedure=random.choice(vocab['procedures']),
                    indication=random.choice(vocab['diagnoses']),
                    technique=f"performed under {random.choice(['conscious sedation', 'general anesthesia', 'local anesthesia'])}",
                    findings=f"revealed {random.choice(['normal anatomy', 'pathological changes', 'inflammatory changes'])}",
                    impression=random.choice(vocab['diagnoses']),
                    reason=random.choice(vocab['chief_complaints']),
                    condition=random.choice(vocab['pmh']),
                    recommendations=f"{random.choice(vocab['medications'])} and follow-up",
                    vitals=f"BP {random.randint(90, 180)}/{random.randint(50, 100)}, HR {random.randint(60, 120)}",
                    assessment=f"likely {random.choice(vocab['diagnoses'])}",
                    disposition=random.choice(['discharged home', 'admitted to hospital', 'transferred to ICU']),
                    mechanism=random.choice(['motor vehicle accident', 'fall', 'assault']),
                    injuries=random.choice(['head trauma', 'chest trauma', 'abdominal trauma']),
                    primary_survey='airway patent, breathing adequate, circulation stable',
                    secondary_survey=f"notable for {random.choice(['lacerations', 'bruising', 'deformity'])}",
                    trauma_plan='CT imaging and surgical consultation',
                    anesthesia=random.choice(['general', 'spinal', 'epidural']),
                    operative_findings=random.choice(['normal anatomy', 'inflammatory changes', 'tumor']),
                    operative_technique='standard technique without complications',
                    complications='none',
                    preop_dx=random.choice(vocab['diagnoses']),
                    postop_dx=random.choice(vocab['diagnoses']),
                    ebl=f"{random.randint(50, 500)} mL",
                    admission_reason=random.choice(vocab['diagnoses']),
                    medications=', '.join(random.sample(vocab['medications'], random.randint(2, 4))),
                    plan=f"continue {random.choice(vocab['medications'])}, monitor closely",
                    clinical_status=random.choice(['stable', 'improving', 'unchanged']),
                    overnight='no acute events',
                    daily_plan='continue current management',
                    study_type=random.choice(['CT chest', 'MRI brain', 'X-ray abdomen']),
                    comparison='prior study from last month',
                    detailed_findings=f"shows {random.choice(['normal appearance', 'abnormal findings', 'improvement'])}",
                    conclusion=random.choice(['normal study', 'abnormal findings', 'recommend follow-up']),
                    specimen=random.choice(['appendix', 'gallbladder', 'colon biopsy']),
                    clinical_history=random.choice(vocab['diagnoses']),
                    gross=f"received {random.choice(['inflamed', 'normal', 'abnormal'])} tissue",
                    microscopic='shows inflammatory changes',
                    pathology_diagnosis=random.choice(['acute inflammation', 'chronic inflammation', 'normal tissue'])
                )
                
                sample_texts.append(sample)
        
        # Fill remaining slots if needed
        while len(sample_texts) < max_samples:
            # Add more diverse samples
            additional_samples = [
                f"Patient is a {random.choice(vocab['ages'])}-year-old {random.choice(vocab['genders'])} with {random.choice(vocab['pmh'])} presenting with {random.choice(vocab['symptoms'])}.",
                f"Physical examination reveals {random.choice(['normal findings', 'abnormal findings', 'significant pathology'])}. Laboratory studies show {random.choice(['normal values', 'elevated markers', 'abnormal results'])}.",
                f"Treatment plan includes {random.choice(vocab['medications'])} and {random.choice(['close monitoring', 'follow-up care', 'specialist referral'])}."
            ]
            sample_texts.extend(additional_samples)
        
        output_path = self.output_dir / "mtsamples_training.txt"
        
        with open(output_path, 'w', encoding='utf-8') as f:
            for text in sample_texts[:max_samples]:
                f.write(text + '\n')
        
        logger.info(f"Generated {max_samples} diverse medical transcription samples: {output_path}")
        return output_path
    
    def download_pubmed_abstracts(self, 
                                 search_terms: List[str] = None,
                                 max_abstracts: int = 10000,
                                 email: str = None,
                                 comprehensive_search: bool = False) -> Path:
        """
        Download PubMed abstracts using the E-utilities API.
        
        Args:
            search_terms: Medical terms to search for
            max_abstracts: Maximum number of abstracts to download
            email: Your email (required by NCBI for API usage)
            comprehensive_search: If True, use broader medical search terms
        """
        if not email:
            logger.warning("Email not provided. NCBI recommends providing email for API usage.")
        
        if not search_terms:
            if comprehensive_search:
                # Comprehensive medical search terms covering all major domains
                search_terms = [
                    # Cardiovascular
                    "myocardial infarction", "heart failure", "stroke", "hypertension", "arrhythmia",
                    "coronary artery disease", "atrial fibrillation", "cardiac arrest",
                    
                    # Endocrine/Metabolic
                    "diabetes mellitus", "thyroid disease", "obesity", "metabolic syndrome",
                    "hyperlipidemia", "osteoporosis",
                    
                    # Respiratory
                    "pneumonia", "asthma", "COPD", "pulmonary embolism", "respiratory failure",
                    "lung cancer", "tuberculosis",
                    
                    # Infectious Diseases
                    "COVID-19", "influenza", "sepsis", "meningitis", "hepatitis", "HIV",
                    "antibiotic resistance",
                    
                    # Neurological
                    "alzheimer disease", "parkinson disease", "epilepsy", "multiple sclerosis",
                    "migraine", "depression", "anxiety", "schizophrenia",
                    
                    # Oncology
                    "breast cancer", "lung cancer", "colorectal cancer", "prostate cancer",
                    "leukemia", "lymphoma", "chemotherapy", "radiation therapy",
                    
                    # Gastrointestinal
                    "inflammatory bowel disease", "peptic ulcer", "cirrhosis", "pancreatitis",
                    "gastroesophageal reflux",
                    
                    # Musculoskeletal
                    "rheumatoid arthritis", "osteoarthritis", "fractures", "back pain",
                    
                    # Renal
                    "chronic kidney disease", "acute kidney injury", "dialysis",
                    
                    # ICU/Emergency
                    "intensive care", "emergency medicine", "trauma", "shock", "mechanical ventilation",
                    "critical care", "resuscitation",
                    
                    # Pediatrics
                    "pediatric", "neonatal", "childhood diseases",
                    
                    # Obstetrics/Gynecology
                    "pregnancy", "obstetrics", "gynecology", "preeclampsia",
                    
                    # Surgery
                    "surgery", "postoperative complications", "anesthesia"
                ]
            else:
                # Original focused search terms
                search_terms = [
                    "myocardial infarction", "diabetes mellitus", "pneumonia", "hypertension",
                    "heart failure", "stroke", "cancer", "COVID-19", "depression", "asthma"
                ]
        
        logger.info(f"Downloading PubMed abstracts for {len(search_terms)} medical terms")
        if comprehensive_search:
            logger.info("Using comprehensive medical domain coverage")
        
        base_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
        abstracts = []
        failed_terms = []
        
        for i, term in enumerate(search_terms):
            max_retries = 3
            retry_delay = 5
            
            for attempt in range(max_retries):
                try:
                    logger.info(f"Searching for ({i+1}/{len(search_terms)}): {term} (attempt {attempt+1})")
                    
                    # Search for PMIDs
                    search_url = f"{base_url}esearch.fcgi"
                    search_params = {
                        'db': 'pubmed',
                        'term': term,
                        'retmax': min(max_abstracts // len(search_terms), 1000),
                        'retmode': 'json'
                    }
                    if email:
                        search_params['email'] = email
                    
                    search_response = self.session.get(search_url, params=search_params, timeout=30)
                    search_response.raise_for_status()
                    search_data = search_response.json()
                    
                    pmids = search_data.get('esearchresult', {}).get('idlist', [])
                    
                    if not pmids:
                        logger.warning(f"No results found for: {term}")
                        break
                    
                    term_abstracts = []
                    
                    # Fetch abstracts in batches
                    batch_size = 200
                    for batch_start in range(0, len(pmids), batch_size):
                        batch_pmids = pmids[batch_start:batch_start+batch_size]
                        
                        fetch_url = f"{base_url}efetch.fcgi"
                        fetch_params = {
                            'db': 'pubmed',
                            'id': ','.join(batch_pmids),
                            'retmode': 'xml'
                        }
                        if email:
                            fetch_params['email'] = email
                        
                        fetch_response = self.session.get(fetch_url, params=fetch_params, timeout=60)
                        fetch_response.raise_for_status()
                        
                        # Parse XML response
                        root = ET.fromstring(fetch_response.content)
                        
                        for article in root.findall('.//PubmedArticle'):
                            abstract_elem = article.find('.//Abstract/AbstractText')
                            title_elem = article.find('.//ArticleTitle')
                            
                            if abstract_elem is not None and abstract_elem.text:
                                title = title_elem.text if title_elem is not None else ""
                                abstract_text = abstract_elem.text
                                
                                # Combine title and abstract
                                full_text = f"{title}. {abstract_text}" if title else abstract_text
                                term_abstracts.append(full_text)
                        
                        # Be respectful to NCBI servers
                        time.sleep(0.5)
                    
                    abstracts.extend(term_abstracts)
                    logger.info(f"✅ Downloaded {len(term_abstracts)} abstracts for: {term}")
                    break  # Success, exit retry loop
                    
                except Exception as e:
                    logger.error(f"❌ Attempt {attempt+1} failed for {term}: {e}")
                    if attempt < max_retries - 1:
                        logger.info(f"⏳ Retrying in {retry_delay} seconds...")
                        time.sleep(retry_delay)
                        retry_delay *= 2  # Exponential backoff
                    else:
                        logger.error(f"❌ All attempts failed for: {term}")
                        failed_terms.append(term)
                
                # Add delay between terms to be respectful
                time.sleep(1)
        
        # Report results
        if failed_terms:
            logger.warning(f"⚠️  Failed to download abstracts for: {', '.join(failed_terms)}")
            logger.info(f"💡 You can retry these terms later with a separate command")
        
        # Save to file
        output_path = self.output_dir / "pubmed_abstracts_training.txt"
        with open(output_path, 'w', encoding='utf-8') as f:
            for abstract in abstracts[:max_abstracts]:
                f.write(abstract + '\n')
        
        logger.info(f"🎉 Successfully downloaded {len(abstracts)} PubMed abstracts: {output_path}")
        logger.info(f"📊 Success rate: {len(search_terms) - len(failed_terms)}/{len(search_terms)} terms")
        
        return output_path
    
    def download_clinical_trials_data(self, max_studies: int = 5000) -> Path:
        """
        Download clinical trial descriptions from ClinicalTrials.gov API.
        Falls back to synthetic clinical data if API fails.
        """
        logger.info("Downloading clinical trials data...")
        
        # Try the new ClinicalTrials.gov API first
        studies = self._try_new_clinical_trials_api(max_studies)
        
        # If that fails, try the old API
        if not studies:
            studies = self._try_old_clinical_trials_api(max_studies)
        
        # If both fail, generate synthetic clinical trial data
        if not studies:
            logger.warning("ClinicalTrials.gov API unavailable, generating synthetic clinical trial data")
            studies = self._generate_synthetic_clinical_trials(max_studies)
        
        # Save to file
        output_path = self.output_dir / "clinical_trials_training.txt"
        with open(output_path, 'w', encoding='utf-8') as f:
            for study in studies[:max_studies]:
                # Clean and format the text
                clean_study = study.replace('\n', ' ').replace('\r', ' ')
                clean_study = ' '.join(clean_study.split())  # Remove extra whitespace
                f.write(clean_study + '\n')
        
        logger.info(f"Downloaded {len(studies)} clinical trial descriptions: {output_path}")
        return output_path
    
    def _try_new_clinical_trials_api(self, max_studies: int) -> List[str]:
        """Try the new ClinicalTrials.gov API (v2)."""
        try:
            base_url = "https://clinicaltrials.gov/api/v2/studies"
            studies = []
            
            conditions = [
                "Heart Disease", "Diabetes", "Cancer", "Stroke", "Pneumonia",
                "Hypertension", "Depression", "Asthma", "COVID-19", "Arthritis"
            ]
            
            for condition in conditions:
                try:
                    params = {
                        'query.cond': condition,
                        'pageSize': min(max_studies // len(conditions), 1000),
                        'format': 'json'
                    }
                    
                    response = self.session.get(base_url, params=params, timeout=30)
                    response.raise_for_status()
                    
                    data = response.json()
                    
                    if 'studies' in data:
                        for study in data['studies']:
                            texts = []
                            
                            # Extract protocol section data
                            protocol = study.get('protocolSection', {})
                            
                            # Brief summary
                            desc = protocol.get('descriptionModule', {})
                            if 'briefSummary' in desc:
                                texts.append(desc['briefSummary'])
                            
                            # Detailed description
                            if 'detailedDescription' in desc:
                                texts.append(desc['detailedDescription'])
                            
                            # Eligibility criteria
                            eligibility = protocol.get('eligibilityModule', {})
                            if 'eligibilityCriteria' in eligibility:
                                texts.append(f"Eligibility: {eligibility['eligibilityCriteria']}")
                            
                            # Intervention descriptions
                            interventions = protocol.get('armsInterventionsModule', {}).get('interventions', [])
                            for intervention in interventions:
                                if 'description' in intervention:
                                    texts.append(f"Intervention: {intervention['description']}")
                            
                            if texts:
                                combined_text = ' '.join(texts)
                                studies.append(combined_text)
                    
                    logger.info(f"Downloaded {len(studies)} studies for: {condition}")
                    time.sleep(1)  # Be respectful to the API
                    
                except Exception as e:
                    logger.warning(f"Error with new API for {condition}: {e}")
                    continue
            
            return studies
            
        except Exception as e:
            logger.warning(f"New ClinicalTrials API failed: {e}")
            return []
    
    def _try_old_clinical_trials_api(self, max_studies: int) -> List[str]:
        """Try the old ClinicalTrials.gov API (v1)."""
        try:
            base_url = "https://clinicaltrials.gov/api/query/study_fields"
            studies = []
            
            conditions = [
                "Heart Disease", "Diabetes", "Cancer", "Stroke", "Pneumonia",
                "Hypertension", "Depression", "Asthma", "COVID-19", "Arthritis"
            ]
            
            for condition in conditions:
                try:
                    params = {
                        'expr': condition,
                        'fields': 'BriefSummary,DetailedDescription,Condition,InterventionDescription',
                        'min_rnk': 1,
                        'max_rnk': min(max_studies // len(conditions), 1000),
                        'fmt': 'json'
                    }
                    
                    response = self.session.get(base_url, params=params, timeout=30)
                    response.raise_for_status()
                    
                    data = response.json()
                    
                    if 'StudyFieldsResponse' in data:
                        study_fields = data['StudyFieldsResponse']['StudyFields']
                        
                        for study in study_fields:
                            texts = []
                            
                            # Extract relevant text fields
                            if 'BriefSummary' in study and study['BriefSummary']:
                                texts.append(study['BriefSummary'][0])
                            
                            if 'DetailedDescription' in study and study['DetailedDescription']:
                                texts.append(study['DetailedDescription'][0])
                            
                            if 'InterventionDescription' in study and study['InterventionDescription']:
                                texts.extend(study['InterventionDescription'])
                            
                            if texts:
                                combined_text = ' '.join(texts)
                                studies.append(combined_text)
                    
                    logger.info(f"Downloaded {len(studies)} studies for: {condition}")
                    time.sleep(1)  # Be respectful to the API
                    
                except Exception as e:
                    logger.warning(f"Error with old API for {condition}: {e}")
                    continue
            
            return studies
            
        except Exception as e:
            logger.warning(f"Old ClinicalTrials API failed: {e}")
            return []
    
    def _generate_synthetic_clinical_trials(self, max_studies: int) -> List[str]:
        """Generate synthetic clinical trial descriptions when APIs fail."""
        
        logger.info("Generating synthetic clinical trial data...")
        
        # Clinical trial templates
        templates = [
            "This {phase} clinical trial evaluates the efficacy of {intervention} in patients with {condition}. "
            "Primary endpoint is {primary_endpoint}. Inclusion criteria include {inclusion}. "
            "The study aims to {objective}.",
            
            "A {design} study investigating {intervention} versus {comparator} in {population}. "
            "Participants will be randomized to receive either {treatment_a} or {treatment_b}. "
            "Primary outcome measures include {outcomes}.",
            
            "This trial assesses the safety and efficacy of {drug} in treating {indication}. "
            "Eligible patients are {eligibility}. Treatment duration is {duration}. "
            "Follow-up includes {followup} assessments.",
            
            "A multicenter {design} trial of {intervention} for {condition}. "
            "The study hypothesis is that {hypothesis}. Patients will be monitored for {monitoring}. "
            "Statistical analysis will include {analysis}.",
        ]
        
        # Medical vocabulary for templates
        vocab = {
            'phases': ['Phase I', 'Phase II', 'Phase III', 'Phase IV'],
            'designs': ['randomized controlled', 'double-blind', 'open-label', 'crossover', 'dose-escalation'],
            'interventions': [
                'novel monoclonal antibody therapy', 'combination chemotherapy regimen',
                'targeted kinase inhibitor', 'immunotherapy treatment', 'gene therapy',
                'stem cell transplantation', 'surgical intervention', 'radiation therapy'
            ],
            'conditions': [
                'advanced solid tumors', 'acute myocardial infarction', 'heart failure',
                'type 2 diabetes mellitus', 'hypertension', 'chronic kidney disease',
                'rheumatoid arthritis', 'inflammatory bowel disease', 'depression',
                'Alzheimer disease', 'stroke', 'COPD'
            ],
            'primary_endpoints': [
                'overall survival', 'progression-free survival', 'objective response rate',
                'change in hemoglobin A1c', 'reduction in blood pressure', 'improvement in ejection fraction',
                'decrease in disease activity score', 'change in quality of life measures'
            ],
            'populations': [
                'adults aged 18-75 years', 'elderly patients over 65',
                'treatment-naive patients', 'patients with refractory disease',
                'newly diagnosed patients', 'high-risk patients'
            ],
            'drugs': [
                'pembrolizumab', 'nivolumab', 'adalimumab', 'rituximab',
                'metformin', 'lisinopril', 'atorvastatin', 'aspirin'
            ],
            'durations': ['12 weeks', '6 months', '1 year', '2 years'],
            'outcomes': [
                'safety and tolerability', 'pharmacokinetic parameters',
                'biomarker changes', 'functional outcomes', 'mortality rates'
            ]
        }
        
        studies = []
        
        for _ in range(max_studies):
            template = random.choice(templates)
            
            # Fill template with random medical terms
            study = template.format(
                phase=random.choice(vocab['phases']),
                design=random.choice(vocab['designs']),
                intervention=random.choice(vocab['interventions']),
                condition=random.choice(vocab['conditions']),
                primary_endpoint=random.choice(vocab['primary_endpoints']),
                inclusion=f"{random.choice(vocab['populations'])} with confirmed {random.choice(vocab['conditions'])}",
                objective=f"demonstrate superiority of {random.choice(vocab['interventions'])}",
                population=random.choice(vocab['populations']),
                comparator='placebo' if random.random() < 0.5 else 'standard of care',
                treatment_a=random.choice(vocab['drugs']),
                treatment_b='placebo' if random.random() < 0.5 else random.choice(vocab['drugs']),
                outcomes=', '.join(random.sample(vocab['outcomes'], 2)),
                drug=random.choice(vocab['drugs']),
                indication=random.choice(vocab['conditions']),
                eligibility=random.choice(vocab['populations']),
                duration=random.choice(vocab['durations']),
                followup='safety and efficacy',
                hypothesis=f"{random.choice(vocab['interventions'])} will improve {random.choice(vocab['primary_endpoints'])}",
                monitoring='adverse events and efficacy endpoints',
                analysis='intention-to-treat and per-protocol analyses'
            )
            
            studies.append(study)
        
        logger.info(f"Generated {len(studies)} synthetic clinical trial descriptions")
        return studies
    
    def create_medical_wikipedia_dataset(self) -> Path:
        """
        Create a diverse dataset of medical encyclopedia content.
        """
        logger.info("Creating diverse medical encyclopedia dataset...")
        
        # Medical conditions with detailed descriptions
        medical_conditions = {
            'cardiovascular': [
                ('Myocardial infarction', 'commonly known as heart attack, occurs when blood flow decreases or stops to a part of the heart, causing damage to the heart muscle. Risk factors include smoking, diabetes, high blood pressure, and high cholesterol.'),
                ('Heart failure', 'is a condition in which the heart cannot pump blood effectively to meet the body\'s needs. Symptoms include shortness of breath, fatigue, and fluid retention.'),
                ('Stroke', 'occurs when blood supply to part of the brain is interrupted, resulting in brain cell death. There are two main types: ischemic and hemorrhagic stroke.'),
                ('Hypertension', 'or high blood pressure, is a condition where blood pressure in arteries is persistently elevated. It is often called the silent killer as it typically has no symptoms.'),
                ('Atrial fibrillation', 'is an irregular and often rapid heart rate that can increase risk of stroke and heart failure. Treatment may include medications or procedures.')
            ],
            'endocrine': [
                ('Diabetes mellitus', 'is a group of disorders characterized by high blood sugar levels. Type 1 diabetes results from autoimmune destruction of insulin-producing cells.'),
                ('Hypothyroidism', 'occurs when the thyroid gland does not produce enough thyroid hormone. Symptoms include fatigue, weight gain, and cold intolerance.'),
                ('Hyperthyroidism', 'is a condition where the thyroid gland produces too much thyroid hormone. Symptoms include weight loss, rapid heartbeat, and anxiety.'),
                ('Metabolic syndrome', 'is a cluster of conditions including high blood pressure, high blood sugar, excess abdominal fat, and abnormal cholesterol levels.')
            ],
            'respiratory': [
                ('Pneumonia', 'is an inflammatory condition of the lung affecting primarily the alveoli. It can be caused by bacteria, viruses, or fungi.'),
                ('Asthma', 'is a respiratory condition marked by attacks of spasm in the bronchi, causing difficulty breathing. Triggers include allergens and irritants.'),
                ('COPD', 'or chronic obstructive pulmonary disease, is a progressive disease that makes breathing difficult. It includes emphysema and chronic bronchitis.'),
                ('Pulmonary embolism', 'is a blockage in pulmonary arteries, usually caused by blood clots that travel from legs or other parts of the body.')
            ],
            'neurological': [
                ('Alzheimer disease', 'is a progressive neurodegenerative disorder that affects memory, thinking, and behavior. It is the most common cause of dementia.'),
                ('Parkinson disease', 'is a neurodegenerative disorder affecting movement. Symptoms include tremor, rigidity, and difficulty with balance and coordination.'),
                ('Epilepsy', 'is a neurological disorder characterized by recurrent seizures. Treatment typically involves antiepileptic medications.'),
                ('Multiple sclerosis', 'is an autoimmune disease affecting the central nervous system. It damages the protective covering of nerve fibers.')
            ],
            'infectious': [
                ('Sepsis', 'is a life-threatening response to infection that occurs when chemicals released into bloodstream trigger inflammation throughout the body.'),
                ('COVID-19', 'is an infectious disease caused by SARS-CoV-2 virus. Symptoms range from mild respiratory illness to severe pneumonia.'),
                ('Influenza', 'is a viral infection that attacks respiratory system. Annual vaccination is recommended for prevention.'),
                ('Tuberculosis', 'is an infectious disease caused by Mycobacterium tuberculosis that primarily affects the lungs.')
            ],
            'gastrointestinal': [
                ('Inflammatory bowel disease', 'includes Crohn\'s disease and ulcerative colitis, both chronic inflammatory conditions of the digestive tract.'),
                ('Peptic ulcer disease', 'involves sores that develop on the lining of stomach or small intestine, often caused by H. pylori infection.'),
                ('Cirrhosis', 'is scarring of the liver caused by long-term liver damage. Common causes include alcohol abuse and hepatitis.'),
                ('Gastroesophageal reflux disease', 'occurs when stomach acid frequently flows back into the esophagus, causing heartburn and potential complications.')
            ],
            'oncology': [
                ('Breast cancer', 'is cancer that develops in breast tissue. Treatment may include surgery, chemotherapy, radiation therapy, and targeted therapy.'),
                ('Lung cancer', 'is the leading cause of cancer deaths worldwide. Smoking is the primary risk factor for developing lung cancer.'),
                ('Colorectal cancer', 'develops in the colon or rectum. Screening with colonoscopy can help detect and prevent this cancer.'),
                ('Prostate cancer', 'is cancer of the prostate gland in men. It is often slow-growing and may not cause symptoms initially.')
            ],
            'psychiatric': [
                ('Major depressive disorder', 'is a mental health condition characterized by persistent sadness and loss of interest in activities.'),
                ('Anxiety disorders', 'are a group of mental health conditions characterized by excessive fear, worry, and related behavioral disturbances.'),
                ('Bipolar disorder', 'is a mental health condition that causes extreme mood swings including emotional highs and lows.'),
                ('Schizophrenia', 'is a chronic mental health disorder affecting thinking, perception, emotions, language, and behavior.')
            ]
        }
        
        # Clinical presentation and treatment templates
        clinical_templates = [
            "{condition} typically presents with {symptoms}. Diagnosis is made through {diagnostic_methods}. Treatment options include {treatments}. Prognosis varies depending on {prognostic_factors}.",
            "Patients with {condition} often experience {symptoms}. Risk factors include {risk_factors}. Management involves {management_approach}. Complications may include {complications}.",
            "{condition} is characterized by {pathophysiology}. Clinical manifestations include {manifestations}. Therapeutic interventions encompass {interventions}. Patient education focuses on {education_points}."
        ]
        
        # Medical vocabulary for templates
        clinical_vocab = {
            'symptoms': [
                'fatigue and weakness', 'shortness of breath', 'chest pain',
                'abdominal discomfort', 'headache and dizziness', 'joint pain and stiffness',
                'nausea and vomiting', 'changes in appetite', 'sleep disturbances'
            ],
            'diagnostic_methods': [
                'clinical evaluation and laboratory tests', 'imaging studies and biopsies',
                'physical examination and patient history', 'specialized testing and consultations'
            ],
            'treatments': [
                'pharmacological therapy and lifestyle modifications', 'surgical intervention when indicated',
                'supportive care and symptom management', 'multidisciplinary treatment approach'
            ],
            'risk_factors': [
                'age, gender, and genetic predisposition', 'environmental exposures and lifestyle factors',
                'comorbid conditions and medication effects', 'occupational and behavioral risks'
            ],
            'management_approach': [
                'comprehensive medical care', 'coordinated specialty treatment',
                'patient-centered care planning', 'evidence-based therapeutic protocols'
            ]
        }
        
        medical_articles = []
        
        # Generate articles for each medical condition
        for specialty, conditions in medical_conditions.items():
            for condition, base_description in conditions:
                # Base article
                article = f"{condition} {base_description}"
                medical_articles.append(article)
                
                # Generate additional clinical content
                for template in clinical_templates:
                    clinical_article = template.format(
                        condition=condition,
                        symptoms=random.choice(clinical_vocab['symptoms']),
                        diagnostic_methods=random.choice(clinical_vocab['diagnostic_methods']),
                        treatments=random.choice(clinical_vocab['treatments']),
                        prognostic_factors='disease severity and patient response to treatment',
                        risk_factors=random.choice(clinical_vocab['risk_factors']),
                        management_approach=random.choice(clinical_vocab['management_approach']),
                        complications='organ dysfunction and quality of life impact',
                        pathophysiology='complex molecular and cellular mechanisms',
                        manifestations=random.choice(clinical_vocab['symptoms']),
                        interventions=random.choice(clinical_vocab['treatments']),
                        education_points='disease understanding and self-management strategies'
                    )
                    medical_articles.append(clinical_article)
        
        # Add general medical content
        general_medical_topics = [
            "Medical diagnosis involves systematic evaluation of patient symptoms, physical examination findings, and diagnostic test results to identify underlying pathology.",
            "Preventive medicine focuses on disease prevention through vaccination, screening programs, lifestyle counseling, and risk factor modification.",
            "Emergency medicine provides immediate care for acute illnesses and injuries, emphasizing rapid assessment and stabilization of critically ill patients.",
            "Pharmacotherapy requires careful consideration of drug interactions, adverse effects, contraindications, and patient-specific factors.",
            "Surgical intervention may be necessary when conservative management fails or when anatomical correction is required for optimal patient outcomes.",
            "Rehabilitation medicine helps patients recover function and independence following illness, injury, or surgical procedures through comprehensive therapy programs.",
            "Palliative care focuses on symptom management and quality of life improvement for patients with serious illnesses.",
            "Medical ethics guides healthcare decision-making through principles of autonomy, beneficence, non-maleficence, and justice."
        ]
        
        medical_articles.extend(general_medical_topics)
        
        # Shuffle and expand if needed
        random.shuffle(medical_articles)
        while len(medical_articles) < 1000:
            medical_articles.append(random.choice(medical_articles))
        
        output_path = self.output_dir / "medical_wikipedia_training.txt"
        
        with open(output_path, 'w', encoding='utf-8') as f:
            for article in medical_articles:
                f.write(article + '\n')
        
        logger.info(f"Created diverse medical encyclopedia dataset with {len(medical_articles)} articles: {output_path}")
        return output_path
    
    def combine_datasets(self, dataset_paths: List[Path], output_name: str = "combined_medical_training.txt") -> Path:
        """
        Combine multiple datasets into a single training file.
        """
        logger.info("Combining datasets...")
        
        output_path = self.output_dir / output_name
        all_texts = []
        
        for dataset_path in dataset_paths:
            if dataset_path.exists():
                with open(dataset_path, 'r', encoding='utf-8') as f:
                    texts = [line.strip() for line in f if line.strip()]
                    all_texts.extend(texts)
                    logger.info(f"Added {len(texts)} texts from {dataset_path.name}")
        
        # Remove duplicates and shuffle
        unique_texts = list(set(all_texts))
        import random
        random.shuffle(unique_texts)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            for text in unique_texts:
                f.write(text + '\n')
        
        logger.info(f"Combined dataset created with {len(unique_texts)} unique texts: {output_path}")
        return output_path


def main():
    """Main function for command line usage."""
    parser = argparse.ArgumentParser(description='Download medical datasets for MedCAT training')
    parser.add_argument('--output-dir', type=Path, default=Path('./datasets'),
                       help='Output directory for datasets')
    parser.add_argument('--email', type=str, help='Email for NCBI API (recommended)')
    parser.add_argument('--max-abstracts', type=int, default=10000,
                       help='Maximum PubMed abstracts to download')
    parser.add_argument('--max-trials', type=int, default=5000,
                       help='Maximum clinical trials to download')
    parser.add_argument('--comprehensive', action='store_true',
                       help='Use comprehensive medical search terms (covers all major domains)')
    parser.add_argument('--retry-failed', type=str,
                       help='Retry specific failed terms (comma-separated)')
    parser.add_argument('--datasets', nargs='+', 
                       choices=['pubmed', 'clinical_trials', 'mtsamples', 'wikipedia', 'all'],
                       default=['all'], help='Datasets to download')
    
    args = parser.parse_args()
    
    downloader = MedicalDatasetDownloader(args.output_dir)
    dataset_paths = []
    
    if 'all' in args.datasets or 'pubmed' in args.datasets:
        # Handle retry of specific terms
        retry_terms = None
        if args.retry_failed:
            retry_terms = [term.strip() for term in args.retry_failed.split(',')]
        
        path = downloader.download_pubmed_abstracts(
            search_terms=retry_terms,
            max_abstracts=args.max_abstracts,
            email=args.email,
            comprehensive_search=args.comprehensive
        )
        dataset_paths.append(path)
    
    if 'all' in args.datasets or 'clinical_trials' in args.datasets:
        path = downloader.download_clinical_trials_data(max_studies=args.max_trials)
        dataset_paths.append(path)
    
    if 'all' in args.datasets or 'mtsamples' in args.datasets:
        path = downloader.download_mtsamples()
        dataset_paths.append(path)
    
    if 'all' in args.datasets or 'wikipedia' in args.datasets:
        path = downloader.create_medical_wikipedia_dataset()
        dataset_paths.append(path)
    
    # Combine all datasets
    if len(dataset_paths) > 1:
        combined_path = downloader.combine_datasets(dataset_paths)
        print(f"\n✅ Combined training dataset ready: {combined_path}")
    elif len(dataset_paths) == 1:
        print(f"\n✅ Training dataset ready: {dataset_paths[0]}")
    
    print(f"\n📁 All datasets saved to: {args.output_dir}")


if __name__ == '__main__':
    main()