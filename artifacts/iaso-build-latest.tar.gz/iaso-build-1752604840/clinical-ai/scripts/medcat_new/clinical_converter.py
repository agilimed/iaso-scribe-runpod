#!/usr/bin/env python3
"""
Convert research abstracts to clinical note style for MedCAT training.
"""

import re
import random
import argparse
from pathlib import Path
from typing import List, Dict
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ClinicalTextConverter:
    """Convert research abstracts to clinical documentation style."""
    
    def __init__(self):
        # Clinical note templates
        self.note_templates = [
            # Chief Complaint & HPI templates
            "{age} year old {gender} with history of {conditions} presents with {symptoms}.",
            "Patient is a {age} year old {gender} with PMH significant for {conditions} who presents to ED with {symptoms}.",
            "{age} y/o {gender} with {conditions} admitted for {chief_complaint}.",
            
            # Assessment templates  
            "Physical examination reveals {findings}.",
            "Assessment: {diagnosis}. Plan: {treatment}.",
            "Patient diagnosed with {diagnosis} and started on {medications}.",
            "Clinical presentation consistent with {diagnosis}.",
            
            # Progress note templates
            "Patient reports {symptoms}. Vital signs stable.",
            "Overnight patient had {events}. Current condition {status}.",
            "Plan to continue {medications} and monitor {parameters}.",
            
            # Discharge templates
            "Patient discharged home on {medications} with follow-up in {timeframe}.",
            "Discharge planning includes {instructions}.",
        ]
        
        # Medical term mappings for clinical style
        self.clinical_mappings = {
            # Conditions
            'myocardial infarction': ['MI', 'heart attack', 'STEMI', 'NSTEMI'],
            'acute coronary syndrome': ['ACS', 'acute MI'],
            'heart failure': ['CHF', 'congestive heart failure', 'HF'],
            'hypertension': ['HTN', 'high blood pressure'],
            'diabetes mellitus': ['DM', 'diabetes', 'T2DM'],
            'chronic obstructive pulmonary disease': ['COPD'],
            'atrial fibrillation': ['A-fib', 'AF'],
            'coronary artery disease': ['CAD'],
            'cerebrovascular accident': ['CVA', 'stroke'],
            
            # Symptoms
            'chest pain': ['CP', 'chest discomfort', 'substernal pain'],
            'shortness of breath': ['SOB', 'dyspnea'],
            'difficulty breathing': ['DOE', 'dyspnea on exertion'],
            'abdominal pain': ['abd pain'],
            
            # Procedures
            'percutaneous coronary intervention': ['PCI'],
            'coronary angiography': ['cardiac cath', 'catheterization'],
            'electrocardiogram': ['ECG', 'EKG'],
            'echocardiogram': ['echo'],
            
            # Medications
            'beta-blocker': ['metoprolol', 'atenolol'],
            'ACE inhibitor': ['lisinopril', 'enalapril'],
            'statin': ['atorvastatin', 'simvastatin'],
        }
        
        # Clinical demographics
        self.demographics = {
            'ages': list(range(25, 90)),
            'genders': ['male', 'female', 'M', 'F'],
        }
        
        # Common clinical abbreviations
        self.abbreviations = {
            'past medical history': 'PMH',
            'history of present illness': 'HPI',
            'chief complaint': 'CC',
            'review of systems': 'ROS',
            'physical examination': 'PE',
            'emergency department': 'ED',
            'intensive care unit': 'ICU',
            'blood pressure': 'BP',
            'heart rate': 'HR',
            'respiratory rate': 'RR',
            'temperature': 'T',
        }
    
    def extract_medical_concepts(self, text: str) -> Dict[str, List[str]]:
        """Extract medical concepts from research text."""
        concepts = {
            'conditions': [],
            'symptoms': [],
            'medications': [],
            'procedures': [],
            'findings': []
        }
        
        text_lower = text.lower()
        
        # Extract conditions
        condition_patterns = [
            r'(myocardial infarction|heart failure|diabetes|hypertension|stroke|cancer|pneumonia)',
            r'(coronary artery disease|atrial fibrillation|COPD|asthma)',
            r'(acute coronary syndrome|heart attack)'
        ]
        
        for pattern in condition_patterns:
            matches = re.findall(pattern, text_lower)
            concepts['conditions'].extend(matches)
        
        # Extract symptoms
        symptom_patterns = [
            r'(chest pain|shortness of breath|dyspnea|abdominal pain)',
            r'(nausea|vomiting|dizziness|fatigue|weakness)'
        ]
        
        for pattern in symptom_patterns:
            matches = re.findall(pattern, text_lower)
            concepts['symptoms'].extend(matches)
        
        # Extract medications
        medication_patterns = [
            r'(statin|beta.?blocker|ACE inhibitor|aspirin)',
            r'(metoprolol|atorvastatin|lisinopril|warfarin)',
            r'(PCSK9 inhibitor|antibiotic|insulin)'
        ]
        
        for pattern in medication_patterns:
            matches = re.findall(pattern, text_lower)
            concepts['medications'].extend(matches)
        
        return concepts
    
    def convert_to_clinical_style(self, text: str) -> List[str]:
        """Convert research abstract to clinical note style."""
        clinical_notes = []
        
        # Extract medical concepts
        concepts = self.extract_medical_concepts(text)
        
        # Generate clinical notes using templates
        if concepts['conditions'] or concepts['symptoms']:
            # Chief complaint / HPI
            age = random.choice(self.demographics['ages'])
            gender = random.choice(self.demographics['genders'])
            
            if concepts['conditions'] and concepts['symptoms']:
                note = f"{age} year old {gender} with history of {', '.join(concepts['conditions'][:2])} presents with {', '.join(concepts['symptoms'][:2])}."
                clinical_notes.append(note)
            
            # Assessment and plan
            if concepts['conditions']:
                diagnosis = concepts['conditions'][0]
                note = f"Assessment: {diagnosis}."
                if concepts['medications']:
                    note += f" Plan: Start {concepts['medications'][0]}."
                clinical_notes.append(note)
        
        # Convert specific research language to clinical
        clinical_text = self.research_to_clinical_language(text)
        if clinical_text:
            clinical_notes.append(clinical_text)
        
        return clinical_notes
    
    def research_to_clinical_language(self, text: str) -> str:
        """Convert research language patterns to clinical language."""
        # Remove research-specific phrases
        research_patterns = [
            r'This study aimed to investigate',
            r'The purpose of this study',
            r'We analyzed',
            r'Results showed',
            r'In conclusion',
            r'These findings suggest'
        ]
        
        clinical_text = text
        for pattern in research_patterns:
            clinical_text = re.sub(pattern + r'[^.]*\.', '', clinical_text, flags=re.IGNORECASE)
        
        # Convert to clinical language
        conversions = {
            r'patients with (.+?) were': r'patient with \1 was',
            r'(\d+) patients': r'patient',
            r'study participants': 'patient',
            r'The patient population': 'Patient',
            r'demonstrated': 'showed',
            r'exhibited': 'had',
            r'were administered': 'received',
        }
        
        for pattern, replacement in conversions.items():
            clinical_text = re.sub(pattern, replacement, clinical_text, flags=re.IGNORECASE)
        
        # Add clinical abbreviations
        for full_term, abbrev in self.abbreviations.items():
            if random.random() < 0.3:  # 30% chance to use abbreviation
                clinical_text = clinical_text.replace(full_term, abbrev)
        
        return clinical_text.strip()
    
    def process_file(self, input_path: Path, output_path: Path) -> None:
        """Process research abstracts file and create clinical-style training data."""
        logger.info(f"Converting research abstracts to clinical style: {input_path}")
        
        clinical_notes = []
        
        with open(input_path, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                
                # Convert each abstract
                converted_notes = self.convert_to_clinical_style(line)
                clinical_notes.extend(converted_notes)
                
                if line_num % 100 == 0:
                    logger.info(f"Processed {line_num} abstracts, generated {len(clinical_notes)} clinical notes")
        
        # Remove duplicates and empty notes
        unique_notes = list(set([note for note in clinical_notes if len(note.strip()) > 20]))
        
        # Write clinical notes
        with open(output_path, 'w', encoding='utf-8') as f:
            for note in unique_notes:
                f.write(note + '\n')
        
        logger.info(f"Generated {len(unique_notes)} clinical-style training texts: {output_path}")


def generate_synthetic_clinical_notes(output_path: Path, num_notes: int = 5000) -> None:
    """Generate synthetic clinical notes for training."""
    
    # Clinical note templates with realistic patterns
    templates = [
        # Chief complaints
        "{age} year old {gender} presents to ED with {chief_complaint}. {symptoms}. PMH significant for {conditions}.",
        
        # History of Present Illness
        "Patient reports {duration} history of {symptoms}. Associated with {associated_symptoms}. Denies {negative_symptoms}.",
        
        # Physical Exam
        "Vital signs: BP {bp}, HR {hr}, RR {rr}, T {temp}. Physical exam notable for {findings}.",
        
        # Assessment and Plan
        "Assessment: {diagnosis}. Plan: {medications}, {monitoring}, follow-up in {timeframe}.",
        
        # Progress Notes
        "Patient improved overnight. {current_status}. Continue current medications. Plan for discharge tomorrow.",
        
        # Discharge
        "Patient discharged home in stable condition on {medications}. Follow-up with PCP in {timeframe}.",
    ]
    
    # Medical vocabulary for templates
    vocab = {
        'ages': [f"{age}" for age in range(30, 85)],
        'genders': ['male', 'female'],
        'chief_complaints': [
            'chest pain', 'shortness of breath', 'abdominal pain', 'dizziness',
            'syncope', 'palpitations', 'nausea and vomiting', 'weakness'
        ],
        'symptoms': [
            'substernal chest pressure', 'SOB on exertion', 'sharp abdominal pain',
            'intermittent dizziness', 'episodes of rapid heart rate'
        ],
        'conditions': [
            'HTN', 'DM', 'CAD', 'CHF', 'COPD', 'A-fib', 'CKD', 'obesity'
        ],
        'medications': [
            'metoprolol', 'lisinopril', 'atorvastatin', 'aspirin', 'insulin',
            'furosemide', 'warfarin', 'albuterol'
        ],
        'findings': [
            'tachycardia', 'elevated BP', 'crackles in lungs', 'irregular rhythm',
            'abdominal tenderness', 'peripheral edema'
        ],
        'diagnoses': [
            'acute MI', 'CHF exacerbation', 'pneumonia', 'UTI', 'acute gastritis',
            'hypertensive crisis', 'A-fib with RVR'
        ]
    }
    
    clinical_notes = []
    
    for _ in range(num_notes):
        template = random.choice(templates)
        
        # Fill template with random medical terms
        note = template.format(
            age=random.choice(vocab['ages']),
            gender=random.choice(vocab['genders']),
            chief_complaint=random.choice(vocab['chief_complaints']),
            symptoms=random.choice(vocab['symptoms']),
            conditions=', '.join(random.sample(vocab['conditions'], 2)),
            medications=random.choice(vocab['medications']),
            findings=random.choice(vocab['findings']),
            diagnosis=random.choice(vocab['diagnoses']),
            duration=f"{random.randint(1, 7)} day",
            timeframe=f"{random.randint(1, 4)} weeks",
            bp=f"{random.randint(110, 180)}/{random.randint(60, 100)}",
            hr=f"{random.randint(60, 120)}",
            rr=f"{random.randint(12, 24)}",
            temp=f"{random.randint(36, 39)}.{random.randint(0, 9)}",
            associated_symptoms=random.choice(vocab['symptoms']),
            negative_symptoms=random.choice(['fever', 'chills', 'night sweats']),
            current_status='pain resolved, ambulating without difficulty',
            monitoring='daily weights, I/Os'
        )
        
        clinical_notes.append(note)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        for note in clinical_notes:
            f.write(note + '\n')
    
    logger.info(f"Generated {len(clinical_notes)} synthetic clinical notes: {output_path}")


def main():
    parser = argparse.ArgumentParser(description='Convert research abstracts to clinical note style')
    parser.add_argument('input_file', type=Path, help='Input file with research abstracts')
    parser.add_argument('-o', '--output', type=Path, help='Output file for clinical notes')
    parser.add_argument('--synthetic', action='store_true', help='Generate synthetic clinical notes')
    parser.add_argument('--num-synthetic', type=int, default=5000, help='Number of synthetic notes to generate')
    
    args = parser.parse_args()
    
    if not args.output:
        args.output = args.input_file.parent / f"{args.input_file.stem}_clinical.txt"
    
    if args.synthetic:
        generate_synthetic_clinical_notes(args.output, args.num_synthetic)
    else:
        converter = ClinicalTextConverter()
        converter.process_file(args.input_file, args.output)


if __name__ == '__main__':
    main()