#!/usr/bin/env python3
"""
Standalone MedCAT Unsupervised Training Script
Run training independently with existing CDB + Vocab + Training texts
"""

import logging
from pathlib import Path
from typing import List
from medcat.cat import CAT
from medcat.cdb import CDB
from medcat.vocab import Vocab
from medcat.config import Config
from datetime import datetime
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def load_training_texts(file_path: Path) -> List[str]:
    """Load training texts from file."""
    if not file_path.exists():
        logger.error(f"Training texts file not found: {file_path}")
        return []
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            texts = [line.strip() for line in f if line.strip()]
        
        logger.info(f"Loaded {len(texts)} training texts from {file_path}")
        return texts
    except Exception as e:
        logger.error(f"Error loading training texts: {e}")
        return []

def run_unsupervised_training(model_dir: str, training_texts_file: str, 
                             output_dir: str = None, batch_size: int = 1000):
    """
    Run unsupervised training on existing MedCAT model.
    
    Args:
        model_dir: Directory containing cdb.dat, vocab.dat, config.json
        training_texts_file: Path to training texts file
        output_dir: Output directory (defaults to model_dir)
        batch_size: Number of documents to process before saving checkpoint
    """
    
    model_dir = Path(model_dir)
    output_dir = Path(output_dir) if output_dir else model_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Load model components
    logger.info("Loading MedCAT model components...")
    
    cdb_path = model_dir / 'cdb.dat'
    vocab_path = model_dir / 'vocab.dat' 
    config_path = model_dir / 'config.json'
    
    if not all(p.exists() for p in [cdb_path, vocab_path]):
        logger.error(f"Missing required files in {model_dir}")
        logger.error(f"Need: cdb.dat, vocab.dat")
        return
    
    # Load components
    cdb = CDB.load(str(cdb_path))
    vocab = Vocab.load(str(vocab_path))
    
    if config_path.exists():
        config = Config.load(str(config_path))
    else:
        logger.warning("No config.json found, creating default config")
        config = create_training_config()
    
    # Load training texts
    training_texts = load_training_texts(Path(training_texts_file))
    if not training_texts:
        logger.error("No training texts loaded")
        return
    
    # Create CAT model
    logger.info("Creating MedCAT model...")
    cat = CAT(cdb=cdb, vocab=vocab, config=config)
    
    # Print initial statistics
    logger.info(f"\n=== Initial Model Statistics ===")
    logger.info(f"CDB concepts: {len(cat.cdb.cui2names):,}")
    logger.info(f"Vocabulary size: {len(cat.vocab.vocab):,}")
    logger.info(f"Words with vectors: {len(cat.vocab.vec_index2word):,}")
    logger.info(f"Training documents: {len(training_texts):,}")
    
    # Check if CDB already has training
    trained_concepts = len([cui for cui, count in cat.cdb.cui2count_train.items() if count > 0])
    logger.info(f"Previously trained concepts: {trained_concepts:,}")
    
    # Run unsupervised training
    logger.info(f"\n=== Starting Unsupervised Training ===")
    
    try:
        # Train the model - MedCAT 1.16 API
        logger.info("Starting training with training texts...")
        cat.train(training_texts)
        
        # Save model after training
        logger.info("Training completed, saving model...")
        save_model(cat, output_dir)
        
    except KeyboardInterrupt:
        logger.info("Training interrupted by user")
        save_model(cat, output_dir)
    except Exception as e:
        logger.error(f"Training error: {e}")
        # Save model even if there was an error
        save_model(cat, output_dir)
        raise
    
    # Print final statistics
    logger.info(f"\n=== Final Model Statistics ===")
    cat.cdb.print_stats()
    
    newly_trained = len([cui for cui, count in cat.cdb.cui2count_train.items() if count > 0])
    logger.info(f"Trained concepts: {newly_trained:,} (added: {newly_trained - trained_concepts:,})")
    
    return cat

def create_training_config() -> Config:
    """Create optimized config for training."""
    config = Config()
    
    config.general['spacy_model'] = 'en_core_sci_lg'
    config.linking['train_count_threshold'] = 1
    config.linking['similarity_threshold'] = 0.3
    config.general['log_level'] = 20  # INFO level
    config.general['cntx_left'] = 15
    config.general['cntx_right'] = 15
    config.general['window_size'] = 1000000
    config.general['separator'] = '~'  # Used internally by MedCAT
    
    # Linking settings (from MedCAT 1.16 linking config)
    config.linking['calculate_dynamic_threshold'] = True
    config.linking['similarity_threshold_type'] = 'dynamic'  # MedCAT 1.16 feature
    
    # CDB maker settings (matching cdb_maker.py requirements)
    config.cdb_maker['multi_separator'] = '|'  # For CSV parsing
    config.cdb_maker['min_letters_required'] = 2
    config.cdb_maker['remove_parenthesis'] = 0
    
    # NER settings (from MedCAT 1.16 NER config)
    config.ner['min_name_len'] = 2
    config.ner['upper_case_limit_len'] = 3
    config.ner['check_upper_case_names'] = True
    config.ner['do_disambiguation'] = True
    
    # Preprocessing settings
    config.preprocessing['words_to_skip'] = set()
    config.preprocessing['keep_punct'] = set()
    
    # Version info for compatibility
    config.version = {
        'medcat_version': '1.16.0',
        'created_at': datetime.now().isoformat()
    }
    
    return config

def save_model(cat: CAT, output_dir: Path):
    """Save complete MedCAT model."""
    cat.cdb.save(str(output_dir / 'cdb.dat'))
    cat.vocab.save(str(output_dir / 'vocab.dat'))
    cat.config.save(str(output_dir / 'config.json'))
    
    logger.info(f"Model saved to: {output_dir}")

def test_model(model_dir: str, test_texts: List[str] = None):
    """Quick test of trained model."""
    if test_texts is None:
        test_texts = [
            "Patient presents with chest pain and dyspnea.",
            "History of myocardial infarction and diabetes mellitus.",
            "Administered aspirin and prescribed metoprolol."
        ]
    
    logger.info("Testing trained model...")
    cat = CAT.load_model_pack(model_dir)
    
    for text in test_texts:
        doc = cat(text)
        logger.info(f"\nText: {text}")
        logger.info("Entities found:")
        for ent in doc.ents:
            logger.info(f"  {ent.text} → {ent._.cui} (conf: {ent._.context_similarity:.3f})")

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Run MedCAT unsupervised training')
    parser.add_argument('model_dir', help='Directory with CDB, vocab, and config')
    parser.add_argument('training_texts', help='Path to training texts file')
    parser.add_argument('--output-dir', help='Output directory (default: same as model_dir)')
    parser.add_argument('--batch-size', type=int, default=1000, 
                       help='Save checkpoint every N documents')
    parser.add_argument('--test', action='store_true', help='Test model after training')
    
    args = parser.parse_args()
    
    # Run training
    cat = run_unsupervised_training(
        model_dir=args.model_dir,
        training_texts_file=args.training_texts,
        output_dir=args.output_dir,
        batch_size=args.batch_size
    )
    
    # Optional testing
    if args.test and cat:
        test_model(args.output_dir or args.model_dir)
        
    logger.info("✅ Training completed!")