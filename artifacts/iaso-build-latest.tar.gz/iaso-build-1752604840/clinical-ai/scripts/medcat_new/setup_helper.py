#!/usr/bin/env python3
"""
Setup Helper and Validation Script for UMLS to MedCAT Pipeline
"""

import os
import sys
import psycopg2
import yaml
import argparse
from pathlib import Path
from typing import Dict, List


def validate_database_connection(config: Dict) -> bool:
    """Validate database connection and UMLS schema."""
    try:
        conn = psycopg2.connect(
            host=config['host'],
            port=config.get('port', 5432),
            database=config['database'],
            user=config['user'],
            password=config['password']
        )
        
        print("✓ Database connection successful")
        
        cursor = conn.cursor()
        
        # Check if schema exists
        umls_schema = config.get('umls_schema', 'clinical_umls')
        cursor.execute("""
            SELECT schema_name 
            FROM information_schema.schemata 
            WHERE schema_name = %s
        """, (umls_schema,))
        
        if not cursor.fetchone():
            print(f"✗ UMLS schema '{umls_schema}' not found")
            return False
        
        print(f"✓ UMLS schema '{umls_schema}' found")
        
        # Check required tables
        required_tables = ['mrconso', 'mrsty', 'mrdef']
        for table in required_tables:
            cursor.execute(f"""
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = %s AND table_name = %s
            """, (umls_schema, table))
            
            if cursor.fetchone():
                print(f"✓ Table {umls_schema}.{table} found")
            else:
                print(f"✗ Table {umls_schema}.{table} not found")
                return False
        
        # Check data in main table
        cursor.execute(f"SELECT COUNT(*) FROM {umls_schema}.mrconso LIMIT 1")
        count = cursor.fetchone()[0]
        print(f"✓ MRCONSO table contains {count:,} records")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"✗ Database validation failed: {e}")
        return False


def check_python_dependencies() -> bool:
    """Check if required Python packages are installed."""
    required_packages = [
        'psycopg2',
        'pandas', 
        'yaml',
        'medcat',
        'spacy'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"✓ {package} installed")
        except ImportError:
            missing_packages.append(package)
            print(f"✗ {package} not installed")
    
    if missing_packages:
        print("\nTo install missing packages:")
        print(f"pip install {' '.join(missing_packages)}")
        return False
    
    return True


def check_spacy_model() -> bool:
    """Check if required spaCy model is installed."""
    try:
        import spacy
        nlp = spacy.load("en_core_web_md")
        print("✓ spaCy model 'en_core_web_md' installed")
        return True
    except OSError:
        print("✗ spaCy model 'en_core_web_md' not installed")
        print("To install: python -m spacy download en_core_web_md")
        return False


def generate_sample_training_texts(output_path: Path, num_samples: int = 100):
    """Generate sample medical training texts."""
    
    sample_texts = [
        "Patient presents with acute chest pain radiating to left arm.",
        "Medical history significant for hypertension and type 2 diabetes mellitus.",
        "Physical examination reveals elevated blood pressure and tachycardia.",
        "Laboratory results show elevated cardiac enzymes and hyperglycemia.",
        "ECG demonstrates ST-segment elevation consistent with myocardial infarction.",
        "Patient diagnosed with pneumonia and started on antibiotic therapy.",
        "Symptoms include fever, cough, and shortness of breath.",
        "Chest X-ray shows bilateral pulmonary infiltrates.",
        "Patient has history of chronic obstructive pulmonary disease.",
        "Blood pressure medication adjusted due to hypotension.",
        "Neurological examination reveals focal weakness in right arm.",
        "MRI brain shows acute ischemic stroke in left middle cerebral artery.",
        "Patient presents with abdominal pain and nausea.",
        "Ultrasound abdomen demonstrates gallbladder inflammation.",
        "Surgical consultation for laparoscopic cholecystectomy.",
        "Postoperative course complicated by wound infection.",
        "Antibiotic prophylaxis administered prior to surgery.",
        "Patient has known allergy to penicillin and sulfa drugs.",
        "Medication reconciliation performed on admission.",
        "Discharge planning includes follow-up with primary care physician.",
        "Patient counseled on diet modification for diabetes management.",
        "Laboratory monitoring required for liver function tests.",
        "Chronic kidney disease stage 3 with proteinuria.",
        "Dialysis access evaluation by vascular surgery.",
        "Mental status examination shows depression and anxiety.",
        "Psychiatric consultation recommended for medication management.",
        "Social work assessment for discharge planning needs.",
        "Physical therapy evaluation for mobility and strength.",
        "Occupational therapy for activities of daily living.",
        "Speech therapy for swallowing evaluation post-stroke.",
        "Nutritionist consultation for weight management.",
        "Endocrinology follow-up for diabetes control.",
        "Cardiology evaluation for heart failure management.",
        "Pulmonology consultation for chronic respiratory symptoms.",
        "Gastroenterology referral for inflammatory bowel disease.",
        "Dermatology examination for suspicious skin lesions.",
        "Ophthalmology screening for diabetic retinopathy.",
        "Orthopedic evaluation for joint pain and mobility issues.",
        "Urology consultation for benign prostatic hyperplasia.",
        "Gynecology examination for abnormal uterine bleeding.",
        "Oncology referral for suspected malignancy.",
        "Radiology interpretation shows no acute abnormalities.",
        "Pathology report confirms diagnosis of adenocarcinoma.",
        "Pharmacist consultation for drug interactions review.",
        "Case management for insurance authorization.",
        "Quality assurance review of medical documentation.",
        "Infection control measures implemented for MRSA.",
        "Patient safety incident reported and investigated.",
        "Electronic health record documentation completed.",
        "Telemedicine consultation arranged for remote monitoring.",
        "Home health services coordinated for post-discharge care.",
        "Hospice care discussion with patient and family.",
        "Advanced directive documentation reviewed and updated.",
        "Pain management consultation for chronic pain syndrome.",
        "Rehabilitation medicine evaluation for functional improvement.",
        "Pediatric consultation for congenital heart disease.",
        "Neonatal intensive care for premature infant.",
        "Emergency department evaluation for acute symptoms.",
        "Urgent care visit for minor illness or injury.",
        "Preventive care screening for cancer detection.",
        "Immunization schedule updated per CDC guidelines.",
        "Travel medicine consultation for international trip.",
        "Occupational medicine evaluation for work-related injury.",
        "Sports medicine assessment for athletic performance.",
        "Geriatric medicine evaluation for elderly patient care.",
        "Palliative care consultation for symptom management.",
        "Critical care monitoring in intensive care unit.",
        "Anesthesiology evaluation for surgical procedure.",
        "Emergency medicine assessment for trauma patient.",
        "Family medicine comprehensive annual examination.",
        "Internal medicine consultation for complex medical issues.",
        "Surgical oncology evaluation for cancer treatment.",
        "Plastic surgery consultation for reconstructive procedure.",
        "Neurosurgery evaluation for brain tumor resection.",
        "Cardiac surgery consultation for valve replacement.",
        "Orthopedic surgery for fracture repair.",
        "Vascular surgery for arterial bypass procedure.",
        "Transplant surgery evaluation for organ transplantation.",
        "Minimally invasive surgery techniques utilized.",
        "Robotic surgery performed for precise intervention.",
        "Interventional radiology procedure for vessel occlusion.",
        "Nuclear medicine scan for metabolic assessment.",
        "Magnetic resonance imaging for detailed tissue evaluation.",
        "Computed tomography for cross-sectional imaging.",
        "Ultrasound examination for real-time visualization.",
        "Electrocardiogram for cardiac rhythm assessment.",
        "Echocardiogram for heart function evaluation.",
        "Stress test for coronary artery disease screening.",
        "Pulmonary function test for respiratory assessment.",
        "Polysomnography for sleep disorder evaluation.",
        "Electroencephalogram for seizure activity monitoring.",
        "Electromyography for neuromuscular disorder diagnosis.",
        "Bone density scan for osteoporosis screening.",
        "Mammography for breast cancer detection.",
        "Colonoscopy for colorectal cancer screening.",
        "Endoscopy for gastrointestinal tract examination.",
        "Bronchoscopy for pulmonary system evaluation.",
        "Arthroscopy for joint visualization and treatment.",
        "Laparoscopy for minimally invasive abdominal surgery.",
        "Cystoscopy for urinary tract examination.",
        "Colposcopy for cervical abnormality evaluation.",
        "Dermatoscopy for skin lesion assessment.",
        "Fundoscopy for retinal examination.",
        "Otoscopy for ear canal and tympanic membrane evaluation.",
        "Rhinoscopy for nasal cavity examination.",
        "Laryngoscopy for vocal cord and throat assessment.",
        "Sigmoidoscopy for lower colon examination.",
        "Proctoscopy for rectal and anal canal evaluation.",
        "Hysteroscopy for uterine cavity visualization.",
        "Thoracoscopy for pleural space examination.",
        "Mediastinoscopy for chest cavity evaluation.",
        "Peritoneoscopy for abdominal cavity assessment.",
        "Angiography for blood vessel visualization.",
        "Cardiac catheterization for coronary artery evaluation.",
        "Electrophysiology study for arrhythmia assessment."
    ]
    
    # Extend with more samples if needed
    while len(sample_texts) < num_samples:
        sample_texts.extend(sample_texts[:min(len(sample_texts), num_samples - len(sample_texts))])
    
    with open(output_path, 'w', encoding='utf-8') as f:
        for text in sample_texts[:num_samples]:
            f.write(text + '\n')
    
    print(f"✓ Generated {num_samples} sample training texts: {output_path}")


def create_sample_config(output_path: Path):
    """Create a sample configuration file."""
    
    config = {
        'database': {
            'host': 'localhost',
            'port': 5432,
            'database': 'umls_db',
            'user': 'your_username',
            'password': 'your_password'
        },
        'umls_schema': 'clinical_umls',
        'output_dir': './medcat_models',
        'languages': ['ENG'],
        'vocabularies': [
            'SNOMEDCT_US',
            'ICD10CM',
            'ICD10PCS',
            'RXNORM',
            'LOINC',
            'MSH',
            'HPO',
            'OMIM'
        ],
        'semantic_types': [
            'T047',  # Disease or Syndrome
            'T048',  # Mental or Behavioral Dysfunction
            'T049',  # Cell or Molecular Dysfunction
            'T046',  # Pathologic Function
            'T184',  # Sign or Symptom
            'T033',  # Finding
            'T074',  # Medical Device
            'T109',  # Organic Chemical
            'T121',  # Pharmacologic Substance
            'T200'   # Clinical Drug
        ],
        'extract_relationships': True,
        'training_texts_file': './training_texts.txt',
        'unigram_table_size': 100000000
    }
    
    with open(output_path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, indent=2)
    
    print(f"✓ Created sample configuration: {output_path}")


def validate_umls_data_quality(config: Dict, sample_size: int = 1000):
    """Validate UMLS data quality and show statistics."""
    try:
        conn = psycopg2.connect(
            host=config['host'],
            port=config.get('port', 5432),
            database=config['database'],
            user=config['user'],
            password=config['password']
        )
        
        cursor = conn.cursor()
        umls_schema = config.get('umls_schema', 'clinical_umls')
        
        print(f"\n=== UMLS Data Quality Report ===")
        
        # Total concepts
        cursor.execute(f"SELECT COUNT(DISTINCT cui) FROM {umls_schema}.mrconso")
        total_concepts = cursor.fetchone()[0]
        print(f"Total unique concepts (CUIs): {total_concepts:,}")
        
        # Total terms
        cursor.execute(f"SELECT COUNT(*) FROM {umls_schema}.mrconso")
        total_terms = cursor.fetchone()[0]
        print(f"Total concept terms: {total_terms:,}")
        
        # Languages
        cursor.execute(f"SELECT lat, COUNT(*) FROM {umls_schema}.mrconso GROUP BY lat ORDER BY COUNT(*) DESC LIMIT 10")
        languages = cursor.fetchall()
        print(f"\nTop languages:")
        for lang, count in languages:
            print(f"  {lang}: {count:,}")
        
        # Vocabularies
        cursor.execute(f"SELECT sab, COUNT(*) FROM {umls_schema}.mrconso GROUP BY sab ORDER BY COUNT(*) DESC LIMIT 15")
        vocabularies = cursor.fetchall()
        print(f"\nTop vocabularies:")
        for vocab, count in vocabularies:
            print(f"  {vocab}: {count:,}")
        
        # Semantic types
        cursor.execute(f"""
            SELECT s.tui, s.sty, COUNT(*) 
            FROM {umls_schema}.mrsty s 
            JOIN {umls_schema}.mrconso c ON s.cui = c.cui 
            GROUP BY s.tui, s.sty 
            ORDER BY COUNT(*) DESC 
            LIMIT 15
        """)
        sem_types = cursor.fetchall()
        print(f"\nTop semantic types:")
        for tui, sty, count in sem_types:
            print(f"  {tui} ({sty}): {count:,}")
        
        # Sample concepts
        cursor.execute(f"""
            SELECT DISTINCT c.cui, c.str, c.sab, s.sty 
            FROM {umls_schema}.mrconso c
            LEFT JOIN {umls_schema}.mrsty s ON c.cui = s.cui
            WHERE c.lat = 'ENG' AND c.suppress != 'Y'
            ORDER BY RANDOM()
            LIMIT {sample_size}
        """)
        samples = cursor.fetchall()
        print(f"\nSample concepts ({len(samples)} random examples):")
        for cui, term, vocab, sem_type in samples[:10]:
            print(f"  {cui}: {term} ({vocab}) [{sem_type or 'No semantic type'}]")
        
        if len(samples) > 10:
            print(f"  ... and {len(samples) - 10} more")
        
        conn.close()
        
    except Exception as e:
        print(f"✗ Data quality validation failed: {e}")


def main():
    """Main setup and validation function."""
    parser = argparse.ArgumentParser(description='UMLS to MedCAT Pipeline Setup Helper')
    parser.add_argument('--config', type=Path, 
                       help='Configuration file to validate')
    parser.add_argument('--create-config', type=Path,
                       help='Create sample configuration file')
    parser.add_argument('--create-training-texts', type=Path,
                       help='Create sample training texts file')
    parser.add_argument('--num-texts', type=int, default=100,
                       help='Number of training texts to generate')
    parser.add_argument('--validate-db', action='store_true',
                       help='Validate database connection and schema')
    parser.add_argument('--check-deps', action='store_true',
                       help='Check Python dependencies')
    parser.add_argument('--data-quality', action='store_true',
                       help='Show UMLS data quality report')
    parser.add_argument('--full-check', action='store_true',
                       help='Run all validation checks')
    
    args = parser.parse_args()
    
    if args.full_check:
        args.check_deps = True
        args.validate_db = True
        args.data_quality = True
    
    print("=== UMLS to MedCAT Pipeline Setup Helper ===\n")
    
    # Check Python dependencies
    if args.check_deps:
        print("Checking Python dependencies...")
        if not check_python_dependencies():
            sys.exit(1)
        
        if not check_spacy_model():
            sys.exit(1)
        print()
    
    # Create sample configuration
    if args.create_config:
        create_sample_config(args.create_config)
        print(f"Edit {args.create_config} with your database credentials.\n")
    
    # Create sample training texts
    if args.create_training_texts:
        generate_sample_training_texts(args.create_training_texts, args.num_texts)
        print()
    
    # Load configuration for validation
    config_data = None
    if args.config:
        try:
            with open(args.config, 'r') as f:
                config_data = yaml.safe_load(f)
            print(f"✓ Configuration loaded from {args.config}")
        except Exception as e:
            print(f"✗ Failed to load configuration: {e}")
            sys.exit(1)
    
    # Validate database
    if args.validate_db:
        if not config_data:
            print("✗ Configuration required for database validation")
            sys.exit(1)
        
        print("Validating database connection...")
        if not validate_database_connection(config_data['database']):
            sys.exit(1)
        print()
    
    # Data quality report
    if args.data_quality:
        if not config_data:
            print("✗ Configuration required for data quality report")
            sys.exit(1)
        
        validate_umls_data_quality(config_data['database'])
        print()
    
    if not any([args.check_deps, args.validate_db, args.data_quality, 
                args.create_config, args.create_training_texts]):
        parser.print_help()
    else:
        print("Setup validation completed!")


if __name__ == '__main__':
    main()