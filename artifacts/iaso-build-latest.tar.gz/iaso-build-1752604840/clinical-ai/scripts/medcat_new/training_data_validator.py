#!/usr/bin/env python3
"""
Training Dataset Validation Script for MedCAT
Validates and analyzes training datasets for quality, content, and suitability.
"""

import re
import json
import argparse
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Set
from collections import Counter, defaultdict
import statistics
import pandas as pd

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class TrainingDataValidator:
    """Comprehensive validation of training datasets for MedCAT."""
    
    def __init__(self):
        """Initialize the validator with medical terminology and patterns."""
        
        # Medical terminology categories
        self.medical_terms = {
            'conditions': [
                'myocardial infarction', 'heart attack', 'diabetes', 'hypertension', 'stroke',
                'pneumonia', 'asthma', 'copd', 'heart failure', 'sepsis', 'covid', 'cancer',
                'alzheimer', 'parkinson', 'epilepsy', 'depression', 'arthritis', 'obesity',
                'anemia', 'infection', 'tumor', 'syndrome', 'disease', 'disorder', 'injury'
            ],
            'symptoms': [
                'chest pain', 'shortness of breath', 'dyspnea', 'pain', 'fever', 'headache',
                'nausea', 'vomiting', 'dizziness', 'fatigue', 'weakness', 'syncope',
                'palpitations', 'cough', 'sputum', 'bleeding', 'swelling', 'rash'
            ],
            'procedures': [
                'surgery', 'operation', 'procedure', 'catheterization', 'angioplasty',
                'biopsy', 'endoscopy', 'colonoscopy', 'ct scan', 'mri', 'x-ray', 'ultrasound',
                'ecg', 'ekg', 'echocardiogram', 'blood test', 'lab', 'examination'
            ],
            'medications': [
                'aspirin', 'metformin', 'insulin', 'lisinopril', 'atorvastatin', 'metoprolol',
                'warfarin', 'furosemide', 'prednisone', 'antibiotic', 'medication', 'drug',
                'therapy', 'treatment', 'dose', 'prescription'
            ],
            'anatomy': [
                'heart', 'lung', 'brain', 'liver', 'kidney', 'blood', 'artery', 'vein',
                'muscle', 'bone', 'skin', 'eye', 'ear', 'throat', 'stomach', 'intestine'
            ],
            'clinical_terms': [
                'patient', 'diagnosis', 'prognosis', 'clinical', 'medical', 'hospital',
                'emergency', 'acute', 'chronic', 'severe', 'mild', 'moderate', 'stable',
                'critical', 'admission', 'discharge', 'follow-up', 'consultation'
            ]
        }
        
        # Clinical patterns
        self.clinical_patterns = {
            'patient_presentations': [
                r'\b\d+[-\s]year[-\s]old\b',
                r'\bpatient\s+(?:is\s+)?(?:a\s+)?\d+\b',
                r'\bpresents?\s+with\b',
                r'\bhistory\s+of\b',
                r'\bdiagnos\w+\s+with\b',
                r'\badmitted\s+(?:for|with)\b'
            ],
            'clinical_assessments': [
                r'\bphysical\s+exam\w*\b',
                r'\bvital\s+signs?\b',
                r'\blaboratory\s+(?:studies|results|tests)\b',
                r'\bimaging\s+(?:studies|shows?)\b',
                r'\bassessment\s+(?:and\s+)?plan\b'
            ],
            'measurements': [
                r'\b\d+/\d+\s*mmhg\b',
                r'\b\d+\s*bpm\b',
                r'\b\d+\.\d+\s*mg/dl\b',
                r'\b\d+\s*°?[cf]\b',
                r'\b\d+\s*cm\b',
                r'\b\d+\s*kg\b'
            ]
        }
        
        # Quality indicators
        self.quality_indicators = {
            'good_patterns': [
                r'\bchief\s+complaint\b',
                r'\bhpi\b|\bhistory\s+of\s+present\s+illness\b',
                r'\bpmh\b|\bpast\s+medical\s+history\b',
                r'\bpe\b|\bphysical\s+exam\w*\b',
                r'\bassessment\b',
                r'\bplan\b',
                r'\bsoap\b'
            ],
            'abbreviations': [
                r'\b(?:bp|hr|rr|temp|o2)\b',
                r'\b(?:mi|uti|copd|chf|dm|htn|cad)\b',
                r'\b(?:sob|cp|nausea|n/v)\b',
                r'\b(?:er|ed|icu|or)\b'
            ]
        }
    
    def load_training_data(self, file_path: Path) -> List[str]:
        """Load training data from file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = [line.strip() for line in f if line.strip()]
            
            logger.info(f"Loaded {len(lines)} training texts from {file_path}")
            return lines
            
        except Exception as e:
            logger.error(f"Failed to load training data: {e}")
            raise
    
    def basic_statistics(self, texts: List[str]) -> Dict:
        """Calculate basic statistics about the dataset."""
        logger.info("Calculating basic statistics...")
        
        if not texts:
            return {'error': 'No texts provided'}
        
        # Text lengths
        lengths = [len(text) for text in texts]
        word_counts = [len(text.split()) for text in texts]
        
        # Character and word statistics
        total_chars = sum(lengths)
        total_words = sum(word_counts)
        
        stats = {
            'total_texts': len(texts),
            'total_characters': total_chars,
            'total_words': total_words,
            'avg_chars_per_text': statistics.mean(lengths),
            'avg_words_per_text': statistics.mean(word_counts),
            'median_chars_per_text': statistics.median(lengths),
            'median_words_per_text': statistics.median(word_counts),
            'min_chars_per_text': min(lengths),
            'max_chars_per_text': max(lengths),
            'min_words_per_text': min(word_counts),
            'max_words_per_text': max(word_counts),
            'std_chars_per_text': statistics.stdev(lengths) if len(lengths) > 1 else 0,
            'std_words_per_text': statistics.stdev(word_counts) if len(word_counts) > 1 else 0
        }
        
        return stats
    
    def analyze_medical_content(self, texts: List[str]) -> Dict:
        """Analyze medical terminology coverage."""
        logger.info("Analyzing medical content...")
        
        analysis = {
            'terminology_coverage': {},
            'total_medical_terms': 0,
            'texts_with_medical_content': 0,
            'medical_term_density': 0.0,
            'category_statistics': {}
        }
        
        all_medical_terms = set()
        for category_terms in self.medical_terms.values():
            all_medical_terms.update([term.lower() for term in category_terms])
        
        total_medical_term_count = 0
        medical_content_count = 0
        
        for category, terms in self.medical_terms.items():
            category_count = 0
            texts_with_category = 0
            
            for text in texts:
                text_lower = text.lower()
                text_has_category = False
                
                for term in terms:
                    term_count = len(re.findall(r'\b' + re.escape(term.lower()) + r'\b', text_lower))
                    category_count += term_count
                    total_medical_term_count += term_count
                    
                    if term_count > 0:
                        text_has_category = True
                
                if text_has_category:
                    texts_with_category += 1
            
            analysis['category_statistics'][category] = {
                'total_occurrences': category_count,
                'texts_with_category': texts_with_category,
                'coverage_percentage': (texts_with_category / len(texts)) * 100
            }
        
        # Count texts with any medical content
        for text in texts:
            text_lower = text.lower()
            has_medical = any(term in text_lower for term in all_medical_terms)
            if has_medical:
                medical_content_count += 1
        
        analysis['total_medical_terms'] = total_medical_term_count
        analysis['texts_with_medical_content'] = medical_content_count
        analysis['medical_content_percentage'] = (medical_content_count / len(texts)) * 100
        analysis['medical_term_density'] = total_medical_term_count / len(texts)
        
        return analysis
    
    def analyze_clinical_patterns(self, texts: List[str]) -> Dict:
        """Analyze clinical documentation patterns."""
        logger.info("Analyzing clinical patterns...")
        
        pattern_analysis = {
            'pattern_coverage': {},
            'clinical_structure_score': 0.0,
            'abbreviation_usage': 0,
            'measurement_patterns': 0
        }
        
        total_pattern_matches = 0
        
        for pattern_category, patterns in self.clinical_patterns.items():
            category_matches = 0
            texts_with_pattern = 0
            
            for text in texts:
                text_lower = text.lower()
                text_has_pattern = False
                
                for pattern in patterns:
                    matches = len(re.findall(pattern, text_lower, re.IGNORECASE))
                    category_matches += matches
                    total_pattern_matches += matches
                    
                    if matches > 0:
                        text_has_pattern = True
                
                if text_has_pattern:
                    texts_with_pattern += 1
            
            pattern_analysis['pattern_coverage'][pattern_category] = {
                'total_matches': category_matches,
                'texts_with_pattern': texts_with_pattern,
                'coverage_percentage': (texts_with_pattern / len(texts)) * 100
            }
        
        # Quality indicators
        good_pattern_matches = 0
        abbreviation_matches = 0
        
        for text in texts:
            text_lower = text.lower()
            
            # Good clinical patterns
            for pattern in self.quality_indicators['good_patterns']:
                good_pattern_matches += len(re.findall(pattern, text_lower, re.IGNORECASE))
            
            # Medical abbreviations
            for pattern in self.quality_indicators['abbreviations']:
                abbreviation_matches += len(re.findall(pattern, text_lower, re.IGNORECASE))
        
        pattern_analysis['clinical_structure_score'] = good_pattern_matches / len(texts)
        pattern_analysis['abbreviation_usage'] = abbreviation_matches / len(texts)
        pattern_analysis['total_pattern_matches'] = total_pattern_matches
        
        return pattern_analysis
    
    def detect_quality_issues(self, texts: List[str]) -> Dict:
        """Detect potential quality issues in the dataset."""
        logger.info("Detecting quality issues...")
        
        issues = {
            'duplicates': 0,
            'very_short_texts': 0,
            'very_long_texts': 0,
            'non_medical_texts': 0,
            'encoding_issues': 0,
            'empty_or_whitespace': 0,
            'repetitive_content': 0,
            'quality_score': 0.0,
            'issues_found': []
        }
        
        # Check for duplicates
        text_counts = Counter(texts)
        duplicates = sum(1 for count in text_counts.values() if count > 1)
        issues['duplicates'] = duplicates
        
        # Length thresholds
        min_length_threshold = 20
        max_length_threshold = 5000
        
        # Medical content threshold
        medical_keywords = ['patient', 'medical', 'clinical', 'diagnosis', 'treatment', 'hospital', 'doctor', 'symptom', 'disease']
        
        for i, text in enumerate(texts):
            text_lower = text.lower()
            
            # Very short texts
            if len(text) < min_length_threshold:
                issues['very_short_texts'] += 1
            
            # Very long texts
            if len(text) > max_length_threshold:
                issues['very_long_texts'] += 1
            
            # Non-medical content
            has_medical_keywords = any(keyword in text_lower for keyword in medical_keywords)
            if not has_medical_keywords:
                issues['non_medical_texts'] += 1
            
            # Encoding issues
            try:
                text.encode('utf-8')
            except UnicodeEncodeError:
                issues['encoding_issues'] += 1
            
            # Empty or whitespace only
            if not text.strip():
                issues['empty_or_whitespace'] += 1
            
            # Repetitive content (same text repeated multiple times)
            if text_counts[text] > 3:
                issues['repetitive_content'] += 1
        
        # Calculate quality score (0-100)
        total_issues = sum([
            issues['duplicates'],
            issues['very_short_texts'],
            issues['very_long_texts'],
            issues['non_medical_texts'],
            issues['encoding_issues'],
            issues['empty_or_whitespace'],
            issues['repetitive_content']
        ])
        
        issues['quality_score'] = max(0, 100 - (total_issues / len(texts) * 100))
        
        # Collect specific issues
        if issues['duplicates'] > 0:
            issues['issues_found'].append(f"{issues['duplicates']} duplicate texts found")
        if issues['very_short_texts'] > 0:
            issues['issues_found'].append(f"{issues['very_short_texts']} texts shorter than {min_length_threshold} characters")
        if issues['very_long_texts'] > 0:
            issues['issues_found'].append(f"{issues['very_long_texts']} texts longer than {max_length_threshold} characters")
        if issues['non_medical_texts'] > 0:
            issues['issues_found'].append(f"{issues['non_medical_texts']} texts with no medical keywords")
        
        return issues
    
    def assess_diversity(self, texts: List[str]) -> Dict:
        """Assess content diversity and vocabulary richness."""
        logger.info("Assessing content diversity...")
        
        # Tokenize all texts
        all_words = []
        all_sentences = []
        
        for text in texts:
            # Simple tokenization
            words = re.findall(r'\b\w+\b', text.lower())
            sentences = re.split(r'[.!?]+', text)
            
            all_words.extend(words)
            all_sentences.extend([s.strip() for s in sentences if s.strip()])
        
        # Vocabulary statistics
        unique_words = set(all_words)
        word_frequencies = Counter(all_words)
        
        # Sentence diversity
        unique_sentences = set(all_sentences)
        
        diversity = {
            'vocabulary_size': len(unique_words),
            'total_words': len(all_words),
            'vocabulary_richness': len(unique_words) / len(all_words) if all_words else 0,
            'unique_sentences': len(unique_sentences),
            'total_sentences': len(all_sentences),
            'sentence_diversity': len(unique_sentences) / len(all_sentences) if all_sentences else 0,
            'most_common_words': word_frequencies.most_common(20),
            'hapax_legomena': sum(1 for count in word_frequencies.values() if count == 1),
            'avg_word_frequency': statistics.mean(word_frequencies.values()) if word_frequencies else 0
        }
        
        return diversity
    
    def generate_recommendations(self, analysis_results: Dict) -> List[str]:
        """Generate recommendations based on analysis results."""
        recommendations = []
        
        # Basic statistics recommendations
        basic_stats = analysis_results['basic_statistics']
        if basic_stats['avg_words_per_text'] < 10:
            recommendations.append("⚠️  Texts are very short (avg < 10 words). Consider longer, more detailed medical texts.")
        elif basic_stats['avg_words_per_text'] > 500:
            recommendations.append("⚠️  Texts are very long (avg > 500 words). Consider breaking into shorter segments.")
        
        # Medical content recommendations
        medical_analysis = analysis_results['medical_content']
        if medical_analysis['medical_content_percentage'] < 80:
            recommendations.append("⚠️  Low medical content coverage. Ensure texts contain medical terminology.")
        
        if medical_analysis['medical_term_density'] < 2:
            recommendations.append("⚠️  Low medical term density. Add more clinical vocabulary to texts.")
        
        # Clinical patterns recommendations
        clinical_analysis = analysis_results['clinical_patterns']
        if clinical_analysis['clinical_structure_score'] < 1:
            recommendations.append("⚠️  Few clinical documentation patterns found. Add more structured clinical notes.")
        
        # Quality issues recommendations
        quality_issues = analysis_results['quality_issues']
        if quality_issues['quality_score'] < 80:
            recommendations.append("⚠️  Quality issues detected. Review and clean the dataset.")
        
        if quality_issues['duplicates'] > 0:
            recommendations.append("🔧 Remove duplicate texts to improve training diversity.")
        
        # Diversity recommendations
        diversity = analysis_results['diversity']
        if diversity['vocabulary_richness'] < 0.3:
            recommendations.append("⚠️  Low vocabulary diversity. Add more varied medical texts.")
        
        if diversity['sentence_diversity'] < 0.7:
            recommendations.append("⚠️  Low sentence diversity. Reduce repetitive content.")
        
        # Positive recommendations
        if medical_analysis['medical_content_percentage'] >= 90:
            recommendations.append("✅ Excellent medical content coverage!")
        
        if quality_issues['quality_score'] >= 90:
            recommendations.append("✅ High quality dataset!")
        
        if diversity['vocabulary_richness'] >= 0.4:
            recommendations.append("✅ Good vocabulary diversity!")
        
        if not recommendations:
            recommendations.append("✅ Dataset appears suitable for MedCAT training!")
        
        return recommendations
    
    def validate_dataset(self, file_path: Path) -> Dict:
        """Run complete validation analysis on the dataset."""
        logger.info(f"Starting comprehensive validation of: {file_path}")
        
        # Load data
        texts = self.load_training_data(file_path)
        
        if not texts:
            return {'error': 'No valid texts found in dataset'}
        
        # Run all analyses
        results = {
            'file_path': str(file_path),
            'basic_statistics': self.basic_statistics(texts),
            'medical_content': self.analyze_medical_content(texts),
            'clinical_patterns': self.analyze_clinical_patterns(texts),
            'quality_issues': self.detect_quality_issues(texts),
            'diversity': self.assess_diversity(texts)
        }
        
        # Generate recommendations
        results['recommendations'] = self.generate_recommendations(results)
        
        # Overall assessment
        results['overall_assessment'] = self.calculate_overall_score(results)
        
        return results
    
    def calculate_overall_score(self, results: Dict) -> Dict:
        """Calculate overall dataset suitability score."""
        
        # Weight factors for different aspects
        weights = {
            'medical_content': 0.3,
            'clinical_patterns': 0.2,
            'quality': 0.3,
            'diversity': 0.2
        }
        
        # Normalize scores to 0-100 scale
        medical_score = min(100, results['medical_content']['medical_content_percentage'])
        clinical_score = min(100, results['clinical_patterns']['clinical_structure_score'] * 20)
        quality_score = results['quality_issues']['quality_score']
        diversity_score = min(100, results['diversity']['vocabulary_richness'] * 250)
        
        # Calculate weighted overall score
        overall_score = (
            medical_score * weights['medical_content'] +
            clinical_score * weights['clinical_patterns'] +
            quality_score * weights['quality'] +
            diversity_score * weights['diversity']
        )
        
        # Determine suitability level
        if overall_score >= 80:
            suitability = "Excellent - Ready for training"
        elif overall_score >= 60:
            suitability = "Good - Suitable with minor improvements"
        elif overall_score >= 40:
            suitability = "Fair - Needs improvements before training"
        else:
            suitability = "Poor - Significant improvements needed"
        
        return {
            'overall_score': round(overall_score, 1),
            'suitability': suitability,
            'component_scores': {
                'medical_content': round(medical_score, 1),
                'clinical_patterns': round(clinical_score, 1),
                'quality': round(quality_score, 1),
                'diversity': round(diversity_score, 1)
            }
        }
    
    def print_validation_report(self, results: Dict):
        """Print a comprehensive validation report."""
        print("\n" + "="*70)
        print("📋 TRAINING DATASET VALIDATION REPORT")
        print("="*70)
        
        # Basic Statistics
        basic = results['basic_statistics']
        print(f"📊 Basic Statistics:")
        print(f"   • Total texts: {basic['total_texts']:,}")
        print(f"   • Total words: {basic['total_words']:,}")
        print(f"   • Average words per text: {basic['avg_words_per_text']:.1f}")
        print(f"   • Text length range: {basic['min_chars_per_text']}-{basic['max_chars_per_text']} chars")
        
        # Medical Content
        medical = results['medical_content']
        print(f"\n🏥 Medical Content Analysis:")
        print(f"   • Medical content coverage: {medical['medical_content_percentage']:.1f}%")
        print(f"   • Medical term density: {medical['medical_term_density']:.1f} terms/text")
        print(f"   • Total medical terms: {medical['total_medical_terms']:,}")
        
        print(f"   • Category breakdown:")
        for category, stats in medical['category_statistics'].items():
            print(f"     - {category.title()}: {stats['coverage_percentage']:.1f}% coverage")
        
        # Clinical Patterns
        clinical = results['clinical_patterns']
        print(f"\n📝 Clinical Pattern Analysis:")
        print(f"   • Clinical structure score: {clinical['clinical_structure_score']:.1f}")
        print(f"   • Abbreviation usage: {clinical['abbreviation_usage']:.1f} per text")
        
        for pattern_type, stats in clinical['pattern_coverage'].items():
            print(f"   • {pattern_type.replace('_', ' ').title()}: {stats['coverage_percentage']:.1f}% coverage")
        
        # Quality Issues
        quality = results['quality_issues']
        print(f"\n⚠️  Quality Assessment:")
        print(f"   • Overall quality score: {quality['quality_score']:.1f}/100")
        print(f"   • Duplicates: {quality['duplicates']}")
        print(f"   • Short texts (<20 chars): {quality['very_short_texts']}")
        print(f"   • Non-medical texts: {quality['non_medical_texts']}")
        
        if quality['issues_found']:
            print(f"   • Issues found:")
            for issue in quality['issues_found']:
                print(f"     - {issue}")
        
        # Diversity
        diversity = results['diversity']
        print(f"\n🎯 Content Diversity:")
        print(f"   • Vocabulary size: {diversity['vocabulary_size']:,} unique words")
        print(f"   • Vocabulary richness: {diversity['vocabulary_richness']:.3f}")
        print(f"   • Sentence diversity: {diversity['sentence_diversity']:.3f}")
        
        # Overall Assessment
        assessment = results['overall_assessment']
        print(f"\n🎖️  Overall Assessment:")
        print(f"   • Overall Score: {assessment['overall_score']}/100")
        print(f"   • Suitability: {assessment['suitability']}")
        
        print(f"   • Component Scores:")
        for component, score in assessment['component_scores'].items():
            print(f"     - {component.replace('_', ' ').title()}: {score}/100")
        
        # Recommendations
        print(f"\n💡 Recommendations:")
        for rec in results['recommendations']:
            print(f"   {rec}")
        
        print("="*70)
        print("✅ Validation completed!")
        print("="*70)


def main():
    """Main function for command line usage."""
    parser = argparse.ArgumentParser(description='Validate training dataset for MedCAT')
    parser.add_argument('dataset_file', type=Path, help='Path to training dataset file')
    parser.add_argument('-o', '--output', type=Path, help='Output file for detailed results (JSON)')
    parser.add_argument('--summary-only', action='store_true', help='Show only summary report')
    
    args = parser.parse_args()
    
    try:
        # Initialize validator
        validator = TrainingDataValidator()
        
        # Run validation
        results = validator.validate_dataset(args.dataset_file)
        
        if 'error' in results:
            logger.error(f"Validation failed: {results['error']}")
            return 1
        
        # Print report
        if not args.summary_only:
            validator.print_validation_report(results)
        else:
            assessment = results['overall_assessment']
            print(f"Dataset: {args.dataset_file}")
            print(f"Overall Score: {assessment['overall_score']}/100")
            print(f"Suitability: {assessment['suitability']}")
        
        # Save detailed results if requested
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            logger.info(f"Detailed results saved to: {args.output}")
        
        # Return exit code based on suitability
        if results['overall_assessment']['overall_score'] >= 60:
            return 0  # Good enough for training
        else:
            return 1  # Needs improvement
            
    except Exception as e:
        logger.error(f"Validation failed: {e}")
        return 1


if __name__ == '__main__':
    exit(main())