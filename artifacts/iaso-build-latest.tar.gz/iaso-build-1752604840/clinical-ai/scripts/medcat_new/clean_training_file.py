#!/usr/bin/env python3
"""
Training Text Cleaner for MedCAT
Extracts clean medical text from structured training data files.
"""

import re
import argparse
import logging
from pathlib import Path
from typing import List, Optional

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class MedicalTextCleaner:
    """Clean and extract medical text from structured training files."""
    
    def __init__(self):
        # Pattern to match the text column (5th column after splitting by comma)
        # Assumes format: id,date,category,field,text,other_fields...
        self.text_column_patterns = [
            r'^[^,]*,[^,]*,[^,]*,[^,]*,(.+)$',  # 5th column
            r'^[^,]*,[^,]*,[^,]*,(.+)$',        # 4th column (alternative)
        ]
        
        # Patterns to remove unwanted content
        self.cleanup_patterns = [
            # Remove metadata fields
            (r'subject_id[^,]*,?', ''),
            (r'chartdate[^,]*,?', ''),
            (r'category[^,]*,?', ''),
            (r'create_year[^,]*,?', ''),
            (r'dob_year[^,]*,?', ''),
            (r'age_year[^,]*,?', ''),
            (r'gender[^,]*,?', ''),
            (r'dob[^,]*,?', ''),
            
            # Remove dates and IDs at beginning
            (r'^\d+,\d{4}-\d{2}-\d{2},', ''),
            (r'^\d+,\d+,\d{4}-\d{2}-\d{2},', ''),
            
            # Remove quoted field names
            (r'"[^"]*":', ''),
            (r'"([^"]*)"', r'\1'),  # Remove quotes but keep content
            
            # Clean up specific medical record artifacts
            (r'HISTORY OF PRESENT ILLNESS:', 'HISTORY OF PRESENT ILLNESS:'),
            (r'CHIEF COMPLAINT:', 'CHIEF COMPLAINT:'),
            (r'REASON FOR (CONSULTATION|ADMISSION):', r'REASON FOR \1:'),
            
            # Remove excessive whitespace and formatting
            (r'\s+', ' '),
            (r'^\s+|\s+$', ''),
            
            # Remove leading/trailing commas and periods from extracted text
            (r'^[,.\s]+|[,.\s]+$', ''),
        ]
    
    def extract_text_from_line(self, line: str) -> Optional[str]:
        """
        Extract medical text from a structured line.
        
        Args:
            line: Raw line from training file
            
        Returns:
            Cleaned medical text or None if no valid text found
        """
        line = line.strip()
        if not line or line.startswith('#'):
            return None
        
        # Try different patterns to extract text column
        extracted_text = None
        for pattern in self.text_column_patterns:
            match = re.match(pattern, line)
            if match:
                extracted_text = match.group(1)
                break
        
        # If pattern matching fails, try simple column extraction
        if not extracted_text:
            parts = line.split(',')
            if len(parts) >= 5:
                # Assume text is in 5th column onwards
                extracted_text = ','.join(parts[4:])
            elif len(parts) >= 4:
                # Fallback to 4th column
                extracted_text = ','.join(parts[3:])
            else:
                return None
        
        if not extracted_text:
            return None
        
        # Clean the extracted text
        cleaned_text = self.clean_text(extracted_text)
        
        # Validate the cleaned text
        if self.is_valid_medical_text(cleaned_text):
            return cleaned_text
        
        return None
    
    def clean_text(self, text: str) -> str:
        """
        Apply cleaning patterns to extract clean medical text.
        
        Args:
            text: Raw text to clean
            
        Returns:
            Cleaned text
        """
        cleaned = text
        
        # Apply cleanup patterns
        for pattern, replacement in self.cleanup_patterns:
            cleaned = re.sub(pattern, replacement, cleaned, flags=re.IGNORECASE)
        
        # Additional cleaning
        cleaned = cleaned.strip()
        
        # Remove leading/trailing punctuation that might be artifacts
        cleaned = re.sub(r'^[,.:;]+|[,.:;]+$', '', cleaned).strip()
        
        return cleaned
    
    def is_valid_medical_text(self, text: str) -> bool:
        """
        Validate if text appears to be meaningful medical content.
        
        Args:
            text: Text to validate
            
        Returns:
            True if text appears to be valid medical content
        """
        if not text or len(text.strip()) < 10:
            return False
        
        # Check for common medical keywords
        medical_keywords = [
            'patient', 'history', 'illness', 'complaint', 'symptom', 'diagnosis',
            'treatment', 'medication', 'examination', 'consultation', 'admission',
            'discharge', 'pain', 'fever', 'infection', 'disease', 'condition',
            'procedure', 'surgery', 'therapy', 'clinical', 'medical', 'hospital',
            'doctor', 'physician', 'nurse', 'present', 'presents', 'presenting'
        ]
        
        text_lower = text.lower()
        keyword_count = sum(1 for keyword in medical_keywords if keyword in text_lower)
        
        # Require at least one medical keyword
        if keyword_count == 0:
            return False
        
        # Check for too many non-alphabetic characters (likely metadata)
        alpha_ratio = sum(c.isalpha() or c.isspace() for c in text) / len(text)
        if alpha_ratio < 0.7:
            return False
        
        return True
    
    def process_file(self, input_path: Path, output_path: Path, min_length: int = 20) -> None:
        """
        Process training file and extract clean medical texts.
        
        Args:
            input_path: Path to input training file
            output_path: Path to output cleaned file
            min_length: Minimum text length to include
        """
        logger.info(f"Processing file: {input_path}")
        
        valid_texts = []
        total_lines = 0
        valid_lines = 0
        
        try:
            with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line_num, line in enumerate(f, 1):
                    total_lines += 1
                    
                    # Extract text from line
                    cleaned_text = self.extract_text_from_line(line)
                    
                    if cleaned_text and len(cleaned_text) >= min_length:
                        valid_texts.append(cleaned_text)
                        valid_lines += 1
                    
                    # Progress logging
                    if line_num % 1000 == 0:
                        logger.info(f"Processed {line_num:,} lines, found {valid_lines:,} valid texts")
        
        except Exception as e:
            logger.error(f"Error reading file: {e}")
            return
        
        # Write cleaned texts
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                for text in valid_texts:
                    f.write(text + '\n')
            
            logger.info(f"Successfully processed {total_lines:,} lines")
            logger.info(f"Extracted {valid_lines:,} valid medical texts")
            logger.info(f"Output saved to: {output_path}")
            
        except Exception as e:
            logger.error(f"Error writing output file: {e}")
    
    def preview_extraction(self, input_path: Path, num_samples: int = 10) -> None:
        """
        Preview text extraction without writing to file.
        
        Args:
            input_path: Path to input file
            num_samples: Number of samples to show
        """
        logger.info(f"Previewing extraction from: {input_path}")
        
        samples = []
        with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line_num, line in enumerate(f, 1):
                if len(samples) >= num_samples:
                    break
                
                cleaned_text = self.extract_text_from_line(line)
                if cleaned_text:
                    samples.append((line_num, line.strip()[:100], cleaned_text))
        
        print("\n=== EXTRACTION PREVIEW ===")
        for line_num, original, cleaned in samples:
            print(f"\nLine {line_num}:")
            print(f"Original: {original}...")
            print(f"Cleaned:  {cleaned}")
            print("-" * 80)


def main():
    """Main function for command line usage."""
    parser = argparse.ArgumentParser(description='Clean medical training text files for MedCAT')
    parser.add_argument('input_file', type=Path, help='Input training text file')
    parser.add_argument('-o', '--output', type=Path, help='Output file (default: input_file_cleaned.txt)')
    parser.add_argument('--min-length', type=int, default=20, help='Minimum text length (default: 20)')
    parser.add_argument('--preview', action='store_true', help='Preview extraction without writing file')
    parser.add_argument('--samples', type=int, default=10, help='Number of preview samples (default: 10)')
    
    args = parser.parse_args()
    
    # Validate input file
    if not args.input_file.exists():
        logger.error(f"Input file not found: {args.input_file}")
        return
    
    # Set default output path
    if not args.output:
        args.output = args.input_file.parent / f"{args.input_file.stem}_cleaned.txt"
    
    # Initialize cleaner
    cleaner = MedicalTextCleaner()
    
    # Preview or process
    if args.preview:
        cleaner.preview_extraction(args.input_file, args.samples)
    else:
        cleaner.process_file(args.input_file, args.output, args.min_length)


if __name__ == '__main__':
    main()