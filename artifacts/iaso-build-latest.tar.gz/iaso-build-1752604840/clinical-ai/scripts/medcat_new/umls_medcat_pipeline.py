#!/usr/bin/env python3
"""
UMLS to MedCAT Pipeline Script - Clean Version
Extracts core UMLS concepts from PostgreSQL database and creates MedCAT CDB and Vocabulary.
Compatible with MedCAT 1.16 standards.
"""

import os
import argparse
import logging
import yaml
import pandas as pd
import psycopg2
from pathlib import Path
from typing import List, Dict, Optional, Set
from datetime import datetime

# MedCAT imports
from medcat.cdb_maker import CDBMaker
from medcat.utils.make_vocab import MakeVocab
from medcat.cat import CAT
from medcat.cdb import CDB
from medcat.config import Config


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class UMLSExtractor:
    """Extract core UMLS concepts from PostgreSQL database for MedCAT."""
    
    def __init__(self, db_config: Dict[str, str], umls_schema: str = "clinical_umls"):
        """
        Initialize UMLS PostgreSQL extractor.
        
        Args:
            db_config: Database connection configuration
            umls_schema: UMLS schema name in database
        """
        self.db_config = db_config
        self.umls_schema = umls_schema
        self.connection = None
        
    def connect(self):
        """Establish database connection."""
        try:
            self.connection = psycopg2.connect(
                host=self.db_config['host'],
                port=self.db_config.get('port', 5432),
                database=self.db_config['database'],
                user=self.db_config['user'],
                password=self.db_config['password']
            )
            logger.info("Connected to PostgreSQL database")
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            raise
    
    def disconnect(self):
        """Close database connection."""
        if self.connection:
            self.connection.close()
            logger.info("Database connection closed")
    
    def extract_core_concepts(self, 
                             languages: List[str] = ['ENG'],
                             vocabularies: Optional[List[str]] = None,
                             semantic_types: Optional[List[str]] = None,
                             limit: Optional[int] = None) -> pd.DataFrame:
        """
        Extract core UMLS concepts in clean MedCAT format.
        Simplified and optimized for large datasets.
        
        Args:
            languages: Language codes to include
            vocabularies: Vocabulary sources to include (optional filter)
            semantic_types: Semantic types to include (optional filter)  
            limit: Limit number of concepts for testing
            
        Returns:
            DataFrame with MedCAT-compatible format
        """
        logger.info("Extracting core UMLS concepts from database...")
        
        # Base query for core concept extraction
        query = f"""
        SELECT 
            m.cui,
            m.str as name,
            m.sab as source_vocab,
            CASE 
                WHEN m.ispref = 'Y' THEN 'P'
                WHEN m.ts = 'P' THEN 'P' 
                ELSE 'A'
            END as name_status,
            COALESCE(s.tui, 'T999') as semantic_type,
            COALESCE(d.def, '') as description
        FROM {self.umls_schema}.mrconso m
        LEFT JOIN {self.umls_schema}.mrsty s ON m.cui = s.cui
        LEFT JOIN {self.umls_schema}.mrdef d ON m.cui = d.cui 
            AND d.sab IN ('MSH', 'NCI', 'MTH')
            AND d.suppress != 'Y'
        WHERE m.lat IN ({','.join([f"'{lang}'" for lang in languages])})
        AND m.suppress != 'Y'
        AND LENGTH(TRIM(m.str)) >= 2
        """
        
        # Add vocabulary filter
        if vocabularies:
            vocab_filter = ','.join([f"'{vocab}'" for vocab in vocabularies])
            query += f" AND m.sab IN ({vocab_filter})"
        
        # Add semantic type filter  
        if semantic_types:
            st_filter = ','.join([f"'{st}'" for st in semantic_types])
            query += f" AND s.tui IN ({st_filter})"
        
        # Add ordering for consistent processing
        query += " ORDER BY m.cui, m.str"
        
        if limit:
            query += f" LIMIT {limit}"
        
        try:
            logger.info("Processing UMLS dataset...")
            df = pd.read_sql_query(query, self.connection)
            logger.info(f"Extracted {len(df)} UMLS concept records")
            
            # Process for MedCAT format
            processed_df = self._process_for_medcat(df)
            
            return processed_df
            
        except Exception as e:
            logger.error(f"Failed to extract UMLS concepts: {e}")
            raise
    
    def _process_for_medcat(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Process raw UMLS data to MedCAT CDB format.
        Ultra-optimized for large datasets, fully compatible with MedCAT 1.16.
        
        Args:
            df: Raw UMLS DataFrame
            
        Returns:
            Clean DataFrame ready for MedCAT CDB creation
        """
        logger.info("Processing UMLS data for MedCAT CDB format...")
        
        # Clean and standardize data efficiently
        df = df.dropna(subset=['cui', 'name'])
        df['name'] = df['name'].str.strip()
        df['cui'] = df['cui'].str.strip().str.upper()
        df['description'] = df['description'].fillna('')
        
        logger.info("Ultra-optimized grouping for large dataset...")
        
        # Create vocabulary priority for consistent selection
        vocab_priority = ['SNOMEDCT_US', 'MSH', 'ICD10CM', 'RXNORM', 'LNC', 'NCI']
        vocab_priority_map = {v: i for i, v in enumerate(vocab_priority)}
        
        df['vocab_priority'] = df['source_vocab'].map(vocab_priority_map).fillna(len(vocab_priority))
        df['is_preferred'] = (df['name_status'] == 'P').astype(int)
        
        logger.info("Aggregating data by CUI...")
        
        # Single-pass aggregation with all needed data
        def aggregate_cui_data(group):
            """Aggregate all data for a CUI in one pass."""
            # Get unique names, sorted
            unique_names = sorted(set(group['name']))
            name_string = '|'.join(unique_names)
            
            # Get best vocabulary (lowest priority number = highest priority)
            best_vocab_idx = group['vocab_priority'].idxmin()
            best_vocab = group.loc[best_vocab_idx, 'source_vocab']
            
            # Get preferred status (1 if any preferred, 0 if none)
            has_preferred = group['is_preferred'].max()
            
            # Get semantic types
            semantic_types = group['semantic_type'].astype(str)
            valid_types = sorted(set([t for t in semantic_types if t.startswith('T') and t != 'T999']))
            type_string = '|'.join(valid_types)
            
            # Get first non-empty description
            descriptions = group['description'].astype(str)
            non_empty_desc = [desc for desc in descriptions if desc.strip()]
            description = non_empty_desc[0] if non_empty_desc else ''
            
            return pd.Series({
                'name': name_string,
                'ontologies': best_vocab,
                'name_status': 'P' if has_preferred else 'A',
                'type_ids': type_string,
                'description': description
            })
        
        # Perform groupby with single custom aggregation function
        logger.info("Processing concepts...")
        grouped = df.groupby('cui').apply(aggregate_cui_data).reset_index()
        
        logger.info("Finalizing MedCAT format...")
        
        # Ensure columns are in correct order for MedCAT 1.16
        required_columns = ['cui', 'name', 'ontologies', 'name_status', 'type_ids', 'description']
        result_df = grouped[required_columns]
        
        logger.info(f"Processed {len(result_df)} unique concepts for MedCAT CDBMaker")
        
        # Log sample for verification
        if len(result_df) > 0:
            logger.info("Sample processed concept:")
            sample = result_df.iloc[0]
            for col in required_columns:
                logger.info(f"  {col}: {sample[col]}")
        
        return result_df


class MedCATBuilder:
    """Build MedCAT models from extracted UMLS concepts."""
    
    def __init__(self, output_dir: Path):
        """
        Initialize MedCAT model builder.
        
        Args:
            output_dir: Output directory for models and files
        """
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
    def create_medcat_config(self, custom_config: Optional[Dict] = None) -> Config:
        """
        Create MedCAT configuration fully compatible with MedCAT 1.16.
        Based on the actual MedCAT codebase structure.
        
        Args:
            custom_config: Optional custom configuration overrides
            
        Returns:
            MedCAT Config object compatible with 1.16
        """
        config = Config()
        
        # General settings (matching MedCAT 1.16 defaults)
        # NOTE: en_core_sci_lg is from scispacy, not standard spacy
        # MedCAT 1.16 typically uses en_core_web_md or en_core_sci_lg
        config.general['spacy_model'] = 'en_core_sci_lg'  # Scientific/medical model
        config.general['log_level'] = 20  # INFO level
        config.general['cntx_left'] = 15
        config.general['cntx_right'] = 15
        config.general['window_size'] = 1000000
        config.general['separator'] = '~'  # Used internally by MedCAT
        
        # Linking settings (from MedCAT 1.16 linking config)
        config.linking['train_count_threshold'] = 1
        config.linking['similarity_threshold'] = 0.3
        config.linking['calculate_dynamic_threshold'] = True
        config.linking['similarity_threshold_type'] = 'dynamic'  # MedCAT 1.16 feature
        
        # CDB maker settings (matching cdb_maker.py requirements)
        config.cdb_maker['multi_separator'] = '|'  # For CSV parsing
        config.cdb_maker['min_letters_required'] = 2
        config.cdb_maker['remove_parenthesis'] = 0
        
        # NER settings (from MedCAT 1.16 NER config)
        config.ner['min_name_len'] = 2
        config.ner['upper_case_limit_len'] = 3
        config.ner['check_upper_case_names'] = True
        config.ner['do_disambiguation'] = True
        
        # Preprocessing settings
        config.preprocessing['words_to_skip'] = set()
        config.preprocessing['keep_punct'] = set()
        
        # Version info for compatibility
        config.version = {
            'medcat_version': '1.16.0',
            'created_at': datetime.now().isoformat()
        }
        
        # Apply custom overrides if provided
        if custom_config:
            self._apply_config_overrides(config, custom_config)
            
        return config
    
    def _apply_config_overrides(self, config: Config, overrides: Dict):
        """Apply custom configuration overrides."""
        for section, settings in overrides.items():
            if hasattr(config, section):
                section_config = getattr(config, section)
                for key, value in settings.items():
                    section_config[key] = value
    
    def create_cdb_from_csv(self, csv_path: Path, config: Config, full_build: bool = True) -> CDB:
        """
        Create MedCAT CDB from concepts CSV.
        
        Args:
            csv_path: Path to concepts CSV file
            config: MedCAT configuration
            full_build: Whether to include additional metadata
            
        Returns:
            Created CDB
        """
        logger.info(f"Creating MedCAT CDB from: {csv_path}")
        
        # Create CDB using MedCAT's CDBMaker
        cdb_maker = CDBMaker(config=config)
        cdb = cdb_maker.prepare_csvs([str(csv_path)], full_build=full_build)
        
        # Save CDB
        cdb_path = self.output_dir / 'cdb.dat'
        cdb.save(str(cdb_path))
        logger.info(f"CDB saved to: {cdb_path}")
        
        # Print CDB statistics
        cdb.print_stats()
        
        return cdb
    
    def create_vocabulary(self, cdb: CDB, config: Config, training_texts: List[str]) -> 'Vocab':
        """
        Create MedCAT vocabulary from CDB and training texts.
        
        Args:
            cdb: MedCAT CDB
            config: MedCAT configuration  
            training_texts: Training text documents
            
        Returns:
            Created vocabulary
        """
        logger.info("Creating MedCAT vocabulary...")
        
        # Create vocabulary using MedCAT's MakeVocab
        make_vocab = MakeVocab(cdb=cdb, config=config)
        
        if training_texts and len(training_texts) > 0:
            # Create vocabulary from training texts
            make_vocab.make(training_texts, out_folder=str(self.output_dir))
            
            # Add word vectors if data.txt was created
            data_txt_path = self.output_dir / 'data.txt'
            if data_txt_path.exists():
                logger.info("Adding word vectors to vocabulary...")
                make_vocab.add_vectors(in_path=str(data_txt_path))
        else:
            logger.warning("No training texts provided - creating basic vocabulary")
            # Create minimal vocabulary from CDB only
            make_vocab.make(["Sample medical text for basic vocabulary."], 
                          out_folder=str(self.output_dir))
        
        # Save vocabulary
        vocab_path = self.output_dir / 'vocab.dat'
        make_vocab.vocab.save(str(vocab_path))
        logger.info(f"Vocabulary saved to: {vocab_path}")
        
        return make_vocab.vocab
    
    def train_unsupervised(self, cdb: CDB, vocab: 'Vocab', config: Config, 
                          training_texts: List[str]) -> CAT:
        """
        Perform unsupervised training on the MedCAT model.
        
        Args:
            cdb: MedCAT CDB
            vocab: MedCAT vocabulary
            config: MedCAT configuration
            training_texts: Training documents
            
        Returns:
            Trained MedCAT instance
        """
        if not training_texts or len(training_texts) < 2:
            logger.warning("Insufficient training texts - skipping unsupervised training")
            return CAT(cdb=cdb, vocab=vocab, config=config)
            
        logger.info(f"Starting unsupervised training with {len(training_texts)} documents...")
        
        # Create CAT instance
        cat = CAT(cdb=cdb, vocab=vocab, config=config)
        
        # Perform unsupervised training
        cat.train(training_texts)
        
        # Save updated CDB with training
        cdb_path = self.output_dir / 'cdb.dat'
        cat.cdb.save(str(cdb_path))
        logger.info("Unsupervised training completed")
        
        return cat


def load_training_texts(file_path: Path) -> List[str]:
    """Load training texts from file."""
    if not file_path.exists():
        logger.warning(f"Training texts file not found: {file_path}")
        return []
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            texts = [line.strip() for line in f if line.strip()]
        
        logger.info(f"Loaded {len(texts)} training texts from {file_path}")
        return texts
    except Exception as e:
        logger.error(f"Error loading training texts: {e}")
        return []


def main():
    """Main pipeline execution."""
    parser = argparse.ArgumentParser(description='Clean UMLS to MedCAT Pipeline')
    parser.add_argument('--config', type=Path, required=True,
                       help='YAML configuration file')
    parser.add_argument('--extract-only', action='store_true',
                       help='Only extract concepts CSV')
    parser.add_argument('--build-only', action='store_true', 
                       help='Only build models from existing CSV')
    parser.add_argument('--limit', type=int,
                       help='Limit concepts for testing')
    
    args = parser.parse_args()
    
    # Load configuration
    with open(args.config, 'r') as f:
        config_data = yaml.safe_load(f)
    
    # Setup output directory
    output_dir = Path(config_data['output_dir'])
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / 'umls_concepts.csv'
    
    # Extract UMLS concepts if needed
    if not args.build_only:
        logger.info("Starting UMLS concept extraction...")
        
        extractor = UMLSExtractor(
            db_config=config_data['database'],
            umls_schema=config_data.get('umls_schema', 'clinical_umls')
        )
        
        try:
            extractor.connect()
            
            # Extract core concepts
            df = extractor.extract_core_concepts(
                languages=config_data.get('languages', ['ENG']),
                vocabularies=config_data.get('vocabularies'),
                semantic_types=config_data.get('semantic_types'),
                limit=args.limit
            )
            
            # Save concepts CSV
            df.to_csv(csv_path, index=False)
            logger.info(f"Concepts saved to: {csv_path}")
            
        finally:
            extractor.disconnect()
    
    if args.extract_only:
        logger.info("Extraction completed.")
        return
    
    # Build MedCAT models
    if not csv_path.exists():
        logger.error(f"Concepts CSV not found: {csv_path}")
        return
    
    logger.info("Building MedCAT models...")
    
    builder = MedCATBuilder(output_dir)
    
    # Create MedCAT configuration
    medcat_config = builder.create_medcat_config(
        custom_config=config_data.get('medcat_config_overrides')
    )
    
    # Create CDB from concepts
    cdb = builder.create_cdb_from_csv(csv_path, medcat_config, full_build=True)
    
    # Load training texts
    training_texts = []
    if 'training_texts_file' in config_data:
        training_texts = load_training_texts(Path(config_data['training_texts_file']))
    
    # Create vocabulary
    vocab = builder.create_vocabulary(cdb, medcat_config, training_texts)
    
    # Unsupervised training if texts available
    if training_texts:
        cat = builder.train_unsupervised(cdb, vocab, medcat_config, training_texts)
    else:
        cat = CAT(cdb=cdb, vocab=vocab, config=medcat_config)
    
    # Save complete model pack
    model_pack_dir = output_dir / 'medcat_model_pack'
    model_pack_dir.mkdir(exist_ok=True)
    
    # Save all components
    cat.cdb.save(str(model_pack_dir / 'cdb.dat'))
    cat.vocab.save(str(model_pack_dir / 'vocab.dat'))
    medcat_config.save(str(model_pack_dir / 'config.json'))
    
    logger.info(f"Complete MedCAT model pack saved to: {model_pack_dir}")
    logger.info("Pipeline completed successfully!")
    
    # Print final statistics
    logger.info("\n=== Final Model Statistics ===")
    cat.cdb.print_stats()


if __name__ == '__main__':
    main()