# clinicalai_service/scripts/convert_to_unsupervised_format.py

import json
import sys
from pathlib import Path

def convert_training_data_to_text(json_file: str, output_file: str = None):
    """Convert our structured training data to plain text format for unsupervised training"""
    
    json_path = Path(json_file)
    if not json_path.exists():
        print(f"❌ Input file not found: {json_file}")
        return None
    
    if not output_file:
        output_file = str(json_path).replace('.json', '_texts.txt')
    
    output_path = Path(output_file)
    
    try:
        # Load the structured training data
        with open(json_path, 'r') as f:
            training_data = json.load(f)
        
        print(f"✅ Loaded {len(training_data)} training examples")
        
        # Extract just the text portions
        training_texts = []
        for example in training_data:
            text = example.get('text', '').strip()
            if text and len(text) > 10:  # Skip very short texts
                training_texts.append(text)
        
        # Remove duplicates while preserving order
        seen = set()
        unique_texts = []
        for text in training_texts:
            if text not in seen:
                seen.add(text)
                unique_texts.append(text)
        
        # Save to text file (one sentence per line)
        with open(output_path, 'w', encoding='utf-8') as f:
            for text in unique_texts:
                f.write(text + '\n')
        
        print(f"✅ Converted {len(unique_texts)} unique texts")
        print(f"📁 Saved to: {output_path}")
        
        # Show sample
        print(f"\n📋 Sample texts:")
        for i, text in enumerate(unique_texts[:5]):
            print(f"  {i+1}. {text}")
        
        return str(output_path)
        
    except Exception as e:
        print(f"❌ Conversion failed: {e}")
        return None

def main():
    """Main function"""
    if len(sys.argv) < 2:
        print("Usage: python convert_to_unsupervised_format.py <training_data.json> [output.txt]")
        return
    
    json_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    result = convert_training_data_to_text(json_file, output_file)
    
    if result:
        print(f"\n🎉 Conversion completed!")
        print(f"📄 Text file: {result}")
        print(f"\n📋 Next step:")
        print(f"python clinicalai_service/scripts/unsupervised_training.py \\")
        print(f"  clinicalai_service/models/trained_medcat_model \\")
        print(f"  {result} \\")
        print(f"  --output-dir clinicalai_service/models/retrained_medcat_model \\")
        print(f"  --test")
    else:
        print(f"\n❌ Conversion failed!")

if __name__ == "__main__":
    main()