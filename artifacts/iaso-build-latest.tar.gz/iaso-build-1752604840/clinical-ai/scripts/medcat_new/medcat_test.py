#!/usr/bin/env python3
"""
MedCAT Linker Initialization Fix - Targeted solution for the E109 error
Based on MedCAT 1.6 codebase analysis
"""

import os
import json
import time
from pathlib import Path
from typing import List, Dict, Any

# MedCAT imports
from medcat.cat import CAT  
from medcat.cdb import CDB
from medcat.vocab import Vocab
from medcat.config import Config


def fix_medcat_initialization(model_path: str) -> Dict[str, Any]:
    """
    Fix MedCAT initialization by properly setting up the linker component.
    Based on analysis of MedCAT 1.6 codebase.
    """
    print("🔧 Attempting MedCAT Initialization Fix...")
    
    results = {
        "initialization_successful": False,
        "method_used": None,
        "processing_results": [],
        "errors": []
    }
    
    try:
        # Load components
        print("📥 Loading CDB and Vocab...")
        cdb = CDB.load(str(Path(model_path) / 'cdb.dat'))
        vocab = Vocab.load(str(Path(model_path) / 'vocab.dat'))
        
        config_path = Path(model_path) / 'config.json'
        if config_path.exists():
            config = Config.load(str(config_path))
        else:
            config = Config()
        
        print("🔄 Creating CAT with initialization fix...")
        
        # Create CAT instance
        cat = CAT(cdb=cdb, vocab=vocab, config=config)
        
        # METHOD 1: Initialize the linker component explicitly
        print("🔧 Method 1: Explicit linker initialization...")
        try:
            # Access the linker component directly
            if hasattr(cat, 'linker'):
                print("✅ Found linker attribute")
                linker = cat.linker
                
                # Check if linker has an initialize method
                if hasattr(linker, 'context_model'):
                    print("✅ Found context_model in linker")
                    
                    # Initialize context model if needed
                    context_model = linker.context_model
                    if hasattr(context_model, 'model') and context_model.model is None:
                        print("🔧 Initializing context model...")
                        # This might trigger proper initialization
                        context_model.model = {}
                        
            # Try to initialize via spacy pipeline
            for name, component in cat.pipe.spacy_nlp.components:
                if name == 'cat_linker':
                    print(f"🔧 Found {name} component, attempting initialization...")
                    
                    # Method 1a: Direct initialization call
                    if hasattr(component, 'initialize'):
                        try:
                            component.initialize()
                            print(f"✅ {name} initialized via initialize() method")
                            break
                        except Exception as e:
                            print(f"⚠️ initialize() failed: {e}")
                    
                    # Method 1b: Check if component has required attributes
                    if hasattr(component, 'vocab') and hasattr(component, 'cdb'):
                        print(f"✅ {name} has required vocab and cdb attributes")
                    else:
                        print(f"⚠️ {name} missing required attributes")
                        # Try to set them
                        if not hasattr(component, 'vocab'):
                            component.vocab = vocab
                            print("🔧 Set vocab on component")
                        if not hasattr(component, 'cdb'):
                            component.cdb = cdb
                            print("🔧 Set cdb on component")
            
            # Test processing after Method 1
            test_text = "Patient has chest pain."
            print(f"🧪 Testing with Method 1: '{test_text}'")
            result = cat.get_entities(test_text)
            
            results["initialization_successful"] = True
            results["method_used"] = "explicit_linker_initialization"
            print("✅ Method 1 SUCCESS!")
            
        except Exception as method1_error:
            error_msg = f"Method 1 failed: {str(method1_error)}"
            results["errors"].append(error_msg)
            print(f"❌ {error_msg}")
        
        # METHOD 2: Bypass linker initialization by modifying config
        if not results["initialization_successful"]:
            print("🔧 Method 2: Bypass via config modification...")
            try:
                # Create new config with linking disabled during initialization
                fixed_config = Config()
                fixed_config.linking.train = False
                fixed_config.linking.calculate_dynamic_threshold = False
                fixed_config.linking.always_calculate_similarity = False
                
                # Create new CAT with fixed config
                print("🔄 Creating CAT with fixed config...")
                fixed_cat = CAT(cdb=cdb, vocab=vocab, config=fixed_config)
                
                # Test processing
                test_text = "Patient has chest pain."
                print(f"🧪 Testing with Method 2: '{test_text}'")
                result = fixed_cat.get_entities(test_text)
                
                results["initialization_successful"] = True
                results["method_used"] = "config_bypass"
                cat = fixed_cat  # Use the working CAT instance
                print("✅ Method 2 SUCCESS!")
                
            except Exception as method2_error:
                error_msg = f"Method 2 failed: {str(method2_error)}"
                results["errors"].append(error_msg)
                print(f"❌ {error_msg}")
        
        # METHOD 3: Manual component setup based on MedCAT 1.6 architecture
        if not results["initialization_successful"]:
            print("🔧 Method 3: Manual component setup...")
            try:
                # Recreate CAT with manual setup
                from medcat.linking.context_based_linker import Linker
                
                print("🔄 Creating manual linker...")
                manual_config = Config()
                manual_config.linking.train = False
                
                # Create linker manually
                manual_linker = Linker(cdb, vocab, manual_config)
                
                # Create CAT with components
                manual_cat = CAT(cdb=cdb, vocab=vocab, config=manual_config)
                
                # Replace the linker in the pipeline
                for i, (name, component) in enumerate(manual_cat.pipe.spacy_nlp.components):
                    if name == 'cat_linker':
                        # Replace with our manually created linker
                        manual_cat.pipe.spacy_nlp.components[i] = (name, manual_linker)
                        print("🔧 Replaced cat_linker component")
                        break
                
                # Test processing
                test_text = "Patient has chest pain."
                print(f"🧪 Testing with Method 3: '{test_text}'")
                result = manual_cat.get_entities(test_text)
                
                results["initialization_successful"] = True
                results["method_used"] = "manual_component_setup"
                cat = manual_cat
                print("✅ Method 3 SUCCESS!")
                
            except Exception as method3_error:
                error_msg = f"Method 3 failed: {str(method3_error)}"
                results["errors"].append(error_msg)
                print(f"❌ {error_msg}")
        
        # If we have a working CAT, test it thoroughly
        if results["initialization_successful"]:
            print("\n🎯 Testing Fixed CAT with Multiple Texts...")
            
            test_texts = [
                "Patient presents with chest pain and dyspnea.",
                "History of diabetes mellitus type 2 and hypertension.",
                "Prescribed aspirin 325mg daily for cardiovascular protection.",
                "Patient complains of severe headache and nausea."
            ]
            
            total_entities = 0
            processing_times = []
            
            for i, text in enumerate(test_texts, 1):
                try:
                    start_time = time.time()
                    result = cat.get_entities(text)
                    processing_time = time.time() - start_time
                    processing_times.append(processing_time)
                    
                    entities = result.get('entities', {})
                    entity_count = len(entities)
                    total_entities += entity_count
                    
                    test_result = {
                        "text": text,
                        "entity_count": entity_count,
                        "processing_time": processing_time,
                        "sample_entities": []
                    }
                    
                    # Get sample entities
                    for ent_id, ent in list(entities.items())[:3]:
                        test_result["sample_entities"].append({
                            "text": ent.get('source_value', ''),
                            "cui": ent.get('cui', ''),
                            "name": ent.get('pretty_name', ''),
                            "confidence": ent.get('acc', 0.0)
                        })
                    
                    results["processing_results"].append(test_result)
                    
                    print(f"✅ Text {i}: {entity_count} entities in {processing_time:.3f}s")
                    for ent in test_result["sample_entities"]:
                        print(f"   📋 '{ent['text']}' -> {ent['cui']} ({ent['name']}) [conf: {ent['confidence']:.3f}]")
                    
                except Exception as test_error:
                    error_msg = f"Processing test {i} failed: {str(test_error)}"
                    results["errors"].append(error_msg)
                    print(f"❌ {error_msg}")
            
            # Summary statistics
            if processing_times:
                avg_time = sum(processing_times) / len(processing_times)
                avg_entities = total_entities / len(processing_times)
                
                print(f"\n📊 Performance Summary:")
                print(f"   • Total entities found: {total_entities}")
                print(f"   • Average processing time: {avg_time:.3f}s")
                print(f"   • Average entities per text: {avg_entities:.1f}")
                print(f"   • Method used: {results['method_used']}")
        
    except Exception as e:
        error_msg = f"Overall initialization fix failed: {str(e)}"
        results["errors"].append(error_msg)
        print(f"❌ {error_msg}")
    
    return results


def create_working_medcat_function(model_path: str):
    """Create a reusable function that returns a working MedCAT instance"""
    print("\n🏭 Creating Reusable MedCAT Function...")
    
    # Load components once
    cdb = CDB.load(str(Path(model_path) / 'cdb.dat'))
    vocab = Vocab.load(str(Path(model_path) / 'vocab.dat'))
    
    config_path = Path(model_path) / 'config.json'
    if config_path.exists():
        config = Config.load(str(config_path))
    else:
        config = Config()
    
    # Apply the fix that worked
    config.linking.train = False
    config.linking.calculate_dynamic_threshold = False
    config.linking.always_calculate_similarity = False
    
    def get_medcat_instance():
        """Returns a working MedCAT instance"""
        return CAT(cdb=cdb, vocab=vocab, config=config)
    
    def process_text(text: str):
        """Process a single text and return entities"""
        cat = get_medcat_instance()
        return cat.get_entities(text)
    
    def process_texts(texts: List[str]):
        """Process multiple texts and return results"""
        cat = get_medcat_instance()
        results = []
        for text in texts:
            try:
                result = cat.get_entities(text)
                results.append(result)
            except Exception as e:
                results.append({"error": str(e), "text": text})
        return results
    
    # Test the functions
    print("🧪 Testing reusable functions...")
    try:
        test_result = process_text("Patient has diabetes and chest pain.")
        entity_count = len(test_result.get('entities', {}))
        print(f"✅ Reusable function works: {entity_count} entities found")
        
        # Save the working functions to a file
        function_code = '''
# Working MedCAT Functions - Generated automatically
# Use these functions to process clinical text with your MedCAT model

from medcat.cat import CAT  
from medcat.cdb import CDB
from medcat.vocab import Vocab
from medcat.config import Config
from pathlib import Path

def create_working_medcat(model_path):
    """Create a working MedCAT instance with proper initialization"""
    cdb = CDB.load(str(Path(model_path) / 'cdb.dat'))
    vocab = Vocab.load(str(Path(model_path) / 'vocab.dat'))
    
    config_path = Path(model_path) / 'config.json'
    if config_path.exists():
        config = Config.load(str(config_path))
    else:
        config = Config()
    
    # Apply initialization fix
    config.linking.train = False
    config.linking.calculate_dynamic_threshold = False
    config.linking.always_calculate_similarity = False
    
    return CAT(cdb=cdb, vocab=vocab, config=config)

def process_clinical_text(model_path, text):
    """Process a single clinical text and return entities"""
    cat = create_working_medcat(model_path)
    return cat.get_entities(text)

def process_multiple_texts(model_path, texts):
    """Process multiple clinical texts"""
    cat = create_working_medcat(model_path)
    results = []
    for text in texts:
        try:
            result = cat.get_entities(text)
            results.append(result)
        except Exception as e:
            results.append({"error": str(e), "text": text})
    return results

# Example usage:
# model_path = "./enhanced_medcat_model"
# result = process_clinical_text(model_path, "Patient has chest pain and diabetes.")
# print(f"Found {len(result['entities'])} entities")
'''
        
        with open("working_medcat_functions.py", "w") as f:
            f.write(function_code)
        
        print("💾 Saved working functions to: working_medcat_functions.py")
        
        return True
        
    except Exception as e:
        print(f"❌ Reusable function test failed: {e}")
        return False


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Fix MedCAT linker initialization")
    parser.add_argument("--model-path", default="./enhanced_medcat_model", 
                       help="Path to MedCAT model directory")
    
    args = parser.parse_args()
    
    if not Path(args.model_path).exists():
        print(f"❌ Model path not found: {args.model_path}")
        exit(1)
    
    print("🚀 MedCAT Linker Initialization Fix")
    print("=" * 50)
    
    # Run the fix
    results = fix_medcat_initialization(args.model_path)
    
    # Save detailed results
    with open("medcat_fix_results.json", "w") as f:
        json.dump(results, f, indent=2, default=str)
    
    # Summary
    print("\n📋 Fix Results Summary:")
    print("=" * 50)
    
    if results["initialization_successful"]:
        print("✅ SUCCESS: MedCAT initialization fixed!")
        print(f"🔧 Method used: {results['method_used']}")
        
        if results["processing_results"]:
            total_entities = sum(r["entity_count"] for r in results["processing_results"])
            avg_time = sum(r["processing_time"] for r in results["processing_results"]) / len(results["processing_results"])
            print(f"📊 Performance: {total_entities} entities found, {avg_time:.3f}s average")
        
        # Create reusable functions
        if create_working_medcat_function(args.model_path):
            print("🎯 READY FOR PRODUCTION: Use working_medcat_functions.py")
        
    else:
        print("❌ FAILED: Could not fix MedCAT initialization")
        if results["errors"]:
            print("🔍 Errors encountered:")
            for error in results["errors"]:
                print(f"   • {error}")
    
    print(f"\n💾 Detailed results saved to: medcat_fix_results.json")


if __name__ == "__main__":
    main()