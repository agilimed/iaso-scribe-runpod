#!/usr/bin/env python3
"""
Medical Training Data Quality Checker & Cleanup Script
Analyzes and improves quality of medical training texts for MedCAT
"""

import re
import logging
import numpy as np
from pathlib import Path
from collections import Counter, defaultdict
from typing import List, Dict, Set, Tuple
import argparse
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class MedicalDataQualityChecker:
    """Comprehensive quality checker for medical training data."""
    
    def __init__(self):
        # Medical terminology patterns
        self.medical_keywords = {
            'conditions': ['diabetes', 'hypertension', 'pneumonia', 'myocardial', 'infarction', 
                          'stroke', 'cancer', 'tumor', 'infection', 'sepsis', 'asthma', 'copd'],
            'symptoms': ['pain', 'fever', 'cough', 'dyspnea', 'nausea', 'vomiting', 'diarrhea',
                        'headache', 'fatigue', 'weakness', 'shortness', 'breath'],
            'anatomy': ['heart', 'lung', 'brain', 'liver', 'kidney', 'stomach', 'chest', 
                       'abdomen', 'cardiac', 'pulmonary', 'hepatic', 'renal'],
            'medications': ['aspirin', 'metoprolol', 'lisinopril', 'insulin', 'morphine',
                           'antibiotic', 'medication', 'drug', 'therapy', 'treatment'],
            'procedures': ['surgery', 'catheterization', 'intubation', 'biopsy', 'procedure',
                          'operation', 'examination', 'assessment', 'evaluation'],
            'clinical_terms': ['patient', 'diagnosis', 'history', 'physical', 'laboratory',
                              'vital', 'signs', 'blood', 'pressure', 'temperature']
        }
        
        # All medical keywords combined
        self.all_medical_keywords = set()
        for category in self.medical_keywords.values():
            self.all_medical_keywords.update(category)
        
        # Common stop words that should be present but not dominant
        self.stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
                          'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have',
                          'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should'}
    
    def analyze_quality(self, file_path: Path, sample_size: int = 10000) -> Dict:
        """Comprehensive quality analysis of training data."""
        logger.info(f"Analyzing quality of {file_path}")
        
        # Load data
        texts = self._load_texts(file_path, sample_size)
        if not texts:
            return {'error': 'No texts loaded'}
        
        # Run all analyses
        results = {
            'file_info': self._analyze_file_info(file_path, len(texts)),
            'vocabulary': self._analyze_vocabulary(texts),
            'content': self._analyze_content(texts),
            'medical_relevance': self._analyze_medical_relevance(texts),
            'diversity': self._analyze_diversity(texts),
            'redundancy': self._analyze_redundancy(texts),
            'quality_issues': self._identify_quality_issues(texts)
        }
        
        # Calculate overall score
        results['overall_score'] = self._calculate_overall_score(results)
        results['recommendations'] = self._generate_recommendations(results)
        
        return results
    
    def _load_texts(self, file_path: Path, sample_size: int) -> List[str]:
        """Load texts from file with sampling."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                texts = [line.strip() for line in f if line.strip()]
            
            if len(texts) > sample_size:
                # Take random sample for analysis
                import random
                texts = random.sample(texts, sample_size)
                logger.info(f"Sampled {sample_size} texts from {len(texts)} total")
            
            return texts
        except Exception as e:
            logger.error(f"Error loading texts: {e}")
            return []
    
    def _analyze_file_info(self, file_path: Path, text_count: int) -> Dict:
        """Basic file information."""
        file_size = file_path.stat().st_size / (1024 * 1024)  # MB
        return {
            'file_size_mb': round(file_size, 2),
            'total_texts': text_count,
            'avg_file_size_per_text': round(file_size / text_count * 1024, 2) if text_count > 0 else 0
        }
    
    def _analyze_vocabulary(self, texts: List[str]) -> Dict:
        """Vocabulary diversity analysis."""
        all_words = []
        for text in texts:
            words = re.findall(r'\b[a-zA-Z]+\b', text.lower())
            all_words.extend(words)
        
        if not all_words:
            return {'error': 'No words found'}
        
        word_counts = Counter(all_words)
        unique_words = len(word_counts)
        total_words = len(all_words)
        
        # Calculate diversity metrics
        type_token_ratio = unique_words / total_words if total_words > 0 else 0
        hapax_legomena = sum(1 for count in word_counts.values() if count == 1)
        hapax_ratio = hapax_legomena / unique_words if unique_words > 0 else 0
        
        # Top words analysis
        top_words = word_counts.most_common(20)
        
        return {
            'total_words': total_words,
            'unique_words': unique_words,
            'type_token_ratio': round(type_token_ratio, 4),
            'hapax_legomena_count': hapax_legomena,
            'hapax_legomena_ratio': round(hapax_ratio, 4),
            'top_words': top_words,
            'avg_word_frequency': round(total_words / unique_words, 2) if unique_words > 0 else 0
        }
    
    def _analyze_content(self, texts: List[str]) -> Dict:
        """Content quality analysis."""
        lengths = [len(text) for text in texts]
        word_counts = [len(text.split()) for text in texts]
        
        return {
            'avg_text_length': round(np.mean(lengths), 2),
            'median_text_length': round(np.median(lengths), 2),
            'std_text_length': round(np.std(lengths), 2),
            'avg_words_per_text': round(np.mean(word_counts), 2),
            'median_words_per_text': round(np.median(word_counts), 2),
            'min_text_length': min(lengths),
            'max_text_length': max(lengths),
            'texts_too_short': sum(1 for length in lengths if length < 20),
            'texts_too_long': sum(1 for length in lengths if length > 1000)
        }
    
    def _analyze_medical_relevance(self, texts: List[str]) -> Dict:
        """Medical relevance analysis."""
        medical_text_count = 0
        category_matches = defaultdict(int)
        total_medical_terms = 0
        
        for text in texts:
            text_lower = text.lower()
            text_medical_terms = 0
            
            # Check each category of medical terms
            for category, keywords in self.medical_keywords.items():
                for keyword in keywords:
                    if keyword in text_lower:
                        category_matches[category] += 1
                        text_medical_terms += text_lower.count(keyword)
            
            if text_medical_terms > 0:
                medical_text_count += 1
                total_medical_terms += text_medical_terms
        
        medical_ratio = medical_text_count / len(texts) if texts else 0
        avg_medical_terms = total_medical_terms / len(texts) if texts else 0
        
        return {
            'medical_texts': medical_text_count,
            'total_texts': len(texts),
            'medical_ratio': round(medical_ratio, 4),
            'avg_medical_terms_per_text': round(avg_medical_terms, 2),
            'category_matches': dict(category_matches),
            'total_medical_terms': total_medical_terms
        }
    
    def _analyze_diversity(self, texts: List[str]) -> Dict:
        """Text diversity analysis."""
        # Sentence starters diversity
        starters = [text.split()[0] if text.split() else '' for text in texts]
        starter_diversity = len(set(starters)) / len(starters) if starters else 0
        
        # Length diversity
        lengths = [len(text) for text in texts]
        length_diversity = np.std(lengths) / np.mean(lengths) if lengths and np.mean(lengths) > 0 else 0
        
        # Exact duplicates
        exact_duplicates = len(texts) - len(set(texts))
        
        # Near duplicates (first 50 characters)
        prefixes = [text[:50] for text in texts]
        near_duplicates = len(prefixes) - len(set(prefixes))
        
        return {
            'starter_diversity': round(starter_diversity, 4),
            'length_diversity': round(length_diversity, 4),
            'exact_duplicates': exact_duplicates,
            'near_duplicates': near_duplicates,
            'duplicate_ratio': round((exact_duplicates + near_duplicates) / len(texts), 4) if texts else 0
        }
    
    def _analyze_redundancy(self, texts: List[str]) -> Dict:
        """Redundancy and repetition analysis."""
        # Common patterns
        patterns = defaultdict(int)
        for text in texts:
            # Look for repeated phrases
            words = text.lower().split()
            for i in range(len(words) - 2):
                trigram = ' '.join(words[i:i+3])
                patterns[trigram] += 1
        
        # Most common patterns
        top_patterns = [(pattern, count) for pattern, count in patterns.items() 
                       if count > len(texts) * 0.1]  # Appears in >10% of texts
        
        return {
            'total_patterns': len(patterns),
            'repetitive_patterns': len(top_patterns),
            'top_repetitive_patterns': sorted(top_patterns, key=lambda x: x[1], reverse=True)[:10]
        }
    
    def _identify_quality_issues(self, texts: List[str]) -> Dict:
        """Identify specific quality issues."""
        issues = []
        
        # Check for empty or very short texts
        short_texts = sum(1 for text in texts if len(text.strip()) < 10)
        if short_texts > len(texts) * 0.05:  # >5% are too short
            issues.append(f"Too many short texts: {short_texts}/{len(texts)}")
        
        # Check for non-medical content
        all_text = ' '.join(texts).lower()
        medical_term_count = sum(all_text.count(term) for term in self.all_medical_keywords)
        if medical_term_count < len(texts) * 0.5:  # Less than 0.5 medical terms per text
            issues.append("Low medical content density")
        
        # Check for repetitive content
        unique_texts = len(set(texts))
        if unique_texts < len(texts) * 0.8:  # >20% duplicates
            issues.append(f"High duplication rate: {len(texts) - unique_texts} duplicates")
        
        return {
            'issues_found': len(issues),
            'issues': issues
        }
    
    def _calculate_overall_score(self, results: Dict) -> float:
        """Calculate overall quality score (0-1)."""
        scores = []
        
        # Vocabulary diversity (0-0.3)
        vocab = results.get('vocabulary', {})
        if vocab.get('type_token_ratio', 0) > 0.01:  # Good diversity
            scores.append(0.3)
        elif vocab.get('type_token_ratio', 0) > 0.005:  # Moderate diversity
            scores.append(0.2)
        else:  # Poor diversity
            scores.append(0.1)
        
        # Medical relevance (0-0.3)
        medical = results.get('medical_relevance', {})
        medical_ratio = medical.get('medical_ratio', 0)
        if medical_ratio > 0.8:
            scores.append(0.3)
        elif medical_ratio > 0.5:
            scores.append(0.2)
        else:
            scores.append(0.1)
        
        # Diversity (0-0.2)
        diversity = results.get('diversity', {})
        if diversity.get('duplicate_ratio', 1) < 0.1:
            scores.append(0.2)
        elif diversity.get('duplicate_ratio', 1) < 0.3:
            scores.append(0.1)
        else:
            scores.append(0.05)
        
        # Content quality (0-0.2)
        content = results.get('content', {})
        avg_words = content.get('avg_words_per_text', 0)
        if avg_words > 15 and avg_words < 200:
            scores.append(0.2)
        elif avg_words > 5:
            scores.append(0.1)
        else:
            scores.append(0.05)
        
        return round(sum(scores), 3)
    
    def _generate_recommendations(self, results: Dict) -> List[str]:
        """Generate actionable recommendations."""
        recommendations = []
        
        vocab = results.get('vocabulary', {})
        medical = results.get('medical_relevance', {})
        diversity = results.get('diversity', {})
        
        # Vocabulary issues
        if vocab.get('type_token_ratio', 0) < 0.01:
            recommendations.append("🚨 CRITICAL: Vocabulary diversity is extremely poor. Regenerate training data with more varied medical content.")
        
        # Medical relevance issues
        if medical.get('medical_ratio', 0) < 0.5:
            recommendations.append("⚠️ LOW medical content. Add more clinical terminology and medical concepts.")
        
        # Duplication issues
        if diversity.get('duplicate_ratio', 0) > 0.2:
            recommendations.append("🔄 HIGH duplication detected. Remove duplicate/near-duplicate texts.")
        
        # Overall quality
        score = results.get('overall_score', 0)
        if score < 0.4:
            recommendations.append("🛑 STOP TRAINING: Data quality too poor. Regenerate training corpus.")
        elif score < 0.7:
            recommendations.append("⚠️ Consider improving data quality before training.")
        else:
            recommendations.append("✅ Data quality acceptable for training.")
        
        return recommendations
    
    def cleanup_data(self, input_file: Path, output_file: Path, 
                    min_length: int = 20, max_length: int = 500,
                    min_medical_terms: int = 1) -> Dict:
        """Clean up training data based on quality criteria."""
        logger.info(f"Cleaning up data from {input_file}")
        
        with open(input_file, 'r', encoding='utf-8') as f:
            texts = [line.strip() for line in f if line.strip()]
        
        original_count = len(texts)
        cleaned_texts = []
        
        for text in texts:
            # Check length
            if not (min_length <= len(text) <= max_length):
                continue
            
            # Check medical content
            text_lower = text.lower()
            medical_count = sum(text_lower.count(term) for term in self.all_medical_keywords)
            if medical_count < min_medical_terms:
                continue
            
            # Check for basic text quality
            if len(text.split()) < 3:  # Too few words
                continue
            
            cleaned_texts.append(text)
        
        # Remove duplicates
        cleaned_texts = list(set(cleaned_texts))
        
        # Save cleaned data
        with open(output_file, 'w', encoding='utf-8') as f:
            for text in cleaned_texts:
                f.write(text + '\n')
        
        cleanup_stats = {
            'original_count': original_count,
            'cleaned_count': len(cleaned_texts),
            'removed_count': original_count - len(cleaned_texts),
            'removal_rate': round((original_count - len(cleaned_texts)) / original_count, 3) if original_count > 0 else 0
        }
        
        logger.info(f"Cleanup complete: {cleanup_stats['removed_count']} texts removed ({cleanup_stats['removal_rate']*100:.1f}%)")
        return cleanup_stats

def print_quality_report(results: Dict):
    """Print formatted quality report."""
    print("\n" + "="*80)
    print("🏥 MEDICAL TRAINING DATA QUALITY REPORT")
    print("="*80)
    
    # File info
    file_info = results.get('file_info', {})
    print(f"\n📁 FILE INFORMATION")
    print("-" * 40)
    print(f"File size: {file_info.get('file_size_mb', 0)} MB")
    print(f"Total texts: {file_info.get('total_texts', 0):,}")
    
    # Vocabulary analysis
    vocab = results.get('vocabulary', {})
    print(f"\n📚 VOCABULARY DIVERSITY")
    print("-" * 40)
    print(f"Total words: {vocab.get('total_words', 0):,}")
    print(f"Unique words: {vocab.get('unique_words', 0):,}")
    print(f"Type-Token Ratio: {vocab.get('type_token_ratio', 0):.4f}")
    print(f"Hapax Legomena Ratio: {vocab.get('hapax_legomena_ratio', 0):.4f}")
    
    # Medical relevance
    medical = results.get('medical_relevance', {})
    print(f"\n🏥 MEDICAL RELEVANCE")
    print("-" * 40)
    print(f"Medical texts: {medical.get('medical_texts', 0)}/{medical.get('total_texts', 0)}")
    print(f"Medical ratio: {medical.get('medical_ratio', 0):.3f}")
    print(f"Avg medical terms per text: {medical.get('avg_medical_terms_per_text', 0):.2f}")
    
    # Diversity
    diversity = results.get('diversity', {})
    print(f"\n🔄 CONTENT DIVERSITY")
    print("-" * 40)
    print(f"Exact duplicates: {diversity.get('exact_duplicates', 0)}")
    print(f"Near duplicates: {diversity.get('near_duplicates', 0)}")
    print(f"Duplicate ratio: {diversity.get('duplicate_ratio', 0):.3f}")
    
    # Overall score and recommendations
    score = results.get('overall_score', 0)
    print(f"\n💡 RECOMMENDATIONS")
    print("-" * 40)
    
    if score >= 0.8:
        print("🟢 Excellent data quality")
    elif score >= 0.6:
        print("🟡 Good data quality with minor issues:")
    elif score >= 0.4:
        print("🟠 Moderate data quality with issues:")
    else:
        print("🔴 Poor data quality - major issues:")
    
    recommendations = results.get('recommendations', [])
    for rec in recommendations:
        print(f"  - {rec}")
    
    print("\n" + "="*80)
    print(f"\n🎯 Overall Quality Score: {score:.3f}")
    
    if score < 0.4:
        print("🛑 STOP TRAINING - Data quality too poor")
    elif score < 0.6:
        print("⚠️  Consider data cleanup before training")
    else:
        print("✅ Data quality acceptable for training")
    
    print("="*80)

def main():
    parser = argparse.ArgumentParser(description='Medical Training Data Quality Checker')
    parser.add_argument('input_file', type=Path, help='Input training data file')
    parser.add_argument('--sample-size', type=int, default=10000, 
                       help='Sample size for analysis (default: 10000)')
    parser.add_argument('--cleanup', action='store_true', 
                       help='Perform data cleanup')
    parser.add_argument('--output-file', type=Path, 
                       help='Output file for cleaned data')
    parser.add_argument('--min-length', type=int, default=20,
                       help='Minimum text length for cleanup')
    parser.add_argument('--max-length', type=int, default=500,
                       help='Maximum text length for cleanup')
    
    args = parser.parse_args()
    
    if not args.input_file.exists():
        logger.error(f"Input file not found: {args.input_file}")
        return
    
    # Initialize checker
    checker = MedicalDataQualityChecker()
    
    # Analyze quality
    results = checker.analyze_quality(args.input_file, args.sample_size)
    
    # Print report
    print_quality_report(results)
    
    # Cleanup if requested
    if args.cleanup:
        if not args.output_file:
            args.output_file = args.input_file.parent / f"{args.input_file.stem}_cleaned.txt"
        
        cleanup_stats = checker.cleanup_data(
            args.input_file, 
            args.output_file,
            args.min_length,
            args.max_length
        )
        
        print(f"\n🧹 CLEANUP RESULTS")
        print("-" * 40)
        print(f"Original texts: {cleanup_stats['original_count']:,}")
        print(f"Cleaned texts: {cleanup_stats['cleaned_count']:,}")
        print(f"Removed: {cleanup_stats['removed_count']:,} ({cleanup_stats['removal_rate']*100:.1f}%)")
        print(f"Cleaned file: {args.output_file}")
        
        # Re-analyze cleaned data
        if args.output_file.exists():
            print(f"\n🔄 RE-ANALYZING CLEANED DATA")
            cleaned_results = checker.analyze_quality(args.output_file, args.sample_size)
            print_quality_report(cleaned_results)

if __name__ == '__main__':
    main()