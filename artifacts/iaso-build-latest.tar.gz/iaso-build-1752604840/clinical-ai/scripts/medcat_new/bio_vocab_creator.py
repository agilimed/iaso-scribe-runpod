#!/usr/bin/env python3
"""
Convert Bio-Word2Vec embeddings to MedCAT vocabulary
Handles both .bin and .txt formats
"""

import numpy as np
from pathlib import Path
from medcat.vocab import Vocab
import gensim.models
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_vocab_from_bio_embeddings(embeddings_path, output_path, min_count=5, max_words=200000):
    """
    Create MedCAT vocabulary from Bio-Word2Vec embeddings.
    
    Args:
        embeddings_path: Path to .bin or .txt embeddings file
        output_path: Path to save MedCAT vocabulary 
        min_count: Minimum word frequency to include
        max_words: Maximum vocabulary size
    """
    logger.info(f"Loading embeddings from: {embeddings_path}")
    
    vocab = Vocab()
    embeddings_path = Path(embeddings_path)
    
    try:
        if embeddings_path.suffix == '.bin':
            # Load binary Word2Vec format
            logger.info("Loading binary Word2Vec format...")
            model = gensim.models.KeyedVectors.load_word2vec_format(
                str(embeddings_path), 
                binary=True,
                limit=max_words
            )
            
            logger.info(f"Loaded {len(model.index_to_key)} word vectors")
            
            # Convert to MedCAT vocabulary
            for i, word in enumerate(model.index_to_key):
                if i % 10000 == 0:
                    logger.info(f"Processed {i:,} words...")
                
                vector = model[word].astype(np.float32)
                vocab.add_word(word, cnt=min_count, vec=vector)
                
        else:
            # Load text format
            logger.info("Loading text format...")
            with open(embeddings_path, 'r', encoding='utf-8') as f:
                # Skip header if present
                first_line = f.readline().strip()
                if len(first_line.split()) == 2:
                    vocab_size, vector_dim = map(int, first_line.split())
                    logger.info(f"Header: {vocab_size:,} words, {vector_dim}D vectors")
                else:
                    f.seek(0)
                
                word_count = 0
                for line_num, line in enumerate(f, 1):
                    if line_num % 10000 == 0:
                        logger.info(f"Processed {line_num:,} lines...")
                    
                    if word_count >= max_words:
                        break
                        
                    parts = line.strip().split()
                    if len(parts) < 50:  # Skip malformed lines
                        continue
                        
                    word = parts[0]
                    try:
                        vector = np.array([float(x) for x in parts[1:]], dtype=np.float32)
                        vocab.add_word(word, cnt=min_count, vec=vector)
                        word_count += 1
                    except (ValueError, IndexError):
                        continue
    
    except Exception as e:
        logger.error(f"Error loading embeddings: {e}")
        raise
    
    logger.info("Creating unigram table for negative sampling...")
    vocab.make_unigram_table()
    
    # Save vocabulary
    logger.info(f"Saving vocabulary to: {output_path}")
    vocab.save(str(output_path))
    
    # Print statistics
    vocab_size_mb = Path(output_path).stat().st_size / (1024 * 1024)
    logger.info(f"\n=== Medical Vocabulary Created ===")
    logger.info(f"File size: {vocab_size_mb:.1f} MB")
    logger.info(f"Total words: {len(vocab.vocab):,}")
    logger.info(f"Words with vectors: {len(vocab.vec_index2word):,}")
    logger.info(f"Vector dimension: {len(next(iter(vocab.vocab.values()))['vec'])}")
    
    return vocab

def combine_with_existing_cdb(vocab_path, cdb_path, output_dir):
    """Combine new vocabulary with existing CDB."""
    from medcat.cat import CAT
    from medcat.cdb import CDB
    from medcat.config import Config
    
    logger.info("Combining new vocabulary with existing CDB...")
    
    # Load components
    cdb = CDB.load(cdb_path)
    vocab = Vocab.load(vocab_path)
    
    # Create or load config
    config_path = Path(cdb_path).parent / 'config.json'
    if config_path.exists():
        config = Config.load(str(config_path))
    else:
        config = Config()
        config.general['spacy_model'] = 'en_core_sci_lg'
        config.linking['train_count_threshold'] = 1
        config.linking['similarity_threshold'] = 0.3
        config.general['log_level'] = 20  # INFO level
        config.general['cntx_left'] = 15
        config.general['cntx_right'] = 15
        config.general['window_size'] = 1000000
        config.general['separator'] = '~'  # Used internally by MedCAT
        
        # Linking settings (from MedCAT 1.16 linking config)
        config.linking['calculate_dynamic_threshold'] = True
        config.linking['similarity_threshold_type'] = 'dynamic'  # MedCAT 1.16 feature
        
        # CDB maker settings (matching cdb_maker.py requirements)
        config.cdb_maker['multi_separator'] = '|'  # For CSV parsing
        config.cdb_maker['min_letters_required'] = 2
        config.cdb_maker['remove_parenthesis'] = 0
        
        # NER settings (from MedCAT 1.16 NER config)
        config.ner['min_name_len'] = 2
        config.ner['upper_case_limit_len'] = 3
        config.ner['check_upper_case_names'] = True
        config.ner['do_disambiguation'] = True
        
        # Preprocessing settings
        config.preprocessing['words_to_skip'] = set()
        config.preprocessing['keep_punct'] = set()
        
        # Version info for compatibility
        config.version = {
            'medcat_version': '1.16.0',
            'created_at': datetime.now().isoformat()
        }
    
    # Create CAT model
    cat = CAT(cdb=cdb, vocab=vocab, config=config)
    
    # Save complete model
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    cat.cdb.save(str(output_dir / 'cdb.dat'))
    cat.vocab.save(str(output_dir / 'vocab.dat'))
    cat.config.save(str(output_dir / 'config.json'))
    
    logger.info(f"Complete model saved to: {output_dir}")
    
    # Print final statistics
    logger.info(f"\n=== Final Model Statistics ===")
    cat.cdb.print_stats()
    
    return cat

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Create MedCAT vocabulary from Bio embeddings')
    parser.add_argument('embeddings_file', help='Path to bio embeddings (.bin or .txt)')
    parser.add_argument('output_vocab', help='Output vocabulary file path')
    parser.add_argument('--cdb-path', help='Path to existing CDB to combine with')
    parser.add_argument('--output-dir', default='./enhanced_medcat_model', 
                       help='Output directory for complete model')
    parser.add_argument('--max-words', type=int, default=200000,
                       help='Maximum vocabulary size')
    
    args = parser.parse_args()
    
    # Create vocabulary from embeddings
    vocab = create_vocab_from_bio_embeddings(
        embeddings_path=args.embeddings_file,
        output_path=args.output_vocab,
        max_words=args.max_words
    )
    
    # Combine with existing CDB if provided
    if args.cdb_path:
        cat = combine_with_existing_cdb(
            vocab_path=args.output_vocab,
            cdb_path=args.cdb_path,
            output_dir=args.output_dir
        )
        
        logger.info("✅ Enhanced MedCAT model ready!")
        logger.info(f"Old vocab: 40MB → New vocab: {Path(args.output_vocab).stat().st_size / (1024*1024):.1f}MB")
        #python bio_vocab_creator.py embeddings/bio_embeddings.bin ./medical_vocab.dat \
  #--cdb-path ./medcat_models/cdb.dat \
  #--output-dir ./enhanced_medcat_model