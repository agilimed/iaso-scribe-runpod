# clinicalai_service/scripts/generate_medcat_training_data.py

import asyncio
import asyncpg
import json
import os
import random
from pathlib import Path
from typing import List, Dict, Any
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables
project_root = Path(__file__).parent.parent.parent
env_path = project_root / ".env"

if env_path.exists():
    load_dotenv(env_path)
    print(f"✅ Loaded .env from: {env_path}")
else:
    print("⚠️  .env file not found, using system environment variables")

async def generate_medcat_training_data():
    """Generate MedCAT training data for missed drugs from UMLS database"""
    
    print("🚀 Starting MedCAT training data generation...")
    
    # Get database config from environment
    db_config = {
        'user': os.getenv("POSTGRES_USER"),
        'password': os.getenv("POSTGRES_PASSWORD"),
        'database': os.getenv("POSTGRES_DB"), 
        'host': os.getenv("PG_HOST_SRC", "localhost"),
        'port': int(os.getenv("PG_PORT", "5432"))
    }
    
    print(f"📊 Database config:")
    print(f"  Host: {db_config['host']}:{db_config['port']}")
    print(f"  Database: {db_config['database']}")
    print(f"  User: {db_config['user']}")
    
    # Validate config
    if not all([db_config['user'], db_config['password'], db_config['database']]):
        print("❌ Missing required database configuration:")
        for key, value in db_config.items():
            if key != 'password':
                print(f"  {key}: {'✅' if value else '❌'}")
        return None
    
    # Connect to database
    try:
        conn = await asyncpg.connect(**db_config)
        print("✅ Connected to database successfully")
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        return None
    
    # Use your corrected query - but limit it for training data generation
    drugs_query = """
    SELECT DISTINCT 
        c1.concept_name as drug_name,
        c2.concept_code as cui,
        c1.concept_code as rxnorm_code
    FROM clinical_vocab.concept c1
    JOIN clinical_vocab.concept_relationship cr ON c1.concept_id = cr.concept_id_1
    JOIN clinical_vocab.concept c2 ON cr.concept_id_2 = c2.concept_id
    WHERE c1.vocabulary_id = 'RxNorm' 
    AND c2.vocabulary_id = 'RxNorm'
    AND c1.concept_class_id IN ('Clinical Drug', 'Branded Drug', 'Generic','Brand Name')
    AND c1.standard_concept = 'S'
    AND cr.relationship_id = 'Maps to'
    ORDER BY c1.concept_name
    """
    
    try:
        drugs = await conn.fetch(drugs_query)
        print(f"✅ Found {len(drugs)} drugs to generate training data for")
        
        # Show first few drugs
        print("📋 Sample drugs found:")
        for i, drug in enumerate(drugs[:10]):
            print(f"  {i+1}. {drug['drug_name']} (CUI: {drug['cui']}, RxNorm: {drug['rxnorm_code']})")
            
    except Exception as e:
        print(f"❌ Drug query failed: {e}")
        await conn.close()
        return None
    
    await conn.close()
    
    if not drugs:
        print("❌ No drugs found! Check your query.")
        return None
    
    # Enhanced training sentence templates
    templates = [
        # Basic medication statements
        "Patient takes {drug} daily.",
        "Patient takes {drug} twice daily.",
        "Patient takes {drug} {dose} daily.",
        "Patient takes {drug} {dose} twice daily.",
        "Patient takes {drug} {dose} once daily.",
        
        # Prescription context
        "Prescribed {drug} for {condition}.",
        "Prescribed {drug} {dose} for {condition}.",
        "Started patient on {drug} therapy.",
        "Started patient on {drug} {dose} for {condition}.",
        "Continue {drug} as previously prescribed.",
        "Continue {drug} {dose} as before.",
        
        # Clinical observations
        "Patient tolerates {drug} well.",
        "Patient reports good response to {drug}.",
        "Monitor patient response to {drug}.",
        "Patient compliant with {drug} regimen.",
        "Patient has been on {drug} for {duration}.",
        "No adverse effects from {drug}.",
        
        # Dosing adjustments
        "Increase {drug} dose to {dose}.",
        "Decrease {drug} dose to {dose}.",
        "Adjust {drug} dosing as needed.",
        "Titrate {drug} dose based on response.",
        
        # Effectiveness
        "{drug} appears effective for patient.",
        "{drug} is controlling symptoms well.",
        "Good therapeutic response to {drug}.",
        
        # Administrative
        "Refill {drug} prescription.",
        "Patient requests {drug} refill.",
        "Renewed prescription for {drug}.",
        
        # Side effects and monitoring
        "Monitor for {drug} side effects.",
        "Discuss {drug} adverse effects with patient.",
        "Patient educated about {drug} use.",
        
        # Combination therapy
        "Added {drug} to current regimen.",
        "Patient also takes {drug}.",
        "Continue current {drug} therapy."
    ]
    
    # Common doses for different drug categories
    doses = [
        "5 mg", "10 mg", "15 mg", "20 mg", "25 mg", "50 mg", "75 mg", "100 mg",
        "2.5 mg", "7.5 mg", "12.5 mg", "40 mg", "80 mg", "150 mg", "200 mg",
        "25 mcg", "50 mcg", "75 mcg", "88 mcg", "100 mcg", "125 mcg", "150 mcg",
        "500 mg", "850 mg", "1000 mg", "1 mg", "2 mg", "0.5 mg", "0.25 mg"
    ]
    
    # Common conditions for context
    conditions = [
        "hypertension", "diabetes", "hypothyroidism", "hyperlipidemia", 
        "heart failure", "atrial fibrillation", "depression", "anxiety",
        "arthritis", "chronic pain", "GERD", "their condition", "symptoms"
    ]
    
    # Time durations
    durations = [
        "6 months", "1 year", "2 years", "several months", "many years",
        "3 months", "9 months", "18 months", "a long time"
    ]
    
    # Generate training data
    print("🎯 Generating training examples...")
    training_data = []
    drugs_processed = 0
    
    for drug_record in drugs:
        drug_name = drug_record['drug_name'].lower()
        cui = drug_record['cui']
        rxnorm_code = drug_record['rxnorm_code']
        
        # Extract base drug name (remove dosage info, formulations, etc.)
        base_drug = extract_base_drug_name(drug_name)
        
        # Skip if base drug name is too short or generic
        if len(base_drug) < 4 or base_drug in ['tablet', 'capsule', 'mg', 'mcg']:
            continue
        
        drugs_processed += 1
        
        # Generate multiple examples per drug (but not too many)
        examples_per_drug = min(4, len(templates) // 4)  # 4 examples max per drug
        selected_templates = random.sample(templates, examples_per_drug)
        
        for template in selected_templates:
            # Fill template with random values
            dose = random.choice(doses)
            condition = random.choice(conditions)
            duration = random.choice(durations)
            
            try:
                text = template.format(
                    drug=base_drug, 
                    dose=dose, 
                    condition=condition,
                    duration=duration
                )
            except KeyError:
                # If template doesn't have all placeholders, just use drug
                text = template.format(drug=base_drug)
            
            # Find drug position in text
            drug_start = text.lower().find(base_drug.lower())
            if drug_start == -1:
                continue
            
            drug_end = drug_start + len(base_drug)
            
            # MedCAT training format
            training_example = {
                'text': text,
                'entities': {
                    "T1": {
                        'start': drug_start,
                        'end': drug_end,
                        'cui': cui,
                        'value': base_drug,
                        'confidence': 1.0,
                        'manually_created': True,
                        'rxnorm_code': rxnorm_code  # Additional metadata
                    }
                }
            }
            
            training_data.append(training_example)
        
        # Progress indicator
        if drugs_processed % 50 == 0:
            print(f"  Processed {drugs_processed} drugs, generated {len(training_data)} examples...")
    
    print(f"✅ Processed {drugs_processed} drugs")
    
    # Save training data
    output_dir = Path("clinicalai_service/training_data") 
    output_dir.mkdir(exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = output_dir / f"medcat_training_data_{timestamp}.json"
    
    with open(output_file, 'w') as f:
        json.dump(training_data, f, indent=2)
    
    print(f"✅ Generated {len(training_data)} training examples")
    print(f"📁 Saved to: {output_file}")
    
    # Save sample for inspection
    sample_file = output_dir / f"medcat_training_sample_{timestamp}.json"
    with open(sample_file, 'w') as f:
        json.dump(training_data[:20], f, indent=2)  # Show more samples
    
    print(f"📋 Sample (first 20) saved to: {sample_file}")
    
    # Save statistics
    stats = {
        'total_examples': len(training_data),
        'drugs_processed': drugs_processed,
        'examples_per_drug_avg': len(training_data) / drugs_processed if drugs_processed > 0 else 0,
        'timestamp': timestamp,
        'query_used': drugs_query.strip()
    }
    
    stats_file = output_dir / f"medcat_training_stats_{timestamp}.json"
    with open(stats_file, 'w') as f:
        json.dump(stats, f, indent=2)
    
    print(f"📊 Statistics saved to: {stats_file}")
    
    return str(output_file)


def extract_base_drug_name(drug_name: str) -> str:
    """Extract the base drug name from complex drug names"""
    
    # Convert to lowercase for processing
    name = drug_name.lower().strip()
    
    # Remove common suffixes and formulation info
    remove_patterns = [
        'tablet', 'capsule', 'oral', 'injection', 'solution', 'suspension',
        'extended-release', 'immediate-release', 'delayed-release',
        'mg', 'mcg', 'ml', 'units', '/ml', 'per ml',
        'film-coated', 'enteric-coated', 'chewable'
    ]
    
    # Split by common delimiters
    words = name.replace('-', ' ').replace('/', ' ').split()
    
    # Keep only the first 1-2 words that look like drug names
    clean_words = []
    for word in words:
        # Skip numeric values and common formulation words
        if (not any(pattern in word for pattern in remove_patterns) and 
            not word.isdigit() and 
            not any(char.isdigit() for char in word) and
            len(word) > 2):
            clean_words.append(word)
        
        # Usually the drug name is in the first 2 words
        if len(clean_words) >= 2:
            break
    
    # Return the base drug name
    if clean_words:
        return ' '.join(clean_words[:2])  # Max 2 words
    else:
        # Fallback: return first word
        return words[0] if words else name


if __name__ == "__main__":
    result = asyncio.run(generate_medcat_training_data())
    if result:
        print(f"\n🎉 Training data generation completed!")
        print(f"📄 File: {result}")
        print(f"\n📋 Next steps:")
        print(f"1. Inspect the sample file to verify quality")
        print(f"2. Run the retraining script with the generated file")
        print(f"3. Test the retrained model")
    else:
        print(f"\n❌ Training data generation failed!")