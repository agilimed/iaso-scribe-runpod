import random
from faker import Faker

fake = Faker()

archetypes = [
    # --- DIABETES RELATED (from before) ---
    {
        "title": "Diabetic Foot Infection", # ... (content as previously defined) ...
        "demographics": [ 
            "{age}-year-old {gender} with type 2 diabetes mellitus",
            "A {age}-year-old {gender} with a known history of T2DM and peripheral neuropathy",
        ],
        "sections": {
            "HPI": [
                "presents with worsening {foot_laterality} foot pain and swelling over {duration}.",
                "Patient notes foul-smelling drainage from a longstanding {toe_location} ulcer and difficulty walking.",
                "Low-grade fever and chills reported, no recent trauma.",
                "Reports a non-healing wound on the {foot_laterality} {toe_location} with increasing purulent discharge for several days."
            ],
            "ROS": [
                "Positive for fatigue, chills, and decreased appetite.",
                "Denies chest pain, cough, or shortness of breath.",
                "Review of systems otherwise negative except as noted in HPI."
            ],
            "PE": [
                "Vital signs: T {temp}°C, HR {hr} bpm, BP {bp_sys}/{bp_dia}, SpO2 {spo2}% on room air.",
                "{foot_laterality} foot with erythema, {ulcer_size} cm ulcer over {toe_location} draining purulent material, surrounding induration and warmth.",
                "Peripheral pulses {pulse_strength} in the {foot_laterality} foot, capillary refill {cap_refill_time} seconds.",
                "No fluctuance or crepitus noted. Sensation diminished to monofilament testing."
            ],
            "Labs": [
                "WBC elevated at {wbc_count}; CRP {crp_value} mg/L; ESR {esr_value} mm/hr.",
                "HbA1c from last visit was {hba1c_value}%. Random blood glucose {rbg_value} mg/dL.",
                "Foot X-ray shows soft tissue swelling with possible gas formation, no definite osteomyelitis.",
                "Blood cultures pending."
            ],
            "Assessment": [
                "Diabetic foot infection, {foot_laterality} foot, with cellulitis.",
                "Infected diabetic foot ulcer, {toe_location}, {foot_laterality}, with concern for underlying osteomyelitis.",
                "Severe diabetic foot infection, suspect early sepsis."
            ],
            "Plan": [
                "Admit to hospital for IV antibiotics (e.g., vancomycin and piperacillin-tazobactam).",
                "Consult podiatry for evaluation and possible debridement. Consult endocrinology for glycemic management.",
                "Strict wound care with daily dressing changes. Offload affected foot.",
                "Obtain MRI of {foot_laterality} foot to further evaluate for osteomyelitis if no improvement.",
                "Pain control with scheduled analgesics."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(50, 85), "gender": lambda: random.choice(["male", "female"]),
            "foot_laterality": lambda: random.choice(["right", "left"]), "duration": lambda: f"{random.randint(2, 10)} days",
            "toe_location": lambda: random.choice(["great toe", "2nd toe", "3rd toe", "lateral malleolus", "plantar surface"]),
            "temp": lambda: round(random.uniform(37.5, 39.2), 1), "hr": lambda: random.randint(80, 115),
            "bp_sys": lambda: random.randint(110, 170), "bp_dia": lambda: random.randint(60, 95), "spo2": lambda: random.randint(92,99),
            "ulcer_size": lambda: round(random.uniform(1.0, 4.0),1),
            "pulse_strength": lambda: random.choice(["weak", "diminished", "palpable", "1+"]), "cap_refill_time": lambda: random.randint(2,5),
            "wbc_count": lambda: f"{random.randint(12, 22)},{random.randint(0,9)}00", "crp_value": lambda: random.randint(50, 250),
            "hba1c_value": lambda: round(random.uniform(8.0, 12.5), 1), "esr_value": lambda: random.randint(40, 110),
            "rbg_value": lambda: random.randint(180, 450),
        }
    },
    # --- CARDIOLOGY (from before) ---
    {
        "title": "Acute Coronary Syndrome (ACS) Admission", # ... (content as previously defined) ...
        "demographics": [
            "{age}-year-old {gender} with history of hypertension and hyperlipidemia",
            "A {age}-year-old {gender} smoker with known CAD",
        ],
        "sections": {
            "HPI": [
                "presents with acute onset substernal chest pain radiating to the {pain_radiation} for {pain_duration}.",
                "Pain described as crushing, 8/10 severity, associated with diaphoresis and nausea.",
                "Symptoms started {time_since_onset} while at rest. Took {num_nitro} nitroglycerin SL with minimal relief."
            ],
            "ROS": [
                "Positive for dyspnea on exertion. Denies palpitations or syncope.",
                "Reports recent increased fatigue. Denies fever or cough."
            ],
            "PE": [
                "Vital signs: T {temp}°C, HR {hr} bpm (sometimes irregular), BP {bp_sys}/{bp_dia}, RR {rr}, SpO2 {spo2}% on {oxygen_delivery}.",
                "Cardiovascular: {heart_sounds}. No JVD or peripheral edema.",
                "Lungs: Clear to auscultation bilaterally.",
            ],
            "ECG": [
                "{ecg_findings_st_segment} in leads {ecg_leads}. {ecg_other_findings}.",
                "Sinus rhythm with new {ecg_arrhythmia_type} noted.",
                "Normal sinus rhythm, no acute ischemic changes." # Less likely given ACS but possible variation
            ],
            "Labs": [
                "Troponin I elevated at {troponin_value} ng/mL (initial was {initial_troponin_value} ng/mL).",
                "CK-MB {ckmb_value} U/L. BNP {bnp_value} pg/mL.",
                "Lipid panel: Total cholesterol {chol_total}, LDL {chol_ldl}, HDL {chol_hdl}."
            ],
            "Assessment": [
                "Acute ST-elevation myocardial infarction (STEMI), {location_of_mi}.",
                "Non-ST-elevation myocardial infarction (NSTEMI).",
                "Unstable angina, rule out myocardial infarction."
            ],
            "Plan": [
                "Immediate cardiac catheterization with PCI if indicated. Administer aspirin, clopidogrel, heparin.",
                "Initiate beta-blocker (e.g., metoprolol) and high-intensity statin (e.g., atorvastatin).",
                "Pain control with morphine PRN. Oxygen supplementation.",
                "Serial ECGs and cardiac enzymes. Echocardiogram to assess LV function.",
                "Admit to CCU for monitoring and management."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(45, 90), "gender": lambda: random.choice(["male", "female"]),
            "pain_radiation": lambda: random.choice(["left arm", "jaw", "back", "epigastrium"]),
            "pain_duration": lambda: f"{random.randint(30, 120)} minutes", "time_since_onset": lambda: f"{random.randint(1,6)} hours ago", "num_nitro": lambda: random.randint(1,3),
            "temp": lambda: round(random.uniform(36.0, 37.5), 1), "hr": lambda: random.randint(50, 110), "rr": lambda: random.randint(16,24),
            "bp_sys": lambda: random.randint(90, 180), "bp_dia": lambda: random.randint(50, 100), "spo2": lambda: random.randint(90,99), "oxygen_delivery": lambda: random.choice(["room air", "2L nasal cannula"]),
            "heart_sounds": lambda: random.choice(["S1, S2 normal, no murmurs, rubs or gallops", "S4 gallop present", "distant heart sounds"]),
            "ecg_findings_st_segment": lambda: random.choice(["ST elevation", "ST depression", "T-wave inversions"]), "ecg_leads": lambda: random.choice(["II, III, aVF", "V1-V4", "I, aVL, V5-V6"]),
            "ecg_other_findings": lambda: random.choice(["Occasional PVCs", "Left bundle branch block", "No significant arrhythmia"]), "ecg_arrhythmia_type": lambda: random.choice(["atrial fibrillation", "ventricular tachycardia"]),
            "troponin_value": lambda: round(random.uniform(1.0, 50.0), 2), "initial_troponin_value": lambda: round(random.uniform(0.01, 0.5), 2),
            "ckmb_value": lambda: random.randint(10, 200), "bnp_value": lambda: random.randint(50, 2000),
            "chol_total": lambda: random.randint(150,300), "chol_ldl": lambda: random.randint(70,200), "chol_hdl": lambda: random.randint(30,70),
            "location_of_mi": lambda: random.choice(["anterior", "inferior", "lateral"]),
        }
    },
    # --- PERIOPERATIVE / SURGERY (from before) ---
    {
        "title": "Preoperative Evaluation", # ... (content as previously defined) ...
        "demographics": [
            "{age}-year-old {gender} scheduled for {procedure_name}.",
            "A {age}-year-old {gender} presenting for pre-op clearance prior to {procedure_name}."
        ],
        "sections": {
            "History": [
                "Past medical history significant for {comorbidity1} and {comorbidity2}.",
                "Current medications include {medication1}, {medication2}. Allergies: {allergy}.",
                "Patient is an active {social_habit}. Denies recent illness."
            ],
            "ReviewOfSystems": [
                "Cardiovascular: Denies chest pain, palpitations. Reports {cardiac_symptom_status}.",
                "Respiratory: Denies cough, dyspnea. {respiratory_symptom_status}.",
                "All other systems reviewed and are negative."
            ],
            "PhysicalExam": [
                "Vital Signs: BP {bp_sys}/{bp_dia}, HR {hr}, RR {rr}, Temp {temp}°C, SpO2 {spo2}% on RA.",
                "HEENT: Normal. Neck: Supple, no thyromegaly. Lungs: {lung_sounds}. Heart: {heart_sounds_preop}.",
                "Airway assessment: Mallampati class {mallampati_score}. Thyromental distance >{thyromental_dist} cm. Good mouth opening."
            ],
            "Labs_Imaging": [
                "CBC: Hgb {hgb_value} g/dL, Plt {plt_count}K. BMP: Cr {cr_value} mg/dL, K {k_value} mEq/L.",
                "ECG: {ecg_preop_findings}. CXR: {cxr_preop_findings}.",
                "PT/INR {pt_inr_value}."
            ],
            "Assessment_Plan": [
                "ASA class {asa_class}. Patient is at {risk_level} risk for perioperative complications.",
                "Plan: Proceed with surgery. Continue current medications except {med_to_hold}. NPO after midnight.",
                "Discussed risks/benefits/alternatives. Consent obtained."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(30, 80), "gender": lambda: random.choice(["male", "female"]),
            "procedure_name": lambda: random.choice(["laparoscopic cholecystectomy", "total knee arthroplasty", "inguinal hernia repair", "colonoscopy with polypectomy"]),
            "comorbidity1": lambda: random.choice(["hypertension", "diabetes mellitus type 2", "asthma", "GERD", "obstructive sleep apnea"]),
            "comorbidity2": lambda: random.choice(["hyperlipidemia", "coronary artery disease", "CKD stage 3", "atrial fibrillation", "none"]),
            "medication1": lambda: random.choice(["lisinopril", "metformin", "atorvastatin", "aspirin", "albuterol inhaler"]),
            "medication2": lambda: random.choice(["amlodipine", "omeprazole", "warfarin", "none"]),
            "allergy": lambda: random.choice(["penicillin (rash)", "sulfa drugs (hives)", "NKDA"]),
            "social_habit": lambda: random.choice(["smoker (1 PPD x 20 years)", "occasional alcohol use", "non-smoker"]),
            "cardiac_symptom_status": lambda: random.choice(["able to climb 2 flights of stairs without symptoms", "gets short of breath after walking one block"]),
            "respiratory_symptom_status": lambda: random.choice(["no wheezing", "uses inhaler 2-3 times per week"]),
            "bp_sys": lambda: random.randint(110,150), "bp_dia": lambda: random.randint(60,90), "hr": lambda: random.randint(60,90),
            "rr": lambda: random.randint(12,18), "temp": lambda: round(random.uniform(36.5, 37.2),1), "spo2": lambda: random.randint(95,100),
            "lung_sounds": lambda: random.choice(["clear to auscultation bilaterally", "bibasilar crackles"]), "heart_sounds_preop": lambda: random.choice(["regular rate and rhythm, no murmurs", "systolic ejection murmur grade 2/6"]),
            "mallampati_score": lambda: random.randint(1,3), "thyromental_dist": lambda: random.randint(5,8),
            "hgb_value": lambda: round(random.uniform(11.0, 15.0),1), "plt_count": lambda: random.randint(150,400),
            "cr_value": lambda: round(random.uniform(0.7, 1.3),2), "k_value": lambda: round(random.uniform(3.5, 5.0),1),
            "ecg_preop_findings": lambda: random.choice(["Normal sinus rhythm", "LVH by voltage criteria", "Non-specific ST-T wave changes"]),
            "cxr_preop_findings": lambda: random.choice(["Clear lungs", "No acute cardiopulmonary process", "Stable cardiomegaly"]),
            "pt_inr_value": lambda: round(random.uniform(0.9, 1.2),1),
            "asa_class": lambda: random.randint(1,3), "risk_level": lambda: random.choice(["low", "moderate"]),
            "med_to_hold": lambda: random.choice(["aspirin 7 days prior", "warfarin 5 days prior", "none"]),
        }
    },
    {
        "title": "Postoperative Note - General Surgery", # ... (content as previously defined, was Appendectomy) ...
        "demographics": [
            "{age}-year-old {gender} status post {procedure_type_general_surg} for {diagnosis_reason_general_surg}.",
        ],
        "sections": {
            "ProcedureDetails": [
                "Operative findings: {op_finding_general_surg}. Procedure completed without apparent intraoperative complication.",
                "Estimated blood loss: {ebl} mL. Drains: {drain_status}."
            ],
            "PostOpCourse_Day0_1": [ # Combined Day 0/1
                "Patient recovered in PACU and transferred to floor. Pain initially {pain_level_initial} controlled with {pain_med_type}.",
                "Diet advanced from NPO to {diet_postop_general}. Passing flatus: {flatus_status}. Nausea {nausea_status_general}.",
                "IV fluids {iv_fluid_type} weaned as PO intake improved. Ambulated {ambulation_status_general}."
            ],
            "PhysicalExam_Day1": [
                "Vitals stable. Afebrile. Abdomen: {abd_exam_general_surg}. Incision(s) {incision_status_general}. Bowel sounds {bowel_sounds_status}."
            ],
            "Plan_Day1": [
                "Continue to advance diet as tolerated. Transition to oral analgesia, e.g. {oral_pain_med_general}.",
                "Encourage mobilization. Monitor for signs of infection or ileus.",
                "Plan for discharge in {discharge_timeline_general} if continues to progress."
            ]
        },
        "placeholders": { # Many placeholders can be reused or adapted
            "age": lambda: random.randint(20,75), "gender": lambda: random.choice(["male", "female"]),
            "procedure_type_general_surg": lambda: random.choice(["laparoscopic cholecystectomy", "inguinal hernia repair", "exploratory laparotomy", "colectomy"]),
            "diagnosis_reason_general_surg": lambda: random.choice(["acute cholecystitis", "incarcerated inguinal hernia", "small bowel obstruction", "colon cancer"]),
            "op_finding_general_surg": lambda: random.choice(["inflamed gallbladder with stones", "viable bowel after hernia reduction", "adhesions lysed", "tumor resected with clear margins"]),
            "ebl": lambda: random.choice([50, 100, 250, 500]), "drain_status": lambda: random.choice(["none", "one Jackson-Pratt drain"]),
            "pain_level_initial": lambda: random.choice(["moderate", "severe"]), "pain_med_type": lambda: random.choice(["PCA hydromorphone", "IV ketorolac", "epidural analgesia"]),
            "diet_postop_general": lambda: random.choice(["clear liquids", "full liquids", "soft diet"]), "flatus_status": lambda: random.choice(["yes", "no", "pending"]),
            "nausea_status_general": lambda: random.choice(["none", "mild, resolved with ondansetron", "present"]),
            "iv_fluid_type": lambda: random.choice(["D5 1/2NS + 20KCL", "Normal Saline"]), "ambulation_status_general": lambda: random.choice(["with assistance twice", "independently in hallways"]),
            "abd_exam_general_surg": lambda: random.choice(["soft, mildly tender, non-distended", "distended, tympanitic", "guarding present"]),
            "incision_status_general": lambda: random.choice(["clean, dry, and intact", "with minimal serous drainage", "erythematous"]),
            "bowel_sounds_status": lambda: random.choice(["normoactive", "hypoactive", "absent"]),
            "oral_pain_med_general": lambda: random.choice(["oxycodone/acetaminophen", "tramadol", "ibuprofen"]),
            "discharge_timeline_general": lambda: random.choice(["1-2 days", "3-5 days"]),
        }
    },
    # --- DISCHARGE SUMMARY (from before) ---
    {
        "title": "Discharge Summary - General Medical", # ... (content as previously defined, was Pneumonia) ...
        "demographics": [
            "This {age}-year-old {gender} was admitted on {admission_date_placeholder} for {admission_reason_general_med}.",
        ],
        "sections": {
            "HospitalCourse": [
                "Patient was diagnosed with {final_diagnosis_general_med}. Pertinent workup included {key_test_general_med} which showed {key_finding_general_med}.",
                "Treated with {treatment1_general_med} and {treatment2_general_med}. Patient's symptoms of {symptom_resolved_general_med} improved.",
                "Clinical course was {course_descriptor_general_med}. {complication_discharge_status_general}."
            ],
            "ConditionAtDischarge": [
                "Afebrile, hemodynamically stable. {mobility_discharge_general}. Tolerating {diet_discharge_general}.",
                "Pain well controlled on oral medication. Key symptoms resolved or significantly improved."
            ],
            "DischargeMedications": [
                "{new_med_discharge_general} {dose_freq_discharge_general} for {duration_discharge_general}.",
                "Continue home medications: {home_med1_discharge}, {home_med2_discharge}. Discontinue {med_stopped_discharge_general}.",
                "{prn_med_discharge_general} as needed for {prn_reason_discharge_general}."
            ],
            "DischargeInstructions_FollowUp": [
                "Follow up with PCP, Dr. {doctor_name_placeholder}, in {fup_time_discharge}. Also follow up with {specialist_fup_discharge} if indicated.",
                "Activity as tolerated, {activity_restriction_discharge}. Diet: {diet_instruction_discharge}.",
                "Return to ED for {return_precautions_general_med}. Wound care instructions provided if applicable."
            ]
        },
        "placeholders": { # Many placeholders can be reused or adapted
            "age": lambda: random.randint(40,95), "gender": lambda: random.choice(["male", "female"]),
            "admission_date_placeholder": lambda: fake.date_this_year(before_today=True, after_today=False).strftime("%Y-%m-%d"),
            "admission_reason_general_med": lambda: random.choice(["acute exacerbation of CHF", "pyelonephritis", "cellulitis of lower extremity", "GI bleed", "syncopal episode"]),
            "final_diagnosis_general_med": lambda: random.choice(["decompensated heart failure", "urosepsis", "left leg cellulitis", "upper GI hemorrhage due to gastritis", "vasovagal syncope"]),
            "key_test_general_med": lambda: random.choice(["echocardiogram", "CT abdomen/pelvis", "lower extremity ultrasound", "EGD", "cardiac telemetry"]),
            "key_finding_general_med": lambda: random.choice(["EF 35%", " perinephric stranding", "no DVT", "diffuse gastritis", "no significant arrhythmia"]),
            "treatment1_general_med": lambda: random.choice(["IV diuretics (furosemide)", "IV antibiotics (ceftriaxone)", "IV vancomycin", "IV pantoprazole", "IV fluids"]),
            "treatment2_general_med": lambda: random.choice(["beta-blocker optimization", "symptomatic care", "elevation and compression", "blood transfusion (2 units PRBC)", "none"]),
            "symptom_resolved_general_med": lambda: random.choice(["dyspnea and edema", "fever and flank pain", "erythema and swelling", "melena", "dizziness"]),
            "course_descriptor_general_med": lambda: random.choice(["uncomplicated", "marked by initial instability but responded well", "prolonged due to comorbidities"]),
            "complication_discharge_status_general": lambda: random.choice(["No acute complications during admission", "Developed mild acute kidney injury, resolved", "Required electrolyte repletion"]),
            "mobility_discharge_general": lambda: random.choice(["Ambulating independently", "Ambulating with walker", "Tolerating PT/OT"]),
            "diet_discharge_general": lambda: random.choice(["regular diet", "low sodium diet", "cardiac diet", "soft diet"]),
            "new_med_discharge_general": lambda: random.choice(["Lisinopril 10mg daily", "Ciprofloxacin 500mg BID", "Clindamycin 300mg QID", "Omeprazole 40mg daily", "none"]),
            "dose_freq_discharge_general": lambda: "", # Often part of the med string itself
            "duration_discharge_general": lambda: random.choice(["7 days", "10 days", "14 days", "as an outpatient indefinitely"]),
            "home_med1_discharge": lambda: random.choice(["lisinopril 20mg daily", "metformin 1000mg BID", "atorvastatin 40mg QHS", "none"]),
            "home_med2_discharge": lambda: random.choice(["amlodipine 5mg daily", "aspirin 81mg daily", "omeprazole 20mg daily", "none"]),
            "med_stopped_discharge_general": lambda: random.choice(["previous home diuretic", "NSAIDs", "none"]),
            "prn_med_discharge_general": lambda: random.choice(["Tylenol 650mg Q6H PRN", "Ondansetron 4mg ODT PRN", "Nitroglycerin SL PRN", "none"]),
            "prn_reason_discharge_general": lambda: random.choice(["pain", "nausea", "chest pain"]),
            "doctor_name_placeholder": lambda: fake.last_name(), "fup_time_discharge": lambda: random.choice(["1 week", "3-5 days", "2 weeks"]),
            "specialist_fup_discharge": lambda: random.choice(["Cardiology", "Infectious Disease", "GI", "Nephrology", "Neurology", "their surgeon"]),
            "activity_restriction_discharge": lambda: random.choice(["no heavy lifting for 2 weeks", "weight bearing as tolerated", "continue home exercises"]),
            "diet_instruction_discharge": lambda: random.choice(["2 gram sodium restriction", "fluid restriction 1.5L/day", "continue diabetic diet"]),
            "return_precautions_general_med": lambda: random.choice(["worsening shortness of breath, chest pain, or edema", "fever >101.5, persistent vomiting, or inability to tolerate PO", "increased redness, swelling, or drainage from wound", "recurrent melena or hematemesis", "recurrent syncope or palpitations"]),
        }
    },

    # --- NEW ARCHETYPES AS REQUESTED ---

    # - GI Bleed
    {
        "title": "Upper GI Bleed Admission",
        "demographics": ["{age}-year-old {gender} with history of {gi_bleed_risk_factor} presenting with {presenting_symptom_gi_bleed}."],
        "sections": {
            "HPI": [
                "Patient reports {num_episodes} episodes of {presenting_symptom_gi_bleed} over the past {duration_gi_symptoms}.",
                "Associated with {associated_symptom_gi_bleed} and lightheadedness. Denies chest pain.",
                "Takes {relevant_med_gi_bleed} daily."
            ],
            "PE": [
                "Vitals: BP {bp_sys_low}/{bp_dia_low}, HR {hr_high} (tachycardic), RR {rr}. Appears pale.",
                "Abdomen: Soft, non-tender, {bowel_sounds_gi_bleed}. Rectal exam: {rectal_exam_finding}."
            ],
            "Labs": [
                "CBC shows Hgb {hgb_low} g/dL (baseline {hgb_baseline} g/dL). Platelets {plt_count}K.",
                "BUN {bun_high} mg/dL, Cr {cr_value} mg/dL. PT/INR {pt_inr_value}."
            ],
            "Interventions": [
                "Two large-bore IVs established. Administered {iv_fluid_volume}L of {iv_fluid_type}.",
                "Type and crossmatch ordered. Transfused {num_prbc_units} units PRBCs.",
                "Started on IV {ppi_med} infusion."
            ],
            "Assessment": ["Acute upper gastrointestinal hemorrhage, likely {suspected_source_gi_bleed}."],
            "Plan": [
                "Admit to ICU/step-down unit. NPO. Continue IV {ppi_med}. Consult GI for urgent EGD.",
                "Monitor vital signs and hemoglobin closely. Transfuse PRBCs to maintain Hgb >{hgb_target} g/dL."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(50,85), "gender": lambda: random.choice(["male","female"]),
            "gi_bleed_risk_factor": lambda: random.choice(["peptic ulcer disease", "chronic NSAID use", "liver cirrhosis", "alcohol abuse"]),
            "presenting_symptom_gi_bleed": lambda: random.choice(["hematemesis", "melena", "coffee-ground emesis"]),
            "num_episodes": lambda: random.randint(1,5), "duration_gi_symptoms": lambda: random.choice(["24 hours", "2 days", "12 hours"]),
            "associated_symptom_gi_bleed": lambda: random.choice(["dizziness", "weakness", "abdominal discomfort"]),
            "relevant_med_gi_bleed": lambda: random.choice(["ibuprofen", "aspirin", "warfarin", "no high-risk meds"]),
            "bp_sys_low": lambda: random.randint(80,110), "bp_dia_low": lambda: random.randint(40,60), "hr_high": lambda: random.randint(100,130), "rr": lambda: random.randint(18,24),
            "bowel_sounds_gi_bleed": lambda: random.choice(["normoactive", "hyperactive"]), "rectal_exam_finding": lambda: random.choice(["melanotic stool on vault", "grossly heme positive", "no gross blood"]),
            "hgb_low": lambda: round(random.uniform(5.0,9.0),1), "hgb_baseline": lambda: round(random.uniform(10.0,14.0),1), "plt_count": lambda: random.randint(100,300),
            "bun_high": lambda: random.randint(30,80), "cr_value": lambda: round(random.uniform(0.8,1.5),2), "pt_inr_value": lambda: round(random.uniform(1.0,2.5),1),
            "iv_fluid_volume": lambda: random.randint(1,2), "num_prbc_units": lambda: random.randint(0,2), "ppi_med": lambda: random.choice(["pantoprazole", "esomeprazole"]),
            "suspected_source_gi_bleed": lambda: random.choice(["peptic ulcer", "esophageal varices", "gastritis/duodenitis"]), "hgb_target": lambda: random.randint(7,8),
            "iv_fluid_type": lambda: random.choice(["Normal Saline", "Lactated Ringers"])
        }
    },
    # - Stroke / TIA
    {
        "title": "Acute Stroke / TIA Evaluation",
        "demographics": ["{age}-year-old {gender} with sudden onset of {neurological_symptom} {symptom_onset_time} ago."],
        "sections": {
            "HPI": [
                "Patient was last known well {last_known_well_time}. Symptoms include {neurological_symptom_list}.",
                "No recent head trauma or seizure activity reported. History of {stroke_risk_factor1} and {stroke_risk_factor2}."
            ],
            "PE_Neuro": [
                "NIHSS score: {nihss_score}. GCS {gcs_score}.",
                "Cranial Nerves: {cn_finding}. Motor: {motor_finding_stroke}. Sensory: {sensory_finding_stroke}.",
                "Coordination: {coordination_finding_stroke}. Speech: {speech_finding_stroke}."
            ],
            "Imaging": [
                "CT head without contrast shows {ct_head_finding_stroke}.",
                "CTA head and neck performed: {cta_finding_stroke}."
            ],
            "Labs": ["Blood glucose {glucose_stroke} mg/dL. Platelets {plt_count}K. INR {pt_inr_value}."],
            "Assessment": ["{stroke_tia_diagnosis} affecting {stroke_location_guess} territory."],
            "Plan": [
                "Admit to stroke unit. Neurology consult. {thrombolysis_plan_stroke}.",
                "Permissive hypertension unless tPA given. Aspirin {aspirin_dose_stroke}mg initiated.",
                "Monitor neuro checks q1h. Swallow screen before PO intake."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(55,90), "gender": lambda: random.choice(["male","female"]),
            "neurological_symptom": lambda: random.choice(["left-sided weakness", "aphasia", "right facial droop", "slurred speech", "vertigo"]),
            "symptom_onset_time": lambda: random.choice(["30 minutes", "2 hours", "upon awakening"]),
            "last_known_well_time": lambda: random.choice(["1 hour prior to arrival", "yesterday evening", "4 hours ago"]),
            "neurological_symptom_list": lambda: ", ".join(random.sample(["left arm plegia", "facial droop", "expressive aphasia", "dysarthria", "gaze deviation", "sensory neglect"], k=random.randint(2,4))),
            "stroke_risk_factor1": lambda: random.choice(["atrial fibrillation", "hypertension", "diabetes"]),
            "stroke_risk_factor2": lambda: random.choice(["hyperlipidemia", "smoking history", "prior TIA"]),
            "nihss_score": lambda: random.randint(2,20), "gcs_score": lambda: random.randint(10,15),
            "cn_finding": lambda: random.choice(["right facial droop present", "left gaze preference", "dysarthria noted", "CN II-XII intact"]),
            "motor_finding_stroke": lambda: random.choice(["left hemiparesis (arm 4/5, leg 3/5)", "right upper extremity drift", "normal strength globally"]),
            "sensory_finding_stroke": lambda: random.choice(["decreased sensation to light touch on left side", "right-sided neglect", "sensation intact"]),
            "coordination_finding_stroke": lambda: random.choice(["ataxic gait", "dysmetria on finger-to-nose testing on left", "coordination normal"]),
            "speech_finding_stroke": lambda: random.choice(["expressive aphasia", "dysarthria", "fluent speech"]),
            "ct_head_finding_stroke": lambda: random.choice(["no acute intracranial hemorrhage or infarct", "early ischemic changes in the right MCA territory", "chronic microvascular ischemic changes"]),
            "cta_finding_stroke": lambda: random.choice(["no large vessel occlusion", "occlusion of the left M1 segment", "significant stenosis of the right ICA"]),
            "glucose_stroke": lambda: random.randint(80,250), "plt_count": lambda: random.randint(150,350), "pt_inr_value": lambda: round(random.uniform(0.9,1.3),1),
            "stroke_tia_diagnosis": lambda: random.choice(["Acute ischemic stroke", "Transient ischemic attack (TIA)", "Hemorrhagic stroke (less likely with this plan)"]),
            "stroke_location_guess": lambda: random.choice(["left MCA", "right MCA", "posterior circulation", "lacunar"]),
            "thrombolysis_plan_stroke": lambda: random.choice(["Patient is a candidate for IV tPA, alteplase administered.", "Patient outside window for tPA.", "Consider mechanical thrombectomy.", "Contraindications to thrombolysis present."]),
            "aspirin_dose_stroke": lambda: random.choice([81, 325]),
        }
    },
    # - UTI / Pyelonephritis
    {
        "title": "Urinary Tract Infection / Pyelonephritis",
        "demographics": ["{age}-year-old {gender} presenting with {uti_symptom1} and {uti_symptom2} for {uti_duration}."],
        "sections": {
            "HPI": ["Associated with {uti_associated_symptom}. Denies vaginal discharge or hematuria.", "No recent antibiotic use. History of recurrent UTIs."],
            "PE": ["Vitals: T {temp_high}°C, HR {hr}, BP {bp_sys}/{bp_dia}. Abdomen: Suprapubic tenderness. {cvat_finding} CVA tenderness."],
            "Labs": ["Urinalysis: +leukocyte esterase, +nitrites, {ua_wbc_count} WBC/hpf, {ua_bacteria_level} bacteria.", "Urine culture pending. CBC: WBC {wbc_count_uti}."],
            "Assessment": ["{uti_pyelo_diagnosis}. Differential includes cystitis, pyelonephritis."],
            "Plan": [
                "Start oral {antibiotic_uti_po} for uncomplicated cystitis.",
                "Admit for IV {antibiotic_pyelo_iv} if pyelonephritis suspected or unable to tolerate PO.",
                "Encourage hydration. Provide symptomatic relief with phenazopyridine."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(18,70), "gender": lambda: random.choice(["female","male"]), # More common in females
            "uti_symptom1": lambda: random.choice(["dysuria", "urinary frequency", "flank pain"]),
            "uti_symptom2": lambda: random.choice(["urgency", "suprapubic pain", "fever"]),
            "uti_duration": lambda: random.choice(["2 days", "3 days", "1 week"]),
            "uti_associated_symptom": lambda: random.choice(["nausea", "chills", "malaise", "no other symptoms"]),
            "temp_high": lambda: round(random.uniform(37.8,39.5),1), "hr": lambda: random.randint(70,100), "bp_sys": lambda: random.randint(100,140), "bp_dia": lambda: random.randint(60,90),
            "cvat_finding": lambda: random.choice(["No", "Right", "Left", "Bilateral"]),
            "ua_wbc_count": lambda: random.choice(["10-20", "20-50", ">50", "many"]), "ua_bacteria_level": lambda: random.choice(["few", "moderate", "many"]),
            "wbc_count_uti": lambda: f"{random.randint(10,18)},{random.randint(0,9)}00",
            "uti_pyelo_diagnosis": lambda: random.choice(["Uncomplicated urinary tract infection (cystitis)", "Acute pyelonephritis", "Complicated UTI"]),
            "antibiotic_uti_po": lambda: random.choice(["nitrofurantoin", "trimethoprim-sulfamethoxazole", "ciprofloxacin"]),
            "antibiotic_pyelo_iv": lambda: random.choice(["ceftriaxone", "ciprofloxacin", "piperacillin-tazobactam"]),
        }
    },
    # - Cellulitis (non-diabetic)
    {
        "title": "Cellulitis (Non-Diabetic)",
        "demographics": ["{age}-year-old {gender} presents with a {duration_cellulitis} history of painful, spreading rash on the {location_cellulitis}."],
        "sections": {
            "HPI": ["Patient reports initial {skin_lesion_cellulitis} that has become erythematous, warm, and tender.", "Associated with {systemic_symptom_cellulitis}. No known insect bite or trauma to the area."],
            "PE": ["Affected area on {location_cellulitis} shows {erythema_description_cellulitis} with indistinct borders and local warmth. {other_pe_finding_cellulitis}.", "No crepitus or fluctuance. {lymphadenopathy_status_cellulitis} regional lymphadenopathy."],
            "Labs": ["WBC {wbc_cellulitis}. CRP {crp_cellulitis}. Blood cultures obtained if systemic signs present."],
            "Assessment": ["Cellulitis of the {location_cellulitis}, likely {bacterial_agent_cellulitis} infection."],
            "Plan": [
                "Outline affected area with marker to monitor spread. Elevate limb.",
                "Start oral antibiotics ({oral_abx_cellulitis}) for mild to moderate non-purulent cellulitis.",
                "Consider IV antibiotics ({iv_abx_cellulitis}) if extensive, systemic signs, or failure of oral therapy.",
                "Pain control with NSAIDs or acetaminophen."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(20,70), "gender": lambda: random.choice(["male","female"]),
            "duration_cellulitis": lambda: random.choice(["2-day", "3-day", "5-day"]),
            "location_cellulitis": lambda: random.choice(["left lower leg", "right forearm", "left hand", "right thigh"]),
            "skin_lesion_cellulitis": lambda: random.choice(["small abrasion", "minor cut", "no identifiable portal of entry"]),
            "systemic_symptom_cellulitis": lambda: random.choice(["low-grade fever", "chills", "malaise", "no systemic symptoms"]),
            "erythema_description_cellulitis": lambda: random.choice(["a 10x15cm area of erythema", "diffuse redness and swelling", "erythematous plaque"]),
            "other_pe_finding_cellulitis": lambda: random.choice(["Mild edema noted", "Several small vesicles present", "Skin is intact"]),
            "lymphadenopathy_status_cellulitis": lambda: random.choice(["No", "Tender ipsilateral"]),
            "wbc_cellulitis": lambda: random.choice(["normal", f"{random.randint(11,16)},{random.randint(0,9)}00"]), "crp_cellulitis": lambda: random.choice(["mildly elevated", f"{random.randint(10,100)} mg/L", "within normal limits"]),
            "bacterial_agent_cellulitis": lambda: random.choice(["Streptococcal", "Staphylococcal"]),
            "oral_abx_cellulitis": lambda: random.choice(["cephalexin", "clindamycin", "doxycycline"]),
            "iv_abx_cellulitis": lambda: random.choice(["cefazolin", "vancomycin", "clindamycin"]),
        }
    },
    # - Mental Health (Depression/Anxiety Outpatient)
    {
        "title": "Mental Health Follow-up (Depression/Anxiety)",
        "demographics": ["{age}-year-old {gender} with diagnosed {mental_health_dx} for routine follow-up."],
        "sections": {
            "IntervalHistory": [
                "Patient reports {mood_status_mh} mood since last visit {last_visit_time_mh} ago. Current medication: {current_med_mh} {dose_mh}.",
                "Sleep has been {sleep_quality_mh}. Appetite is {appetite_status_mh}. Energy levels are {energy_level_mh}.",
                "Reports {anxiety_symptom_status_mh} anxiety symptoms. Any recent stressors: {stressors_mh}."
            ],
            "MentalStatusExam": [
                "Appearance: Well-groomed. Behavior: Cooperative. Speech: Normal rate and rhythm.",
                "Mood: '{reported_mood_mh}'. Affect: {observed_affect_mh}, congruent with mood.",
                "Thought Process: Logical, goal-directed. Thought Content: {thought_content_mh}. No SI/HI." # Suicidal/Homicidal Ideation
            ],
            "Assessment": ["{mental_health_dx}, {current_severity_mh}. Patient is {response_to_tx_mh} to current regimen."],
            "Plan": [
                "{med_adjustment_plan_mh} current medication. Continue {therapy_type_mh} therapy.",
                "Reinforce coping strategies. Safety plan reviewed.",
                "Follow up in {fup_interval_mh} or PRN for worsening symptoms."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(25,65), "gender": lambda: random.choice(["male","female"]),
            "mental_health_dx": lambda: random.choice(["Major Depressive Disorder (MDD)", "Generalized Anxiety Disorder (GAD)", "Panic Disorder", "MDD with anxious distress"]),
            "mood_status_mh": lambda: random.choice(["stable", "somewhat improved", "persistently low", "fluctuating"]),
            "last_visit_time_mh": lambda: random.choice(["4 weeks", "6 weeks", "3 months"]),
            "current_med_mh": lambda: random.choice(["sertraline", "escitalopram", "fluoxetine", "venlafaxine", "bupropion", "lorazepam PRN"]),
            "dose_mh": lambda: random.choice(["50mg daily", "100mg daily", "20mg daily", "150mg XR daily", "0.5mg PRN"]),
            "sleep_quality_mh": lambda: random.choice(["improved, sleeping 7-8 hours", "still experiencing initial insomnia", "disrupted with middle-of-night awakenings"]),
            "appetite_status_mh": lambda: random.choice(["good", "decreased", "increased slightly"]), "energy_level_mh": lambda: random.choice(["improved", "still low", "fair"]),
            "anxiety_symptom_status_mh": lambda: random.choice(["reduced", "still experiencing frequent panic attacks", "manageable with PRN medication"]),
            "stressors_mh": lambda: random.choice(["ongoing work stress", "family issues", "financial concerns", "none new"]),
            "reported_mood_mh": lambda: random.choice(["euthymic", "anxious", "depressed", "okay"]),
            "observed_affect_mh": lambda: random.choice(["full range", "constricted", "tearful at times", "anxious"]),
            "thought_content_mh": lambda: random.choice(["no suicidal or homicidal ideation", "some passive death wishes but no intent or plan", "preoccupations with worry"]),
            "current_severity_mh": lambda: random.choice(["mild", "moderate", "in partial remission", "severe but improving"]),
            "response_to_tx_mh": lambda: random.choice(["responding well", "partially responding", "not adequately responding"]),
            "med_adjustment_plan_mh": lambda: random.choice(["Continue current dose of", "Increase dose of", "Consider switching", "Add adjunct agent to"]),
            "therapy_type_mh": lambda: random.choice(["Cognitive Behavioral Therapy (CBT)", "psychodynamic psychotherapy", "supportive therapy"]),
            "fup_interval_mh": lambda: random.choice(["4 weeks", "6 weeks", "2 months"]),
        }
    },
    # - Orthopedic (Fracture Follow-up / Joint Replacement Post-Op)
    {
        "title": "Orthopedic Follow-up",
        "demographics": ["{age}-year-old {gender} for follow-up of {ortho_condition} of the {ortho_location}."],
        "sections": {
            "IntervalHistory": [
                "Patient is {weeks_post_op_fracture} weeks status post {ortho_procedure_treatment}.",
                "Pain level is currently {pain_level_ortho}/10, managed with {pain_med_ortho}.",
                "Reports {functional_status_ortho}. Attending physical therapy {pt_freq_ortho} times per week."
            ],
            "PhysicalExam": [
                "Wound: {wound_appearance_ortho}. Range of Motion ({ortho_joint}): {rom_findings_ortho}.",
                "Strength: {strength_findings_ortho}. Neurovascularly intact distally."
            ],
            "Imaging": ["Follow-up X-rays show {xray_findings_ortho}."],
            "Assessment": ["{ortho_condition} of the {ortho_location}, status post {ortho_procedure_treatment}, {healing_status_ortho}."],
            "Plan": [
                "Continue current weight-bearing restrictions: {weight_bearing_status_ortho}.",
                "Advance physical therapy as tolerated. Wean off narcotic analgesia.",
                "Follow up in {fup_ortho_weeks} weeks with repeat X-rays."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(20,80), "gender": lambda: random.choice(["male","female"]),
            "ortho_condition": lambda: random.choice(["distal radius fracture", "hip fracture", "total knee arthroplasty", "ACL reconstruction", "tibial shaft fracture"]),
            "ortho_location": lambda: random.choice(["right wrist", "left hip", "right knee", "left ankle", "left tibia"]),
            "weeks_post_op_fracture": lambda: random.choice([2, 4, 6, 8, 12]),
            "ortho_procedure_treatment": lambda: random.choice(["open reduction internal fixation (ORIF)", "closed reduction and casting", "total hip arthroplasty", "arthroscopic repair", "intramedullary nailing"]),
            "pain_level_ortho": lambda: random.randint(1,5), "pain_med_ortho": lambda: random.choice(["ibuprofen PRN", "acetaminophen with codeine", "oxycodone as needed"]),
            "functional_status_ortho": lambda: random.choice(["improving, able to perform ADLs with some difficulty", "still significant limitations with mobility", "using crutches for ambulation"]),
            "pt_freq_ortho": lambda: random.randint(1,3),
            "wound_appearance_ortho": lambda: random.choice(["clean, dry, and intact", "well-healed", "sutures removed, steri-strips in place", "minimal erythema at incision site"]),
            "ortho_joint": lambda: random.choice(["wrist", "hip", "knee", "ankle"]),
            "rom_findings_ortho": lambda: random.choice(["flexion to 90 degrees, extension to 0", "full active and passive range of motion", "limited by pain and swelling"]),
            "strength_findings_ortho": lambda: random.choice(["5/5 throughout", "4/5 in quadriceps", "deferred due to pain"]),
            "xray_findings_ortho": lambda: random.choice(["good alignment and early callus formation", "fracture healing appropriately", "implants in good position, no loosening", "non-union evident"]),
            "healing_status_ortho": lambda: random.choice(["healing well", "delayed union", "progressing as expected", "non-union requiring further intervention"]),
            "weight_bearing_status_ortho": lambda: random.choice(["non-weight bearing", "toe-touch weight bearing", "partial weight bearing as tolerated", "full weight bearing"]),
            "fup_ortho_weeks": lambda: random.randint(4,8),
        }
    },
    # - Routine Well Visit / Physical Exam
    {
        "title": "Routine Adult Well Visit",
        "demographics": ["{age}-year-old {gender} presents for annual physical examination and health maintenance."],
        "sections": {
            "IntervalHistory": [
                "Patient reports feeling generally well. No acute complaints. Last physical exam {last_pe_time} ago.",
                "Review of chronic conditions: {chronic_condition_status_well_visit}. Current medications reviewed and reconciled.",
                "Social history: {social_habit_well_visit}. Diet is {diet_well_visit}. Exercise: {exercise_well_visit}."
            ],
            "PreventiveCare": [
                "Immunizations up to date: {flu_shot_status_well_visit} flu shot, {pneumo_shot_status_well_visit} pneumococcal vaccine.",
                "Cancer screening: Colonoscopy {colonoscopy_status_well_visit}. Mammogram (if female) {mammogram_status_well_visit}. Pap smear (if female) {pap_status_well_visit}."
            ],
            "PhysicalExam": [
                "Vitals: BP {bp_sys_well}/{bp_dia_well}, HR {hr_well}, RR {rr_well}, Temp {temp_well}°C, BMI {bmi_well}.",
                "General: Alert, well-nourished, in no acute distress. Skin: {skin_exam_well_visit}.",
                "HEENT, Neck, Lungs, Heart, Abdomen, Extremities, Neurological exams are all within normal limits."
            ],
            "LabsOrdered": ["Fasting lipid panel, CMP, HbA1c, TSH ordered today. Results pending."],
            "AssessmentPlan": [
                "Health maintenance examination. Patient is overall healthy with {minor_finding_well_visit}.",
                "Counseling provided on healthy diet, regular exercise, and smoking cessation (if applicable).",
                "Continue current medications. Follow up in 1 year or PRN. Discuss lab results when available."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(25,70), "gender": lambda: random.choice(["male","female"]),
            "last_pe_time": lambda: random.choice(["1 year", "2 years", "several years"]),
            "chronic_condition_status_well_visit": lambda: random.choice(["hypertension well-controlled on lisinopril", "no active chronic conditions", "GERD stable on omeprazole"]),
            "social_habit_well_visit": lambda: random.choice(["non-smoker, drinks alcohol socially", "former smoker, quit 10 years ago", "smokes 0.5 PPD"]),
            "diet_well_visit": lambda: random.choice(["balanced", "could improve, high in processed foods", "vegetarian"]),
            "exercise_well_visit": lambda: random.choice(["walks 30 minutes 3-4 times per week", "sedentary", "active in gym 5 times per week"]),
            "flu_shot_status_well_visit": lambda: random.choice(["received current season's", "declined", "due for"]),
            "pneumo_shot_status_well_visit": lambda: random.choice(["up to date", "not yet eligible", "received PCV13 and PPSV23"]),
            "colonoscopy_status_well_visit": lambda: random.choice(["last done 2 years ago, normal", "due, will schedule", "never had, advised"]),
            "mammogram_status_well_visit": lambda: random.choice(["last done 1 year ago, BI-RADS 1", "due, will schedule", "N/A"]),
            "pap_status_well_visit": lambda: random.choice(["last done 3 years ago, normal", "due", "N/A"]),
            "bp_sys_well": lambda: random.randint(100,130), "bp_dia_well": lambda: random.randint(60,85), "hr_well": lambda: random.randint(55,85),
            "rr_well": lambda: random.randint(12,18), "temp_well": lambda: round(random.uniform(36.5,37.2),1), "bmi_well": lambda: round(random.uniform(19.0,35.0),1),
            "skin_exam_well_visit": lambda: random.choice(["no suspicious lesions", "few benign nevi noted", "dry skin, advised moisturizer"]),
            "minor_finding_well_visit": lambda: random.choice(["well-controlled hypertension", "mild obesity", "no significant new issues"]),
        }
    },
    # - Obstetric Note (Prenatal Visit)
    {
        "title": "Prenatal Visit",
        "demographics": ["{age}-year-old G{gravida}P{para} at {gestational_weeks} weeks gestation by {dating_method}."],
        "sections": {
            "IntervalHistory": [
                "Patient reports {fetal_movement_status} fetal movement. Denies vaginal bleeding, leakage of fluid, or contractions.",
                "Common pregnancy symptoms: {pregnancy_symptom1_ob}, {pregnancy_symptom2_ob}. Taking prenatal vitamins."
            ],
            "PhysicalExam": [
                "Weight: {weight_ob} kg (change of {weight_change_ob} kg since last visit). BP {bp_sys_ob}/{bp_dia_ob}.",
                "Fundal height: {fundal_height_ob} cm. Fetal heart tones (FHT): {fht_ob} bpm by Doppler, regular.",
                "Urine dip: Protein {protein_urine_ob}, glucose {glucose_urine_ob}."
            ],
            "Ultrasound": ["{ultrasound_status_ob}: Estimated fetal weight {efw_ob}g. Amniotic fluid index {afi_ob}. {placenta_location_ob}."],
            "LabsPending": ["Glucose tolerance test (GTT) results pending. Group B Strep (GBS) screen scheduled for {gbs_week_ob} weeks."],
            "AssessmentPlan": [
                "Intrauterine pregnancy at {gestational_weeks} weeks, progressing normally.",
                "Discussed signs of preterm labor, preeclampsia. Reviewed birth plan.",
                "Continue prenatal vitamins. Iron supplementation if anemic. Follow up in {fup_ob_weeks} weeks."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(20,40), "gravida": lambda: random.randint(1,5), "para": lambda: lambda g=random.randint(0,4): min(g, random.randint(0,g)), # Para <= Gravida
            "gestational_weeks": lambda: random.randint(12,38), "dating_method": lambda: random.choice(["LMP", "early ultrasound"]),
            "fetal_movement_status": lambda: random.choice(["good", "consistent", "decreased today, now reassuring"]),
            "pregnancy_symptom1_ob": lambda: random.choice(["mild nausea", "heartburn", "backache", "fatigue"]),
            "pregnancy_symptom2_ob": lambda: random.choice(["leg cramps", "constipation", "no major complaints"]),
            "weight_ob": lambda: random.randint(50,100), "weight_change_ob": lambda: round(random.uniform(0.5,2.0),1),
            "bp_sys_ob": lambda: random.randint(90,130), "bp_dia_ob": lambda: random.randint(50,85),
            "fundal_height_ob": lambda: lambda gw=random.randint(12,38): random.randint(gw-2, gw+2), # Fundal height approx gestational weeks
            "fht_ob": lambda: random.randint(120,160),
            "protein_urine_ob": lambda: random.choice(["negative", "trace"]), "glucose_urine_ob": lambda: random.choice(["negative", "trace"]),
            "ultrasound_status_ob": lambda: random.choice(["Anatomy scan at 20 weeks was normal", "Recent growth scan performed", "No ultrasound this visit"]),
            "efw_ob": lambda: random.randint(500,3500), "afi_ob": lambda: random.randint(8,18), "placenta_location_ob": lambda: random.choice(["Anterior placenta", "Posterior placenta, fundal", "Low-lying placenta identified previously, resolved"]),
            "gbs_week_ob": lambda: random.randint(35,37),
            "fup_ob_weeks": lambda: random.choice([1, 2, 4]),
        }
    },
    # - Oncology (Outpatient Chemo Visit)
    {
        "title": "Oncology - Chemotherapy Visit",
        "demographics": ["{age}-year-old {gender} with {cancer_type} stage {cancer_stage}, here for Cycle {cycle_num} of {chemo_regimen}."],
        "sections": {
            "IntervalHistory": [
                "Patient reports {side_effect1_chemo} and {side_effect2_chemo} since last cycle.",
                "Overall performance status is {ecog_status}. Appetite {appetite_chemo}. Nausea/vomiting {nv_chemo}."
            ],
            "PhysicalExam": [
                "Vitals stable. Weight {weight_chemo} kg. Exam unremarkable or pertinent findings: {pe_finding_chemo}."
            ],
            "Labs": [
                "CBC: WBC {wbc_chemo}, ANC {anc_chemo}, Hgb {hgb_chemo}, Plt {plt_chemo}.",
                "CMP: Creatinine {cr_chemo}, LFTs {lfts_chemo}."
            ],
            "AssessmentPlan": [
                "Tolerating {chemo_regimen} with {toxicity_grade_chemo} toxicity.",
                "Proceed with Cycle {cycle_num} today at full dose / {dose_reduction_chemo} dose reduction.",
                "Continue antiemetics ({antiemetic1}, {antiemetic2}). {growth_factor_support_chemo}.",
                "Follow up prior to next cycle in {fup_chemo_weeks} weeks. Repeat imaging after {imaging_interval_chemo} cycles."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(40,80), "gender": lambda: random.choice(["male","female"]),
            "cancer_type": lambda: random.choice(["colon cancer", "breast cancer", "lung cancer (NSCLC)", "pancreatic cancer", "lymphoma"]),
            "cancer_stage": lambda: random.choice(["II", "III", "IV (metastatic)"]),
            "cycle_num": lambda: random.randint(1,12), "chemo_regimen": lambda: random.choice(["FOLFOX", "FOLFIRI", "Carboplatin/Paclitaxel", "Gemcitabine/Abraxane", "R-CHOP"]),
            "side_effect1_chemo": lambda: random.choice(["fatigue", "neuropathy (grade 1)", "mucositis", "diarrhea"]),
            "side_effect2_chemo": lambda: random.choice(["mild nausea", "decreased appetite", "hand-foot syndrome", "no major issues"]),
            "ecog_status": lambda: random.randint(0,2), "appetite_chemo": lambda: random.choice(["good", "fair", "poor"]),
            "nv_chemo": lambda: random.choice(["well-controlled with prophylactic antiemetics", "occasional breakthrough nausea", "none"]),
            "weight_chemo": lambda: random.randint(50,100), "pe_finding_chemo": lambda: random.choice(["no new findings", "mild peripheral edema", "rash on chest"]),
            "wbc_chemo": lambda: round(random.uniform(2.0,8.0),1), "anc_chemo": lambda: round(random.uniform(1.0,5.0),2)*1000, # ANC in thousands
            "hgb_chemo": lambda: round(random.uniform(8.0,13.0),1), "plt_chemo": lambda: random.randint(50,250),
            "cr_chemo": lambda: round(random.uniform(0.7,1.5),2), "lfts_chemo": lambda: random.choice(["within normal limits", "mildly elevated AST/ALT", "bilirubin normal"]),
            "toxicity_grade_chemo": lambda: random.choice(["manageable grade 1-2", "no significant", "grade 3 requiring intervention"]),
            "dose_reduction_chemo": lambda: random.choice(["no", "20%"]),
            "antiemetic1": lambda: random.choice(["ondansetron", "prochlorperazine"]), "antiemetic2": lambda: random.choice(["dexamethasone", "aprepitant", "none"]),
            "growth_factor_support_chemo": lambda: random.choice(["Neulasta on body injector placed", "No growth factor support needed this cycle", "Filgrastim initiated"]),
            "fup_chemo_weeks": lambda: random.randint(2,4), "imaging_interval_chemo": lambda: random.randint(2,4),
        }
    },
    # - Trauma (Initial ED Evaluation)
    {
        "title": "Trauma Evaluation - ED",
        "demographics": ["{age}-year-old {gender} brought in by EMS as a trauma activation after {trauma_mechanism}."],
        "sections": {
            "PrimarySurvey_ABCDE": [
                "Airway: {airway_trauma}, patent. Breathing: {breathing_trauma}, bilateral breath sounds. Circulation: {circulation_trauma}, no signs of external hemorrhage. BP {bp_trauma}, HR {hr_trauma}.",
                "Disability: GCS {gcs_trauma} ({gcs_e}E{gcs_v}V{gcs_m}M). Pupils {pupils_trauma}. Exposure: Patient fully exposed, {exposure_finding_trauma}."
            ],
            "SecondarySurvey_HPI": [
                "Patient complains of {pain_location1_trauma} and {pain_location2_trauma}. {loss_of_consciousness_trauma} LOC at scene.",
                "Mechanism: {mechanism_details_trauma}. PMH: {pmh_trauma}. Meds: {meds_trauma}. Allergies: {allergies_trauma}."
            ],
            "ImagingTrauma": [
                "FAST exam: {fast_exam_trauma}. Portable CXR: {cxr_trauma}. Pelvis X-ray: {pelvis_xray_trauma}.",
                "Pan-scan (CT head, C-spine, chest, abdomen/pelvis) ordered / in progress / completed, findings pending."
            ],
            "InterventionsED": [
                "Two large-bore IVs placed. {iv_fluid_trauma} initiated. Blood drawn for trauma panel, type and screen.",
                "{intervention1_trauma}. {intervention2_trauma}."
            ],
            "AssessmentPlanED": [
                "{suspected_injury1_trauma}. {suspected_injury2_trauma}. Requires further stabilization and workup.",
                "Consult {consult_service1_trauma} and {consult_service2_trauma}. Admit to {admission_level_trauma}."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(16,70), "gender": lambda: random.choice(["male","female"]),
            "trauma_mechanism": lambda: random.choice(["motor vehicle collision (driver, restrained)", "fall from height (approx {fall_height} feet)", "motorcycle accident", "pedestrian struck", "gunshot wound to {gsw_location}", "stabbing to {stab_location}"]),
            "fall_height": lambda: random.randint(5,20), "gsw_location": lambda: random.choice(["chest","abdomen","extremity"]), "stab_location": lambda: random.choice(["chest","abdomen","back"]),
            "airway_trauma": lambda: random.choice(["clear", "sonorous respirations, jaw thrust applied", "intubated in field"]),
            "breathing_trauma": lambda: random.choice(["spontaneous, good chest rise", "shallow respirations, tachypneic", "diminished breath sounds on left"]),
            "circulation_trauma": lambda: random.choice(["strong peripheral pulses", "cool extremities, tachycardic", "cap refill >2s"]),
            "bp_trauma": lambda: f"{random.randint(80,140)}/{random.randint(50,90)}", "hr_trauma": lambda: random.randint(70,130),
            "gcs_trauma": lambda: random.randint(3,15), "gcs_e": lambda: random.randint(1,4), "gcs_v": lambda: random.randint(1,5), "gcs_m": lambda: random.randint(1,6),
            "pupils_trauma": lambda: random.choice(["equal, round, and reactive to light (PERRL)", "anisocoria R>L, sluggishly reactive", "fixed and dilated (ominous)"]),
            "exposure_finding_trauma": lambda: random.choice(["no obvious deformities beyond primary injury site", "multiple abrasions, laceration to scalp", "significant deformity of right lower extremity"]),
            "pain_location1_trauma": lambda: random.choice(["chest pain", "abdominal pain", "right leg pain", "headache", "neck pain"]),
            "pain_location2_trauma": lambda: random.choice(["back pain", "pelvic pain", "left arm pain", "none other significant"]),
            "loss_of_consciousness_trauma": lambda: random.choice(["No", "Brief (<1 min)", "Prolonged, per EMS"]),
            "mechanism_details_trauma": lambda: random.choice(["High-speed MVC, significant vehicle damage", "Fell from ladder onto concrete", "Reported assault", "Self-inflicted GSW"]),
            "pmh_trauma": lambda: random.choice(["None", "Hypertension", "Diabetes", "CAD"]), "meds_trauma": lambda: random.choice(["None", "Aspirin", "Lisinopril", "Metformin"]), "allergies_trauma": lambda: random.choice(["NKDA", "Penicillin", "Contrast dye"]),
            "fast_exam_trauma": lambda: random.choice(["Negative", "Positive for free fluid in Morrison's pouch", "Inconclusive"]),
            "cxr_trauma": lambda: random.choice(["No pneumothorax or hemothorax", "Left-sided rib fractures noted", "ET tube in good position"]),
            "pelvis_xray_trauma": lambda: random.choice(["Stable pelvis", "Open book pelvic fracture", "Pubic rami fracture"]),
            "iv_fluid_trauma": lambda: random.choice(["1L Normal Saline bolus", "Lactated Ringers wide open"]),
            "intervention1_trauma": lambda: random.choice(["Pain medication administered (IV morphine)", "Tetanus shot given", "Cervical collar placed"]),
            "intervention2_trauma": lambda: random.choice(["Tranexamic acid (TXA) administered", "Chest tube placed for pneumothorax", "Splint applied to extremity", "Nothing further at this time"]),
            "suspected_injury1_trauma": lambda: random.choice(["Multiple rib fractures", "Splenic laceration", "Closed head injury", "Femur fracture"]),
            "suspected_injury2_trauma": lambda: random.choice(["Pneumothorax", "Liver contusion", "Cervical spine injury (rule out)", "Pelvic fracture", "None other immediately apparent"]),
            "consult_service1_trauma": lambda: random.choice(["Trauma Surgery", "Orthopedic Surgery", "Neurosurgery"]),
            "consult_service2_trauma": lambda: random.choice(["General Surgery", "Vascular Surgery", "Critical Care", "none other"]),
            "admission_level_trauma": lambda: random.choice(["Trauma ICU", "Surgical ICU", "step-down unit", "floor bed if stable minor trauma"]),
        }
    },
    # - Outpatient Clinic Visit (General Internal Medicine)
    {
        "title": "Outpatient IM Clinic Visit",
        "demographics": ["{age}-year-old {gender} here for {visit_reason_op_im}."],
        "sections": {
            "Subjective": [
                "Patient reports {symptom_status_op_im} regarding {primary_complaint_op_im}. Current medications reviewed: {med_review_op_im}.",
                "Any new issues or concerns since last visit {last_visit_op_im} ago? {new_issue_op_im}."
            ],
            "Objective_Vitals": ["BP {bp_op_im}, HR {hr_op_im}, Wt {wt_op_im} lbs, Temp {temp_op_im}°C."],
            "Objective_Exam": ["{exam_focus_op_im} exam: {exam_finding_op_im}. Other pertinent findings: {other_exam_finding_op_im}."],
            "Labs_Recent": ["Recent labs (if any): HgbA1c {hba1c_op_im}, Lipids {lipids_op_im}, Cr {cr_op_im}."],
            "Assessment": ["{dx1_op_im}: {status_dx1_op_im}. {dx2_op_im}: {status_dx2_op_im}."],
            "Plan": [
                "Medication adjustment: {med_adjust_op_im}. Continue {med_continue_op_im}.",
                "Order {lab_ordered_op_im}. Health maintenance: {health_maint_op_im} discussed/updated.",
                "Refer to {specialist_referral_op_im} for {referral_reason_op_im}. Follow up here in {fup_op_im}."
            ]
        },
        "placeholders": {
            "age": lambda: random.randint(40,80), "gender": lambda: random.choice(["male","female"]),
            "visit_reason_op_im": lambda: random.choice(["follow-up of chronic conditions", "acute problem: cough", "medication refill", "annual check-up if not covered by Well Visit"]),
            "symptom_status_op_im": lambda: random.choice(["stable", "improved", "worsening", "no change"]),
            "primary_complaint_op_im": lambda: random.choice(["hypertension management", "diabetes control", "back pain", "fatigue"]),
            "med_review_op_im": lambda: random.choice(["no changes", "added new medication last month", "patient compliant"]),
            "last_visit_op_im": lambda: random.choice(["3 months", "6 months", "1 year"]),
            "new_issue_op_im": lambda: random.choice(["none", "reports new onset knee pain", "recent viral illness, resolved"]),
            "bp_op_im": lambda: f"{random.randint(110,160)}/{random.randint(70,95)}", "hr_op_im": lambda: random.randint(60,90), "wt_op_im": lambda: random.randint(120,250), "temp_op_im": lambda: round(random.uniform(36.5,37.2),1),
            "exam_focus_op_im": lambda: random.choice(["Cardiovascular", "Pulmonary", "Musculoskeletal", "Focused"]),
            "exam_finding_op_im": lambda: random.choice(["normal S1/S2, no murmur", "lungs clear", "mild tenderness over lumbar spine", "no acute distress"]),
            "other_exam_finding_op_im": lambda: random.choice(["no edema", "good peripheral pulses", "skin clear", "within normal limits"]),
            "hba1c_op_im": lambda: random.choice(["not done recently", f"{round(random.uniform(5.5,9.0),1)}%"]),
            "lipids_op_im": lambda: random.choice(["LDL {ldl_val}", "within goal on statin", "pending"]), "ldl_val": lambda: random.randint(70,160),
            "cr_op_im": lambda: random.choice([f"{round(random.uniform(0.7,1.4),2)}", "stable"]),
            "dx1_op_im": lambda: random.choice(["Hypertension", "Type 2 Diabetes", "Hyperlipidemia", "Chronic Back Pain"]),
            "status_dx1_op_im": lambda: random.choice(["controlled", "suboptimal control", "stable", "exacerbated"]),
            "dx2_op_im": lambda: random.choice(["GERD", "Asthma", "Obesity", "None other active"]),
            "status_dx2_op_im": lambda: random.choice(["stable on PPI", "using inhaler PRN", "counseled on weight loss", ""]),
            "med_adjust_op_im": lambda: random.choice(["Increase lisinopril to 20mg", "Start metformin 500mg BID", "No changes today", "Add HCTZ 12.5mg"]),
            "med_continue_op_im": lambda: random.choice(["current regimen", "atorvastatin", "aspirin"]),
            "lab_ordered_op_im": lambda: random.choice(["fasting lipid panel and CMP in 6 months", "repeat A1c in 3 months", "TSH today", "UA if symptomatic"]),
            "health_maint_op_im": lambda: random.choice(["colon cancer screening discussed", "mammogram due", "flu shot given", "smoking cessation offered"]),
            "specialist_referral_op_im": lambda: random.choice(["Cardiology", "Endocrinology", "Orthopedics", "Physical Therapy", "none at this time"]),
            "referral_reason_op_im": lambda: random.choice(["persistent chest pain", "uncontrolled diabetes", "severe knee arthritis", "low back pain exercises"]),
            "fup_op_im": lambda: random.choice(["3 months", "6 months", "1 year", "PRN"]),
        }
    },

]

# --- (fill_placeholders and generate_rich_note_v2 functions as previously defined) ---
def fill_placeholders(text, placeholder_values):
    for key, value_func in placeholder_values.items():
        placeholder_tag = "{" + key + "}"
        # Need to handle cases where a value_func might itself need other placeholders (not done here for simplicity)
        # or where value_func returns a number that needs to be str
        if placeholder_tag in text:
            # If value_func is a lambda that needs another placeholder's value, this simple replacement won't work.
            # For this example, assume value_func directly returns the value or is parameterless.
            try:
                replacement_value = value_func()
                # Handle cases where lambda might return another lambda (e.g. fundal_height_ob, para)
                if callable(replacement_value):
                    # This is a simplification; might need actual parameters if the inner lambda expects them
                    # For now, just call it if it's callable without args, or use a default if it fails
                    try:
                        replacement_value = replacement_value()
                    except TypeError: # Fails if inner lambda needs args we don't have here
                        replacement_value = "N/A" # Or some other default
                text = text.replace(placeholder_tag, str(replacement_value))
            except Exception as e:
                print(f"Error filling placeholder {placeholder_tag} with function {value_func}: {e}")
                # Keep placeholder if error
    return text

def generate_rich_note_v2():
    archetype = random.choice(archetypes)
    sections_data = archetype["sections"]
    # Pass the entire placeholder map so lambdas can be resolved
    placeholder_map_for_archetype = archetype.get("placeholders", {}) 

    note_parts = []

    if "demographics" in archetype and archetype["demographics"] and random.random() > 0.1:
        demo_sentence = random.choice(archetype["demographics"])
        note_parts.append(fill_placeholders(demo_sentence, placeholder_map_for_archetype).strip('.'))

    section_order = list(sections_data.keys())
    if random.random() > 0.3: # Increased chance of shuffling section order
        random.shuffle(section_order)
    
    # Ensure at least one section is included, up to all of them
    min_sections = 1 
    # More variability in number of sections
    num_sections_to_include = random.randint(min_sections, len(section_order)) 
    sections_to_actually_include = random.sample(section_order, k=num_sections_to_include)

    for section_name in sections_to_actually_include:
        if len(note_parts) > 0 and random.random() < 0.05 and len(sections_to_actually_include) > 1 : 
            continue

        section_content_options = sections_data[section_name]
        if section_content_options: 
            max_sents = len(section_content_options)
            num_sentences_to_pick = random.randint(1, max_sents)
            chosen_sentences_raw = random.sample(section_content_options, k=num_sentences_to_pick)
            
            chosen_sentences_filled = [fill_placeholders(s, placeholder_map_for_archetype).strip('.') for s in chosen_sentences_raw]
            
            section_text = f"{section_name}: {' '.join(s for s in chosen_sentences_filled if s)}." # Ensure not joining empty strings
            note_parts.append(section_text)
    
    final_note = ' '.join(pt for pt in note_parts if pt) # Ensure not joining empty section strings
    return final_note.strip()


# --- Main execution ---
if __name__ == "__main__":
    num_notes_to_generate = 1000000 # Start with a smaller number for testing
    output_path_flat = "./synthetic_training_corpus_expanded.txt" 

    print(f"Starting generation of {num_notes_to_generate} notes...")
    with open(output_path_flat, "w", encoding="utf-8") as f:
        for i in range(num_notes_to_generate):
            if (i + 1) % 5000 == 0: 
                print(f"  Generated {i+1}/{num_notes_to_generate} notes...")
            note = generate_rich_note_v2()
            if note: 
                f.write(note + "\n")

    print(f"Finished generating {num_notes_to_generate} notes to {output_path_flat}")

    print("\n--- First 5 Sample Generated Notes ---")
    with open(output_path_flat, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if i < 5:
                print(f"Note {i+1}: {line.strip()}")
            else:
                break