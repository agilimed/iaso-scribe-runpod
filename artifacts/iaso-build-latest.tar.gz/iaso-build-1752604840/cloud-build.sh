#!/bin/bash
set -e

# This script runs in AWS Cloud Shell or any environment with Docker and AWS CLI

# Configuration
AWS_REGION="us-west-2"
AWS_ACCOUNT_ID="727646479986"
ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
ECR_REPO_PREFIX="iaso"
IMAGE_TAG="${1:-latest}"

echo "🚀 Starting IASO ECR build process..."
echo "Region: $AWS_REGION"
echo "Account: $AWS_ACCOUNT_ID"
echo "Tag: $IMAGE_TAG"

# Login to ECR
echo "🔐 Logging into ECR..."
aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin $ECR_REGISTRY

# Services to build
declare -A services=(
    ["clinical-ai"]="clinical-ai/clinicalai_service"
    ["terminology"]="clinical-ai/terminology_service"
    ["knowledge"]="clinical-ai/knowledge_service"
    ["template"]="clinical-ai/template_service"
    ["slm"]="clinical-ai/slm_service"
    ["api-gateway"]="insights-ai"
    ["embeddings"]="services/embeddings-service"
)

# Create ECR repositories
echo "📦 Creating ECR repositories..."
for service in "${!services[@]}"; do
    repo_name="${ECR_REPO_PREFIX}-${service}"
    
    if aws ecr describe-repositories --repository-names $repo_name --region $AWS_REGION >/dev/null 2>&1; then
        echo "   Repository $repo_name already exists"
    else
        echo "   Creating repository $repo_name..."
        aws ecr create-repository \
            --repository-name $repo_name \
            --region $AWS_REGION \
            --image-scanning-configuration scanOnPush=true \
            --encryption-configuration encryptionType=AES256
    fi
done

# Build and push images
echo "🏗️  Building and pushing images..."
for service in "${!services[@]}"; do
    service_dir="${services[$service]}"
    image_name="${ECR_REGISTRY}/${ECR_REPO_PREFIX}-${service}:${IMAGE_TAG}"
    
    echo ""
    echo "Building $service..."
    echo "  Directory: $service_dir"
    echo "  Image: $image_name"
    
    if [ -f "$service_dir/Dockerfile" ]; then
        # Build with proper context for clinical-ai services
        if [[ $service_dir == clinical-ai/* ]]; then
            docker build -t $image_name -f $service_dir/Dockerfile clinical-ai/
        else
            docker build -t $image_name $service_dir
        fi
        
        if [ $? -eq 0 ]; then
            echo "✅ Build successful"
            echo "📤 Pushing to ECR..."
            docker push $image_name
            echo "✅ Push successful"
        else
            echo "❌ Build failed for $service"
        fi
    else
        echo "❌ Dockerfile not found in $service_dir"
    fi
done

echo ""
echo "✅ All builds complete!"
echo ""
echo "📋 Image URIs:"
for service in "${!services[@]}"; do
    echo "  ${service}: ${ECR_REGISTRY}/${ECR_REPO_PREFIX}-${service}:${IMAGE_TAG}"
done
