const axios = require('axios');

async function checkChunkDistribution() {
  console.log('📊 Checking Chunk Distribution\n');
  
  try {
    // Get all chunks
    const response = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 2000,
      with_payload: ['chunk_type', 'resource_type']
    });
    
    const chunks = response.data.result.points;
    
    // Analyze chunk types
    const chunkTypes = {};
    const resourceTypes = {};
    
    chunks.forEach(chunk => {
      const chunkType = chunk.payload.chunk_type;
      const resourceType = chunk.payload.resource_type;
      
      chunkTypes[chunkType] = (chunkTypes[chunkType] || 0) + 1;
      resourceTypes[resourceType] = (resourceTypes[resourceType] || 0) + 1;
    });
    
    console.log('📋 CHUNK TYPE DISTRIBUTION:');
    Object.entries(chunkTypes)
      .sort(([,a], [,b]) => b - a)
      .forEach(([type, count]) => {
        console.log(`   ${type}: ${count} chunks (${((count/chunks.length)*100).toFixed(1)}%)`);
      });
    
    console.log('\n📋 RESOURCE TYPE DISTRIBUTION:');
    Object.entries(resourceTypes)
      .sort(([,a], [,b]) => b - a)
      .forEach(([type, count]) => {
        console.log(`   ${type}: ${count} chunks`);
      });
    
    console.log(`\n📊 TOTAL: ${chunks.length} chunks`);
    
    // Check for contact chunks specifically
    const contactChunks = chunks.filter(c => c.payload.chunk_type === 'contact');
    console.log(`\n🔍 Contact chunks: ${contactChunks.length}`);
    
    if (contactChunks.length === 0) {
      console.log('❌ NO CONTACT CHUNKS FOUND - This explains the 0% contact retrieval!');
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

checkChunkDistribution()
  .then(() => console.log('\n✅ Complete!'))
  .catch(error => console.error('❌ Failed:', error.message));