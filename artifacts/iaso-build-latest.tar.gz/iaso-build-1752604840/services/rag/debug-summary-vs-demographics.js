const axios = require('axios');

async function debugSummaryVsDemographics() {
  console.log('🔍 Debug: Summary vs Demographics Chunk Competition\n');
  
  try {
    // Get sample summary chunk
    const summaryResponse = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 1,
      with_payload: true,
      filter: {
        must: [
          { key: 'chunk_type', match: { value: 'summary' } },
          { key: 'resource_type', match: { value: 'Patient' } }
        ]
      }
    });
    
    // Get sample demographics chunk  
    const demographicsResponse = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 1,
      with_payload: true,
      filter: {
        must: [
          { key: 'chunk_type', match: { value: 'demographics' } }
        ]
      }
    });
    
    if (summaryResponse.data.result.points.length > 0 && demographicsResponse.data.result.points.length > 0) {
      const summaryChunk = summaryResponse.data.result.points[0];
      const demographicsChunk = demographicsResponse.data.result.points[0];
      
      console.log('📋 SUMMARY CHUNK:');
      console.log(`Content: "${summaryChunk.payload.content.substring(0, 200)}..."`);
      console.log(`Searchable Terms: [${(summaryChunk.payload.searchable_terms || []).join(', ')}]\n`);
      
      console.log('📋 DEMOGRAPHICS CHUNK:');
      console.log(`Content: "${demographicsChunk.payload.content.substring(0, 200)}..."`);
      console.log(`Searchable Terms: [${(demographicsChunk.payload.searchable_terms || []).join(', ')}]\n`);
      
      console.log('🎯 ISSUE ANALYSIS:');
      console.log('Summary chunks contain demographic info but lack "demographics" semantic terms');
      console.log('Query "show me patient demographics" matches summary content + "patient" term');
      console.log('But demographics chunks have explicit "demographics" term that should rank higher\n');
      
      // Test individual scores
      const queryEmbedding = (await axios.post('http://localhost:8050/embeddings', {
        texts: ['show me patient demographics'],
        model: 'bge-m3'
      })).data.embeddings[0];
      
      // Score summary chunk
      const summaryScore = await axios.post('http://localhost:6333/collections/fhir_chunks/points/search', {
        vector: queryEmbedding,
        limit: 1,
        with_payload: false,
        filter: {
          must: [{ key: 'id', match: { value: summaryChunk.id } }]
        }
      });
      
      // Score demographics chunk  
      const demographicsScore = await axios.post('http://localhost:6333/collections/fhir_chunks/points/search', {
        vector: queryEmbedding,
        limit: 1,
        with_payload: false,
        filter: {
          must: [{ key: 'id', match: { value: demographicsChunk.id } }]
        }
      });
      
      console.log('📊 SCORES:');
      console.log(`Summary chunk score: ${summaryScore.data.result[0]?.score.toFixed(3) || 'N/A'}`);
      console.log(`Demographics chunk score: ${demographicsScore.data.result[0]?.score.toFixed(3) || 'N/A'}\n`);
      
      console.log('💡 SOLUTION:');
      console.log('Demographics chunks need stronger semantic alignment or summary chunks need demographics terms');
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

debugSummaryVsDemographics()
  .then(() => console.log('\n🎉 Debug Complete!'))
  .catch(error => console.error('❌ Debug failed:', error.message));