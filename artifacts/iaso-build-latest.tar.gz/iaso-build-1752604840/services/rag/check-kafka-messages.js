const { Kafka } = require('kafkajs');

async function checkKafkaMessages() {
  const kafka = new Kafka({
    clientId: 'debug-client',
    brokers: ['localhost:9092']
  });

  const admin = kafka.admin();
  const consumer = kafka.consumer({ 
    groupId: 'debug-consumer-' + Date.now() // Unique group to read from beginning
  });

  try {
    // Check admin info
    await admin.connect();
    console.log('🔍 Connected to Kafka admin\n');

    // List all topics
    const topics = await admin.listTopics();
    console.log('📋 Available topics:', topics);
    console.log('');

    // Check if fhir.events exists
    if (!topics.includes('fhir.events')) {
      console.log('❌ Topic "fhir.events" does not exist!');
      console.log('Available topics:', topics.join(', '));
      return;
    }

    // Get topic metadata
    const metadata = await admin.fetchTopicMetadata({ topics: ['fhir.events'] });
    console.log('📊 Topic metadata:', JSON.stringify(metadata, null, 2));

    // Get topic offsets
    const offsets = await admin.fetchTopicOffsets('fhir.events');
    console.log('\n📍 Topic offsets:', JSON.stringify(offsets, null, 2));

    // Check consumer group
    const groups = await admin.listGroups();
    console.log('\n👥 Consumer groups:', groups.groups.map(g => g.groupId));

    // Read some messages
    await consumer.connect();
    await consumer.subscribe({ topic: 'fhir.events', fromBeginning: true });

    console.log('\n📨 Reading last 10 messages from topic...\n');
    
    let messageCount = 0;
    const messages = [];

    await consumer.run({
      eachMessage: async ({ topic, partition, message }) => {
        messageCount++;
        messages.push({
          partition,
          offset: message.offset,
          key: message.key?.toString(),
          value: message.value?.toString().substring(0, 200) + '...',
          timestamp: new Date(parseInt(message.timestamp)).toISOString()
        });

        if (messageCount >= 10) {
          console.log('Last 10 messages:', JSON.stringify(messages, null, 2));
          await consumer.disconnect();
          await admin.disconnect();
          process.exit(0);
        }
      },
    });

    // Timeout after 5 seconds if no messages
    setTimeout(async () => {
      console.log(`\n📭 Found ${messageCount} messages in topic`);
      if (messageCount === 0) {
        console.log('❌ No messages found in fhir.events topic!');
      }
      await consumer.disconnect();
      await admin.disconnect();
      process.exit(0);
    }, 5000);

  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

checkKafkaMessages();