const axios = require('axios');

async function debugSemanticTerms() {
  console.log('🔍 Debug: Enhanced Semantic Terms\n');
  
  try {
    // Get recent temporal chunks to check for enhanced terms
    const temporalResponse = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 5,
      with_payload: true,
      filter: {
        must: [
          { key: 'chunk_type', match: { value: 'temporal' } }
        ]
      }
    });
    
    console.log('📅 TEMPORAL CHUNKS (should have "recent", "latest", "last"):');
    temporalResponse.data.result.points.forEach((chunk, index) => {
      const terms = chunk.payload.searchable_terms || [];
      console.log(`\n${index + 1}. Resource: ${chunk.payload.resource_type}/${chunk.payload.resource_id}`);
      console.log(`   Searchable terms: [${terms.slice(0, 10).join(', ')}]`);
      
      const hasEnhanced = terms.some(term => 
        ['recent', 'latest', 'last', 'last visit', 'recent visit'].includes(term.toLowerCase())
      );
      console.log(`   Has enhanced terms: ${hasEnhanced ? '✅' : '❌'}`);
    });
    
    // Get clinical chunks to check for "multiple conditions", "comorbidities"
    const clinicalResponse = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 5,
      with_payload: true,
      filter: {
        must: [
          { key: 'chunk_type', match: { value: 'clinical' } },
          { key: 'resource_type', match: { value: 'Condition' } }
        ]
      }
    });
    
    console.log('\n\n🏥 CLINICAL CONDITION CHUNKS (should have "comorbidities", "multiple conditions"):');
    clinicalResponse.data.result.points.forEach((chunk, index) => {
      const terms = chunk.payload.searchable_terms || [];
      console.log(`\n${index + 1}. Resource: ${chunk.payload.resource_type}/${chunk.payload.resource_id}`);
      console.log(`   Searchable terms: [${terms.slice(0, 10).join(', ')}]`);
      
      const hasEnhanced = terms.some(term => 
        ['comorbidities', 'multiple conditions', 'chronic', 'acute'].includes(term.toLowerCase())
      );
      console.log(`   Has enhanced terms: ${hasEnhanced ? '✅' : '❌'}`);
    });
    
    // Check relationship chunks
    const relationshipResponse = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 3,
      with_payload: true,
      filter: {
        must: [
          { key: 'chunk_type', match: { value: 'relationship' } }
        ]
      }
    });
    
    console.log('\n\n🔗 RELATIONSHIP CHUNKS:');
    relationshipResponse.data.result.points.forEach((chunk, index) => {
      const terms = chunk.payload.searchable_terms || [];
      console.log(`\n${index + 1}. Resource: ${chunk.payload.resource_type}/${chunk.payload.resource_id}`);
      console.log(`   Content: "${chunk.payload.content.substring(0, 200)}..."`);
      console.log(`   Searchable terms: [${terms.slice(0, 8).join(', ')}]`);
      
      if (chunk.payload.relationships) {
        console.log(`   Related resources: ${chunk.payload.relationships.relatedResources?.length || 0}`);
        if (chunk.payload.relationships.relatedResources?.length > 0) {
          const sample = chunk.payload.relationships.relatedResources[0];
          console.log(`   Sample relationship: ${sample.resourceType}/${sample.resourceId} (${sample.relationship})`);
        }
      }
    });
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

debugSemanticTerms()
  .then(() => console.log('\n✅ Debug Complete!'))
  .catch(error => console.error('❌ Debug failed:', error.message));