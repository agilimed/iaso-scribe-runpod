const axios = require('axios');

async function checkDuplicates() {
  console.log('🔍 Checking for Duplicate Patient Data\n');
  
  try {
    // Get all chunks
    const allData = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 1200,
      with_payload: ['resource_type', 'resource_id', 'patient_id', 'content', 'chunk_type', 'timestamp']
    });
    
    const chunks = allData.data.result.points;
    console.log(`📊 Total chunks: ${chunks.length}\n`);
    
    // Analyze by resource ID
    const resourceCounts = {};
    const patientCounts = {};
    
    chunks.forEach(chunk => {
      const resourceKey = `${chunk.payload.resource_type}/${chunk.payload.resource_id}`;
      const patientId = chunk.payload.patient_id;
      
      resourceCounts[resourceKey] = (resourceCounts[resourceKey] || 0) + 1;
      patientCounts[patientId] = (patientCounts[patientId] || 0) + 1;
    });
    
    // Find duplicates
    const duplicateResources = Object.entries(resourceCounts)
      .filter(([resource, count]) => count > 10) // More than 10 chunks per resource is suspicious
      .sort(([,a], [,b]) => b - a);
    
    const duplicatePatients = Object.entries(patientCounts)
      .filter(([patient, count]) => count > 50) // More than 50 chunks per patient is suspicious
      .sort(([,a], [,b]) => b - a);
    
    console.log('🚨 DUPLICATE RESOURCES (>10 chunks):');
    duplicateResources.slice(0, 10).forEach(([resource, count]) => {
      console.log(`   ${resource}: ${count} chunks`);
    });
    
    console.log(`\n🚨 DUPLICATE PATIENTS (>50 chunks):`);
    duplicatePatients.slice(0, 10).forEach(([patient, count]) => {
      console.log(`   Patient ${patient}: ${count} chunks`);
    });
    
    // Check for identical content
    console.log('\n🔍 Checking for identical content...');
    const contentGroups = {};
    
    chunks.forEach(chunk => {
      const contentKey = chunk.payload.content.substring(0, 100); // First 100 chars
      if (!contentGroups[contentKey]) {
        contentGroups[contentKey] = [];
      }
      contentGroups[contentKey].push(chunk);
    });
    
    const identicalContent = Object.entries(contentGroups)
      .filter(([content, chunks]) => chunks.length > 5)
      .sort(([,a], [,b]) => b.length - a.length);
    
    console.log('🔄 IDENTICAL CONTENT (>5 occurrences):');
    identicalContent.slice(0, 5).forEach(([content, chunks]) => {
      console.log(`   "${content}..." appears ${chunks.length} times`);
      console.log(`     Resource types: [${[...new Set(chunks.map(c => c.payload.resource_type))].join(', ')}]`);
      console.log(`     Chunk types: [${[...new Set(chunks.map(c => c.payload.chunk_type))].join(', ')}]\n`);
    });
    
    // Check timestamps to see if they're recent duplicates
    console.log('⏰ RECENT DUPLICATES (last 10 minutes):');
    const recentTime = new Date(Date.now() - 10 * 60 * 1000);
    const recentChunks = chunks.filter(c => new Date(c.payload.timestamp) > recentTime);
    
    const recentResources = {};
    recentChunks.forEach(chunk => {
      const resourceKey = `${chunk.payload.resource_type}/${chunk.payload.resource_id}`;
      recentResources[resourceKey] = (recentResources[resourceKey] || 0) + 1;
    });
    
    const recentDuplicates = Object.entries(recentResources)
      .filter(([resource, count]) => count > 5)
      .sort(([,a], [,b]) => b - a);
    
    recentDuplicates.slice(0, 10).forEach(([resource, count]) => {
      console.log(`   ${resource}: ${count} chunks in last 10 minutes`);
    });
    
    // Impact analysis
    console.log('\n📈 IMPACT ANALYSIS:');
    const totalDuplicateChunks = duplicateResources.reduce((sum, [, count]) => sum + (count - 5), 0); // Assuming 5 chunks per resource is normal
    console.log(`   Estimated duplicate chunks: ${totalDuplicateChunks}`);
    console.log(`   Storage bloat: ${((totalDuplicateChunks / chunks.length) * 100).toFixed(1)}%`);
    
    if (duplicateResources.length > 0 || duplicatePatients.length > 0) {
      console.log('\n💡 RECOMMENDATIONS:');
      console.log('   1. Clear Qdrant collection and resend clean data');
      console.log('   2. Or implement upsert logic to prevent duplicates');
      console.log('   3. Add resource deduplication in the backend');
    } else {
      console.log('\n✅ No significant duplicates found!');
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

checkDuplicates()
  .then(() => console.log('\n🎉 Duplicate Check Complete!'))
  .catch(error => console.error('❌ Check failed:', error.message));