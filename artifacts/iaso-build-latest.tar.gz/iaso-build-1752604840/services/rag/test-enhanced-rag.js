const axios = require('axios');

// Enhanced test queries for comprehensive FHIR resource testing
const testQueries = [
  // Previous working queries
  "Find patients from Boston",
  "Show me patients with MRN starting with MRN-00",
  "Who are the male patients?",
  
  // Enhanced date/age queries (previously failed)
  "Find patients born in 1985",
  "Show me patients aged 30-40 years",
  "Find young adult patients",
  "Show me middle aged patients",
  "Find elderly patients",
  
  // Contact information queries (improved)
  "Show me contact information for patients",
  "Find patients with phone numbers",
  "Show me patients with email addresses",
  "Find patients with residential addresses",
  
  // Clinical resource queries (new capabilities)
  "Find observations with high values",
  "Show me blood pressure measurements",
  "Find conditions that are active",
  "Show me surgical procedures",
  "Find medication requests",
  "Show me allergy information",
  
  // Temporal queries (new capabilities)
  "Find recent observations",
  "Show me procedures from 2024",
  "Find conditions recorded this year",
  
  // Multi-resource complex queries
  "Find clinical information for Boston patients",
  "Show me all medical codes and diagnoses",
  "Find financial and billing information"
];

async function testEnhancedRAGPipeline() {
  console.log('🧪 Testing Enhanced RAG Pipeline with Comprehensive FHIR Support\n');
  
  try {
    // Get current collection stats
    const collectionInfo = await axios.get('http://localhost:6333/collections/fhir_chunks');
    console.log(`📊 Collection Stats:`);
    console.log(`- Total chunks: ${collectionInfo.data.result.points_count}`);
    console.log(`- Vector dimensions: ${collectionInfo.data.result.config.params.vectors.size}`);
    
    // Get chunk type distribution
    const chunkStats = await getChunkTypeDistribution();
    console.log(`- Chunk types: ${Object.entries(chunkStats).map(([type, count]) => `${type}(${count})`).join(', ')}\n`);

    let successfulQueries = 0;
    let totalQueries = testQueries.length;

    for (const query of testQueries) {
      console.log(`\n🔍 Query: "${query}"`);
      console.log('=' .repeat(60));
      
      try {
        // Generate embedding for the query
        const queryEmbedding = await generateQueryEmbedding(query);
        
        // Search Qdrant for similar chunks
        const searchResults = await searchQdrant(queryEmbedding, 5);
        
        if (searchResults.length > 0) {
          successfulQueries++;
          await analyzeResults(query, searchResults);
        } else {
          console.log('❌ No relevant results found');
        }
        
      } catch (error) {
        console.log(`❌ Error processing query: ${error.message}`);
      }
    }

    console.log(`\n📈 Query Success Rate: ${successfulQueries}/${totalQueries} (${Math.round(successfulQueries/totalQueries*100)}%)`);
    
    // Test chunk type coverage
    await testChunkTypeCoverage();
    
    // Test semantic similarity quality
    await testSemanticQuality();
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

async function generateQueryEmbedding(query) {
  const response = await axios.post('http://localhost:8050/embeddings', {
    texts: [query],
    model: 'bge-m3'
  });
  
  if (!response.data.embeddings || response.data.embeddings.length === 0) {
    throw new Error('Failed to generate query embedding');
  }
  
  return response.data.embeddings[0];
}

async function searchQdrant(vector, limit = 5) {
  const response = await axios.post('http://localhost:6333/collections/fhir_chunks/points/search', {
    vector: vector,
    limit: limit,
    with_payload: true,
    score_threshold: 0.3  // Lower threshold to catch more results
  });
  
  return response.data.result;
}

async function analyzeResults(query, results) {
  console.log(`✅ Found ${results.length} relevant chunks:`);
  
  // Group by chunk type for analysis
  const chunkTypeDistribution = {};
  const resourceTypeDistribution = {};
  
  results.forEach((result, index) => {
    const chunkType = result.payload.chunk_type;
    const resourceType = result.payload.resource_type;
    
    chunkTypeDistribution[chunkType] = (chunkTypeDistribution[chunkType] || 0) + 1;
    resourceTypeDistribution[resourceType] = (resourceTypeDistribution[resourceType] || 0) + 1;
    
    console.log(`\n${index + 1}. Score: ${result.score.toFixed(4)} | ${resourceType}/${result.payload.resource_id} (${chunkType})`);
    console.log(`   Content: ${result.payload.content.substring(0, 150)}...`);
    
    if (result.payload.searchable_terms && result.payload.searchable_terms.length > 0) {
      console.log(`   Key Terms: ${result.payload.searchable_terms.slice(0, 5).join(', ')}`);
    }
  });
  
  console.log(`\n📊 Result Distribution:`);
  console.log(`   Chunk Types: ${Object.entries(chunkTypeDistribution).map(([type, count]) => `${type}(${count})`).join(', ')}`);
  console.log(`   Resource Types: ${Object.entries(resourceTypeDistribution).map(([type, count]) => `${type}(${count})`).join(', ')}`);
  console.log(`   Avg Relevance: ${(results.reduce((sum, r) => sum + r.score, 0) / results.length).toFixed(3)}`);
}

async function getChunkTypeDistribution() {
  const scrollResult = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
    limit: 1000,
    with_payload: ['chunk_type']
  });
  
  const distribution = {};
  scrollResult.data.result.points.forEach(point => {
    const type = point.payload.chunk_type;
    distribution[type] = (distribution[type] || 0) + 1;
  });
  
  return distribution;
}

async function testChunkTypeCoverage() {
  console.log('\n\n🎯 Testing Chunk Type Coverage');
  console.log('=' .repeat(60));
  
  const expectedChunkTypes = [
    'summary', 'demographics', 'identifiers', 'contact', 
    'clinical', 'administrative', 'financial', 'codes', 'temporal'
  ];
  
  const actualDistribution = await getChunkTypeDistribution();
  
  console.log('Chunk Type Coverage:');
  expectedChunkTypes.forEach(type => {
    const count = actualDistribution[type] || 0;
    const status = count > 0 ? '✅' : '❌';
    console.log(`${status} ${type}: ${count} chunks`);
  });
  
  const coveragePercentage = Object.keys(actualDistribution).length / expectedChunkTypes.length * 100;
  console.log(`\n📈 Coverage: ${Math.round(coveragePercentage)}% of expected chunk types`);
}

async function testSemanticQuality() {
  console.log('\n\n🔬 Testing Semantic Quality');
  console.log('=' .repeat(60));
  
  const semanticTests = [
    {
      query: "blood pressure measurement",
      expectedChunkType: "clinical",
      expectedResourceType: "observation"
    },
    {
      query: "patient contact phone number",
      expectedChunkType: "contact",
      expectedResourceType: "patient"
    },
    {
      query: "medical record number MRN",
      expectedChunkType: "identifiers",
      expectedResourceType: "patient"
    },
    {
      query: "patient demographics age gender",
      expectedChunkType: "demographics",
      expectedResourceType: "patient"
    }
  ];
  
  let passedTests = 0;
  
  for (const test of semanticTests) {
    console.log(`\nTest: "${test.query}"`);
    
    try {
      const queryEmbedding = await generateQueryEmbedding(test.query);
      const results = await searchQdrant(queryEmbedding, 3);
      
      if (results.length > 0) {
        const topResult = results[0];
        const matchesChunkType = topResult.payload.chunk_type === test.expectedChunkType;
        const matchesResourceType = topResult.payload.resource_type === test.expectedResourceType;
        
        if (matchesChunkType && matchesResourceType) {
          passedTests++;
          console.log(`✅ PASS - Found ${test.expectedChunkType} chunk for ${test.expectedResourceType} (score: ${topResult.score.toFixed(3)})`);
        } else {
          console.log(`❌ FAIL - Expected ${test.expectedChunkType}/${test.expectedResourceType}, got ${topResult.payload.chunk_type}/${topResult.payload.resource_type}`);
        }
      } else {
        console.log(`❌ FAIL - No results found`);
      }
    } catch (error) {
      console.log(`❌ ERROR - ${error.message}`);
    }
  }
  
  console.log(`\n📊 Semantic Quality: ${passedTests}/${semanticTests.length} tests passed (${Math.round(passedTests/semanticTests.length*100)}%)`);
}

// Run all tests
testEnhancedRAGPipeline()
  .then(() => {
    console.log('\n🎉 Enhanced RAG Pipeline Testing Complete!');
    console.log('\nKey Improvements Tested:');
    console.log('✅ Enhanced date/age semantic representation');
    console.log('✅ Multi-resource type support (Clinical, Administrative, Business)');
    console.log('✅ FHIR-compliant chunking strategies');
    console.log('✅ Improved contact information retrieval');
    console.log('✅ Comprehensive temporal and coding support');
    console.log('✅ Advanced semantic search capabilities');
  })
  .catch(error => {
    console.error('❌ Test failed:', error.message);
  });