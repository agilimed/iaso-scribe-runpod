import { ResourceTemplateService } from '../../ai/fhir/ResourceTemplateService';
import { KafkaConsumerService } from '../utils/kafkaConsumer';
import { QdrantService } from '../utils/qdrantClient';
import { EmbeddingsClient } from '../utils/embeddingsClient';
import { FHIREvent, ResourceChunk, QueryRequest, QueryResult } from '../types';
import { logger } from '../utils/logger';
import * as cron from 'node-cron';

export class RAGProcessorService {
  private resourceTemplateService: ResourceTemplateService;
  private kafkaConsumer: KafkaConsumerService;
  private qdrantService: QdrantService;
  private embeddingsClient: EmbeddingsClient;
  private isProcessing: boolean = false;
  private processingStats = {
    processed: 0,
    failed: 0,
    startTime: new Date(),
  };

  constructor(
    kafkaBrokers: string[] = ['localhost:9092'],
    qdrantUrl: string = 'http://localhost:6333',
    embeddingsServiceUrl: string = 'localhost:50051'
  ) {
    this.resourceTemplateService = new ResourceTemplateService();
    this.kafkaConsumer = new KafkaConsumerService(kafkaBrokers, 'fhir-rag-processor');
    this.qdrantService = new QdrantService(qdrantUrl, 'fhir_resources', 1024); // BGE-M3 dimensions
    this.embeddingsClient = new EmbeddingsClient(embeddingsServiceUrl);
  }

  async initialize(): Promise<void> {
    try {
      // Initialize Qdrant collection
      await this.qdrantService.initialize();
      logger.info('[RAGProcessorService] Qdrant initialized');

      // Check embeddings service health
      logger.info('[RAGProcessorService] Checking embeddings service health...');
      const embeddingsHealthy = await this.embeddingsClient.healthCheck();
      if (!embeddingsHealthy) {
        throw new Error('Embeddings service is not healthy');
      }
      logger.info('[RAGProcessorService] Embeddings service healthy');

      // Start metrics reporting
      this.startMetricsReporting();

      logger.info('[RAGProcessorService] Initialization complete');
    } catch (error) {
      logger.error('[RAGProcessorService] Initialization failed:', error);
      throw error;
    }
  }

  async start(): Promise<void> {
    try {
      this.isProcessing = true;
      
      // Start Kafka consumer
      await this.kafkaConsumer.start('fhir.events', this.processFHIREvent.bind(this));
      
      logger.info('[RAGProcessorService] Started processing FHIR events');
    } catch (error) {
      logger.error('[RAGProcessorService] Failed to start:', error);
      throw error;
    }
  }

  async stop(): Promise<void> {
    this.isProcessing = false;
    await this.kafkaConsumer.stop();
    logger.info('[RAGProcessorService] Stopped');
  }

  private async processFHIREvent(event: FHIREvent): Promise<void> {
    const startTime = Date.now();
    
    try {
      logger.debug(`[RAGProcessorService] Processing event: ${event.resourceType}/${event.resourceId}`);

      // Handle delete events
      if (event.action === 'delete') {
        await this.qdrantService.deleteByResourceId(
          event.tenantId,
          event.resourceType,
          event.resourceId
        );
        logger.info(`[RAGProcessorService] Deleted chunks for ${event.resourceType}/${event.resourceId}`);
        return;
      }

      // Generate chunks using ResourceTemplateService
      const chunks = await this.resourceTemplateService.generateChunks(event.resource);
      
      if (chunks.length === 0) {
        logger.warn(`[RAGProcessorService] No chunks generated for ${event.resourceType}/${event.resourceId}`);
        return;
      }

      // Extract metadata for all chunks
      const metadata = await this.resourceTemplateService.extractMetadata(event.resource);
      
      // Prepare chunks for embedding
      const chunksWithMetadata: ResourceChunk[] = chunks.map(chunk => ({
        id: chunk.id,
        resourceType: event.resourceType,
        resourceId: event.resourceId,
        versionId: event.versionId,
        tenantId: event.tenantId,
        chunkType: chunk.type,
        content: chunk.content,
        metadata: {
          ...metadata,
          searchable_terms: chunk.searchable_terms,
          temporal_context: chunk.temporal_context,
          clinical_codes: chunk.clinical_codes,
          clinical_significance: chunk.clinical_significance,
        },
      }));

      // Generate embeddings in batches
      const batchSize = 10;
      for (let i = 0; i < chunksWithMetadata.length; i += batchSize) {
        const batch = chunksWithMetadata.slice(i, i + batchSize);
        const texts = batch.map(chunk => chunk.content);
        
        try {
          const embeddingResponse = await this.embeddingsClient.generateEmbeddings(texts);
          
          // Assign embeddings to chunks
          batch.forEach((chunk, index) => {
            chunk.embedding = embeddingResponse.embeddings[index];
          });

          // Store in Qdrant
          await this.qdrantService.upsertChunks(batch);
          
          logger.debug(`[RAGProcessorService] Stored ${batch.length} chunks for ${event.resourceType}/${event.resourceId}`);
        } catch (error) {
          logger.error(`[RAGProcessorService] Failed to process batch:`, error);
          this.processingStats.failed++;
        }
      }

      this.processingStats.processed++;
      
      const processingTime = Date.now() - startTime;
      logger.info(`[RAGProcessorService] Processed ${event.resourceType}/${event.resourceId} in ${processingTime}ms with ${chunksWithMetadata.length} chunks`);
      
    } catch (error) {
      this.processingStats.failed++;
      logger.error(`[RAGProcessorService] Error processing event:`, error);
      
      // Consider implementing dead letter queue here
      // await this.sendToDeadLetterQueue(event, error);
    }
  }

  async query(request: QueryRequest): Promise<QueryResult[]> {
    try {
      // Generate embedding for query
      const queryEmbedding = await this.embeddingsClient.generateEmbedding(request.query);
      
      // Search in Qdrant
      const results = await this.qdrantService.search(
        queryEmbedding,
        request.tenantId,
        request.limit || 10,
        {
          resourceTypes: request.resourceTypes,
          ...request.filters,
        }
      );

      logger.info(`[RAGProcessorService] Query returned ${results.length} results`);
      
      return results;
    } catch (error) {
      logger.error('[RAGProcessorService] Query failed:', error);
      throw error;
    }
  }

  async getStats(): Promise<any> {
    const collectionInfo = await this.qdrantService.getCollectionInfo();
    
    return {
      service: 'RAGProcessorService',
      status: this.isProcessing ? 'running' : 'stopped',
      stats: {
        ...this.processingStats,
        uptime: Date.now() - this.processingStats.startTime.getTime(),
        kafkaConsumerActive: this.kafkaConsumer.isActive(),
      },
      qdrant: {
        collection: collectionInfo.result?.name,
        vectorCount: collectionInfo.result?.vectors_count,
        pointsCount: collectionInfo.result?.points_count,
        status: collectionInfo.result?.status,
      },
    };
  }

  private startMetricsReporting(): void {
    // Report metrics every 5 minutes
    cron.schedule('*/5 * * * *', async () => {
      const stats = await this.getStats();
      logger.info('[RAGProcessorService] Metrics:', stats);
    });
  }

  // Utility method for reprocessing specific resources
  async reprocessResource(
    tenantId: string,
    resourceType: string,
    resourceId: string,
    resource: any
  ): Promise<void> {
    const event: FHIREvent = {
      id: `reprocess-${Date.now()}`,
      resourceType,
      resourceId,
      versionId: resource.meta?.versionId || '1',
      action: 'update',
      tenantId,
      timestamp: new Date().toISOString(),
      resource,
    };

    await this.processFHIREvent(event);
  }

  // Batch reprocessing for bulk updates
  async reprocessBatch(events: FHIREvent[]): Promise<void> {
    logger.info(`[RAGProcessorService] Starting batch reprocessing of ${events.length} events`);
    
    for (const event of events) {
      await this.processFHIREvent(event);
    }
    
    logger.info('[RAGProcessorService] Batch reprocessing complete');
  }
}