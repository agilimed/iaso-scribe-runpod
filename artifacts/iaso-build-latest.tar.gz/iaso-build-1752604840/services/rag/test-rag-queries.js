const axios = require('axios');

// Test queries that would be common in healthcare settings
const testQueries = [
  "Find patients from Boston",
  "Show me patients with MRN starting with MRN-00",
  "Who are the male patients?",
  "Find patients born in 1985",
  "Show me contact information for patients",
  "Which patients have driver's licenses?",
  "Find patients aged around 30-40 years",
  "Show me patients with phone numbers"
];

async function testRAGPipeline() {
  console.log('🧪 Testing RAG Pipeline with Healthcare Queries\n');
  
  try {
    // First, let's see what data we have
    const collectionInfo = await axios.get('http://localhost:6333/collections/fhir_chunks');
    console.log(`📊 Testing against ${collectionInfo.data.result.points_count} chunks from ${await getUniquePatientCount()} patients\n`);

    for (const query of testQueries) {
      console.log(`\n🔍 Query: "${query}"`);
      console.log('=' .repeat(60));
      
      try {
        // Generate embedding for the query
        const queryEmbedding = await generateQueryEmbedding(query);
        
        // Search Qdrant for similar chunks
        const searchResults = await searchQdrant(queryEmbedding, 5);
        
        // Analyze and present results
        await analyzeResults(query, searchResults);
        
      } catch (error) {
        console.log(`❌ Error processing query: ${error.message}`);
      }
    }

    console.log('\n🎯 Testing Specific Use Cases');
    console.log('=' .repeat(60));
    
    // Test specific healthcare scenarios
    await testClinicalScenarios();
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

async function generateQueryEmbedding(query) {
  const response = await axios.post('http://localhost:8050/embeddings', {
    texts: [query],
    model: 'bge-m3'
  });
  
  if (!response.data.embeddings || response.data.embeddings.length === 0) {
    throw new Error('Failed to generate query embedding');
  }
  
  return response.data.embeddings[0];
}

async function searchQdrant(vector, limit = 5) {
  const response = await axios.post('http://localhost:6333/collections/fhir_chunks/points/search', {
    vector: vector,
    limit: limit,
    with_payload: true,
    score_threshold: 0.5  // Only return reasonably similar results
  });
  
  return response.data.result;
}

async function analyzeResults(query, results) {
  if (results.length === 0) {
    console.log('❌ No relevant results found');
    return;
  }
  
  console.log(`✅ Found ${results.length} relevant chunks:`);
  
  // Group results by patient and chunk type
  const patientResults = {};
  
  results.forEach((result, index) => {
    const patientId = result.payload.resource_id;
    const chunkType = result.payload.chunk_type;
    const score = result.score;
    
    if (!patientResults[patientId]) {
      patientResults[patientId] = {
        chunks: [],
        maxScore: 0
      };
    }
    
    patientResults[patientId].chunks.push({
      type: chunkType,
      score: score,
      content: result.payload.content,
      searchableTerms: result.payload.searchable_terms
    });
    
    patientResults[patientId].maxScore = Math.max(patientResults[patientId].maxScore, score);
  });
  
  // Sort patients by relevance
  const sortedPatients = Object.entries(patientResults)
    .sort(([,a], [,b]) => b.maxScore - a.maxScore);
  
  sortedPatients.forEach(([patientId, data], index) => {
    console.log(`\n${index + 1}. Patient: ${patientId} (Score: ${data.maxScore.toFixed(4)})`);
    
    data.chunks.forEach(chunk => {
      console.log(`   📄 ${chunk.type}: ${chunk.content.substring(0, 120)}...`);
      if (chunk.searchableTerms && chunk.searchableTerms.length > 0) {
        console.log(`   🏷️  Terms: ${chunk.searchableTerms.join(', ')}`);
      }
    });
  });
  
  // Provide insights
  const uniquePatients = Object.keys(patientResults).length;
  const chunkTypes = results.map(r => r.payload.chunk_type);
  const typeDistribution = chunkTypes.reduce((acc, type) => {
    acc[type] = (acc[type] || 0) + 1;
    return acc;
  }, {});
  
  console.log(`\n📈 Results Summary:`);
  console.log(`   👥 ${uniquePatients} unique patients found`);
  console.log(`   📊 Chunk types: ${Object.entries(typeDistribution).map(([type, count]) => `${type}(${count})`).join(', ')}`);
  console.log(`   🎯 Average relevance: ${(results.reduce((sum, r) => sum + r.score, 0) / results.length).toFixed(3)}`);
}

async function testClinicalScenarios() {
  const scenarios = [
    {
      name: "Patient Lookup by MRN",
      query: "MRN-003",
      expectedFindings: "Should find patients with specific medical record numbers"
    },
    {
      name: "Geographic Patient Search", 
      query: "Massachusetts Boston patients",
      expectedFindings: "Should find patients from Boston, MA area"
    },
    {
      name: "Demographic Search",
      query: "male patients born 1985",
      expectedFindings: "Should find male patients with specific birth year"
    },
    {
      name: "Contact Information Retrieval",
      query: "phone email contact information",
      expectedFindings: "Should find patient contact details"
    }
  ];
  
  for (const scenario of scenarios) {
    console.log(`\n🏥 Scenario: ${scenario.name}`);
    console.log(`Query: "${scenario.query}"`);
    console.log(`Expected: ${scenario.expectedFindings}`);
    console.log('-'.repeat(50));
    
    try {
      const queryEmbedding = await generateQueryEmbedding(scenario.query);
      const results = await searchQdrant(queryEmbedding, 3);
      
      if (results.length > 0) {
        console.log(`✅ Found ${results.length} relevant results:`);
        results.forEach((result, index) => {
          console.log(`${index + 1}. ${result.payload.resource_type}/${result.payload.resource_id} (${result.payload.chunk_type})`);
          console.log(`   Score: ${result.score.toFixed(4)}`);
          console.log(`   Content: ${result.payload.content.substring(0, 100)}...`);
        });
      } else {
        console.log('❌ No results found for this scenario');
      }
    } catch (error) {
      console.log(`❌ Error: ${error.message}`);
    }
  }
}

async function getUniquePatientCount() {
  try {
    const scrollResult = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 1000,
      with_payload: ['resource_id', 'resource_type']
    });
    
    const uniquePatients = new Set();
    scrollResult.data.result.points.forEach(point => {
      if (point.payload.resource_type === 'patient') {
        uniquePatients.add(point.payload.resource_id);
      }
    });
    
    return uniquePatients.size;
  } catch (error) {
    return 'unknown';
  }
}

// Enhanced RAG with context assembly
async function testContextualRAG() {
  console.log('\n\n🧠 Testing Contextual RAG Assembly');
  console.log('=' .repeat(60));
  
  const complexQuery = "Find information about patients from Boston with MRN numbers and their contact details";
  console.log(`Query: "${complexQuery}"`);
  
  try {
    const queryEmbedding = await generateQueryEmbedding(complexQuery);
    const results = await searchQdrant(queryEmbedding, 10);
    
    // Assemble comprehensive patient profiles
    const patientProfiles = {};
    
    results.forEach(result => {
      const patientId = result.payload.resource_id;
      if (!patientProfiles[patientId]) {
        patientProfiles[patientId] = {
          summary: null,
          demographics: null,
          identifiers: null,
          contact: null,
          maxScore: 0
        };
      }
      
      const chunkType = result.payload.chunk_type;
      patientProfiles[patientId][chunkType] = {
        content: result.payload.content,
        score: result.score,
        searchableTerms: result.payload.searchable_terms
      };
      
      patientProfiles[patientId].maxScore = Math.max(
        patientProfiles[patientId].maxScore, 
        result.score
      );
    });
    
    // Present comprehensive profiles
    const sortedProfiles = Object.entries(patientProfiles)
      .sort(([,a], [,b]) => b.maxScore - a.maxScore)
      .slice(0, 3);  // Top 3 most relevant
    
    console.log(`\n📋 Assembled Patient Profiles (Top ${sortedProfiles.length}):`);
    
    sortedProfiles.forEach(([patientId, profile], index) => {
      console.log(`\n${index + 1}. 👤 Patient ${patientId} (Relevance: ${profile.maxScore.toFixed(4)})`);
      console.log('─'.repeat(40));
      
      if (profile.summary) {
        console.log(`📝 Summary: ${profile.summary.content}`);
      }
      
      if (profile.demographics) {
        console.log(`👥 Demographics: ${profile.demographics.content}`);
      }
      
      if (profile.identifiers) {
        console.log(`🆔 Identifiers: ${profile.identifiers.content}`);
      }
      
      if (profile.contact) {
        console.log(`📞 Contact: ${profile.contact.content}`);
      }
      
      // Highlight why this patient was matched
      const allTerms = new Set();
      Object.values(profile).forEach(chunk => {
        if (chunk && chunk.searchableTerms) {
          chunk.searchableTerms.forEach(term => allTerms.add(term));
        }
      });
      
      if (allTerms.size > 0) {
        console.log(`🏷️  Key Terms: ${Array.from(allTerms).slice(0, 8).join(', ')}`);
      }
    });
    
  } catch (error) {
    console.log(`❌ Error: ${error.message}`);
  }
}

// Run all tests
testRAGPipeline()
  .then(() => testContextualRAG())
  .then(() => {
    console.log('\n🎉 RAG Pipeline Testing Complete!');
    console.log('\nThe pipeline successfully demonstrates:');
    console.log('✅ Semantic search across patient data');
    console.log('✅ Contextual chunk retrieval');
    console.log('✅ Multi-faceted patient profiles');
    console.log('✅ Relevance scoring and ranking');
    console.log('✅ Clinical use case support');
  })
  .catch(error => {
    console.error('❌ Test failed:', error.message);
  });