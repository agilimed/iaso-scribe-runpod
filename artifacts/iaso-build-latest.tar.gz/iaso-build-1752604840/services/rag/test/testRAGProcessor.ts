import { RAGProcessorService } from '../processors/RAGProcessorService';
import { FHIREvent } from '../types';
import { logger } from '../utils/logger';

async function testRAGProcessor() {
  const processor = new RAGProcessorService(
    ['localhost:9092'],
    'http://localhost:6333',
    'localhost:50051'
  );

  try {
    // Initialize the processor
    await processor.initialize();
    logger.info('RAG processor initialized successfully');

    // Test with a sample patient resource
    const samplePatient = {
      resourceType: 'Patient',
      id: 'test-patient-001',
      meta: {
        versionId: '1',
        lastUpdated: '2024-01-10T10:00:00Z',
      },
      identifier: [{
        system: 'http://hospital.example.org/patients',
        value: 'P12345',
      }],
      name: [{
        use: 'official',
        family: 'Smith',
        given: ['John', 'Michael'],
      }],
      gender: 'male',
      birthDate: '1980-05-15',
      address: [{
        use: 'home',
        line: ['123 Main St'],
        city: 'Boston',
        state: 'MA',
        postalCode: '02134',
      }],
    };

    const event: FHIREvent = {
      id: 'test-event-001',
      resourceType: 'Patient',
      resourceId: 'test-patient-001',
      versionId: '1',
      action: 'create',
      tenantId: 'test-tenant',
      timestamp: new Date().toISOString(),
      resource: samplePatient,
    };

    // Reprocess the resource
    await processor.reprocessResource(
      event.tenantId,
      event.resourceType,
      event.resourceId,
      event.resource
    );
    logger.info('Successfully processed patient resource');

    // Test query
    const queryResults = await processor.query({
      query: 'patient named John Smith',
      tenantId: 'test-tenant',
      resourceTypes: ['Patient'],
      limit: 5,
    });

    logger.info(`Query returned ${queryResults.length} results`);
    queryResults.forEach((result, index) => {
      logger.info(`Result ${index + 1}: ${result.resourceType}/${result.resourceId} (score: ${result.score})`);
    });

    // Get stats
    const stats = await processor.getStats();
    logger.info('Processor stats:', stats);

  } catch (error) {
    logger.error('Test failed:', error);
  }
}

// Run the test
testRAGProcessor().catch(console.error);