const axios = require('axios');

async function debugDemographicsSearch() {
  console.log('🔍 Debug: Demographics Search Issue\n');
  
  try {
    // 1. Generate embedding for "show me patient demographics"
    console.log('1. Generating embedding...');
    const embeddingResponse = await axios.post('http://localhost:8050/embeddings', {
      texts: ['show me patient demographics'],
      model: 'bge-m3'
    });
    const queryEmbedding = embeddingResponse.data.embeddings[0];
    console.log(`✅ Generated embedding with ${queryEmbedding.length} dimensions\n`);
    
    // 2. Search Qdrant
    console.log('2. Searching Qdrant...');
    const searchResponse = await axios.post('http://localhost:6333/collections/fhir_chunks/points/search', {
      vector: queryEmbedding,
      limit: 10,
      with_payload: true,
      score_threshold: 0.3
    });
    
    const results = searchResponse.data.result;
    console.log(`Found ${results.length} results\n`);
    
    // 3. Analyze results
    console.log('3. Top Results Analysis:');
    results.forEach((result, index) => {
      console.log(`\n${index + 1}. Score: ${result.score.toFixed(3)}`);
      console.log(`   Chunk Type: ${result.payload.chunk_type}`);
      console.log(`   Resource: ${result.payload.resource_type}/${result.payload.resource_id}`);
      console.log(`   Content: "${result.payload.content.substring(0, 100)}..."`);
      console.log(`   Searchable Terms: [${(result.payload.searchable_terms || []).slice(0, 5).join(', ')}]`);
    });
    
    // 4. Check if demographics chunks exist
    console.log('\n4. Demographics Chunks Check:');
    const allChunksResponse = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 100,
      with_payload: true,
      filter: {
        must: [
          {
            key: 'chunk_type',
            match: { value: 'demographics' }
          }
        ]
      }
    });
    
    const demographicsChunks = allChunksResponse.data.result.points;
    console.log(`Found ${demographicsChunks.length} demographics chunks in database`);
    
    if (demographicsChunks.length > 0) {
      console.log('\n5. Sample Demographics Chunk:');
      const sample = demographicsChunks[0];
      console.log(`   Content: "${sample.payload.content.substring(0, 200)}..."`);
      console.log(`   Searchable Terms: [${(sample.payload.searchable_terms || []).join(', ')}]`);
      
      // Test similarity manually
      console.log('\n6. Manual Similarity Test:');
      const sampleSearchResponse = await axios.post('http://localhost:6333/collections/fhir_chunks/points/search', {
        vector: queryEmbedding,
        limit: 5,
        with_payload: true,
        filter: {
          must: [
            {
              key: 'chunk_type',
              match: { value: 'demographics' }
            }
          ]
        }
      });
      
      const filteredResults = sampleSearchResponse.data.result;
      console.log(`Filtered search found ${filteredResults.length} demographics chunks`);
      if (filteredResults.length > 0) {
        console.log(`Best demographics score: ${filteredResults[0].score.toFixed(3)}`);
      }
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

debugDemographicsSearch()
  .then(() => console.log('\n🎉 Debug Complete!'))
  .catch(error => console.error('❌ Debug failed:', error.message));