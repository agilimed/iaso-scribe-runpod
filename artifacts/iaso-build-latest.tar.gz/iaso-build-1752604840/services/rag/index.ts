import { RAGProcessorService } from './processors/RAGProcessorService';
import { RAGGrpcServer } from './grpc/server';
import { logger } from './utils/logger';
import * as dotenv from 'dotenv';

// Load environment variables
dotenv.config();

export class RAGServiceManager {
  private ragProcessor: RAGProcessorService;
  private grpcServer: RAGGrpcServer;

  constructor() {
    const kafkaBrokers = (process.env.KAFKA_BROKERS || 'localhost:9092').split(',');
    const qdrantUrl = process.env.QDRANT_URL || 'http://localhost:6333';
    const embeddingsServiceUrl = process.env.EMBEDDINGS_SERVICE_URL || 'localhost:50051';

    this.ragProcessor = new RAGProcessorService(
      kafkaBrokers,
      qdrantUrl,
      embeddingsServiceUrl
    );

    this.grpcServer = new RAGGrpcServer(this.ragProcessor);
  }

  async start(): Promise<void> {
    try {
      // Initialize RAG processor
      await this.ragProcessor.initialize();
      
      // Start processing FHIR events
      await this.ragProcessor.start();
      
      // Start gRPC server
      const grpcPort = parseInt(process.env.GRPC_PORT || '50052');
      await this.grpcServer.start(grpcPort);
      
      logger.info('[RAGServiceManager] All services started successfully');
      
      // Setup graceful shutdown
      this.setupGracefulShutdown();
    } catch (error) {
      logger.error('[RAGServiceManager] Failed to start services:', error);
      throw error;
    }
  }

  private setupGracefulShutdown(): void {
    const shutdown = async (signal: string) => {
      logger.info(`[RAGServiceManager] Received ${signal}, shutting down gracefully...`);
      
      try {
        await this.grpcServer.stop();
        await this.ragProcessor.stop();
        
        logger.info('[RAGServiceManager] Shutdown complete');
        process.exit(0);
      } catch (error) {
        logger.error('[RAGServiceManager] Error during shutdown:', error);
        process.exit(1);
      }
    };

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));
  }
}

// Export for use as a module
export { RAGProcessorService } from './processors/RAGProcessorService';
export { RAGGrpcServer } from './grpc/server';
export * from './types';

// Start service if run directly
if (require.main === module) {
  const manager = new RAGServiceManager();
  
  manager.start().catch((error) => {
    logger.error('[RAGServiceManager] Fatal error:', error);
    process.exit(1);
  });
}