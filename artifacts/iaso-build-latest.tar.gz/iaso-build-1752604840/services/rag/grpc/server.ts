import * as grpc from '@grpc/grpc-js';
import * as protoLoader from '@grpc/proto-loader';
import path from 'path';
import { RAGProcessorService } from '../processors/RAGProcessorService';
import { QueryRequest, QueryResult } from '../types';
import { logger } from '../utils/logger';

const PROTO_PATH = path.join(__dirname, '../../../protos/rag.proto');

export class RAGGrpcServer {
  private server: grpc.Server;
  private ragProcessor: RAGProcessorService;

  constructor(ragProcessor: RAGProcessorService) {
    this.server = new grpc.Server();
    this.ragProcessor = ragProcessor;
    this.setupHandlers();
  }

  private setupHandlers(): void {
    const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
      keepCase: true,
      longs: String,
      enums: String,
      defaults: true,
      oneofs: true,
    });

    const proto = grpc.loadPackageDefinition(packageDefinition) as any;

    this.server.addService(proto.rag.RAGService.service, {
      Query: this.handleQuery.bind(this),
      GetStats: this.handleGetStats.bind(this),
      ReprocessResource: this.handleReprocessResource.bind(this),
      HealthCheck: this.handleHealthCheck.bind(this),
    });
  }

  private async handleQuery(
    call: grpc.ServerUnaryCall<any, any>,
    callback: grpc.sendUnaryData<any>
  ): Promise<void> {
    try {
      const request: QueryRequest = {
        query: call.request.query,
        tenantId: call.request.tenant_id,
        resourceTypes: call.request.resource_types,
        limit: call.request.limit || 10,
        filters: call.request.filters,
      };

      const results = await this.ragProcessor.query(request);

      const response = {
        results: results.map(result => ({
          id: result.id,
          resource_type: result.resourceType,
          resource_id: result.resourceId,
          score: result.score,
          content: result.content,
          metadata: result.metadata,
        })),
        total: results.length,
      };

      callback(null, response);
    } catch (error) {
      logger.error('[RAGGrpcServer] Query error:', error);
      callback({
        code: grpc.status.INTERNAL,
        details: error instanceof Error ? error.message : 'Unknown error',
      });
    }
  }

  private async handleGetStats(
    call: grpc.ServerUnaryCall<any, any>,
    callback: grpc.sendUnaryData<any>
  ): Promise<void> {
    try {
      const stats = await this.ragProcessor.getStats();
      callback(null, stats);
    } catch (error) {
      logger.error('[RAGGrpcServer] GetStats error:', error);
      callback({
        code: grpc.status.INTERNAL,
        details: error instanceof Error ? error.message : 'Unknown error',
      });
    }
  }

  private async handleReprocessResource(
    call: grpc.ServerUnaryCall<any, any>,
    callback: grpc.sendUnaryData<any>
  ): Promise<void> {
    try {
      await this.ragProcessor.reprocessResource(
        call.request.tenant_id,
        call.request.resource_type,
        call.request.resource_id,
        call.request.resource
      );

      callback(null, { success: true });
    } catch (error) {
      logger.error('[RAGGrpcServer] ReprocessResource error:', error);
      callback({
        code: grpc.status.INTERNAL,
        details: error instanceof Error ? error.message : 'Unknown error',
      });
    }
  }

  private handleHealthCheck(
    call: grpc.ServerUnaryCall<any, any>,
    callback: grpc.sendUnaryData<any>
  ): void {
    callback(null, {
      healthy: true,
      service: 'fhir-rag-processor',
      timestamp: new Date().toISOString(),
    });
  }

  async start(port: number = 50052): Promise<void> {
    return new Promise((resolve, reject) => {
      this.server.bindAsync(
        `0.0.0.0:${port}`,
        grpc.ServerCredentials.createInsecure(),
        (error, port) => {
          if (error) {
            reject(error);
            return;
          }

          this.server.start();
          logger.info(`[RAGGrpcServer] Server started on port ${port}`);
          resolve();
        }
      );
    });
  }

  async stop(): Promise<void> {
    return new Promise((resolve) => {
      this.server.tryShutdown(() => {
        logger.info('[RAGGrpcServer] Server stopped');
        resolve();
      });
    });
  }
}