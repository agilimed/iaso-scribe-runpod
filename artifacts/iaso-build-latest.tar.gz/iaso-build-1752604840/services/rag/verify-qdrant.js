const axios = require('axios');

async function verifyQdrantData() {
  try {
    console.log('🔍 Checking Qdrant collection...\n');

    // Get collection info
    const collectionInfo = await axios.get('http://localhost:6333/collections/fhir_chunks');
    console.log('📊 Collection Info:');
    console.log(`- Vectors Count: ${collectionInfo.data.result.vectors_count}`);
    console.log(`- Points Count: ${collectionInfo.data.result.points_count}`);
    console.log(`- Vector Size: ${collectionInfo.data.result.config.params.vectors.size}`);
    console.log(`- Distance: ${collectionInfo.data.result.config.params.vectors.distance}\n`);

    // Search for some sample data
    console.log('🔎 Performing sample search for "John"...\n');
    
    // First, get a sample vector by retrieving a point
    const samplePoint = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 1,
      with_payload: false,
      with_vector: true
    });

    if (samplePoint.data.result.points.length > 0) {
      const sampleVector = samplePoint.data.result.points[0].vector;
      
      // Use the sample vector for search (you'd normally use embeddings service)
      const searchResults = await axios.post('http://localhost:6333/collections/fhir_chunks/points/search', {
        vector: sampleVector,
        limit: 5,
        with_payload: true
      });

      console.log('📄 Sample search results:');
      searchResults.data.result.forEach((result, index) => {
        console.log(`\n${index + 1}. Score: ${result.score.toFixed(4)}`);
        console.log(`   Resource: ${result.payload.resource_type}/${result.payload.resource_id}`);
        console.log(`   Chunk Type: ${result.payload.chunk_type}`);
        console.log(`   Content: ${result.payload.content.substring(0, 150)}...`);
        if (result.payload.searchable_terms) {
          console.log(`   Searchable Terms: ${result.payload.searchable_terms.join(', ')}`);
        }
      });
    }

    // Get some statistics
    console.log('\n📈 Chunk Type Distribution:');
    const scrollResults = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 1000,
      with_payload: ['chunk_type']
    });

    const chunkTypes = {};
    scrollResults.data.result.points.forEach(point => {
      const type = point.payload.chunk_type;
      chunkTypes[type] = (chunkTypes[type] || 0) + 1;
    });

    Object.entries(chunkTypes).forEach(([type, count]) => {
      console.log(`   ${type}: ${count} chunks`);
    });

    // Count unique patients
    const uniquePatients = new Set();
    const allPoints = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 1000,
      with_payload: ['resource_id', 'resource_type']
    });

    allPoints.data.result.points.forEach(point => {
      if (point.payload.resource_type === 'patient') {
        uniquePatients.add(point.payload.resource_id);
      }
    });

    console.log(`\n👥 Total unique patients: ${uniquePatients.size}`);

  } catch (error) {
    console.error('❌ Error:', error.response?.data || error.message);
  }
}

verifyQdrantData();