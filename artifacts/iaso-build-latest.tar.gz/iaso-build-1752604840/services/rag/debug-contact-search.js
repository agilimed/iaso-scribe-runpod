const axios = require('axios');

async function debugContactSearch() {
  console.log('🔍 Debug: Contact Information Search\n');
  
  try {
    // Generate embedding for query
    const embeddingResponse = await axios.post('http://localhost:8050/embeddings', {
      texts: ['patient contact information'],
      model: 'bge-m3'
    });
    const queryEmbedding = embeddingResponse.data.embeddings[0];
    
    // Search without filters
    const searchResponse = await axios.post('http://localhost:6333/collections/fhir_chunks/points/search', {
      vector: queryEmbedding,
      limit: 10,
      with_payload: true
    });
    
    console.log('📋 TOP 10 RESULTS FOR "patient contact information":');
    searchResponse.data.result.forEach((result, index) => {
      console.log(`\n${index + 1}. Score: ${result.score.toFixed(3)}`);
      console.log(`   Type: ${result.payload.chunk_type}`);
      console.log(`   Resource: ${result.payload.resource_type}`);
      console.log(`   Content: "${result.payload.content.substring(0, 100)}..."`);
      console.log(`   Terms: [${(result.payload.searchable_terms || []).slice(0, 5).join(', ')}]`);
    });
    
    // Now search specifically for contact chunks
    const contactSearchResponse = await axios.post('http://localhost:6333/collections/fhir_chunks/points/search', {
      vector: queryEmbedding,
      limit: 5,
      with_payload: true,
      filter: {
        must: [
          { key: 'chunk_type', match: { value: 'contact' } }
        ]
      }
    });
    
    console.log('\n\n📋 TOP CONTACT CHUNKS:');
    contactSearchResponse.data.result.forEach((result, index) => {
      console.log(`\n${index + 1}. Score: ${result.score.toFixed(3)}`);
      console.log(`   Content: "${result.payload.content.substring(0, 150)}..."`);
      console.log(`   Terms: [${(result.payload.searchable_terms || []).join(', ')}]`);
    });
    
    // Get a sample contact chunk to analyze
    const sampleContactResponse = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 1,
      with_payload: true,
      filter: {
        must: [
          { key: 'chunk_type', match: { value: 'contact' } }
        ]
      }
    });
    
    if (sampleContactResponse.data.result.points.length > 0) {
      const sample = sampleContactResponse.data.result.points[0];
      console.log('\n\n📝 SAMPLE CONTACT CHUNK ANALYSIS:');
      console.log(`Full Content: "${sample.payload.content}"`);
      console.log(`\nSearchable Terms: [${(sample.payload.searchable_terms || []).join(', ')}]`);
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

debugContactSearch()
  .then(() => console.log('\n✅ Debug Complete!'))
  .catch(error => console.error('❌ Failed:', error.message));