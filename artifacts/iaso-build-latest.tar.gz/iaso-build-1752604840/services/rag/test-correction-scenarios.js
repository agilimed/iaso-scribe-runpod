const axios = require('axios');

async function testCorrectionScenarios() {
  console.log('🔧 Testing Patient Data Correction Scenarios\n');
  console.log('=' .repeat(80));
  
  // Scenario 1: Patient Name Correction
  console.log('📝 SCENARIO 1: Patient Name Correction');
  console.log('-' .repeat(50));
  
  const originalPatient = {
    resourceType: 'Patient',
    id: 'patient-001',
    name: [{
      given: ['Jhon'], // Misspelled name
      family: 'Smith',
      use: 'official'
    }],
    gender: 'male',
    birthDate: '1985-06-15'
  };
  
  const correctedPatient = {
    resourceType: 'Patient',
    id: 'patient-001', // Same ID
    name: [{
      given: ['John'], // Corrected spelling
      family: 'Smith',
      use: 'official'
    }],
    gender: 'male',
    birthDate: '1985-06-15'
  };
  
  console.log('Initial Patient (CREATE):');
  console.log(`   Name: ${originalPatient.name[0].given[0]} ${originalPatient.name[0].family}`);
  console.log(`   Chunks created: Patient:patient-001:demographics`);
  console.log(`   Content includes: "Patient: Jhon Smith"`);
  console.log(`   Searchable terms: ["Jhon", "Smith", "patient", ...]`);
  
  console.log('\nName Correction (UPDATE):');
  console.log(`   Corrected Name: ${correctedPatient.name[0].given[0]} ${correctedPatient.name[0].family}`);
  console.log(`   Process:`);
  console.log(`   1. DELETE chunks: Patient:patient-001:* (removes "Jhon Smith" content)`);
  console.log(`   2. CREATE new chunks with same IDs: Patient:patient-001:demographics`);
  console.log(`   3. New content: "Patient: John Smith"`);
  console.log(`   4. New searchable terms: ["John", "Smith", "patient", ...]`);
  
  console.log('\n✅ Result: Old misspelling completely removed, corrected name searchable');
  
  // Scenario 2: Contact Detail Correction
  console.log('\n\n📝 SCENARIO 2: Contact Detail Correction');
  console.log('-' .repeat(50));
  
  const patientWithOldPhone = {
    resourceType: 'Patient',
    id: 'patient-002',
    name: [{ given: ['Jane'], family: 'Doe', use: 'official' }],
    telecom: [{
      system: 'phone',
      value: '555-1111', // Old phone number
      use: 'mobile'
    }]
  };
  
  const patientWithNewPhone = {
    resourceType: 'Patient',
    id: 'patient-002',
    name: [{ given: ['Jane'], family: 'Doe', use: 'official' }],
    telecom: [{
      system: 'phone',
      value: '555-9999', // New phone number
      use: 'mobile'
    }]
  };
  
  console.log('Original Contact (CREATE):');
  console.log(`   Phone: ${patientWithOldPhone.telecom[0].value}`);
  console.log(`   Chunks: Patient:patient-002:contact`);
  console.log(`   Content: "Phone (mobile): 555-1111"`);
  console.log(`   Searchable terms: ["555-1111", "phone", "contact", ...]`);
  
  console.log('\nContact Correction (UPDATE):');
  console.log(`   New Phone: ${patientWithNewPhone.telecom[0].value}`);
  console.log(`   Process:`);
  console.log(`   1. DELETE chunks: Patient:patient-002:* (removes old phone)`);
  console.log(`   2. CREATE new chunks: Patient:patient-002:contact`);
  console.log(`   3. New content: "Phone (mobile): 555-9999"`);
  console.log(`   4. New searchable terms: ["555-9999", "phone", "contact", ...]`);
  
  console.log('\n✅ Result: Old phone number completely removed, new number searchable');
  
  // Scenario 3: Allergy Removal (Most Complex)
  console.log('\n\n📝 SCENARIO 3: Allergy Removal (Peanut Allergy)');
  console.log('-' .repeat(50));
  
  const patientWithAllergies = {
    resourceType: 'Patient',
    id: 'patient-003',
    name: [{ given: ['Bob'], family: 'Johnson', use: 'official' }]
  };
  
  const peanutAllergy = {
    resourceType: 'AllergyIntolerance',
    id: 'allergy-001',
    clinicalStatus: {
      coding: [{
        system: 'http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical',
        code: 'active',
        display: 'Active'
      }]
    },
    code: {
      coding: [{
        system: 'http://snomed.info/sct',
        code: '256349002',
        display: 'Peanut allergy'
      }]
    },
    subject: {
      reference: 'Patient/patient-003'
    },
    criticality: 'high'
  };
  
  console.log('Original Allergy (CREATE):');
  console.log(`   Allergy: ${peanutAllergy.code.coding[0].display}`);
  console.log(`   Status: ${peanutAllergy.clinicalStatus.coding[0].display}`);
  console.log(`   Chunks created:`);
  console.log(`   - AllergyIntolerance:allergy-001:summary`);
  console.log(`   - AllergyIntolerance:allergy-001:clinical`);
  console.log(`   - AllergyIntolerance:allergy-001:relationship`);
  console.log(`   Content includes: "Allergen: Peanut allergy", "Clinical Status: active"`);
  console.log(`   Searchable terms: ["peanut", "allergy", "active", "allergen", ...]`);
  
  console.log('\nAllergy Removal Options:');
  
  // Option A: DELETE the AllergyIntolerance resource
  console.log('\n🔥 OPTION A: DELETE AllergyIntolerance Resource');
  console.log(`   FHIR Backend: Sends DELETE event for allergy-001`);
  console.log(`   Our Process:`);
  console.log(`   1. Receive: { event_type: "delete", resource_id: "allergy-001" }`);
  console.log(`   2. SOFT DELETE all chunks: AllergyIntolerance:allergy-001:*`);
  console.log(`   3. Mark chunks: is_deleted: true, deleted_at: timestamp`);
  console.log(`   4. Chunks remain in Qdrant but filtered out of search results`);
  console.log(`   ✅ Peanut allergy no longer appears in patient searches`);
  console.log(`   ✅ Audit trail preserved for compliance`);
  
  // Option B: UPDATE to inactive status
  const inactiveAllergy = {
    ...peanutAllergy,
    clinicalStatus: {
      coding: [{
        system: 'http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical',
        code: 'inactive',
        display: 'Inactive'
      }]
    }
  };
  
  console.log('\n📝 OPTION B: UPDATE to Inactive Status');
  console.log(`   FHIR Backend: Sends UPDATE event with inactive status`);
  console.log(`   New Status: ${inactiveAllergy.clinicalStatus.coding[0].display}`);
  console.log(`   Our Process:`);
  console.log(`   1. DELETE old chunks: AllergyIntolerance:allergy-001:*`);
  console.log(`   2. CREATE new chunks with same IDs`);
  console.log(`   3. New content: "Allergen: Peanut allergy", "Clinical Status: inactive"`);
  console.log(`   4. New searchable terms: ["peanut", "allergy", "inactive", ...]`);
  console.log(`   ✅ Allergy still searchable but marked as inactive`);
  console.log(`   ✅ Complete replacement - no trace of "active" status`);
  
  // Option C: UPDATE to resolved
  const resolvedAllergy = {
    ...peanutAllergy,
    clinicalStatus: {
      coding: [{
        system: 'http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical',
        code: 'resolved',
        display: 'Resolved'
      }]
    }
  };
  
  console.log('\n✅ OPTION C: UPDATE to Resolved Status');
  console.log(`   New Status: ${resolvedAllergy.clinicalStatus.coding[0].display}`);
  console.log(`   Same process as Option B but with "resolved" status`);
  console.log(`   ✅ Maintains historical record but indicates resolution`);
  
  // Test how search would work after removal
  console.log('\n\n📝 SCENARIO 4: Search Behavior After Corrections');
  console.log('-' .repeat(50));
  
  const searchScenarios = [
    {
      query: 'Find patients named Jhon',
      before: 'Returns patient-001 (misspelled name)',
      after: 'No results (name corrected to John)'
    },
    {
      query: 'Find patients named John',
      before: 'No results (was misspelled)',
      after: 'Returns patient-001 (corrected name)'
    },
    {
      query: 'Find phone number 555-1111',
      before: 'Returns patient-002 contact info',
      after: 'No results (phone updated)'
    },
    {
      query: 'Find peanut allergies',
      before: 'Returns active peanut allergy for patient-003',
      after: {
        delete: 'No results (allergy deleted/soft-deleted)',
        inactive: 'Returns inactive peanut allergy',
        resolved: 'Returns resolved peanut allergy'
      }
    },
    {
      query: 'Find active allergies for patient-003',
      before: 'Returns peanut allergy',
      after: {
        delete: 'No results',
        inactive: 'No results (not active)',
        resolved: 'No results (not active)'
      }
    }
  ];
  
  searchScenarios.forEach((scenario, index) => {
    console.log(`\n${index + 1}. Query: "${scenario.query}"`);
    console.log(`   Before correction: ${scenario.before}`);
    if (typeof scenario.after === 'string') {
      console.log(`   After correction: ${scenario.after}`);
    } else {
      console.log(`   After DELETE: ${scenario.after.delete}`);
      console.log(`   After INACTIVE: ${scenario.after.inactive}`);
      console.log(`   After RESOLVED: ${scenario.after.resolved}`);
    }
  });
  
  // Key Benefits Summary
  console.log('\n\n📝 SUMMARY: Correction Handling Benefits');
  console.log('-' .repeat(50));
  
  console.log('✅ COMPLETE DATA REPLACEMENT:');
  console.log('   • Old incorrect data is completely removed');
  console.log('   • New correct data becomes immediately searchable');
  console.log('   • No partial updates or data fragments');
  console.log('   • Deterministic chunk IDs ensure reliable replacement');
  
  console.log('\n✅ SEARCH ACCURACY:');
  console.log('   • Searches for old data return no results');
  console.log('   • Searches for new data return current information');
  console.log('   • No confusion between old and new values');
  
  console.log('\n✅ AUDIT TRAIL (for deletions):');
  console.log('   • Soft delete preserves historical data');
  console.log('   • Timestamps track when changes occurred');
  console.log('   • Compliance with medical record requirements');
  
  console.log('\n⚠️ CONSIDERATIONS:');
  console.log('   • Full resource replacement (not partial updates)');
  console.log('   • Requires complete/accurate resource data in UPDATE events');
  console.log('   • Cross-resource references need manual handling');
  
  try {
    // Test if we can see this in action with a real example
    console.log('\n\n🧪 LIVE TEST: Correction Simulation');
    console.log('-' .repeat(50));
    
    // Check current chunks in Qdrant
    const currentChunks = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 5,
      with_payload: true,
      filter: {
        must: [
          { key: 'resourceType', match: { value: 'Patient' } }
        ]
      }
    });
    
    const patientChunks = currentChunks.data.result.points || [];
    console.log(`📊 Found ${patientChunks.length} existing patient chunks`);
    
    if (patientChunks.length > 0) {
      const sampleChunk = patientChunks[0];
      console.log(`\nSample chunk ID: ${sampleChunk.id}`);
      console.log(`Sample content: "${sampleChunk.payload.content.substring(0, 100)}..."`);
      console.log(`Updated at: ${sampleChunk.payload.updated_at || 'Not set'}`);
      console.log(`Version: ${sampleChunk.payload.resource_version || 'Not set'}`);
      
      console.log('\n✅ When this patient is updated:');
      console.log(`   1. This chunk will be completely replaced`);
      console.log(`   2. New content will reflect corrections`);
      console.log(`   3. Old content will be completely removed`);
      console.log(`   4. Chunk ID remains the same: ${sampleChunk.id}`);
    }
    
  } catch (error) {
    console.log(`⚠️ Could not test with live Qdrant: ${error.message}`);
    console.log('   (This is expected if Qdrant is not running)');
  }
}

testCorrectionScenarios()
  .then(() => console.log('\n🎉 Correction Scenarios Analysis Complete!'))
  .catch(error => console.error('❌ Analysis failed:', error.message));