const axios = require('axios');

// Comprehensive test suite for expanded RAG dataset
const testSuite = {
  // Performance Tests
  performance: [
    { query: "Find patients from Boston", expectedResults: 3, metric: "geographic_search" },
    { query: "medication requests for antibiotics", expectedResults: 2, metric: "medication_search" },
    { query: "blood pressure measurements", expectedResults: 3, metric: "observation_search" },
    { query: "patient encounters in emergency", expectedResults: 2, metric: "encounter_search" },
    { query: "billing invoices over $100", expectedResults: 2, metric: "financial_search" }
  ],
  
  // Efficacy Tests (Different Resource Types)
  efficacy: [
    { query: "show me patient demographics", expectedType: "demographics", metric: "chunk_type_targeting" },
    { query: "find medical codes and diagnoses", expectedType: "codes", metric: "medical_coding" },
    { query: "patient contact information", expectedType: "contact", metric: "contact_retrieval" },
    { query: "medication dosage and instructions", expectedType: "clinical", metric: "clinical_details" },
    { query: "appointment scheduling information", expectedType: "temporal", metric: "temporal_search" },
    { query: "healthcare provider information", expectedType: "administrative", metric: "admin_search" },
    { query: "insurance and billing details", expectedType: "financial", metric: "financial_details" }
  ],
  
  // Quality Tests (Semantic Understanding)
  quality: [
    { query: "high blood pressure patients", expectedTerms: ["blood pressure", "hypertension"], metric: "clinical_semantics" },
    { query: "patients born in 1985", expectedTerms: ["1985", "birth"], metric: "temporal_semantics" },
    { query: "young adult patients", expectedTerms: ["young adult", "age"], metric: "age_group_semantics" },
    { query: "prescription medications", expectedTerms: ["medication", "prescription"], metric: "medication_semantics" },
    { query: "emergency room visits", expectedTerms: ["emergency", "encounter"], metric: "encounter_semantics" },
    { query: "chronic conditions", expectedTerms: ["condition", "chronic"], metric: "condition_semantics" }
  ],
  
  // Multi-Resource Complex Tests
  complexity: [
    { query: "patients with diabetes and medications", expectedResources: ["patient", "condition", "medication_request"], metric: "multi_resource_search" },
    { query: "recent hospital encounters with billing", expectedResources: ["encounter", "invoice"], metric: "clinical_financial_link" },
    { query: "patients with allergies and immunizations", expectedResources: ["patient", "condition", "immunization"], metric: "allergy_immunization_link" },
    { query: "laboratory results and follow-up appointments", expectedResources: ["observation", "appointment"], metric: "lab_followup_link" }
  ]
};

async function runComprehensiveEvaluation() {
  console.log('🧪 Comprehensive RAG Dataset Evaluation\n');
  console.log('=' .repeat(80));
  
  try {
    // Get dataset overview
    const overview = await getDatasetOverview();
    console.log('📊 Dataset Overview:');
    console.log(`   Total Chunks: ${overview.totalChunks}`);
    console.log(`   Unique Resources: ${overview.uniqueResources}`);
    console.log(`   Resource Types: ${overview.resourceTypes}`);
    console.log(`   Chunk Types: ${overview.chunkTypes}\n`);
    
    const results = {
      performance: [],
      efficacy: [],
      quality: [],
      complexity: [],
      summary: {}
    };
    
    // Run Performance Tests
    console.log('🚀 PERFORMANCE EVALUATION');
    console.log('=' .repeat(50));
    results.performance = await runPerformanceTests(testSuite.performance);
    
    // Run Efficacy Tests  
    console.log('\n🎯 EFFICACY EVALUATION');
    console.log('=' .repeat(50));
    results.efficacy = await runEfficacyTests(testSuite.efficacy);
    
    // Run Quality Tests
    console.log('\n🔬 QUALITY EVALUATION');
    console.log('=' .repeat(50));
    results.quality = await runQualityTests(testSuite.quality);
    
    // Run Complexity Tests
    console.log('\n🧩 COMPLEXITY EVALUATION');
    console.log('=' .repeat(50));
    results.complexity = await runComplexityTests(testSuite.complexity);
    
    // Generate Summary Report
    console.log('\n📈 COMPREHENSIVE SUMMARY REPORT');
    console.log('=' .repeat(60));
    results.summary = generateSummaryReport(results);
    
    // Benchmark against research
    console.log('\n📊 RESEARCH BENCHMARK COMPARISON');
    console.log('=' .repeat(50));
    benchmarkAgainstResearch(results);
    
  } catch (error) {
    console.error('❌ Evaluation failed:', error.message);
  }
}

async function getDatasetOverview() {
  const collectionInfo = await axios.get('http://localhost:6333/collections/fhir_chunks');
  const allData = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
    limit: 1200,
    with_payload: ['resource_type', 'chunk_type', 'resource_id']
  });
  
  const points = allData.data.result.points;
  const resourceTypes = [...new Set(points.map(p => p.payload.resource_type))].length;
  const chunkTypes = [...new Set(points.map(p => p.payload.chunk_type))].length;
  const uniqueResources = [...new Set(points.map(p => `${p.payload.resource_type}/${p.payload.resource_id}`))].length;
  
  return {
    totalChunks: collectionInfo.data.result.points_count,
    uniqueResources,
    resourceTypes,
    chunkTypes
  };
}

async function runPerformanceTests(tests) {
  const results = [];
  
  for (const test of tests) {
    const startTime = Date.now();
    
    try {
      const queryEmbedding = await generateQueryEmbedding(test.query);
      const searchResults = await searchQdrant(queryEmbedding, 10);
      const responseTime = Date.now() - startTime;
      
      const score = calculatePerformanceScore(searchResults, test.expectedResults, responseTime);
      
      console.log(`   ${test.metric}: Query "${test.query}"`);
      console.log(`     Results: ${searchResults.length}/${test.expectedResults} | Time: ${responseTime}ms | Score: ${score.toFixed(3)}`);
      
      results.push({
        metric: test.metric,
        query: test.query,
        resultsFound: searchResults.length,
        expectedResults: test.expectedResults,
        responseTime,
        score,
        avgRelevance: searchResults.length > 0 ? (searchResults.reduce((sum, r) => sum + r.score, 0) / searchResults.length) : 0
      });
      
    } catch (error) {
      console.log(`   ${test.metric}: ❌ Error - ${error.message}`);
      results.push({ metric: test.metric, query: test.query, error: error.message, score: 0 });
    }
  }
  
  return results;
}

async function runEfficacyTests(tests) {
  const results = [];
  
  for (const test of tests) {
    try {
      const queryEmbedding = await generateQueryEmbedding(test.query);
      const searchResults = await searchQdrant(queryEmbedding, 5);
      
      const targetChunkTypeFound = searchResults.some(r => r.payload.chunk_type === test.expectedType);
      const chunkTypeDistribution = searchResults.reduce((acc, r) => {
        acc[r.payload.chunk_type] = (acc[r.payload.chunk_type] || 0) + 1;
        return acc;
      }, {});
      
      const efficacyScore = targetChunkTypeFound ? 1.0 : 0.0;
      const precision = searchResults.length > 0 ? 
        (searchResults.filter(r => r.payload.chunk_type === test.expectedType).length / searchResults.length) : 0;
      
      console.log(`   ${test.metric}: Query "${test.query}"`);
      console.log(`     Target: ${test.expectedType} | Found: ${targetChunkTypeFound ? '✅' : '❌'} | Precision: ${precision.toFixed(3)}`);
      console.log(`     Distribution: ${Object.entries(chunkTypeDistribution).map(([type, count]) => `${type}(${count})`).join(', ')}`);
      
      results.push({
        metric: test.metric,
        query: test.query,
        expectedType: test.expectedType,
        targetFound: targetChunkTypeFound,
        precision,
        efficacyScore,
        chunkDistribution: chunkTypeDistribution
      });
      
    } catch (error) {
      console.log(`   ${test.metric}: ❌ Error - ${error.message}`);
      results.push({ metric: test.metric, query: test.query, error: error.message, efficacyScore: 0 });
    }
  }
  
  return results;
}

async function runQualityTests(tests) {
  const results = [];
  
  for (const test of tests) {
    try {
      const queryEmbedding = await generateQueryEmbedding(test.query);
      const searchResults = await searchQdrant(queryEmbedding, 5);
      
      const qualityScore = calculateSemanticQuality(searchResults, test.expectedTerms);
      const avgRelevance = searchResults.length > 0 ? 
        (searchResults.reduce((sum, r) => sum + r.score, 0) / searchResults.length) : 0;
      
      const termsFound = test.expectedTerms.filter(term => 
        searchResults.some(r => 
          r.payload.content.toLowerCase().includes(term.toLowerCase()) ||
          (r.payload.searchable_terms && r.payload.searchable_terms.some(st => 
            st.toLowerCase().includes(term.toLowerCase())
          ))
        )
      );
      
      console.log(`   ${test.metric}: Query "${test.query}"`);
      console.log(`     Expected terms: [${test.expectedTerms.join(', ')}]`);
      console.log(`     Found terms: [${termsFound.join(', ')}] | Avg Relevance: ${avgRelevance.toFixed(3)} | Quality: ${qualityScore.toFixed(3)}`);
      
      results.push({
        metric: test.metric,
        query: test.query,
        expectedTerms: test.expectedTerms,
        termsFound,
        avgRelevance,
        qualityScore,
        termsPrecision: termsFound.length / test.expectedTerms.length
      });
      
    } catch (error) {
      console.log(`   ${test.metric}: ❌ Error - ${error.message}`);
      results.push({ metric: test.metric, query: test.query, error: error.message, qualityScore: 0 });
    }
  }
  
  return results;
}

async function runComplexityTests(tests) {
  const results = [];
  
  for (const test of tests) {
    try {
      const queryEmbedding = await generateQueryEmbedding(test.query);
      const searchResults = await searchQdrant(queryEmbedding, 10);
      
      const resourceTypesFound = [...new Set(searchResults.map(r => r.payload.resource_type))];
      const resourceMatches = test.expectedResources.filter(expected => 
        resourceTypesFound.some(found => found.toLowerCase().includes(expected.toLowerCase()))
      );
      
      const complexityScore = resourceMatches.length / test.expectedResources.length;
      const crossResourceConnections = analyzeResourceConnections(searchResults);
      
      console.log(`   ${test.metric}: Query "${test.query}"`);
      console.log(`     Expected resources: [${test.expectedResources.join(', ')}]`);
      console.log(`     Found resources: [${resourceTypesFound.join(', ')}]`);
      console.log(`     Match rate: ${resourceMatches.length}/${test.expectedResources.length} | Complexity Score: ${complexityScore.toFixed(3)}`);
      
      results.push({
        metric: test.metric,
        query: test.query,
        expectedResources: test.expectedResources,
        resourceTypesFound,
        resourceMatches,
        complexityScore,
        crossResourceConnections
      });
      
    } catch (error) {
      console.log(`   ${test.metric}: ❌ Error - ${error.message}`);
      results.push({ metric: test.metric, query: test.query, error: error.message, complexityScore: 0 });
    }
  }
  
  return results;
}

function generateSummaryReport(results) {
  const performanceScores = results.performance.filter(r => !r.error).map(r => r.score);
  const efficacyScores = results.efficacy.filter(r => !r.error).map(r => r.efficacyScore);
  const qualityScores = results.quality.filter(r => !r.error).map(r => r.qualityScore);
  const complexityScores = results.complexity.filter(r => !r.error).map(r => r.complexityScore);
  
  const avgPerformance = performanceScores.length > 0 ? (performanceScores.reduce((a, b) => a + b, 0) / performanceScores.length) : 0;
  const avgEfficacy = efficacyScores.length > 0 ? (efficacyScores.reduce((a, b) => a + b, 0) / efficacyScores.length) : 0;
  const avgQuality = qualityScores.length > 0 ? (qualityScores.reduce((a, b) => a + b, 0) / qualityScores.length) : 0;
  const avgComplexity = complexityScores.length > 0 ? (complexityScores.reduce((a, b) => a + b, 0) / complexityScores.length) : 0;
  
  const overallScore = (avgPerformance + avgEfficacy + avgQuality + avgComplexity) / 4;
  
  console.log(`🎯 Performance Score: ${(avgPerformance * 100).toFixed(1)}%`);
  console.log(`🎯 Efficacy Score: ${(avgEfficacy * 100).toFixed(1)}%`);
  console.log(`🎯 Quality Score: ${(avgQuality * 100).toFixed(1)}%`);
  console.log(`🎯 Complexity Score: ${(avgComplexity * 100).toFixed(1)}%`);
  console.log(`🏆 Overall RAG Score: ${(overallScore * 100).toFixed(1)}%`);
  
  // Response time analysis
  const responseTimes = results.performance.filter(r => r.responseTime).map(r => r.responseTime);
  if (responseTimes.length > 0) {
    const avgResponseTime = responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length;
    const maxResponseTime = Math.max(...responseTimes);
    console.log(`⚡ Avg Response Time: ${avgResponseTime.toFixed(0)}ms`);
    console.log(`⚡ Max Response Time: ${maxResponseTime}ms`);
  }
  
  return {
    avgPerformance,
    avgEfficacy,
    avgQuality,
    avgComplexity,
    overallScore,
    avgResponseTime: responseTimes.length > 0 ? responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length : 0
  };
}

function benchmarkAgainstResearch(results) {
  console.log('📚 Comparison with Published Research:');
  
  // Xmartlabs benchmark: 0.83 retrieval accuracy
  const ourRetrievalAccuracy = results.summary.avgPerformance;
  console.log(`   Xmartlabs Benchmark: 83.0% retrieval accuracy`);
  console.log(`   Our Performance: ${(ourRetrievalAccuracy * 100).toFixed(1)}% (${ourRetrievalAccuracy > 0.83 ? '✅ Better' : '❌ Lower'})`);
  
  // ArXiv paper benchmark: 73.54% mean score
  const ourMeanScore = results.summary.overallScore;
  console.log(`   ArXiv Paper Benchmark: 73.5% overall score`);
  console.log(`   Our Overall Score: ${(ourMeanScore * 100).toFixed(1)}% (${ourMeanScore > 0.735 ? '✅ Better' : '❌ Lower'})`);
  
  // Response time benchmark (industry standard: <500ms)
  const avgResponseTime = results.summary.avgResponseTime;
  console.log(`   Industry Standard: <500ms response time`);
  console.log(`   Our Response Time: ${avgResponseTime.toFixed(0)}ms (${avgResponseTime < 500 ? '✅ Meets Standard' : '⚠️ Above Standard'})`);
  
  // Multi-resource capability (novel feature)
  const complexityScore = results.summary.avgComplexity;
  console.log(`   Multi-Resource Search: ${(complexityScore * 100).toFixed(1)}% (🆕 Novel Capability)`);
}

// Helper functions
async function generateQueryEmbedding(query) {
  const response = await axios.post('http://localhost:8050/embeddings', {
    texts: [query],
    model: 'bge-m3'
  });
  return response.data.embeddings[0];
}

async function searchQdrant(vector, limit = 5) {
  const response = await axios.post('http://localhost:6333/collections/fhir_chunks/points/search', {
    vector: vector,
    limit: limit,
    with_payload: true,
    score_threshold: 0.3
  });
  return response.data.result;
}

function calculatePerformanceScore(results, expected, responseTime) {
  const resultScore = Math.min(results.length / expected, 1.0);
  const timeScore = responseTime < 200 ? 1.0 : responseTime < 500 ? 0.8 : responseTime < 1000 ? 0.6 : 0.4;
  return (resultScore + timeScore) / 2;
}

function calculateSemanticQuality(results, expectedTerms) {
  if (results.length === 0) return 0;
  
  const avgRelevance = results.reduce((sum, r) => sum + r.score, 0) / results.length;
  const termMatches = expectedTerms.filter(term => 
    results.some(r => 
      r.payload.content.toLowerCase().includes(term.toLowerCase()) ||
      (r.payload.searchable_terms && r.payload.searchable_terms.some(st => 
        st.toLowerCase().includes(term.toLowerCase())
      ))
    )
  ).length;
  
  const termScore = termMatches / expectedTerms.length;
  return (avgRelevance + termScore) / 2;
}

function analyzeResourceConnections(results) {
  const resourceTypes = [...new Set(results.map(r => r.payload.resource_type))];
  return resourceTypes.length > 1 ? resourceTypes.length : 0;
}

// Run the comprehensive evaluation
runComprehensiveEvaluation()
  .then(() => console.log('\n🎉 Comprehensive Evaluation Complete!'))
  .catch(error => console.error('❌ Evaluation failed:', error.message));