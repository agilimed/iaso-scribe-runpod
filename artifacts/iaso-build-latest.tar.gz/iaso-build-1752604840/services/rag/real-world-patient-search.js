const axios = require('axios');

// Real-world healthcare queries that clinicians and staff actually use
const realWorldQueries = [
  // Patient lookup queries
  { query: "find patient John Smith", intent: "patient_lookup", expectedChunks: ["summary", "demographics"] },
  { query: "patient with MRN-000015", intent: "identifier_lookup", expectedChunks: ["identifiers", "summary"] },
  
  // Clinical information queries
  { query: "show me John Smith's recent lab results", intent: "lab_results", expectedChunks: ["clinical", "codes"] },
  { query: "what medications is patient MRN-000015 taking", intent: "medications", expectedChunks: ["clinical", "summary"] },
  { query: "patient's blood pressure readings", intent: "vitals", expectedChunks: ["clinical", "temporal"] },
  { query: "diabetes patients with high A1C", intent: "condition_search", expectedChunks: ["clinical", "codes"] },
  
  // Administrative queries
  { query: "contact information for patient John Smith", intent: "contact", expectedChunks: ["contact", "demographics"] },
  { query: "when was the patient's last visit", intent: "encounters", expectedChunks: ["temporal", "summary"] },
  { query: "patient's insurance information", intent: "coverage", expectedChunks: ["financial", "identifiers"] },
  
  // Care coordination queries
  { query: "patients seen today in emergency", intent: "daily_census", expectedChunks: ["temporal", "clinical"] },
  { query: "elderly patients with multiple conditions", intent: "population_health", expectedChunks: ["demographics", "clinical"] },
  { query: "patients due for follow-up appointments", intent: "care_gaps", expectedChunks: ["temporal", "clinical"] },
  
  // Billing queries
  { query: "outstanding bills for patient", intent: "billing", expectedChunks: ["financial", "summary"] },
  { query: "procedures performed last month", intent: "revenue", expectedChunks: ["clinical", "temporal", "financial"] }
];

async function generateQueryEmbedding(query) {
  const response = await axios.post('http://localhost:8050/embeddings', {
    texts: [query],
    model: 'bge-m3'
  });
  return response.data.embeddings[0];
}

async function searchQdrant(vector, limit = 10) {
  const response = await axios.post('http://localhost:6333/collections/fhir_chunks/points/search', {
    vector: vector,
    limit: limit,
    with_payload: true,
    score_threshold: 0.3
  });
  return response.data.result;
}

async function runRealWorldSearch() {
  console.log('🏥 Real-World Healthcare Query Evaluation\n');
  console.log('=' .repeat(80));
  
  const results = {
    successful: 0,
    partial: 0,
    failed: 0,
    details: []
  };
  
  for (const testQuery of realWorldQueries) {
    console.log(`\n📋 Query: "${testQuery.query}"`);
    console.log(`   Intent: ${testQuery.intent}`);
    console.log(`   Expected chunks: [${testQuery.expectedChunks.join(', ')}]`);
    
    try {
      // Generate embedding and search
      const embedding = await generateQueryEmbedding(testQuery.query);
      const searchResults = await searchQdrant(embedding);
      
      // Analyze results
      const foundChunkTypes = [...new Set(searchResults.map(r => r.payload.chunk_type))];
      const matchingExpected = testQuery.expectedChunks.filter(expected => 
        foundChunkTypes.includes(expected)
      );
      
      // Calculate success metrics
      const matchRate = matchingExpected.length / testQuery.expectedChunks.length;
      const topResult = searchResults[0];
      
      console.log(`\n   🔍 Results:`);
      console.log(`   Top match: ${topResult.payload.resource_type}/${topResult.payload.chunk_type} (score: ${topResult.score.toFixed(3)})`);
      console.log(`   Found chunk types: [${foundChunkTypes.slice(0, 5).join(', ')}]`);
      console.log(`   Expected match rate: ${(matchRate * 100).toFixed(0)}%`);
      
      // Show sample content from top result
      console.log(`\n   📄 Top result content:`);
      console.log(`   "${topResult.payload.content.substring(0, 150)}..."`);
      
      // Categorize result
      if (matchRate >= 0.5) {
        results.successful++;
        console.log(`   ✅ SUCCESS - Found relevant information`);
      } else if (matchRate > 0) {
        results.partial++;
        console.log(`   ⚠️ PARTIAL - Some relevant chunks found`);
      } else {
        results.failed++;
        console.log(`   ❌ FAILED - No relevant chunks found`);
      }
      
      // Store detailed results
      results.details.push({
        query: testQuery.query,
        intent: testQuery.intent,
        expectedChunks: testQuery.expectedChunks,
        foundChunks: foundChunkTypes,
        matchRate,
        topScore: topResult.score,
        success: matchRate >= 0.5
      });
      
    } catch (error) {
      console.log(`   ❌ ERROR: ${error.message}`);
      results.failed++;
    }
  }
  
  // Summary Report
  console.log('\n\n' + '=' .repeat(80));
  console.log('📊 REAL-WORLD EFFICACY SUMMARY\n');
  
  const totalQueries = realWorldQueries.length;
  const successRate = (results.successful / totalQueries * 100).toFixed(1);
  const partialRate = (results.partial / totalQueries * 100).toFixed(1);
  const failureRate = (results.failed / totalQueries * 100).toFixed(1);
  
  console.log(`Total Queries: ${totalQueries}`);
  console.log(`✅ Successful: ${results.successful} (${successRate}%)`);
  console.log(`⚠️  Partial: ${results.partial} (${partialRate}%)`);
  console.log(`❌ Failed: ${results.failed} (${failureRate}%)`);
  console.log(`\n🎯 Overall Success Rate: ${successRate}%`);
  
  // Breakdown by intent
  console.log('\n📋 Success by Query Intent:');
  const intentGroups = {};
  results.details.forEach(r => {
    if (!intentGroups[r.intent]) {
      intentGroups[r.intent] = { total: 0, successful: 0 };
    }
    intentGroups[r.intent].total++;
    if (r.success) intentGroups[r.intent].successful++;
  });
  
  Object.entries(intentGroups).forEach(([intent, stats]) => {
    const rate = (stats.successful / stats.total * 100).toFixed(0);
    console.log(`   ${intent}: ${rate}% (${stats.successful}/${stats.total})`);
  });
  
  // Chunk type effectiveness
  console.log('\n📊 Chunk Type Effectiveness:');
  const chunkTypeHits = {};
  results.details.forEach(r => {
    r.foundChunks.forEach(chunk => {
      chunkTypeHits[chunk] = (chunkTypeHits[chunk] || 0) + 1;
    });
  });
  
  Object.entries(chunkTypeHits)
    .sort(([,a], [,b]) => b - a)
    .forEach(([chunk, count]) => {
      console.log(`   ${chunk}: ${count} queries`);
    });
  
  // Recommendations
  console.log('\n💡 Recommendations:');
  if (failureRate > 30) {
    console.log('   - High failure rate indicates missing data or chunk types');
  }
  if (results.details.filter(r => r.expectedChunks.includes('financial') && !r.success).length > 2) {
    console.log('   - Financial queries failing - need financial resource data');
  }
  if (results.details.filter(r => r.matchRate < 0.5 && r.topScore < 0.5).length > 3) {
    console.log('   - Low relevance scores - consider reindexing with enhanced terms');
  }
  
  return results;
}

// Run the evaluation
runRealWorldSearch()
  .then(results => {
    console.log('\n\n🏁 Real-World Evaluation Complete!');
  })
  .catch(error => {
    console.error('❌ Evaluation failed:', error.message);
  });