const axios = require('axios');

async function checkRecentChunks() {
  console.log('🔍 Checking Recent Chunks for Enhanced Terms\n');
  
  try {
    // Get the most recent summary chunks (last 10 minutes)
    const recentTime = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    
    const allChunksResponse = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 100,
      with_payload: true,
      filter: {
        must: [
          { key: 'chunk_type', match: { value: 'summary' } },
          { key: 'resource_type', match: { value: 'Patient' } }
        ]
      }
    });
    
    const chunks = allChunksResponse.data.result.points;
    console.log(`Found ${chunks.length} Patient summary chunks\n`);
    
    if (chunks.length > 0) {
      // Check most recent chunk
      const sortedChunks = chunks.sort((a, b) => 
        new Date(b.payload.timestamp) - new Date(a.payload.timestamp)
      );
      
      console.log('📋 MOST RECENT PATIENT SUMMARY CHUNK:');
      const recent = sortedChunks[0];
      console.log(`Timestamp: ${recent.payload.timestamp}`);
      console.log(`Content: "${recent.payload.content.substring(0, 150)}..."`);
      console.log(`Searchable Terms Count: ${(recent.payload.searchable_terms || []).length}`);
      console.log(`Searchable Terms: [${(recent.payload.searchable_terms || []).join(', ')}]\n`);
      
      // Check if it has enhanced terms
      const searchableTerms = recent.payload.searchable_terms || [];
      const hasEnhancedTerms = searchableTerms.some(term => 
        ['healthcare', 'medical', 'health', 'clinical'].includes(term)
      );
      
      console.log(`Has Enhanced Terms: ${hasEnhancedTerms ? '✅ YES' : '❌ NO'}\n`);
      
      if (!hasEnhancedTerms) {
        console.log('🚨 ISSUE: Recent chunks still don\'t have enhanced terms!');
        console.log('This means the extractSearchableTerms method enhancement isn\'t working.\n');
        
        // Check if the terms exist in extractSearchableTerms output
        console.log('🔧 Expected terms for Patient resource type should include:');
        console.log('["healthcare", "medical", "health", "clinical", "patient", "patient information", "patient data"]');
      } else {
        console.log('✅ Enhanced terms are present - the issue may be with ranking/scoring');
      }
      
      // Check demographics chunk for comparison
      const demographicsResponse = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
        limit: 5,
        with_payload: true,
        filter: {
          must: [{ key: 'chunk_type', match: { value: 'demographics' } }]
        }
      });
      
      if (demographicsResponse.data.result.points.length > 0) {
        const demo = demographicsResponse.data.result.points[0];
        console.log('\n📋 DEMOGRAPHICS CHUNK FOR COMPARISON:');
        console.log(`Searchable Terms Count: ${(demo.payload.searchable_terms || []).length}`);
        console.log(`Has "demographics" term: ${(demo.payload.searchable_terms || []).includes('demographics') ? '✅' : '❌'}`);
        console.log(`Has "patient demographics" term: ${(demo.payload.searchable_terms || []).includes('patient demographics') ? '✅' : '❌'}`);
      }
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

checkRecentChunks()
  .then(() => console.log('\n🎉 Check Complete!'))
  .catch(error => console.error('❌ Check failed:', error.message));