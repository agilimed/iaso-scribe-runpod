const { Kafka } = require('kafkajs');

async function produceTestEvent() {
  const kafka = new Kafka({
    clientId: 'test-producer',
    brokers: ['localhost:9092']
  });

  const producer = kafka.producer();

  try {
    await producer.connect();
    console.log('Connected to Kafka producer');

    const testEvent = {
      sign: 1,
      domain: 'fhir',
      user_id: 'test-user',
      tenant_id: 'test-tenant',
      event_time: new Date().toISOString(),
      event_type: 'create',
      resource_id: 'test-patient-001',
      resource_data: {
        resourceType: 'Patient',
        id: 'test-patient-001',
        name: [{
          given: ['Test'],
          family: 'Patient'
        }]
      },
      resource_type: 'Patient'
    };

    await producer.send({
      topic: 'fhir.events',
      messages: [
        {
          key: 'test-event-' + Date.now(),
          value: JSON.stringify(testEvent)
        }
      ]
    });

    console.log('✅ Successfully sent test event to Kafka');
    await producer.disconnect();
  } catch (error) {
    console.error('❌ Error:', error);
  }
}

produceTestEvent();