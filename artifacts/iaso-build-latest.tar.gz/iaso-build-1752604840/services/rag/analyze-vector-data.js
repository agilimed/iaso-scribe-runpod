const axios = require('axios');

async function analyzeVectorData() {
  console.log('🔍 Comprehensive Vector Database Analysis\n');
  
  try {
    // Get basic collection info
    const collectionInfo = await axios.get('http://localhost:6333/collections/fhir_chunks');
    console.log('📊 Collection Overview:');
    console.log(`- Total Points: ${collectionInfo.data.result.points_count}`);
    console.log(`- Vector Dimensions: ${collectionInfo.data.result.config.params.vectors.size}`);
    console.log(`- Distance Metric: ${collectionInfo.data.result.config.params.vectors.distance}\n`);

    // Get all data for analysis
    const allData = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 2000,
      with_payload: true,
      with_vector: false
    });

    const points = allData.data.result.points;
    console.log(`📋 Analyzing ${points.length} chunks...\n`);

    // Analyze by resource type
    const resourceTypes = {};
    const chunkTypes = {};
    const patients = new Set();
    const resourceIds = new Set();

    points.forEach(point => {
      const payload = point.payload;
      
      // Resource type distribution
      const resourceType = payload.resource_type;
      resourceTypes[resourceType] = (resourceTypes[resourceType] || 0) + 1;
      
      // Chunk type distribution
      const chunkType = payload.chunk_type;
      chunkTypes[chunkType] = (chunkTypes[chunkType] || 0) + 1;
      
      // Unique patients
      if (payload.patient_id) {
        patients.add(payload.patient_id);
      }
      
      // Unique resources
      if (payload.resource_id) {
        resourceIds.add(`${resourceType}/${payload.resource_id}`);
      }
    });

    // Resource Type Analysis
    console.log('🏥 Resource Type Distribution:');
    const sortedResourceTypes = Object.entries(resourceTypes)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 15);
    
    sortedResourceTypes.forEach(([type, count]) => {
      const percentage = ((count / points.length) * 100).toFixed(1);
      console.log(`   ${type}: ${count} chunks (${percentage}%)`);
    });

    // Chunk Type Analysis
    console.log('\n📊 Chunk Type Distribution:');
    Object.entries(chunkTypes)
      .sort(([,a], [,b]) => b - a)
      .forEach(([type, count]) => {
        const percentage = ((count / points.length) * 100).toFixed(1);
        console.log(`   ${type}: ${count} chunks (${percentage}%)`);
      });

    console.log('\n📈 Summary Statistics:');
    console.log(`   👥 Unique Patients: ${patients.size}`);
    console.log(`   🏥 Unique Resources: ${resourceIds.size}`);
    console.log(`   📦 Avg Chunks per Resource: ${(points.length / resourceIds.size).toFixed(1)}`);
    console.log(`   📦 Avg Chunks per Patient: ${(points.length / patients.size).toFixed(1)}`);

    // Sample resource breakdown
    console.log('\n🔬 Sample Resource Breakdown:');
    const sampleResources = Array.from(resourceIds).slice(0, 5);
    
    for (const resource of sampleResources) {
      const [resourceType, resourceId] = resource.split('/');
      const resourceChunks = points.filter(p => 
        p.payload.resource_type === resourceType && p.payload.resource_id === resourceId
      );
      
      console.log(`\n   ${resource}:`);
      resourceChunks.forEach(chunk => {
        console.log(`     - ${chunk.payload.chunk_type}: ${chunk.payload.content.substring(0, 80)}...`);
      });
    }

    // Temporal analysis
    console.log('\n⏰ Recent Activity Analysis:');
    const recentChunks = points
      .filter(p => p.payload.timestamp)
      .sort((a, b) => new Date(b.payload.timestamp) - new Date(a.payload.timestamp))
      .slice(0, 10);

    console.log('   Most Recent Chunks:');
    recentChunks.forEach((chunk, index) => {
      const time = new Date(chunk.payload.timestamp).toLocaleTimeString();
      console.log(`   ${index + 1}. ${time} - ${chunk.payload.resource_type}/${chunk.payload.resource_id} (${chunk.payload.chunk_type})`);
    });

    // Search quality test
    console.log('\n🔍 Search Quality Test:');
    await testSearchQuality(points);

  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

async function testSearchQuality(points) {
  const testQueries = [
    'medication request',
    'patient encounter',
    'clinical observation',
    'allergy information'
  ];

  for (const query of testQueries) {
    try {
      const queryEmbedding = await generateQueryEmbedding(query);
      const results = await searchQdrant(queryEmbedding, 3);
      
      console.log(`\n   Query: "${query}" - ${results.length} results`);
      if (results.length > 0) {
        const avgScore = (results.reduce((sum, r) => sum + r.score, 0) / results.length).toFixed(3);
        const resourceTypes = [...new Set(results.map(r => r.payload.resource_type))];
        console.log(`     Avg Score: ${avgScore}, Resource Types: ${resourceTypes.join(', ')}`);
      }
    } catch (error) {
      console.log(`     Error testing "${query}": ${error.message}`);
    }
  }
}

async function generateQueryEmbedding(query) {
  const response = await axios.post('http://localhost:8050/embeddings', {
    texts: [query],
    model: 'bge-m3'
  });
  return response.data.embeddings[0];
}

async function searchQdrant(vector, limit = 3) {
  const response = await axios.post('http://localhost:6333/collections/fhir_chunks/points/search', {
    vector: vector,
    limit: limit,
    with_payload: true,
    score_threshold: 0.5
  });
  return response.data.result;
}

analyzeVectorData()
  .then(() => console.log('\n🎉 Analysis Complete!'))
  .catch(error => console.error('❌ Analysis failed:', error.message));