import { QdrantClient } from '@qdrant/js-client-rest';
import { v4 as uuidv4 } from 'uuid';
import { ResourceChunk, QueryResult } from '../types';

export class QdrantService {
  private client: QdrantClient;
  private collectionName: string;
  private vectorSize: number;

  constructor(
    url: string = process.env.QDRANT_URL || 'http://localhost:6333',
    collectionName: string = 'fhir_resources',
    vectorSize: number = 1024 // BGE-M3 dimensions
  ) {
    this.client = new QdrantClient({ url });
    this.collectionName = collectionName;
    this.vectorSize = vectorSize;
  }

  async initialize(): Promise<void> {
    try {
      const collections = await this.client.getCollections();
      const collectionExists = collections.collections.some(
        (c) => c.name === this.collectionName
      );

      if (!collectionExists) {
        await this.client.createCollection(this.collectionName, {
          vectors: {
            size: this.vectorSize,
            distance: 'Cosine',
          },
        });
        console.log(`Created collection: ${this.collectionName}`);
      }

      // Create indices for better search performance
      await this.client.createPayloadIndex(this.collectionName, {
        field_name: 'tenantId',
        field_schema: 'keyword',
      });

      await this.client.createPayloadIndex(this.collectionName, {
        field_name: 'resourceType',
        field_schema: 'keyword',
      });

      await this.client.createPayloadIndex(this.collectionName, {
        field_name: 'resourceId',
        field_schema: 'keyword',
      });
    } catch (error) {
      console.error('Error initializing Qdrant:', error);
      throw error;
    }
  }

  async upsertChunk(chunk: ResourceChunk): Promise<void> {
    if (!chunk.embedding || chunk.embedding.length === 0) {
      throw new Error('Chunk must have embedding');
    }

    const point = {
      id: uuidv4(),
      vector: chunk.embedding,
      payload: {
        resourceType: chunk.resourceType,
        resourceId: chunk.resourceId,
        versionId: chunk.versionId,
        tenantId: chunk.tenantId,
        chunkType: chunk.chunkType,
        content: chunk.content,
        metadata: chunk.metadata,
        timestamp: new Date().toISOString(),
      },
    };

    await this.client.upsert(this.collectionName, {
      points: [point],
    });
  }

  async upsertChunks(chunks: ResourceChunk[]): Promise<void> {
    const points = chunks
      .filter((chunk) => chunk.embedding && chunk.embedding.length > 0)
      .map((chunk) => ({
        id: uuidv4(),
        vector: chunk.embedding!,
        payload: {
          resourceType: chunk.resourceType,
          resourceId: chunk.resourceId,
          versionId: chunk.versionId,
          tenantId: chunk.tenantId,
          chunkType: chunk.chunkType,
          content: chunk.content,
          metadata: chunk.metadata,
          timestamp: new Date().toISOString(),
        },
      }));

    if (points.length === 0) return;

    await this.client.upsert(this.collectionName, {
      points,
    });
  }

  async search(
    queryEmbedding: number[],
    tenantId: string,
    limit: number = 10,
    filters?: Record<string, any>
  ): Promise<QueryResult[]> {
    const mustFilters: any[] = [
      {
        key: 'tenantId',
        match: { value: tenantId },
      },
    ];

    if (filters?.resourceTypes && filters.resourceTypes.length > 0) {
      mustFilters.push({
        key: 'resourceType',
        match: { any: filters.resourceTypes },
      });
    }

    // Add any additional filters
    Object.entries(filters || {}).forEach(([key, value]) => {
      if (key !== 'resourceTypes' && value !== undefined) {
        mustFilters.push({
          key,
          match: { value },
        });
      }
    });

    const searchResult = await this.client.search(this.collectionName, {
      vector: queryEmbedding,
      filter: {
        must: mustFilters,
      },
      limit,
      with_payload: true,
    });

    return searchResult.map((result) => ({
      id: result.id as string,
      resourceType: result.payload?.resourceType as string,
      resourceId: result.payload?.resourceId as string,
      score: result.score,
      content: result.payload?.content as string,
      metadata: result.payload?.metadata as Record<string, any>,
    }));
  }

  async deleteByResourceId(
    tenantId: string,
    resourceType: string,
    resourceId: string
  ): Promise<void> {
    await this.client.delete(this.collectionName, {
      filter: {
        must: [
          { key: 'tenantId', match: { value: tenantId } },
          { key: 'resourceType', match: { value: resourceType } },
          { key: 'resourceId', match: { value: resourceId } },
        ],
      },
    });
  }

  async getCollectionInfo(): Promise<any> {
    return await this.client.getCollection(this.collectionName);
  }
}