import * as grpc from '@grpc/grpc-js';
import * as protoLoader from '@grpc/proto-loader';
import path from 'path';
import { EmbeddingRequest, EmbeddingResponse } from '../types';

const PROTO_PATH = path.join(__dirname, '../../../protos/embeddings_service.proto');

export class EmbeddingsClient {
  private client: any;

  constructor(
    serviceUrl: string = process.env.EMBEDDINGS_SERVICE_URL || 'localhost:50051'
  ) {
    const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
      keepCase: true,
      longs: String,
      enums: String,
      defaults: true,
      oneofs: true,
    });

    const proto = grpc.loadPackageDefinition(packageDefinition) as any;
    this.client = new proto.rag.EmbeddingService(
      serviceUrl,
      grpc.credentials.createInsecure()
    );
  }

  async generateEmbeddings(
    texts: string[],
    model?: string
  ): Promise<EmbeddingResponse> {
    return new Promise((resolve, reject) => {
      const request = {
        texts,
        model: model || 'bge-m3',  // Use bge-m3 as default model
      };

      this.client.GenerateEmbeddings(request, (error: any, response: any) => {
        if (error) {
          reject(error);
        } else {
          resolve({
            embeddings: response.embeddings.map((e: any) => e.values),
            model: response.model,
            usage: {
              prompt_tokens: response.usage.prompt_tokens,
              total_tokens: response.usage.total_tokens,
            },
          });
        }
      });
    });
  }

  async generateEmbedding(text: string, model?: string): Promise<number[]> {
    const response = await this.generateEmbeddings([text], model);
    return response.embeddings[0];
  }

  async healthCheck(): Promise<boolean> {
    return new Promise((resolve) => {
      // Set a timeout to prevent hanging
      const timeout = setTimeout(() => {
        console.warn('Embeddings service health check timed out after 5 seconds');
        resolve(false);
      }, 5000);

      this.client.HealthCheck({}, { deadline: Date.now() + 5000 }, (error: any, response: any) => {
        clearTimeout(timeout);
        if (error) {
          // If health check is not implemented, try a simple embeddings request
          if (error.code === 12) { // UNIMPLEMENTED
            console.log('Health check not implemented, testing with embeddings generation...');
            this.generateEmbeddings(['test'], 'bge-m3')
              .then(() => {
                console.log('Embeddings service is healthy (tested via generation)');
                resolve(true);
              })
              .catch((embError) => {
                console.error('Embeddings service is not healthy:', embError);
                resolve(false);
              });
          } else {
            console.error('Embeddings service health check failed:', error);
            resolve(false);
          }
        } else {
          resolve(response.healthy === true);
        }
      });
    });
  }
}