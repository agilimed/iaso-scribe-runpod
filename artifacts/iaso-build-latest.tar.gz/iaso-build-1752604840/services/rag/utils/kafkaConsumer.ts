import { Kafka, Consumer, EachMessagePayload } from 'kafkajs';
import { FHIREvent } from '../types';

export class KafkaConsumerService {
  private kafka: Kafka;
  private consumer: Consumer;
  private isRunning: boolean = false;

  constructor(
    brokers: string[] = ['localhost:9092'],
    groupId: string = 'fhir-rag-processor'
  ) {
    this.kafka = new Kafka({
      clientId: 'fhir-rag-processor',
      brokers,
      retry: {
        initialRetryTime: 100,
        retries: 8,
      },
    });

    this.consumer = this.kafka.consumer({ groupId });
  }

  async start(
    topic: string,
    messageHandler: (event: FHIREvent) => Promise<void>
  ): Promise<void> {
    try {
      await this.consumer.connect();
      await this.consumer.subscribe({ topic, fromBeginning: false });

      this.isRunning = true;

      await this.consumer.run({
        eachMessage: async ({ message }: EachMessagePayload) => {
          try {
            const eventData = JSON.parse(message.value?.toString() || '{}');
            
            // Transform PostgreSQL trigger event format to FHIREvent format
            let action: 'create' | 'update' | 'delete';
            if (eventData.sign === 'C') {
              action = 'create';
            } else if (eventData.sign === 'U') {
              action = 'update';
            } else if (eventData.sign === 'D') {
              action = 'delete';
            } else {
              console.warn(`Unknown sign value: ${eventData.sign}, defaulting to update`);
              action = 'update';
            }

            // Parse resource_data if it's a string
            let resource = null;
            if (eventData.resource_data) {
              try {
                resource = typeof eventData.resource_data === 'string' 
                  ? JSON.parse(eventData.resource_data) 
                  : eventData.resource_data;
              } catch (e) {
                console.error('Failed to parse resource_data:', e);
                resource = eventData.resource_data;
              }
            }

            const event: FHIREvent = {
              id: eventData.event_id || `${eventData.resource_type}-${eventData.resource_id}-${Date.now()}`,
              resourceType: eventData.resource_type,
              resourceId: eventData.resource_id,
              versionId: eventData.resource_vid || '1',
              action: action,
              tenantId: eventData.tenant_id,
              timestamp: eventData.timestamp || new Date().toISOString(),
              resource: resource,
            };

            console.log(`Processing ${action} event for ${event.resourceType}/${event.resourceId}`);
            await messageHandler(event);
          } catch (error) {
            console.error('Error processing message:', error);
            // Consider implementing dead letter queue here
          }
        },
      });

      console.log(`Kafka consumer started for topic: ${topic}`);
    } catch (error) {
      console.error('Error starting Kafka consumer:', error);
      throw error;
    }
  }

  async stop(): Promise<void> {
    if (this.isRunning) {
      this.isRunning = false;
      await this.consumer.disconnect();
      console.log('Kafka consumer stopped');
    }
  }

  isActive(): boolean {
    return this.isRunning;
  }
}