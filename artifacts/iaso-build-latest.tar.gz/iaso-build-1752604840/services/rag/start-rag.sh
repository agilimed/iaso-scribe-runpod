#!/bin/bash

# Start RAG service in isolation to prevent signal propagation
echo "Starting RAG service..."

# Load environment variables
export $(cat .env | grep -v '^#' | xargs)

# Run the service directly without nodemon to debug
node -r ts-node/register src/simple-server.ts