export interface FHIREvent {
  id: string;
  resourceType: string;
  resourceId: string;
  versionId: string;
  action: 'create' | 'update' | 'delete';
  tenantId: string;
  timestamp: string;
  resource: any;
}

export interface ResourceChunk {
  id: string;
  resourceType: string;
  resourceId: string;
  versionId: string;
  tenantId: string;
  chunkType: string;
  content: string;
  metadata: Record<string, any>;
  embedding?: number[];
}

export interface QueryRequest {
  query: string;
  tenantId: string;
  resourceTypes?: string[];
  limit?: number;
  filters?: Record<string, any>;
}

export interface QueryResult {
  id: string;
  resourceType: string;
  resourceId: string;
  score: number;
  content: string;
  metadata: Record<string, any>;
}

export interface EmbeddingRequest {
  texts: string[];
  model?: string;
}

export interface EmbeddingResponse {
  embeddings: number[][];
  model: string;
  usage: {
    prompt_tokens: number;
    total_tokens: number;
  };
}