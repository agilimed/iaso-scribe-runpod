const { Kafka } = require('kafkajs');

async function testKafkaConnection() {
  const kafka = new Kafka({
    clientId: 'rag-test-client',
    brokers: ['localhost:9092']
  });

  const consumer = kafka.consumer({ groupId: 'rag-test-group' });

  try {
    console.log('🔗 Connecting to Kafka...');
    await consumer.connect();
    console.log('✅ Connected to Kafka successfully');

    console.log('📥 Subscribing to fhir.events topic...');
    await consumer.subscribe({ topic: 'fhir.events' });
    console.log('✅ Subscribed to fhir.events topic');

    console.log('👂 Starting to listen for FHIR events...');
    
    await consumer.run({
      eachMessage: async ({ topic, partition, message, heartbeat, pause }) => {
        console.log('📨 Received FHIR event:');
        console.log('  Topic:', topic);
        console.log('  Partition:', partition);
        console.log('  Offset:', message.offset);
        console.log('  Key:', message.key?.toString());
        console.log('  Value:', message.value?.toString());
        console.log('  Headers:', message.headers);
        console.log('---');
        
        // Keep the consumer alive by calling heartbeat
        await heartbeat();
      },
    });

  } catch (error) {
    console.error('❌ Error connecting to Kafka:', error);
  }
}

// Handle graceful shutdown
process.on('SIGINT', async () => {
  console.log('🛑 Shutting down gracefully...');
  process.exit(0);
});

testKafkaConnection();