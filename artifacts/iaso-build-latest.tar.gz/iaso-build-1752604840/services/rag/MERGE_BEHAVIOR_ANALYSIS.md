# Merge Behavior Analysis: RAG Service & Qdrant

## Executive Summary

**Current State**: Our RAG service does NOT implement true merge operations. Instead, it uses **complete replacement** strategies via Qdrant's upsert mechanism.

**Qdrant Upsert Behavior**: When upserting with the same point ID, Qdrant performs a **complete replacement** of both vector and payload data - no merging occurs.

## Detailed Analysis

### 1. Qdrant Upsert Behavior

```typescript
// Qdrant upsert with same ID = COMPLETE REPLACEMENT
await this.client.upsert(collection, {
  points: [{
    id: "Patient:123:demographics", // Same ID
    vector: [new_embeddings],       // Completely replaces old vector
    payload: {new_payload}          // Completely replaces old payload
  }]
});
```

**Result**: 
- ✅ Old point is completely overwritten
- ❌ No data merging or preservation
- ❌ No conflict detection
- ✅ Atomic operation (consistent state)

### 2. Our Service Merge Strategy

#### Current Implementation (UPDATE Events)

```typescript
private async handleUpdateEvent(event: any): Promise<void> {
  // 1. DELETE all existing chunks for resource
  await this.deleteResourceChunks(event.resource_type, event.resource_id, event.tenant_id);
  
  // 2. CREATE new chunks with same deterministic IDs
  const chunks = this.generateChunksWithDeterministicIds(resource, event);
  
  // 3. UPSERT (complete replacement)
  await this.qdrantService.upsertPoints(event.tenant_id, points);
}
```

**This is NOT a merge - it's a complete replacement strategy**:
- ✅ Prevents duplicate chunks
- ✅ Ensures data consistency
- ❌ Loses any data not in the new resource
- ❌ No intelligent data combination

#### Missing: True MERGE Events

Our strategy document mentions MERGE events but they're **not implemented**:

```typescript
// FROM STRATEGY DOC - NOT IMPLEMENTED
interface FHIREvent {
  event_type: 'create' | 'update' | 'delete' | 'patch' | 'restore' | 'merge';
  // ... other fields
}
```

### 3. Production Merge Scenarios & Current Gaps

| Scenario | What Happens Now | What Should Happen | Status |
|----------|------------------|-------------------|---------|
| **Patient Update** | Complete replacement of all chunks | ✅ Expected behavior | ✅ Working |
| **Duplicate Patient Merge** | Both exist separately | Combine into single record | ❌ Not implemented |
| **Partial Resource Update** | Full resource replacement | Selective field updates | ❌ Not implemented |
| **Concurrent Updates** | Last write wins | Conflict detection/resolution | ❌ Not implemented |
| **Cross-Resource References** | No cascade updates | Update related chunks | ❌ Not implemented |

### 4. Types of Merges We Need

#### A. Resource Update "Merge" (Currently Working)
```typescript
// Patient gets updated contact info
// Old: Patient:123:contact -> "555-1111"
// New: Patient:123:contact -> "555-2222"
// Result: Complete replacement (expected)
```

#### B. Patient Record Merge (NOT Implemented)
```typescript
// Merge duplicate patients: Patient A + Patient B -> Patient B
// Challenge: Combine clinical history, preserve identifiers, update references
```

#### C. Partial Resource Update (NOT Implemented)
```typescript
// PATCH: Only phone number changes
// Should: Update only contact chunk, preserve other chunks
// Currently: Replaces ALL chunks for the resource
```

#### D. Cross-Resource Merge (NOT Implemented)
```typescript
// When Patient:123 merges into Patient:456
// Should: Update all Observation/Condition/etc. that reference Patient:123
// Currently: References become stale
```

### 5. Merge Implementation Recommendations

#### Phase 1: Add True MERGE Event Handler

```typescript
private async handleMergeEvent(event: any): Promise<void> {
  const { source_resource_id, target_resource_id, merge_strategy } = event;
  
  // 1. Get all chunks for source resource
  const sourceChunks = await this.getResourceChunks(source_resource_id);
  
  // 2. Get all chunks for target resource
  const targetChunks = await this.getResourceChunks(target_resource_id);
  
  // 3. Merge data intelligently based on chunk type
  const mergedChunks = this.mergeChunkData(sourceChunks, targetChunks, merge_strategy);
  
  // 4. Update chunk IDs to target resource
  const updatedChunks = this.updateChunkIds(mergedChunks, target_resource_id);
  
  // 5. Upsert merged chunks
  await this.qdrantService.upsertPoints(event.tenant_id, updatedChunks);
  
  // 6. Soft delete source chunks
  await this.markResourceDeleted(source_resource_id);
  
  // 7. Update cross-references
  await this.updateCrossReferences(source_resource_id, target_resource_id);
}
```

#### Phase 2: Intelligent Chunk Data Merging

```typescript
private mergeChunkData(sourceChunks: ResourceChunk[], targetChunks: ResourceChunk[], strategy: string): ResourceChunk[] {
  const mergedChunks: ResourceChunk[] = [];
  
  for (const chunkType of ['demographics', 'contact', 'clinical', 'identifiers']) {
    const sourceChunk = sourceChunks.find(c => c.metadata.chunkType === chunkType);
    const targetChunk = targetChunks.find(c => c.metadata.chunkType === chunkType);
    
    switch (chunkType) {
      case 'demographics':
        // Take most complete/recent demographic data
        mergedChunks.push(this.mergeDemo graphics(sourceChunk, targetChunk));
        break;
        
      case 'contact':
        // Combine all contact methods
        mergedChunks.push(this.mergeContact(sourceChunk, targetChunk));
        break;
        
      case 'identifiers':
        // Preserve all identifiers from both records
        mergedChunks.push(this.mergeIdentifiers(sourceChunk, targetChunk));
        break;
        
      case 'clinical':
        // Combine all clinical observations
        mergedChunks.push(this.mergeClinical(sourceChunk, targetChunk));
        break;
    }
  }
  
  return mergedChunks;
}
```

#### Phase 3: Cross-Reference Updates

```typescript
private async updateCrossReferences(oldResourceId: string, newResourceId: string): Promise<void> {
  // Find all chunks that reference the old resource
  const referencingChunks = await this.findReferencingChunks(oldResourceId);
  
  // Update their content and searchable terms
  for (const chunk of referencingChunks) {
    chunk.content = chunk.content.replace(oldResourceId, newResourceId);
    chunk.metadata.searchableTerms = chunk.metadata.searchableTerms.map(
      term => term.replace(oldResourceId, newResourceId)
    );
    
    // Update relationships metadata
    if (chunk.metadata.relationships) {
      chunk.metadata.relationships.relatedResources.forEach(rel => {
        if (rel.resourceId === oldResourceId) {
          rel.resourceId = newResourceId;
        }
      });
    }
  }
  
  // Upsert updated chunks
  await this.qdrantService.upsertPoints(tenantId, referencingChunks);
}
```

### 6. Configuration for Merge Behavior

```yaml
rag:
  merge:
    enabled: true
    strategies:
      patient_merge:
        demographics: 'most_recent'  # or 'most_complete'
        contact: 'combine_all'
        identifiers: 'preserve_all'
        clinical: 'combine_all'
      
      conflict_resolution: 'manual'  # or 'automatic', 'timestamp_wins'
      
      cross_reference_update:
        enabled: true
        cascade_depth: 2  # How many relationship levels to update
        
      audit_trail:
        preserve_source_data: true
        track_merge_operations: true
```

### 7. Current Workarounds

Until true merge is implemented, here's how updates behave:

#### ✅ Working Scenarios:
- **Resource Updates**: Patient contact info changes → Complete replacement (expected)
- **Tenant Isolation**: Same resource ID in different tenants → No conflicts
- **Deterministic IDs**: Prevents accidental duplicates

#### ⚠️ Limitation Scenarios:
- **Duplicate Patients**: Must be handled by backend before sending to RAG
- **Partial Updates**: Full resource replacement even for small changes
- **Cross-References**: Manual cleanup required if resources are merged

## Summary

**Current Merge Behavior**: Complete replacement via Qdrant upsert
- ✅ Reliable and consistent
- ✅ Prevents duplicates  
- ❌ No intelligent data merging
- ❌ No cross-reference updates

**Recommendation**: Implement true MERGE event handling for production scenarios where patient record consolidation is required.

**Priority**: Medium (current replacement strategy works for most update scenarios)