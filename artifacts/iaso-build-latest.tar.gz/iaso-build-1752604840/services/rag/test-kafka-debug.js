const { Kafka } = require('kafkajs');

async function testKafka() {
  console.log('🔍 Testing Kafka connection...');
  
  const kafka = new Kafka({
    clientId: 'test-client',
    brokers: ['localhost:9092'],
    retry: {
      initialRetryTime: 100,
      retries: 5
    },
    connectionTimeout: 10000,
    requestTimeout: 30000,
  });

  const admin = kafka.admin();

  try {
    console.log('📡 Connecting to Kafka admin...');
    await admin.connect();
    console.log('✅ Connected to Kafka!');

    console.log('📋 Listing topics...');
    const topics = await admin.listTopics();
    console.log('Topics:', topics);

    console.log('🔍 Getting cluster info...');
    const cluster = await admin.describeCluster();
    console.log('Cluster:', cluster);

    await admin.disconnect();
  } catch (error) {
    console.error('❌ Error:', error);
  }
}

testKafka();