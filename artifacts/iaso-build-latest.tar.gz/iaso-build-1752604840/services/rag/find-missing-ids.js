const axios = require('axios');

async function findMissingResourceIds() {
  console.log('🔍 Analyzing Missing Resource IDs\n');
  
  try {
    // Get all data
    const allData = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 2000,
      with_payload: true,
      with_vector: false
    });

    const points = allData.data.result.points;
    console.log(`📋 Analyzing ${points.length} chunks for missing resource IDs...\n`);

    // Find chunks with missing or undefined resource IDs
    const missingResourceIds = points.filter(point => {
      const payload = point.payload;
      return !payload.resource_id || 
             payload.resource_id === 'undefined' || 
             payload.resource_id === '' ||
             payload.resource_id === null;
    });

    console.log(`🚨 Found ${missingResourceIds.length} chunks with missing resource IDs\n`);

    if (missingResourceIds.length === 0) {
      console.log('✅ All chunks have valid resource IDs!');
      return;
    }

    // Group by resource type
    const missingByType = {};
    const missingByChunkType = {};
    
    missingResourceIds.forEach(point => {
      const resourceType = point.payload.resource_type;
      const chunkType = point.payload.chunk_type;
      
      missingByType[resourceType] = (missingByType[resourceType] || 0) + 1;
      missingByChunkType[chunkType] = (missingByChunkType[chunkType] || 0) + 1;
    });

    console.log('📊 Missing Resource IDs by Resource Type:');
    Object.entries(missingByType)
      .sort(([,a], [,b]) => b - a)
      .forEach(([type, count]) => {
        const percentage = ((count / missingResourceIds.length) * 100).toFixed(1);
        console.log(`   ${type}: ${count} chunks (${percentage}%)`);
      });

    console.log('\n📊 Missing Resource IDs by Chunk Type:');
    Object.entries(missingByChunkType)
      .sort(([,a], [,b]) => b - a)
      .forEach(([type, count]) => {
        const percentage = ((count / missingResourceIds.length) * 100).toFixed(1);
        console.log(`   ${type}: ${count} chunks (${percentage}%)`);
      });

    // Show sample problematic chunks
    console.log('\n🔬 Sample Problematic Chunks:');
    missingResourceIds.slice(0, 10).forEach((point, index) => {
      const payload = point.payload;
      console.log(`\n${index + 1}. Resource Type: ${payload.resource_type}`);
      console.log(`   Chunk Type: ${payload.chunk_type}`);
      console.log(`   Resource ID: "${payload.resource_id}"`);
      console.log(`   Patient ID: "${payload.patient_id}"`);
      console.log(`   Content: ${payload.content.substring(0, 100)}...`);
      console.log(`   Timestamp: ${payload.timestamp}`);
    });

    // Check if these chunks have other identifying information
    console.log('\n🔍 Analysis of Missing ID Chunks:');
    
    const hasPatientId = missingResourceIds.filter(p => p.payload.patient_id && p.payload.patient_id !== 'undefined').length;
    const hasTenantId = missingResourceIds.filter(p => p.payload.tenant_id && p.payload.tenant_id !== 'undefined').length;
    const hasSearchableTerms = missingResourceIds.filter(p => p.payload.searchable_terms && p.payload.searchable_terms.length > 0).length;
    
    console.log(`   Chunks with Patient ID: ${hasPatientId}/${missingResourceIds.length} (${((hasPatientId/missingResourceIds.length)*100).toFixed(1)}%)`);
    console.log(`   Chunks with Tenant ID: ${hasTenantId}/${missingResourceIds.length} (${((hasTenantId/missingResourceIds.length)*100).toFixed(1)}%)`);
    console.log(`   Chunks with Searchable Terms: ${hasSearchableTerms}/${missingResourceIds.length} (${((hasSearchableTerms/missingResourceIds.length)*100).toFixed(1)}%)`);

    // Check recent vs older chunks
    const now = new Date();
    const recentMissing = missingResourceIds.filter(p => {
      if (!p.payload.timestamp) return false;
      const chunkTime = new Date(p.payload.timestamp);
      const ageHours = (now - chunkTime) / (1000 * 60 * 60);
      return ageHours < 1; // Last hour
    });

    const olderMissing = missingResourceIds.filter(p => {
      if (!p.payload.timestamp) return true;
      const chunkTime = new Date(p.payload.timestamp);
      const ageHours = (now - chunkTime) / (1000 * 60 * 60);
      return ageHours >= 1;
    });

    console.log(`\n⏰ Temporal Analysis:`);
    console.log(`   Recent chunks (< 1h): ${recentMissing.length}`);
    console.log(`   Older chunks (≥ 1h): ${olderMissing.length}`);

    // Check if this is a specific resource processing issue
    console.log('\n🛠️  Potential Root Causes:');
    
    const topMissingType = Object.entries(missingByType)[0];
    if (topMissingType) {
      console.log(`   1. Resource extraction issue in ${topMissingType[0]} processing`);
    }
    
    if (recentMissing.length > olderMissing.length) {
      console.log(`   2. Recent processing change may have introduced the issue`);
    }
    
    const hasUndefinedString = missingResourceIds.filter(p => p.payload.resource_id === 'undefined').length;
    if (hasUndefinedString > 0) {
      console.log(`   3. JavaScript undefined being converted to string "undefined" (${hasUndefinedString} cases)`);
    }

  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

findMissingResourceIds()
  .then(() => console.log('\n🎉 Analysis Complete!'))
  .catch(error => console.error('❌ Analysis failed:', error.message));