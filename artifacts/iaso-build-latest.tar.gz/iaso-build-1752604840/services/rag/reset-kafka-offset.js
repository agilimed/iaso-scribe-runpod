const { Kafka } = require('kafkajs');

async function resetConsumerGroup() {
  const kafka = new Kafka({
    clientId: 'admin-client',
    brokers: ['localhost:9092']
  });

  const admin = kafka.admin();

  try {
    await admin.connect();
    console.log('Connected to Kafka admin');

    // Reset the consumer group offset to earliest
    await admin.resetOffsets({
      groupId: 'fhir-rag-processor',
      topic: 'fhir.events',
      earliest: true
    });

    console.log('✅ Reset consumer group offset to earliest');
    
    // List topic offsets
    const offsets = await admin.fetchOffsets({
      groupId: 'fhir-rag-processor',
      topics: ['fhir.events']
    });
    
    console.log('Current offsets:', JSON.stringify(offsets, null, 2));

    await admin.disconnect();
  } catch (error) {
    console.error('Error:', error);
  }
}

resetConsumerGroup();