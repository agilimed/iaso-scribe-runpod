const axios = require('axios');

async function analyzeChunkContent() {
  console.log('🔍 Analyzing Chunk Content and Searchable Terms\n');
  
  try {
    // Get samples of each chunk type to understand the content structure
    const chunkTypes = ['demographics', 'contact', 'clinical', 'temporal', 'administrative'];
    
    for (const chunkType of chunkTypes) {
      console.log(`\n📊 Analyzing ${chunkType.toUpperCase()} chunks:`);
      console.log('=' .repeat(50));
      
      // Get samples of this chunk type
      const allData = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
        limit: 1100,
        with_payload: true,
        with_vector: false
      });
      
      const chunks = allData.data.result.points.filter(p => p.payload.chunk_type === chunkType);
      
      if (chunks.length === 0) {
        console.log(`❌ No ${chunkType} chunks found!`);
        continue;
      }
      
      console.log(`Found ${chunks.length} ${chunkType} chunks`);
      
      // Analyze first 3 samples
      console.log('\n📝 Sample Content:');
      chunks.slice(0, 3).forEach((chunk, index) => {
        console.log(`\n${index + 1}. Resource: ${chunk.payload.resource_type}/${chunk.payload.resource_id}`);
        console.log(`   Content: "${chunk.payload.content.substring(0, 150)}..."`);
        console.log(`   Searchable Terms: [${(chunk.payload.searchable_terms || []).slice(0, 8).join(', ')}]`);
      });
      
      // Analyze searchable terms distribution
      const allTerms = chunks.flatMap(c => c.payload.searchable_terms || []);
      const termFrequency = allTerms.reduce((acc, term) => {
        acc[term] = (acc[term] || 0) + 1;
        return acc;
      }, {});
      
      const topTerms = Object.entries(termFrequency)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 10);
      
      console.log(`\n🏷️  Top Searchable Terms:`);
      topTerms.forEach(([term, count]) => {
        console.log(`   "${term}": ${count} occurrences`);
      });
    }
    
    // Test what users actually search for vs what we have
    console.log('\n\n🎯 USER QUERY vs CHUNK ANALYSIS');
    console.log('=' .repeat(60));
    
    const testMappings = [
      {
        userQuery: "show me patient demographics",
        expectedChunkType: "demographics",
        expectedTerms: ["demographics", "patient", "age", "gender", "birth", "demographic"]
      },
      {
        userQuery: "patient contact information",
        expectedChunkType: "contact",
        expectedTerms: ["contact", "phone", "email", "address", "telephone"]
      },
      {
        userQuery: "medication dosage and instructions",
        expectedChunkType: "clinical",
        expectedTerms: ["medication", "dosage", "clinical", "prescription", "treatment"]
      },
      {
        userQuery: "appointment scheduling information",
        expectedChunkType: "temporal",
        expectedTerms: ["appointment", "schedule", "date", "time", "temporal"]
      },
      {
        userQuery: "healthcare provider information",
        expectedChunkType: "administrative",
        expectedTerms: ["provider", "practitioner", "doctor", "administrative", "healthcare"]
      }
    ];
    
    for (const mapping of testMappings) {
      console.log(`\n🔍 Query: "${mapping.userQuery}"`);
      console.log(`Expected chunk type: ${mapping.expectedChunkType}`);
      console.log(`Expected terms: [${mapping.expectedTerms.join(', ')}]`);
      
      // Check if our chunks contain these expected terms
      const relevantChunks = allData.data.result.points.filter(p => 
        p.payload.chunk_type === mapping.expectedChunkType
      );
      
      if (relevantChunks.length > 0) {
        const sampleChunk = relevantChunks[0];
        const chunkTerms = sampleChunk.payload.searchable_terms || [];
        const contentTerms = sampleChunk.payload.content.toLowerCase();
        
        const matchingTerms = mapping.expectedTerms.filter(term => 
          chunkTerms.some(ct => ct.toLowerCase().includes(term.toLowerCase())) ||
          contentTerms.includes(term.toLowerCase())
        );
        
        console.log(`✅ Chunk terms: [${chunkTerms.slice(0, 6).join(', ')}]`);
        console.log(`🎯 Matching: [${matchingTerms.join(', ')}] (${matchingTerms.length}/${mapping.expectedTerms.length})`);
        
        if (matchingTerms.length === 0) {
          console.log(`❌ NO OVERLAP! This explains why queries fail.`);
        }
      } else {
        console.log(`❌ No chunks of type ${mapping.expectedChunkType} found!`);
      }
    }
    
    // Recommend fixes
    console.log('\n\n💡 RECOMMENDED FIXES');
    console.log('=' .repeat(40));
    
    console.log('1. DEMOGRAPHICS chunks should include terms:');
    console.log('   ["demographics", "patient demographics", "age", "birth date", "gender", "personal info"]');
    
    console.log('\n2. CONTACT chunks should include terms:');
    console.log('   ["contact", "contact information", "phone", "telephone", "email", "address", "contact details"]');
    
    console.log('\n3. CLINICAL chunks should include terms:');
    console.log('   ["clinical", "medical", "diagnosis", "treatment", "medication", "dosage", "clinical details"]');
    
    console.log('\n4. TEMPORAL chunks should include terms:');
    console.log('   ["temporal", "date", "time", "schedule", "appointment", "timeline", "when"]');
    
    console.log('\n5. ADMINISTRATIVE chunks should include terms:');
    console.log('   ["administrative", "provider", "practitioner", "doctor", "healthcare provider", "staff"]');
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

analyzeChunkContent()
  .then(() => console.log('\n🎉 Analysis Complete!'))
  .catch(error => console.error('❌ Analysis failed:', error.message));