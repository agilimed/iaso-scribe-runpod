const axios = require('axios');

async function testEnhancedFeatures() {
  console.log('🚀 Testing Enhanced Cross-Resource Linking & Semantic Terms\n');
  console.log('=' .repeat(80));
  
  // Test enhanced semantic terms
  const enhancedSemanticTests = [
    { query: "recent lab results", expectedTerms: ["recent", "latest", "last"], expectedChunks: ["temporal", "clinical"] },
    { query: "patients with multiple conditions", expectedTerms: ["multiple conditions", "comorbidities"], expectedChunks: ["clinical", "relationship"] },
    { query: "outstanding bills", expectedTerms: ["outstanding", "unpaid", "due"], expectedChunks: ["financial"] },
    { query: "last visit", expectedTerms: ["last visit", "recent visit"], expectedChunks: ["temporal", "relationship"] },
    { query: "procedures performed last month", expectedTerms: ["procedures performed", "last month"], expectedChunks: ["relationship", "temporal"] }
  ];

  // Test cross-resource linking
  const crossResourceTests = [
    { query: "lab results and related encounters", expectedChunks: ["relationship", "clinical"] },
    { query: "medications prescribed during visit", expectedChunks: ["relationship", "clinical"] },
    { query: "care coordination for patient", expectedChunks: ["relationship", "clinical"] },
    { query: "healthcare team involved in treatment", expectedChunks: ["relationship", "administrative"] },
    { query: "comprehensive care timeline", expectedChunks: ["relationship", "temporal"] }
  ];

  console.log('🎯 ENHANCED SEMANTIC TERMS TESTS:');
  console.log('-' .repeat(50));
  
  for (const test of enhancedSemanticTests) {
    console.log(`\n📋 Query: "${test.query}"`);
    
    try {
      const embedding = await generateQueryEmbedding(test.query);
      const results = await searchQdrant(embedding, 5);
      
      const foundChunkTypes = [...new Set(results.map(r => r.payload.chunk_type))];
      const topResult = results[0];
      
      console.log(`   Top result: ${topResult.payload.chunk_type} (score: ${topResult.score.toFixed(3)})`);
      console.log(`   Found chunks: [${foundChunkTypes.join(', ')}]`);
      
      // Check if expected semantic terms are in searchable terms
      const allSearchableTerms = results.flatMap(r => r.payload.searchable_terms || []);
      const foundExpectedTerms = test.expectedTerms.filter(term =>
        allSearchableTerms.some(st => st.toLowerCase().includes(term.toLowerCase()))
      );
      
      console.log(`   Expected semantic terms: [${test.expectedTerms.join(', ')}]`);
      console.log(`   Found semantic terms: [${foundExpectedTerms.join(', ')}]`);
      
      const semanticSuccess = foundExpectedTerms.length > 0;
      console.log(`   Semantic enhancement: ${semanticSuccess ? '✅ Working' : '❌ Missing'}`);
      
    } catch (error) {
      console.log(`   ❌ Error: ${error.message}`);
    }
  }

  console.log('\n\n🔗 CROSS-RESOURCE LINKING TESTS:');
  console.log('-' .repeat(50));
  
  for (const test of crossResourceTests) {
    console.log(`\n📋 Query: "${test.query}"`);
    
    try {
      const embedding = await generateQueryEmbedding(test.query);
      const results = await searchQdrant(embedding, 5);
      
      const foundChunkTypes = [...new Set(results.map(r => r.payload.chunk_type))];
      const relationshipChunks = results.filter(r => r.payload.chunk_type === 'relationship');
      const topResult = results[0];
      
      console.log(`   Top result: ${topResult.payload.chunk_type} (score: ${topResult.score.toFixed(3)})`);
      console.log(`   Found chunks: [${foundChunkTypes.join(', ')}]`);
      console.log(`   Relationship chunks: ${relationshipChunks.length}`);
      
      if (relationshipChunks.length > 0) {
        const sample = relationshipChunks[0];
        console.log(`   Sample relationship content: "${sample.payload.content.substring(0, 150)}..."`);
        
        // Check for relationship metadata
        if (sample.payload.relationships) {
          console.log(`   Related resources: ${sample.payload.relationships.relatedResources?.length || 0}`);
        }
      }
      
      const linkingSuccess = relationshipChunks.length > 0;
      console.log(`   Cross-resource linking: ${linkingSuccess ? '✅ Working' : '❌ No relationship chunks'}`);
      
    } catch (error) {
      console.log(`   ❌ Error: ${error.message}`);
    }
  }

  // Check overall chunk distribution with new relationship chunks
  console.log('\n\n📊 CHUNK DISTRIBUTION WITH ENHANCEMENTS:');
  console.log('-' .repeat(50));
  
  try {
    const allChunks = await axios.post('http://localhost:6333/collections/fhir_chunks/points/scroll', {
      limit: 3000,
      with_payload: ['chunk_type', 'resource_type']
    });
    
    const chunks = allChunks.data.result.points;
    const chunkTypes = {};
    
    chunks.forEach(chunk => {
      const type = chunk.payload.chunk_type;
      chunkTypes[type] = (chunkTypes[type] || 0) + 1;
    });
    
    console.log('Chunk type distribution:');
    Object.entries(chunkTypes)
      .sort(([,a], [,b]) => b - a)
      .forEach(([type, count]) => {
        const percentage = ((count / chunks.length) * 100).toFixed(1);
        console.log(`   ${type}: ${count} (${percentage}%)`);
      });
      
    const relationshipCount = chunkTypes['relationship'] || 0;
    console.log(`\n🔗 Relationship chunks created: ${relationshipCount}`);
    
    if (relationshipCount > 0) {
      console.log('✅ Cross-resource linking is active!');
    } else {
      console.log('⚠️ No relationship chunks found - may need more complex resource data');
    }
    
  } catch (error) {
    console.log(`❌ Error checking distribution: ${error.message}`);
  }
}

async function generateQueryEmbedding(query) {
  const response = await axios.post('http://localhost:8050/embeddings', {
    texts: [query],
    model: 'bge-m3'
  });
  return response.data.embeddings[0];
}

async function searchQdrant(vector, limit = 5) {
  const response = await axios.post('http://localhost:6333/collections/fhir_chunks/points/search', {
    vector: vector,
    limit: limit,
    with_payload: true,
    score_threshold: 0.3
  });
  return response.data.result;
}

testEnhancedFeatures()
  .then(() => console.log('\n🎉 Enhanced Features Test Complete!'))
  .catch(error => console.error('❌ Test failed:', error.message));