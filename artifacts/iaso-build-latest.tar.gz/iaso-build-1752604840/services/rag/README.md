# RAG Processor Service

The RAG (Retrieval-Augmented Generation) Processor Service handles semantic search and knowledge extraction from FHIR resources in the NexusCare platform.

## Architecture

```
FHIR Resources → Kafka Events → RAG Processor → Qdrant Vector DB
                                       ↓
                              Embeddings Service
```

## Components

### RAGProcessorService
- Main service that orchestrates the RAG pipeline
- Listens to Kafka events for FHIR resource changes
- Generates semantic chunks from resources
- Creates embeddings and stores in Qdrant

### ResourceTemplateService
- Generates meaningful chunks from FHIR resources
- Supports: Patient, Condition, Observation, Medication, Procedure
- Extracts metadata and clinical context

### Embeddings Service
- Separate gRPC service for generating embeddings
- Uses OpenAI's text-embedding-3-small model
- Runs on port 50051

### Qdrant Integration
- Vector database for similarity search
- Stores embeddings with metadata
- Supports filtering by tenant, resource type, etc.

## Local Development

### Quick Start

1. **Start RAG services:**
   ```bash
   ./scripts/development/start-rag-services.sh
   ```

2. **Start backend with RAG enabled:**
   ```bash
   ./scripts/development/start-backend-with-rag.sh
   ```

3. **Test the integration:**
   ```bash
   cd scripts/test/rag
   ts-node test-rag-local-integration.ts
   ```

### Manual Setup

1. **Start Qdrant:**
   ```bash
   docker run -d -p 6333:6333 -p 6334:6334 qdrant/qdrant:latest
   ```

2. **Start Embeddings Service:**
   ```bash
   cd ai/embeddings-service
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   python embeddings_server_simplified.py
   ```

3. **Configure Backend:**
   Add to `backend/.env`:
   ```env
   ENABLE_RAG_PROCESSOR=true
   QDRANT_URL=http://localhost:6333
   EMBEDDINGS_SERVICE_URL=localhost:50051
   ```

4. **Start Backend:**
   ```bash
   cd backend
   npm run dev
   ```

## API Endpoints

### Query Endpoint
```http
POST /api/rag/query
Content-Type: application/json
X-Tenant-ID: tenant-id

{
  "query": "patients with diabetes",
  "tenantId": "tenant-id",
  "resourceTypes": ["Patient", "Condition"],
  "limit": 10
}
```

### Health Check
```http
GET /api/rag/health
```

### Processor Stats
```http
GET /api/rag/processor/stats
Authorization: Bearer <token>
```

## Processing Flow

1. **FHIR Resource Created/Updated**
   - Resource saved to PostgreSQL
   - Event published to Kafka topic `fhir.events`

2. **RAG Processor Receives Event**
   - Extracts resource from event
   - Generates chunks based on resource type

3. **Chunk Processing**
   - Creates embeddings via gRPC service
   - Stores vectors in Qdrant with metadata

4. **Query Processing**
   - Converts query to embedding
   - Searches Qdrant for similar vectors
   - Returns relevant resources

## Configuration

### Environment Variables

- `ENABLE_RAG_PROCESSOR`: Enable RAG processor (default: false)
- `QDRANT_URL`: Qdrant HTTP endpoint (default: http://localhost:6333)
- `EMBEDDINGS_SERVICE_URL`: Embeddings gRPC endpoint (default: localhost:50051)
- `KAFKA_BROKERS`: Kafka broker list (default: localhost:9092)
- `RAG_GRPC_PORT`: gRPC port for RAG processor (default: 50052)

### Qdrant Collection

- Collection Name: `fhir_resources`
- Vector Dimension: 1536 (OpenAI embedding size)
- Distance Metric: Cosine

## Monitoring

### Logs
The RAG processor logs:
- Processing statistics every 5 minutes
- Individual event processing times
- Errors and warnings

### Metrics
Available via `/api/rag/processor/stats`:
- Events processed/failed
- Uptime
- Qdrant vector count
- Kafka consumer status

## Troubleshooting

### Common Issues

**No results from queries:**
- Wait 5-10 seconds after creating resources
- Check Kafka connectivity
- Verify embeddings service is running
- Check Qdrant dashboard at http://localhost:6333

**Embeddings service not healthy:**
- Ensure Python dependencies are installed
- Check port 50051 is not in use
- Verify OpenAI API key is set (if using OpenAI)

**Kafka connection issues:**
- Verify Kafka is running on port 9092
- Check Docker network connectivity
- Ensure topic `fhir.events` exists

## Development Tips

1. **Testing Locally:**
   - Use the test script to verify integration
   - Check Qdrant UI for stored vectors
   - Monitor backend logs for processing

2. **Debugging:**
   - Enable debug logging: `LOG_LEVEL=debug`
   - Check individual service health endpoints
   - Use Qdrant dashboard for vector inspection

3. **Performance:**
   - Batch size for embeddings: 10 chunks
   - Processing timeout: 30 seconds per event
   - Retry failed events after 5 minutes

## Future Enhancements

- Support for more FHIR resource types
- Custom embedding models
- Advanced chunking strategies
- Hybrid search (vector + keyword)
- Real-time index updates
- Multi-language support