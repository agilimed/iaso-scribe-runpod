const { Kafka } = require('kafkajs');

async function checkConsumerGroup() {
  const kafka = new Kafka({
    clientId: 'admin-check',
    brokers: ['localhost:9092']
  });

  const admin = kafka.admin();

  try {
    await admin.connect();
    
    // List consumer groups
    const groups = await admin.listGroups();
    console.log('Consumer groups:', groups.groups.map(g => g.groupId));
    
    // Describe the fhir-rag-processor group
    const groupDescriptions = await admin.describeGroups(['fhir-rag-processor']);
    console.log('\nGroup Description:', JSON.stringify(groupDescriptions.groups[0], null, 2));
    
    // Check consumer group offsets
    const offsets = await admin.fetchOffsets({
      groupId: 'fhir-rag-processor',
      topics: ['fhir.events']
    });
    console.log('\nConsumer Group Offsets:', JSON.stringify(offsets, null, 2));
    
    // Get topic end offsets
    const topicOffsets = await admin.fetchTopicOffsets('fhir.events');
    console.log('\nTopic End Offsets:', JSON.stringify(topicOffsets, null, 2));
    
    // Calculate lag
    console.log('\nLag Analysis:');
    topicOffsets.forEach(to => {
      const consumerOffset = offsets[0].partitions.find(p => p.partition === to.partition);
      if (consumerOffset) {
        const lag = parseInt(to.high) - parseInt(consumerOffset.offset);
        console.log(`Partition ${to.partition}: Consumer at ${consumerOffset.offset}, Topic at ${to.high}, Lag: ${lag}`);
      }
    });
    
    await admin.disconnect();
  } catch (error) {
    console.error('Error:', error);
  }
}

checkConsumerGroup();