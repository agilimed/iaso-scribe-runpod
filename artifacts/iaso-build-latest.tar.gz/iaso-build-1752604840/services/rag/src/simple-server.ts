import * as dotenv from 'dotenv';
dotenv.config(); // Load environment variables

import { KafkaConsumerService } from './services/KafkaConsumerService';
import { QdrantService } from './services/QdrantService';
import { FHIRRAGProcessor } from './rag-processor';
import { logger } from './utils/logger';
import { config } from './config';

async function startSimpleServer() {
  try {
    logger.info('Starting simple FHIR RAG processor...');

    // Initialize Qdrant service
    const qdrantService = new QdrantService(config.qdrant);
    await qdrantService.initialize();
    logger.info('Qdrant service initialized');

    // Initialize FHIR RAG processor with embeddings configuration
    const processor = new FHIRRAGProcessor(qdrantService, {
      host: 'localhost',
      port: 8050
    });

    // Initialize Kafka consumer with RAG processor
    const kafkaConsumer = new KafkaConsumerService(processor as any, config.kafka);
    await kafkaConsumer.start();
    logger.info('Kafka consumer started, listening for FHIR events...');

    // Graceful shutdown
    process.on('SIGTERM', async () => {
      logger.info('SIGTERM received, shutting down gracefully');
      await kafkaConsumer.stop();
      await qdrantService.close();
      process.exit(0);
    });

    process.on('SIGINT', async () => {
      logger.info('SIGINT received, shutting down gracefully');
      await kafkaConsumer.stop();
      await qdrantService.close();
      process.exit(0);
    });

  } catch (error) {
    logger.error('Failed to start simple server:', error);
    process.exit(1);
  }
}

startSimpleServer().catch((error) => {
  logger.error('Unhandled error:', error);
  process.exit(1);
});