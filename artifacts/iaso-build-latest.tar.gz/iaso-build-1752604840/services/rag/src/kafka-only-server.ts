import * as dotenv from 'dotenv';
dotenv.config(); // Load environment variables

import { Kafka } from 'kafkajs';
import { logger } from './utils/logger';

async function startKafkaOnlyServer() {
  try {
    logger.info('Starting Kafka-only FHIR processor (no Qdrant)...');

    // Create Kafka consumer directly
    const kafka = new Kafka({
      clientId: 'fhir-rag-processor-test',
      brokers: ['localhost:9092'],
      connectionTimeout: 3000,
      requestTimeout: 25000,
      retry: {
        initialRetryTime: 300,
        retries: 3
      }
    });

    const consumer = kafka.consumer({ 
      groupId: 'fhir-rag-processor-test',
      sessionTimeout: 30000,
      rebalanceTimeout: 60000
    });

    logger.info('Connecting to Kafka...');
    await consumer.connect();
    logger.info('Connected to Kafka successfully');

    logger.info('Subscribing to fhir.events topic...');
    await consumer.subscribe({ topic: 'fhir.events', fromBeginning: false });
    logger.info('Subscribed to fhir.events topic');

    await consumer.run({
      eachMessage: async ({ topic, partition, message, heartbeat }) => {
        logger.info('Received FHIR event:', {
          topic,
          partition,
          offset: message.offset,
          key: message.key?.toString(),
          value: message.value?.toString().substring(0, 200) + '...',
          timestamp: message.timestamp
        });

        // Just log for now - no Qdrant processing
        await heartbeat();
      }
    });

    logger.info('Kafka consumer is running, waiting for messages...');

    // Graceful shutdown
    process.on('SIGTERM', async () => {
      logger.info('SIGTERM received, shutting down gracefully');
      await consumer.disconnect();
      process.exit(0);
    });

    process.on('SIGINT', async () => {
      logger.info('SIGINT received, shutting down gracefully');
      await consumer.disconnect();
      process.exit(0);
    });

  } catch (error) {
    logger.error('Failed to start Kafka-only server:', error);
    process.exit(1);
  }
}

startKafkaOnlyServer().catch((error) => {
  logger.error('Unhandled error:', error);
  process.exit(1);
});