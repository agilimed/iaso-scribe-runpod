import * as grpc from '@grpc/grpc-js';
import * as protoLoader from '@grpc/proto-loader';
import path from 'path';
import { logger } from '../utils/logger';

const PROTO_PATH = path.join(__dirname, '../../../../protos/rag.proto');

export class EmbeddingClient {
  private client: any;
  private connected: boolean = false;

  constructor(private host: string, private port: number) {
    this.initializeClient();
  }

  private initializeClient() {
    try {
      const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
        keepCase: true,
        longs: String,
        enums: String,
        defaults: true,
        oneofs: true,
      });

      const ragProto = grpc.loadPackageDefinition(packageDefinition) as any;
      
      this.client = new ragProto.nexuscare.rag.EmbeddingService(
        `${this.host}:${this.port}`,
        grpc.credentials.createInsecure(),
        {
          'grpc.max_receive_message_length': 50 * 1024 * 1024,
          'grpc.max_send_message_length': 50 * 1024 * 1024,
          'grpc.keepalive_time_ms': 30000,
          'grpc.keepalive_timeout_ms': 10000,
        }
      );

      this.connected = true;
      logger.info(`Connected to embedding service at ${this.host}:${this.port}`);
    } catch (error) {
      logger.error(`Failed to initialize embedding client: ${error}`);
      throw error;
    }
  }

  async generateEmbedding(text: string, model?: string): Promise<number[]> {
    return new Promise((resolve, reject) => {
      const request = {
        text,
        model: model || 'bge-m3',
        options: {}
      };

      this.client.GenerateEmbedding(request, (error: any, response: any) => {
        if (error) {
          logger.error(`Embedding generation failed: ${error.message}`);
          reject(error);
        } else {
          resolve(response.embedding);
        }
      });
    });
  }

  async generateBatchEmbeddings(texts: string[], model?: string): Promise<number[][]> {
    return new Promise((resolve, reject) => {
      const request = {
        texts,
        model: model || 'bge-m3',
        options: {}
      };

      this.client.GenerateEmbeddings(request, (error: any, response: any) => {
        if (error) {
          logger.error(`Batch embedding generation failed: ${error.message}`);
          reject(error);
        } else {
          const embeddings = response.embeddings.map((e: any) => e.values);
          resolve(embeddings);
        }
      });
    });
  }

  async getModelInfo(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.client.GetModelInfo({}, (error: any, response: any) => {
        if (error) {
          logger.error(`Failed to get model info: ${error.message}`);
          reject(error);
        } else {
          resolve(response);
        }
      });
    });
  }

  async healthCheck(): Promise<boolean> {
    return new Promise((resolve) => {
      this.client.HealthCheck({}, { deadline: Date.now() + 5000 }, (error: any, response: any) => {
        if (error) {
          logger.warn(`Embedding service health check failed: ${error.message}`);
          resolve(false);
        } else {
          resolve(response.healthy);
        }
      });
    });
  }

  close() {
    if (this.client) {
      grpc.closeClient(this.client);
      this.connected = false;
      logger.info('Embedding client connection closed');
    }
  }
}