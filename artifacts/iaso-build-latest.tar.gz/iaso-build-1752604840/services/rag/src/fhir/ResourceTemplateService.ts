import { v4 as uuidv4 } from 'uuid';
import { logger } from '../utils/logger';

// Types from the TODO specification
export interface ResourceTemplate {
  resourceType: string;
  priority: 'critical' | 'high' | 'medium' | 'low';
  chunkTypes: ChunkType[];
  generateChunks: (resource: any) => ResourceChunk[];
  extractMetadata: (resource: any) => ChunkMetadata;
  clinicalSignificance: (resource: any) => 'critical' | 'abnormal' | 'normal';
}

export interface ResourceChunk {
  id: string;
  content: string;
  type: 'granular_fact' | 'resource_summary' | 'ips_summary';
  clinical_significance: 'critical' | 'abnormal' | 'normal';
  searchable_terms: string[];
  temporal_context: {
    date: string;
    encounter_id?: string;
    episode_id?: string;
  };
  clinical_codes: {
    loinc?: string[];
    icd10?: string[];
    rxnorm?: string[];
    snomed?: string[];
  };
}

export interface ChunkMetadata {
  patient_id: string;
  resource_type: string;
  resource_id: string;
  tenant_id: string;
  clinical_domain: 'labs' | 'medications' | 'procedures' | 'conditions' | 'admin';
  clinical_significance: 'critical' | 'abnormal' | 'normal';
  temporal_context: {
    date: string;
    encounter_id?: string;
    episode_id?: string;
  };
  chunk_type: 'granular_fact' | 'resource_summary' | 'ips_summary';
  chunk_level: 'observation' | 'encounter' | 'patient';
  searchable_codes: string[];
  searchable_values: number[];
  searchable_units: string[];
  reference_ranges?: {
    low?: number;
    high?: number;
    unit?: string;
    interpretation?: string;
  };
}

export type ChunkType = 'granular_fact' | 'resource_summary' | 'ips_summary';
export type ClinicalDomain = 'labs' | 'medications' | 'procedures' | 'conditions' | 'admin';
export type ClinicalSignificance = 'critical' | 'abnormal' | 'normal';

// Base template class
export abstract class BaseResourceTemplate implements ResourceTemplate {
  abstract resourceType: string;
  abstract priority: 'critical' | 'high' | 'medium' | 'low';
  abstract chunkTypes: ChunkType[];

  abstract generateChunks(resource: any): ResourceChunk[];
  abstract extractMetadata(resource: any): ChunkMetadata;
  abstract clinicalSignificance(resource: any): ClinicalSignificance;

  // Common utility methods
  protected extractPatientId(resource: any): string {
    if (resource.resourceType === 'Patient') {
      return resource.id;
    }
    
    // Handle reference formats
    const patientRef = resource.subject?.reference || resource.patient?.reference;
    if (patientRef) {
      return patientRef.replace('Patient/', '');
    }
    
    return '';
  }

  protected extractDate(resource: any): string {
    const dateFields = [
      'effectiveDateTime',
      'onsetDateTime', 
      'recordedDate',
      'performedDateTime',
      'authoredOn',
      'date',
      'period?.start',
      'meta?.lastUpdated'
    ];
    
    for (const field of dateFields) {
      const value = this.getNestedValue(resource, field);
      if (value) {
        return new Date(value).toISOString().split('T')[0];
      }
    }
    
    return new Date().toISOString().split('T')[0];
  }

  protected extractEncounterId(resource: any): string | undefined {
    const encounterRef = resource.encounter?.reference || resource.context?.reference;
    return encounterRef?.replace('Encounter/', '');
  }

  protected extractEpisodeId(resource: any): string | undefined {
    const episodeRef = resource.episodeOfCare?.reference;
    return episodeRef?.replace('EpisodeOfCare/', '');
  }

  protected extractClinicalCodes(resource: any): ResourceChunk['clinical_codes'] {
    const codes: ResourceChunk['clinical_codes'] = {};
    
    // Extract from code field
    const codeFields = [resource.code, resource.medicationCodeableConcept];
    
    for (const codeField of codeFields) {
      if (codeField?.coding) {
        for (const coding of codeField.coding) {
          if (coding.system?.includes('loinc')) {
            codes.loinc = codes.loinc || [];
            codes.loinc.push(coding.code);
          } else if (coding.system?.includes('icd')) {
            codes.icd10 = codes.icd10 || [];
            codes.icd10.push(coding.code);
          } else if (coding.system?.includes('rxnorm')) {
            codes.rxnorm = codes.rxnorm || [];
            codes.rxnorm.push(coding.code);
          } else if (coding.system?.includes('snomed')) {
            codes.snomed = codes.snomed || [];
            codes.snomed.push(coding.code);
          }
        }
      }
    }
    
    return codes;
  }

  protected extractSearchableTerms(resource: any): string[] {
    const terms: string[] = [];
    
    // Extract display names from codings
    const extractFromCoding = (coding: any[]) => {
      if (Array.isArray(coding)) {
        coding.forEach(c => {
          if (c.display) terms.push(c.display.toLowerCase());
          if (c.code) terms.push(c.code.toLowerCase());
        });
      }
    };
    
    if (resource.code?.coding) {
      extractFromCoding(resource.code.coding);
    }
    
    // Extract text values
    if (resource.code?.text) {
      terms.push(resource.code.text.toLowerCase());
    }
    
    // Extract from value fields
    if (resource.valueString) {
      terms.push(resource.valueString.toLowerCase());
    }
    
    return [...new Set(terms)]; // Remove duplicates
  }

  protected getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => {
      if (key.includes('?')) {
        key = key.replace('?', '');
      }
      return current && current[key];
    }, obj);
  }

  protected createChunk(
    content: string,
    type: ChunkType,
    resource: any,
    clinical_significance: ClinicalSignificance = 'normal'
  ): ResourceChunk {
    return {
      id: uuidv4(),
      content,
      type,
      clinical_significance,
      searchable_terms: this.extractSearchableTerms(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      clinical_codes: this.extractClinicalCodes(resource)
    };
  }

  protected getClinicalDomain(resourceType: string): ClinicalDomain {
    const domainMap: Record<string, ClinicalDomain> = {
      'Observation': 'labs',
      'DiagnosticReport': 'labs',
      'Medication': 'medications',
      'MedicationRequest': 'medications',
      'MedicationAdministration': 'medications',
      'MedicationDispense': 'medications',
      'MedicationStatement': 'medications',
      'Procedure': 'procedures',
      'Condition': 'conditions',
      'AllergyIntolerance': 'conditions',
      'Patient': 'admin',
      'Practitioner': 'admin',
      'Organization': 'admin',
      'Location': 'admin',
      'Encounter': 'admin',
      'EpisodeOfCare': 'admin'
    };
    
    return domainMap[resourceType] || 'admin';
  }
}

// Service to manage all resource templates
export class ResourceTemplateService {
  private templates = new Map<string, ResourceTemplate>();

  constructor() {
    this.initializeTemplates();
  }

  private initializeTemplates(): void {
    // Import and register all FHIR resource templates
    const { PatientTemplate } = require('./templates/PatientTemplate');
    const { ObservationTemplate } = require('./templates/ObservationTemplate');
    const { ConditionTemplate } = require('./templates/ConditionTemplate');
    const { PractitionerTemplate } = require('./templates/PractitionerTemplate');
    const { OrganizationTemplate } = require('./templates/OrganizationTemplate');
    const { LocationTemplate } = require('./templates/LocationTemplate');
    const { EncounterTemplate } = require('./templates/EncounterTemplate');
    const { ProcedureTemplate } = require('./templates/ProcedureTemplate');
    const { MedicationRequestTemplate } = require('./templates/MedicationRequestTemplate');
    const { AllergyIntoleranceTemplate } = require('./templates/AllergyIntoleranceTemplate');
    const { AppointmentTemplate } = require('./templates/AppointmentTemplate');
    const { DiagnosticReportTemplate } = require('./templates/DiagnosticReportTemplate');
    const { ImmunizationTemplate } = require('./templates/ImmunizationTemplate');
    const { CarePlanTemplate } = require('./templates/CarePlanTemplate');
    const { GoalTemplate } = require('./templates/GoalTemplate');
    const { ServiceRequestTemplate } = require('./templates/ServiceRequestTemplate');
    const { CompositionTemplate } = require('./templates/CompositionTemplate');
    const { TaskTemplate } = require('./templates/TaskTemplate');
    const { MedicationTemplate } = require('./templates/MedicationTemplate');
    const { MedicationStatementTemplate } = require('./templates/MedicationStatementTemplate');
    const { ClinicalImpressionTemplate } = require('./templates/ClinicalImpressionTemplate');
    const { DocumentReferenceTemplate } = require('./templates/DocumentReferenceTemplate');
    const { EpisodeOfCareTemplate } = require('./templates/EpisodeOfCareTemplate');
    const { ChargeItemTemplate } = require('./templates/ChargeItemTemplate');
    const { HealthcareServiceTemplate } = require('./templates/HealthcareServiceTemplate');
    const { MedicationAdministrationTemplate } = require('./templates/MedicationAdministrationTemplate');
    const { MedicationDispenseTemplate } = require('./templates/MedicationDispenseTemplate');
    const { PractitionerRoleTemplate } = require('./templates/PractitionerRoleTemplate');
    const { QuestionnaireResponseTemplate } = require('./templates/QuestionnaireResponseTemplate');
    const { SupplyDeliveryTemplate } = require('./templates/SupplyDeliveryTemplate');
    const { SubscriptionTemplate } = require('./templates/SubscriptionTemplate');

    // Import business resource templates
    const { AccountTemplate } = require('./templates/business/AccountTemplate');
    const { InvoiceTemplate } = require('./templates/business/InvoiceTemplate');
    const { EmployeeTemplate } = require('./templates/business/EmployeeTemplate');
    const { SupplyItemTemplate } = require('./templates/business/SupplyItemTemplate');
    const { TimeEntryTemplate } = require('./templates/business/TimeEntryTemplate');
    const { IncidentTemplate } = require('./templates/business/IncidentTemplate');
    const { ConsumerExperienceTemplate } = require('./templates/business/ConsumerExperienceTemplate');
    const { CostCenterTemplate } = require('./templates/business/CostCenterTemplate');
    const { MeasureReportTemplate } = require('./templates/business/MeasureReportTemplate');
    const { QualityMeasureTemplate } = require('./templates/business/QualityMeasureTemplate');
    const { ResourceUtilizationTemplate } = require('./templates/business/ResourceUtilizationTemplate');
    const { SupplyRequestTemplate } = require('./templates/business/SupplyRequestTemplate');
    const { CoverageTemplate } = require('./templates/business/CoverageTemplate');
    const { EmployeeFHIRTemplate } = require('./templates/business/EmployeeFHIRTemplate');
    const { InvoiceFHIRTemplate } = require('./templates/business/InvoiceFHIRTemplate');
    const { TimeEntryFHIRTemplate } = require('./templates/business/TimeEntryFHIRTemplate');

    // Register all templates
    this.registerTemplate(new PatientTemplate());
    this.registerTemplate(new ObservationTemplate());
    this.registerTemplate(new ConditionTemplate());
    this.registerTemplate(new PractitionerTemplate());
    this.registerTemplate(new OrganizationTemplate());
    this.registerTemplate(new LocationTemplate());
    this.registerTemplate(new EncounterTemplate());
    this.registerTemplate(new ProcedureTemplate());
    this.registerTemplate(new MedicationRequestTemplate());
    this.registerTemplate(new AllergyIntoleranceTemplate());
    this.registerTemplate(new AppointmentTemplate());
    this.registerTemplate(new DiagnosticReportTemplate());
    this.registerTemplate(new ImmunizationTemplate());
    this.registerTemplate(new CarePlanTemplate());
    this.registerTemplate(new GoalTemplate());
    this.registerTemplate(new ServiceRequestTemplate());
    this.registerTemplate(new CompositionTemplate());
    this.registerTemplate(new TaskTemplate());
    this.registerTemplate(new MedicationTemplate());
    this.registerTemplate(new MedicationStatementTemplate());
    this.registerTemplate(new ClinicalImpressionTemplate());
    this.registerTemplate(new DocumentReferenceTemplate());
    this.registerTemplate(new EpisodeOfCareTemplate());
    this.registerTemplate(new ChargeItemTemplate());
    this.registerTemplate(new HealthcareServiceTemplate());
    this.registerTemplate(new MedicationAdministrationTemplate());
    this.registerTemplate(new MedicationDispenseTemplate());
    this.registerTemplate(new PractitionerRoleTemplate());
    this.registerTemplate(new QuestionnaireResponseTemplate());
    this.registerTemplate(new SupplyDeliveryTemplate());
    this.registerTemplate(new SubscriptionTemplate());

    // Register business templates
    this.registerTemplate(new AccountTemplate());
    this.registerTemplate(new InvoiceTemplate());
    this.registerTemplate(new EmployeeTemplate());
    this.registerTemplate(new SupplyItemTemplate());
    this.registerTemplate(new TimeEntryTemplate());
    this.registerTemplate(new IncidentTemplate());
    this.registerTemplate(new ConsumerExperienceTemplate());
    this.registerTemplate(new CostCenterTemplate());
    this.registerTemplate(new MeasureReportTemplate());
    this.registerTemplate(new QualityMeasureTemplate());
    this.registerTemplate(new ResourceUtilizationTemplate());
    this.registerTemplate(new SupplyRequestTemplate());
    this.registerTemplate(new CoverageTemplate());
    this.registerTemplate(new EmployeeFHIRTemplate());
    this.registerTemplate(new InvoiceFHIRTemplate());
    this.registerTemplate(new TimeEntryFHIRTemplate());

    logger.info(`[ResourceTemplateService] Initialized with ${this.templates.size} templates`);
  }

  registerTemplate(template: ResourceTemplate): void {
    this.templates.set(template.resourceType, template);
    logger.info(`[ResourceTemplateService] Registered template for ${template.resourceType}`);
  }

  getTemplate(resourceType: string): ResourceTemplate | undefined {
    return this.templates.get(resourceType);
  }

  getAllTemplates(): ResourceTemplate[] {
    return Array.from(this.templates.values());
  }

  getSupportedResourceTypes(): string[] {
    return Array.from(this.templates.keys());
  }

  async generateChunks(resource: any): Promise<ResourceChunk[]> {
    const template = this.getTemplate(resource.resourceType);
    if (!template) {
      logger.warn(`[ResourceTemplateService] No template found for ${resource.resourceType}`);
      return [];
    }

    try {
      const chunks = template.generateChunks(resource);
      logger.debug(`[ResourceTemplateService] Generated ${chunks.length} chunks for ${resource.resourceType}/${resource.id}`);
      return chunks;
    } catch (error) {
      logger.error(`[ResourceTemplateService] Error generating chunks for ${resource.resourceType}/${resource.id}:`, error);
      return [];
    }
  }

  async extractMetadata(resource: any): Promise<ChunkMetadata | null> {
    const template = this.getTemplate(resource.resourceType);
    if (!template) {
      return null;
    }

    try {
      return template.extractMetadata(resource);
    } catch (error) {
      logger.error(`[ResourceTemplateService] Error extracting metadata for ${resource.resourceType}/${resource.id}:`, error);
      return null;
    }
  }

  async assessClinicalSignificance(resource: any): Promise<ClinicalSignificance> {
    const template = this.getTemplate(resource.resourceType);
    if (!template) {
      return 'normal';
    }

    try {
      return template.clinicalSignificance(resource);
    } catch (error) {
      logger.error(`[ResourceTemplateService] Error assessing clinical significance for ${resource.resourceType}/${resource.id}:`, error);
      return 'normal';
    }
  }
}