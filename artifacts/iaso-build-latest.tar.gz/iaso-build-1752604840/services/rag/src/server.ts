import * as grpc from '@grpc/grpc-js';
import * as protoLoader from '@grpc/proto-loader';
import path from 'path';
import { promisify } from 'util';
import { RAGProcessorService } from './services/RAGProcessorService';
import { KafkaConsumerService } from './services/KafkaConsumerService';
import { QdrantService } from './services/QdrantService';
import { MetricsService } from './services/MetricsService';
import { logger } from './utils/logger';
import { config } from './config';

// Load proto file
const PROTO_PATH = path.join(__dirname, '../../../protos/rag.proto');
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});

const ragProto = grpc.loadPackageDefinition(packageDefinition) as any;

async function startServer() {
  try {
    // Initialize services
    const metricsService = new MetricsService();
    const qdrantService = new QdrantService(config.qdrant);
    const ragProcessor = new RAGProcessorService(qdrantService, config.embeddings);
    const kafkaConsumer = new KafkaConsumerService(ragProcessor, config.kafka);

    // Initialize Qdrant collections
    await qdrantService.initialize();

    // Start Kafka consumer
    await kafkaConsumer.start();

    // Create gRPC server
    const server = new grpc.Server({
      'grpc.max_receive_message_length': 50 * 1024 * 1024, // 50MB
      'grpc.max_send_message_length': 50 * 1024 * 1024,
      'grpc.keepalive_time_ms': 30000,
      'grpc.keepalive_timeout_ms': 10000,
    });

    // Add RAG processor service
    server.addService(ragProto.nexuscare.rag.RAGProcessorService.service, {
      ProcessFHIREvent: ragProcessor.processFHIREvent.bind(ragProcessor),
      GenerateChunks: ragProcessor.generateChunks.bind(ragProcessor),
      Query: ragProcessor.query.bind(ragProcessor),
      HealthCheck: ragProcessor.healthCheck.bind(ragProcessor),
    });

    // Start metrics server
    metricsService.startServer(config.metrics.port);

    // Start gRPC server
    const bindAsync = promisify(server.bindAsync).bind(server);
    const port = await bindAsync(
      `0.0.0.0:${config.grpc.port}`,
      grpc.ServerCredentials.createInsecure()
    );

    server.start();
    logger.info(`FHIR RAG Processor started on port ${port}`);
    logger.info(`Metrics available at http://localhost:${config.metrics.port}/metrics`);

    // Graceful shutdown
    process.on('SIGTERM', async () => {
      logger.info('SIGTERM received, shutting down gracefully');
      server.forceShutdown();
      await kafkaConsumer.stop();
      await qdrantService.close();
      process.exit(0);
    });

    process.on('SIGINT', async () => {
      logger.info('SIGINT received, shutting down gracefully');
      server.forceShutdown();
      await kafkaConsumer.stop();
      await qdrantService.close();
      process.exit(0);
    });

  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer().catch((error) => {
  logger.error('Unhandled error:', error);
  process.exit(1);
});