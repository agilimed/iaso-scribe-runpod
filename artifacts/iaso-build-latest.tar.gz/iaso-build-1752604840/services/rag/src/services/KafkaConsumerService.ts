import { Kafka, Consumer, EachMessagePayload, KafkaConfig } from 'kafkajs';
import { RAGProcessorService } from './RAGProcessorService';
import { logger } from '../utils/logger';
import { Counter, Histogram, Gauge } from 'prom-client';

// Prometheus metrics
const kafkaMessagesReceived = new Counter({
  name: 'kafka_messages_received_total',
  help: 'Total number of Kafka messages received',
  labelNames: ['topic', 'resource_type']
});

const kafkaMessagesProcessed = new Counter({
  name: 'kafka_messages_processed_total',
  help: 'Total number of Kafka messages processed successfully',
  labelNames: ['topic', 'resource_type']
});

const kafkaMessagesError = new Counter({
  name: 'kafka_messages_error_total',
  help: 'Total number of Kafka message processing errors',
  labelNames: ['topic', 'resource_type', 'error_type']
});

const kafkaMessageProcessingDuration = new Histogram({
  name: 'kafka_message_processing_duration_seconds',
  help: 'Time spent processing Kafka messages',
  labelNames: ['topic', 'resource_type'],
  buckets: [0.1, 0.5, 1, 2, 5, 10, 30]
});

const kafkaConsumerLag = new Gauge({
  name: 'kafka_consumer_lag',
  help: 'Current consumer lag for Kafka topics',
  labelNames: ['topic', 'partition']
});

interface KafkaConsumerConfig {
  brokers: string[];
  groupId: string;
  topics: string[];
  sessionTimeout: number;
  rebalanceTimeout: number;
}

export class KafkaConsumerService {
  private kafka: Kafka;
  private consumer: Consumer;
  private isRunning = false;
  private processingCount = 0;

  constructor(
    private ragProcessor: any, // Accept any processor type for now
    private config: KafkaConsumerConfig
  ) {
    // Initialize Kafka client
    const kafkaConfig: KafkaConfig = {
      clientId: 'fhir-rag-processor',
      brokers: config.brokers,
      connectionTimeout: 30000,
      requestTimeout: 30000,
      retry: {
        initialRetryTime: 100,
        retries: 8,
        maxRetryTime: 30000,
        factor: 2,
        multiplier: 1.5,
      },
    };

    this.kafka = new Kafka(kafkaConfig);
    this.consumer = this.kafka.consumer({
      groupId: config.groupId,
      sessionTimeout: config.sessionTimeout,
      rebalanceTimeout: config.rebalanceTimeout,
      heartbeatInterval: 3000,
      maxBytesPerPartition: 1048576, // 1MB
      maxWaitTimeInMs: 100,
    });
  }

  async start(): Promise<void> {
    try {
      logger.info('Starting Kafka consumer service...');

      // Connect to Kafka
      await this.consumer.connect();
      logger.info('Connected to Kafka');

      // Subscribe to topics
      await this.consumer.subscribe({
        topics: this.config.topics,
        fromBeginning: false, // Start from latest
      });
      logger.info(`Subscribed to topics: ${this.config.topics.join(', ')}`);

      // Start consuming
      this.isRunning = true;
      await this.consumer.run({
        eachMessage: this.handleMessage.bind(this),
        autoCommit: false, // Manual commit for better control
      });

      // Start lag monitoring
      this.startLagMonitoring();

      logger.info('Kafka consumer service started successfully');
    } catch (error) {
      logger.error('Failed to start Kafka consumer:', error);
      throw error;
    }
  }

  async stop(): Promise<void> {
    try {
      logger.info('Stopping Kafka consumer service...');
      this.isRunning = false;

      // Wait for in-flight messages to complete
      const maxWaitTime = 30000; // 30 seconds
      const startTime = Date.now();
      
      while (this.processingCount > 0 && Date.now() - startTime < maxWaitTime) {
        logger.info(`Waiting for ${this.processingCount} messages to complete...`);
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      // Disconnect consumer
      await this.consumer.disconnect();
      logger.info('Kafka consumer service stopped');
    } catch (error) {
      logger.error('Error stopping Kafka consumer:', error);
      throw error;
    }
  }

  private async handleMessage({ topic, partition, message }: EachMessagePayload): Promise<void> {
    const timer = kafkaMessageProcessingDuration.startTimer();
    this.processingCount++;

    try {
      // Parse message
      const event = this.parseMessage(message);
      if (!event) {
        logger.warn('Skipping invalid message');
        await this.consumer.commitOffsets([{
          topic,
          partition,
          offset: (Number(message.offset) + 1).toString(),
        }]);
        return;
      }

      // Track metrics
      kafkaMessagesReceived.inc({
        topic,
        resource_type: event.resource_type
      });

      // Skip if not a relevant resource type
      if (!this.isRelevantResourceType(event.resource_type)) {
        logger.debug(`Skipping non-relevant resource type: ${event.resource_type}`);
        await this.consumer.commitOffsets([{
          topic,
          partition,
          offset: (Number(message.offset) + 1).toString(),
        }]);
        return;
      }

      // Process through RAG pipeline
      logger.info(`Processing ${event.event_type} event for ${event.resource_type}/${event.resource_id}`);
      
      // Pass the original Kafka message to the processor
      const result = await this.processWithRetry({ ...message, parsedEvent: event });
      
      if (result.success) {
        kafkaMessagesProcessed.inc({
          topic,
          resource_type: event.resource_type
        });
        logger.info(`Successfully processed event: ${event.event_id}`);
      } else {
        throw new Error(result.message || 'Processing failed');
      }

      // Commit offset after successful processing
      await this.consumer.commitOffsets([{
        topic,
        partition,
        offset: (Number(message.offset) + 1).toString(),
      }]);

    } catch (error) {
      logger.error(`Error processing message: ${error}`);
      kafkaMessagesError.inc({
        topic,
        resource_type: 'unknown',
        error_type: (error as Error).name || 'UnknownError'
      });

      // Decide whether to retry or skip based on error type
      if (this.isRetriableError(error)) {
        // Don't commit offset - message will be retried
        throw error;
      } else {
        // Non-retriable error - commit offset to skip
        logger.warn('Skipping message due to non-retriable error');
        await this.consumer.commitOffsets([{
          topic,
          partition,
          offset: (Number(message.offset) + 1).toString(),
        }]);
      }
    } finally {
      timer({ topic, resource_type: 'unknown' });
      this.processingCount--;
    }
  }

  private parseMessage(message: any): any {
    try {
      if (!message.value) return null;
      
      const payload = JSON.parse(message.value.toString());
      
      // Log the actual message structure for debugging
      logger.debug('Raw Kafka message:', {
        keys: Object.keys(payload),
        resource_type: payload.resource_type,
        resource_id: payload.resource_id,
        event_type: payload.event_type
      });
      
      // Handle NexusCare message format
      // Based on the earlier Kafka debug, messages have: resource_id, resource_data, resource_type
      if (!payload.resource_id || !payload.resource_data) {
        logger.warn('Message missing required fields', {
          hasResourceId: !!payload.resource_id,
          hasResourceData: !!payload.resource_data,
          hasResourceType: !!payload.resource_type,
          actualKeys: Object.keys(payload)
        });
        return null;
      }

      // Extract resource type from resource_data if not at top level
      const resourceType = payload.resource_type || 
                          payload.resource_data?.resourceType || 
                          'Unknown';

      return {
        event_id: message.key?.toString() || payload.event_id || `${Date.now()}-${payload.resource_id}`,
        resource_type: resourceType,
        resource_id: payload.resource_id,
        patient_id: payload.patient_id || payload.resource_data?.subject?.reference?.split('/')[1] || '',
        tenant_id: payload.tenant_id || 'default',
        resource_json: typeof payload.resource_data === 'string' 
          ? payload.resource_data 
          : JSON.stringify(payload.resource_data),
        event_type: payload.event_type || 'create',
        version: payload.version || payload.sign || 1,
        timestamp: payload.event_time || payload.timestamp || Date.now()
      };
    } catch (error) {
      logger.error('Failed to parse message:', error);
      return null;
    }
  }

  private isRelevantResourceType(resourceType: string): boolean {
    // Check if we have a template for this resource type
    const supportedTypes = [
      // FHIR Resources
      'Patient', 'Observation', 'Condition', 'Procedure', 'MedicationRequest',
      'AllergyIntolerance', 'Encounter', 'DiagnosticReport', 'Immunization',
      'CarePlan', 'Goal', 'Appointment', 'ServiceRequest', 'Composition',
      'Task', 'Medication', 'MedicationStatement', 'Practitioner', 'Organization',
      'Location', 'PractitionerRole', 'EpisodeOfCare', 'ClinicalImpression',
      'DocumentReference', 'ChargeItem', 'HealthcareService', 'MedicationAdministration',
      'MedicationDispense', 'QuestionnaireResponse', 'SupplyDelivery', 'Subscription',
      // Business Resources
      'Account', 'Invoice', 'Employee', 'Coverage', 'Claim', 'Payment'
    ];

    // Case-insensitive check - NexusCare sends lowercase resource types with underscores
    // Convert: "medication_request" → "MedicationRequest", "patient" → "Patient"
    const normalizedType = resourceType
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join('');
    
    const isSupported = supportedTypes.includes(normalizedType);
    
    if (!isSupported && resourceType === 'EpisodeOfCare') {
      logger.warn(`EpisodeOfCare not matching. Original: ${resourceType}, Normalized: ${normalizedType}, Supported: ${supportedTypes.includes('EpisodeOfCare')}`);
    }
    
    return isSupported;
  }

  private async processWithRetry(message: any, maxRetries = 3): Promise<any> {
    let lastError: Error | null = null;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        // For SimpleFHIRProcessor, just call the method directly
        await this.ragProcessor.processFHIREvent(message);
        
        // Return success response
        return { 
          success: true, 
          message: 'Event processed successfully',
          chunks_generated: 0,
          chunks_stored: 0
        };
      } catch (error) {
        lastError = error as Error;
        logger.warn(`Processing attempt ${attempt} failed: ${(error as Error).message}`);
        
        if (attempt < maxRetries) {
          // Exponential backoff
          const delay = Math.min(1000 * Math.pow(2, attempt - 1), 10000);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }

    throw lastError || new Error('Processing failed after retries');
  }

  private isRetriableError(error: any): boolean {
    // Define retriable error conditions
    const retriableErrors = [
      'ECONNREFUSED',
      'ETIMEDOUT',
      'ENOTFOUND',
      'NetworkError',
      'ServiceUnavailable',
      'TooManyRequests'
    ];

    const errorMessage = error.message || '';
    const errorCode = error.code || '';

    return retriableErrors.some(retriable => 
      errorMessage.includes(retriable) || errorCode === retriable
    );
  }

  private startLagMonitoring(): void {
    // Monitor consumer lag every 30 seconds
    setInterval(async () => {
      try {
        const admin = this.kafka.admin();
        await admin.connect();

        // Get consumer group offsets
        const offsets = await admin.fetchOffsets({
          groupId: this.config.groupId,
          topics: this.config.topics
        });

        // Get topic offsets
        for (const topic of this.config.topics) {
          const topicOffsets = await admin.fetchTopicOffsets(topic);
          
          for (const partition of topicOffsets) {
            const consumerOffset = offsets.find(
              o => o.topic === topic && o.partitions.some(p => p.partition === partition.partition)
            );

            if (consumerOffset) {
              const partitionInfo = consumerOffset.partitions.find(p => p.partition === partition.partition);
              if (partitionInfo) {
                const lag = Number(partition.high) - Number(partitionInfo.offset);
                kafkaConsumerLag.set(
                  { topic, partition: partition.partition.toString() },
                  lag
                );
              }
            }
          }
        }

        await admin.disconnect();
      } catch (error) {
        logger.error('Error monitoring consumer lag:', error);
      }
    }, 30000);
  }
}