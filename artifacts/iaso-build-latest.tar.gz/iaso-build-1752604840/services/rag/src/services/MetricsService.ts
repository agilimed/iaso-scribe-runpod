import { Registry, collectDefaultMetrics, Counter, Histogram, Gauge, register } from 'prom-client';
import * as http from 'http';
import { logger } from '../utils/logger';

// Create a custom registry
const customRegistry = new Registry();

// Collect default metrics (CPU, memory, etc.)
collectDefaultMetrics({ register: customRegistry });

// RAG Processing Metrics
export const ragEventsProcessed = new Counter({
  name: 'rag_events_processed_total',
  help: 'Total number of FHIR events processed by RAG',
  labelNames: ['resource_type', 'event_type', 'tenant_id'],
  registers: [customRegistry]
});

export const ragChunksGenerated = new Counter({
  name: 'rag_chunks_generated_total',
  help: 'Total number of chunks generated',
  labelNames: ['resource_type', 'chunk_type', 'tenant_id'],
  registers: [customRegistry]
});

export const ragProcessingDuration = new Histogram({
  name: 'rag_processing_duration_seconds',
  help: 'Time spent processing FHIR events',
  labelNames: ['resource_type', 'event_type'],
  buckets: [0.1, 0.5, 1, 2, 5, 10, 30],
  registers: [customRegistry]
});

export const ragProcessingErrors = new Counter({
  name: 'rag_processing_errors_total',
  help: 'Total number of RAG processing errors',
  labelNames: ['resource_type', 'error_type'],
  registers: [customRegistry]
});

// Embedding Metrics
export const embeddingRequests = new Counter({
  name: 'embedding_requests_total',
  help: 'Total number of embedding requests to embedding service',
  labelNames: ['type', 'model'],
  registers: [customRegistry]
});

export const embeddingLatency = new Histogram({
  name: 'embedding_latency_seconds',
  help: 'Latency of embedding generation',
  labelNames: ['type', 'model'],
  buckets: [0.01, 0.05, 0.1, 0.5, 1, 2, 5],
  registers: [customRegistry]
});

// Qdrant Metrics
export const qdrantOperations = new Counter({
  name: 'qdrant_operations_total',
  help: 'Total number of Qdrant operations',
  labelNames: ['operation', 'collection'],
  registers: [customRegistry]
});

export const qdrantOperationDuration = new Histogram({
  name: 'qdrant_operation_duration_seconds',
  help: 'Duration of Qdrant operations',
  labelNames: ['operation', 'collection'],
  buckets: [0.01, 0.05, 0.1, 0.5, 1, 2, 5],
  registers: [customRegistry]
});

export const qdrantStoredVectors = new Gauge({
  name: 'qdrant_stored_vectors_total',
  help: 'Total number of vectors stored in Qdrant',
  labelNames: ['collection', 'tenant_id'],
  registers: [customRegistry]
});

// Query Metrics
export const ragQueries = new Counter({
  name: 'rag_queries_total',
  help: 'Total number of RAG queries',
  labelNames: ['tenant_id'],
  registers: [customRegistry]
});

export const ragQueryDuration = new Histogram({
  name: 'rag_query_duration_seconds',
  help: 'Duration of RAG queries',
  labelNames: ['tenant_id'],
  buckets: [0.1, 0.5, 1, 2, 5, 10],
  registers: [customRegistry]
});

export const ragQueryResultsReturned = new Histogram({
  name: 'rag_query_results_returned',
  help: 'Number of results returned per query',
  labelNames: ['tenant_id'],
  buckets: [0, 1, 5, 10, 20, 50, 100],
  registers: [customRegistry]
});

// Service Health Metrics
export const serviceHealth = new Gauge({
  name: 'rag_service_health',
  help: 'Health status of RAG service components (1=healthy, 0=unhealthy)',
  labelNames: ['component'],
  registers: [customRegistry]
});

export const activeConnections = new Gauge({
  name: 'rag_active_connections',
  help: 'Number of active gRPC connections',
  registers: [customRegistry]
});

// Resource Usage Metrics
export const chunkCacheSize = new Gauge({
  name: 'rag_chunk_cache_size',
  help: 'Number of chunks in cache',
  labelNames: ['cache_type'],
  registers: [customRegistry]
});

export const chunkCacheHits = new Counter({
  name: 'rag_chunk_cache_hits_total',
  help: 'Total number of chunk cache hits',
  labelNames: ['cache_type'],
  registers: [customRegistry]
});

export const chunkCacheMisses = new Counter({
  name: 'rag_chunk_cache_misses_total',
  help: 'Total number of chunk cache misses',
  labelNames: ['cache_type'],
  registers: [customRegistry]
});

export class MetricsService {
  private server: http.Server | null = null;

  startServer(port: number): void {
    this.server = http.createServer(async (req, res) => {
      if (req.url === '/metrics') {
        res.setHeader('Content-Type', customRegistry.contentType);
        try {
          const metrics = await customRegistry.metrics();
          res.end(metrics);
        } catch (error) {
          logger.error('Error generating metrics:', error);
          res.statusCode = 500;
          res.end('Error generating metrics');
        }
      } else if (req.url === '/health') {
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ status: 'healthy' }));
      } else {
        res.statusCode = 404;
        res.end('Not found');
      }
    });

    this.server.listen(port, () => {
      logger.info(`Metrics server listening on port ${port}`);
    });

    // Update service health periodically
    this.startHealthMonitoring();
  }

  stopServer(): void {
    if (this.server) {
      this.server.close(() => {
        logger.info('Metrics server stopped');
      });
    }
  }

  private startHealthMonitoring(): void {
    // Monitor service health every 30 seconds
    setInterval(() => {
      // These would be actual health checks in production
      serviceHealth.set({ component: 'grpc_server' }, 1);
      serviceHealth.set({ component: 'kafka_consumer' }, 1);
      serviceHealth.set({ component: 'qdrant_connection' }, 1);
      serviceHealth.set({ component: 'embedding_service' }, 1);
    }, 30000);
  }

  // Utility methods for tracking metrics
  static recordRAGProcessing(
    resourceType: string,
    eventType: string,
    tenantId: string,
    duration: number,
    chunksGenerated: number,
    success: boolean
  ): void {
    if (success) {
      ragEventsProcessed.inc({ resource_type: resourceType, event_type: eventType, tenant_id: tenantId });
      ragProcessingDuration.observe({ resource_type: resourceType, event_type: eventType }, duration / 1000);
      
      if (chunksGenerated > 0) {
        ragChunksGenerated.inc({ 
          resource_type: resourceType, 
          chunk_type: 'all', 
          tenant_id: tenantId 
        }, chunksGenerated);
      }
    } else {
      ragProcessingErrors.inc({ resource_type: resourceType, error_type: 'processing_failed' });
    }
  }

  static recordEmbeddingOperation(
    type: 'single' | 'batch',
    model: string,
    duration: number,
    success: boolean
  ): void {
    if (success) {
      embeddingRequests.inc({ type, model });
      embeddingLatency.observe({ type, model }, duration / 1000);
    } else {
      ragProcessingErrors.inc({ resource_type: 'embedding', error_type: 'embedding_failed' });
    }
  }

  static recordQdrantOperation(
    operation: 'upsert' | 'search' | 'delete',
    collection: string,
    duration: number,
    success: boolean,
    count?: number
  ): void {
    if (success) {
      qdrantOperations.inc({ operation, collection });
      qdrantOperationDuration.observe({ operation, collection }, duration / 1000);
      
      if (operation === 'upsert' && count) {
        qdrantStoredVectors.inc({ collection, tenant_id: 'all' }, count);
      }
    } else {
      ragProcessingErrors.inc({ resource_type: 'qdrant', error_type: `${operation}_failed` });
    }
  }

  static recordQuery(
    tenantId: string,
    duration: number,
    resultsCount: number,
    success: boolean
  ): void {
    if (success) {
      ragQueries.inc({ tenant_id: tenantId });
      ragQueryDuration.observe({ tenant_id: tenantId }, duration / 1000);
      ragQueryResultsReturned.observe({ tenant_id: tenantId }, resultsCount);
    } else {
      ragProcessingErrors.inc({ resource_type: 'query', error_type: 'query_failed' });
    }
  }

  static recordCacheOperation(
    cacheType: 'embedding' | 'chunk',
    hit: boolean
  ): void {
    if (hit) {
      chunkCacheHits.inc({ cache_type: cacheType });
    } else {
      chunkCacheMisses.inc({ cache_type: cacheType });
    }
  }

  static updateCacheSize(cacheType: string, size: number): void {
    chunkCacheSize.set({ cache_type: cacheType }, size);
  }

  static updateActiveConnections(count: number): void {
    activeConnections.set(count);
  }
}

// Export the registry for custom metrics
export { customRegistry };