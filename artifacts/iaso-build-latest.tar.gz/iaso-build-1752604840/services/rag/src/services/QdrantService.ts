import { QdrantClient } from '@qdrant/js-client-rest';
import { logger } from '../utils/logger';

interface QdrantConfig {
  host: string;
  port: number;
  collections: {
    fhir_chunks: {
      vectorSize: number;
      distance: 'Cosine' | 'Euclid' | 'Dot';
    };
  };
}

interface ChunkPoint {
  id: string;
  vector: number[];
  payload: any;
}

export class QdrantService {
  private client: QdrantClient;
  private collectionName = 'fhir_chunks';

  constructor(private config: QdrantConfig) {
    this.client = new QdrantClient({
      host: config.host,
      port: config.port,
    });
  }

  async initialize(): Promise<void> {
    try {
      // Check if collection exists
      const collections = await this.client.getCollections();
      const collectionExists = collections.collections.some(
        c => c.name === this.collectionName
      );

      if (!collectionExists) {
        logger.info(`Creating Qdrant collection: ${this.collectionName}`);
        await this.createCollection();
      } else {
        logger.info(`Qdrant collection ${this.collectionName} already exists`);
      }

      // Create indexes for efficient filtering
      await this.createIndexes();
      
      logger.info('Qdrant service initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize Qdrant service:', error);
      throw error;
    }
  }

  private async createCollection(): Promise<void> {
    const { vectorSize, distance } = this.config.collections.fhir_chunks;
    
    await this.client.createCollection(this.collectionName, {
      vectors: {
        size: vectorSize,
        distance: distance,
      },
      optimizers_config: {
        default_segment_number: 2,
        indexing_threshold: 20000,
      },
      replication_factor: 2,
      write_consistency_factor: 1,
    });

    logger.info(`Created collection ${this.collectionName} with vector size ${vectorSize}`);
  }

  private async createIndexes(): Promise<void> {
    try {
      // Create payload indexes for efficient filtering
      const indexes = [
        'tenant_id',
        'resourceType', 
        'resourceId',
        'patientId',
        'chunkType',
        'is_deleted',
        'resource_version',
        'created_at',
        'updated_at'
      ];

      for (const fieldName of indexes) {
        try {
          // Note: Qdrant automatically indexes keyword fields in payload
          // No explicit index creation needed for most use cases
          logger.debug(`Field ${fieldName} will be auto-indexed by Qdrant`);
        } catch (error: any) {
          logger.warn(`Index consideration for ${fieldName}: ${error.message}`);
        }
      }
      
      logger.info('Payload field indexing prepared for CRUD operations');
    } catch (error) {
      logger.error('Error preparing indexes:', error);
    }
  }

  async upsertChunks(tenantId: string, points: ChunkPoint[]): Promise<void> {
    try {
      // Add tenant isolation to each point
      const isolatedPoints = points.map(point => ({
        ...point,
        payload: {
          ...point.payload,
          tenant_id: tenantId,
        }
      }));

      // Upsert in batches for better performance
      const batchSize = 100;
      for (let i = 0; i < isolatedPoints.length; i += batchSize) {
        const batch = isolatedPoints.slice(i, i + batchSize);
        await this.client.upsert(this.collectionName, {
          wait: true,
          points: batch,
        });
      }

      logger.info(`Upserted ${points.length} chunks for tenant ${tenantId}`);
    } catch (error) {
      logger.error('Failed to upsert chunks:', error);
      throw error;
    }
  }

  // Alias for upsertChunks to match the method called in rag-processor
  async upsertPoints(tenantId: string, points: ChunkPoint[]): Promise<void> {
    return this.upsertChunks(tenantId, points);
  }

  async deleteResourceChunks(
    tenantId: string,
    resourceType: string,
    resourceId: string
  ): Promise<void> {
    try {
      await this.client.delete(this.collectionName, {
        wait: true,
        filter: {
          must: [
            { key: 'tenant_id', match: { value: tenantId } },
            { key: 'resource_type', match: { value: resourceType } },
            { key: 'resource_id', match: { value: resourceId } },
          ],
        },
      });

      logger.info(`Deleted chunks for ${resourceType}/${resourceId} in tenant ${tenantId}`);
    } catch (error) {
      logger.error('Failed to delete resource chunks:', error);
      throw error;
    }
  }

  // Generic delete method with custom filter
  async deleteChunks(tenantId: string, filter: any): Promise<void> {
    try {
      await this.client.delete(this.collectionName, {
        wait: true,
        filter: filter,
      });

      logger.info(`Deleted chunks with custom filter for tenant ${tenantId}`);
    } catch (error) {
      logger.error('Failed to delete chunks with filter:', error);
      throw error;
    }
  }

  // Search method that returns raw points (for CRUD operations)
  async searchPoints(tenantId: string, searchParams: any): Promise<any[]> {
    try {
      const result = await this.client.search(this.collectionName, searchParams);
      return result;
    } catch (error) {
      logger.error('Failed to search points:', error);
      throw error;
    }
  }

  async search(
    tenantId: string,
    queryVector: number[],
    limit: number = 20,
    scoreThreshold: number = 0.7,
    filters?: any
  ): Promise<any[]> {
    try {
      // Build filter with tenant isolation
      const mustFilters: any[] = [
        { key: 'tenant_id', match: { value: tenantId } }
      ];

      // Add additional filters
      if (filters) {
        if (filters.patient_ids?.length > 0) {
          mustFilters.push({
            key: 'patient_id',
            match: { any: filters.patient_ids }
          });
        }

        if (filters.resource_types?.length > 0) {
          mustFilters.push({
            key: 'resource_type',
            match: { any: filters.resource_types }
          });
        }

        if (filters.clinical_domains?.length > 0) {
          mustFilters.push({
            key: 'metadata.clinical_domain',
            match: { any: filters.clinical_domains }
          });
        }

        // Date range filter
        if (filters.date_from || filters.date_to) {
          const dateFilter: any = { key: 'temporal_context.date' };
          if (filters.date_from && filters.date_to) {
            dateFilter.range = {
              gte: filters.date_from,
              lte: filters.date_to
            };
          } else if (filters.date_from) {
            dateFilter.range = { gte: filters.date_from };
          } else if (filters.date_to) {
            dateFilter.range = { lte: filters.date_to };
          }
          mustFilters.push(dateFilter);
        }
      }

      const searchResult = await this.client.search(this.collectionName, {
        vector: queryVector,
        limit: limit,
        score_threshold: scoreThreshold,
        with_payload: true,
        filter: {
          must: mustFilters
        }
      });

      return searchResult;
    } catch (error) {
      logger.error('Search failed:', error);
      throw error;
    }
  }

  async getCollectionInfo(): Promise<any> {
    try {
      return await this.client.getCollection(this.collectionName);
    } catch (error) {
      logger.error('Failed to get collection info:', error);
      throw error;
    }
  }

  async healthCheck(): Promise<boolean> {
    try {
      await this.client.getCollections();
      return true;
    } catch (error) {
      logger.error('Qdrant health check failed:', error);
      return false;
    }
  }

  async close(): Promise<void> {
    // QdrantClient doesn't require explicit closing
    logger.info('Qdrant service closed');
  }
}