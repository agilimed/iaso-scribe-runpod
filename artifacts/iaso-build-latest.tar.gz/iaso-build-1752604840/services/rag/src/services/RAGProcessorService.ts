import * as grpc from '@grpc/grpc-js';
import { v4 as uuidv4 } from 'uuid';
import { ResourceTemplateService } from '../fhir/ResourceTemplateService';
import { QdrantService } from './QdrantService';
import { EmbeddingClient } from '../clients/EmbeddingClient';
import { logger } from '../utils/logger';
import { MetricsService } from './MetricsService';
import { nexuscare } from '../generated/rag';

// Type aliases for cleaner code  
type FHIREvent = nexuscare.rag.FHIREvent;
type ProcessingResult = nexuscare.rag.ProcessingResult;
type FHIRResource = nexuscare.rag.FHIRResource;
type ChunkList = nexuscare.rag.ChunkList;
type RAGQuery = nexuscare.rag.RAGQuery;
type RAGQueryResult = nexuscare.rag.RAGQueryResult;
type Empty = nexuscare.rag.Empty;
type HealthStatus = nexuscare.rag.HealthStatus;
type Chunk = nexuscare.rag.Chunk;
type ChunkType = nexuscare.rag.ChunkType;
type ClinicalSignificance = nexuscare.rag.ClinicalSignificance;
type SemanticResult = nexuscare.rag.SemanticResult;
type ClinicalContext = nexuscare.rag.ClinicalContext;

export class RAGProcessorService {
  private templateService: ResourceTemplateService;
  private embeddingClient: EmbeddingClient;

  constructor(
    private qdrantService: QdrantService,
    private embeddingServiceConfig: { host: string; port: number }
  ) {
    this.templateService = new ResourceTemplateService();
    this.embeddingClient = new EmbeddingClient(
      embeddingServiceConfig.host,
      embeddingServiceConfig.port
    );
  }

  async processFHIREvent(
    call: grpc.ServerUnaryCall<FHIREvent, ProcessingResult>,
    callback: grpc.sendUnaryData<ProcessingResult>
  ): Promise<void> {
    const startTime = Date.now();
    const event = call.request;

    try {
      logger.info(`Processing FHIR event: ${event.event_type} for ${event.resource_type}/${event.resource_id}`);

      // Parse the FHIR resource
      const resource = JSON.parse(event.resource_json);
      resource.id = event.resource_id;
      resource.resourceType = event.resource_type;

      // Handle different event types
      if (event.event_type === 'delete') {
        // Delete chunks for this resource
        await this.qdrantService.deleteResourceChunks(
          event.tenant_id,
          event.resource_type,
          event.resource_id
        );

        callback(null, {
          success: true,
          message: 'Resource chunks deleted',
          chunks_generated: 0,
          chunks_stored: 0,
          chunk_ids: [],
          processing_time_ms: Date.now() - startTime,
          metadata: {}
        } as ProcessingResult);
        return;
      }

      // Generate chunks using templates
      const chunks = await this.templateService.generateChunks(resource);
      if (!chunks || chunks.length === 0) {
        logger.warn(`No chunks generated for ${event.resource_type}/${event.resource_id}`);
        callback(null, {
          success: true,
          message: 'No chunks generated',
          chunks_generated: 0,
          chunks_stored: 0,
          chunk_ids: [],
          processing_time_ms: Date.now() - startTime,
          metadata: {}
        } as ProcessingResult);
        return;
      }

      // Extract metadata
      const metadata = await this.templateService.extractMetadata(resource);

      // Generate embeddings for all chunks
      const chunkTexts = chunks.map(chunk => chunk.content);
      const embeddings = await this.embeddingClient.generateBatchEmbeddings(chunkTexts);

      // Prepare points for Qdrant
      const points = chunks.map((chunk, index) => ({
        id: chunk.id,
        vector: embeddings[index],
        payload: {
          ...chunk,
          resource_type: event.resource_type,
          resource_id: event.resource_id,
          patient_id: event.patient_id,
          tenant_id: event.tenant_id,
          version: event.version,
          timestamp: event.timestamp,
          metadata: metadata
        }
      }));

      // Store in Qdrant
      await this.qdrantService.upsertChunks(event.tenant_id, points);

      // Record metrics
      const processingTime = Date.now() - startTime;
      MetricsService.recordRAGProcessing(
        event.resource_type,
        event.event_type,
        event.tenant_id,
        processingTime,
        chunks.length,
        true
      );

      // Return result
      callback(null, {
        success: true,
        message: 'Event processed successfully',
        chunks_generated: chunks.length,
        chunks_stored: chunks.length,
        chunk_ids: chunks.map(c => c.id),
        processing_time_ms: processingTime,
        metadata: {
          resource_type: event.resource_type,
          clinical_significance: metadata?.clinical_significance || 'normal'
        }
      } as ProcessingResult);

    } catch (error) {
      logger.error(`Error processing FHIR event: ${error}`);
      callback({
        code: grpc.status.INTERNAL,
        message: `Failed to process event: ${error.message}`
      }, null);
    }
  }

  async generateChunks(
    call: grpc.ServerUnaryCall<FHIRResource, ChunkList>,
    callback: grpc.sendUnaryData<ChunkList>
  ): Promise<void> {
    try {
      const resource = JSON.parse(call.request.resource_json);
      resource.resourceType = call.request.resource_type;
      resource.id = call.request.resource_id;

      const chunks = await this.templateService.generateChunks(resource);

      // Convert to proto format
      const protoChunks = chunks.map(chunk => ({
        id: chunk.id,
        content: chunk.content,
        type: this.mapChunkType(chunk.type),
        clinical_significance: this.mapClinicalSignificance(chunk.clinical_significance),
        searchable_terms: chunk.searchable_terms,
        temporal_context: chunk.temporal_context,
        clinical_codes: chunk.clinical_codes,
        metadata: {}
      } as Chunk));

      callback(null, {
        chunks: protoChunks,
        resource_type: call.request.resource_type,
        resource_id: call.request.resource_id
      } as ChunkList);

    } catch (error) {
      logger.error(`Error generating chunks: ${error}`);
      callback({
        code: grpc.status.INTERNAL,
        message: `Failed to generate chunks: ${error.message}`
      }, null);
    }
  }

  async query(
    call: grpc.ServerUnaryCall<RAGQuery, RAGQueryResult>,
    callback: grpc.sendUnaryData<RAGQueryResult>
  ): Promise<void> {
    const startTime = Date.now();
    
    try {
      const { query, tenant_id, filters, limit = 20, similarity_threshold = 0.7 } = call.request;

      // Generate embedding for query
      const queryEmbedding = await this.embeddingClient.generateEmbedding(query);

      // Search in Qdrant
      const searchResults = await this.qdrantService.search(
        tenant_id,
        queryEmbedding,
        limit,
        similarity_threshold,
        filters
      );

      // Convert to semantic results
      const semanticResults: SemanticResult[] = searchResults.map(result => ({
        chunk_id: result.id as string,
        content: result.payload.content as string,
        similarity_score: result.score,
        resource_type: result.payload.resource_type as string,
        resource_id: result.payload.resource_id as string,
        metadata: result.payload.metadata as any || {}
      }));

      // Extract clinical context
      const clinicalContext = this.extractClinicalContext(searchResults);

      callback(null, {
        results: semanticResults,
        clinical_context: clinicalContext,
        query_time_ms: Date.now() - startTime,
        metadata: {
          total_results: searchResults.length.toString(),
          model_used: 'bge-m3'
        }
      } as RAGQueryResult);

    } catch (error) {
      logger.error(`Error executing query: ${error}`);
      callback({
        code: grpc.status.INTERNAL,
        message: `Query failed: ${error.message}`
      }, null);
    }
  }

  async healthCheck(
    call: grpc.ServerUnaryCall<Empty, HealthStatus>,
    callback: grpc.sendUnaryData<HealthStatus>
  ): Promise<void> {
    try {
      // Check Qdrant connection
      const qdrantHealthy = await this.qdrantService.healthCheck();
      
      // Check embedding service
      const embeddingHealthy = await this.embeddingClient.healthCheck();

      const healthy = qdrantHealthy && embeddingHealthy;

      callback(null, {
        healthy,
        status: healthy ? 'All services healthy' : 'Some services unhealthy',
        details: {
          qdrant: qdrantHealthy ? 'healthy' : 'unhealthy',
          embeddings: embeddingHealthy ? 'healthy' : 'unhealthy',
          templates: 'healthy'
        }
      } as HealthStatus);

    } catch (error) {
      callback(null, {
        healthy: false,
        status: `Health check failed: ${error.message}`,
        details: {}
      } as HealthStatus);
    }
  }

  private mapChunkType(type: string): ChunkType {
    switch (type) {
      case 'granular_fact':
        return ChunkType.GRANULAR_FACT;
      case 'resource_summary':
        return ChunkType.RESOURCE_SUMMARY;
      case 'ips_summary':
        return ChunkType.IPS_SUMMARY;
      default:
        return ChunkType.CHUNK_TYPE_UNSPECIFIED;
    }
  }

  private mapClinicalSignificance(significance: string): ClinicalSignificance {
    switch (significance) {
      case 'critical':
        return ClinicalSignificance.CRITICAL;
      case 'abnormal':
        return ClinicalSignificance.ABNORMAL;
      case 'normal':
        return ClinicalSignificance.NORMAL;
      default:
        return ClinicalSignificance.SIGNIFICANCE_UNSPECIFIED;
    }
  }

  private extractClinicalContext(searchResults: any[]): ClinicalContext {
    const context: ClinicalContext = {
      relevant_patients: [],
      clinical_codes: {
        loinc: [],
        icd10: [],
        rxnorm: [],
        snomed: []
      },
      reference_ranges: {},
      temporal_context: {
        start_date: '',
        end_date: '',
        encounter_ids: [],
        episode_ids: []
      },
      clinical_notes: [],
      ips_context: []
    };

    // Extract unique values from search results
    const patients = new Set<string>();
    const loinc = new Set<string>();
    const icd10 = new Set<string>();
    const encounters = new Set<string>();

    for (const result of searchResults) {
      const payload = result.payload;
      
      if (payload.patient_id) patients.add(payload.patient_id);
      
      if (payload.clinical_codes) {
        payload.clinical_codes.loinc?.forEach((code: string) => loinc.add(code));
        payload.clinical_codes.icd10?.forEach((code: string) => icd10.add(code));
      }
      
      if (payload.temporal_context?.encounter_id) {
        encounters.add(payload.temporal_context.encounter_id);
      }
      
      if (payload.content && payload.type === 'resource_summary') {
        context.clinical_notes.push(payload.content);
      }
    }

    context.relevant_patients = Array.from(patients);
    context.clinical_codes.loinc = Array.from(loinc);
    context.clinical_codes.icd10 = Array.from(icd10);
    context.temporal_context.encounter_ids = Array.from(encounters);

    return context;
  }
}