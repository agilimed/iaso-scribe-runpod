import { QdrantService } from './services/QdrantService';
import { logger } from './utils/logger';
import { v4 as uuidv4 } from 'uuid';
import axios from 'axios';

interface FHIRResource {
  resourceType: string;
  id: string;
  name?: Array<{
    given?: string[];
    family?: string;
    use?: string;
  }>;
  identifier?: Array<{
    system?: string;
    value?: string;
  }>;
  birthDate?: string;
  gender?: string;
  address?: Array<{
    line?: string[];
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
  }>;
  telecom?: Array<{
    system?: string;
    value?: string;
    use?: string;
  }>;
  [key: string]: any;
}

interface ResourceChunk {
  id: string;
  content: string;
  metadata: {
    resourceType: string;
    resourceId: string;
    patientId?: string;
    patientName?: string;
    chunkType: 'summary' | 'demographics' | 'identifiers' | 'contact' | 'clinical' | 'administrative' | 'financial' | 'codes' | 'temporal' | 'relationship';
    searchableTerms: string[];
    clinicalContext?: any;
    relationships?: {
      relatedResources: Array<{
        resourceType: string;
        resourceId: string;
        relationship: string;
      }>;
    };
  };
}

export class FHIRRAGProcessor {
  private embeddingsServiceUrl: string;

  constructor(
    private qdrantService: QdrantService,
    embeddingsConfig: { host: string; port: number }
  ) {
    this.embeddingsServiceUrl = `http://${embeddingsConfig.host}:${embeddingsConfig.port}`;
  }

  async processFHIREvent(message: any): Promise<void> {
    try {
      const startTime = Date.now();
      
      // Parse the event
      const parsedEvent = message.parsedEvent;
      const eventType = parsedEvent.event_type || 'create';
      
      logger.info('Processing FHIR event', {
        eventType,
        resourceType: parsedEvent.resource_type,
        resourceId: parsedEvent.resource_id,
        patientId: parsedEvent.patient_id,
        version: parsedEvent.version
      });

      // Handle different CRUD operations
      switch (eventType.toLowerCase()) {
        case 'create':
          await this.handleCreateEvent(parsedEvent);
          break;
        case 'update':
          await this.handleUpdateEvent(parsedEvent);
          break;
        case 'delete':
          await this.handleDeleteEvent(parsedEvent);
          break;
        case 'patch':
          await this.handlePatchEvent(parsedEvent);
          break;
        default:
          logger.warn(`Unknown event type: ${eventType}, treating as create`);
          await this.handleCreateEvent(parsedEvent);
      }
      
      const processingTime = Date.now() - startTime;
      logger.info(`Successfully processed ${eventType} event for ${parsedEvent.resource_type}/${parsedEvent.resource_id} in ${processingTime}ms`);

    } catch (error) {
      logger.error('Error processing FHIR event:', error);
      throw error;
    }
  }

  // CRUD Event Handlers
  private async handleCreateEvent(event: any): Promise<void> {
    logger.info(`Handling CREATE event for ${event.resource_type}/${event.resource_id}`);
    
    // Parse the resource
    const resource = typeof event.resource_json === 'string' 
      ? JSON.parse(event.resource_json) 
      : event.resource_json;

    // Generate chunks with deterministic IDs for future updates
    const chunks = this.generateChunksWithDeterministicIds(resource, event);
    
    if (chunks.length === 0) {
      logger.warn(`No chunks generated for ${event.resource_type}/${event.resource_id}`);
      return;
    }

    // Generate embeddings
    const embeddings = await this.generateEmbeddings(chunks.map(c => c.content));
    
    // Create Qdrant points
    const points = chunks.map((chunk, index) => ({
      id: chunk.id,
      vector: embeddings[index],
      payload: {
        content: chunk.content,
        ...chunk.metadata,
        tenant_id: event.tenant_id,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        resource_version: event.version || '1',
        is_deleted: false
      }
    }));

    // Store in Qdrant
    await this.qdrantService.upsertPoints(event.tenant_id, points);
    
    logger.info(`Created ${chunks.length} chunks for ${event.resource_type}/${event.resource_id}`);
  }

  private async handleUpdateEvent(event: any): Promise<void> {
    logger.info(`Handling UPDATE event for ${event.resource_type}/${event.resource_id}`);
    
    try {
      // First, delete existing chunks for this resource
      await this.deleteResourceChunks(event.resource_type, event.resource_id, event.tenant_id);
      
      // Parse the updated resource
      const resource = typeof event.resource_json === 'string' 
        ? JSON.parse(event.resource_json) 
        : event.resource_json;

      // Generate new chunks with deterministic IDs
      const chunks = this.generateChunksWithDeterministicIds(resource, event);
      
      if (chunks.length === 0) {
        logger.warn(`No chunks generated for updated ${event.resource_type}/${event.resource_id}`);
        return;
      }

      // Generate embeddings for new content
      const embeddings = await this.generateEmbeddings(chunks.map(c => c.content));
      
      // Create Qdrant points
      const points = chunks.map((chunk, index) => ({
        id: chunk.id,
        vector: embeddings[index],
        payload: {
          content: chunk.content,
          ...chunk.metadata,
          tenant_id: event.tenant_id,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          resource_version: event.version || '1',
          is_deleted: false
        }
      }));

      // Store updated chunks in Qdrant
      await this.qdrantService.upsertPoints(event.tenant_id, points);
      
      // Update related chunks if needed
      await this.updateRelatedChunks(event);
      
      logger.info(`Updated ${chunks.length} chunks for ${event.resource_type}/${event.resource_id}`);
      
    } catch (error) {
      logger.error(`Error updating ${event.resource_type}/${event.resource_id}:`, error);
      throw error;
    }
  }

  private async handleDeleteEvent(event: any): Promise<void> {
    logger.info(`Handling DELETE event for ${event.resource_type}/${event.resource_id}`);
    
    try {
      // Soft delete: mark chunks as deleted but preserve for audit
      await this.markResourceDeleted(event.resource_type, event.resource_id, event.tenant_id);
      
      // Update related chunks to remove references
      await this.removeResourceReferences(event);
      
      logger.info(`Soft deleted chunks for ${event.resource_type}/${event.resource_id}`);
      
    } catch (error) {
      logger.error(`Error deleting ${event.resource_type}/${event.resource_id}:`, error);
      throw error;
    }
  }

  private async handlePatchEvent(event: any): Promise<void> {
    logger.info(`Handling PATCH event for ${event.resource_type}/${event.resource_id}`);
    
    try {
      // For now, treat PATCH the same as UPDATE
      // In the future, we could implement selective chunk updates
      await this.handleUpdateEvent(event);
      
      logger.info(`Patched chunks for ${event.resource_type}/${event.resource_id}`);
      
    } catch (error) {
      logger.error(`Error patching ${event.resource_type}/${event.resource_id}:`, error);
      throw error;
    }
  }

  // CRUD Helper Methods
  private generateChunksWithDeterministicIds(resource: FHIRResource, event: any): ResourceChunk[] {
    // Generate chunks using existing logic
    const chunks = this.generateChunks(resource, event);
    
    // Replace random UUIDs with deterministic IDs
    return chunks.map(chunk => ({
      ...chunk,
      id: this.generateDeterministicChunkId(
        resource.resourceType || event.resource_type,
        resource.id || event.resource_id,
        chunk.metadata.chunkType
      )
    }));
  }

  private generateDeterministicChunkId(resourceType: string, resourceId: string, chunkType: string): string {
    return `${resourceType}:${resourceId}:${chunkType}`;
  }

  private async deleteResourceChunks(resourceType: string, resourceId: string, tenantId: string): Promise<void> {
    try {
      // Build filter to find all chunks for this resource
      const filter = {
        must: [
          { key: 'tenant_id', match: { value: tenantId } },
          { key: 'resourceType', match: { value: resourceType } },
          { key: 'resourceId', match: { value: resourceId } }
        ]
      };
      
      // Delete chunks from Qdrant
      await this.qdrantService.deleteChunks(tenantId, filter);
      
      logger.info(`Deleted existing chunks for ${resourceType}/${resourceId}`);
      
    } catch (error) {
      logger.error(`Error deleting chunks for ${resourceType}/${resourceId}:`, error);
      throw error;
    }
  }

  private async markResourceDeleted(resourceType: string, resourceId: string, tenantId: string): Promise<void> {
    try {
      // Build filter to find all chunks for this resource
      const filter = {
        must: [
          { key: 'tenant_id', match: { value: tenantId } },
          { key: 'resourceType', match: { value: resourceType } },
          { key: 'resourceId', match: { value: resourceId } },
          { key: 'is_deleted', match: { value: false } }
        ]
      };
      
      // Get all chunks for this resource
      const response = await this.qdrantService.searchPoints(tenantId, {
        vector: new Array(1024).fill(0), // Dummy vector for filtering
        filter,
        limit: 1000,
        with_payload: true,
        with_vector: false
      });
      
      if (response.length === 0) {
        logger.warn(`No chunks found to delete for ${resourceType}/${resourceId}`);
        return;
      }
      
      // Update chunks to mark as deleted
      const updatedPoints = response.map(point => ({
        id: point.id,
        vector: point.vector || new Array(1024).fill(0),
        payload: {
          ...point.payload,
          is_deleted: true,
          deleted_at: new Date().toISOString()
        }
      }));
      
      await this.qdrantService.upsertPoints(tenantId, updatedPoints);
      
      logger.info(`Marked ${updatedPoints.length} chunks as deleted for ${resourceType}/${resourceId}`);
      
    } catch (error) {
      logger.error(`Error marking chunks as deleted for ${resourceType}/${resourceId}:`, error);
      throw error;
    }
  }

  private async updateRelatedChunks(event: any): Promise<void> {
    // TODO: Implement cascade updates for related resources
    // This would update chunks that reference this resource
    logger.debug(`Cascade updates not yet implemented for ${event.resource_type}/${event.resource_id}`);
  }

  private async removeResourceReferences(event: any): Promise<void> {
    // TODO: Implement removal of references to deleted resource
    // This would update relationship chunks that reference the deleted resource
    logger.debug(`Reference removal not yet implemented for ${event.resource_type}/${event.resource_id}`);
  }

  private generateChunks(resource: FHIRResource, event: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    const resourceType = resource.resourceType || event.resource_type;
    const resourceId = resource.id || event.resource_id;

    // Extract patient name for better context
    const patientName = this.extractPatientName(resource);
    const patientId = this.extractPatientId(resource, event);

    // 1. Resource Summary Chunk (for all resources)
    const summaryContent = this.generateResourceSummary(resource, resourceType);
    chunks.push({
      id: uuidv4(),
      content: summaryContent,
      metadata: {
        resourceType,
        resourceId,
        patientId,
        patientName,
        chunkType: 'summary',
        searchableTerms: this.extractSearchableTerms(resource, resourceType),
        clinicalContext: {
          resourceVersion: resource.meta?.versionId,
          lastUpdated: resource.meta?.lastUpdated
        }
      }
    });

    // Resource-specific chunks based on type
    if (resourceType.toLowerCase() === 'patient') {
      chunks.push(...this.generatePatientChunks(resource, resourceId, patientId, patientName));
    } else if (this.isClinicalResource(resourceType)) {
      chunks.push(...this.generateClinicalChunks(resource, resourceType, resourceId, patientId, patientName));
    } else if (this.isAdministrativeResource(resourceType)) {
      chunks.push(...this.generateAdministrativeChunks(resource, resourceType, resourceId, patientId, patientName));
    } else if (this.isBusinessResource(resourceType)) {
      chunks.push(...this.generateBusinessChunks(resource, resourceType, resourceId, patientId, patientName));
    }

    // Universal chunks for applicable resources
    if (resource.identifier && resource.identifier.length > 0) {
      chunks.push(this.generateIdentifiersChunk(resource, resourceType, resourceId, patientId, patientName));
    }

    if ((resource.telecom && resource.telecom.length > 0) || 
        (resource.address && resource.address.length > 0)) {
      chunks.push(this.generateContactChunk(resource, resourceType, resourceId, patientId, patientName));
    }

    // Codes chunk for resources with coding information
    if (this.hasCodingInformation(resource)) {
      chunks.push(this.generateCodesChunk(resource, resourceType, resourceId, patientId, patientName));
    }

    // Temporal chunk for resources with time-based information
    if (this.hasTemporalInformation(resource)) {
      chunks.push(this.generateTemporalChunk(resource, resourceType, resourceId, patientId, patientName));
    }

    // Cross-resource relationship chunks for enhanced linking
    const relationshipChunks = this.generateRelationshipChunks(resource, resourceType, resourceId, patientId, patientName, event);
    chunks.push(...relationshipChunks);

    return chunks;
  }

  private generateResourceSummary(resource: FHIRResource, resourceType: string): string {
    const parts: string[] = [];
    
    if (resourceType.toLowerCase() === 'patient') {
      const name = this.extractPatientName(resource);
      parts.push(`Patient: ${name}`);
      
      if (resource.identifier) {
        const mrn = resource.identifier.find((id: any) => 
          id.type?.coding?.[0]?.code === 'MR' || id.system?.includes('mrn')
        );
        if (mrn) parts.push(`MRN: ${mrn.value}`);
      }
      
      if (resource.gender) parts.push(`Gender: ${resource.gender}`);
      if (resource.birthDate) {
        const birthYear = new Date(resource.birthDate).getFullYear();
        parts.push(`Birth Date: ${resource.birthDate}`);
        parts.push(`Born in ${birthYear}`);
        
        const age = this.calculateAge(resource.birthDate);
        if (age !== null) {
          parts.push(`Age: ${age} years`);
          parts.push(`${age} years old`);
          
          // Add age group for better semantic matching
          const ageGroup = this.getAgeGroup(age);
          parts.push(`${ageGroup}`);
        }
      }
      
      if (resource.address?.[0]) {
        const addr = resource.address[0];
        const location = [addr.city, addr.state].filter(Boolean).join(', ');
        if (location) parts.push(`Location: ${location}`);
      }
    } else {
      parts.push(`${resourceType} Resource ID: ${resource.id}`);
      // Add specific summaries for other resource types as needed
    }

    return parts.join(' | ');
  }

  private generateDemographicsChunk(resource: FHIRResource): string {
    const name = this.extractPatientName(resource);
    
    // Start with more natural, searchable language
    const parts: string[] = [`Patient demographics for ${name}.`];
    
    // Add searchable demographic terms naturally
    parts.push(`This patient's demographic information includes:`);
    
    if (resource.gender) {
      parts.push(`Gender is ${resource.gender}.`);
      parts.push(`Patient gender: ${resource.gender}.`);
    }
    
    if (resource.birthDate) {
      const birthDate = resource.birthDate;
      const age = this.calculateAge(birthDate);
      
      // Enhanced date/age representation for better semantic search
      parts.push(`Date of birth: ${birthDate}.`);
      parts.push(`Born on ${birthDate}.`);
      parts.push(`Birth year: ${new Date(birthDate).getFullYear()}.`);
      
      if (age !== null) {
        parts.push(`Current age is ${age} years old.`);
        parts.push(`Patient is ${age} years old.`);
        parts.push(`Age: ${age} years.`);
        
        // Add age range descriptors for better semantic matching
        const ageGroup = this.getAgeGroup(age);
        parts.push(`Age group: ${ageGroup}.`);
        parts.push(`Patient is a ${ageGroup}.`);
        
        // Add decade information
        const decade = Math.floor(age / 10) * 10;
        parts.push(`Age range: ${decade}-${decade + 9} years.`);
        
        // Add semantic age descriptors
        const ageDescriptor = this.getAgeDescriptor(age);
        parts.push(`Life stage: ${ageDescriptor}.`);
        parts.push(`Patient is a ${ageDescriptor}.`);
      }
    }
    
    if (resource.maritalStatus?.coding?.[0]?.display) {
      parts.push(`Marital status: ${resource.maritalStatus.coding[0].display}.`);
      parts.push(`Patient is ${resource.maritalStatus.coding[0].display.toLowerCase()}.`);
    }
    
    if (resource.address && resource.address.length > 0) {
      const primaryAddr = resource.address.find((a: any) => a.use === 'home') || resource.address[0];
      const addrParts = [
        ...(primaryAddr.line || []),
        primaryAddr.city,
        primaryAddr.state,
        primaryAddr.postalCode,
        primaryAddr.country
      ].filter(Boolean);
      parts.push(`Primary address: ${addrParts.join(', ')}.`);
      parts.push(`Patient lives at ${addrParts.join(', ')}.`);
      if (primaryAddr.city) {
        parts.push(`Patient lives in ${primaryAddr.city}.`);
      }
    }
    
    // Add explicit demographic summary
    parts.push(`These are the patient's key demographic details and personal information.`);

    return parts.join(' ');
  }



  private extractPatientName(resource: FHIRResource): string {
    if (resource.name && resource.name.length > 0) {
      const officialName = resource.name.find((n: any) => n.use === 'official') || resource.name[0];
      const given = officialName.given?.join(' ') || '';
      const family = officialName.family || '';
      return `${given} ${family}`.trim() || 'Unknown Patient';
    }
    return 'Unknown Patient';
  }

  private extractPatientId(resource: FHIRResource, event: any): string {
    // For Patient resources, use the resource ID
    if (resource.resourceType?.toLowerCase() === 'patient') {
      return resource.id || event.resource_id;
    }
    
    // For other resources, try to extract from subject reference
    if (resource.subject?.reference) {
      const ref = resource.subject.reference;
      if (ref.includes('/')) {
        return ref.split('/').pop() || '';
      }
    }
    
    // Fall back to event patient_id
    return event.patient_id || '';
  }


  private calculateAge(birthDate?: string): number | null {
    if (!birthDate) return null;
    
    const birth = new Date(birthDate);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    
    return age;
  }

  private getAgeGroup(age: number): string {
    if (age < 1) return 'infant';
    if (age < 3) return 'toddler';
    if (age < 13) return 'child';
    if (age < 20) return 'teenager';
    if (age < 30) return 'young adult';
    if (age < 40) return 'adult in thirties';
    if (age < 50) return 'adult in forties';
    if (age < 60) return 'middle aged';
    if (age < 70) return 'senior';
    return 'elderly';
  }

  private getAgeDescriptor(age: number): string {
    if (age < 18) return 'pediatric patient';
    if (age < 25) return 'young adult';
    if (age < 65) return 'adult';
    return 'geriatric patient';
  }

  private async generateEmbeddings(texts: string[]): Promise<number[][]> {
    try {
      const response = await axios.post<{
        embeddings: number[][];
        model: string;
        dimensions: number;
      }>(`${this.embeddingsServiceUrl}/embeddings`, {
        texts,
        model: 'bge-m3'
      });

      if (response.data.embeddings && response.data.embeddings.length === texts.length) {
        return response.data.embeddings;
      } else {
        throw new Error('Invalid embeddings response');
      }
    } catch (error) {
      logger.error('Error generating embeddings:', error);
      throw error;
    }
  }

  // Resource categorization methods
  private isClinicalResource(resourceType: string): boolean {
    const clinicalTypes = [
      'Observation', 'Condition', 'Procedure', 'MedicationRequest', 'AllergyIntolerance',
      'Encounter', 'DiagnosticReport', 'Immunization', 'CarePlan', 'Goal',
      'ServiceRequest', 'ClinicalImpression', 'MedicationStatement', 'MedicationAdministration',
      'MedicationDispense', 'QuestionnaireResponse'
    ];
    return clinicalTypes.includes(resourceType);
  }

  private isAdministrativeResource(resourceType: string): boolean {
    const adminTypes = [
      'Practitioner', 'Organization', 'Location', 'PractitionerRole', 'EpisodeOfCare',
      'Appointment', 'Task', 'Medication', 'HealthcareService', 'Composition',
      'DocumentReference', 'SupplyDelivery', 'Subscription'
    ];
    return adminTypes.includes(resourceType);
  }

  private isBusinessResource(resourceType: string): boolean {
    const businessTypes = [
      'Account', 'Invoice', 'Employee', 'Coverage', 'Claim', 'Payment', 'ChargeItem'
    ];
    return businessTypes.includes(resourceType);
  }

  private hasCodingInformation(resource: any): boolean {
    return !!(resource.code || resource.category || resource.coding || 
             resource.type || resource.status || resource.class);
  }

  private hasTemporalInformation(resource: any): boolean {
    return !!(resource.effectiveDateTime || resource.performedDateTime || 
             resource.period || resource.authoredOn || resource.recordedDate ||
             resource.onset || resource.abatement);
  }

  // Patient-specific chunk generators
  private generatePatientChunks(resource: FHIRResource, resourceId: string, patientId: string, patientName: string): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];

    // Demographics chunk
    const demographicsContent = this.generateDemographicsChunk(resource);
    if (demographicsContent) {
      chunks.push({
        id: uuidv4(),
        content: demographicsContent,
        metadata: {
          resourceType: 'Patient',
          resourceId,
          patientId,
          patientName,
          chunkType: 'demographics',
          searchableTerms: [
            // Core semantic terms users would search for
            'demographics', 'patient demographics', 'personal information', 'patient info',
            'age', 'gender', 'birth date', 'date of birth', 'personal details',
            
            // Actual data values
            resource.gender || '',
            resource.birthDate || '',
            resource.birthDate ? new Date(resource.birthDate).getFullYear().toString() : '',
            resource.birthDate ? this.calculateAge(resource.birthDate)?.toString() || '' : '',
            resource.birthDate ? this.getAgeGroup(this.calculateAge(resource.birthDate) || 0) : '',
            
            // Location information
            ...(resource.address || []).map((a: any) => a.city || '').filter(Boolean),
            
            // Age-related semantic terms
            'patient age', 'birth year', 'demographic data', 'personal characteristics'
          ].filter(Boolean),
          clinicalContext: {
            gender: resource.gender,
            birthDate: resource.birthDate,
            age: this.calculateAge(resource.birthDate)
          }
        }
      });
    }

    return chunks;
  }

  // Clinical resource chunk generators
  private generateClinicalChunks(resource: any, resourceType: string, resourceId: string, patientId: string, patientName: string): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];

    // Clinical details chunk
    const clinicalContent = this.generateClinicalChunk(resource, resourceType);
    if (clinicalContent) {
      chunks.push({
        id: uuidv4(),
        content: clinicalContent,
        metadata: {
          resourceType,
          resourceId,
          patientId,
          patientName,
          chunkType: 'clinical',
          searchableTerms: this.extractClinicalTerms(resource, resourceType),
          clinicalContext: this.extractClinicalContext(resource, resourceType)
        }
      });
    }

    return chunks;
  }

  private generateClinicalChunk(resource: any, resourceType: string): string {
    const parts: string[] = [`${resourceType} Clinical Details:`];

    switch (resourceType.toLowerCase()) {
      case 'observation':
        // Core observation details per FHIR spec
        if (resource.code?.text || resource.code?.coding?.[0]?.display) {
          parts.push(`Observation Type: ${resource.code.text || resource.code.coding[0].display}`);
        }
        
        // Value representation (multiple types supported)
        if (resource.valueQuantity) {
          parts.push(`Measured Value: ${resource.valueQuantity.value} ${resource.valueQuantity.unit || ''}`);
          if (resource.valueQuantity.comparator) {
            parts.push(`Comparator: ${resource.valueQuantity.comparator}`);
          }
        } else if (resource.valueString) {
          parts.push(`Result: ${resource.valueString}`);
        } else if (resource.valueCodeableConcept) {
          parts.push(`Finding: ${resource.valueCodeableConcept.text || resource.valueCodeableConcept.coding?.[0]?.display}`);
        } else if (resource.valueBoolean !== undefined) {
          parts.push(`Result: ${resource.valueBoolean ? 'Present' : 'Absent'}`);
        }

        // Clinical interpretation
        if (resource.interpretation?.coding?.[0]?.display) {
          parts.push(`Interpretation: ${resource.interpretation.coding[0].display}`);
        }
        
        // Reference ranges for context
        if (resource.referenceRange?.[0]) {
          const range = resource.referenceRange[0];
          if (range.text) {
            parts.push(`Reference Range: ${range.text}`);
          } else if (range.low || range.high) {
            const lowVal = range.low ? `${range.low.value} ${range.low.unit || ''}` : '';
            const highVal = range.high ? `${range.high.value} ${range.high.unit || ''}` : '';
            parts.push(`Normal Range: ${lowVal} - ${highVal}`.trim());
          }
        }

        // Body site and method
        if (resource.bodySite?.coding?.[0]?.display || resource.bodySite?.text) {
          parts.push(`Body Site: ${resource.bodySite.text || resource.bodySite.coding[0].display}`);
        }
        if (resource.method?.coding?.[0]?.display || resource.method?.text) {
          parts.push(`Method: ${resource.method.text || resource.method.coding[0].display}`);
        }

        if (resource.status) parts.push(`Status: ${resource.status}`);
        if (resource.category?.[0]?.coding?.[0]?.display) {
          parts.push(`Category: ${resource.category[0].coding[0].display}`);
        }
        break;

      case 'condition':
        // Core condition information per FHIR spec
        if (resource.code?.text || resource.code?.coding?.[0]?.display) {
          parts.push(`Diagnosis: ${resource.code.text || resource.code.coding[0].display}`);
        }
        
        // Clinical and verification status
        if (resource.clinicalStatus?.coding?.[0]?.code) {
          parts.push(`Clinical Status: ${resource.clinicalStatus.coding[0].code}`);
        }
        if (resource.verificationStatus?.coding?.[0]?.code) {
          parts.push(`Verification Status: ${resource.verificationStatus.coding[0].code}`);
        }
        
        // Severity assessment
        if (resource.severity?.coding?.[0]?.display || resource.severity?.text) {
          parts.push(`Severity: ${resource.severity.text || resource.severity.coding[0].display}`);
        }
        
        // Body site
        if (resource.bodySite?.[0]?.coding?.[0]?.display || resource.bodySite?.[0]?.text) {
          parts.push(`Body Site: ${resource.bodySite[0].text || resource.bodySite[0].coding[0].display}`);
        }
        
        // Category
        if (resource.category?.[0]?.coding?.[0]?.display) {
          parts.push(`Category: ${resource.category[0].coding[0].display}`);
        }

        // Stage information
        if (resource.stage?.[0]?.summary?.coding?.[0]?.display) {
          parts.push(`Stage: ${resource.stage[0].summary.coding[0].display}`);
        }
        break;

      case 'procedure':
        if (resource.code?.text || resource.code?.coding?.[0]?.display) {
          parts.push(`Procedure: ${resource.code.text || resource.code.coding[0].display}`);
        }
        if (resource.status) parts.push(`Status: ${resource.status}`);
        if (resource.category?.coding?.[0]?.display) {
          parts.push(`Category: ${resource.category.coding[0].display}`);
        }
        if (resource.bodySite?.[0]?.coding?.[0]?.display) {
          parts.push(`Body Site: ${resource.bodySite[0].coding[0].display}`);
        }
        if (resource.outcome?.coding?.[0]?.display) {
          parts.push(`Outcome: ${resource.outcome.coding[0].display}`);
        }
        break;

      case 'medicationrequest':
        if (resource.medicationCodeableConcept?.text || resource.medicationCodeableConcept?.coding?.[0]?.display) {
          parts.push(`Medication: ${resource.medicationCodeableConcept.text || resource.medicationCodeableConcept.coding[0].display}`);
        }
        if (resource.status) parts.push(`Status: ${resource.status}`);
        if (resource.intent) parts.push(`Intent: ${resource.intent}`);
        if (resource.priority) parts.push(`Priority: ${resource.priority}`);
        if (resource.dosageInstruction?.[0]) {
          const dosage = resource.dosageInstruction[0];
          if (dosage.text) {
            parts.push(`Dosage Instructions: ${dosage.text}`);
          }
          if (dosage.route?.coding?.[0]?.display) {
            parts.push(`Route: ${dosage.route.coding[0].display}`);
          }
        }
        break;

      case 'allergyintolerance':
        if (resource.code?.text || resource.code?.coding?.[0]?.display) {
          parts.push(`Allergen: ${resource.code.text || resource.code.coding[0].display}`);
        }
        if (resource.clinicalStatus?.coding?.[0]?.code) {
          parts.push(`Clinical Status: ${resource.clinicalStatus.coding[0].code}`);
        }
        if (resource.verificationStatus?.coding?.[0]?.code) {
          parts.push(`Verification: ${resource.verificationStatus.coding[0].code}`);
        }
        if (resource.type) parts.push(`Type: ${resource.type}`);
        if (resource.category?.[0]) parts.push(`Category: ${resource.category[0]}`);
        if (resource.criticality) parts.push(`Criticality: ${resource.criticality}`);
        
        // Reactions
        if (resource.reaction?.[0]) {
          const reaction = resource.reaction[0];
          if (reaction.manifestation?.[0]?.coding?.[0]?.display) {
            parts.push(`Reaction: ${reaction.manifestation[0].coding[0].display}`);
          }
          if (reaction.severity) {
            parts.push(`Reaction Severity: ${reaction.severity}`);
          }
        }
        break;

      case 'encounter':
        if (resource.class?.code || resource.class?.display) {
          parts.push(`Encounter Type: ${resource.class.display || resource.class.code}`);
        }
        if (resource.status) parts.push(`Status: ${resource.status}`);
        if (resource.type?.[0]?.coding?.[0]?.display) {
          parts.push(`Type: ${resource.type[0].coding[0].display}`);
        }
        if (resource.serviceType?.coding?.[0]?.display) {
          parts.push(`Service Type: ${resource.serviceType.coding[0].display}`);
        }
        if (resource.priority?.coding?.[0]?.display) {
          parts.push(`Priority: ${resource.priority.coding[0].display}`);
        }
        break;

      case 'diagnosticreport':
        if (resource.code?.text || resource.code?.coding?.[0]?.display) {
          parts.push(`Report Type: ${resource.code.text || resource.code.coding[0].display}`);
        }
        if (resource.status) parts.push(`Status: ${resource.status}`);
        if (resource.category?.[0]?.coding?.[0]?.display) {
          parts.push(`Category: ${resource.category[0].coding[0].display}`);
        }
        if (resource.conclusion) {
          parts.push(`Conclusion: ${resource.conclusion}`);
        }
        if (resource.conclusionCode?.[0]?.coding?.[0]?.display) {
          parts.push(`Conclusion Code: ${resource.conclusionCode[0].coding[0].display}`);
        }
        break;

      default:
        // Enhanced generic clinical resource handling
        if (resource.code?.text || resource.code?.coding?.[0]?.display) {
          parts.push(`${resourceType}: ${resource.code.text || resource.code.coding[0].display}`);
        }
        if (resource.status) parts.push(`Status: ${resource.status}`);
        if (resource.category?.coding?.[0]?.display) {
          parts.push(`Category: ${resource.category.coding[0].display}`);
        }
    }

    return parts.join(' ');
  }

  private extractClinicalTerms(resource: any, resourceType: string): string[] {
    const terms: string[] = [];

    // Core semantic terms users would search for
    terms.push('clinical', 'clinical details', 'medical', 'medical information');
    terms.push('diagnosis', 'treatment', 'clinical data', 'medical records');
    
    // Resource-specific semantic terms
    switch (resourceType.toLowerCase()) {
      case 'observation':
        terms.push('lab results', 'test results', 'measurements', 'vital signs', 'laboratory');
        break;
      case 'condition':
        terms.push('diagnosis', 'medical condition', 'disease', 'illness', 'health condition');
        terms.push('comorbidities', 'multiple conditions', 'chronic', 'acute', 'active condition');
        break;
      case 'procedure':
        terms.push('surgery', 'procedure', 'medical procedure', 'operation', 'treatment');
        break;
      case 'medicationrequest':
        terms.push('medication', 'prescription', 'drug', 'medicine', 'dosage', 'medication instructions');
        break;
      case 'encounter':
        terms.push('visit', 'appointment', 'hospital visit', 'medical encounter', 'consultation');
        break;
    }

    // Add resource type
    terms.push(resourceType.toLowerCase());

    // Extract coding terms
    if (resource.code?.coding) {
      resource.code.coding.forEach((coding: any) => {
        if (coding.display) terms.push(coding.display);
        if (coding.code) terms.push(coding.code);
      });
    }
    if (resource.code?.text) terms.push(resource.code.text);

    // Add status
    if (resource.status) terms.push(resource.status);

    // Add category
    if (resource.category?.coding) {
      resource.category.coding.forEach((coding: any) => {
        if (coding.display) terms.push(coding.display);
      });
    }

    return terms.filter(Boolean);
  }

  private extractClinicalContext(resource: any, resourceType: string): any {
    return {
      resourceType,
      status: resource.status,
      category: resource.category?.coding?.[0]?.code,
      code: resource.code?.coding?.[0]?.code,
      effectiveDateTime: resource.effectiveDateTime,
      performedDateTime: resource.performedDateTime
    };
  }

  // Administrative resource chunks
  private generateAdministrativeChunks(resource: any, resourceType: string, resourceId: string, patientId: string, patientName: string): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];

    const adminContent = this.generateAdministrativeChunk(resource, resourceType);
    if (adminContent) {
      chunks.push({
        id: uuidv4(),
        content: adminContent,
        metadata: {
          resourceType,
          resourceId,
          patientId,
          patientName,
          chunkType: 'administrative',
          searchableTerms: this.extractAdministrativeTerms(resource, resourceType),
          clinicalContext: {
            resourceType,
            status: resource.status || resource.active
          }
        }
      });
    }

    return chunks;
  }

  private generateAdministrativeChunk(resource: any, resourceType: string): string {
    const parts: string[] = [`${resourceType} Information:`];

    switch (resourceType.toLowerCase()) {
      case 'practitioner':
        if (resource.name?.[0]) {
          const name = resource.name[0];
          const fullName = `${name.given?.join(' ')} ${name.family}`.trim();
          parts.push(`Practitioner: ${fullName}`);
        }
        if (resource.qualification) {
          resource.qualification.forEach((qual: any) => {
            if (qual.code?.text || qual.code?.coding?.[0]?.display) {
              parts.push(`Qualification: ${qual.code.text || qual.code.coding[0].display}`);
            }
          });
        }
        break;

      case 'organization':
        if (resource.name) parts.push(`Organization: ${resource.name}`);
        if (resource.type?.[0]?.coding?.[0]?.display) {
          parts.push(`Type: ${resource.type[0].coding[0].display}`);
        }
        break;

      case 'location':
        if (resource.name) parts.push(`Location: ${resource.name}`);
        if (resource.type?.[0]?.coding?.[0]?.display) {
          parts.push(`Type: ${resource.type[0].coding[0].display}`);
        }
        if (resource.address) {
          const addr = resource.address;
          const location = [addr.city, addr.state].filter(Boolean).join(', ');
          if (location) parts.push(`Address: ${location}`);
        }
        break;

      default:
        if (resource.name) parts.push(`${resourceType}: ${resource.name}`);
        if (resource.status) parts.push(`Status: ${resource.status}`);
    }

    return parts.join(' ');
  }

  private extractAdministrativeTerms(resource: any, resourceType: string): string[] {
    const terms: string[] = [];

    // Core semantic terms users would search for
    terms.push('administrative', 'healthcare provider', 'provider information');
    terms.push('staff', 'healthcare staff', 'medical staff', 'admin');
    
    // Resource-specific semantic terms
    switch (resourceType.toLowerCase()) {
      case 'practitioner':
        terms.push('doctor', 'physician', 'provider', 'practitioner', 'clinician', 'healthcare provider');
        break;
      case 'organization':
        terms.push('hospital', 'clinic', 'healthcare organization', 'medical facility', 'organization');
        break;
      case 'location':
        terms.push('facility', 'location', 'medical facility', 'healthcare facility', 'address');
        break;
      case 'appointment':
        terms.push('appointment', 'schedule', 'booking', 'scheduled visit', 'appointment info');
        break;
      case 'task':
        terms.push('task', 'care task', 'healthcare task', 'workflow', 'assignment');
        break;
    }

    // Add resource type
    terms.push(resourceType.toLowerCase());

    if (resource.name) terms.push(resource.name);
    if (resource.status) terms.push(resource.status);
    if (resource.type?.coding) {
      resource.type.coding.forEach((coding: any) => {
        if (coding.display) terms.push(coding.display);
      });
    }

    return terms.filter(Boolean);
  }

  // Business resource chunks
  private generateBusinessChunks(resource: any, resourceType: string, resourceId: string, patientId: string, patientName: string): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];

    const businessContent = this.generateBusinessChunk(resource, resourceType);
    if (businessContent) {
      chunks.push({
        id: uuidv4(),
        content: businessContent,
        metadata: {
          resourceType,
          resourceId,
          patientId,
          patientName,
          chunkType: 'financial',
          searchableTerms: this.extractBusinessTerms(resource, resourceType),
          clinicalContext: {
            resourceType,
            status: resource.status,
            amount: resource.total?.value || resource.amount?.value
          }
        }
      });
    }

    return chunks;
  }

  private generateBusinessChunk(resource: any, resourceType: string): string {
    const parts: string[] = [`${resourceType} Financial Information:`];

    switch (resourceType.toLowerCase()) {
      case 'account':
        if (resource.name) parts.push(`Account Name: ${resource.name}`);
        if (resource.status) parts.push(`Account Status: ${resource.status}`);
        if (resource.type?.coding?.[0]?.display) {
          parts.push(`Account Type: ${resource.type.coding[0].display}`);
        }
        if (resource.description) parts.push(`Description: ${resource.description}`);
        // Handle both FHIR standard and custom balance formats
        if (resource.balance?.value) {
          parts.push(`Balance: ${resource.balance.value} ${resource.balance.currency || 'USD'}`);
        } else if (resource.balance !== undefined) {
          parts.push(`Balance: ${resource.balance} ${resource.currencyCode || 'USD'}`);
        }
        if (resource.accountNumber) {
          parts.push(`Account Number: ${resource.accountNumber}`);
        }
        if (resource.servicePeriod) {
          parts.push(`Service Period: ${resource.servicePeriod.start} to ${resource.servicePeriod.end || 'ongoing'}`);
        }
        break;

      case 'invoice':
        // Handle both identifier array and direct invoiceNumber
        if (resource.identifier?.[0]?.value) {
          parts.push(`Invoice Number: ${resource.identifier[0].value}`);
        } else if (resource.invoiceNumber) {
          parts.push(`Invoice Number: ${resource.invoiceNumber}`);
        }
        if (resource.status) parts.push(`Invoice Status: ${resource.status}`);
        if (resource.date) parts.push(`Invoice Date: ${resource.date}`);
        if (resource.totalNet?.value) {
          parts.push(`Total Amount: ${resource.totalNet.value} ${resource.totalNet.currency || 'USD'}`);
        }
        if (resource.totalGross?.value) {
          parts.push(`Gross Amount: ${resource.totalGross.value} ${resource.totalGross.currency || 'USD'}`);
        }
        if (resource.totalTax?.value) {
          parts.push(`Tax Amount: ${resource.totalTax.value} ${resource.totalTax.currency || 'USD'}`);
        }
        if (resource.paymentTerms) {
          parts.push(`Payment Terms: ${resource.paymentTerms}`);
        }
        // Include line items summary with more detail
        if (resource.lineItem?.length > 0) {
          parts.push(`Line Items: ${resource.lineItem.length} items`);
          // Add first line item detail as example
          const firstItem = resource.lineItem[0];
          if (firstItem.priceComponent?.[0]?.amount?.value) {
            parts.push(`First item: ${firstItem.priceComponent[0].amount.value} ${firstItem.priceComponent[0].amount.currency || 'USD'}`);
          }
        }
        break;

      case 'claim':
        if (resource.identifier?.[0]?.value) {
          parts.push(`Claim Number: ${resource.identifier[0].value}`);
        }
        if (resource.status) parts.push(`Claim Status: ${resource.status}`);
        if (resource.type?.coding?.[0]?.display) {
          parts.push(`Claim Type: ${resource.type.coding[0].display}`);
        }
        if (resource.use) parts.push(`Claim Use: ${resource.use}`);
        if (resource.total?.value) {
          parts.push(`Total Claim Amount: ${resource.total.value} ${resource.total.currency || 'USD'}`);
        }
        if (resource.created) parts.push(`Submitted Date: ${resource.created}`);
        if (resource.billablePeriod) {
          parts.push(`Billable Period: ${resource.billablePeriod.start} to ${resource.billablePeriod.end}`);
        }
        if (resource.diagnosis?.length > 0) {
          parts.push(`Diagnosis Count: ${resource.diagnosis.length}`);
        }
        break;

      case 'coverage':
        if (resource.identifier?.[0]?.value) {
          parts.push(`Policy Number: ${resource.identifier[0].value}`);
        }
        if (resource.status) parts.push(`Coverage Status: ${resource.status}`);
        if (resource.type?.coding?.[0]?.display) {
          parts.push(`Coverage Type: ${resource.type.coding[0].display}`);
        }
        if (resource.payor?.[0]?.display) {
          parts.push(`Insurance Company: ${resource.payor[0].display}`);
        }
        if (resource.period) {
          parts.push(`Coverage Period: ${resource.period.start} to ${resource.period.end || 'ongoing'}`);
        }
        if (resource.costToBeneficiary) {
          resource.costToBeneficiary.forEach((cost: any) => {
            if (cost.type?.coding?.[0]?.display && cost.valueMoney) {
              parts.push(`${cost.type.coding[0].display}: ${cost.valueMoney.value} ${cost.valueMoney.currency || 'USD'}`);
            }
          });
        }
        break;

      case 'chargeitem':
        if (resource.code?.text || resource.code?.coding?.[0]?.display) {
          parts.push(`Service: ${resource.code.text || resource.code.coding[0].display}`);
        }
        if (resource.status) parts.push(`Charge Status: ${resource.status}`);
        if (resource.quantity?.value) {
          parts.push(`Quantity: ${resource.quantity.value}`);
        }
        if (resource.priceOverride?.value) {
          parts.push(`Price: ${resource.priceOverride.value} ${resource.priceOverride.currency || 'USD'}`);
        }
        if (resource.occurrenceDateTime) {
          parts.push(`Service Date: ${resource.occurrenceDateTime}`);
        }
        break;

      case 'payment':
        if (resource.identifier?.[0]?.value) {
          parts.push(`Payment ID: ${resource.identifier[0].value}`);
        }
        if (resource.status) parts.push(`Payment Status: ${resource.status}`);
        if (resource.amount?.value) {
          parts.push(`Payment Amount: ${resource.amount.value} ${resource.amount.currency || 'USD'}`);
        }
        if (resource.date) parts.push(`Payment Date: ${resource.date}`);
        if (resource.paymentStatus?.coding?.[0]?.display) {
          parts.push(`Processing Status: ${resource.paymentStatus.coding[0].display}`);
        }
        break;

      case 'employee':
        if (resource.name) parts.push(`Employee: ${resource.name}`);
        if (resource.identifier?.[0]?.value) {
          parts.push(`Employee ID: ${resource.identifier[0].value}`);
        }
        if (resource.role) parts.push(`Role: ${resource.role}`);
        if (resource.department) parts.push(`Department: ${resource.department}`);
        if (resource.status) parts.push(`Status: ${resource.status}`);
        break;

      default:
        if (resource.status) parts.push(`Status: ${resource.status}`);
        if (resource.type?.coding?.[0]?.display) {
          parts.push(`Type: ${resource.type.coding[0].display}`);
        }
        if (resource.identifier?.[0]?.value) {
          parts.push(`ID: ${resource.identifier[0].value}`);
        }
    }

    return parts.join(' ');
  }

  private extractBusinessTerms(resource: any, resourceType: string): string[] {
    const terms: string[] = [];
    
    // Core semantic terms users would search for
    terms.push('financial', 'billing', 'payment', 'business', 'finance');
    terms.push('insurance', 'cost', 'charge', 'invoice', 'financial information');
    
    // Resource-specific semantic terms
    switch (resourceType.toLowerCase()) {
      case 'account':
        terms.push('account', 'financial account', 'billing account', 'patient account');
        terms.push('account balance', 'account status', 'financial records');
        break;
      case 'invoice':
        terms.push('invoice', 'bill', 'billing statement', 'medical bill');
        terms.push('charges', 'payment due', 'billing information');
        break;
      case 'claim':
        terms.push('claim', 'insurance claim', 'medical claim', 'reimbursement');
        terms.push('claim status', 'insurance submission', 'coverage');
        break;
      case 'coverage':
        terms.push('coverage', 'insurance coverage', 'insurance plan', 'benefits');
        terms.push('policy', 'insurance policy', 'coverage details');
        break;
      case 'payment':
        terms.push('payment', 'payment record', 'transaction', 'financial transaction');
        terms.push('payment status', 'payment amount', 'remittance');
        break;
      case 'chargeitem':
        terms.push('charge', 'charge item', 'service charge', 'medical charge');
        terms.push('billing code', 'charge amount', 'service cost');
        break;
      case 'employee':
        terms.push('employee', 'staff member', 'healthcare worker', 'personnel');
        terms.push('employee record', 'staff information', 'workforce');
        break;
    }
    
    // Add resource type
    terms.push(resourceType.toLowerCase());

    // Add status
    if (resource.status) terms.push(resource.status);
    
    // Add type information
    if (resource.type?.coding) {
      resource.type.coding.forEach((coding: any) => {
        if (coding.display) terms.push(coding.display);
      });
    }
    
    // Add amount-related search terms if present
    if (resource.total || resource.totalNet || resource.amount) {
      terms.push('amount', 'total', 'cost amount', 'financial amount');
    }
    
    // Add payor information
    if (resource.payor) {
      terms.push('payor', 'insurance company', 'payer');
    }

    return terms.filter(Boolean);
  }

  // Universal chunk generators
  private generateCodesChunk(resource: any, resourceType: string, resourceId: string, patientId: string, patientName: string): ResourceChunk {
    const parts: string[] = ['Medical Codes:'];
    const codes: string[] = [];

    // Extract all coding information
    if (resource.code?.coding) {
      resource.code.coding.forEach((coding: any) => {
        if (coding.system && coding.code) {
          parts.push(`${coding.system}: ${coding.code} - ${coding.display || 'No description'}`);
          codes.push(coding.code, coding.display);
        }
      });
    }

    if (resource.category?.coding) {
      resource.category.coding.forEach((coding: any) => {
        if (coding.system && coding.code) {
          parts.push(`Category ${coding.system}: ${coding.code} - ${coding.display || 'No description'}`);
          codes.push(coding.code, coding.display);
        }
      });
    }

    return {
      id: uuidv4(),
      content: parts.join(' '),
      metadata: {
        resourceType,
        resourceId,
        patientId,
        patientName,
        chunkType: 'codes',
        searchableTerms: [
          // Core semantic terms users would search for
          'codes', 'medical codes', 'coding', 'medical coding', 'diagnosis codes',
          'procedure codes', 'billing codes', 'icd', 'cpt', 'snomed', 'loinc',
          'classification', 'medical classification', 'code lookup',
          
          // Include actual codes and displays
          ...codes.filter(Boolean)
        ],
        clinicalContext: {
          codesCount: codes.length,
          systems: resource.code?.coding?.map((c: any) => c.system).filter(Boolean) || []
        }
      }
    };
  }

  private generateTemporalChunk(resource: any, resourceType: string, resourceId: string, patientId: string, patientName: string): ResourceChunk {
    const parts: string[] = ['Timeline Information:'];
    const dates: string[] = [];

    // Extract temporal information
    if (resource.effectiveDateTime) {
      parts.push(`Effective Date: ${resource.effectiveDateTime}`);
      dates.push(resource.effectiveDateTime);
    }
    if (resource.performedDateTime) {
      parts.push(`Performed Date: ${resource.performedDateTime}`);
      dates.push(resource.performedDateTime);
    }
    if (resource.period) {
      if (resource.period.start) {
        parts.push(`Start Date: ${resource.period.start}`);
        dates.push(resource.period.start);
      }
      if (resource.period.end) {
        parts.push(`End Date: ${resource.period.end}`);
        dates.push(resource.period.end);
      }
    }
    if (resource.authoredOn) {
      parts.push(`Authored On: ${resource.authoredOn}`);
      dates.push(resource.authoredOn);
    }

    return {
      id: uuidv4(),
      content: parts.join(' '),
      metadata: {
        resourceType,
        resourceId,
        patientId,
        patientName,
        chunkType: 'temporal',
        searchableTerms: [
          // Core semantic terms users would search for
          'temporal', 'timeline', 'date', 'time', 'schedule', 'scheduling',
          'appointment', 'when', 'timing', 'chronology', 'timeline information',
          'date information', 'time information', 'schedule information',
          
          // Enhanced relative time terms
          'recent', 'latest', 'last', 'most recent', 'current', 'previous',
          'last visit', 'recent visit', 'latest appointment', 'recent encounter',
          'today', 'yesterday', 'this week', 'last week', 'this month', 'last month',
          
          // Extract years and meaningful date context
          ...dates.map(d => new Date(d).getFullYear().toString()).filter(Boolean),
          ...dates.map(d => {
            const date = new Date(d);
            const month = date.toLocaleString('default', { month: 'long' });
            return `${month} ${date.getFullYear()}`;
          }).filter(Boolean)
        ].filter(Boolean),
        clinicalContext: {
          hasEffectiveDate: !!resource.effectiveDateTime,
          hasPerformedDate: !!resource.performedDateTime,
          hasPeriod: !!resource.period
        }
      }
    };
  }

  // Cross-Resource Relationship Chunks
  private generateRelationshipChunks(resource: any, resourceType: string, resourceId: string, patientId: string, patientName: string, event: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Only generate relationship chunks for non-Patient resources
    if (resourceType.toLowerCase() === 'patient') {
      return chunks;
    }

    const relationships = this.extractResourceRelationships(resource, resourceType);
    
    if (relationships.length === 0) {
      return chunks;
    }

    // Generate comprehensive relationship chunk
    const relationshipContent = this.generateRelationshipContent(resource, resourceType, relationships, patientName);
    
    if (relationshipContent) {
      chunks.push({
        id: uuidv4(),
        content: relationshipContent,
        metadata: {
          resourceType,
          resourceId,
          patientId,
          patientName,
          chunkType: 'relationship',
          searchableTerms: this.generateRelationshipSearchTerms(resource, resourceType, relationships),
          clinicalContext: {
            resourceType,
            relationshipCount: relationships.length,
            primaryRelationships: relationships.map(r => r.relationship)
          },
          relationships: {
            relatedResources: relationships
          }
        }
      });
    }

    return chunks;
  }

  private extractResourceRelationships(resource: any, resourceType: string): Array<{resourceType: string, resourceId: string, relationship: string}> {
    const relationships: Array<{resourceType: string, resourceId: string, relationship: string}> = [];

    // Extract references from the resource
    const extractReference = (ref: string | any, relationship: string) => {
      if (typeof ref === 'string' && ref.includes('/')) {
        const [refType, refId] = ref.split('/');
        relationships.push({
          resourceType: refType,
          resourceId: refId,
          relationship
        });
      } else if (ref?.reference && ref.reference.includes('/')) {
        const [refType, refId] = ref.reference.split('/');
        relationships.push({
          resourceType: refType,
          resourceId: refId,
          relationship
        });
      }
    };

    // Common FHIR reference patterns
    if (resource.subject) extractReference(resource.subject, 'patient');
    if (resource.encounter) extractReference(resource.encounter, 'encounter');
    if (resource.performer) {
      if (Array.isArray(resource.performer)) {
        resource.performer.forEach((p: any) => extractReference(p, 'performer'));
      } else {
        extractReference(resource.performer, 'performer');
      }
    }
    if (resource.requester) extractReference(resource.requester, 'requester');
    if (resource.practitioner) extractReference(resource.practitioner, 'practitioner');
    if (resource.organization) extractReference(resource.organization, 'organization');
    if (resource.location) extractReference(resource.location, 'location');
    
    // Condition-specific relationships
    if (resourceType.toLowerCase() === 'condition') {
      if (resource.asserter) extractReference(resource.asserter, 'asserter');
      if (resource.encounter) extractReference(resource.encounter, 'related_encounter');
    }

    // Observation-specific relationships
    if (resourceType.toLowerCase() === 'observation') {
      if (resource.basedOn) {
        if (Array.isArray(resource.basedOn)) {
          resource.basedOn.forEach((b: any) => extractReference(b, 'based_on'));
        } else {
          extractReference(resource.basedOn, 'based_on');
        }
      }
      if (resource.derivedFrom) {
        if (Array.isArray(resource.derivedFrom)) {
          resource.derivedFrom.forEach((d: any) => extractReference(d, 'derived_from'));
        } else {
          extractReference(resource.derivedFrom, 'derived_from');
        }
      }
    }

    // Encounter-specific relationships
    if (resourceType.toLowerCase() === 'encounter') {
      if (resource.participant) {
        resource.participant.forEach((p: any) => {
          if (p.individual) extractReference(p.individual, 'participant');
        });
      }
      if (resource.serviceProvider) extractReference(resource.serviceProvider, 'service_provider');
    }

    return relationships;
  }

  private generateRelationshipContent(resource: any, resourceType: string, relationships: Array<{resourceType: string, resourceId: string, relationship: string}>, patientName: string): string {
    const parts: string[] = [];
    
    // Start with patient relationship context
    parts.push(`This ${resourceType.toLowerCase()} for patient ${patientName} is connected to multiple healthcare resources.`);
    
    // Add resource-specific relationship descriptions
    switch (resourceType.toLowerCase()) {
      case 'observation':
        parts.push(`This lab result or clinical observation was`);
        break;
      case 'condition':
        parts.push(`This medical condition or diagnosis was`);
        break;
      case 'procedure':
        parts.push(`This medical procedure was`);
        break;
      case 'medicationrequest':
        parts.push(`This medication prescription was`);
        break;
      case 'encounter':
        parts.push(`This patient visit or encounter involved`);
        break;
      case 'immunization':
        parts.push(`This vaccination was`);
        break;
      default:
        parts.push(`This healthcare record was`);
    }

    // Describe relationships in natural language
    const encounterRels = relationships.filter(r => r.relationship === 'encounter');
    const practitionerRels = relationships.filter(r => r.relationship === 'performer' || r.relationship === 'requester' || r.relationship === 'practitioner');
    const organizationRels = relationships.filter(r => r.relationship === 'organization' || r.relationship === 'service_provider');

    if (encounterRels.length > 0) {
      parts.push(`performed during healthcare encounter ${encounterRels[0].resourceId}.`);
    }

    if (practitionerRels.length > 0) {
      parts.push(`The healthcare provider involved was practitioner ${practitionerRels[0].resourceId}.`);
    }

    if (organizationRels.length > 0) {
      parts.push(`This was provided by healthcare organization ${organizationRels[0].resourceId}.`);
    }

    // Add temporal context for procedures/results
    if (resource.effectiveDateTime || resource.performedDateTime) {
      const date = resource.effectiveDateTime || resource.performedDateTime;
      parts.push(`This healthcare event occurred on ${date}.`);
    }

    // Add clinical significance context
    if (resourceType.toLowerCase() === 'observation' && resource.interpretation) {
      parts.push(`The clinical significance is ${resource.interpretation[0]?.coding?.[0]?.display || 'normal'}.`);
    }

    if (resourceType.toLowerCase() === 'condition' && resource.clinicalStatus) {
      parts.push(`The condition status is ${resource.clinicalStatus.coding?.[0]?.code || 'active'}.`);
    }

    parts.push(`This ${resourceType.toLowerCase()} is part of the patient's comprehensive healthcare record and care coordination.`);

    return parts.join(' ');
  }

  private generateRelationshipSearchTerms(resource: any, resourceType: string, relationships: Array<{resourceType: string, resourceId: string, relationship: string}>): string[] {
    const terms: string[] = [];
    
    // Core relationship terms
    terms.push('relationship', 'connected', 'related', 'linked', 'associated');
    terms.push('care coordination', 'healthcare team', 'comprehensive care');
    terms.push('multi-resource', 'cross-reference', 'clinical relationship');
    
    // Resource type combinations
    terms.push(`${resourceType.toLowerCase()} relationship`);
    
    // Relationship-specific terms
    const relationshipTypes = [...new Set(relationships.map(r => r.relationship))];
    relationshipTypes.forEach(rel => {
      switch (rel) {
        case 'encounter':
          terms.push('visit', 'encounter', 'during visit', 'hospital visit');
          break;
        case 'performer':
        case 'practitioner':
        case 'requester':
          terms.push('provider', 'doctor', 'practitioner', 'healthcare provider');
          break;
        case 'organization':
        case 'service_provider':
          terms.push('hospital', 'clinic', 'healthcare organization', 'facility');
          break;
      }
    });

    // Clinical workflow terms
    terms.push('care team', 'healthcare workflow', 'clinical process');
    terms.push('patient care', 'treatment team', 'medical team');
    
    // Multi-resource query terms
    terms.push('procedures performed', 'labs and encounters', 'medications and visits');
    terms.push('recent procedures', 'visit history', 'care timeline');

    return terms.filter(Boolean);
  }

  // Updated helper methods
  private generateIdentifiersChunk(resource: FHIRResource, resourceType: string, resourceId: string, patientId: string, patientName: string): ResourceChunk {
    const parts: string[] = ['Identifiers:'];
    
    resource.identifier?.forEach((id: any) => {
      const type = id.type?.coding?.[0]?.display || id.type?.text || 'ID';
      const system = id.system ? ` (${id.system.split('/').pop()})` : '';
      parts.push(`${type}${system}: ${id.value}`);
    });

    return {
      id: uuidv4(),
      content: parts.join(' '),
      metadata: {
        resourceType,
        resourceId,
        patientId,
        patientName,
        chunkType: 'identifiers',
        searchableTerms: resource.identifier?.map((id: any) => id.value).filter(Boolean) || [],
        clinicalContext: {
          identifierCount: resource.identifier?.length || 0
        }
      }
    };
  }

  private generateContactChunk(resource: FHIRResource, resourceType: string, resourceId: string, patientId: string, patientName: string): ResourceChunk {
    const parts: string[] = ['Contact Information:'];
    
    // Phone numbers with enhanced descriptions
    const phones = resource.telecom?.filter((t: any) => t.system === 'phone') || [];
    phones.forEach((phone: any) => {
      const use = phone.use ? ` (${phone.use})` : '';
      parts.push(`Phone${use}: ${phone.value}`);
      parts.push(`${phone.use || 'Phone'} number ${phone.value}`);
      parts.push(`Contact phone ${phone.value}`);
    });
    
    // Email addresses with enhanced descriptions
    const emails = resource.telecom?.filter((t: any) => t.system === 'email') || [];
    emails.forEach((email: any) => {
      const use = email.use ? ` (${email.use})` : '';
      parts.push(`Email${use}: ${email.value}`);
      parts.push(`${email.use || 'Email'} address ${email.value}`);
      parts.push(`Contact email ${email.value}`);
    });
    
    // Addresses with enhanced descriptions
    resource.address?.forEach((addr: any) => {
      const use = addr.use ? ` (${addr.use})` : '';
      const addrParts = [
        ...(addr.line || []),
        addr.city,
        addr.state,
        addr.postalCode
      ].filter(Boolean);
      parts.push(`Address${use}: ${addrParts.join(', ')}`);
      parts.push(`${addr.use || 'Address'} location ${addrParts.join(', ')}`);
      if (addr.city) parts.push(`Lives in ${addr.city}`);
      if (addr.state) parts.push(`Resides in ${addr.state}`);
    });

    // Add general contact descriptors
    if (phones.length > 0) {
      parts.push('Has phone contact information');
      parts.push('Phone number available');
    }
    if (emails.length > 0) {
      parts.push('Has email contact information');
      parts.push('Email address available');
    }
    if (resource.address && resource.address.length > 0) {
      parts.push('Has address information');
      parts.push('Residential address available');
    }

    return {
      id: uuidv4(),
      content: parts.join(' '),
      metadata: {
        resourceType,
        resourceId,
        patientId,
        patientName,
        chunkType: 'contact',
        searchableTerms: [
          // Core semantic terms users would search for
          'contact', 'contact information', 'patient contact', 'contact details',
          'phone', 'telephone', 'phone number', 'mobile', 'cell phone',
          'email', 'email address', 'electronic mail',
          'address', 'home address', 'residential address', 'location',
          'contact info', 'how to reach', 'communication',
          
          // Actual contact values
          ...(resource.telecom || []).map((t: any) => t.value).filter(Boolean),
          ...(resource.telecom || []).map((t: any) => t.system).filter(Boolean),
          ...(resource.address || []).map((a: any) => a.city).filter(Boolean),
          ...(resource.address || []).map((a: any) => a.state).filter(Boolean),
          ...(resource.address || []).map((a: any) => `${a.city} ${a.state}`).filter(Boolean)
        ],
        clinicalContext: {
          hasPhone: !!(resource.telecom?.some((t: any) => t.system === 'phone')),
          hasEmail: !!(resource.telecom?.some((t: any) => t.system === 'email')),
          hasAddress: !!(resource.address && resource.address.length > 0)
        }
      }
    };
  }

  private extractSearchableTerms(resource: FHIRResource, resourceType: string): string[] {
    const terms: string[] = [];
    
    // Add core semantic terms based on resource type
    const normalizedType = resourceType.toLowerCase();
    
    // Universal healthcare search terms
    terms.push('healthcare', 'medical', 'health', 'clinical');
    
    // Resource type specific semantic terms
    switch (normalizedType) {
      case 'patient':
        terms.push('patient', 'patient information', 'patient data', 'patient record');
        terms.push('demographics', 'personal information', 'patient demographics');
        break;
      case 'observation':
        terms.push('observation', 'lab result', 'test result', 'measurement', 'vital signs');
        terms.push('clinical observation', 'medical test');
        break;
      case 'condition':
        terms.push('condition', 'diagnosis', 'disease', 'illness', 'medical condition');
        terms.push('health condition', 'patient condition');
        break;
      case 'medicationrequest':
        terms.push('medication', 'prescription', 'drug', 'medicine', 'pharmaceutical');
        terms.push('medication request', 'prescription order');
        break;
      case 'encounter':
        terms.push('encounter', 'visit', 'appointment', 'consultation', 'medical visit');
        terms.push('hospital visit', 'clinical encounter');
        break;
      case 'appointment':
        terms.push('appointment', 'schedule', 'booking', 'scheduled visit');
        terms.push('medical appointment', 'healthcare appointment');
        break;
      case 'practitioner':
        terms.push('practitioner', 'doctor', 'physician', 'provider', 'clinician');
        terms.push('healthcare provider', 'medical professional');
        break;
      case 'organization':
        terms.push('organization', 'hospital', 'clinic', 'facility', 'medical center');
        terms.push('healthcare organization', 'medical facility');
        break;
      case 'account':
        terms.push('account', 'billing account', 'financial account', 'patient account');
        terms.push('billing', 'financial', 'account information');
        break;
      case 'invoice':
        terms.push('invoice', 'bill', 'medical bill', 'billing statement');
        terms.push('charges', 'billing', 'financial', 'outstanding', 'unpaid', 'due', 'payment due');
        terms.push('outstanding bill', 'unpaid invoice', 'amount due');
        break;
      case 'claim':
        terms.push('claim', 'insurance claim', 'medical claim', 'reimbursement');
        terms.push('insurance', 'billing', 'financial');
        break;
      case 'coverage':
        terms.push('coverage', 'insurance', 'insurance coverage', 'insurance plan');
        terms.push('benefits', 'policy', 'financial');
        break;
      case 'chargeitem':
        terms.push('charge', 'charge item', 'billing code', 'service charge');
        terms.push('cost', 'billing', 'financial');
        break;
      default:
        terms.push(normalizedType, `${normalizedType} record`, `${normalizedType} information`);
    }
    
    // Add resource type
    terms.push(normalizedType);
    
    // Add patient name
    if (resource.name) {
      resource.name.forEach((n: any) => {
        if (n.given) terms.push(...n.given);
        if (n.family) terms.push(n.family);
      });
    }
    
    // Add identifiers
    if (resource.identifier) {
      resource.identifier.forEach((id: any) => {
        if (id.value) terms.push(id.value);
      });
    }
    
    // Add location
    if (resource.address) {
      resource.address.forEach((addr: any) => {
        if (addr.city) terms.push(addr.city);
        if (addr.state) terms.push(addr.state);
      });
    }

    // Add clinical codes
    if (resource.code?.coding) {
      resource.code.coding.forEach((coding: any) => {
        if (coding.display) terms.push(coding.display);
        if (coding.code) terms.push(coding.code);
      });
    }

    return terms.filter(Boolean);
  }
}