import * as fs from 'fs';
import * as path from 'path';

interface Config {
  grpc: {
    port: number;
  };
  metrics: {
    port: number;
  };
  embeddings: {
    host: string;
    port: number;
  };
  qdrant: {
    host: string;
    port: number;
    collections: {
      fhir_chunks: {
        vectorSize: number;
        distance: 'Cosine' | 'Euclid' | 'Dot';
      };
    };
  };
  kafka: {
    brokers: string[];
    groupId: string;
    topics: string[];
    sessionTimeout: number;
    rebalanceTimeout: number;
  };
}

function loadConfig(): Config {
  // Check for config file path
  const configPath = process.env.CONFIG_PATH || path.join(__dirname, '../config/config.json');
  
  // Default configuration
  const defaultConfig: Config = {
    grpc: {
      port: parseInt(process.env.GRPC_PORT || '50052')
    },
    metrics: {
      port: parseInt(process.env.METRICS_PORT || '8001')
    },
    embeddings: {
      host: process.env.EMBEDDINGS_HOST || 'embeddings-service',
      port: parseInt(process.env.EMBEDDINGS_PORT || '50051')
    },
    qdrant: {
      host: process.env.QDRANT_HOST || 'qdrant',
      port: parseInt(process.env.QDRANT_PORT || '6333'),
      collections: {
        fhir_chunks: {
          vectorSize: 1024, // BGE-M3 default size
          distance: 'Cosine'
        }
      }
    },
    kafka: {
      brokers: (process.env.KAFKA_BROKERS || 'kafka-0.kafka-headless:9092').split(','),
      groupId: process.env.KAFKA_GROUP_ID || 'fhir-rag-processor',
      topics: (process.env.KAFKA_TOPICS || 'fhir.events').split(','),
      sessionTimeout: parseInt(process.env.KAFKA_SESSION_TIMEOUT || '30000'),
      rebalanceTimeout: parseInt(process.env.KAFKA_REBALANCE_TIMEOUT || '60000')
    }
  };

  // Try to load config file
  if (fs.existsSync(configPath)) {
    try {
      const fileConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      return { ...defaultConfig, ...fileConfig };
    } catch (error) {
      console.error(`Failed to load config from ${configPath}:`, error);
      console.log('Using default configuration');
    }
  }

  return defaultConfig;
}

export const config = loadConfig();