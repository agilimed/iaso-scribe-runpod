// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('@grpc/grpc-js');
var rag_pb = require('./rag_pb.js');

function serialize_nexuscare_rag_BatchEmbeddingRequest(arg) {
  if (!(arg instanceof rag_pb.BatchEmbeddingRequest)) {
    throw new Error('Expected argument of type nexuscare.rag.BatchEmbeddingRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_nexuscare_rag_BatchEmbeddingRequest(buffer_arg) {
  return rag_pb.BatchEmbeddingRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_nexuscare_rag_BatchEmbeddingResponse(arg) {
  if (!(arg instanceof rag_pb.BatchEmbeddingResponse)) {
    throw new Error('Expected argument of type nexuscare.rag.BatchEmbeddingResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_nexuscare_rag_BatchEmbeddingResponse(buffer_arg) {
  return rag_pb.BatchEmbeddingResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_nexuscare_rag_ChunkList(arg) {
  if (!(arg instanceof rag_pb.ChunkList)) {
    throw new Error('Expected argument of type nexuscare.rag.ChunkList');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_nexuscare_rag_ChunkList(buffer_arg) {
  return rag_pb.ChunkList.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_nexuscare_rag_EmbeddingRequest(arg) {
  if (!(arg instanceof rag_pb.EmbeddingRequest)) {
    throw new Error('Expected argument of type nexuscare.rag.EmbeddingRequest');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_nexuscare_rag_EmbeddingRequest(buffer_arg) {
  return rag_pb.EmbeddingRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_nexuscare_rag_EmbeddingResponse(arg) {
  if (!(arg instanceof rag_pb.EmbeddingResponse)) {
    throw new Error('Expected argument of type nexuscare.rag.EmbeddingResponse');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_nexuscare_rag_EmbeddingResponse(buffer_arg) {
  return rag_pb.EmbeddingResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_nexuscare_rag_Empty(arg) {
  if (!(arg instanceof rag_pb.Empty)) {
    throw new Error('Expected argument of type nexuscare.rag.Empty');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_nexuscare_rag_Empty(buffer_arg) {
  return rag_pb.Empty.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_nexuscare_rag_FHIREvent(arg) {
  if (!(arg instanceof rag_pb.FHIREvent)) {
    throw new Error('Expected argument of type nexuscare.rag.FHIREvent');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_nexuscare_rag_FHIREvent(buffer_arg) {
  return rag_pb.FHIREvent.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_nexuscare_rag_FHIRResource(arg) {
  if (!(arg instanceof rag_pb.FHIRResource)) {
    throw new Error('Expected argument of type nexuscare.rag.FHIRResource');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_nexuscare_rag_FHIRResource(buffer_arg) {
  return rag_pb.FHIRResource.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_nexuscare_rag_HealthStatus(arg) {
  if (!(arg instanceof rag_pb.HealthStatus)) {
    throw new Error('Expected argument of type nexuscare.rag.HealthStatus');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_nexuscare_rag_HealthStatus(buffer_arg) {
  return rag_pb.HealthStatus.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_nexuscare_rag_ModelInfo(arg) {
  if (!(arg instanceof rag_pb.ModelInfo)) {
    throw new Error('Expected argument of type nexuscare.rag.ModelInfo');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_nexuscare_rag_ModelInfo(buffer_arg) {
  return rag_pb.ModelInfo.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_nexuscare_rag_ProcessingResult(arg) {
  if (!(arg instanceof rag_pb.ProcessingResult)) {
    throw new Error('Expected argument of type nexuscare.rag.ProcessingResult');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_nexuscare_rag_ProcessingResult(buffer_arg) {
  return rag_pb.ProcessingResult.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_nexuscare_rag_RAGQuery(arg) {
  if (!(arg instanceof rag_pb.RAGQuery)) {
    throw new Error('Expected argument of type nexuscare.rag.RAGQuery');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_nexuscare_rag_RAGQuery(buffer_arg) {
  return rag_pb.RAGQuery.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_nexuscare_rag_RAGQueryResult(arg) {
  if (!(arg instanceof rag_pb.RAGQueryResult)) {
    throw new Error('Expected argument of type nexuscare.rag.RAGQueryResult');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_nexuscare_rag_RAGQueryResult(buffer_arg) {
  return rag_pb.RAGQueryResult.deserializeBinary(new Uint8Array(buffer_arg));
}


// Service definitions
var EmbeddingServiceService = exports.EmbeddingServiceService = {
  // Generate embeddings for a single text
generateEmbedding: {
    path: '/nexuscare.rag.EmbeddingService/GenerateEmbedding',
    requestStream: false,
    responseStream: false,
    requestType: rag_pb.EmbeddingRequest,
    responseType: rag_pb.EmbeddingResponse,
    requestSerialize: serialize_nexuscare_rag_EmbeddingRequest,
    requestDeserialize: deserialize_nexuscare_rag_EmbeddingRequest,
    responseSerialize: serialize_nexuscare_rag_EmbeddingResponse,
    responseDeserialize: deserialize_nexuscare_rag_EmbeddingResponse,
  },
  // Generate embeddings for multiple texts (batch)
generateEmbeddings: {
    path: '/nexuscare.rag.EmbeddingService/GenerateEmbeddings',
    requestStream: false,
    responseStream: false,
    requestType: rag_pb.BatchEmbeddingRequest,
    responseType: rag_pb.BatchEmbeddingResponse,
    requestSerialize: serialize_nexuscare_rag_BatchEmbeddingRequest,
    requestDeserialize: deserialize_nexuscare_rag_BatchEmbeddingRequest,
    responseSerialize: serialize_nexuscare_rag_BatchEmbeddingResponse,
    responseDeserialize: deserialize_nexuscare_rag_BatchEmbeddingResponse,
  },
  // Get model information
getModelInfo: {
    path: '/nexuscare.rag.EmbeddingService/GetModelInfo',
    requestStream: false,
    responseStream: false,
    requestType: rag_pb.Empty,
    responseType: rag_pb.ModelInfo,
    requestSerialize: serialize_nexuscare_rag_Empty,
    requestDeserialize: deserialize_nexuscare_rag_Empty,
    responseSerialize: serialize_nexuscare_rag_ModelInfo,
    responseDeserialize: deserialize_nexuscare_rag_ModelInfo,
  },
  // Health check
healthCheck: {
    path: '/nexuscare.rag.EmbeddingService/HealthCheck',
    requestStream: false,
    responseStream: false,
    requestType: rag_pb.Empty,
    responseType: rag_pb.HealthStatus,
    requestSerialize: serialize_nexuscare_rag_Empty,
    requestDeserialize: deserialize_nexuscare_rag_Empty,
    responseSerialize: serialize_nexuscare_rag_HealthStatus,
    responseDeserialize: deserialize_nexuscare_rag_HealthStatus,
  },
};

exports.EmbeddingServiceClient = grpc.makeGenericClientConstructor(EmbeddingServiceService, 'EmbeddingService');
var RAGProcessorServiceService = exports.RAGProcessorServiceService = {
  // Process a FHIR resource event
processFHIREvent: {
    path: '/nexuscare.rag.RAGProcessorService/ProcessFHIREvent',
    requestStream: false,
    responseStream: false,
    requestType: rag_pb.FHIREvent,
    responseType: rag_pb.ProcessingResult,
    requestSerialize: serialize_nexuscare_rag_FHIREvent,
    requestDeserialize: deserialize_nexuscare_rag_FHIREvent,
    responseSerialize: serialize_nexuscare_rag_ProcessingResult,
    responseDeserialize: deserialize_nexuscare_rag_ProcessingResult,
  },
  // Generate chunks for a FHIR resource
generateChunks: {
    path: '/nexuscare.rag.RAGProcessorService/GenerateChunks',
    requestStream: false,
    responseStream: false,
    requestType: rag_pb.FHIRResource,
    responseType: rag_pb.ChunkList,
    requestSerialize: serialize_nexuscare_rag_FHIRResource,
    requestDeserialize: deserialize_nexuscare_rag_FHIRResource,
    responseSerialize: serialize_nexuscare_rag_ChunkList,
    responseDeserialize: deserialize_nexuscare_rag_ChunkList,
  },
  // Query the RAG system
query: {
    path: '/nexuscare.rag.RAGProcessorService/Query',
    requestStream: false,
    responseStream: false,
    requestType: rag_pb.RAGQuery,
    responseType: rag_pb.RAGQueryResult,
    requestSerialize: serialize_nexuscare_rag_RAGQuery,
    requestDeserialize: deserialize_nexuscare_rag_RAGQuery,
    responseSerialize: serialize_nexuscare_rag_RAGQueryResult,
    responseDeserialize: deserialize_nexuscare_rag_RAGQueryResult,
  },
  // Health check
healthCheck: {
    path: '/nexuscare.rag.RAGProcessorService/HealthCheck',
    requestStream: false,
    responseStream: false,
    requestType: rag_pb.Empty,
    responseType: rag_pb.HealthStatus,
    requestSerialize: serialize_nexuscare_rag_Empty,
    requestDeserialize: deserialize_nexuscare_rag_Empty,
    responseSerialize: serialize_nexuscare_rag_HealthStatus,
    responseDeserialize: deserialize_nexuscare_rag_HealthStatus,
  },
};

exports.RAGProcessorServiceClient = grpc.makeGenericClientConstructor(RAGProcessorServiceService, 'RAGProcessorService');
