# NexusCare Embedding Service

High-performance, offline embedding service for the NexusCare platform. Optimized for healthcare text and FHIR/ClickHouse schema understanding.

## Features

- **100% Offline**: Works in air-gapped environments
- **Multiple Models**: Support for general, medical, and multilingual embeddings
- **High Performance**: ONNX-optimized models with caching
- **Healthcare Optimized**: Includes BioBERT for medical text understanding
- **REST API**: Simple HTTP interface
- **Kubernetes Ready**: Includes deployment manifests

## Quick Start

### Local Development

```bash
# Install dependencies
npm install

# Download models (one-time setup)
npm run download-models

# Start development server
npm run dev
```

### Docker

```bash
# Build image
docker build -t nexuscare-embedding-service .

# Run container
docker run -p 8090:8090 nexuscare-embedding-service
```

## API Endpoints

### Generate Embeddings

```bash
# Single text
curl -X POST http://localhost:8090/api/v1/embed \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Patient has diabetes mellitus type 2"
  }'

# Batch processing
curl -X POST http://localhost:8090/api/v1/embed \
  -H "Content-Type: application/json" \
  -d '{
    "texts": [
      "Blood glucose 126 mg/dL",
      "SELECT * FROM fhir_current WHERE resource_type = 'Observation'"
    ]
  }'
```

### Model Management

```bash
# List available models
curl http://localhost:8090/api/v1/models

# Switch active model
curl -X POST http://localhost:8090/api/v1/models/biobert-base/activate
```

### Health Checks

```bash
# Basic health
curl http://localhost:8090/health

# Readiness check
curl http://localhost:8090/ready
```

## Available Models

1. **all-MiniLM-L6-v2** (Default)
   - Dimensions: 384
   - Speed: ~5ms per embedding
   - Use case: General purpose, real-time queries

2. **biobert-base**
   - Dimensions: 768
   - Speed: ~15ms per embedding
   - Use case: Medical text, clinical notes

3. **bge-base-en**
   - Dimensions: 768
   - Speed: ~12ms per embedding
   - Use case: High quality, document indexing

4. **multilingual-e5-base**
   - Dimensions: 768
   - Speed: ~15ms per embedding
   - Use case: Multi-language support

## Performance

On a 4-core CPU:
- Single embedding: 5-15ms
- Batch processing: 100-300 embeddings/second
- Memory usage: 1-2GB per model

## Kubernetes Deployment

See `/infrastructure/kubernetes/gke-deployment/applications/embedding-service.yaml`

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| PORT | 8090 | Service port |
| DEFAULT_MODEL | all-MiniLM-L6-v2 | Initial model to load |
| MODEL_CACHE_PATH | ./models | Model storage directory |
| MAX_BATCH_SIZE | 100 | Maximum batch size |
| CACHE_ENABLED | true | Enable embedding cache |
| CACHE_TTL | 3600 | Cache TTL in seconds |

## Integration with NexusCare

The embedding service integrates with:
- **Qdrant**: For vector storage
- **LlamaIndex**: For RAG pipeline
- **Backend API**: For conversational analytics

Example integration:

```typescript
// In your backend service
const embeddingResponse = await fetch('http://embedding-service:8090/api/v1/embed', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ text: query })
});

const { embeddings } = await embeddingResponse.json();

// Use with Qdrant
await qdrantClient.upsert({
  collection_name: 'medical_knowledge',
  points: [{
    id: docId,
    vector: embeddings,
    payload: { text, metadata }
  }]
});