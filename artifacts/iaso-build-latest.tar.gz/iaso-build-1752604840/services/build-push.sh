#!/bin/bash
set -e

# Configuration
PROJECT_ID="nexuscare-463413"
SERVICE_NAME="embedding-service"
IMAGE_NAME="gcr.io/${PROJECT_ID}/${SERVICE_NAME}"
TAG="${1:-latest}"

echo "Building and pushing embedding service..."
echo "Image: ${IMAGE_NAME}:${TAG}"

# Build the Docker image
echo "Building Docker image..."
docker build -t ${IMAGE_NAME}:${TAG} .

# Configure docker to use gcloud credentials
echo "Configuring Docker authentication..."
gcloud auth configure-docker

# Push to GCR
echo "Pushing to Google Container Registry..."
docker push ${IMAGE_NAME}:${TAG}

# Update the deployment manifest with the new image
echo "Updating deployment manifest..."
sed -i.bak "s|image: nexuscare-embedding-service:latest|image: ${IMAGE_NAME}:${TAG}|g" \
    ../../infrastructure/kubernetes/gke-deployment/applications/embedding-service.yaml

echo "Build and push completed successfully!"
echo "Image available at: ${IMAGE_NAME}:${TAG}"