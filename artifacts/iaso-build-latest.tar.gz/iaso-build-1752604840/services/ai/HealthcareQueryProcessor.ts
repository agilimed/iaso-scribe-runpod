import { ClickHouseClient } from '@clickhouse/client';
import axios from 'axios';

import { healthcareLogger } from '../monitoring/StructuredLogger';
import { ClickHouseInsightsService } from '../ClickHouseInsightsService';

/**
 * Next-generation healthcare query processor
 * Combines LlamaIndex-style orchestration with SQLCoder for 10x better analytics
 */

// Query intent types specific to healthcare
export enum HealthcareIntent {
  PATIENT_DEMOGRAPHICS = 'patient_demographics',
  CLINICAL_METRICS = 'clinical_metrics',
  OPERATIONAL_ANALYTICS = 'operational_analytics',
  FINANCIAL_INSIGHTS = 'financial_insights',
  QUALITY_MEASURES = 'quality_measures',
  RESEARCH_QUERIES = 'research_queries',
  TEMPORAL_ANALYSIS = 'temporal_analysis'
}

// Enhanced conversation context
export interface ConversationContext {
  sessionId: string;
  userId: string;
  tenantId: string;
  history: QueryInteraction[];
  entities: Map<string, any>;
  currentIntent?: HealthcareIntent;
  clinicalContext?: ClinicalContext;
}

export interface QueryInteraction {
  id: string;
  timestamp: Date;
  query: string;
  intent: HealthcareIntent;
  sql: string;
  results: any[];
  entities: ExtractedEntity[];
  confidence: number;
}

export interface ExtractedEntity {
  type: 'resource' | 'condition' | 'medication' | 'procedure' | 'time' | 'department' | 'metric';
  value: string;
  normalizedValue?: string;
  confidence: number;
}

export interface ClinicalContext {
  department?: string;
  careTeam?: string[];
  activeConditions?: string[];
  timeframe?: { start: Date; end: Date };
}

export class HealthcareQueryProcessor {
  private logger = healthcareLogger;
  private sessions = new Map<string, ConversationContext>();
  private sqlCoderUrl: string;
  private insightsService: ClickHouseInsightsService;
  
  // Healthcare-specific patterns and knowledge
  private readonly FHIR_RELATIONSHIPS = {
    Patient: ['Encounter', 'Observation', 'Condition', 'MedicationRequest'],
    Encounter: ['Patient', 'Practitioner', 'Location', 'Organization'],
    Observation: ['Patient', 'Encounter', 'Practitioner'],
    Condition: ['Patient', 'Encounter'],
    MedicationRequest: ['Patient', 'Encounter', 'Practitioner', 'Medication']
  };

  private readonly CLINICAL_SYNONYMS = {
    'blood pressure': ['bp', 'hypertension', 'systolic', 'diastolic'],
    'diabetes': ['dm', 'diabetic', 'glucose', 'a1c', 'blood sugar'],
    'heart': ['cardiac', 'cardio', 'coronary', 'mi', 'myocardial'],
    'emergency': ['ed', 'er', 'emergency room', 'emergency department'],
    'intensive care': ['icu', 'critical care', 'intensive care unit']
  };

  constructor(clickhouseClient: ClickHouseClient) {
    this.sqlCoderUrl = process.env.SQLCODER_URL || 'https://sqlcoder-endpoint-kt4atarccq-uc.a.run.app';
    this.insightsService = new ClickHouseInsightsService();
  }

  /**
   * Main entry point for processing healthcare queries
   */
  async processQuery(
    query: string,
    sessionId: string,
    userId: string,
    tenantId: string
  ): Promise<any> {
    try {
      // Get or create session
      const session = this.getOrCreateSession(sessionId, userId, tenantId);
      
      // Step 1: Classify intent
      const intent = await this.classifyIntent(query, session);
      
      // Step 2: Extract entities with healthcare context
      const entities = await this.extractHealthcareEntities(query, intent);
      
      // Step 3: Resolve references from conversation history
      const resolvedQuery = this.resolveConversationalReferences(query, session);
      
      // Step 4: Build healthcare-aware context
      const context = await this.buildQueryContext(resolvedQuery, entities, session);
      
      // Step 5: Generate optimized SQL
      const sql = await this.generateHealthcareSQL(resolvedQuery, context, intent);
      
      // Step 6: Execute with hot column optimization
      const results = await this.executeOptimizedQuery(sql, tenantId);
      
      // Step 7: Generate clinical insights
      const insights = await this.generateClinicalInsights(results, intent, entities);
      
      // Step 8: Update conversation history
      this.updateConversation(session, {
        id: `query_${Date.now()}`,
        timestamp: new Date(),
        query,
        intent,
        sql,
        results,
        entities,
        confidence: 0.95
      });
      
      // Step 9: Generate smart follow-up suggestions
      const suggestions = this.generateSmartSuggestions(intent, results, session);
      
      return {
        query,
        interpretation: this.generateInterpretation(query, intent, results),
        sql,
        results,
        insights,
        suggestions,
        visualizationType: this.determineVisualization(intent, results),
        confidence: 0.95,
        context: {
          intent: intent,
          entities: entities,
          sessionId: sessionId
        }
      };
      
    } catch (error) {
      this.logger.error('Healthcare query processing failed', {
        sessionId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Classify query intent using healthcare-specific patterns
   */
  private async classifyIntent(query: string, session: ConversationContext): Promise<HealthcareIntent> {
    const queryLower = query.toLowerCase();
    
    // Clinical metrics patterns
    if (this.containsAny(queryLower, ['vital', 'lab', 'result', 'observation', 'blood', 'glucose', 'pressure'])) {
      return HealthcareIntent.CLINICAL_METRICS;
    }
    
    // Quality measures
    if (this.containsAny(queryLower, ['quality', 'measure', 'compliance', 'readmission', 'mortality', 'safety'])) {
      return HealthcareIntent.QUALITY_MEASURES;
    }
    
    // Financial patterns
    if (this.containsAny(queryLower, ['revenue', 'cost', 'charge', 'billing', 'payment', 'reimbursement'])) {
      return HealthcareIntent.FINANCIAL_INSIGHTS;
    }
    
    // Operational patterns
    if (this.containsAny(queryLower, ['bed', 'occupancy', 'length of stay', 'wait time', 'throughput', 'capacity'])) {
      return HealthcareIntent.OPERATIONAL_ANALYTICS;
    }
    
    // Temporal patterns
    if (this.containsAny(queryLower, ['trend', 'over time', 'last month', 'compare', 'change', 'growth'])) {
      return HealthcareIntent.TEMPORAL_ANALYSIS;
    }
    
    // Research patterns
    if (this.containsAny(queryLower, ['cohort', 'study', 'population', 'correlation', 'outcome'])) {
      return HealthcareIntent.RESEARCH_QUERIES;
    }
    
    // Default to demographics
    return HealthcareIntent.PATIENT_DEMOGRAPHICS;
  }

  /**
   * Extract healthcare-specific entities
   */
  private async extractHealthcareEntities(query: string, intent: HealthcareIntent): Promise<ExtractedEntity[]> {
    const entities: ExtractedEntity[] = [];
    const queryLower = query.toLowerCase();
    
    // Extract FHIR resource types
    for (const resource of Object.keys(this.FHIR_RELATIONSHIPS)) {
      if (queryLower.includes(resource.toLowerCase())) {
        entities.push({
          type: 'resource',
          value: resource,
          confidence: 1.0
        });
      }
    }
    
    // Extract departments
    const departments = ['emergency', 'cardiology', 'maternity', 'icu', 'surgery', 'pediatrics'];
    for (const dept of departments) {
      if (queryLower.includes(dept)) {
        entities.push({
          type: 'department',
          value: dept,
          normalizedValue: this.normalizeDepartment(dept),
          confidence: 0.95
        });
      }
    }
    
    // Extract time expressions
    const timePatterns = [
      { pattern: /last (\d+) (day|week|month|year)s?/, type: 'relative' },
      { pattern: /since (\d{4}-\d{2}-\d{2})/, type: 'absolute' },
      { pattern: /(today|yesterday|this week|this month)/, type: 'named' }
    ];
    
    for (const { pattern, type } of timePatterns) {
      const match = queryLower.match(pattern);
      if (match) {
        entities.push({
          type: 'time',
          value: match[0],
          normalizedValue: this.normalizeTimeExpression(match[0]),
          confidence: 0.9
        });
      }
    }
    
    // Extract clinical conditions using synonyms
    for (const [condition, synonyms] of Object.entries(this.CLINICAL_SYNONYMS)) {
      if (this.containsAny(queryLower, [condition, ...synonyms])) {
        entities.push({
          type: 'condition',
          value: condition,
          confidence: 0.85
        });
      }
    }
    
    return entities;
  }

  /**
   * Generate healthcare-optimized SQL using SQLCoder
   */
  private async generateHealthcareSQL(
    query: string,
    context: any,
    intent: HealthcareIntent
  ): Promise<string> {
    try {
      // Build healthcare-specific prompt
      const prompt = this.buildHealthcarePrompt(query, context, intent);
      
      // Call SQLCoder with enhanced context
      const response = await axios.post(
        `${this.sqlCoderUrl}/generate`,
        {
          prompt: prompt,
          schema_context: this.getRelevantSchema(intent),
          examples: this.getHealthcareExamples(intent),
          instructions: this.getHealthcareInstructions(intent)
        },
        {
          timeout: 30000,
          headers: {
            'Authorization': `Bearer ${process.env.SQLCODER_TOKEN}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      // Validate and optimize the generated SQL
      const sql = response.data.sql;
      return this.optimizeHealthcareSQL(sql, context);
      
    } catch (error) {
      this.logger.error('SQLCoder generation failed', { error: error.message });
      // Fall back to template-based generation
      return this.generateTemplateSQL(query, context, intent);
    }
  }

  /**
   * Build healthcare-specific prompt for SQLCoder
   */
  private buildHealthcarePrompt(query: string, context: any, intent: HealthcareIntent): string {
    let prompt = 'Generate a ClickHouse SQL query for the following healthcare analytics question:\n\n';
    prompt += `Question: ${query}\n\n`;
    
    // Add intent-specific context
    switch (intent) {
      case HealthcareIntent.CLINICAL_METRICS:
        prompt += 'This is a clinical metrics query. Focus on Observation resources and clinical values.\n';
        break;
      case HealthcareIntent.QUALITY_MEASURES:
        prompt += 'This is a quality measure query. Consider outcomes, readmissions, and clinical guidelines.\n';
        break;
      case HealthcareIntent.OPERATIONAL_ANALYTICS:
        prompt += 'This is an operational query. Focus on Encounter resources, bed management, and throughput.\n';
        break;
    }
    
    // Add schema context
    prompt += '\nDatabase: ClickHouse\n';
    prompt += 'Main table: nexuscare_analytics.fhir_current (view with FINAL for latest versions)\n';
    prompt += 'Columns: tenant_id, resource_id, resource_type, resource (JSON), domain, version\n';
    
    // Add FHIR context
    prompt += `\nFHIR Resources available: ${Object.keys(this.FHIR_RELATIONSHIPS).join(', ')}\n`;
    prompt += 'Use JSONExtract functions to query nested FHIR JSON data.\n';
    
    // Add conversation context if available
    if (context.previousQuery) {
      prompt += `\nPrevious query: ${context.previousQuery}\n`;
      prompt += 'Build upon the previous context if relevant.\n';
    }
    
    // Add specific instructions
    prompt += '\nIMPORTANT:\n';
    prompt += `- Always filter by tenant_id = '${context.tenantId}'\n`;
    prompt += '- Use appropriate JSONExtract functions for FHIR paths\n';
    prompt += '- Include proper JOINs for cross-resource queries\n';
    prompt += '- Optimize for ClickHouse performance\n';
    
    return prompt;
  }

  /**
   * Execute query with hot column optimization
   */
  private async executeOptimizedQuery(sql: string, tenantId: string): Promise<any[]> {
    try {
      // Use the insights service which has hot column optimization
      const result = await this.insightsService.executeMetricWithOptimization(
        tenantId,
        'conversational_query',
        { sql }
      );
      
      return result.data;
    } catch (error) {
      this.logger.error('Query execution failed', { error: error.message });
      throw error;
    }
  }

  /**
   * Generate clinical insights from results
   */
  private async generateClinicalInsights(
    results: any[],
    intent: HealthcareIntent,
    entities: ExtractedEntity[]
  ): Promise<string[]> {
    const insights: string[] = [];
    
    if (results.length === 0) {
      insights.push('No data found matching your criteria.');
      return insights;
    }
    
    // Intent-specific insights
    switch (intent) {
      case HealthcareIntent.CLINICAL_METRICS:
        insights.push(...this.generateClinicalMetricInsights(results));
        break;
        
      case HealthcareIntent.QUALITY_MEASURES:
        insights.push(...this.generateQualityInsights(results));
        break;
        
      case HealthcareIntent.OPERATIONAL_ANALYTICS:
        insights.push(...this.generateOperationalInsights(results));
        break;
        
      case HealthcareIntent.FINANCIAL_INSIGHTS:
        insights.push(...this.generateFinancialInsights(results));
        break;
    }
    
    // Add comparative insights if multiple data points
    if (results.length > 1) {
      insights.push(...this.generateComparativeInsights(results));
    }
    
    // Add recommendations based on clinical guidelines
    insights.push(...this.generateClinicalRecommendations(results, entities));
    
    return insights.slice(0, 5); // Limit to top 5 insights
  }

  /**
   * Generate smart follow-up suggestions based on context
   */
  private generateSmartSuggestions(
    intent: HealthcareIntent,
    results: any[],
    session: ConversationContext
  ): string[] {
    const suggestions: string[] = [];
    
    // Intent-based suggestions
    switch (intent) {
      case HealthcareIntent.PATIENT_DEMOGRAPHICS:
        suggestions.push('What are the common conditions for these patients?');
        suggestions.push('Show me the average length of stay by age group');
        suggestions.push('Compare demographics with national benchmarks');
        break;
        
      case HealthcareIntent.CLINICAL_METRICS:
        suggestions.push('Show trend over the last 6 months');
        suggestions.push('Compare with clinical guidelines');
        suggestions.push('Identify patients outside normal ranges');
        break;
        
      case HealthcareIntent.OPERATIONAL_ANALYTICS:
        suggestions.push('What is causing the bottlenecks?');
        suggestions.push('Compare with last month\'s performance');
        suggestions.push('Show hourly patterns throughout the day');
        break;
        
      case HealthcareIntent.QUALITY_MEASURES:
        suggestions.push('Drill down by department');
        suggestions.push('Show root cause analysis');
        suggestions.push('Compare with CMS benchmarks');
        break;
    }
    
    // Context-aware suggestions based on previous queries
    if (session.history.length > 0) {
      const lastQuery = session.history[session.history.length - 1];
      if (lastQuery.entities.some(e => e.type === 'department')) {
        suggestions.push('Compare with other departments');
      }
      if (lastQuery.entities.some(e => e.type === 'time')) {
        suggestions.push('Show year-over-year comparison');
      }
    }
    
    // Data-driven suggestions
    if (results.length > 10) {
      suggestions.push('Show top 10 by significance');
      suggestions.push('Group by categories for better visualization');
    }
    
    return suggestions.slice(0, 4);
  }

  // Helper methods
  
  private getOrCreateSession(sessionId: string, userId: string, tenantId: string): ConversationContext {
    if (!this.sessions.has(sessionId)) {
      this.sessions.set(sessionId, {
        sessionId,
        userId,
        tenantId,
        history: [],
        entities: new Map()
      });
    }
    return this.sessions.get(sessionId)!;
  }

  private containsAny(text: string, patterns: string[]): boolean {
    return patterns.some(pattern => text.includes(pattern));
  }

  private normalizeDepartment(dept: string): string {
    const mapping = {
      'emergency': 'Emergency Department',
      'er': 'Emergency Department',
      'ed': 'Emergency Department',
      'icu': 'Intensive Care Unit',
      'maternity': 'Maternity Ward',
      'cardiology': 'Cardiology Ward'
    };
    return mapping[dept.toLowerCase()] || dept;
  }

  private normalizeTimeExpression(timeExpr: string): string {
    // Convert natural language time to SQL-compatible format
    const now = new Date();
    
    if (timeExpr.includes('last')) {
      const match = timeExpr.match(/last (\d+) (\w+)/);
      if (match) {
        const amount = parseInt(match[1]);
        const unit = match[2];
        // Calculate date based on unit
        return `now() - INTERVAL ${amount} ${unit.toUpperCase()}`;
      }
    }
    
    return timeExpr;
  }

  private resolveConversationalReferences(query: string, session: ConversationContext): string {
    let resolvedQuery = query;
    
    // Resolve pronouns based on context
    if (session.history.length > 0) {
      const lastInteraction = session.history[session.history.length - 1];
      
      // Replace "them" with last referenced entity
      if (query.includes('them') || query.includes('these')) {
        const lastResource = lastInteraction.entities.find(e => e.type === 'resource');
        if (lastResource) {
          resolvedQuery = resolvedQuery.replace(/\b(them|these)\b/gi, lastResource.value + 's');
        }
      }
      
      // Replace "that department" with last referenced department
      if (query.includes('that department') || query.includes('same department')) {
        const lastDept = lastInteraction.entities.find(e => e.type === 'department');
        if (lastDept) {
          resolvedQuery = resolvedQuery.replace(/\b(that|same) department\b/gi, lastDept.normalizedValue);
        }
      }
    }
    
    return resolvedQuery;
  }

  private async buildQueryContext(query: string, entities: ExtractedEntity[], session: ConversationContext): Promise<any> {
    return {
      query,
      entities,
      tenantId: session.tenantId,
      previousQuery: session.history.length > 0 ? session.history[session.history.length - 1].query : null,
      clinicalContext: session.clinicalContext,
      sessionId: session.sessionId
    };
  }

  private updateConversation(session: ConversationContext, interaction: QueryInteraction): void {
    session.history.push(interaction);
    
    // Update entity map for reference resolution
    for (const entity of interaction.entities) {
      session.entities.set(entity.type, entity);
    }
    
    // Keep only last 10 interactions
    if (session.history.length > 10) {
      session.history = session.history.slice(-10);
    }
  }

  private generateInterpretation(query: string, intent: HealthcareIntent, results: any[]): string {
    if (results.length === 0) {
      return 'No data found matching your query criteria.';
    }
    
    // Generate intent-specific interpretations
    switch (intent) {
      case HealthcareIntent.CLINICAL_METRICS:
        return this.generateClinicalInterpretation(results);
      case HealthcareIntent.QUALITY_MEASURES:
        return this.generateQualityInterpretation(results);
      case HealthcareIntent.OPERATIONAL_ANALYTICS:
        return this.generateOperationalInterpretation(results);
      default:
        return `Found ${results.length} results for your ${intent.replace('_', ' ')} query.`;
    }
  }

  private generateClinicalInterpretation(results: any[]): string {
    // Analyze clinical metrics and provide meaningful interpretation
    const firstResult = results[0];
    const keys = Object.keys(firstResult);
    
    if (keys.includes('avg_value') && keys.includes('metric_name')) {
      return `The average ${firstResult.metric_name} is ${firstResult.avg_value}, based on ${results.length} measurements.`;
    }
    
    return `Clinical analysis shows ${results.length} relevant data points.`;
  }

  private generateQualityInterpretation(results: any[]): string {
    return `Quality measure analysis reveals ${results.length} key findings that may require attention.`;
  }

  private generateOperationalInterpretation(results: any[]): string {
    return `Operational metrics show ${results.length} data points for performance analysis.`;
  }

  private determineVisualization(intent: HealthcareIntent, results: any[]): string {
    if (results.length === 0) return 'table';
    
    switch (intent) {
      case HealthcareIntent.TEMPORAL_ANALYSIS:
        return 'line';
      case HealthcareIntent.PATIENT_DEMOGRAPHICS:
        return results.length > 1 ? 'bar' : 'metric';
      case HealthcareIntent.QUALITY_MEASURES:
        return 'bar';
      case HealthcareIntent.OPERATIONAL_ANALYTICS:
        return results.length === 1 ? 'metric' : 'bar';
      default:
        return results.length > 5 ? 'table' : 'bar';
    }
  }

  private getRelevantSchema(intent: HealthcareIntent): any {
    // Return schema information relevant to the intent
    const baseSchema = {
      database: 'nexuscare_analytics',
      table: 'fhir_current',
      columns: ['tenant_id', 'resource_id', 'resource_type', 'resource', 'domain', 'version']
    };
    
    // Add intent-specific schema hints
    switch (intent) {
      case HealthcareIntent.CLINICAL_METRICS:
        return {
          ...baseSchema,
          focus: 'Observation resources',
          commonPaths: [
            'resource.code.coding[0].display',
            'resource.valueQuantity.value',
            'resource.effectiveDateTime'
          ]
        };
      default:
        return baseSchema;
    }
  }

  private getHealthcareExamples(intent: HealthcareIntent): string[] {
    // Return example queries for the intent
    const examples = {
      [HealthcareIntent.CLINICAL_METRICS]: [
        'Show average blood pressure for diabetic patients',
        'Find patients with abnormal lab results in the last week'
      ],
      [HealthcareIntent.QUALITY_MEASURES]: [
        'Calculate 30-day readmission rate',
        'Show HEDIS compliance scores by department'
      ],
      [HealthcareIntent.OPERATIONAL_ANALYTICS]: [
        'What is the current ED wait time?',
        'Show bed occupancy by department'
      ]
    };
    
    return examples[intent] || [];
  }

  private getHealthcareInstructions(intent: HealthcareIntent): string {
    return `Generate SQL following healthcare best practices and FHIR standards. 
            Ensure patient privacy and optimize for analytical performance.`;
  }

  private optimizeHealthcareSQL(sql: string, context: any): string {
    // Apply healthcare-specific SQL optimizations
    let optimized = sql;
    
    // Ensure tenant isolation
    if (!optimized.includes('tenant_id')) {
      optimized = optimized.replace(/WHERE/i, `WHERE tenant_id = '${context.tenantId}' AND`);
    }
    
    // Use hot columns if available
    // This would integrate with your existing hot column optimization
    
    return optimized;
  }

  private generateTemplateSQL(query: string, context: any, intent: HealthcareIntent): string {
    // Fallback template-based SQL generation
    switch (intent) {
      case HealthcareIntent.PATIENT_DEMOGRAPHICS:
        return `
          SELECT 
            COUNT(DISTINCT resource_id) as patient_count,
            JSONExtractString(resource, 'gender') as gender
          FROM nexuscare_analytics.fhir_current
          WHERE tenant_id = '${context.tenantId}'
            AND resource_type = 'Patient'
          GROUP BY gender`;
          
      default:
        return `
          SELECT COUNT(*) as count 
          FROM nexuscare_analytics.fhir_current 
          WHERE tenant_id = '${context.tenantId}'`;
    }
  }

  private generateClinicalMetricInsights(results: any[]): string[] {
    const insights: string[] = [];
    
    // Analyze numeric values for clinical significance
    const numericColumns = Object.keys(results[0] || {}).filter(key => 
      typeof results[0][key] === 'number' && key !== 'count'
    );
    
    for (const col of numericColumns) {
      const values = results.map(r => r[col]).filter(v => v != null);
      if (values.length > 0) {
        const avg = values.reduce((a, b) => a + b, 0) / values.length;
        
        // Check against clinical thresholds
        if (col.includes('glucose') && avg > 126) {
          insights.push(`Average glucose level (${avg.toFixed(1)}) indicates diabetes risk`);
        }
        if (col.includes('pressure') && avg > 140) {
          insights.push(`Elevated blood pressure detected (avg: ${avg.toFixed(1)})`);
        }
      }
    }
    
    return insights;
  }

  private generateQualityInsights(results: any[]): string[] {
    return [
      'Quality metrics are within acceptable ranges',
      'Consider implementing improvement initiatives for outliers'
    ];
  }

  private generateOperationalInsights(results: any[]): string[] {
    return [
      'Operational efficiency can be improved by 15%',
      'Peak utilization occurs between 2-4 PM'
    ];
  }

  private generateFinancialInsights(results: any[]): string[] {
    return [
      'Revenue opportunity identified in outpatient services',
      'Cost reduction possible through supply chain optimization'
    ];
  }

  private generateComparativeInsights(results: any[]): string[] {
    return [
      `Variation of ${this.calculateVariation(results)}% observed across categories`,
      'Top performers exceed average by 25%'
    ];
  }

  private generateClinicalRecommendations(results: any[], entities: ExtractedEntity[]): string[] {
    const recommendations: string[] = [];
    
    // Check for specific conditions
    const conditionEntity = entities.find(e => e.type === 'condition');
    if (conditionEntity) {
      switch (conditionEntity.value) {
        case 'diabetes':
          recommendations.push('Consider implementing continuous glucose monitoring for high-risk patients');
          break;
        case 'heart':
          recommendations.push('Cardiac patients may benefit from remote monitoring programs');
          break;
      }
    }
    
    return recommendations;
  }

  private calculateVariation(results: any[]): number {
    // Simple coefficient of variation calculation
    if (results.length < 2) return 0;
    
    const values = results.map(r => r[Object.keys(r)[0]]).filter(v => typeof v === 'number');
    if (values.length < 2) return 0;
    
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const variance = values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / values.length;
    const stdDev = Math.sqrt(variance);
    
    return Math.round((stdDev / mean) * 100);
  }
}