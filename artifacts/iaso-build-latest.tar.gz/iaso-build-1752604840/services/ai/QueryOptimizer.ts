/**
 * Query Optimizer Service
 * 
 * Optimizes natural language queries and implements intelligent caching
 * for the NexusCare Insights Engine.
 */

import crypto from 'crypto';

import { logger } from '../../utils/logger';
import redisService from '../cache/RedisService';
import { getClickHouseClient } from '../clickhouse';

import { ParsedQuery } from './NLPQueryParser';

export interface QueryOptimizationResult {
  optimizedSQL: string;
  executionPlan: QueryExecutionPlan;
  cacheKey: string;
  estimatedCost: number;
  suggestions: OptimizationSuggestion[];
}

export interface QueryExecutionPlan {
  strategy: 'cache' | 'materialized_view' | 'direct_query' | 'aggregated_cache';
  estimatedRows: number;
  estimatedTimeMs: number;
  resourceUsage: {
    cpu: 'low' | 'medium' | 'high';
    memory: 'low' | 'medium' | 'high';
    io: 'low' | 'medium' | 'high';
  };
}

export interface OptimizationSuggestion {
  type: 'index' | 'materialized_view' | 'query_rewrite' | 'cache_strategy';
  description: string;
  impact: 'low' | 'medium' | 'high';
  implementation?: string;
}

export interface CacheStrategy {
  ttl: number;
  scope: 'user' | 'tenant' | 'global';
  invalidationRules: string[];
}

export class QueryOptimizer {
  private redis: any; // RedisService instance
  private cacheTTLs: Map<string, number>;
  private materializedViews: Map<string, string>;

  constructor() {
    try {
      // Temporarily disable Redis to debug startup issue
      this.redis = null;
      this.initializeCacheTTLs();
      this.initializeMaterializedViews();
    } catch (error) {
      logger.error('Failed to initialize QueryOptimizer', error as Error);
      throw error;
    }
  }

  /**
   * Initialize cache TTL configurations
   */
  private initializeCacheTTLs(): void {
    this.cacheTTLs = new Map([
      ['aggregation', 300], // 5 minutes
      ['trend', 600], // 10 minutes
      ['detail', 60], // 1 minute
      ['comparison', 300], // 5 minutes
      ['metric', 900], // 15 minutes
      ['alert', 30] // 30 seconds
    ]);
  }

  /**
   * Initialize materialized views mapping
   */
  private initializeMaterializedViews(): void {
    this.materializedViews = new Map([
      ['daily_encounter_summary', 'mv_daily_encounters'],
      ['hourly_ed_metrics', 'mv_hourly_emergency'],
      ['patient_readmissions', 'mv_patient_readmissions'],
      ['department_costs', 'mv_department_costs'],
      ['clinical_outcomes', 'mv_clinical_outcomes']
    ]);
  }

  /**
   * Optimize a parsed query
   */
  async optimizeQuery(
    parsedQuery: ParsedQuery,
    sql: string,
    context?: any
  ): Promise<QueryOptimizationResult> {
    const cacheKey = this.generateCacheKey(parsedQuery, context);
    
    // Check cache first
    const cachedResult = await this.checkCache(cacheKey);
    if (cachedResult) {
      return {
        optimizedSQL: sql,
        executionPlan: {
          strategy: 'cache',
          estimatedRows: 0,
          estimatedTimeMs: 1,
          resourceUsage: { cpu: 'low', memory: 'low', io: 'low' }
        },
        cacheKey,
        estimatedCost: 0.1,
        suggestions: []
      };
    }

    // Analyze query pattern
    const executionPlan = await this.analyzeExecutionPlan(parsedQuery, sql);
    
    // Apply optimizations
    const optimizedSQL = await this.applyOptimizations(sql, parsedQuery, executionPlan);
    
    // Generate suggestions
    const suggestions = this.generateOptimizationSuggestions(parsedQuery, executionPlan);

    return {
      optimizedSQL,
      executionPlan,
      cacheKey,
      estimatedCost: this.calculateQueryCost(executionPlan),
      suggestions
    };
  }

  /**
   * Cache query results
   */
  async cacheQueryResult(
    cacheKey: string,
    result: any,
    parsedQuery: ParsedQuery
  ): Promise<boolean> {
    try {
      const ttl = this.cacheTTLs.get(parsedQuery.intent.type) || 300;
      
      const cacheData = {
        result,
        cachedAt: new Date().toISOString(),
        queryIntent: parsedQuery.intent,
        rowCount: result.length,
        ttl
      };

      await this.redis.setex(
        `query_result:${cacheKey}`,
        ttl,
        JSON.stringify(cacheData)
      );

      // Update cache statistics
      await this.updateCacheStats(parsedQuery.intent.type, 'hit');

      return true;
    } catch (error) {
      logger.error('Failed to cache query result', error as Error);
      return false;
    }
  }

  /**
   * Get cached query result
   */
  async getCachedResult(cacheKey: string): Promise<any | null> {
    try {
      const cached = await this.redis.get(`query_result:${cacheKey}`);
      if (!cached) {
        await this.updateCacheStats('unknown', 'miss');
        return null;
      }

      const data = JSON.parse(cached);
      
      // Check if cache is still valid
      const cachedTime = new Date(data.cachedAt).getTime();
      const now = Date.now();
      const age = (now - cachedTime) / 1000;

      if (age > data.ttl) {
        await this.redis.delete(`query_result:${cacheKey}`);
        await this.updateCacheStats(data.queryIntent.type, 'expired');
        return null;
      }

      await this.updateCacheStats(data.queryIntent.type, 'hit');
      return data.result;
    } catch (error) {
      logger.error('Failed to get cached result', error as Error);
      return null;
    }
  }

  /**
   * Invalidate cache based on data changes
   */
  async invalidateCache(patterns: string[]): Promise<number> {
    let invalidated = 0;

    for (const pattern of patterns) {
      const keys = await this.redis.keys(`query_result:*${pattern}*`);
      for (const key of keys) {
        await this.redis.delete(key);
        invalidated++;
      }
    }

    logger.info(`Invalidated ${invalidated} cache entries`, { patterns });
    return invalidated;
  }

  /**
   * Private helper methods
   */

  private generateCacheKey(parsedQuery: ParsedQuery, context?: any): string {
    const keyComponents = [
      parsedQuery.intent.type,
      parsedQuery.intent.subType || 'default',
      JSON.stringify(parsedQuery.filters || {}),
      JSON.stringify(parsedQuery.timeRange || {}),
      context?.tenantId || 'global',
      context?.userId || 'anonymous'
    ];

    const keyString = keyComponents.join(':');
    return crypto.createHash('md5').update(keyString).digest('hex');
  }

  private async checkCache(cacheKey: string): Promise<boolean> {
    return await this.redis.exists(`query_result:${cacheKey}`);
  }

  private async analyzeExecutionPlan(
    parsedQuery: ParsedQuery,
    sql: string
  ): Promise<QueryExecutionPlan> {
    // Check if query can use materialized views
    const mvCandidate = this.findMaterializedView(parsedQuery);
    if (mvCandidate) {
      return {
        strategy: 'materialized_view',
        estimatedRows: 1000,
        estimatedTimeMs: 50,
        resourceUsage: { cpu: 'low', memory: 'low', io: 'low' }
      };
    }

    // Estimate query complexity
    const complexity = this.estimateQueryComplexity(sql, parsedQuery);
    
    // Determine strategy based on complexity and intent
    let strategy: QueryExecutionPlan['strategy'] = 'direct_query';
    if (parsedQuery.intent.type === 'aggregation' && complexity.aggregations > 2) {
      strategy = 'aggregated_cache';
    }

    return {
      strategy,
      estimatedRows: complexity.estimatedRows,
      estimatedTimeMs: complexity.estimatedTime,
      resourceUsage: {
        cpu: complexity.cpuIntensity,
        memory: complexity.memoryIntensity,
        io: complexity.ioIntensity
      }
    };
  }

  private async applyOptimizations(
    sql: string,
    parsedQuery: ParsedQuery,
    plan: QueryExecutionPlan
  ): Promise<string> {
    let optimizedSQL = sql;

    // Use materialized view if available
    if (plan.strategy === 'materialized_view') {
      const mvName = this.findMaterializedView(parsedQuery);
      if (mvName) {
        optimizedSQL = sql.replace(/FROM\s+fhir_events/gi, `FROM ${mvName}`);
      }
    }

    // Add sampling for large datasets
    if (plan.estimatedRows > 1000000 && parsedQuery.intent.type === 'trend') {
      optimizedSQL = optimizedSQL.replace(
        /FROM\s+(\w+)/gi,
        'FROM $1 SAMPLE 0.1'
      );
    }

    // Add query hints
    if (plan.resourceUsage.memory === 'high') {
      optimizedSQL = `${optimizedSQL} SETTINGS max_memory_usage = 10000000000`;
    }

    // Optimize time filters
    if (parsedQuery.timeRange) {
      optimizedSQL = this.optimizeTimeFilters(optimizedSQL, parsedQuery.timeRange);
    }

    return optimizedSQL;
  }

  private findMaterializedView(parsedQuery: ParsedQuery): string | null {
    // Check for daily encounter summaries
    if (parsedQuery.intent.type === 'aggregation' && 
        parsedQuery.resourceTypes?.includes('Encounter') &&
        parsedQuery.timeRange?.period?.includes('day')) {
      return this.materializedViews.get('daily_encounter_summary') || null;
    }

    // Check for ED metrics
    if (parsedQuery.filters?.department === 'ED' &&
        parsedQuery.intent.type === 'metric') {
      return this.materializedViews.get('hourly_ed_metrics') || null;
    }

    // Check for readmission queries
    if (parsedQuery.entities.some(e => e.text.includes('readmission'))) {
      return this.materializedViews.get('patient_readmissions') || null;
    }

    return null;
  }

  private estimateQueryComplexity(sql: string, parsedQuery: ParsedQuery): any {
    const complexity = {
      estimatedRows: 10000,
      estimatedTime: 100,
      aggregations: 0,
      joins: 0,
      cpuIntensity: 'medium' as const,
      memoryIntensity: 'medium' as const,
      ioIntensity: 'medium' as const
    };

    // Count aggregations
    complexity.aggregations = (sql.match(/COUNT|SUM|AVG|MAX|MIN/gi) || []).length;

    // Count joins
    complexity.joins = (sql.match(/JOIN/gi) || []).length;

    // Estimate based on time range
    if (parsedQuery.timeRange) {
      const days = this.getDaysInRange(parsedQuery.timeRange);
      complexity.estimatedRows = Math.min(days * 10000, 1000000);
      complexity.estimatedTime = days * 10;
    }

    // Adjust intensity based on operations
    if (complexity.aggregations > 3) {
      complexity.cpuIntensity = 'high';
      complexity.memoryIntensity = 'high';
    }

    if (complexity.joins > 2) {
      complexity.memoryIntensity = 'high';
      complexity.ioIntensity = 'high';
    }

    return complexity;
  }

  private getDaysInRange(timeRange: any): number {
    if (!timeRange.start || !timeRange.end) return 7;
    
    const start = new Date(timeRange.start).getTime();
    const end = new Date(timeRange.end).getTime();
    const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    
    return Math.max(1, days);
  }

  private optimizeTimeFilters(sql: string, timeRange: any): string {
    // Add partition pruning hints
    if (timeRange.start) {
      const startDate = new Date(timeRange.start);
      const partition = `${startDate.getFullYear()}${String(startDate.getMonth() + 1).padStart(2, '0')}`;
      
      // Add partition hint as comment
      sql = `/* partition_hint: ${partition} */ ${sql}`;
    }

    return sql;
  }

  private generateOptimizationSuggestions(
    parsedQuery: ParsedQuery,
    plan: QueryExecutionPlan
  ): OptimizationSuggestion[] {
    const suggestions: OptimizationSuggestion[] = [];

    // Suggest materialized view creation
    if (plan.strategy === 'direct_query' && plan.estimatedTimeMs > 1000) {
      suggestions.push({
        type: 'materialized_view',
        description: `Create a materialized view for ${parsedQuery.intent.type} queries on ${parsedQuery.resourceTypes?.join(', ')}`,
        impact: 'high',
        implementation: this.generateMaterializedViewSQL(parsedQuery)
      });
    }

    // Suggest better time range
    if (!parsedQuery.timeRange) {
      suggestions.push({
        type: 'query_rewrite',
        description: 'Add a time range filter to improve query performance',
        impact: 'medium'
      });
    }

    // Suggest caching strategy
    if (plan.estimatedTimeMs > 500) {
      suggestions.push({
        type: 'cache_strategy',
        description: `Enable ${this.cacheTTLs.get(parsedQuery.intent.type) || 300}s caching for this query pattern`,
        impact: 'medium'
      });
    }

    return suggestions;
  }

  private generateMaterializedViewSQL(parsedQuery: ParsedQuery): string {
    const viewName = `mv_${parsedQuery.intent.type}_${parsedQuery.resourceTypes?.[0]?.toLowerCase()}`;
    
    return `
CREATE MATERIALIZED VIEW ${viewName}
ENGINE = AggregatingMergeTree()
ORDER BY (tenant_id, date)
AS
SELECT
  tenant_id,
  toDate(event_time) as date,
  resource_type,
  COUNT(*) as event_count,
  uniqState(resource_id) as unique_resources
FROM fhir_events
WHERE resource_type IN (${parsedQuery.resourceTypes?.map(rt => `'${rt}'`).join(', ')})
GROUP BY tenant_id, date, resource_type`;
  }

  private calculateQueryCost(plan: QueryExecutionPlan): number {
    let cost = 1.0;

    // Factor in resource usage
    const resourceMultipliers = { low: 1, medium: 2, high: 3 };
    cost *= resourceMultipliers[plan.resourceUsage.cpu];
    cost *= resourceMultipliers[plan.resourceUsage.memory];
    cost *= resourceMultipliers[plan.resourceUsage.io];

    // Factor in estimated time
    cost *= Math.log10(plan.estimatedTimeMs + 10) / 2;

    // Factor in rows
    cost *= Math.log10(plan.estimatedRows + 10) / 4;

    return Math.round(cost * 10) / 10;
  }

  private async updateCacheStats(intentType: string, event: 'hit' | 'miss' | 'expired'): Promise<void> {
    const key = `cache_stats:${intentType}:${event}`;
    const today = new Date().toISOString().split('T')[0];
    
    await this.redis.hincrby(`${key}:${today}`, 'count', 1);
    await this.redis.expire(`${key}:${today}`, 86400 * 7); // Keep for 7 days
  }

  /**
   * Get cache statistics
   */
  async getCacheStatistics(): Promise<any> {
    const stats: any = {};
    const intentTypes = Array.from(this.cacheTTLs.keys());
    
    for (const intent of intentTypes) {
      stats[intent] = {
        hits: 0,
        misses: 0,
        expired: 0,
        hitRate: 0
      };

      const today = new Date().toISOString().split('T')[0];
      
      const hits = await this.redis.hget(`cache_stats:${intent}:hit:${today}`, 'count');
      const misses = await this.redis.hget(`cache_stats:${intent}:miss:${today}`, 'count');
      const expired = await this.redis.hget(`cache_stats:${intent}:expired:${today}`, 'count');

      stats[intent].hits = parseInt(hits || '0');
      stats[intent].misses = parseInt(misses || '0');
      stats[intent].expired = parseInt(expired || '0');
      
      const total = stats[intent].hits + stats[intent].misses;
      stats[intent].hitRate = total > 0 ? (stats[intent].hits / total * 100).toFixed(2) : 0;
    }

    return stats;
  }
}

export default QueryOptimizer;