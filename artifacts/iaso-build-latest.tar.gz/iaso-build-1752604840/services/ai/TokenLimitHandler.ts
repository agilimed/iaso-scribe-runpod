// Token Limit Handler - Practical strategies for handling large queries
export class TokenLimitHandler {
  
  /**
   * Strategy 1: Increase Token Limit
   * Simple but has cost implications
   */
  static adjustTokenLimit(estimatedTokens: number): number {
    const buffer = 200; // Safety buffer
    const limits = {
      small: 500,
      medium: 1000,
      large: 1500,
      xlarge: 2000,
      max: 4000 // Most models support up to 4k
    };

    if (estimatedTokens < limits.small) return limits.small;
    if (estimatedTokens < limits.medium) return limits.medium;
    if (estimatedTokens < limits.large) return limits.large;
    if (estimatedTokens < limits.xlarge) return limits.xlarge;
    return limits.max;
  }

  /**
   * Strategy 2: Query Simplification
   * Simplify the query to reduce token usage
   */
  static simplifyQuery(query: string): string {
    // Remove redundant words
    let simplified = query
      .replace(/\b(please|could you|can you|I want to|I need to)\b/gi, '')
      .replace(/\s+/g, ' ')
      .trim();

    // Shorten verbose phrases
    const replacements = [
      { from: /patients who have both (.+) and (.+)/i, to: 'patients with $1 and $2' },
      { from: /calculate (.+) and then (.+)/i, to: 'calculate $1, then $2' },
      { from: /based on their (.+)/i, to: 'by $1' },
      { from: /in the last (\d+) (days|months|years)/i, to: 'last $1 $2' }
    ];

    replacements.forEach(({ from, to }) => {
      simplified = simplified.replace(from, to);
    });

    return simplified;
  }

  /**
   * Strategy 3: Progressive Query Building
   * Build complex queries in steps
   */
  static createProgressiveQuery(complexQuery: string): {
    steps: Array<{
      description: string;
      query: string;
      buildOn: string | null;
    }>;
  } {
    // Example for the nested CTE query about chronic conditions
    if (complexQuery.includes('chronic conditions') && complexQuery.includes('medication') && complexQuery.includes('risk score')) {
      return {
        steps: [
          {
            description: 'Step 1: Find patients with chronic conditions',
            query: 'Find all patients who have at least one chronic condition (diabetes, hypertension, heart disease)',
            buildOn: null
          },
          {
            description: 'Step 2: Count medications per patient',
            query: 'For the patients from step 1, count how many active medications each patient has',
            buildOn: 'chronic_patients'
          },
          {
            description: 'Step 3: Calculate risk score',
            query: 'Calculate a risk score for each patient: (condition_count * 2 + medication_count * 1.5)',
            buildOn: 'patient_medications'
          }
        ]
      };
    }

    // Default: return as single step
    return {
      steps: [{
        description: 'Execute query',
        query: complexQuery,
        buildOn: null
      }]
    };
  }

  /**
   * Strategy 4: Smart Chunking with Context Preservation
   * Split query while maintaining context
   */
  static chunkWithContext(
    query: string,
    maxTokensPerChunk: number = 800
  ): Array<{
    chunk: string;
    context: string;
    combineStrategy: 'union' | 'join' | 'cte';
  }> {
    const chunks: Array<{
      chunk: string;
      context: string;
      combineStrategy: 'union' | 'join' | 'cte';
    }> = [];

    // Identify logical breaking points
    const breakPoints = [
      /\b(then|after that|finally|next)\b/i,
      /\b(and also|additionally|furthermore)\b/i,
      /\b(based on|using|with)\b/i
    ];

    let remaining = query;
    let context = '';

    breakPoints.forEach(pattern => {
      const match = remaining.match(pattern);
      if (match && match.index) {
        const beforeBreak = remaining.substring(0, match.index);
        const afterBreak = remaining.substring(match.index);

        if (beforeBreak.trim()) {
          chunks.push({
            chunk: beforeBreak.trim(),
            context: context,
            combineStrategy: 'cte'
          });
          context = beforeBreak.trim(); // Use as context for next chunk
        }

        remaining = afterBreak;
      }
    });

    // Add remaining part
    if (remaining.trim()) {
      chunks.push({
        chunk: remaining.trim(),
        context: context,
        combineStrategy: 'cte'
      });
    }

    return chunks.length > 0 ? chunks : [{
      chunk: query,
      context: '',
      combineStrategy: 'cte'
    }];
  }

  /**
   * Strategy 5: Query Templates for Common Complex Patterns
   * Pre-defined templates for common complex queries
   */
  static applyTemplate(query: string): string | null {
    const templates = [
      {
        pattern: /patients.*both.*conditions.*medications.*risk/i,
        template: `
-- Template: Patient Risk Assessment with Conditions and Medications
WITH chronic_conditions AS (
  SELECT patient_id, COUNT(*) as condition_count
  FROM conditions
  WHERE is_chronic = true
  GROUP BY patient_id
),
patient_medications AS (
  SELECT patient_id, COUNT(*) as medication_count
  FROM medications
  WHERE status = 'active'
  GROUP BY patient_id
)
SELECT 
  p.patient_id,
  cc.condition_count,
  pm.medication_count,
  (cc.condition_count * 2 + pm.medication_count * 1.5) as risk_score
FROM patients p
JOIN chronic_conditions cc ON p.id = cc.patient_id
JOIN patient_medications pm ON p.id = pm.patient_id
ORDER BY risk_score DESC`
      }
    ];

    for (const { pattern, template } of templates) {
      if (pattern.test(query)) {
        return template;
      }
    }

    return null;
  }

  /**
   * Main handler that combines all strategies
   */
  static async handleLargeQuery(
    query: string,
    iasoqlClient: any,
    schemaContext: string
  ): Promise<string> {
    // Try template first
    const template = this.applyTemplate(query);
    if (template) {
      return template;
    }

    // Estimate tokens
    const estimatedTokens = query.split(' ').length * 15;

    // If within limits, just adjust token limit
    if (estimatedTokens < 1500) {
      const tokenLimit = this.adjustTokenLimit(estimatedTokens);
      return await iasoqlClient.generate({
        prompt: `${schemaContext}\n\nQuestion: ${query}\n\nSQL:`,
        max_tokens: tokenLimit
      });
    }

    // For larger queries, use progressive building
    const progressive = this.createProgressiveQuery(query);
    if (progressive.steps.length > 1) {
      const results: string[] = [];
      
      for (const step of progressive.steps) {
        const stepPrompt = `${schemaContext}

${step.buildOn ? `Building on CTE named '${step.buildOn}',` : ''} 
${step.query}

Generate SQL:`;

        const result = await iasoqlClient.generate({
          prompt: stepPrompt,
          max_tokens: 800
        });
        
        results.push(result);
      }

      // Combine results
      return this.combineProgressiveResults(results);
    }

    // Fall back to chunking
    const chunks = this.chunkWithContext(query);
    const chunkResults: string[] = [];

    for (const chunk of chunks) {
      const chunkPrompt = `${schemaContext}

${chunk.context ? `Context: ${chunk.context}` : ''}
Query part: ${chunk.chunk}

Generate SQL:`;

      const result = await iasoqlClient.generate({
        prompt: chunkPrompt,
        max_tokens: 600
      });
      
      chunkResults.push(result);
    }

    return this.combineChunkedResults(chunkResults, chunks);
  }

  private static combineProgressiveResults(results: string[]): string {
    // Combine CTEs from progressive steps
    const ctes: string[] = [];
    let finalSelect = '';

    results.forEach((result, index) => {
      if (result.toUpperCase().includes('WITH')) {
        // Extract CTE
        const cteMatch = result.match(/WITH\s+(\w+)\s+AS\s*\(([\s\S]+?)\)(?:,|SELECT)/i);
        if (cteMatch) {
          ctes.push(`${cteMatch[1]} AS (${cteMatch[2]})`);
        }
      } else if (result.toUpperCase().includes('SELECT') && index === results.length - 1) {
        finalSelect = result;
      }
    });

    if (ctes.length > 0) {
      return `WITH ${ctes.join(',\n')}\n${finalSelect}`;
    }

    return results.join('\n');
  }

  private static combineChunkedResults(
    results: string[], 
    chunks: Array<{ combineStrategy: string }>
  ): string {
    // Intelligent combination based on strategies
    if (chunks.every(c => c.combineStrategy === 'union')) {
      return results.join('\nUNION ALL\n');
    }

    // Default to CTE combination
    const ctes: string[] = [];
    results.forEach((result, index) => {
      ctes.push(`chunk_${index} AS (${result})`);
    });

    return `WITH ${ctes.join(',\n')}\nSELECT * FROM chunk_${results.length - 1}`;
  }
}