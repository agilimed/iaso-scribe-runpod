/**
 * ClickHouse MCP Integration Service
 * 
 * Integrates ClickHouse MCP server with Qwen3 for direct database access
 * and natural language query processing.
 */

import { spawn, ChildProcess } from 'child_process';

import axios from 'axios';

import { logger } from '../../utils/logger';

export interface MCPServerConfig {
  host: string;
  port: number;
  user: string;
  password: string;
  secure: boolean;
  verify: boolean;
  connectTimeout: number;
  sendReceiveTimeout: number;
  transport: 'stdio' | 'http' | 'streamable-http' | 'sse';
}

export interface MCPTool {
  name: string;
  description: string;
  parameters?: any;
}

export interface MCPQueryRequest {
  tool: 'query_clickhouse' | 'list_databases' | 'list_tables';
  params: {
    sql?: string;
    database?: string;
  };
}

export interface MCPQueryResponse {
  success: boolean;
  data?: any;
  error?: string;
  metadata?: {
    rowCount?: number;
    executionTime?: number;
    databases?: string[];
    tables?: string[];
  };
}

export class ClickHouseMCPIntegration {
  private mcpProcess: ChildProcess | null = null;
  private config: MCPServerConfig;
  private isInitialized: boolean = false;
  private mcpEndpoint: string;

  constructor() {
    this.config = {
      host: process.env.CLICKHOUSE_HOST || 'clickhouse',
      port: parseInt(process.env.CLICKHOUSE_PORT || '8443'),
      user: process.env.CLICKHOUSE_MCP_USER || 'mcp_readonly',
      password: process.env.CLICKHOUSE_MCP_PASSWORD || '',
      secure: process.env.CLICKHOUSE_SECURE === 'true',
      verify: process.env.CLICKHOUSE_VERIFY === 'true',
      connectTimeout: parseInt(process.env.CLICKHOUSE_CONNECT_TIMEOUT || '30'),
      sendReceiveTimeout: parseInt(process.env.CLICKHOUSE_SEND_RECEIVE_TIMEOUT || '30'),
      transport: (process.env.CLICKHOUSE_MCP_SERVER_TRANSPORT || 'stdio') as any
    };

    this.mcpEndpoint = process.env.MCP_SERVER_ENDPOINT || 'http://localhost:8003';
  }

  /**
   * Initialize the MCP server connection
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) {
      logger.info('ClickHouse MCP server already initialized');
      return;
    }

    try {
      logger.info('Initializing ClickHouse MCP server', { config: this.config });

      if (this.config.transport === 'stdio') {
        await this.startStdioServer();
      } else {
        await this.startHttpServer();
      }

      this.isInitialized = true;
      logger.info('ClickHouse MCP server initialized successfully');

      // Register available tools with Qwen3
      await this.registerToolsWithLLM();

    } catch (error) {
      logger.error('Failed to initialize ClickHouse MCP server', error as Error);
      throw error;
    }
  }

  /**
   * Start MCP server in stdio mode
   */
  private async startStdioServer(): Promise<void> {
    const env = {
      ...process.env,
      CLICKHOUSE_HOST: this.config.host,
      CLICKHOUSE_PORT: this.config.port.toString(),
      CLICKHOUSE_USER: this.config.user,
      CLICKHOUSE_PASSWORD: this.config.password,
      CLICKHOUSE_SECURE: this.config.secure.toString(),
      CLICKHOUSE_VERIFY: this.config.verify.toString(),
      CLICKHOUSE_CONNECT_TIMEOUT: this.config.connectTimeout.toString(),
      CLICKHOUSE_SEND_RECEIVE_TIMEOUT: this.config.sendReceiveTimeout.toString()
    };

    this.mcpProcess = spawn('mcp-clickhouse', [], { env });

    this.mcpProcess.on('error', (error) => {
      logger.error('MCP server process error', error);
    });

    this.mcpProcess.on('exit', (code) => {
      logger.warn('MCP server process exited', { code });
      this.isInitialized = false;
    });

    // Wait for server to be ready
    await new Promise((resolve) => setTimeout(resolve, 2000));
  }

  /**
   * Start MCP server in HTTP mode
   */
  private async startHttpServer(): Promise<void> {
    // For HTTP mode, we assume the MCP server is running as a separate service
    // Check if it's accessible
    try {
      const response = await axios.get(`${this.mcpEndpoint}/health`);
      if (response.status !== 200) {
        throw new Error('MCP server health check failed');
      }
    } catch (error) {
      throw new Error(`MCP server not accessible at ${this.mcpEndpoint}`);
    }
  }

  /**
   * Register MCP tools with Qwen3 LLM
   */
  private async registerToolsWithLLM(): Promise<void> {
    const tools: MCPTool[] = [
      {
        name: 'query_clickhouse',
        description: 'Execute a read-only SQL query on ClickHouse database',
        parameters: {
          type: 'object',
          properties: {
            sql: {
              type: 'string',
              description: 'The SQL query to execute (SELECT only)'
            }
          },
          required: ['sql']
        }
      },
      {
        name: 'list_databases',
        description: 'List all available databases in ClickHouse',
        parameters: {
          type: 'object',
          properties: {}
        }
      },
      {
        name: 'list_tables',
        description: 'List all tables in a specific ClickHouse database',
        parameters: {
          type: 'object',
          properties: {
            database: {
              type: 'string',
              description: 'The name of the database'
            }
          },
          required: ['database']
        }
      }
    ];

    // Register tools with Qwen3
    const qwen3Endpoint = process.env.QWEN3_SERVICE_URL || 'http://localhost:8002';
    
    try {
      await axios.post(`${qwen3Endpoint}/register_tools`, {
        tools,
        integration: 'clickhouse_mcp'
      });
      
      logger.info('Successfully registered ClickHouse MCP tools with Qwen3');
    } catch (error) {
      logger.warn('Failed to register tools with Qwen3', error);
    }
  }

  /**
   * Execute a query through MCP
   */
  async executeQuery(request: MCPQueryRequest): Promise<MCPQueryResponse> {
    if (!this.isInitialized) {
      throw new Error('MCP server not initialized');
    }

    try {
      const startTime = Date.now();

      if (this.config.transport === 'stdio') {
        return await this.executeStdioQuery(request);
      } else {
        return await this.executeHttpQuery(request);
      }

    } catch (error) {
      logger.error('Failed to execute MCP query', error as Error);
      return {
        success: false,
        error: (error as Error).message
      };
    }
  }

  /**
   * Execute query via stdio
   */
  private async executeStdioQuery(request: MCPQueryRequest): Promise<MCPQueryResponse> {
    return new Promise((resolve, reject) => {
      if (!this.mcpProcess || !this.mcpProcess.stdin || !this.mcpProcess.stdout) {
        reject(new Error('MCP process not available'));
        return;
      }

      const requestId = Date.now().toString();
      const message = {
        id: requestId,
        method: request.tool,
        params: request.params
      };

      let responseData = '';

      const onData = (data: Buffer) => {
        responseData += data.toString();
        
        // Check if we have a complete response
        try {
          const response = JSON.parse(responseData);
          if (response.id === requestId) {
            this.mcpProcess!.stdout!.removeListener('data', onData);
            resolve({
              success: !response.error,
              data: response.result,
              error: response.error?.message
            });
          }
        } catch (e) {
          // Not a complete JSON yet, continue buffering
        }
      };

      this.mcpProcess.stdout.on('data', onData);
      this.mcpProcess.stdin.write(JSON.stringify(message) + '\n');

      // Timeout after 30 seconds
      setTimeout(() => {
        this.mcpProcess!.stdout!.removeListener('data', onData);
        reject(new Error('Query timeout'));
      }, 30000);
    });
  }

  /**
   * Execute query via HTTP
   */
  private async executeHttpQuery(request: MCPQueryRequest): Promise<MCPQueryResponse> {
    const response = await axios.post(`${this.mcpEndpoint}/execute`, {
      tool: request.tool,
      params: request.params
    }, {
      timeout: 30000
    });

    return {
      success: response.data.success,
      data: response.data.data,
      error: response.data.error,
      metadata: response.data.metadata
    };
  }

  /**
   * Get tool for natural language processing
   */
  getToolForNLP(): any {
    return {
      name: 'clickhouse_query',
      description: 'Query ClickHouse database using natural language',
      execute: async (params: { query: string }) => {
        // First, use Qwen3 to convert natural language to SQL
        const qwen3Endpoint = process.env.QWEN3_SERVICE_URL || 'http://localhost:8002';
        
        const sqlResponse = await axios.post(`${qwen3Endpoint}/nl_to_sql`, {
          query: params.query,
          context: {
            database: 'nexuscare_analytics',
            tables: ['fhir_events', 'metric_values', 'realtime_metrics']
          }
        });

        const sql = sqlResponse.data.sql;

        // Execute the SQL query through MCP
        const result = await this.executeQuery({
          tool: 'query_clickhouse',
          params: { sql }
        });

        return {
          sql,
          result: result.data,
          success: result.success,
          error: result.error
        };
      }
    };
  }

  /**
   * Shutdown the MCP server
   */
  async shutdown(): Promise<void> {
    if (this.mcpProcess) {
      this.mcpProcess.kill();
      this.mcpProcess = null;
    }
    this.isInitialized = false;
    logger.info('ClickHouse MCP server shutdown');
  }
}

// Singleton instance
let mcpIntegration: ClickHouseMCPIntegration | null = null;

export function getClickHouseMCPIntegration(): ClickHouseMCPIntegration {
  if (!mcpIntegration) {
    mcpIntegration = new ClickHouseMCPIntegration();
  }
  return mcpIntegration;
}