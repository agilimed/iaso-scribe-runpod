/**
 * Tests for NLP Query Parser
 */

import NLPQueryParser from '../NLPQueryParser';

describe('NLPQueryParser', () => {
  let parser: NLPQueryParser;

  beforeEach(() => {
    parser = new NLPQueryParser();
  });

  describe('Intent Recognition', () => {
    it('should recognize aggregation queries', async () => {
      const testQueries = [
        { query: 'How many patients were admitted today?', expectedType: 'aggregation', expectedSubType: 'count' },
        { query: 'Show me the average glucose level', expectedType: 'aggregation', expectedSubType: 'average' },
        { query: 'What is the total cost of procedures?', expectedType: 'aggregation', expectedSubType: 'sum' }
      ];

      for (const test of testQueries) {
        const result = await parser.parseQuery({ query: test.query });
        expect(result.intent.type).toBe(test.expectedType);
        if (test.expectedSubType) {
          expect(result.intent.subType).toBe(test.expectedSubType);
        }
      }
    });

    it('should recognize trend queries', async () => {
      const result = await parser.parseQuery({ 
        query: 'Show me the trend of admissions this month' 
      });
      expect(result.intent.type).toBe('trend');
    });

    it('should recognize comparison queries', async () => {
      const result = await parser.parseQuery({ 
        query: 'Compare readmission rates between cardiology and neurology' 
      });
      expect(result.intent.type).toBe('comparison');
    });
  });

  describe('Entity Extraction', () => {
    it('should extract medical conditions', async () => {
      const result = await parser.parseQuery({ 
        query: 'Show me all patients with diabetes and hypertension' 
      });
      
      const conditions = result.entities.filter(e => e.type === 'condition');
      expect(conditions).toHaveLength(2);
      expect(conditions.map(c => c.text)).toContain('diabetes');
      expect(conditions.map(c => c.text)).toContain('hypertension');
    });

    it('should extract medications', async () => {
      const result = await parser.parseQuery({ 
        query: 'Which patients are on insulin or metformin?' 
      });
      
      const medications = result.entities.filter(e => e.type === 'medication');
      expect(medications).toHaveLength(2);
      expect(medications[0].code).toBeDefined();
    });

    it('should extract lab values', async () => {
      const result = await parser.parseQuery({ 
        query: 'Show glucose and hemoglobin levels' 
      });
      
      const labs = result.entities.filter(e => e.type === 'lab');
      expect(labs).toHaveLength(2);
      expect(labs.map(l => l.text)).toContain('glucose');
      expect(labs.map(l => l.text)).toContain('hemoglobin');
    });

    it('should extract departments', async () => {
      const result = await parser.parseQuery({ 
        query: 'How many patients in emergency and ICU?' 
      });
      
      const departments = result.entities.filter(e => e.type === 'department');
      expect(departments).toHaveLength(2);
      expect(departments.map(d => d.value)).toContain('ED');
      expect(departments.map(d => d.value)).toContain('ICU');
    });
  });

  describe('Time Range Extraction', () => {
    it('should extract "today" time range', async () => {
      const result = await parser.parseQuery({ 
        query: 'Show me admissions today' 
      });
      
      expect(result.timeRange).toBeDefined();
      expect(result.timeRange?.start).toBeDefined();
      expect(result.timeRange?.end).toBeDefined();
      
      const start = result.timeRange!.start!;
      const end = result.timeRange!.end!;
      expect(start.getHours()).toBe(0);
      expect(start.getMinutes()).toBe(0);
      expect(end.getTime()).toBeGreaterThan(start.getTime());
    });

    it('should extract "last N days" time range', async () => {
      const result = await parser.parseQuery({ 
        query: 'Show me data from the last 7 days' 
      });
      
      expect(result.timeRange?.period).toBe('7_day');
      expect(result.timeRange?.start).toBeDefined();
      expect(result.timeRange?.end).toBeDefined();
    });

    it('should extract "this week" time range', async () => {
      const result = await parser.parseQuery({ 
        query: 'What happened this week?' 
      });
      
      expect(result.timeRange).toBeDefined();
      const start = result.timeRange!.start!;
      expect(start.getDay()).toBe(0); // Sunday
    });
  });

  describe('Resource Type Determination', () => {
    it('should map conditions to appropriate resources', async () => {
      const result = await parser.parseQuery({ 
        query: 'Patients with diabetes' 
      });
      
      expect(result.resourceTypes).toContain('Condition');
      expect(result.resourceTypes).toContain('Encounter');
    });

    it('should map labs to Observation resources', async () => {
      const result = await parser.parseQuery({ 
        query: 'Show glucose levels' 
      });
      
      expect(result.resourceTypes).toContain('Observation');
    });

    it('should default to common resources when unclear', async () => {
      const result = await parser.parseQuery({ 
        query: 'Show me some data' 
      });
      
      expect(result.resourceTypes).toContain('Encounter');
      expect(result.resourceTypes).toContain('Observation');
    });
  });

  describe('SQL Translation', () => {
    it('should generate valid SQL for simple queries', async () => {
      const parsed = await parser.parseQuery({ 
        query: 'How many patients today?',
        context: { tenantId: 'test-tenant' }
      });
      
      const sqlResult = await parser.translateToSQL(parsed);
      
      expect(sqlResult.sql).toContain('SELECT');
      expect(sqlResult.sql).toContain('COUNT(*)');
      expect(sqlResult.sql).toContain('tenant_id = \'test-tenant\'');
      expect(sqlResult.sql).toContain('event_time >=');
    });

    it('should include warnings for broad queries', async () => {
      const parsed = await parser.parseQuery({ 
        query: 'Show me everything' 
      });
      
      const sqlResult = await parser.translateToSQL(parsed);
      
      expect(sqlResult.warnings).toBeDefined();
      expect(sqlResult.warnings!.length).toBeGreaterThan(0);
    });

    it('should estimate query cost', async () => {
      const parsed = await parser.parseQuery({ 
        query: 'Show trend for last year' 
      });
      
      const sqlResult = await parser.translateToSQL(parsed);
      
      expect(sqlResult.estimatedCost).toBeGreaterThan(1);
    });
  });

  describe('Complex Healthcare Queries', () => {
    it('should handle sepsis monitoring query', async () => {
      const result = await parser.parseQuery({ 
        query: 'Show me patients with sepsis in ICU with abnormal vitals in the last 24 hours' 
      });
      
      expect(result.entities.find(e => e.text === 'sepsis')).toBeDefined();
      expect(result.entities.find(e => e.text === 'icu')).toBeDefined();
      expect(result.entities.find(e => e.type === 'vital')).toBeDefined();
      expect(result.timeRange?.period).toBe('24_hour');
    });

    it('should handle quality metric query', async () => {
      const result = await parser.parseQuery({ 
        query: 'Compare average length of stay for pneumonia patients between this month and last month' 
      });
      
      expect(result.intent.type).toBe('comparison');
      expect(result.entities.find(e => e.text === 'pneumonia')).toBeDefined();
      expect(result.metrics).toContain('average');
    });

    it('should handle financial query', async () => {
      const result = await parser.parseQuery({ 
        query: 'What is the total cost of cardiac procedures in cardiology department this quarter?' 
      });
      
      expect(result.intent.type).toBe('aggregation');
      expect(result.entities.find(e => e.text === 'cardiology')).toBeDefined();
      expect(result.resourceTypes).toContain('Procedure');
    });
  });
});