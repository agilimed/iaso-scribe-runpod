/**
 * RAG (Retrieval-Augmented Generation) Service
 * 
 * Orchestrates the RAG pipeline for clinical knowledge integration
 * combining vector search, document retrieval, and LLM generation
 */

import { logger } from '../../utils/logger';

import { vectorDatabaseService, VectorDocument, SearchOptions } from './VectorDatabaseService';
import { embeddingsService } from './EmbeddingsService';
import { clinicalDocumentProcessor } from './ClinicalDocumentProcessor';
import { AIModelFactory, AIModelConfig } from './AIModelAdapter';

export interface RAGQuery {
  query: string;
  context?: {
    userId?: string;
    tenantId?: string;
    specialty?: string;
    useCase?: 'clinical_decision' | 'drug_info' | 'protocol' | 'general';
  };
  options?: {
    topK?: number;
    includeMetadata?: boolean;
    rerank?: boolean;
    hybridSearch?: boolean;
    expandQuery?: boolean;
  };
}

export interface RAGResponse {
  answer: string;
  sources: Array<{
    id: string;
    content: string;
    score: number;
    metadata?: any;
    highlights?: string[];
  }>;
  metadata: {
    queryExpansion?: string[];
    retrievalTimeMs: number;
    generationTimeMs: number;
    totalTimeMs: number;
    model: string;
  };
}

export interface DocumentIngestionResult {
  documentId: string;
  chunks: number;
  status: 'success' | 'failed';
  error?: string;
}

export class RAGService {
  private initialized = false;

  /**
   * Initialize the RAG service
   */
  async initialize(): Promise<void> {
    if (this.initialized) return;

    try {
      // Initialize all components
      await Promise.all([
        vectorDatabaseService.initialize(),
        embeddingsService.initialize()
      ]);

      this.initialized = true;
      logger.info('RAG service initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize RAG service', error as Error);
      throw error;
    }
  }

  /**
   * Process a RAG query
   */
  async query(ragQuery: RAGQuery): Promise<RAGResponse> {
    await this.initialize();
    
    const startTime = Date.now();
    const {
      query,
      context = {},
      options = {}
    } = ragQuery;

    const {
      topK = 5,
      includeMetadata = true,
      rerank = true,
      hybridSearch = false,
      expandQuery = true
    } = options;

    try {
      // Step 1: Query expansion (if enabled)
      let expandedQueries: string[] = [query];
      if (expandQuery) {
        expandedQueries = await this.expandQuery(query, context);
        logger.info(`Expanded query to ${expandedQueries.length} variations`);
      }

      // Step 2: Retrieve relevant documents
      const retrievalStart = Date.now();
      let retrievedDocs: Array<{
        document: VectorDocument;
        score: number;
        highlights?: string[];
      }> = [];

      if (hybridSearch) {
        // Hybrid search with keywords
        const keywords = this.extractKeywords(query);
        retrievedDocs = await this.hybridRetrieve(
          expandedQueries[0],
          keywords,
          { ...context, topK, includeMetadata }
        );
      } else {
        // Standard semantic search
        retrievedDocs = await this.semanticRetrieve(
          expandedQueries,
          { ...context, topK, includeMetadata }
        );
      }

      const retrievalTime = Date.now() - retrievalStart;

      // Step 3: Re-rank if enabled
      if (rerank && retrievedDocs.length > 0) {
        retrievedDocs = await this.rerankDocuments(query, retrievedDocs);
      }

      // Step 4: Generate answer using LLM
      const generationStart = Date.now();
      const answer = await this.generateAnswer(
        query,
        retrievedDocs,
        context
      );
      const generationTime = Date.now() - generationStart;

      // Step 5: Extract highlights
      const sources = await this.prepareSources(query, retrievedDocs);

      const totalTime = Date.now() - startTime;

      return {
        answer,
        sources,
        metadata: {
          queryExpansion: expandedQueries.length > 1 ? expandedQueries : undefined,
          retrievalTimeMs: retrievalTime,
          generationTimeMs: generationTime,
          totalTimeMs: totalTime,
          model: 'gpt-4' // Default model
        }
      };

    } catch (error) {
      logger.error('RAG query failed', error as Error);
      throw error;
    }
  }

  /**
   * Ingest a clinical document into the RAG system
   */
  async ingestDocument(
    content: string,
    metadata: {
      title: string;
      source: string;
      type: 'clinical_guideline' | 'protocol' | 'drug_info' | 'procedure' | 'policy' | 'research';
      specialty?: string;
      tenantId?: string;
      [key: string]: any;
    }
  ): Promise<DocumentIngestionResult> {
    await this.initialize();

    try {
      // Process document into chunks
      const processedDoc = await clinicalDocumentProcessor.processDocument(
        content,
        metadata.type,
        {
          chunkSize: 512,
          chunkOverlap: 50,
          preserveContext: true,
          extractMetadata: true
        }
      );

      // Convert to vector documents
      const vectorDocs = clinicalDocumentProcessor.toVectorDocuments(
        processedDoc,
        metadata
      );

      // Generate embeddings and store
      const documentIds = await vectorDatabaseService.addDocuments(
        vectorDocs,
        this.getCollectionName(metadata.type)
      );

      logger.info(`Ingested document ${metadata.title} with ${vectorDocs.length} chunks`);

      return {
        documentId: metadata.source,
        chunks: vectorDocs.length,
        status: 'success'
      };

    } catch (error) {
      logger.error('Document ingestion failed', error as Error);
      return {
        documentId: metadata.source,
        chunks: 0,
        status: 'failed',
        error: (error as Error).message
      };
    }
  }

  /**
   * Batch ingest multiple documents
   */
  async batchIngest(
    documents: Array<{
      content: string;
      metadata: any;
    }>
  ): Promise<DocumentIngestionResult[]> {
    const results: DocumentIngestionResult[] = [];

    for (const doc of documents) {
      const result = await this.ingestDocument(doc.content, doc.metadata);
      results.push(result);
    }

    return results;
  }

  /**
   * Update the knowledge base with new information
   */
  async updateKnowledge(
    documentId: string,
    updates: {
      content?: string;
      metadata?: any;
    }
  ): Promise<void> {
    await this.initialize();

    try {
      // If content updated, re-process the document
      if (updates.content) {
        // Get existing metadata
        const existingDoc = await vectorDatabaseService.getDocument(documentId);
        if (!existingDoc) {
          throw new Error(`Document ${documentId} not found`);
        }

        // Delete old chunks
        await vectorDatabaseService.deleteDocuments([documentId]);

        // Re-ingest with updated content
        await this.ingestDocument(updates.content, {
          ...existingDoc.metadata,
          ...updates.metadata
        });
      } else if (updates.metadata) {
        // Just update metadata
        await vectorDatabaseService.updateDocument(
          documentId,
          { metadata: updates.metadata }
        );
      }

      logger.info(`Updated knowledge base document ${documentId}`);
    } catch (error) {
      logger.error('Knowledge update failed', error as Error);
      throw error;
    }
  }

  /**
   * Private helper methods
   */

  private async expandQuery(
    query: string,
    context: any
  ): Promise<string[]> {
    const expansions = [query];

    // Add clinical context expansions
    if (context.useCase === 'clinical_decision') {
      expansions.push(
        `${query} clinical guidelines`,
        `${query} best practices`,
        `${query} evidence-based treatment`
      );
    } else if (context.useCase === 'drug_info') {
      expansions.push(
        `${query} medication information`,
        `${query} drug interactions`,
        `${query} dosage administration`
      );
    }

    // Add specialty-specific expansions
    if (context.specialty) {
      expansions.push(`${query} ${context.specialty}`);
    }

    return expansions;
  }

  private extractKeywords(query: string): string[] {
    // Simple keyword extraction
    const stopWords = new Set([
      'what', 'is', 'the', 'for', 'in', 'a', 'an', 'and', 'or',
      'how', 'when', 'where', 'why', 'which', 'with', 'to', 'of'
    ]);

    return query
      .toLowerCase()
      .split(/\s+/)
      .filter(word => word.length > 2 && !stopWords.has(word));
  }

  private async semanticRetrieve(
    queries: string[],
    options: any
  ): Promise<any[]> {
    const allResults: any[] = [];

    for (const query of queries) {
      const results = await vectorDatabaseService.search(query, {
        k: options.topK || 5,
        filter: {
          tenantId: options.tenantId,
          specialty: options.specialty
        },
        includeMetadata: options.includeMetadata
      });

      allResults.push(...results);
    }

    // Deduplicate and sort by score
    const uniqueResults = this.deduplicateResults(allResults);
    return uniqueResults.slice(0, options.topK || 5);
  }

  private async hybridRetrieve(
    query: string,
    keywords: string[],
    options: any
  ): Promise<any[]> {
    const results = await vectorDatabaseService.hybridSearch(
      query,
      keywords,
      {
        k: options.topK || 5,
        filter: {
          tenantId: options.tenantId,
          specialty: options.specialty
        }
      }
    );

    return results;
  }

  private deduplicateResults(results: any[]): any[] {
    const seen = new Set<string>();
    const unique: any[] = [];

    for (const result of results) {
      const id = result.document.id;
      if (!seen.has(id)) {
        seen.add(id);
        unique.push(result);
      }
    }

    return unique.sort((a, b) => b.score - a.score);
  }

  private async rerankDocuments(
    query: string,
    documents: any[]
  ): Promise<any[]> {
    // Use embeddings service for re-ranking
    const candidates = documents.map(doc => ({
      id: doc.document.id,
      text: doc.document.content,
      originalScore: doc.score,
      metadata: doc.document.metadata
    }));

    const rerankedResults = await embeddingsService.findSimilar(
      query,
      candidates.map(c => ({ id: c.id, text: c.text })),
      documents.length,
      0 // No threshold for re-ranking
    );

    // Combine original and rerank scores
    return rerankedResults.map(result => {
      const original = candidates.find(c => c.id === result.id)!;
      return {
        document: {
          id: result.id,
          content: result.text,
          metadata: original.metadata
        },
        score: (original.originalScore + result.similarity) / 2
      };
    });
  }

  private async generateAnswer(
    query: string,
    retrievedDocs: any[],
    context: any
  ): Promise<string> {
    // Prepare context for LLM
    const contextText = retrievedDocs
      .map((doc, idx) => `[Source ${idx + 1}]: ${doc.document.content}`)
      .join('\n\n');

    const prompt = this.buildPrompt(query, contextText, context);

    // Get AI model adapter
    const config: AIModelConfig = {
      provider: 'gpt4',
      endpoint: process.env.LLM_SERVICE_URL || 'http://localhost:8007',
      maxTokens: 500,
      temperature: 0.3
    };
    const aiAdapter = AIModelFactory.createAdapter(config);

    // Generate response
    const response = await aiAdapter.query({
      prompt,
      systemPrompt: this.getSystemPrompt(context)
    });

    return response.response;
  }

  private buildPrompt(
    query: string,
    context: string,
    userContext: any
  ): string {
    let prompt = `Based on the following clinical knowledge base information, please answer the question accurately and concisely.

Context:
${context}

Question: ${query}

Instructions:
1. Base your answer only on the provided context
2. If the context doesn't contain enough information, state that clearly
3. Reference specific sources when possible
4. Use clinical terminology appropriately`;

    if (userContext.useCase === 'clinical_decision') {
      prompt += '\n5. Include evidence-based recommendations when applicable';
    } else if (userContext.useCase === 'drug_info') {
      prompt += '\n5. Include dosage, contraindications, and interactions if mentioned';
    }

    prompt += '\n\nAnswer:';

    return prompt;
  }

  private getSystemPrompt(context: any): string {
    let systemPrompt = 'You are a clinical knowledge assistant helping healthcare professionals access evidence-based information.';

    if (context.specialty) {
      systemPrompt += ` You have expertise in ${context.specialty}.`;
    }

    systemPrompt += ' Always prioritize patient safety and clinical accuracy in your responses.';

    return systemPrompt;
  }

  private async prepareSources(
    query: string,
    retrievedDocs: any[]
  ): Promise<RAGResponse['sources']> {
    return retrievedDocs.map(doc => ({
      id: doc.document.id,
      content: doc.document.content,
      score: doc.score,
      metadata: doc.document.metadata,
      highlights: doc.highlights || this.extractHighlights(query, doc.document.content)
    }));
  }

  private extractHighlights(query: string, content: string): string[] {
    const queryTerms = query.toLowerCase().split(/\s+/);
    const sentences = content.split(/[.!?]+/);
    const highlights: string[] = [];

    for (const sentence of sentences) {
      const sentenceLower = sentence.toLowerCase();
      const matchCount = queryTerms.filter(term => 
        sentenceLower.includes(term)
      ).length;

      if (matchCount >= 2 || (matchCount === 1 && queryTerms.length === 1)) {
        highlights.push(sentence.trim());
      }

      if (highlights.length >= 3) break;
    }

    return highlights;
  }

  private getCollectionName(docType: string): string {
    const mapping: Record<string, string> = {
      'clinical_guideline': 'clinical_guidelines',
      'protocol': 'medical_protocols',
      'drug_info': 'drug_information',
      'procedure': 'procedures',
      'policy': 'policies',
      'research': 'research_papers'
    };

    return mapping[docType] || 'clinical_guidelines';
  }

  /**
   * Search for similar clinical cases
   */
  async findSimilarCases(
    caseDescription: string,
    options: {
      topK?: number;
      includeRationale?: boolean;
    } = {}
  ): Promise<Array<{
    caseId: string;
    similarity: number;
    summary: string;
    outcome?: string;
    rationale?: string;
  }>> {
    const { topK = 5, includeRationale = true } = options;

    // Search for similar cases
    const results = await vectorDatabaseService.search(caseDescription, {
      k: topK,
      filter: { type: 'clinical_case' }
    });

    // Format results
    const cases: Array<{
      caseId: string;
      similarity: number;
      summary: string;
      outcome?: string;
      rationale?: string;
    }> = results.map(result => ({
      caseId: result.document.id,
      similarity: result.score,
      summary: result.document.content.substring(0, 200) + '...',
      outcome: result.document.metadata.outcome
    }));

    // Add rationale if requested
    if (includeRationale) {
      for (const caseResult of cases) {
        caseResult.rationale = await this.generateCaseRationale(
          caseDescription,
          caseResult.summary
        );
      }
    }

    return cases;
  }

  private async generateCaseRationale(
    queryCase: string,
    similarCase: string
  ): Promise<string> {
    const prompt = `Compare these two clinical cases and explain their similarities:

Case 1 (Query): ${queryCase}

Case 2 (Retrieved): ${similarCase}

Provide a brief rationale for why these cases are similar:`;

    const config: AIModelConfig = {
      provider: 'gpt4',
      endpoint: process.env.LLM_SERVICE_URL || 'http://localhost:8007',
      maxTokens: 150,
      temperature: 0.3
    };
    const aiAdapter = AIModelFactory.createAdapter(config);
    const response = await aiAdapter.query({
      prompt
    });

    return response.response;
  }
}

// Export singleton instance
export const ragService = new RAGService();