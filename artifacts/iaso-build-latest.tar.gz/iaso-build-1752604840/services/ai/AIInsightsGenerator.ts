/**
 * AI Insights Generator
 * 
 * Generates AI-powered insights and performs anomaly detection on healthcare metrics.
 * Integrates with LLM services for natural language insights and statistical analysis.
 */

import axios from 'axios';

import { logger } from '../../utils/logger';
import { getClickHouseClient } from '../clickhouse';
// import { ragService } from './RAGService';

export interface InsightRequest {
  tenantId: string;
  userId: string;
  metricId: string;
  timeRange: {
    start?: Date;
    end?: Date;
    period?: string;
  };
  options?: {
    includeComparisons?: boolean;
    includePredictions?: boolean;
    includeRecommendations?: boolean;
    contextualFactors?: string[];
  };
}

export interface AnomalyRequest {
  tenantId: string;
  metricId: string;
  sensitivity: 'low' | 'medium' | 'high';
  timeRange: {
    start?: Date;
    end?: Date;
    period?: string;
  };
}

export interface GeneratedInsight {
  id: string;
  type: 'trend' | 'anomaly' | 'prediction' | 'recommendation' | 'comparison';
  title: string;
  description: string;
  severity: 'info' | 'warning' | 'critical';
  confidence: number;
  data: {
    current_value?: number;
    previous_value?: number;
    change_percentage?: number;
    statistical_significance?: number;
    supporting_data?: any[];
  };
  recommendations?: string[];
  timestamp: Date;
  expires_at?: Date;
}

export interface DetectedAnomaly {
  id: string;
  timestamp: Date;
  metric_value: number;
  expected_value: number;
  deviation_score: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  type: 'spike' | 'drop' | 'trend_break' | 'seasonal_deviation';
  description: string;
  potential_causes?: string[];
  recommended_actions?: string[];
  confidence: number;
}

export class AIInsightsGenerator {
  private llmEndpoint: string;
  private readonly ANOMALY_THRESHOLDS = {
    low: 2.0,     // 2 standard deviations
    medium: 2.5,   // 2.5 standard deviations  
    high: 3.0      // 3 standard deviations
  };

  constructor() {
    this.llmEndpoint = process.env.LLM_SERVICE_URL || 'http://localhost:8007';
  }

  // private async initializeRAGService() {
  //   if (!ragService) {
  //     try {
  //       const module = await import('./RAGService');
  //       ragService = module.ragService;
  //     } catch (error) {
  //       logger.warn('RAG service not available, using mock', error);
  //       // Mock RAG service
  //       ragService = {
  //         query: async () => ({
  //           answer: 'RAG service not configured',
  //           sources: [],
  //           metadata: { retrievalTimeMs: 0, generationTimeMs: 0, totalTimeMs: 0 }
  //         })
  //       };
  //     }
  //   }
  // }

  /**
   * Generate AI insights for a metric
   */
  async generateInsights(request: InsightRequest): Promise<GeneratedInsight[]> {
    try {
      logger.info('Generating AI insights', { 
        metricId: request.metricId, 
        tenantId: request.tenantId 
      });

      // Get metric data and statistics
      const metricData = await this.getMetricData(request);
      const statistics = await this.calculateStatistics(metricData);
      
      const insights: GeneratedInsight[] = [];

      // Generate trend insights
      if (request.options?.includeComparisons !== false) {
        const trendInsight = await this.generateTrendInsight(request, metricData, statistics);
        if (trendInsight) insights.push(trendInsight);
      }

      // Generate comparison insights
      if (request.options?.includeComparisons) {
        const comparisonInsight = await this.generateComparisonInsight(request, metricData);
        if (comparisonInsight) insights.push(comparisonInsight);
      }

      // Generate predictions
      if (request.options?.includePredictions) {
        const predictionInsight = await this.generatePredictionInsight(request, metricData);
        if (predictionInsight) insights.push(predictionInsight);
      }

      // Generate recommendations
      if (request.options?.includeRecommendations) {
        const recommendations = await this.generateRecommendations(request, metricData, statistics);
        insights.push(...recommendations);
      }

      // Store insights in ClickHouse
      await this.storeInsights(request.tenantId, insights);

      logger.info('Generated AI insights', { 
        metricId: request.metricId, 
        insightCount: insights.length 
      });

      return insights;

    } catch (error) {
      logger.error('Failed to generate AI insights', error as Error);
      throw error;
    }
  }

  /**
   * Detect anomalies in metric data
   */
  async detectAnomalies(request: AnomalyRequest): Promise<DetectedAnomaly[]> {
    try {
      logger.info('Detecting anomalies', { 
        metricId: request.metricId, 
        sensitivity: request.sensitivity 
      });

      // Get time series data
      const timeSeriesData = await this.getTimeSeriesData(request);
      
      if (timeSeriesData.length < 10) {
        logger.warn('Insufficient data for anomaly detection', { 
          metricId: request.metricId,
          dataPoints: timeSeriesData.length 
        });
        return [];
      }

      const anomalies: DetectedAnomaly[] = [];
      const threshold = this.ANOMALY_THRESHOLDS[request.sensitivity];

      // Statistical anomaly detection
      const statisticalAnomalies = await this.detectStatisticalAnomalies(
        timeSeriesData, 
        threshold
      );
      anomalies.push(...statisticalAnomalies);

      // Trend break detection
      const trendBreaks = await this.detectTrendBreaks(timeSeriesData);
      anomalies.push(...trendBreaks);

      // Seasonal anomaly detection
      const seasonalAnomalies = await this.detectSeasonalAnomalies(timeSeriesData);
      anomalies.push(...seasonalAnomalies);

      // Use AI to analyze anomalies and provide context
      for (const anomaly of anomalies) {
        await this.enrichAnomalyWithAI(anomaly, request);
      }

      // Store anomalies in ClickHouse
      await this.storeAnomalies(request.tenantId, anomalies);

      logger.info('Detected anomalies', { 
        metricId: request.metricId, 
        anomalyCount: anomalies.length 
      });

      return anomalies;

    } catch (error) {
      logger.error('Failed to detect anomalies', error as Error);
      throw error;
    }
  }

  /**
   * Get metric data from ClickHouse
   */
  private async getMetricData(request: InsightRequest): Promise<any[]> {
    const client = getClickHouseClient();
    
    const timeFilter = this.buildTimeFilter(request.timeRange);
    
    const query = `
      SELECT 
        calculated_at,
        metric_value,
        dimension_values,
        event_count
      FROM nexuscare_analytics.metric_values
      WHERE tenant_id = {tenant_id:String}
        AND metric_id = {metric_id:String}
        ${timeFilter}
      ORDER BY calculated_at ASC
    `;

    const result = await client.query({
      query,
      query_params: {
        tenant_id: request.tenantId,
        metric_id: request.metricId
      },
      format: 'JSONEachRow'
    }).toPromise();

    return Array.isArray(result) ? result : [];
  }

  /**
   * Get time series data for anomaly detection
   */
  private async getTimeSeriesData(request: AnomalyRequest): Promise<any[]> {
    const client = getClickHouseClient();
    
    const timeFilter = this.buildTimeFilter(request.timeRange);
    
    const query = `
      SELECT 
        calculated_at,
        metric_value,
        LAG(metric_value, 1) OVER (ORDER BY calculated_at) as previous_value,
        LAG(metric_value, 7) OVER (ORDER BY calculated_at) as week_ago_value
      FROM nexuscare_analytics.metric_values
      WHERE tenant_id = {tenant_id:String}
        AND metric_id = {metric_id:String}
        ${timeFilter}
      ORDER BY calculated_at ASC
    `;

    const result = await client.query({
      query,
      query_params: {
        tenant_id: request.tenantId,
        metric_id: request.metricId
      },
      format: 'JSONEachRow'
    }).toPromise();

    return Array.isArray(result) ? result : [];
  }

  /**
   * Calculate basic statistics
   */
  private async calculateStatistics(data: any[]): Promise<any> {
    if (data.length === 0) return {};

    const values = data.map(d => d.metric_value).filter(v => v !== null);
    
    const sum = values.reduce((a, b) => a + b, 0);
    const mean = sum / values.length;
    const variance = values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / values.length;
    const stdDev = Math.sqrt(variance);
    
    values.sort((a, b) => a - b);
    const median = values.length % 2 === 0 
      ? (values[values.length / 2 - 1] + values[values.length / 2]) / 2
      : values[Math.floor(values.length / 2)];

    return {
      count: values.length,
      sum,
      mean,
      median,
      stdDev,
      variance,
      min: Math.min(...values),
      max: Math.max(...values),
      latest: data[data.length - 1]?.metric_value,
      earliest: data[0]?.metric_value
    };
  }

  /**
   * Generate trend insight using AI
   */
  private async generateTrendInsight(
    request: InsightRequest,
    data: any[],
    stats: any
  ): Promise<GeneratedInsight | null> {
    if (data.length < 2) return null;

    const recent = data.slice(-7); // Last 7 data points
    const older = data.slice(-14, -7); // Previous 7 data points

    const recentAvg = recent.reduce((sum, d) => sum + d.metric_value, 0) / recent.length;
    const olderAvg = older.length > 0 
      ? older.reduce((sum, d) => sum + d.metric_value, 0) / older.length 
      : recentAvg;

    const changePercentage = olderAvg !== 0 
      ? ((recentAvg - olderAvg) / olderAvg) * 100 
      : 0;

    // Use AI to generate natural language description
    const description = await this.generateTrendDescription(
      request.metricId, 
      changePercentage, 
      recentAvg, 
      olderAvg
    );

    const severity = Math.abs(changePercentage) > 20 ? 'warning' : 
                    Math.abs(changePercentage) > 50 ? 'critical' : 'info';

    return {
      id: `trend_${request.metricId}_${Date.now()}`,
      type: 'trend',
      title: `Trend Analysis: ${Math.abs(changePercentage).toFixed(1)}% ${changePercentage > 0 ? 'increase' : 'decrease'}`,
      description,
      severity,
      confidence: Math.min(0.95, 0.7 + (Math.abs(changePercentage) / 100)),
      data: {
        current_value: recentAvg,
        previous_value: olderAvg,
        change_percentage: changePercentage,
        statistical_significance: this.calculateSignificance(recent, older)
      },
      timestamp: new Date(),
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
    };
  }

  /**
   * Generate AI-powered trend description
   */
  private async generateTrendDescription(
    metricId: string,
    changePercentage: number,
    current: number,
    previous: number
  ): Promise<string> {
    try {
      // RAG integration temporarily disabled
      // await this.initializeRAGService();
      
      const prompt = `Analyze this healthcare metric trend:
Metric: ${metricId}
Change: ${changePercentage.toFixed(1)}% ${changePercentage > 0 ? 'increase' : 'decrease'}
Current value: ${current.toFixed(2)}
Previous value: ${previous.toFixed(2)}

Provide a concise, professional analysis in 1-2 sentences focusing on clinical significance.`;

      const response = await axios.post(`${this.llmEndpoint}/analyze`, {
        prompt,
        max_tokens: 150,
        temperature: 0.3
      });

      return response.data.response || `The metric shows a ${Math.abs(changePercentage).toFixed(1)}% ${changePercentage > 0 ? 'increase' : 'decrease'} compared to the previous period.`;
    } catch (error) {
      logger.warn('Failed to generate AI trend description', error);
      return `The metric shows a ${Math.abs(changePercentage).toFixed(1)}% ${changePercentage > 0 ? 'increase' : 'decrease'} compared to the previous period.`;
    }
  }

  /**
   * Detect statistical anomalies using z-score
   */
  private async detectStatisticalAnomalies(
    data: any[],
    threshold: number
  ): Promise<DetectedAnomaly[]> {
    const values = data.map(d => d.metric_value);
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const stdDev = Math.sqrt(
      values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / values.length
    );

    const anomalies: DetectedAnomaly[] = [];

    data.forEach((point, index) => {
      const zScore = Math.abs((point.metric_value - mean) / stdDev);
      
      if (zScore > threshold) {
        const severity = zScore > 4 ? 'critical' : 
                        zScore > 3.5 ? 'high' : 
                        zScore > 3 ? 'medium' : 'low';

        const type = point.metric_value > mean ? 'spike' : 'drop';

        anomalies.push({
          id: `anomaly_${Date.now()}_${index}`,
          timestamp: new Date(point.calculated_at),
          metric_value: point.metric_value,
          expected_value: mean,
          deviation_score: zScore,
          severity,
          type,
          description: `${type === 'spike' ? 'Unusual spike' : 'Unusual drop'} detected (${zScore.toFixed(2)} standard deviations from normal)`,
          confidence: Math.min(0.99, 0.5 + (zScore / 10))
        });
      }
    });

    return anomalies;
  }

  /**
   * Detect trend breaks
   */
  private async detectTrendBreaks(data: any[]): Promise<DetectedAnomaly[]> {
    if (data.length < 10) return [];

    const anomalies: DetectedAnomaly[] = [];
    const windowSize = 5;

    for (let i = windowSize; i < data.length - windowSize; i++) {
      const beforeWindow = data.slice(i - windowSize, i);
      const afterWindow = data.slice(i, i + windowSize);

      const beforeTrend = this.calculateTrend(beforeWindow);
      const afterTrend = this.calculateTrend(afterWindow);

      // Detect significant trend changes
      const trendChange = Math.abs(afterTrend - beforeTrend);
      
      if (trendChange > 0.5) { // Threshold for trend break
        anomalies.push({
          id: `trend_break_${Date.now()}_${i}`,
          timestamp: new Date(data[i].calculated_at),
          metric_value: data[i].metric_value,
          expected_value: data[i].metric_value, // Could be improved with prediction
          deviation_score: trendChange,
          severity: trendChange > 1 ? 'high' : 'medium',
          type: 'trend_break',
          description: 'Significant trend change detected',
          confidence: Math.min(0.9, 0.6 + (trendChange / 2))
        });
      }
    }

    return anomalies;
  }

  /**
   * Detect seasonal anomalies (simplified)
   */
  private async detectSeasonalAnomalies(data: any[]): Promise<DetectedAnomaly[]> {
    // This is a simplified implementation
    // In production, you'd want more sophisticated seasonal decomposition
    return [];
  }

  /**
   * Enrich anomaly with AI analysis
   */
  private async enrichAnomalyWithAI(
    anomaly: DetectedAnomaly,
    request: AnomalyRequest
  ): Promise<void> {
    try {
      // RAG integration temporarily disabled
      /*
      const ragQuery = `${request.metricId} anomaly ${anomaly.type} healthcare operations response protocol`;
      
      const ragResponse = await ragService.query({
        query: ragQuery,
        context: {
          useCase: 'protocol'
        },
        options: {
          topK: 3,
          includeMetadata: true,
          hybridSearch: true
        }
      });

      // Build enhanced prompt with RAG context
      const contextSummary = ragResponse.sources.length > 0
        ? `\nRelevant protocols and guidelines:\n${ragResponse.sources.map(s => s.content).join('\n').substring(0, 500)}`
        : '';

      const prompt = `Analyze this healthcare metric anomaly:
Type: ${anomaly.type}
Severity: ${anomaly.severity}
Metric ID: ${request.metricId}
Metric Value: ${anomaly.metric_value}
Expected: ${anomaly.expected_value}
Deviation: ${anomaly.deviation_score.toFixed(2)} standard deviations
${contextSummary}

Based on clinical best practices, provide:
1. 2-3 potential causes
2. 2-3 recommended actions for healthcare operations

Format each cause and action on a new line starting with "Cause:" or "Action:".`;
      */

      const prompt = `Analyze this healthcare metric anomaly:
Type: ${anomaly.type}
Severity: ${anomaly.severity}
Metric ID: ${request.metricId}
Metric Value: ${anomaly.metric_value}
Expected: ${anomaly.expected_value}
Deviation: ${anomaly.deviation_score.toFixed(2)} standard deviations

Based on clinical best practices, provide:
1. 2-3 potential causes
2. 2-3 recommended actions for healthcare operations

Format each cause and action on a new line starting with "Cause:" or "Action:".`;

      const response = await axios.post(`${this.llmEndpoint}/analyze`, {
        prompt,
        max_tokens: 300,
        temperature: 0.4
      });

      const analysis = response.data.response;
      
      // Parse the response to extract causes and actions
      const lines = analysis.split('\n').filter((line: string) => line.trim());
      
      anomaly.potential_causes = lines
        .filter((line: string) => line.toLowerCase().includes('cause:'))
        .map((line: string) => line.replace(/^cause:/i, '').replace(/^\s+/, '').trim())
        .slice(0, 3);
        
      anomaly.recommended_actions = lines
        .filter((line: string) => line.toLowerCase().includes('action:'))
        .map((line: string) => line.replace(/^action:/i, '').replace(/^\s+/, '').trim())
        .slice(0, 3);

      // If structured parsing failed, fall back to generic parsing
      if (anomaly.potential_causes.length === 0) {
        anomaly.potential_causes = lines
          .filter((line: string) => line.toLowerCase().includes('cause') || line.toLowerCase().includes('due to'))
          .slice(0, 3);
      }
      
      if (anomaly.recommended_actions.length === 0) {
        anomaly.recommended_actions = lines
          .filter((line: string) => line.toLowerCase().includes('action') || line.toLowerCase().includes('recommend'))
          .slice(0, 3);
      }

    } catch (error) {
      logger.warn('Failed to enrich anomaly with AI', error);
      // Provide default recommendations based on anomaly type
      anomaly.potential_causes = [`${anomaly.type} detected in healthcare metric`];
      anomaly.recommended_actions = ['Review recent operational changes', 'Monitor metric closely'];
    }
  }

  /**
   * Helper methods
   */
  private buildTimeFilter(timeRange: any): string {
    if (timeRange.start && timeRange.end) {
      return `AND calculated_at BETWEEN '${timeRange.start.toISOString()}' AND '${timeRange.end.toISOString()}'`;
    }
    
    if (timeRange.period) {
      const periodMap: Record<string, string> = {
        'last_7_days': 'AND calculated_at >= now() - INTERVAL 7 DAY',
        'last_30_days': 'AND calculated_at >= now() - INTERVAL 30 DAY',
        'last_90_days': 'AND calculated_at >= now() - INTERVAL 90 DAY'
      };
      
      return periodMap[timeRange.period] || 'AND calculated_at >= now() - INTERVAL 30 DAY';
    }
    
    return 'AND calculated_at >= now() - INTERVAL 30 DAY';
  }

  private calculateTrend(data: any[]): number {
    if (data.length < 2) return 0;
    
    const values = data.map(d => d.metric_value);
    const n = values.length;
    const sumX = (n * (n - 1)) / 2;
    const sumY = values.reduce((a, b) => a + b, 0);
    const sumXY = values.reduce((sum, y, x) => sum + x * y, 0);
    const sumX2 = (n * (n - 1) * (2 * n - 1)) / 6;
    
    return (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  }

  private calculateSignificance(recent: any[], older: any[]): number {
    // Simplified t-test implementation
    if (recent.length === 0 || older.length === 0) return 0;
    
    const recentValues = recent.map(d => d.metric_value);
    const olderValues = older.map(d => d.metric_value);
    
    const recentMean = recentValues.reduce((a, b) => a + b, 0) / recentValues.length;
    const olderMean = olderValues.reduce((a, b) => a + b, 0) / olderValues.length;
    
    const recentVar = recentValues.reduce((a, b) => a + Math.pow(b - recentMean, 2), 0) / recentValues.length;
    const olderVar = olderValues.reduce((a, b) => a + Math.pow(b - olderMean, 2), 0) / olderValues.length;
    
    const pooledStdDev = Math.sqrt((recentVar + olderVar) / 2);
    const tStat = Math.abs(recentMean - olderMean) / (pooledStdDev * Math.sqrt(2 / recent.length));
    
    return Math.min(0.99, tStat / 3); // Normalized to 0-1
  }

  private async generateComparisonInsight(request: InsightRequest, data: any[]): Promise<GeneratedInsight | null> {
    // Implementation for comparison insights
    return null;
  }

  private async generatePredictionInsight(request: InsightRequest, data: any[]): Promise<GeneratedInsight | null> {
    // Implementation for prediction insights
    return null;
  }

  private async generateRecommendations(request: InsightRequest, data: any[], stats: any): Promise<GeneratedInsight[]> {
    try {
      // RAG integration temporarily disabled - using direct LLM for recommendations
      const prompt = `Based on the metric data, provide actionable recommendations:

Metric: ${request.metricId}
Current Stats:
- Mean: ${stats.mean?.toFixed(2) || 'N/A'}
- Latest: ${stats.latest?.toFixed(2) || 'N/A'}
- Trend: ${((stats.latest - stats.earliest) / stats.earliest * 100).toFixed(1)}% change

Provide 2-3 specific, actionable recommendations for improving this metric. Format each as:
"Recommendation: [specific action]"`;

      const response = await axios.post(`${this.llmEndpoint}/analyze`, {
        prompt,
        max_tokens: 300,
        temperature: 0.4
      });

      const analysis = response.data.response;
      const recommendations = analysis.split('\n')
        .filter((line: string) => line.toLowerCase().includes('recommendation:'))
        .map((line: string) => line.replace(/^recommendation:\s*/i, '').trim())
        .slice(0, 3);

      if (recommendations.length === 0) {
        return [];
      }

      // Create recommendation insights
      return recommendations.map((rec, index) => ({
        id: `rec_${request.metricId}_${Date.now()}_${index}`,
        type: 'recommendation' as const,
        title: 'Clinical Best Practice Recommendation',
        description: rec,
        severity: 'info' as const,
        confidence: 0.8,
        data: {
          current_value: stats.latest,
          statistical_significance: 0.75,
          supporting_data: []
        },
        recommendations: [rec],
        timestamp: new Date(),
        expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
      }));

    } catch (error) {
      logger.warn('Failed to generate recommendations', error);
      return [];
    }
  }

  private async storeInsights(tenantId: string, insights: GeneratedInsight[]): Promise<void> {
    const client = getClickHouseClient();
    
    const values = insights.map(insight => ({
      event_time: insight.timestamp,
      tenant_id: tenantId,
      insight_id: insight.id,
      insight_type: insight.type,
      title: insight.title,
      description: insight.description,
      severity: insight.severity,
      confidence_score: insight.confidence,
      insight_data: JSON.stringify(insight.data),
      recommendations: JSON.stringify(insight.recommendations || []),
      expires_at: insight.expires_at,
      insight_hash: this.generateInsightHash(insight)
    }));

    await client.insert({
      table: 'nexuscare_analytics.insight_events',
      values,
      format: 'JSONEachRow'
    });
  }

  private async storeAnomalies(tenantId: string, anomalies: DetectedAnomaly[]): Promise<void> {
    // Store anomalies as special insight events
    const insights: GeneratedInsight[] = anomalies.map(anomaly => ({
      id: anomaly.id,
      type: 'anomaly',
      title: `Anomaly Detected: ${anomaly.type}`,
      description: anomaly.description,
      severity: anomaly.severity === 'critical' ? 'critical' : 
               anomaly.severity === 'high' ? 'warning' : 'info',
      confidence: anomaly.confidence,
      data: {
        current_value: anomaly.metric_value,
        expected_value: anomaly.expected_value,
        deviation_score: anomaly.deviation_score
      },
      recommendations: anomaly.recommended_actions,
      timestamp: anomaly.timestamp
    }));

    await this.storeInsights(tenantId, insights);
  }

  private generateInsightHash(insight: GeneratedInsight): string {
    const hashContent = `${insight.type}_${insight.title}_${JSON.stringify(insight.data)}`;
    // Simple hash - in production use crypto.createHash
    return Buffer.from(hashContent).toString('base64').slice(0, 16);
  }
}

export default AIInsightsGenerator;