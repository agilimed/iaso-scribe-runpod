/**
 * AI Model Adapter Interface
 * 
 * Provides a unified interface for different AI models (Qwen3, GPT-4, Claude, etc.)
 * with support for both direct and MCP-based integrations.
 */

import { logger } from '../../utils/logger';

export interface AIModelConfig {
  provider: 'gpt4' | 'claude' | 'gemini' | 'custom';
  endpoint: string;
  apiKey?: string;
  model?: string;
  temperature?: number;
  maxTokens?: number;
  timeout?: number;
  customHeaders?: Record<string, string>;
}

export interface AIQueryRequest {
  prompt: string;
  systemPrompt?: string;
  context?: any;
  tools?: AITool[];
  stream?: boolean;
}

export interface AIQueryResponse {
  response: string;
  usage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  toolCalls?: AIToolCall[];
  metadata?: any;
}

export interface AITool {
  name: string;
  description: string;
  parameters?: any;
  execute?: (params: any) => Promise<any>;
}

export interface AIToolCall {
  name: string;
  arguments: any;
  result?: any;
}

export abstract class AIModelAdapter {
  protected config: AIModelConfig;

  constructor(config: AIModelConfig) {
    this.config = config;
  }

  /**
   * Send a query to the AI model
   */
  abstract query(request: AIQueryRequest): Promise<AIQueryResponse>;

  /**
   * Register tools/functions with the AI model
   */
  abstract registerTools(tools: AITool[]): Promise<void>;

  /**
   * Convert natural language to SQL
   */
  abstract nlToSQL(query: string, context: any): Promise<string>;

  /**
   * Extract entities from text
   */
  abstract extractEntities(text: string, entityTypes: string[]): Promise<any[]>;

  /**
   * Classify intent
   */
  abstract classifyIntent(text: string, intents: string[]): Promise<{ intent: string; confidence: number }>;

  /**
   * Get model capabilities
   */
  abstract getCapabilities(): {
    supportsTools: boolean;
    supportsStreaming: boolean;
    supportsMCP: boolean;
    maxContextLength: number;
    supportedLanguages: string[];
  };
}

// Removed Qwen3Adapter class - Qwen3 no longer used

/**
 * GPT-4 Model Adapter
 */
export class GPT4Adapter extends AIModelAdapter {
  async query(request: AIQueryRequest): Promise<AIQueryResponse> {
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.apiKey}`,
          ...this.config.customHeaders
        },
        body: JSON.stringify({
          model: this.config.model || 'gpt-4-turbo-preview',
          messages: [
            ...(request.systemPrompt ? [{ role: 'system', content: request.systemPrompt }] : []),
            { role: 'user', content: request.prompt }
          ],
          temperature: this.config.temperature || 0.3,
          max_tokens: this.config.maxTokens || 1000,
          tools: request.tools?.map(t => ({
            type: 'function',
            function: {
              name: t.name,
              description: t.description,
              parameters: t.parameters
            }
          })),
          stream: request.stream || false
        }),
        signal: AbortSignal.timeout(this.config.timeout || 30000)
      });

      const data = await response.json();

      return {
        response: data.choices[0].message.content,
        usage: data.usage,
        toolCalls: data.choices[0].message.tool_calls?.map((tc: any) => ({
          name: tc.function.name,
          arguments: JSON.parse(tc.function.arguments)
        }))
      };
    } catch (error) {
      logger.error('GPT-4 query failed', error as Error);
      throw error;
    }
  }

  async registerTools(tools: AITool[]): Promise<void> {
    logger.info('Tools will be registered with each GPT-4 request', { toolCount: tools.length });
  }

  async nlToSQL(query: string, context: any): Promise<string> {
    const response = await this.query({
      prompt: query,
      systemPrompt: `You are a SQL expert. Convert natural language queries to ClickHouse SQL.
Database context: ${JSON.stringify(context)}
Return only the SQL query.`,
    });

    return response.response.trim();
  }

  async extractEntities(text: string, entityTypes: string[]): Promise<any[]> {
    const response = await this.query({
      prompt: `Extract medical entities from: "${text}"
Entity types: ${entityTypes.join(', ')}
Return JSON array with structure: [{"text": "...", "type": "...", "value": "..."}]`,
    });

    try {
      return JSON.parse(response.response);
    } catch {
      return [];
    }
  }

  async classifyIntent(text: string, intents: string[]): Promise<{ intent: string; confidence: number }> {
    const response = await this.query({
      prompt: `Classify the intent of: "${text}"
Possible intents: ${intents.join(', ')}
Return JSON: {"intent": "selected_intent", "confidence": 0.0-1.0}`,
    });

    try {
      return JSON.parse(response.response);
    } catch {
      return { intent: 'unknown', confidence: 0.5 };
    }
  }

  getCapabilities() {
    return {
      supportsTools: true,
      supportsStreaming: true,
      supportsMCP: false, // OpenAI doesn't support MCP directly
      maxContextLength: 128000,
      supportedLanguages: ['en', 'es', 'fr', 'de', 'it', 'pt', 'nl', 'ja', 'ko', 'zh']
    };
  }
}

/**
 * Claude Model Adapter
 */
export class ClaudeAdapter extends AIModelAdapter {
  async query(request: AIQueryRequest): Promise<AIQueryResponse> {
    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': this.config.apiKey!,
          'anthropic-version': '2023-06-01',
          ...this.config.customHeaders
        },
        body: JSON.stringify({
          model: this.config.model || 'claude-3-opus-20240229',
          messages: [
            { role: 'user', content: request.prompt }
          ],
          system: request.systemPrompt,
          max_tokens: this.config.maxTokens || 1000,
          temperature: this.config.temperature || 0.3,
          tools: request.tools?.map(t => ({
            name: t.name,
            description: t.description,
            input_schema: t.parameters
          }))
        }),
        signal: AbortSignal.timeout(this.config.timeout || 30000)
      });

      const data = await response.json();

      return {
        response: data.content[0].text,
        usage: {
          promptTokens: data.usage.input_tokens,
          completionTokens: data.usage.output_tokens,
          totalTokens: data.usage.input_tokens + data.usage.output_tokens
        },
        toolCalls: data.content.filter((c: any) => c.type === 'tool_use').map((tc: any) => ({
          name: tc.name,
          arguments: tc.input
        }))
      };
    } catch (error) {
      logger.error('Claude query failed', error as Error);
      throw error;
    }
  }

  async registerTools(tools: AITool[]): Promise<void> {
    logger.info('Tools will be registered with each Claude request', { toolCount: tools.length });
  }

  async nlToSQL(query: string, context: any): Promise<string> {
    const response = await this.query({
      prompt: query,
      systemPrompt: `You are a ClickHouse SQL expert. Convert natural language to SQL.
Database: ${JSON.stringify(context)}
Respond with only the SQL query.`,
    });

    return response.response.trim();
  }

  async extractEntities(text: string, entityTypes: string[]): Promise<any[]> {
    const response = await this.query({
      prompt: `Extract entities from: "${text}"
Types: ${entityTypes.join(', ')}
Return JSON array: [{"text": "...", "type": "...", "value": "..."}]`,
    });

    try {
      return JSON.parse(response.response);
    } catch {
      return [];
    }
  }

  async classifyIntent(text: string, intents: string[]): Promise<{ intent: string; confidence: number }> {
    const response = await this.query({
      prompt: `Classify intent: "${text}"
Options: ${intents.join(', ')}
Return JSON: {"intent": "...", "confidence": 0.0-1.0}`,
    });

    try {
      return JSON.parse(response.response);
    } catch {
      return { intent: 'unknown', confidence: 0.5 };
    }
  }

  getCapabilities() {
    return {
      supportsTools: true,
      supportsStreaming: true,
      supportsMCP: true, // Claude Desktop supports MCP
      maxContextLength: 200000,
      supportedLanguages: ['en', 'es', 'fr', 'de', 'it', 'pt', 'ja', 'ko', 'zh']
    };
  }
}

/**
 * AI Model Factory
 */
export class AIModelFactory {
  private static adapters: Map<string, AIModelAdapter> = new Map();

  static createAdapter(config: AIModelConfig): AIModelAdapter {
    const key = `${config.provider}_${config.endpoint}`;
    
    if (this.adapters.has(key)) {
      return this.adapters.get(key)!;
    }

    let adapter: AIModelAdapter;

    switch (config.provider) {
      // case 'qwen3': // Qwen3 removed
      //   adapter = new Qwen3Adapter(config);
      //   break;
      case 'gpt4':
        adapter = new GPT4Adapter(config);
        break;
      case 'claude':
        adapter = new ClaudeAdapter(config);
        break;
      default:
        throw new Error(`Unsupported AI provider: ${config.provider}`);
    }

    this.adapters.set(key, adapter);
    return adapter;
  }

  static clearCache(): void {
    this.adapters.clear();
  }
}