import {
  VectorStoreIndex,
  SimpleVectorStore,
  Document,
  Settings,
} from 'llamaindex';

import { healthcareLogger } from '../../monitoring/StructuredLogger';

import { RemoteEmbeddings, createEmbedding } from './RemoteEmbeddings';

const logger = healthcareLogger;

export interface QueryContext {
  sessionId: string;
  userId: string;
  tenantId: string;
  previousQueries?: string[];
  filters?: Record<string, any>;
}

export class SimpleLlamaIndexQueryEngine {
  private vectorStore: SimpleVectorStore | null = null;
  private index: VectorStoreIndex | null = null;
  private initialized = false;
  
  constructor() {
    // TODO: Configure your preferred LLM here
    // Settings.llm = new YourLLM({});

    // Configure Remote Embeddings
    Settings.embedModel = createEmbedding('general');
  }

  async initialize(): Promise<void> {
    try {
      logger.info('[SimpleLlamaIndex] Initializing Query Engine...');
      
      // Create a simple vector store
      this.vectorStore = new SimpleVectorStore();
      
      // Create some sample documents about our schema
      const documents = [
        new Document({
          text: `The FHIR database contains healthcare resources in a table called 'fhir_current'. 
                 Table columns: tenant_id (tenant identifier), domain (resource domain), resource_type (FHIR type like Patient, Observation), 
                 resource_id (unique resource identifier), version (version number), version_time (timestamp), 
                 sign (1 for active, -1 for deleted), resource (full FHIR resource as JSON), 
                 event_type (create/update/delete), source_system, correlation_id, created_by, hot_fields (optimized fields).
                 IMPORTANT: Use resource_id NOT id for counting or identifying resources.`,
          metadata: { type: 'schema', source: 'clickhouse' }
        }),
        new Document({
          text: `To query patient data, use: SELECT * FROM fhir_current WHERE resource_type = 'Patient' 
                 AND JSONExtractString(resource, 'identifier[0].value') = 'MRN123'`,
          metadata: { type: 'example', source: 'patient_query' }
        }),
        new Document({
          text: `To query observations, use: SELECT * FROM fhir_current WHERE resource_type = 'Observation' 
                 AND JSONExtractString(resource, 'code.coding[0].code') = '15074-8'`,
          metadata: { type: 'example', source: 'observation_query' }
        }),
        new Document({
          text: `To count unique observations: SELECT COUNT(DISTINCT resource_id) FROM fhir_current 
                 WHERE resource_type = 'Observation' AND JSONExtractString(resource, 'code.coding[0].code') = '55284-4'`,
          metadata: { type: 'example', source: 'count_query' }
        }),
      ];
      
      // Create index from documents
      this.index = await VectorStoreIndex.fromDocuments(documents, {
        vectorStore: this.vectorStore,
      });
      
      this.initialized = true;
      logger.info('[SimpleLlamaIndex] Query Engine initialized successfully');
    } catch (error) {
      logger.error('[SimpleLlamaIndex] Failed to initialize', {
        metadata: { error: (error as Error).message }
      });
      throw error;
    }
  }

  async query(query: string, context?: QueryContext): Promise<any> {
    if (!this.initialized || !this.index) {
      throw new Error('Query engine not initialized');
    }

    try {
      logger.info('[SimpleLlamaIndex] Processing query', {
        component: 'SimpleLlamaIndexQueryEngine',
        operation: 'query',
        metadata: { query: query.substring(0, 100) }
      });

      // Create a query engine from the index
      const queryEngine = this.index.asQueryEngine();
      
      // Execute the query
      const response = await queryEngine.query({
        query,
      });

      return {
        response: response.toString(),
        sourceNodes: response.sourceNodes,
      };
    } catch (error) {
      logger.error('[SimpleLlamaIndex] Query failed', {
        metadata: { error: (error as Error).message }
      });
      throw error;
    }
  }

  async getHealth(): Promise<any> {
    return {
      status: this.initialized ? 'healthy' : 'not_initialized',
      vectorStore: this.vectorStore ? 'ready' : 'not_ready',
      index: this.index ? 'ready' : 'not_ready',
    };
  }

  async updateConversationMemory(sessionId: string, interaction: any): Promise<void> {
    // Add the interaction to the vector store for future queries
    if (this.index && interaction.naturalQuery && interaction.generatedSQL) {
      const doc = new Document({
        text: `Question: ${interaction.naturalQuery}\nSQL: ${interaction.generatedSQL}`,
        metadata: { 
          type: 'interaction',
          sessionId,
          timestamp: new Date().toISOString()
        }
      });
      
      // In a real implementation, we'd add this to the existing index
      // For now, just log it
      logger.info('[SimpleLlamaIndex] Updated conversation memory', {
        sessionId,
        operation: 'updateConversationMemory'
      });
    }
  }

  async generateSQL(query: string, context?: QueryContext): Promise<{ sql: string; confidence: number }> {
    // For now, this will use the LLM directly via Settings.llm
    // In a real implementation, this would use the vector store to find similar queries
    const llm = Settings.llm;
    if (!llm) {
      throw new Error('LLM not configured');
    }

    const prompt = `Generate a ClickHouse SQL query for the following question about healthcare data:
    
Question: ${query}

The database contains FHIR resources in a table called 'fhir_current' with columns:
- resource_id: unique identifier for the resource (NOT id)
- resource_type: FHIR resource type (Patient, Observation, etc.)
- resource: full FHIR resource as JSON
- version: version number
- version_time: timestamp
- tenant_id, domain, sign, event_type, etc.

IMPORTANT: Use resource_id for counting or identifying resources, NOT id.
Use JSONExtract functions to query nested JSON fields.
Example: SELECT COUNT(DISTINCT resource_id) FROM fhir_current WHERE resource_type = 'Observation'`;

    const response = await llm.complete({ prompt });
    
    // Extract SQL from response
    const responseText = response.text;
    const sqlMatch = responseText.match(/```sql\n([\s\S]*?)\n```/);
    const sql = sqlMatch ? sqlMatch[1] : responseText;
    
    return {
      sql: sql.trim(),
      confidence: 0.85 // Default confidence for now
    };
  }
}