import { BaseEmbedding } from 'llamaindex';
import fetch from 'node-fetch';

import { logger } from '../../../utils/logger';

interface EmbeddingServiceResponse {
  embeddings: number[] | number[][];
  model: string;
  dimensions: number;
  duration_ms: number;
}

export class RemoteEmbeddings extends BaseEmbedding {
  private serviceUrl: string;
  private model: string;
  private timeout: number;

  constructor(config: {
    serviceUrl?: string;
    model?: string;
    timeout?: number;
  } = {}) {
    super();
    this.serviceUrl = config.serviceUrl || 'http://embedding-service.nexuscare.svc.cluster.local:8090';
    this.model = config.model || 'all-MiniLM-L6-v2';
    this.timeout = config.timeout || 30000;
  }

  // Required: class name for serialization
  static className(): string {
    return 'RemoteEmbeddings';
  }

  // Public method expected by LlamaIndex
  async getTextEmbedding(text: string): Promise<number[]> {
    return this._getTextEmbedding(text);
  }

  // Implement all required abstract methods with underscores
  async _getQueryEmbedding(query: string): Promise<number[]> {
    return this._getTextEmbedding(query);
  }

  async _getTextEmbedding(text: string): Promise<number[]> {
    try {
      const response = await fetch(`${this.serviceUrl}/api/v1/embed`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text,
          model: this.model,
        }),
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) {
        throw new Error(`Embedding service error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json() as EmbeddingServiceResponse;
      
      // Handle both single and batch responses
      if (Array.isArray(data.embeddings) && data.embeddings.length > 0) {
        if (Array.isArray(data.embeddings[0])) {
          // Batch response, return first embedding
          return data.embeddings[0] as number[];
        } else {
          // Single embedding response
          return data.embeddings as number[];
        }
      }

      throw new Error('Invalid embedding response format');
    } catch (error) {
      logger.error('Failed to get embedding from service:', error);
      throw error;
    }
  }

  async getTextEmbeddings(texts: string[]): Promise<number[][]> {
    try {
      const response = await fetch(`${this.serviceUrl}/api/v1/embed`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          texts,
          model: this.model,
        }),
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) {
        throw new Error(`Embedding service error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json() as EmbeddingServiceResponse;
      
      // Ensure we have a 2D array
      if (Array.isArray(data.embeddings)) {
        if (texts.length === 1 && !Array.isArray(data.embeddings[0])) {
          // Single text was sent but response is 1D array
          return [data.embeddings as number[]];
        }
        return data.embeddings as number[][];
      }

      throw new Error('Invalid batch embedding response format');
    } catch (error) {
      logger.error('Failed to get batch embeddings from service:', error);
      throw error;
    }
  }

  // Additional methods for model management
  async switchModel(modelName: string): Promise<void> {
    try {
      const response = await fetch(`${this.serviceUrl}/api/v1/models/${modelName}/activate`, {
        method: 'POST',
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) {
        throw new Error(`Failed to switch model: ${response.status} ${response.statusText}`);
      }

      this.model = modelName;
      logger.info(`Switched to embedding model: ${modelName}`);
    } catch (error) {
      logger.error('Failed to switch embedding model:', error);
      throw error;
    }
  }

  async getAvailableModels(): Promise<{ models: string[]; active: string }> {
    try {
      const response = await fetch(`${this.serviceUrl}/api/v1/models`, {
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) {
        throw new Error(`Failed to get models: ${response.status} ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      logger.error('Failed to get available models:', error);
      throw error;
    }
  }
}

// Factory function for different embedding models
export function createEmbedding(modelType: 'general' | 'medical' | 'multilingual' = 'general'): RemoteEmbeddings {
  const modelMap = {
    general: 'all-MiniLM-L6-v2',
    medical: 'biobert-base',
    multilingual: 'multilingual-e5-base',
  };

  // Use localhost when running locally
  const isLocal = process.env.NODE_ENV !== 'production' && !process.env.KUBERNETES_SERVICE_HOST;
  const serviceUrl = isLocal ? 'http://localhost:8090' : 'http://embedding-service.nexuscare.svc.cluster.local:8090';

  return new RemoteEmbeddings({
    model: modelMap[modelType],
    serviceUrl,
  });
}