import { Tool } from 'llamaindex';

import { ClickHouseService } from '../../../analytics/ClickHouseService';
import { healthcareLogger } from '../../../monitoring/StructuredLogger';

const logger = healthcareLogger;

export class ClickHouseTool extends Tool {
  private clickhouse: ClickHouseService;

  constructor() {
    super();
    this.clickhouse = new ClickHouseService();
  }

  get name(): string {
    return 'clickhouse_executor';
  }

  get description(): string {
    return 'Execute SQL queries against ClickHouse database and return results';
  }

  async call(input: any): Promise<any> {
    const { sql, tenantId } = input;
    return this.executeQuery(sql, tenantId);
  }

  async executeQuery(
    sql: string,
    tenantId: string = 'default'
  ): Promise<{
    data: any[];
    rowCount: number;
    executionTime: number;
    error?: string;
  }> {
    const startTime = Date.now();

    try {
      // Validate and sanitize SQL
      const safeSql = this.validateAndSanitizeSQL(sql, tenantId);

      logger.info('Executing ClickHouse query', {
        sql: safeSql.substring(0, 200), // Log first 200 chars
        tenantId,
      });

      const results = await this.clickhouse.query(safeSql);
      const executionTime = Date.now() - startTime;

      logger.info('ClickHouse query executed successfully', {
        rowCount: results.length,
        executionTime,
      });

      return {
        data: results,
        rowCount: results.length,
        executionTime,
      };
    } catch (error) {
      logger.error('ClickHouse query execution failed', {
        error: error.message,
        sql: sql.substring(0, 200),
        tenantId,
      });

      return {
        data: [],
        rowCount: 0,
        executionTime: Date.now() - startTime,
        error: error.message,
      };
    }
  }

  async getTableInfo(tableName: string): Promise<any> {
    try {
      const query = `
        SELECT 
          name,
          type,
          default_expression,
          comment
        FROM system.columns
        WHERE database = 'nexuscare_analytics'
          AND table = '${tableName}'
        ORDER BY position
      `;

      const columns = await this.clickhouse.query(query);
      
      return {
        tableName,
        database: 'nexuscare_analytics',
        columns,
      };
    } catch (error) {
      logger.error('Failed to get table info', {
        error: error.message,
        tableName,
      });
      throw error;
    }
  }

  async explainQuery(sql: string): Promise<string> {
    try {
      const explainQuery = `EXPLAIN SYNTAX ${sql}`;
      const result = await this.clickhouse.query(explainQuery);
      
      return result.map(row => row.explain).join('\n');
    } catch (error) {
      logger.error('Failed to explain query', {
        error: error.message,
      });
      return 'Unable to explain query';
    }
  }

  private validateAndSanitizeSQL(sql: string, tenantId: string): string {
    let safeSql = sql.trim();

    // Remove any potential harmful statements
    const dangerousPatterns = [
      /DROP\s+/i,
      /DELETE\s+/i,
      /TRUNCATE\s+/i,
      /INSERT\s+/i,
      /UPDATE\s+/i,
      /CREATE\s+/i,
      /ALTER\s+/i,
      /GRANT\s+/i,
      /REVOKE\s+/i,
    ];

    for (const pattern of dangerousPatterns) {
      if (pattern.test(safeSql)) {
        throw new Error('Potentially harmful SQL statement detected');
      }
    }

    // Ensure tenant_id filter if not present
    if (!safeSql.includes('tenant_id')) {
      if (safeSql.toUpperCase().includes('WHERE')) {
        safeSql = safeSql.replace(
          /WHERE/i,
          `WHERE tenant_id = '${tenantId}' AND`
        );
      } else {
        // Add WHERE clause if it doesn't exist
        const fromMatch = safeSql.match(/FROM\s+[\w.]+/i);
        if (fromMatch) {
          const fromClause = fromMatch[0];
          safeSql = safeSql.replace(
            fromClause,
            `${fromClause} WHERE tenant_id = '${tenantId}'`
          );
        }
      }
    }

    // Add query timeout
    if (!safeSql.includes('SETTINGS')) {
      safeSql += ' SETTINGS max_execution_time = 30';
    }

    return safeSql;
  }
}