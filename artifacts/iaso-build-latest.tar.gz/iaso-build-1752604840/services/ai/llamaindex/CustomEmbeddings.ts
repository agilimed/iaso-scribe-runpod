/**
 * Custom Embeddings Implementation for LlamaIndex
 * Provides alternatives to OpenAI embeddings for healthcare data
 */

import { BaseEmbedding } from 'llamaindex';

import { healthcareLogger as logger } from '../../monitoring/StructuredLogger';

/**
 * Simple implementation using fetch API for HuggingFace Inference API
 * This is a lightweight alternative when you don't want to load models locally
 */
export class HuggingFaceAPIEmbedding extends BaseEmbedding {
  private apiKey: string;
  private modelId: string;
  private apiUrl: string;

  constructor(
    modelId: string = 'sentence-transformers/all-MiniLM-L6-v2',
    apiKey?: string
  ) {
    super();
    this.modelId = modelId;
    this.apiKey = apiKey || process.env.HUGGINGFACE_API_KEY || '';
    this.apiUrl = `https://api-inference.huggingface.co/pipeline/feature-extraction/${modelId}`;
  }

  get className(): string {
    return 'HuggingFaceAPIEmbedding';
  }

  async getQueryEmbedding(query: string): Promise<number[]> {
    return this._getEmbedding(query);
  }

  async getTextEmbedding(text: string): Promise<number[]> {
    return this._getEmbedding(text);
  }
  
  async getTextEmbeddings(texts: string[]): Promise<number[][]> {
    return Promise.all(texts.map(text => this._getEmbedding(text)));
  }

  private async _getEmbedding(text: string): Promise<number[]> {
    try {
      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          inputs: text,
          options: { wait_for_model: true }
        }),
      });

      if (!response.ok) {
        throw new Error(`HuggingFace API error: ${response.statusText}`);
      }

      const embeddings = await response.json();
      return embeddings[0] || embeddings;
    } catch (error) {
      logger.error('HuggingFace embedding failed', { error });
      throw error;
    }
  }
}

/**
 * Healthcare-specific embedding using sentence transformers locally
 * Requires: npm install @xenova/transformers
 */
export class HealthcareLocalEmbedding extends BaseEmbedding {
  private pipeline: any;
  private modelName: string;
  private initialized: boolean = false;

  constructor(modelName: string = 'Xenova/all-MiniLM-L6-v2') {
    super();
    this.modelName = modelName;
  }

  get className(): string {
    return 'HealthcareLocalEmbedding';
  }

  private async initialize() {
    if (this.initialized) return;
    
    try {
      // Dynamic import to avoid loading if not used
      const { pipeline } = await import('@xenova/transformers');
      this.pipeline = await pipeline('feature-extraction', this.modelName);
      this.initialized = true;
      logger.info('Local embedding model initialized', { modelName: this.modelName });
    } catch (error) {
      logger.error('Failed to initialize local embedding model', { error });
      throw error;
    }
  }

  async getQueryEmbedding(query: string): Promise<number[]> {
    await this.initialize();
    return this._getEmbedding(query);
  }

  async getTextEmbedding(text: string): Promise<number[]> {
    await this.initialize();
    return this._getEmbedding(text);
  }
  
  async getTextEmbeddings(texts: string[]): Promise<number[][]> {
    await this.initialize();
    return Promise.all(texts.map(text => this._getEmbedding(text)));
  }

  private async _getEmbedding(text: string): Promise<number[]> {
    try {
      const output = await this.pipeline(text, {
        pooling: 'mean',
        normalize: true,
      });
      return Array.from(output.data);
    } catch (error) {
      logger.error('Local embedding generation failed', { error });
      throw error;
    }
  }
}

/**
 * Mock embedding for testing without any external dependencies
 * Generates deterministic embeddings based on text content
 */
export class MockEmbedding extends BaseEmbedding {
  private dimension: number;

  constructor(dimension: number = 384) {
    super();
    this.dimension = dimension;
  }

  get className(): string {
    return 'MockEmbedding';
  }

  async getQueryEmbedding(query: string): Promise<number[]> {
    return this._generateMockEmbedding(query);
  }

  async getTextEmbedding(text: string): Promise<number[]> {
    return this._generateMockEmbedding(text);
  }
  
  async getTextEmbeddings(texts: string[]): Promise<number[][]> {
    return Promise.all(texts.map(text => this._generateMockEmbedding(text)));
  }

  private _generateMockEmbedding(text: string): number[] {
    // Simple deterministic embedding based on text
    const embedding = new Array(this.dimension).fill(0);
    
    // Use character codes to generate values
    for (let i = 0; i < text.length; i++) {
      const charCode = text.charCodeAt(i);
      const index = (charCode * (i + 1)) % this.dimension;
      embedding[index] = Math.sin(charCode / 100) * 0.5 + 0.5;
    }
    
    // Normalize
    const magnitude = Math.sqrt(embedding.reduce((sum, val) => sum + val * val, 0));
    return embedding.map(val => val / magnitude);
  }
}

/**
 * Factory function to create appropriate embedding based on configuration
 */
export function createEmbedding(config?: {
  provider?: 'huggingface-api' | 'local' | 'mock' | 'openai';
  modelName?: string;
  apiKey?: string;
}): BaseEmbedding | undefined {
  const provider = config?.provider || process.env.EMBEDDING_PROVIDER || 'huggingface-api';
  
  switch (provider) {
    case 'huggingface-api':
      return new HuggingFaceAPIEmbedding(
        config?.modelName || process.env.HF_MODEL_NAME,
        config?.apiKey
      );
    
    case 'local':
      return new HealthcareLocalEmbedding(
        config?.modelName || process.env.LOCAL_MODEL_NAME
      );
    
    case 'mock':
      return new MockEmbedding();
    
    case 'openai':
      // Return undefined to use LlamaIndex default (OpenAI)
      return undefined;
    
    default:
      logger.warn(`Unknown embedding provider: ${provider}, using HuggingFace API`);
      return new HuggingFaceAPIEmbedding();
  }
}

/**
 * Factory class for creating embeddings
 */
export class CustomEmbeddingFactory {
  static create(provider: string): BaseEmbedding {
    switch (provider) {
      case 'mock':
        return new MockEmbedding();
      
      case 'huggingface-api':
      case 'huggingface':
        return new HuggingFaceAPIEmbedding(
          process.env.HF_MODEL_NAME || 'BAAI/bge-base-en-v1.5'
        );
      
      case 'local':
      case 'transformers':
        return new HealthcareLocalEmbedding();
      
      default:
        logger.warn(`Unknown embedding provider: ${provider}, using mock`);
        return new MockEmbedding();
    }
  }
}

/**
 * Get embedding dimensions for different models
 */
export function getEmbeddingDimension(modelName?: string): number {
  const model = modelName || process.env.HF_MODEL_NAME || 'sentence-transformers/all-MiniLM-L6-v2';
  
  const dimensions: Record<string, number> = {
    // Sentence Transformers
    'sentence-transformers/all-MiniLM-L6-v2': 384,
    'sentence-transformers/all-MiniLM-L12-v2': 384,
    'sentence-transformers/all-mpnet-base-v2': 768,
    'sentence-transformers/all-distilroberta-v1': 768,
    
    // BGE Models
    'BAAI/bge-small-en': 384,
    'BAAI/bge-small-en-v1.5': 384,
    'BAAI/bge-base-en': 768,
    'BAAI/bge-base-en-v1.5': 768,
    'BAAI/bge-large-en': 1024,
    'BAAI/bge-large-en-v1.5': 1024,
    
    // Healthcare/Biomedical Models
    'dmis-lab/biobert-base-cased-v1.1': 768,
    'emilyalsentzer/Bio_ClinicalBERT': 768,
    'microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract': 768,
    
    // OpenAI
    'text-embedding-ada-002': 1536,
    'text-embedding-3-small': 1536,
    'text-embedding-3-large': 3072,
    
    // Xenova models (for local transformers.js)
    'Xenova/all-MiniLM-L6-v2': 384,
    'Xenova/all-MiniLM-L12-v2': 384,
    'Xenova/bge-small-en-v1.5': 384,
  };
  
  return dimensions[model] || 768; // Default to 768
}