import { QdrantClient } from '@qdrant/js-client-rest';
import { 
  VectorStoreIndex,
  QdrantVectorStore,
  Document,
  VectorStoreQueryMode,
  Settings,
  BaseEmbedding
} from 'llamaindex';

import { healthcareLogger } from '../../monitoring/StructuredLogger';

import { RemoteEmbeddings, createEmbedding } from './RemoteEmbeddings';

const logger = healthcareLogger;

export interface VectorStoreConfig {
  url: string;
  apiKey?: string;
  collectionName: string;
  embeddingDimension: number;
  embeddingModel?: 'general' | 'medical' | 'multilingual';
}

export class VectorStoreManager {
  private qdrantClient: QdrantClient;
  private vectorStore: QdrantVectorStore;
  private index: VectorStoreIndex | null = null;
  private config: VectorStoreConfig;
  private embeddings: BaseEmbedding;

  constructor(config: VectorStoreConfig) {
    this.config = config;
    
    // Initialize Qdrant client
    this.qdrantClient = new QdrantClient({
      url: config.url,
      apiKey: config.apiKey,
    });

    // Initialize embeddings
    this.embeddings = createEmbedding(config.embeddingModel || 'general');

    // Initialize vector store
    this.vectorStore = new QdrantVectorStore({
      client: this.qdrantClient,
      collectionName: config.collectionName,
    });
  }

  async initialize(): Promise<void> {
    try {
      // Check if collection exists
      const collections = await this.qdrantClient.getCollections();
      const collectionExists = collections.collections.some(
        c => c.name === this.config.collectionName
      );

      if (!collectionExists) {
        // Create collection with proper configuration
        await this.qdrantClient.createCollection(this.config.collectionName, {
          vectors: {
            size: this.config.embeddingDimension,
            distance: 'Cosine',
          },
          optimizers_config: {
            default_segment_number: 2,
          },
          replication_factor: 2,
        });
        
        logger.info('Created Qdrant collection', {
          collectionName: this.config.collectionName,
          dimension: this.config.embeddingDimension
        });
      }

      // Set the embeddings in Settings
      Settings.embedModel = this.embeddings;

      // Create or load index with embeddings
      this.index = await VectorStoreIndex.fromVectorStore(this.vectorStore, {
        serviceContext: {
          embedModel: this.embeddings,
        },
      });
      
      logger.info('Vector store initialized successfully', {
        collectionName: this.config.collectionName,
        embeddingModel: this.config.embeddingModel || 'general'
      });
    } catch (error) {
      logger.error('Failed to initialize vector store', {
        error: error.message,
        collectionName: this.config.collectionName
      });
      throw error;
    }
  }

  async addDocuments(documents: Document[]): Promise<void> {
    if (!this.index) {
      throw new Error('Vector store not initialized');
    }

    try {
      // Insert documents into the index
      for (const doc of documents) {
        await this.index.insert(doc);
      }
      
      logger.info('Documents added to vector store', {
        count: documents.length,
        collectionName: this.config.collectionName
      });
    } catch (error) {
      logger.error('Failed to add documents to vector store', {
        error: error.message,
        documentCount: documents.length
      });
      throw error;
    }
  }

  async search(
    query: string,
    topK: number = 5,
    filters?: Record<string, any>
  ): Promise<any> {
    if (!this.index) {
      throw new Error('Vector store not initialized');
    }

    try {
      const queryEngine = this.index.asQueryEngine({
        similarityTopK: topK,
        mode: VectorStoreQueryMode.DEFAULT,
      });

      const response = await queryEngine.query({
        query,
      });

      return {
        response: response.toString(),
        sourceNodes: response.sourceNodes?.map(node => ({
          text: node.node.text,
          score: node.score,
          metadata: node.node.metadata,
        })),
      };
    } catch (error) {
      logger.error('Vector search failed', {
        error: error.message,
        query,
      });
      throw error;
    }
  }

  async upsertDocument(
    id: string,
    content: string,
    metadata: Record<string, any>
  ): Promise<void> {
    if (!this.index) {
      throw new Error('Vector store not initialized');
    }

    const doc = new Document({
      text: content,
      id_: id,
      metadata: {
        ...metadata,
        timestamp: new Date().toISOString(),
      },
    });

    await this.addDocuments([doc]);
  }

  async deleteDocument(id: string): Promise<void> {
    try {
      await this.qdrantClient.delete(this.config.collectionName, {
        filter: {
          must: [
            {
              key: 'doc_id',
              match: { value: id },
            },
          ],
        },
      });
      
      logger.info('Document deleted from vector store', {
        documentId: id,
        collectionName: this.config.collectionName
      });
    } catch (error) {
      logger.error('Failed to delete document', {
        error: error.message,
        documentId: id
      });
      throw error;
    }
  }

  async createSnapshot(): Promise<string> {
    try {
      const result = await this.qdrantClient.createSnapshot(this.config.collectionName);
      logger.info('Snapshot created', {
        collectionName: this.config.collectionName,
        snapshotName: result.name
      });
      return result.name;
    } catch (error) {
      logger.error('Failed to create snapshot', {
        error: error.message,
        collectionName: this.config.collectionName
      });
      throw error;
    }
  }

  getIndex(): VectorStoreIndex | null {
    return this.index;
  }

  async getCollectionInfo(): Promise<any> {
    try {
      return await this.qdrantClient.getCollection(this.config.collectionName);
    } catch (error) {
      logger.error('Failed to get collection info', {
        error: error.message,
        collectionName: this.config.collectionName
      });
      throw error;
    }
  }
}

// Factory function for different vector store collections
export class VectorStoreFactory {
  private static instances: Map<string, VectorStoreManager> = new Map();

  static async getOrCreate(
    collectionName: string,
    config?: Partial<VectorStoreConfig>
  ): Promise<VectorStoreManager> {
    if (!this.instances.has(collectionName)) {
      const fullConfig: VectorStoreConfig = {
        url: process.env.QDRANT_URL || 'http://localhost:6333',
        apiKey: process.env.QDRANT_API_KEY,
        collectionName,
        embeddingDimension: 384, // Default to all-MiniLM-L6-v2 dimensions
        embeddingModel: 'general',
        ...config,
      };

      const manager = new VectorStoreManager(fullConfig);
      await manager.initialize();
      this.instances.set(collectionName, manager);
    }

    return this.instances.get(collectionName)!;
  }

  static async createCollections(): Promise<void> {
    // Create all necessary collections with appropriate embedding models
    const collections = [
      { name: 'fhir_resources', dimension: 384, model: 'general' as const },
      { name: 'medical_knowledge', dimension: 768, model: 'medical' as const },
      { name: 'clickhouse_schema', dimension: 384, model: 'general' as const },
      { name: 'conversation_memory', dimension: 384, model: 'general' as const },
      { name: 'query_patterns', dimension: 384, model: 'general' as const },
    ];

    for (const collection of collections) {
      await this.getOrCreate(collection.name, {
        embeddingDimension: collection.dimension,
        embeddingModel: collection.model,
      });
    }

    logger.info('All vector store collections created');
  }
}