import { healthcareLogger as logger } from '../../monitoring/StructuredLogger';

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  metadata: {
    hasProperJoins: boolean;
    usesValidTables: boolean;
    hasReferenceResolution: boolean;
    hasFHIRStructure: boolean;
    detectedTables: string[];
    detectedResources: string[];
  };
}

export class SQLValidator {
  // Valid tables in our ClickHouse schema
  private readonly validTables = [
    'nexuscare_analytics.fhir_current',
    'nexuscare_analytics.fhir_events',
    'fhir_current',
    'fhir_events'
  ];

  // Known hallucinated tables to reject
  private readonly hallucinatedTables = [
    'glucose_readings',
    'diabetic_patients',
    'patient_conditions',
    'medication_history',
    'vital_signs',
    'lab_results',
    'appointments',
    'providers',
    'facilities'
  ];

  // Valid FHIR resource types
  private readonly validResourceTypes = [
    'Patient', 'Condition', 'Observation', 'MedicationRequest', 'MedicationAdministration',
    'Encounter', 'Procedure', 'DiagnosticReport', 'Immunization', 'AllergyIntolerance',
    'CarePlan', 'CareTeam', 'Practitioner', 'PractitionerRole', 'Organization',
    'Location', 'Device', 'DeviceRequest', 'DeviceUseStatement', 'Appointment',
    'Schedule', 'Slot', 'ServiceRequest', 'Task', 'Claim', 'ClaimResponse',
    'ChargeItem', 'Invoice', 'Coverage', 'CoverageEligibilityRequest'
  ];

  // FHIR reference patterns
  private readonly referencePatterns = [
    /arrayElement\s*\(\s*splitByChar\s*\(\s*'\/'\s*,\s*JSONExtractString\s*\(\s*resource\s*,\s*'[^']+\.reference'\s*\)\s*\)\s*,\s*2\s*\)/gi,
    /JSONExtractString\s*\(\s*resource\s*,\s*'[^']+\.reference'\s*\)/gi
  ];

  // JSON extraction patterns
  private readonly jsonExtractPatterns = [
    /JSONExtractString\s*\(\s*resource\s*,/gi,
    /JSONExtractFloat\s*\(\s*resource\s*,/gi,
    /JSONExtractInt\s*\(\s*resource\s*,/gi,
    /JSONExtractBool\s*\(\s*resource\s*,/gi,
    /JSONExtractArrayRaw\s*\(\s*resource\s*,/gi
  ];

  validate(sql: string, originalQuery?: string): ValidationResult {
    const result: ValidationResult = {
      isValid: true,
      errors: [],
      warnings: [],
      metadata: {
        hasProperJoins: false,
        usesValidTables: false,
        hasReferenceResolution: false,
        hasFHIRStructure: false,
        detectedTables: [],
        detectedResources: []
      }
    };

    // Normalize SQL for analysis
    const normalizedSQL = sql.toLowerCase();

    // 1. Check for hallucinated tables
    const hallucinatedFound = this.checkHallucinatedTables(normalizedSQL);
    if (hallucinatedFound.length > 0) {
      result.isValid = false;
      result.errors.push(`Found hallucinated tables: ${hallucinatedFound.join(', ')}`);
    }

    // 2. Check for valid tables
    const tablesUsed = this.extractTables(sql);
    result.metadata.detectedTables = tablesUsed;
    
    const validTablesUsed = tablesUsed.filter(table => 
      this.validTables.some(valid => 
        table.toLowerCase().includes(valid.toLowerCase().replace('nexuscare_analytics.', ''))
      )
    );
    
    if (validTablesUsed.length === 0 && tablesUsed.length > 0) {
      result.isValid = false;
      result.errors.push('No valid FHIR tables found. Must use fhir_current or fhir_events');
    } else if (validTablesUsed.length > 0) {
      result.metadata.usesValidTables = true;
    }

    // 3. Check for FHIR structure (JSONExtract usage)
    const hasFHIRExtraction = this.jsonExtractPatterns.some(pattern => pattern.test(sql));
    if (!hasFHIRExtraction && normalizedSQL.includes('select')) {
      result.warnings.push('No JSONExtract functions found. FHIR data requires JSON extraction');
    } else {
      result.metadata.hasFHIRStructure = true;
    }

    // 4. Check for reference resolution patterns
    const hasReferencePattern = this.referencePatterns.some(pattern => pattern.test(sql));
    result.metadata.hasReferenceResolution = hasReferencePattern;

    // 5. Check for proper joins when multiple resources involved
    const resourceTypes = this.extractResourceTypes(sql);
    result.metadata.detectedResources = resourceTypes;
    
    if (resourceTypes.length > 1) {
      // Multiple resources detected, should have JOIN
      if (!normalizedSQL.includes('join')) {
        result.warnings.push('Multiple resource types detected but no JOIN found');
      } else {
        result.metadata.hasProperJoins = true;
      }

      // Should have reference resolution for joins
      if (!hasReferencePattern) {
        result.isValid = false;
        result.errors.push('Multi-resource query must use arrayElement(splitByChar(...)) for reference resolution');
      }
    }

    // 6. Check for sign = 1 filter (required for active records)
    if (!normalizedSQL.includes('sign = 1') && 
        !normalizedSQL.includes('sign=1') && 
        validTablesUsed.length > 0) {
      result.warnings.push('Missing sign = 1 filter. This may include deleted records');
    }

    // 7. Specific validation for patient condition queries
    if (this.isPatientConditionQuery(sql)) {
      const validationErrors = this.validatePatientConditionQuery(sql);
      if (validationErrors.length > 0) {
        result.isValid = false;
        result.errors.push(...validationErrors);
      }
    }

    // Log validation results
    logger.info('[SQLValidator] Validation complete', {
      metadata: {
        isValid: result.isValid,
        errorCount: result.errors.length,
        warningCount: result.warnings.length,
        ...result.metadata
      }
    });

    return result;
  }

  private checkHallucinatedTables(sql: string): string[] {
    const found: string[] = [];
    
    for (const table of this.hallucinatedTables) {
      // Check for table references (word boundaries to avoid false positives)
      const tableRegex = new RegExp(`\\b${table}\\b`, 'gi');
      if (tableRegex.test(sql)) {
        found.push(table);
      }
    }
    
    return found;
  }

  private extractTables(sql: string): string[] {
    const tables: string[] = [];
    
    // Pattern for FROM clause
    const fromPattern = /FROM\s+([a-zA-Z0-9_\.]+)/gi;
    let match;
    while ((match = fromPattern.exec(sql)) !== null) {
      tables.push(match[1]);
    }
    
    // Pattern for JOIN clause
    const joinPattern = /JOIN\s+([a-zA-Z0-9_\.]+)/gi;
    while ((match = joinPattern.exec(sql)) !== null) {
      tables.push(match[1]);
    }
    
    return [...new Set(tables)]; // Remove duplicates
  }

  private extractResourceTypes(sql: string): string[] {
    const resources: string[] = [];
    
    // Pattern for resource_type = 'ResourceType'
    const resourcePattern = /resource_type\s*=\s*'([A-Za-z]+)'/gi;
    let match;
    while ((match = resourcePattern.exec(sql)) !== null) {
      if (this.validResourceTypes.includes(match[1])) {
        resources.push(match[1]);
      }
    }
    
    return [...new Set(resources)];
  }

  private isPatientConditionQuery(sql: string): boolean {
    const normalized = sql.toLowerCase();
    
    // Check if the query context indicates it's about patient conditions
    // This is called during validation, so we need to check the SQL structure
    const hasPatientReference = normalized.includes('patient');
    const hasConditionContext = 
      normalized.includes('condition') ||
      normalized.includes('diabetes') ||
      normalized.includes('diagnosis') ||
      normalized.includes('hypertension') ||
      normalized.includes('asthma') ||
      normalized.includes('disease') ||
      normalized.includes('illness') ||
      normalized.includes('disorder');
    
    // Also check if it's counting patients but doesn't have condition resource
    const isCountingPatients = normalized.includes('count') && hasPatientReference;
    const lacksConditionResource = !normalized.includes('resource_type = \'condition\'');
    
    // Special case: if query is ONLY about Patient resource but mentions conditions
    const queryingOnlyPatients = normalized.includes('resource_type = \'patient\'') && 
                                !normalized.includes('resource_type = \'condition\'');
    
    return (hasPatientReference && hasConditionContext && queryingOnlyPatients) || 
           (isCountingPatients && lacksConditionResource && hasConditionContext);
  }

  private validatePatientConditionQuery(sql: string): string[] {
    const errors: string[] = [];
    const normalized = sql.toLowerCase();
    
    // Check for incorrect pattern: looking for conditions inside Patient resource
    if (normalized.includes('jsonextractstring(f.resource, \'condition') ||
        normalized.includes('jsonextractstring(resource, \'condition') ||
        normalized.includes('jsonextractstring(p.resource, \'condition')) {
      errors.push('Invalid pattern: Conditions are NOT stored inside Patient resources. Must JOIN with Condition resource type');
    }
    
    // If querying for conditions, must have Condition resource type
    if ((normalized.includes('diabetes') || normalized.includes('hypertension') || 
         normalized.includes('condition')) && 
        !normalized.includes('resource_type = \'condition\'')) {
      errors.push('Condition queries must filter by resource_type = \'Condition\'');
    }
    
    return errors;
  }

  /**
   * Validate SQL before execution (lighter validation)
   */
  validateForExecution(sql: string): { safe: boolean; reason?: string } {
    const normalized = sql.toLowerCase();
    
    // Prevent destructive operations
    if (normalized.includes('drop') || normalized.includes('truncate') || 
        normalized.includes('delete') || normalized.includes('update')) {
      return { safe: false, reason: 'Destructive operations not allowed' };
    }
    
    // Ensure it's a SELECT query
    if (!normalized.trim().startsWith('select') && !normalized.trim().startsWith('with')) {
      return { safe: false, reason: 'Only SELECT queries allowed' };
    }
    
    // Check for system tables
    if (normalized.includes('system.') || normalized.includes('information_schema')) {
      return { safe: false, reason: 'System table access not allowed' };
    }
    
    return { safe: true };
  }
}