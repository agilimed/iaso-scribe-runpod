import {
  VectorStoreIndex,
  Document,
  Settings,
} from 'llamaindex';
import type { BaseQueryEngine } from '@llamaindex/core/query-engine';

import { healthcareLogger } from '../../monitoring/StructuredLogger';

import { QdrantVectorStore } from './QdrantVectorStore';
import { createEmbedding } from './RemoteEmbeddings';
import queryExamplesData from './data/healthcare-query-examples.json';
import { SQLValidator } from './SQLValidator';
import { ClickHouseValidator } from './ClickHouseValidator';

const logger = healthcareLogger;

export interface HealthcareQueryContext {
  sessionId: string;
  userId: string;
  tenantId: string;
  previousQueries?: Array<{
    query: string;
    sql: string;
    success: boolean;
  }>;
}

export class HealthcareRAGEngine {
  private vectorStore: QdrantVectorStore;
  private index: VectorStoreIndex | null = null;
  private queryEngine: BaseQueryEngine | null = null;
  private initialized = false;
  private sqlValidator: SQLValidator;
  private clickhouseValidator: ClickHouseValidator;

  constructor() {
    this.sqlValidator = new SQLValidator();
    this.clickhouseValidator = new ClickHouseValidator();
    // TODO: Configure your preferred LLM here
    // Settings.llm = new YourLLM({});
    Settings.embedModel = createEmbedding('general');

    // Initialize vector store
    this.vectorStore = new QdrantVectorStore({
      url: process.env.QDRANT_URL || 'http://localhost:6333',
      collectionName: 'nexuscare_healthcare_queries',
      vectorSize: 384, // for all-MiniLM-L6-v2
    });
  }

  async initialize(): Promise<void> {
    try {
      logger.info('[HealthcareRAG] Initializing RAG Engine...');

      // Initialize Qdrant
      await this.vectorStore.init();

      // Create index
      this.index = await VectorStoreIndex.fromVectorStore(this.vectorStore);

      // Load training data
      await this.loadTrainingData();

      // Create query engine using the simpler pattern
      this.queryEngine = this.index.asQueryEngine({
        similarityTopK: 10, // Retrieve more examples for better context
      });

      this.initialized = true;
      logger.info('[HealthcareRAG] RAG Engine initialized successfully');
    } catch (error) {
      logger.error('[HealthcareRAG] Failed to initialize', {
        metadata: { error: (error as Error).message }
      });
      throw error;
    }
  }

  private async loadTrainingData(): Promise<void> {
    logger.info('[HealthcareRAG] Loading training data...');

    const documents: Document[] = [];

    // Load schema documentation
    documents.push(new Document({
      text: `ClickHouse Schema for Healthcare Analytics:
      
      Table: fhir_current
      This is a view that shows the current state of all FHIR resources using the FINAL modifier.
      
      Key columns:
      - tenant_id (String): Multi-tenant identifier
      - domain (String): Resource domain (e.g., 'fhir', 'business')
      - resource_type (String): FHIR resource type (Patient, Observation, Encounter, etc.)
      - resource_id (String): Unique identifier for the resource
      - version (UInt64): Version number
      - version_time (DateTime): When this version was created
      - sign (Int8): 1 for active records, -1 for deleted
      - resource (String): Complete FHIR resource as JSON
      - event_type (String): create, update, or delete
      - source_system (String): System that created the record
      - correlation_id (String): For tracking related events
      - created_by (String): User or system that created the record
      - hot_fields (Map(String, String)): Optimized frequently accessed fields
      
      IMPORTANT: All FHIR data is stored as JSON in the 'resource' column. Use JSONExtract functions to access nested fields.`,
      metadata: {
        category: 'schema',
        type: 'documentation',
        source: 'clickhouse'
      }
    }));

    // Load FHIR resource examples
    documents.push(new Document({
      text: `Common FHIR Resource JSONExtract Patterns:
      
      Patient:
      - Name: JSONExtractString(resource, 'name[0].family'), JSONExtractString(resource, 'name[0].given[0]')
      - Gender: JSONExtractString(resource, 'gender')
      - Birth Date: JSONExtractString(resource, 'birthDate')
      - MRN: JSONExtractString(resource, 'identifier[0].value')
      - Phone: JSONExtractString(resource, 'telecom[0].value')
      
      Observation:
      - Code: JSONExtractString(resource, 'code.coding[0].code')
      - Value: JSONExtractFloat(resource, 'valueQuantity.value')
      - Unit: JSONExtractString(resource, 'valueQuantity.unit')
      - Date: JSONExtractString(resource, 'effectiveDateTime')
      - Status: JSONExtractString(resource, 'status')
      - Patient Reference: JSONExtractString(resource, 'subject.reference')
      
      Encounter:
      - Status: JSONExtractString(resource, 'status')
      - Class: JSONExtractString(resource, 'class.code')
      - Start: JSONExtractString(resource, 'period.start')
      - End: JSONExtractString(resource, 'period.end')
      - Department: JSONExtractString(resource, 'location[0].location.display')
      - Patient: JSONExtractString(resource, 'subject.reference')
      
      Condition:
      - Code: JSONExtractString(resource, 'code.coding[0].code')
      - Text: JSONExtractString(resource, 'code.text')
      - Clinical Status: JSONExtractString(resource, 'clinicalStatus.coding[0].code')
      - Onset: JSONExtractString(resource, 'onsetDateTime')
      - Patient: JSONExtractString(resource, 'subject.reference')`,
      metadata: {
        category: 'patterns',
        type: 'json_extraction',
        source: 'fhir'
      }
    }));

    // Load all query examples
    for (const category of queryExamplesData.queryExamples) {
      for (const example of category.examples) {
        documents.push(new Document({
          text: `Query: ${example.query}
          
SQL: ${example.sql}

Description: ${example.description}
Category: ${category.category}`,
          metadata: {
            category: category.category,
            query: example.query,
            sql: example.sql,
            description: example.description,
            query_type: this.classifyQueryType(example.query)
          }
        }));
      }
    }

    // Add documents to index
    if (this.index) {
      await this.index.insertNodes(documents);
      logger.info('[HealthcareRAG] Loaded training data', {
        metadata: { documentCount: documents.length }
      });
    }
  }

  private classifyQueryType(query: string): string {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('how many') || lowerQuery.includes('count')) return 'count';
    if (lowerQuery.includes('average') || lowerQuery.includes('avg')) return 'aggregate';
    if (lowerQuery.includes('trend') || lowerQuery.includes('over time')) return 'trend';
    if (lowerQuery.includes('compare') || lowerQuery.includes('versus')) return 'comparison';
    if (lowerQuery.includes('list') || lowerQuery.includes('show me all')) return 'list';
    if (lowerQuery.includes('rate') || lowerQuery.includes('percentage')) return 'metric';
    if (lowerQuery.includes('by') && (lowerQuery.includes('department') || lowerQuery.includes('group'))) return 'grouping';
    if (lowerQuery.includes('audit') || lowerQuery.includes('who') || lowerQuery.includes('changes')) return 'audit';
    if (lowerQuery.includes('movement') || lowerQuery.includes('transfer') || lowerQuery.includes('location')) return 'location';
    
    return 'general';
  }

  private analyzeQueryIntent(query: string): {
    queryType: string;
    suggestedTable: 'fhir_current' | 'fhir_events';
    temporalScope: string;
  } {
    const lowerQuery = query.toLowerCase();
    const queryType = this.classifyQueryType(query);
    
    // Determine if query needs historical data
    const needsHistory = 
      lowerQuery.includes('trend') ||
      lowerQuery.includes('over time') ||
      lowerQuery.includes('history') ||
      lowerQuery.includes('historical') ||
      lowerQuery.includes('audit') ||
      lowerQuery.includes('changes') ||
      lowerQuery.includes('movement') ||
      lowerQuery.includes('was') ||
      lowerQuery.includes('were') ||
      lowerQuery.includes('growth') ||
      lowerQuery.includes('by month') ||
      lowerQuery.includes('by week') ||
      lowerQuery.includes('by day') ||
      lowerQuery.includes('last month') ||
      lowerQuery.includes('last year') ||
      lowerQuery.includes('past');
    
    // Determine temporal scope
    let temporalScope = 'current';
    if (lowerQuery.includes('today')) temporalScope = 'today';
    else if (lowerQuery.includes('yesterday')) temporalScope = 'yesterday';
    else if (lowerQuery.includes('last') && lowerQuery.includes('hour')) temporalScope = 'recent';
    else if (lowerQuery.includes('last') && lowerQuery.includes('day')) temporalScope = 'recent';
    else if (lowerQuery.includes('last') && lowerQuery.includes('week')) temporalScope = 'weekly';
    else if (lowerQuery.includes('last') && lowerQuery.includes('month')) temporalScope = 'monthly';
    else if (lowerQuery.includes('last') && lowerQuery.includes('year')) temporalScope = 'yearly';
    else if (needsHistory) temporalScope = 'historical';
    
    return {
      queryType,
      suggestedTable: needsHistory ? 'fhir_events' : 'fhir_current',
      temporalScope
    };
  }

  async generateSQL(query: string, context?: HealthcareQueryContext): Promise<{
    sql: string;
    confidence: number;
    explanation: string;
    similarExamples: Array<{ query: string; sql: string; similarity: number }>;
    validation?: {
      isValid: boolean;
      errors: string[];
      warnings: string[];
    };
  }> {
    if (!this.initialized || !this.queryEngine) {
      throw new Error('RAG Engine not initialized');
    }

    try {
      logger.info('[HealthcareRAG] Generating SQL with RAG', {
        metadata: {
          query: query.substring(0, 100),
          hasContext: !!context
        }
      });

      // Analyze query to determine table usage
      const queryAnalysis = this.analyzeQueryIntent(query);
      
      // Build enhanced prompt with context
      let enhancedPrompt = `You are an expert at generating ClickHouse SQL queries for healthcare analytics.

CRITICAL RULES:
1. ALWAYS use 'resource_id' NOT 'id' for resource identifiers
2. ALL patient/clinical data is stored as JSON in the 'resource' column
3. ALWAYS use JSONExtract functions to access data inside the resource column
4. ALWAYS include 'sign = 1' when querying fhir_current (already filtered) or fhir_events
5. Choose the correct table based on the query:
   - Use 'fhir_current' for: current state, active records, point-in-time queries
   - Use 'fhir_events' for: historical analysis, trends, audit trails, version tracking
6. NEVER assume columns exist outside of the documented schema
7. CRITICAL: FHIR resources are SEPARATE entities. Patients DO NOT contain conditions, medications, or observations. You MUST JOIN the appropriate resource tables:
   - For patient conditions: JOIN with Condition resources via subject.reference
   - For patient medications: JOIN with MedicationRequest via subject.reference
   - For patient observations: JOIN with Observation via subject.reference
8. To extract patient_id from a reference: arrayElement(splitByChar('/', JSONExtractString(resource, 'subject.reference')), 2)

Query Analysis:
- Query Type: ${queryAnalysis.queryType}
- Suggested Table: ${queryAnalysis.suggestedTable}
- Temporal Scope: ${queryAnalysis.temporalScope}

User Query: ${query}`;

      // Add session context if available
      if (context?.previousQueries && context.previousQueries.length > 0) {
        enhancedPrompt += '\n\nPrevious queries in this session:\n';
        context.previousQueries.slice(-3).forEach(pq => {
          enhancedPrompt += `- Query: ${pq.query}\n  SQL: ${pq.sql}\n`;
        });
      }

      // Use RAG to find similar queries - search with just the user query, not the full prompt
      const ragResponse = await this.queryEngine.query({
        query: query, // Use original user query for better similarity matching
      });

      // Extract similar examples from the response
      const similarExamples: Array<{ query: string; sql: string; similarity: number }> = [];
      
      if (ragResponse.sourceNodes) {
        logger.info('[HealthcareRAG] Found source nodes', {
          metadata: { 
            count: ragResponse.sourceNodes.length,
            firstNode: ragResponse.sourceNodes[0]?.node.metadata
          }
        });
        
        for (const node of ragResponse.sourceNodes.slice(0, 5)) {
          const metadata = node.node.metadata;
          if (metadata?.query && metadata?.sql) {
            similarExamples.push({
              query: metadata.query as string,
              sql: metadata.sql as string,
              similarity: node.score || 0,
            });
          }
        }
      }

      // Build final prompt with examples
      let finalPrompt = enhancedPrompt;
      
      if (similarExamples.length > 0) {
        finalPrompt += '\n\nHere are similar queries and their SQL for reference:\n';
        similarExamples.forEach((ex, idx) => {
          finalPrompt += `\nExample ${idx + 1}:\nQuery: ${ex.query}\nSQL: ${ex.sql}\n`;
        });
      }

      // Add general pattern for FHIR resource relationships
      const queryLower = query.toLowerCase();
      const resourcePatterns = [
        { keywords: ['condition', 'diabetes', 'diagnosis', 'disease', 'disorder'], resource: 'Condition' },
        { keywords: ['allergy', 'allergies', 'allergic', 'intolerance'], resource: 'AllergyIntolerance' },
        { keywords: ['medication', 'drug', 'prescription', 'medicine'], resource: 'MedicationRequest' },
        { keywords: ['procedure', 'surgery', 'operation', 'treatment'], resource: 'Procedure' },
        { keywords: ['observation', 'vital', 'blood pressure', 'glucose', 'lab', 'result'], resource: 'Observation' },
        { keywords: ['immunization', 'vaccine', 'vaccination'], resource: 'Immunization' },
        { keywords: ['encounter', 'visit', 'admission', 'appointment'], resource: 'Encounter' }
      ];
      
      // Check if query is asking about patients with clinical data
      if (queryLower.includes('patient')) {
        for (const pattern of resourcePatterns) {
          if (pattern.keywords.some(keyword => queryLower.includes(keyword))) {
            finalPrompt += `\n\nCRITICAL PATTERN DETECTED: This query asks about patients with ${pattern.resource} data.

YOU MUST FOLLOW THIS EXACT PATTERN:
1. Query the ${pattern.resource} resource table: WHERE resource_type = '${pattern.resource}'
2. Extract patient IDs from subject.reference: arrayElement(splitByChar('/', JSONExtractString(resource, 'subject.reference')), 2)
3. NEVER query Patient resource for clinical data - ${pattern.resource} is a SEPARATE resource
4. Use the appropriate code/value fields for ${pattern.resource} resources
5. Always include sign = 1 for active records

Example pattern for ${pattern.resource}:
SELECT COUNT(DISTINCT arrayElement(splitByChar('/', JSONExtractString(resource, 'subject.reference')), 2)) as patient_count
FROM nexuscare_analytics.fhir_current
WHERE resource_type = '${pattern.resource}'
  AND sign = 1
  AND [appropriate conditions for ${pattern.resource}]`;
            break;
          }
        }
      }

      finalPrompt += `\n\nCRITICAL REQUIREMENTS:
- Use ONLY these tables: nexuscare_analytics.fhir_current or nexuscare_analytics.fhir_events
- NEVER create or reference tables like 'diabetic_patients', 'glucose_readings', etc.
- ALL data is in the 'resource' column as JSON - use JSONExtract functions
- For conditions, medications, observations - they are SEPARATE resources, not inside Patient
- You MUST follow the pattern from the examples above
- When counting patients with conditions, you MUST query Condition resources, NOT Patient resources

Generate the ClickHouse SQL query for the user query above. Return ONLY the SQL query without any explanation.`;

      // Generate SQL using the LLM
      const llmResponse = await Settings.llm!.complete({ prompt: finalPrompt });
      
      // Extract and clean SQL
      let sql = llmResponse.text;
      
      // Remove any markdown code blocks
      sql = sql.replace(/```sql\n?/g, '').replace(/```\n?/g, '').trim();
      
      // Ensure quotes are balanced
      const singleQuotes = (sql.match(/'/g) || []).length;
      if (singleQuotes % 2 === 1) {
        sql += '\'';
      }

      // Calculate confidence based on similarity scores
      const avgSimilarity = similarExamples.length > 0 
        ? similarExamples.reduce((sum, ex) => sum + ex.similarity, 0) / similarExamples.length
        : 0.5;
      
      const confidence = Math.min(0.95, Math.max(0.6, avgSimilarity + 0.2));

      // Validate SQL before storing
      const validation = this.sqlValidator.validate(sql, query);
      
      // If structural validation passes, validate against ClickHouse
      let clickhouseValid = false;
      if (validation.isValid) {
        try {
          const chValidation = await this.clickhouseValidator.validateQuery(
            sql, 
            queryAnalysis.queryType
          );
          clickhouseValid = chValidation.isValid;
          
          if (!clickhouseValid) {
            validation.isValid = false;
            validation.errors.push(`ClickHouse validation failed: ${chValidation.error}`);
          }
        } catch (error) {
          logger.error('[HealthcareRAG] ClickHouse validation error', {
            metadata: { error: (error as Error).message }
          });
        }
      }
      
      // Only store if both validations pass
      if (context?.sessionId && validation.isValid && clickhouseValid) {
        await this.addQueryExample(query, sql, context, true);
        logger.info('[HealthcareRAG] Storing validated query', {
          metadata: {
            query: query.substring(0, 50),
            validated: true
          }
        });
      } else if (context?.sessionId) {
        logger.warn('[HealthcareRAG] Not storing query due to validation errors', {
          metadata: {
            query: query.substring(0, 50),
            errors: validation.errors,
            clickhouseValid
          }
        });
      }

      return {
        sql,
        confidence: validation.isValid ? confidence : confidence * 0.7, // Lower confidence for invalid SQL
        explanation: `Generated using ${similarExamples.length} similar examples from the knowledge base`,
        similarExamples: similarExamples.slice(0, 3), // Return top 3 for transparency
        validation: {
          isValid: validation.isValid,
          errors: validation.errors,
          warnings: validation.warnings
        }
      };

    } catch (error) {
      logger.error('[HealthcareRAG] SQL generation failed', {
        metadata: { error: (error as Error).message }
      });
      throw error;
    }
  }

  async addQueryExample(
    query: string, 
    sql: string, 
    context: HealthcareQueryContext,
    success: boolean = true
  ): Promise<void> {
    if (!this.index) return;

    try {
      const document = new Document({
        text: `Query: ${query}
        
SQL: ${sql}

Context: User ${context.userId} in tenant ${context.tenantId}
Success: ${success}`,
        metadata: {
          category: 'user_generated',
          query,
          sql,
          query_type: this.classifyQueryType(query),
          userId: context.userId,
          tenantId: context.tenantId,
          success,
          timestamp: new Date().toISOString(),
        }
      });

      await this.index.insertNodes([document]);
      
      logger.info('[HealthcareRAG] Added query example', {
        metadata: {
          query: query.substring(0, 50),
          success
        }
      });
    } catch (error) {
      logger.error('[HealthcareRAG] Failed to add query example', {
        metadata: { error: (error as Error).message }
      });
    }
  }

  async getHealth(): Promise<any> {
    return {
      initialized: this.initialized,
      vectorStore: 'qdrant',
      documentsLoaded: true,
      ragEnabled: true,
      embeddingService: 'connected',
      llm: Settings.llm ? 'sqlcoder' : 'not_configured',
    };
  }
}