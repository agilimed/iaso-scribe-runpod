// Enhanced Query Analyzer using LlamaIndex + Qdrant for intelligent SQL generation
import { Document, VectorStoreIndex, QueryEngine, Settings, TextNode, BaseNode } from 'llamaindex';

import { logger } from '../../../utils/logger';

import { QdrantVectorStore } from './QdrantVectorStore';
import { HealthcareRAGEngine } from './HealthcareRAGEngine';

export interface QueryComplexityAnalysis {
  complexity: 'simple' | 'medium' | 'complex' | 'very_complex';
  confidence: number;
  suggestedApproach: 'direct' | 'single_cte' | 'multi_cte' | 'chunked' | 'use_existing_metric';
  estimatedTokens: number;
  semanticComponents: {
    entities: string[];
    operations: string[];
    timeWindows: string[];
    conditions: string[];
    aggregations: string[];
  };
  similarQueries: SimilarQuery[];
  existingMetrics: ExistingMetric[];
  technicalHints: string[];
}

interface SimilarQuery {
  query: string;
  sql: string;
  similarity: number;
  executionTime: number;
  resultCount: number;
}

interface ExistingMetric {
  id: string;
  name: string;
  description: string;
  sql: string;
  confidence: number;
  lastExecuted: Date;
  avgExecutionTime: number;
}

export class EnhancedQueryAnalyzer {
  private vectorStore: QdrantVectorStore;
  private ragEngine: HealthcareRAGEngine;
  private queryIndex?: VectorStoreIndex;
  private metricIndex?: VectorStoreIndex;
  
  constructor(
    private qdrantUrl: string = process.env.QDRANT_URL || 'http://localhost:6333'
  ) {
    // Initialize vector stores for queries and metrics
    this.vectorStore = new QdrantVectorStore({
      url: this.qdrantUrl,
      collectionName: 'healthcare_queries',
      vectorSize: 1536,
    });

    this.ragEngine = new HealthcareRAGEngine({
      qdrantUrl: this.qdrantUrl,
      collectionName: 'healthcare_knowledge',
    });
  }

  async initialize(): Promise<void> {
    try {
      // Initialize vector stores
      await this.vectorStore.init();
      await this.ragEngine.initialize();

      // Create separate collections for queries and metrics
      const metricVectorStore = new QdrantVectorStore({
        url: this.qdrantUrl,
        collectionName: 'metric_definitions',
        vectorSize: 1536,
      });
      await metricVectorStore.init();

      // Create indices
      this.queryIndex = await VectorStoreIndex.fromVectorStore(this.vectorStore);
      this.metricIndex = await VectorStoreIndex.fromVectorStore(metricVectorStore);

      logger.info('[EnhancedQueryAnalyzer] Initialized successfully', {
        metadata: { collections: ['healthcare_queries', 'metric_definitions'] }
      });
    } catch (error) {
      logger.error('[EnhancedQueryAnalyzer] Initialization failed', {
        metadata: { error: error.message }
      });
      throw error;
    }
  }

  /**
   * Analyzes query complexity using LlamaIndex semantic understanding
   */
  async analyzeQuery(query: string): Promise<QueryComplexityAnalysis> {
    const startTime = Date.now();

    try {
      // Step 1: Check for existing metrics first
      const existingMetrics = await this.findMatchingMetrics(query);
      if (existingMetrics.length > 0 && existingMetrics[0].confidence > 0.85) {
        return {
          complexity: 'simple',
          confidence: existingMetrics[0].confidence,
          suggestedApproach: 'use_existing_metric',
          estimatedTokens: 0,
          semanticComponents: this.extractSemanticComponents(query),
          similarQueries: [],
          existingMetrics,
          technicalHints: [`Use existing metric: ${existingMetrics[0].name}`]
        };
      }

      // Step 2: Find similar historical queries
      const similarQueries = await this.findSimilarQueries(query);

      // Step 3: Extract semantic components using RAG
      const semanticAnalysis = await this.performSemanticAnalysis(query);

      // Step 4: Calculate complexity based on semantic analysis
      const complexity = this.calculateComplexity(semanticAnalysis);

      // Step 5: Determine approach and generate hints
      const approach = this.determineApproach(complexity, similarQueries, existingMetrics);
      const technicalHints = this.generateTechnicalHints(semanticAnalysis, approach);

      const analysis: QueryComplexityAnalysis = {
        complexity: complexity.level,
        confidence: complexity.confidence,
        suggestedApproach: approach,
        estimatedTokens: this.estimateTokens(semanticAnalysis),
        semanticComponents: semanticAnalysis,
        similarQueries: similarQueries.slice(0, 3),
        existingMetrics: existingMetrics.slice(0, 3),
        technicalHints
      };

      const duration = Date.now() - startTime;
      logger.info('[EnhancedQueryAnalyzer] Query analyzed', {
        metadata: { 
          query: query.substring(0, 50),
          complexity: analysis.complexity,
          approach: analysis.suggestedApproach,
          duration
        }
      });

      return analysis;

    } catch (error) {
      logger.error('[EnhancedQueryAnalyzer] Analysis failed', {
        metadata: { error: error.message, query }
      });
      
      // Fallback to basic analysis
      return this.fallbackAnalysis(query);
    }
  }

  /**
   * Generates optimized prompt based on analysis
   */
  async generateOptimizedPrompt(
    query: string,
    analysis: QueryComplexityAnalysis,
    schemaContext: string
  ): Promise<string> {
    let prompt = schemaContext + '\n\n';

    // Add similar query examples if available
    if (analysis.similarQueries.length > 0) {
      prompt += 'Similar queries for reference:\n';
      analysis.similarQueries.forEach(sq => {
        prompt += `Query: ${sq.query}\nSQL: ${sq.sql}\n\n`;
      });
    }

    // Add the current query
    prompt += `Question: ${query}\n\n`;

    // Add technical hints
    if (analysis.technicalHints.length > 0) {
      prompt += 'Technical guidance:\n';
      analysis.technicalHints.forEach(hint => {
        prompt += `- ${hint}\n`;
      });
      prompt += '\n';
    }

    // Add approach-specific instructions
    switch (analysis.suggestedApproach) {
      case 'use_existing_metric':
        prompt += `Use the existing metric "${analysis.existingMetrics[0].name}" with ID: ${analysis.existingMetrics[0].id}\n`;
        break;
      case 'multi_cte':
        prompt += 'Generate multiple CTEs to break down this complex query step by step.\n';
        break;
      case 'chunked':
        prompt += 'This query is very complex. Generate the first part focusing on data extraction.\n';
        break;
    }

    prompt += '\nSQL:';
    return prompt;
  }

  /**
   * Handles token limits intelligently using historical data
   */
  async handleTokenLimits(
    query: string,
    analysis: QueryComplexityAnalysis,
    maxTokens: number = 1500
  ): Promise<{ prompts: string[]; combineStrategy: string }> {
    // If we can use an existing metric, no need for SQL generation
    if (analysis.suggestedApproach === 'use_existing_metric') {
      return {
        prompts: [`SELECT * FROM metric_values WHERE metric_id = '${analysis.existingMetrics[0].id}' ORDER BY computed_at DESC LIMIT 1`],
        combineStrategy: 'direct'
      };
    }

    // If we have a very similar query, adapt it
    if (analysis.similarQueries.length > 0 && analysis.similarQueries[0].similarity > 0.9) {
      const adaptedSQL = await this.adaptSimilarQuery(
        query,
        analysis.similarQueries[0],
        analysis.semanticComponents
      );
      return {
        prompts: [adaptedSQL],
        combineStrategy: 'direct'
      };
    }

    // For complex queries, use intelligent chunking
    if (analysis.suggestedApproach === 'chunked') {
      return this.createIntelligentChunks(query, analysis);
    }

    // Default: single prompt with increased token limit
    return {
      prompts: [await this.generateOptimizedPrompt(query, analysis, '')],
      combineStrategy: 'direct'
    };
  }

  /**
   * Stores successful queries for future reuse
   */
  async storeSuccessfulQuery(
    query: string,
    sql: string,
    executionTime: number,
    resultCount: number
  ): Promise<void> {
    try {
      const node = new TextNode({
        text: query,
        metadata: {
          sql,
          executionTime,
          resultCount,
          timestamp: new Date().toISOString(),
          category: 'healthcare_analytics',
          query_type: this.detectQueryType(query)
        }
      });

      await this.vectorStore.add([node]);

      logger.info('[EnhancedQueryAnalyzer] Stored successful query', {
        metadata: { query: query.substring(0, 50), executionTime }
      });
    } catch (error) {
      logger.error('[EnhancedQueryAnalyzer] Failed to store query', {
        metadata: { error: error.message }
      });
    }
  }

  // Private helper methods

  private async findMatchingMetrics(query: string): Promise<ExistingMetric[]> {
    if (!this.metricIndex) return [];

    try {
      const queryEngine = this.metricIndex.asQueryEngine();
      const response = await queryEngine.query({
        query: `Find metrics that answer: ${query}`
      });

      // Parse response to extract metric information
      const metrics: ExistingMetric[] = [];
      
      // This would parse the actual response from the vector store
      // For now, returning empty array as placeholder
      return metrics;
    } catch (error) {
      logger.error('[EnhancedQueryAnalyzer] Metric search failed', {
        metadata: { error: error.message }
      });
      return [];
    }
  }

  private async findSimilarQueries(query: string): Promise<SimilarQuery[]> {
    if (!this.queryIndex) return [];

    try {
      const results = await this.vectorStore.query({
        queryEmbedding: await this.getQueryEmbedding(query),
        limit: 5,
        similarityTopK: 5
      });

      return results.nodes.map((node, idx) => ({
        query: node.text,
        sql: node.metadata?.sql || '',
        similarity: results.similarities?.[idx] || 0,
        executionTime: node.metadata?.executionTime || 0,
        resultCount: node.metadata?.resultCount || 0
      }));
    } catch (error) {
      logger.error('[EnhancedQueryAnalyzer] Similar query search failed', {
        metadata: { error: error.message }
      });
      return [];
    }
  }

  private async performSemanticAnalysis(query: string): Promise<any> {
    // Use RAG engine to understand query components
    const context = await this.ragEngine.queryWithContext(
      `Analyze this healthcare query and identify: entities (patients, conditions, etc.), operations (count, average, etc.), time windows, conditions, and aggregations: ${query}`,
      'query_analysis'
    );

    // Parse the response to extract components
    return this.parseSemanticResponse(context.response);
  }

  private extractSemanticComponents(query: string): any {
    // Basic extraction as fallback
    const lower = query.toLowerCase();
    
    return {
      entities: this.extractEntities(lower),
      operations: this.extractOperations(lower),
      timeWindows: this.extractTimeWindows(lower),
      conditions: this.extractConditions(lower),
      aggregations: this.extractAggregations(lower)
    };
  }

  private extractEntities(query: string): string[] {
    const entities = [];
    const entityPatterns = [
      'patient', 'encounter', 'observation', 'condition', 'procedure',
      'medication', 'practitioner', 'organization', 'location'
    ];
    
    entityPatterns.forEach(pattern => {
      if (query.includes(pattern)) entities.push(pattern);
    });
    
    return entities;
  }

  private extractOperations(query: string): string[] {
    const operations = [];
    const operationPatterns = [
      'count', 'average', 'sum', 'max', 'min', 'total',
      'compare', 'trend', 'change', 'growth', 'decline'
    ];
    
    operationPatterns.forEach(pattern => {
      if (query.includes(pattern)) operations.push(pattern);
    });
    
    return operations;
  }

  private extractTimeWindows(query: string): string[] {
    const timeWindows = [];
    const timePatterns = [
      /last (\d+) (day|week|month|year)/,
      /past (\d+) (day|week|month|year)/,
      /since (.+)/,
      /between (.+) and (.+)/,
      /this (week|month|year)/,
      /today|yesterday|tomorrow/
    ];
    
    timePatterns.forEach(pattern => {
      const match = query.match(pattern);
      if (match) timeWindows.push(match[0]);
    });
    
    return timeWindows;
  }

  private extractConditions(query: string): string[] {
    const conditions = [];
    const conditionPatterns = [
      'diabetes', 'hypertension', 'covid', 'sepsis', 'heart disease',
      'chronic', 'acute', 'emergency', 'urgent'
    ];
    
    conditionPatterns.forEach(pattern => {
      if (query.includes(pattern)) conditions.push(pattern);
    });
    
    return conditions;
  }

  private extractAggregations(query: string): string[] {
    const aggregations = [];
    const aggregationPatterns = [
      'by gender', 'by age', 'by department', 'by location',
      'per patient', 'per day', 'per encounter', 'group by'
    ];
    
    aggregationPatterns.forEach(pattern => {
      if (query.includes(pattern)) aggregations.push(pattern);
    });
    
    return aggregations;
  }

  private calculateComplexity(analysis: any): { level: 'simple' | 'medium' | 'complex' | 'very_complex'; confidence: number } {
    let score = 0;
    
    // Score based on component counts
    score += analysis.entities.length * 1;
    score += analysis.operations.length * 2;
    score += analysis.timeWindows.length * 2;
    score += analysis.conditions.length * 1.5;
    score += analysis.aggregations.length * 2.5;

    let level: 'simple' | 'medium' | 'complex' | 'very_complex';
    if (score <= 3) level = 'simple';
    else if (score <= 7) level = 'medium';
    else if (score <= 12) level = 'complex';
    else level = 'very_complex';

    // Confidence based on how well we understood the query
    const totalComponents = Object.values(analysis).flat().length;
    const confidence = Math.min(0.95, 0.6 + (totalComponents * 0.05));

    return { level, confidence };
  }

  private determineApproach(
    complexity: any,
    similarQueries: SimilarQuery[],
    existingMetrics: ExistingMetric[]
  ): 'direct' | 'single_cte' | 'multi_cte' | 'chunked' | 'use_existing_metric' {
    // Priority 1: Use existing metric if confidence is high
    if (existingMetrics.length > 0 && existingMetrics[0].confidence > 0.85) {
      return 'use_existing_metric';
    }

    // Priority 2: Adapt similar query if very similar
    if (similarQueries.length > 0 && similarQueries[0].similarity > 0.9) {
      return 'direct';
    }

    // Based on complexity
    switch (complexity.level) {
      case 'simple':
        return 'direct';
      case 'medium':
        return 'single_cte';
      case 'complex':
        return 'multi_cte';
      case 'very_complex':
        return 'chunked';
      default:
        return 'direct';
    }
  }

  private generateTechnicalHints(analysis: any, approach: string): string[] {
    const hints = [];

    // Add approach-specific hints
    switch (approach) {
      case 'single_cte':
        hints.push('Use a CTE for better query organization');
        break;
      case 'multi_cte':
        hints.push('Use multiple CTEs to break down the complex logic');
        break;
      case 'chunked':
        hints.push('This query requires multiple steps due to complexity');
        break;
    }

    // Add component-specific hints
    if (analysis.timeWindows.length > 0) {
      hints.push('Use appropriate date functions for time filtering');
    }
    if (analysis.aggregations.length > 0) {
      hints.push('Include GROUP BY clause for aggregations');
    }
    if (analysis.operations.includes('trend') || analysis.operations.includes('change')) {
      hints.push('Consider using window functions for trend analysis');
    }

    return hints;
  }

  private estimateTokens(analysis: any): number {
    let tokens = 100; // Base tokens

    // Add tokens based on components
    tokens += analysis.entities.length * 50;
    tokens += analysis.operations.length * 75;
    tokens += analysis.timeWindows.length * 60;
    tokens += analysis.conditions.length * 80;
    tokens += analysis.aggregations.length * 100;

    return tokens;
  }

  private async getQueryEmbedding(query: string): Promise<number[]> {
    // Use the embedding model from Settings
    if (!Settings.embedModel) {
      throw new Error('No embedding model configured');
    }

    const embedding = await Settings.embedModel.getTextEmbedding(query);
    return Array.from(embedding);
  }

  private parseSemanticResponse(response: string): any {
    // Parse the LLM response to extract structured components
    // This is a simplified version - in production would use more sophisticated parsing
    
    try {
      // Attempt to parse JSON response
      return JSON.parse(response);
    } catch {
      // Fallback to basic extraction
      return this.extractSemanticComponents(response);
    }
  }

  private detectQueryType(query: string): string {
    const lower = query.toLowerCase();
    
    if (lower.includes('count') || lower.includes('how many')) return 'count';
    if (lower.includes('average') || lower.includes('mean')) return 'aggregate';
    if (lower.includes('trend') || lower.includes('over time')) return 'temporal';
    if (lower.includes('compare') || lower.includes('versus')) return 'comparison';
    
    return 'general';
  }

  private async adaptSimilarQuery(
    newQuery: string,
    similarQuery: SimilarQuery,
    components: any
  ): Promise<string> {
    // Intelligent adaptation of similar query
    // This would use LLM to adapt the SQL based on differences
    
    return similarQuery.sql; // Placeholder
  }

  private createIntelligentChunks(
    query: string,
    analysis: QueryComplexityAnalysis
  ): { prompts: string[]; combineStrategy: string } {
    // Create logical chunks based on semantic components
    const chunks = [];

    // Chunk 1: Data extraction
    if (analysis.semanticComponents.entities.length > 0) {
      chunks.push({
        focus: 'Extract base data',
        components: analysis.semanticComponents.entities
      });
    }

    // Chunk 2: Filtering and conditions
    if (analysis.semanticComponents.conditions.length > 0 || 
        analysis.semanticComponents.timeWindows.length > 0) {
      chunks.push({
        focus: 'Apply filters and time windows',
        components: [...analysis.semanticComponents.conditions, ...analysis.semanticComponents.timeWindows]
      });
    }

    // Chunk 3: Aggregations and calculations
    if (analysis.semanticComponents.aggregations.length > 0 ||
        analysis.semanticComponents.operations.length > 0) {
      chunks.push({
        focus: 'Perform aggregations and calculations',
        components: [...analysis.semanticComponents.aggregations, ...analysis.semanticComponents.operations]
      });
    }

    return {
      prompts: chunks.map(chunk => `Focus: ${chunk.focus}\nComponents: ${chunk.components.join(', ')}`),
      combineStrategy: 'progressive_cte'
    };
  }

  private fallbackAnalysis(query: string): QueryComplexityAnalysis {
    const components = this.extractSemanticComponents(query);
    const wordCount = query.split(' ').length;
    
    let complexity: 'simple' | 'medium' | 'complex' | 'very_complex' = 'simple';
    if (wordCount > 30) complexity = 'complex';
    else if (wordCount > 20) complexity = 'medium';

    return {
      complexity,
      confidence: 0.6,
      suggestedApproach: complexity === 'complex' ? 'multi_cte' : 'direct',
      estimatedTokens: wordCount * 15,
      semanticComponents: components,
      similarQueries: [],
      existingMetrics: [],
      technicalHints: ['Using fallback analysis due to error']
    };
  }
}