import { 
  BaseVectorStore, 
  VectorStoreQuery, 
  VectorStoreQueryResult,
  TextNode,
  NodeWithScore,
  BaseNode,
  BaseEmbedding,
  Settings,
  MetadataMode
} from 'llamaindex';
import { QdrantClient } from '@qdrant/js-client-rest';
import { v4 as uuidv4 } from 'uuid';

import { healthcareLogger } from '../../monitoring/StructuredLogger';

const logger = healthcareLogger;

export interface QdrantConfig {
  url?: string;
  apiKey?: string;
  collectionName?: string;
  vectorSize?: number;
  embedModel?: BaseEmbedding;
}

export class QdrantVectorStore extends BaseVectorStore {
  private qdrantClient: QdrantClient;
  private collectionName: string;
  private vectorSize: number;
  storesText = true;

  constructor(config: QdrantConfig = {}) {
    super();
    // Set the embedding model
    if (config.embedModel) {
      this.embedModel = config.embedModel;
    } else if (!this.embedModel) {
      this.embedModel = Settings.embedModel;
    }
    
    this.qdrantClient = new QdrantClient({
      url: config.url || process.env.QDRANT_URL || 'http://localhost:6333',
      apiKey: config.apiKey,
    });
    this.collectionName = config.collectionName || 'nexuscare_healthcare_queries';
    this.vectorSize = config.vectorSize || 384; // Default for all-MiniLM-L6-v2
  }

  client(): QdrantClient {
    return this.qdrantClient;
  }

  async init(): Promise<void> {
    try {
      // Check if collection exists
      const collections = await this.qdrantClient.getCollections();
      const exists = collections.collections.some(c => c.name === this.collectionName);

      if (!exists) {
        // Create collection with appropriate settings
        await this.qdrantClient.createCollection(this.collectionName, {
          vectors: {
            size: this.vectorSize,
            distance: 'Cosine',
          },
          optimizers_config: {
            default_segment_number: 2,
          },
          replication_factor: 2,
        });

        logger.info('[QdrantVectorStore] Created collection', {
          metadata: {
            collectionName: this.collectionName,
            vectorSize: this.vectorSize
          }
        });
      } else {
        logger.info('[QdrantVectorStore] Collection already exists', {
          metadata: { collectionName: this.collectionName }
        });
      }

      // Create indexes for better search performance
      await this.qdrantClient.createPayloadIndex(this.collectionName, {
        field_name: 'category',
        field_schema: 'keyword',
      });

      await this.qdrantClient.createPayloadIndex(this.collectionName, {
        field_name: 'query_type',
        field_schema: 'keyword',
      });

    } catch (error) {
      logger.error('[QdrantVectorStore] Failed to initialize', {
        metadata: { error: (error as Error).message }
      });
      throw error;
    }
  }

  async add(nodes: BaseNode[]): Promise<string[]> {
    if (nodes.length === 0) return [];

    try {
      const points = await Promise.all(nodes.map(async (node) => {
        const id = node.id_ || uuidv4();
        
        // Get embedding - either from node or generate it
        let embedding = node.getEmbedding();
        if (!embedding || embedding.length === 0) {
          // Generate embedding using the embed model
          const text = node.getContent(MetadataMode.EMBED);
          embedding = await this.embedModel.getTextEmbedding(text);
        }
        
        if (!embedding || embedding.length === 0) {
          throw new Error(`Node ${id} has no embedding`);
        }

        return {
          id,
          vector: embedding,
          payload: {
            text: node.getContent(MetadataMode.ALL),
            metadata: node.metadata || {},
            category: node.metadata?.category || 'general',
            query_type: node.metadata?.query_type || 'unknown',
            sql: node.metadata?.sql || '',
            description: node.metadata?.description || '',
            timestamp: new Date().toISOString(),
            node_info: node.toJSON(),
          },
        };
      }));

      await this.qdrantClient.upsert(this.collectionName, {
        points,
        wait: true,
      });

      logger.info('[QdrantVectorStore] Added nodes', {
        metadata: {
          count: nodes.length,
          collectionName: this.collectionName
        }
      });

      return points.map(p => p.id as string);
    } catch (error) {
      logger.error('[QdrantVectorStore] Failed to add nodes', {
        metadata: { error: (error as Error).message }
      });
      throw error;
    }
  }

  async delete(refDocId: string): Promise<void> {
    try {
      await this.qdrantClient.delete(this.collectionName, {
        filter: {
          must: [
            {
              key: 'ref_doc_id',
              match: { value: refDocId },
            },
          ],
        },
      });

      logger.info('[QdrantVectorStore] Deleted nodes', {
        metadata: {
          refDocId,
          collectionName: this.collectionName
        }
      });
    } catch (error) {
      logger.error('[QdrantVectorStore] Failed to delete nodes', {
        metadata: { error: (error as Error).message }
      });
      throw error;
    }
  }

  async query(query: VectorStoreQuery): Promise<VectorStoreQueryResult> {
    try {
      if (!query.queryEmbedding || query.queryEmbedding.length === 0) {
        throw new Error('Query embedding is required');
      }

      // Build filter if provided
      const filter: any = {};
      if (query.filters && query.filters.filters) {
        filter.must = query.filters.filters.map(f => ({
          key: f.key,
          match: { value: f.value },
        }));
      }

      // Search in Qdrant
      const searchResult = await this.qdrantClient.search(this.collectionName, {
        vector: query.queryEmbedding,
        limit: query.similarityTopK || 10,
        filter: Object.keys(filter).length > 0 ? filter : undefined,
        with_payload: true,
        with_vector: false,
      });

      // Convert Qdrant results to LlamaIndex format
      const nodes: NodeWithScore[] = searchResult.map(result => {
        const baseMetadata = (result.payload?.metadata as Record<string, any>) || {};
        const node = new TextNode({
          id_: result.id as string,
          text: result.payload?.text as string || '',
          metadata: {
            ...baseMetadata,
            category: result.payload?.category,
            query_type: result.payload?.query_type,
            sql: result.payload?.sql,
            description: result.payload?.description,
          },
        });

        return {
          node,
          score: result.score || 0,
        };
      });

      logger.info('[QdrantVectorStore] Query completed', {
        metadata: {
          resultCount: nodes.length,
          topScore: nodes[0]?.score || 0
        }
      });

      return {
        nodes: nodes.map(n => n.node),
        similarities: nodes.map(n => n.score) as number[],
        ids: nodes.map(n => n.node.id_),
      };
    } catch (error) {
      logger.error('[QdrantVectorStore] Query failed', {
        metadata: { error: (error as Error).message }
      });
      throw error;
    }
  }

}