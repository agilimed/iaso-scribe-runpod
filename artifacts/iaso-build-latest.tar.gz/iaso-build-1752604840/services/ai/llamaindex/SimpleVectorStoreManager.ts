import { 
  VectorStoreIndex,
  SimpleVectorStore,
  Document,
  VectorStoreQueryMode,
  Settings,
  BaseEmbedding
} from 'llamaindex';

import { healthcareLogger } from '../../monitoring/StructuredLogger';

import { CustomEmbeddingFactory } from './CustomEmbeddings';

const logger = healthcareLogger;

export interface VectorStoreConfig {
  collectionName: string;
  embeddingDimension?: number;
  persistDir?: string;
}

export class SimpleVectorStoreManager {
  private vectorStore: SimpleVectorStore;
  private index: VectorStoreIndex | null = null;
  private config: VectorStoreConfig;

  constructor(config: VectorStoreConfig) {
    this.config = config;
    
    // Initialize embedding model based on environment
    const embeddingProvider = process.env.EMBEDDING_PROVIDER || 'mock';
    const embedModel = CustomEmbeddingFactory.create(embeddingProvider);
    Settings.embedModel = embedModel;
    
    // Initialize simple vector store with text storage
    this.vectorStore = new SimpleVectorStore({
      storeText: true,
    });
  }

  async initialize(): Promise<void> {
    try {
      // Create or load index
      this.index = await VectorStoreIndex.fromVectorStore(this.vectorStore);
      
      logger.info('Simple vector store initialized successfully', {
        collectionName: this.config.collectionName
      });
    } catch (error) {
      logger.error('Failed to initialize vector store', {
        error: error.message,
        collectionName: this.config.collectionName
      });
      throw error;
    }
  }

  async addDocuments(documents: Document[]): Promise<void> {
    if (!this.index) {
      throw new Error('Vector store not initialized');
    }

    try {
      // Insert documents into the index
      for (const doc of documents) {
        await this.index.insert(doc);
      }
      
      logger.info('Documents added to vector store', {
        count: documents.length,
        collectionName: this.config.collectionName
      });
    } catch (error) {
      logger.error('Failed to add documents to vector store', {
        error: error.message,
        documentCount: documents.length
      });
      throw error;
    }
  }

  async search(
    query: string,
    topK: number = 5
  ): Promise<any> {
    if (!this.index) {
      throw new Error('Vector store not initialized');
    }

    try {
      const queryEngine = this.index.asQueryEngine({
        similarityTopK: topK,
        mode: VectorStoreQueryMode.DEFAULT,
      });

      const response = await queryEngine.query({
        query,
      });

      return {
        response: response.toString(),
        sourceNodes: response.sourceNodes?.map(node => ({
          text: node.node.text,
          score: node.score,
          metadata: node.node.metadata,
        })),
      };
    } catch (error) {
      logger.error('Vector search failed', {
        error: error.message,
        query,
      });
      throw error;
    }
  }

  async persist(): Promise<void> {
    if (this.config.persistDir && this.index) {
      try {
        await this.index.storageContext.persist(this.config.persistDir);
        logger.info('Vector store persisted', {
          persistDir: this.config.persistDir
        });
      } catch (error) {
        logger.error('Failed to persist vector store', {
          error: error.message
        });
        throw error;
      }
    }
  }

  getIndex(): VectorStoreIndex | null {
    return this.index;
  }
}

// Factory function for different vector store collections
export class SimpleVectorStoreFactory {
  private static instances: Map<string, SimpleVectorStoreManager> = new Map();

  static async getOrCreate(
    collectionName: string,
    config?: Partial<VectorStoreConfig>
  ): Promise<SimpleVectorStoreManager> {
    if (!this.instances.has(collectionName)) {
      const fullConfig: VectorStoreConfig = {
        collectionName,
        persistDir: `./vector_stores/${collectionName}`,
        ...config,
      };

      const manager = new SimpleVectorStoreManager(fullConfig);
      await manager.initialize();
      this.instances.set(collectionName, manager);
    }

    return this.instances.get(collectionName)!;
  }

  static async createCollections(): Promise<void> {
    // Create all necessary collections
    const collections = [
      'fhir_resources',
      'medical_knowledge', 
      'clickhouse_schema',
      'conversation_memory',
      'query_patterns',
    ];

    for (const collection of collections) {
      await this.getOrCreate(collection);
    }

    logger.info('All vector store collections created');
  }
}