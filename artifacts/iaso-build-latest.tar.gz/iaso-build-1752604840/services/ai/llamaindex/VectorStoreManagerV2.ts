/**
 * Enhanced Vector Store Manager with Custom Embeddings Support
 * This version removes OpenAI dependency and uses custom embeddings
 */

import { QdrantClient } from '@qdrant/js-client-rest';
import { 
  VectorStoreIndex,
  QdrantVectorStore,
  Document,
  VectorStoreQueryMode,
  Settings,
  BaseEmbedding
} from 'llamaindex';

import { healthcareLogger } from '../../monitoring/StructuredLogger';

import { createEmbedding, getEmbeddingDimension } from './CustomEmbeddings';

const logger = healthcareLogger;

export interface VectorStoreConfig {
  url: string;
  apiKey?: string;
  collectionName: string;
  embeddingDimension?: number; // Now optional, will be auto-detected
  embeddingProvider?: 'huggingface-api' | 'local' | 'mock' | 'openai';
  embeddingModel?: string;
}

export class VectorStoreManagerV2 {
  private qdrantClient: QdrantClient;
  private vectorStore: QdrantVectorStore;
  private index: VectorStoreIndex | null = null;
  private config: VectorStoreConfig;
  private embeddingModel: BaseEmbedding | undefined;

  constructor(config: VectorStoreConfig) {
    this.config = config;
    
    // Initialize custom embeddings
    this.initializeEmbeddings();
    
    // Auto-detect embedding dimension if not provided
    if (!this.config.embeddingDimension) {
      this.config.embeddingDimension = getEmbeddingDimension(this.config.embeddingModel);
    }
    
    // Initialize Qdrant client
    this.qdrantClient = new QdrantClient({
      url: config.url,
      apiKey: config.apiKey,
    });

    // Initialize vector store
    this.vectorStore = new QdrantVectorStore({
      client: this.qdrantClient,
      collectionName: config.collectionName,
    });
  }

  private initializeEmbeddings(): void {
    // Create custom embedding model
    this.embeddingModel = createEmbedding({
      provider: this.config.embeddingProvider,
      modelName: this.config.embeddingModel,
    });

    // Set in global Settings if created
    if (this.embeddingModel) {
      Settings.embedModel = this.embeddingModel;
      logger.info('Custom embedding model initialized', {
        provider: this.config.embeddingProvider,
        model: this.config.embeddingModel,
        dimension: this.config.embeddingDimension
      });
    } else {
      logger.info('Using default OpenAI embeddings');
    }
  }

  async initialize(): Promise<void> {
    try {
      // Check if collection exists
      const collections = await this.qdrantClient.getCollections();
      const collectionExists = collections.collections.some(
        c => c.name === this.config.collectionName
      );

      if (!collectionExists) {
        // Create collection with proper configuration
        await this.qdrantClient.createCollection(this.config.collectionName, {
          vectors: {
            size: this.config.embeddingDimension!,
            distance: 'Cosine',
          },
          optimizers_config: {
            default_segment_number: 2,
          },
          replication_factor: 2,
        });
        
        logger.info('Created Qdrant collection', {
          collectionName: this.config.collectionName,
          dimension: this.config.embeddingDimension,
          embeddingProvider: this.config.embeddingProvider
        });
      } else {
        // Verify dimension matches
        const collectionInfo = await this.qdrantClient.getCollection(this.config.collectionName);
        const existingDimension = collectionInfo.config?.params?.vectors?.size;
        
        if (existingDimension && existingDimension !== this.config.embeddingDimension) {
          logger.warn('Collection dimension mismatch', {
            collection: this.config.collectionName,
            existing: existingDimension,
            configured: this.config.embeddingDimension
          });
        }
      }

      // Create or load index
      this.index = await VectorStoreIndex.fromVectorStore(this.vectorStore);
      
      logger.info('Vector store initialized successfully', {
        collectionName: this.config.collectionName,
        embeddingProvider: this.config.embeddingProvider
      });
    } catch (error) {
      logger.error('Failed to initialize vector store', {
        error: error.message,
        collectionName: this.config.collectionName
      });
      throw error;
    }
  }

  async addDocuments(documents: Document[]): Promise<void> {
    if (!this.index) {
      throw new Error('Vector store not initialized');
    }

    try {
      // Batch processing for better performance
      const batchSize = 10;
      for (let i = 0; i < documents.length; i += batchSize) {
        const batch = documents.slice(i, i + batchSize);
        
        // Insert documents into the index
        for (const doc of batch) {
          await this.index.insert(doc);
        }
        
        logger.info('Batch of documents added to vector store', {
          batchNumber: Math.floor(i / batchSize) + 1,
          documentsInBatch: batch.length,
          collectionName: this.config.collectionName
        });
      }
      
      logger.info('All documents added to vector store', {
        totalCount: documents.length,
        collectionName: this.config.collectionName
      });
    } catch (error) {
      logger.error('Failed to add documents to vector store', {
        error: error.message,
        documentCount: documents.length
      });
      throw error;
    }
  }

  async search(
    query: string,
    topK: number = 5,
    filters?: Record<string, any>
  ): Promise<any> {
    if (!this.index) {
      throw new Error('Vector store not initialized');
    }

    try {
      const queryEngine = this.index.asQueryEngine({
        similarityTopK: topK,
        mode: VectorStoreQueryMode.DEFAULT,
      });

      const response = await queryEngine.query({
        query,
      });

      return {
        response: response.toString(),
        sourceNodes: response.sourceNodes?.map(node => ({
          text: node.node.text,
          score: node.score,
          metadata: node.node.metadata,
        })),
      };
    } catch (error) {
      logger.error('Vector search failed', {
        error: error.message,
        query,
      });
      throw error;
    }
  }

  async upsertDocument(
    id: string,
    content: string,
    metadata: Record<string, any>
  ): Promise<void> {
    if (!this.index) {
      throw new Error('Vector store not initialized');
    }

    const doc = new Document({
      text: content,
      id_: id,
      metadata: {
        ...metadata,
        timestamp: new Date().toISOString(),
      },
    });

    await this.addDocuments([doc]);
  }

  async deleteDocument(id: string): Promise<void> {
    try {
      await this.qdrantClient.delete(this.config.collectionName, {
        filter: {
          must: [
            {
              key: 'doc_id',
              match: { value: id },
            },
          ],
        },
      });
      
      logger.info('Document deleted from vector store', {
        documentId: id,
        collectionName: this.config.collectionName
      });
    } catch (error) {
      logger.error('Failed to delete document', {
        error: error.message,
        documentId: id
      });
      throw error;
    }
  }

  async createSnapshot(): Promise<string> {
    try {
      const result = await this.qdrantClient.createSnapshot(this.config.collectionName);
      logger.info('Snapshot created', {
        collectionName: this.config.collectionName,
        snapshotName: result.name
      });
      return result.name;
    } catch (error) {
      logger.error('Failed to create snapshot', {
        error: error.message,
        collectionName: this.config.collectionName
      });
      throw error;
    }
  }

  getIndex(): VectorStoreIndex | null {
    return this.index;
  }

  async getCollectionInfo(): Promise<any> {
    try {
      return await this.qdrantClient.getCollection(this.config.collectionName);
    } catch (error) {
      logger.error('Failed to get collection info', {
        error: error.message,
        collectionName: this.config.collectionName
      });
      throw error;
    }
  }

  /**
   * Migrate from one embedding model to another
   */
  async migrateEmbeddings(
    newProvider: 'huggingface-api' | 'local' | 'mock' | 'openai',
    newModel?: string
  ): Promise<void> {
    logger.info('Starting embedding migration', {
      from: this.config.embeddingProvider,
      to: newProvider,
      model: newModel
    });

    // Create new collection with new dimensions
    const newDimension = getEmbeddingDimension(newModel);
    const tempCollectionName = `${this.config.collectionName}_migration_${Date.now()}`;
    
    // Create temporary manager with new embeddings
    const tempManager = new VectorStoreManagerV2({
      ...this.config,
      collectionName: tempCollectionName,
      embeddingDimension: newDimension,
      embeddingProvider: newProvider,
      embeddingModel: newModel,
    });
    
    await tempManager.initialize();
    
    // TODO: Implement document migration logic
    // This would involve:
    // 1. Scrolling through all documents in current collection
    // 2. Re-embedding with new model
    // 3. Inserting into new collection
    // 4. Swapping collections when complete
    
    logger.info('Embedding migration completed');
  }
}

// Enhanced factory with custom embedding support
export class VectorStoreFactoryV2 {
  private static instances: Map<string, VectorStoreManagerV2> = new Map();

  static async getOrCreate(
    collectionName: string,
    config?: Partial<VectorStoreConfig>
  ): Promise<VectorStoreManagerV2> {
    const cacheKey = `${collectionName}_${config?.embeddingProvider || 'default'}`;
    
    if (!this.instances.has(cacheKey)) {
      const embeddingProvider = config?.embeddingProvider || 
        (process.env.EMBEDDING_PROVIDER as any) || 
        'huggingface-api';
      
      const embeddingModel = config?.embeddingModel || 
        process.env.HF_MODEL_NAME || 
        'sentence-transformers/all-MiniLM-L6-v2';
      
      const fullConfig: VectorStoreConfig = {
        url: process.env.QDRANT_URL || 'http://localhost:6333',
        apiKey: process.env.QDRANT_API_KEY,
        collectionName,
        embeddingProvider,
        embeddingModel,
        embeddingDimension: getEmbeddingDimension(embeddingModel),
        ...config,
      };

      const manager = new VectorStoreManagerV2(fullConfig);
      await manager.initialize();
      this.instances.set(cacheKey, manager);
    }

    return this.instances.get(cacheKey)!;
  }

  static async createCollections(): Promise<void> {
    // Create all necessary collections with appropriate models
    const collections = [
      { 
        name: 'fhir_resources', 
        provider: 'huggingface-api' as const,
        model: 'BAAI/bge-base-en-v1.5' // Good for structured data
      },
      { 
        name: 'medical_knowledge', 
        provider: 'huggingface-api' as const,
        model: 'sentence-transformers/all-mpnet-base-v2' // Good for knowledge
      },
      { 
        name: 'clickhouse_schema', 
        provider: 'huggingface-api' as const,
        model: 'sentence-transformers/all-MiniLM-L6-v2' // Fast for schema
      },
      { 
        name: 'conversation_memory', 
        provider: 'huggingface-api' as const,
        model: 'sentence-transformers/all-MiniLM-L6-v2' // Fast for conversations
      },
      { 
        name: 'query_patterns', 
        provider: 'huggingface-api' as const,
        model: 'BAAI/bge-small-en-v1.5' // Good balance for SQL patterns
      },
    ];

    for (const collection of collections) {
      await this.getOrCreate(collection.name, {
        embeddingProvider: collection.provider,
        embeddingModel: collection.model,
      });
    }

    logger.info('All vector store collections created with custom embeddings');
  }

  /**
   * Get collection statistics
   */
  static async getStats(): Promise<Record<string, any>> {
    const stats: Record<string, any> = {};
    
    for (const [key, manager] of this.instances) {
      const info = await manager.getCollectionInfo();
      stats[key] = {
        vectorsCount: info.vectors_count,
        indexedVectorsCount: info.indexed_vectors_count,
        pointsCount: info.points_count,
        config: info.config,
      };
    }
    
    return stats;
  }
}