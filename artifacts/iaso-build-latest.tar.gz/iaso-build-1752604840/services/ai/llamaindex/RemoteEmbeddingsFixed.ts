import { BaseEmbedding } from 'llamaindex';
import fetch from 'node-fetch';

import { logger } from '../../../utils/logger';

interface EmbeddingServiceResponse {
  embeddings: number[] | number[][];
  model: string;
  dimensions: number;
  duration_ms: number;
}

export class RemoteEmbeddingsFixed extends BaseEmbedding {
  private serviceUrl: string;
  private model: string;
  private timeout: number;
  embedBatchSize: number = 100;

  constructor(config: {
    serviceUrl?: string;
    model?: string;
    timeout?: number;
    batchSize?: number;
  } = {}) {
    super();
    this.serviceUrl = config.serviceUrl || 'http://localhost:8090';
    this.model = config.model || 'all-MiniLM-L6-v2';
    this.timeout = config.timeout || 30000;
    this.embedBatchSize = config.batchSize || 100;
  }

  // Implement synchronous methods (throw error as we need async)
  getQueryEmbedding(query: string): number[] {
    throw new Error('Synchronous embedding not supported. Use async methods.');
  }

  getTextEmbedding(text: string): number[] {
    throw new Error('Synchronous embedding not supported. Use async methods.');
  }

  getTextEmbeddings(texts: string[]): number[][] {
    throw new Error('Synchronous embedding not supported. Use async methods.');
  }

  // Implement async methods
  async getQueryEmbedding(query: string): Promise<number[]> {
    return this.getTextEmbedding(query);
  }

  async getTextEmbedding(text: string): Promise<number[]> {
    try {
      const response = await fetch(`${this.serviceUrl}/api/v1/embed`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text,
          model: this.model,
        }),
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) {
        throw new Error(`Embedding service error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json() as EmbeddingServiceResponse;
      
      // Handle both single and batch responses
      if (Array.isArray(data.embeddings) && data.embeddings.length > 0) {
        if (Array.isArray(data.embeddings[0])) {
          // Batch response, return first embedding
          return data.embeddings[0] as number[];
        } else {
          // Single embedding response
          return data.embeddings as number[];
        }
      }

      throw new Error('Invalid embedding response format');
    } catch (error) {
      logger.error('Failed to get embedding from service:', error);
      throw error;
    }
  }

  async getTextEmbeddings(texts: string[]): Promise<number[][]> {
    try {
      // Process in batches if needed
      const batches: string[][] = [];
      for (let i = 0; i < texts.length; i += this.embedBatchSize) {
        batches.push(texts.slice(i, i + this.embedBatchSize));
      }

      const allEmbeddings: number[][] = [];
      
      for (const batch of batches) {
        const response = await fetch(`${this.serviceUrl}/api/v1/embed`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            texts: batch,
            model: this.model,
          }),
          signal: AbortSignal.timeout(this.timeout),
        });

        if (!response.ok) {
          throw new Error(`Embedding service error: ${response.status} ${response.statusText}`);
        }

        const data = await response.json() as EmbeddingServiceResponse;
        
        // Ensure we have a 2D array
        if (Array.isArray(data.embeddings)) {
          if (batch.length === 1 && !Array.isArray(data.embeddings[0])) {
            // Single text was sent but response is 1D array
            allEmbeddings.push(data.embeddings as number[]);
          } else {
            allEmbeddings.push(...(data.embeddings as number[][]));
          }
        } else {
          throw new Error('Invalid batch embedding response format');
        }
      }

      return allEmbeddings;
    } catch (error) {
      logger.error('Failed to get batch embeddings from service:', error);
      throw error;
    }
  }

  // Additional methods for model management
  async switchModel(modelName: string): Promise<void> {
    try {
      const response = await fetch(`${this.serviceUrl}/api/v1/models/${modelName}/activate`, {
        method: 'POST',
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) {
        throw new Error(`Failed to switch model: ${response.status} ${response.statusText}`);
      }

      this.model = modelName;
      logger.info(`Switched to embedding model: ${modelName}`);
    } catch (error) {
      logger.error('Failed to switch embedding model:', error);
      throw error;
    }
  }

  async getAvailableModels(): Promise<{ models: string[]; active: string }> {
    try {
      const response = await fetch(`${this.serviceUrl}/api/v1/models`, {
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) {
        throw new Error(`Failed to get models: ${response.status} ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      logger.error('Failed to get available models:', error);
      throw error;
    }
  }
}

// Factory function for different embedding models
export function createEmbeddingFixed(modelType: 'general' | 'medical' | 'multilingual' = 'general'): RemoteEmbeddingsFixed {
  const modelMap = {
    general: 'all-MiniLM-L6-v2',
    medical: 'biobert-base',
    multilingual: 'multilingual-e5-base',
  };

  return new RemoteEmbeddingsFixed({
    model: modelMap[modelType],
  });
}