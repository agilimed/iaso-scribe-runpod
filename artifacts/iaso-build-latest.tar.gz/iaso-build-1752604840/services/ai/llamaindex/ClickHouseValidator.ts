import ClickHouseService from '../../analytics/ClickHouseService';
import { healthcareLogger as logger } from '../../monitoring/StructuredLogger';

export interface QueryValidationResult {
  isValid: boolean;
  executionTime?: number;
  rowCount?: number;
  error?: string;
  syntaxValid: boolean;
  executionValid: boolean;
  hasResults: boolean;
}

export class ClickHouseValidator {
  private clickhouseClient: any;
  private readonly maxRowsForValidation = 100;
  
  constructor() {
    this.clickhouseClient = ClickHouseService.getInstance().getClient();
  }

  /**
   * Validate SQL query by actually running it against ClickHouse
   * This ensures:
   * 1. Syntax is correct
   * 2. Tables and columns exist
   * 3. Functions are valid
   * 4. Query produces results
   */
  async validateQuery(sql: string, expectedIntent?: string): Promise<QueryValidationResult> {
    const result: QueryValidationResult = {
      isValid: false,
      syntaxValid: false,
      executionValid: false,
      hasResults: false
    };

    try {
      // 1. First, check if it's a safe query (SELECT only)
      const safetyCheck = this.isSafeQuery(sql);
      if (!safetyCheck.safe) {
        result.error = safetyCheck.reason;
        return result;
      }

      // 2. Add LIMIT to prevent large result sets during validation
      const limitedSQL = this.addLimitIfNeeded(sql);

      // 3. Try to execute the query
      const startTime = Date.now();
      
      logger.info('[ClickHouseValidator] Executing validation query', {
        metadata: {
          sqlPreview: sql.substring(0, 100)
        }
      });

      const queryResult = await this.clickhouseClient.query({
        query: limitedSQL,
        format: 'JSON'
      });

      const data = await queryResult.json();
      const executionTime = Date.now() - startTime;

      // Query executed successfully
      result.syntaxValid = true;
      result.executionValid = true;
      result.executionTime = executionTime;
      result.rowCount = data.rows || 0;
      result.hasResults = result.rowCount > 0;

      // 4. Additional validation based on expected intent
      if (expectedIntent) {
        const intentValid = this.validateIntent(sql, data, expectedIntent);
        if (!intentValid.valid) {
          result.isValid = false;
          result.error = intentValid.reason;
          return result;
        }
      }

      // All checks passed
      result.isValid = true;

      logger.info('[ClickHouseValidator] Query validation successful', {
        metadata: {
          executionTime,
          rowCount: result.rowCount,
          hasResults: result.hasResults
        }
      });

    } catch (error: any) {
      result.error = error.message;
      
      // Check if it's a syntax error
      if (error.message.includes('Syntax error') || 
          error.message.includes('Unknown identifier') ||
          error.message.includes('Unknown table') ||
          error.message.includes('Unknown column')) {
        result.syntaxValid = false;
      } else {
        // Syntax might be valid but execution failed
        result.syntaxValid = true;
        result.executionValid = false;
      }

      logger.error('[ClickHouseValidator] Query validation failed', {
        metadata: {
          error: error.message,
          sqlPreview: sql.substring(0, 100)
        }
      });
    }

    return result;
  }

  /**
   * Validate that the query result matches the expected intent
   */
  private validateIntent(sql: string, result: any, intent: string): { valid: boolean; reason?: string } {
    const normalizedSQL = sql.toLowerCase();
    
    switch (intent.toLowerCase()) {
      case 'count':
        // For count queries, should return a numeric result
        if (!normalizedSQL.includes('count')) {
          return { valid: false, reason: 'Count query should use COUNT function' };
        }
        break;
        
      case 'patient_conditions':
        // Should query Condition resource type
        if (!normalizedSQL.includes('resource_type = \'condition\'')) {
          return { valid: false, reason: 'Patient condition queries must filter by Condition resource type' };
        }
        break;
        
      case 'list':
        // Should return multiple columns for listing
        if (result.meta && result.meta.length < 2) {
          return { valid: false, reason: 'List queries should return multiple fields' };
        }
        break;
    }
    
    return { valid: true };
  }

  /**
   * Check if query is safe to execute
   */
  private isSafeQuery(sql: string): { safe: boolean; reason?: string } {
    const normalized = sql.toLowerCase().trim();
    
    // Only allow SELECT statements
    if (!normalized.startsWith('select') && !normalized.startsWith('with')) {
      return { safe: false, reason: 'Only SELECT queries allowed for validation' };
    }
    
    // Prevent dangerous operations
    const dangerousKeywords = [
      'insert', 'update', 'delete', 'drop', 'truncate', 'alter', 'create',
      'grant', 'revoke', 'kill', 'system', 'detach', 'attach'
    ];
    
    for (const keyword of dangerousKeywords) {
      if (normalized.includes(` ${keyword} `) || normalized.includes(`\n${keyword} `)) {
        return { safe: false, reason: `Dangerous operation detected: ${keyword}` };
      }
    }
    
    // Prevent access to system tables
    if (normalized.includes('system.') || normalized.includes('information_schema')) {
      return { safe: false, reason: 'System table access not allowed' };
    }
    
    return { safe: true };
  }

  /**
   * Add LIMIT clause if not present to prevent large result sets
   */
  private addLimitIfNeeded(sql: string): string {
    const normalized = sql.toLowerCase();
    
    // Check if already has LIMIT
    if (normalized.includes(' limit ')) {
      return sql;
    }
    
    // Add limit at the end
    return `${sql.trim()} LIMIT ${this.maxRowsForValidation}`;
  }

  /**
   * Test if ClickHouse connection is working
   */
  async testConnection(): Promise<boolean> {
    try {
      const result = await this.clickhouseClient.query({
        query: 'SELECT 1 as test',
        format: 'JSON'
      });
      
      const data = await result.json();
      return data.rows === 1;
    } catch (error) {
      logger.error('[ClickHouseValidator] Connection test failed', {
        metadata: { error: (error as Error).message }
      });
      return false;
    }
  }
}