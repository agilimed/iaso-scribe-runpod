import * as fs from 'fs/promises';
import * as path from 'path';

import { Document, MetadataMode } from 'llamaindex';

import { ClickHouseService } from '../../analytics/ClickHouseService';
import { healthcareLogger } from '../../monitoring/StructuredLogger';

const logger = healthcareLogger;

export interface DocumentMetadata {
  source: string;
  type: string;
  resourceType?: string;
  category?: string;
  lastUpdated: string;
  tags?: string[];
}

export class DocumentLoader {
  private clickhouse: ClickHouseService;

  constructor() {
    this.clickhouse = new ClickHouseService();
  }

  /**
   * Load FHIR resource metadata from ClickHouse
   */
  async loadFHIRMetadata(): Promise<Document[]> {
    try {
      const query = `
        SELECT 
          metadata_id,
          resource_type,
          fhir_element,
          display_name,
          description,
          data_type,
          is_array,
          is_required,
          example_values,
          common_codes,
          use_cases
        FROM nexuscare_analytics.fhir_metadata
        WHERE is_active = 1
        ORDER BY resource_type, fhir_element
      `;

      const results = await this.clickhouse.query(query);
      const documents: Document[] = [];

      for (const row of results) {
        const content = this.formatFHIRMetadataContent(row);
        const doc = new Document({
          text: content,
          id_: `fhir_metadata_${row.metadata_id}`,
          metadata: {
            source: 'clickhouse_fhir_metadata',
            type: 'fhir_field_metadata',
            resourceType: row.resource_type,
            fhirElement: row.fhir_element,
            dataType: row.data_type,
            displayName: row.display_name,
            lastUpdated: new Date().toISOString(),
            tags: ['fhir', 'metadata', row.resource_type.toLowerCase()],
          } as DocumentMetadata,
        });
        documents.push(doc);
      }

      logger.info('Loaded FHIR metadata documents', {
        count: documents.length,
      });

      return documents;
    } catch (error) {
      logger.error('Failed to load FHIR metadata', {
        error: error.message,
      });
      throw error;
    }
  }

  /**
   * Load ClickHouse schema information
   */
  async loadClickHouseSchema(): Promise<Document[]> {
    try {
      const documents: Document[] = [];

      // Load table schemas
      const tableQuery = `
        SELECT 
          table,
          engine,
          partition_key,
          sorting_key,
          primary_key,
          sampling_key
        FROM system.tables
        WHERE database = 'nexuscare_analytics'
      `;

      const tables = await this.clickhouse.query(tableQuery);

      for (const table of tables) {
        // Get column information
        const columnQuery = `
          SELECT 
            name,
            type,
            default_expression,
            comment
          FROM system.columns
          WHERE database = 'nexuscare_analytics'
            AND table = '${table.table}'
          ORDER BY position
        `;

        const columns = await this.clickhouse.query(columnQuery);
        const content = this.formatTableSchemaContent(table, columns);

        const doc = new Document({
          text: content,
          id_: `clickhouse_schema_${table.table}`,
          metadata: {
            source: 'clickhouse_schema',
            type: 'table_schema',
            tableName: table.table,
            engine: table.engine,
            category: 'database_schema',
            lastUpdated: new Date().toISOString(),
            tags: ['clickhouse', 'schema', 'table'],
          } as DocumentMetadata,
        });
        documents.push(doc);
      }

      logger.info('Loaded ClickHouse schema documents', {
        count: documents.length,
      });

      return documents;
    } catch (error) {
      logger.error('Failed to load ClickHouse schema', {
        error: error.message,
      });
      throw error;
    }
  }

  /**
   * Load medical knowledge documents
   */
  async loadMedicalKnowledge(): Promise<Document[]> {
    try {
      const documents: Document[] = [];

      // Load FHIR resource descriptions
      const fhirResources = [
        {
          name: 'Patient',
          description: 'Demographics and administrative information about an individual receiving care',
          key_fields: ['identifier', 'name', 'birthDate', 'gender', 'address'],
          relationships: ['generalPractitioner', 'managingOrganization'],
          use_cases: ['Patient registration', 'Demographics queries', 'Patient matching'],
        },
        {
          name: 'Encounter',
          description: 'An interaction between a patient and healthcare provider(s) for the purpose of providing healthcare service(s)',
          key_fields: ['status', 'class', 'type', 'period', 'location'],
          relationships: ['subject (Patient)', 'participant (Practitioner)', 'serviceProvider (Organization)'],
          use_cases: ['Admission tracking', 'Visit history', 'Department analytics'],
        },
        {
          name: 'Observation',
          description: 'Measurements and simple assertions made about a patient, device or other subject',
          key_fields: ['status', 'code', 'value', 'effectiveDateTime', 'interpretation'],
          relationships: ['subject (Patient)', 'encounter', 'performer'],
          use_cases: ['Lab results', 'Vital signs', 'Clinical measurements'],
        },
        {
          name: 'Condition',
          description: 'A clinical condition, problem, diagnosis, or other event that has risen to a level of concern',
          key_fields: ['clinicalStatus', 'verificationStatus', 'code', 'severity', 'onset'],
          relationships: ['subject (Patient)', 'encounter', 'asserter'],
          use_cases: ['Diagnosis tracking', 'Problem lists', 'Disease management'],
        },
        {
          name: 'MedicationRequest',
          description: 'An order or request for both supply of the medication and the instructions for administration',
          key_fields: ['status', 'intent', 'medication', 'dosageInstruction', 'dispenseRequest'],
          relationships: ['subject (Patient)', 'encounter', 'requester'],
          use_cases: ['Prescription management', 'Medication orders', 'Drug utilization'],
        },
      ];

      for (const resource of fhirResources) {
        const content = `
FHIR Resource: ${resource.name}

Description: ${resource.description}

Key Fields:
${resource.key_fields.map(f => `- ${f}`).join('\n')}

Relationships:
${resource.relationships.map(r => `- ${r}`).join('\n')}

Common Use Cases:
${resource.use_cases.map(u => `- ${u}`).join('\n')}

Query Patterns:
- Get all ${resource.name} resources: SELECT * FROM fhir_current WHERE resource_type = '${resource.name}'
- Get by patient: SELECT * FROM fhir_current WHERE resource_type = '${resource.name}' AND JSONExtractString(resource, 'subject.reference') = 'Patient/{id}'
- Filter by status: SELECT * FROM fhir_current WHERE resource_type = '${resource.name}' AND status = '{status}'
`;

        const doc = new Document({
          text: content,
          id_: `medical_knowledge_fhir_${resource.name}`,
          metadata: {
            source: 'medical_knowledge',
            type: 'fhir_resource_guide',
            resourceType: resource.name,
            category: 'fhir_documentation',
            lastUpdated: new Date().toISOString(),
            tags: ['fhir', 'medical', resource.name.toLowerCase()],
          } as DocumentMetadata,
        });
        documents.push(doc);
      }

      // Add medical terminology documents
      const terminologies = [
        {
          name: 'ICD-10 Codes',
          description: 'International Classification of Diseases, 10th Revision - used for diagnosis coding',
          examples: ['E11 - Type 2 diabetes mellitus', 'I10 - Essential hypertension', 'J44 - COPD'],
          usage: 'Used in Condition.code for diagnosis documentation',
        },
        {
          name: 'LOINC Codes',
          description: 'Logical Observation Identifiers Names and Codes - used for lab tests and clinical observations',
          examples: ['2160-0 - Creatinine', '718-7 - Hemoglobin', '2339-0 - Glucose'],
          usage: 'Used in Observation.code for lab results and measurements',
        },
        {
          name: 'SNOMED CT',
          description: 'Systematized Nomenclature of Medicine Clinical Terms - comprehensive clinical terminology',
          examples: ['386661006 - Fever', '271737000 - Anemia', '73211009 - Diabetes mellitus'],
          usage: 'Used across multiple resources for clinical concepts',
        },
      ];

      for (const terminology of terminologies) {
        const content = `
Medical Terminology: ${terminology.name}

Description: ${terminology.description}

Example Codes:
${terminology.examples.map(e => `- ${e}`).join('\n')}

Usage in FHIR: ${terminology.usage}

Query Examples:
- Find by code: JSONExtractString(resource, 'code.coding[0].code') = '{code}'
- Search by display: JSONExtractString(resource, 'code.coding[0].display') LIKE '%{term}%'
`;

        const doc = new Document({
          text: content,
          id_: `medical_knowledge_terminology_${terminology.name.replace(/\s+/g, '_')}`,
          metadata: {
            source: 'medical_knowledge',
            type: 'medical_terminology',
            category: 'clinical_codes',
            lastUpdated: new Date().toISOString(),
            tags: ['terminology', 'codes', terminology.name.toLowerCase()],
          } as DocumentMetadata,
        });
        documents.push(doc);
      }

      logger.info('Loaded medical knowledge documents', {
        count: documents.length,
      });

      return documents;
    } catch (error) {
      logger.error('Failed to load medical knowledge', {
        error: error.message,
      });
      throw error;
    }
  }

  /**
   * Load query patterns and examples
   */
  async loadQueryPatterns(): Promise<Document[]> {
    try {
      const patterns = [
        {
          name: 'Patient Demographics Query',
          query: 'Show me all patients over 65 with diabetes',
          sql: `
SELECT 
  JSONExtractString(p.resource, 'id') as patient_id,
  JSONExtractString(p.resource, 'name[0].given[0]') as first_name,
  JSONExtractString(p.resource, 'name[0].family') as last_name,
  JSONExtractString(p.resource, 'birthDate') as birth_date,
  JSONExtractString(c.resource, 'code.text') as condition
FROM fhir_current p
JOIN fhir_current c ON JSONExtractString(c.resource, 'subject.reference') = concat('Patient/', JSONExtractString(p.resource, 'id'))
WHERE p.resource_type = 'Patient'
  AND c.resource_type = 'Condition'
  AND toYear(now()) - toYear(parseDateTime64BestEffort(JSONExtractString(p.resource, 'birthDate'))) > 65
  AND (JSONExtractString(c.resource, 'code.text') LIKE '%diabetes%' 
       OR JSONExtractString(c.resource, 'code.coding[0].code') LIKE 'E11%')`,
          explanation: 'Joins Patient and Condition resources, calculates age, and filters by diagnosis',
        },
        {
          name: 'Lab Results Trend',
          query: 'Show glucose levels for patient X over the last month',
          sql: `
SELECT 
  JSONExtractString(resource, 'effectiveDateTime') as test_date,
  JSONExtractFloat(resource, 'valueQuantity.value') as glucose_value,
  JSONExtractString(resource, 'valueQuantity.unit') as unit,
  JSONExtractString(resource, 'interpretation[0].text') as interpretation
FROM fhir_current
WHERE resource_type = 'Observation'
  AND JSONExtractString(resource, 'code.coding[0].code') = '2339-0' -- Glucose code
  AND JSONExtractString(resource, 'subject.reference') = 'Patient/{patient_id}'
  AND parseDateTime64BestEffort(JSONExtractString(resource, 'effectiveDateTime')) >= now() - INTERVAL 1 MONTH
ORDER BY test_date DESC`,
          explanation: 'Filters Observations by LOINC code for glucose and time range',
        },
        {
          name: 'Department Utilization',
          query: 'Show current bed occupancy by department',
          sql: `
SELECT 
  JSONExtractString(resource, 'location[0].location.display') as department,
  count(*) as occupied_beds,
  sum(CASE WHEN JSONExtractString(resource, 'class.code') = 'IMP' THEN 1 ELSE 0 END) as inpatient_count,
  sum(CASE WHEN JSONExtractString(resource, 'class.code') = 'EMER' THEN 1 ELSE 0 END) as emergency_count
FROM fhir_current
WHERE resource_type = 'Encounter'
  AND status = 'in-progress'
GROUP BY department
ORDER BY occupied_beds DESC`,
          explanation: 'Groups active encounters by location and class',
        },
      ];

      const documents: Document[] = patterns.map((pattern, index) => {
        const content = `
Query Pattern: ${pattern.name}

Natural Language Query: "${pattern.query}"

SQL Query:
${pattern.sql}

Explanation: ${pattern.explanation}

Key Concepts:
- Resource filtering by type
- JSON extraction functions
- Temporal filtering
- Joining resources by reference
- Aggregation and grouping
`;

        return new Document({
          text: content,
          id_: `query_pattern_${index}`,
          metadata: {
            source: 'query_patterns',
            type: 'sql_example',
            patternName: pattern.name,
            category: 'query_examples',
            lastUpdated: new Date().toISOString(),
            tags: ['sql', 'clickhouse', 'fhir', 'examples'],
          } as DocumentMetadata,
        });
      });

      logger.info('Loaded query pattern documents', {
        count: documents.length,
      });

      return documents;
    } catch (error) {
      logger.error('Failed to load query patterns', {
        error: error.message,
      });
      throw error;
    }
  }

  /**
   * Load all documents into respective vector stores
   */
  async loadAllDocuments(): Promise<{
    fhirMetadata: Document[];
    clickhouseSchema: Document[];
    medicalKnowledge: Document[];
    queryPatterns: Document[];
  }> {
    const [fhirMetadata, clickhouseSchema, medicalKnowledge, queryPatterns] = await Promise.all([
      this.loadFHIRMetadata(),
      this.loadClickHouseSchema(),
      this.loadMedicalKnowledge(),
      this.loadQueryPatterns(),
    ]);

    return {
      fhirMetadata,
      clickhouseSchema,
      medicalKnowledge,
      queryPatterns,
    };
  }

  private formatFHIRMetadataContent(row: any): string {
    return `
FHIR Field: ${row.resource_type}.${row.fhir_element}
Display Name: ${row.display_name}
Description: ${row.description || 'No description available'}
Data Type: ${row.data_type}${row.is_array ? ' (Array)' : ''}
Required: ${row.is_required ? 'Yes' : 'No'}

Example Values: ${row.example_values || 'None'}
Common Codes: ${row.common_codes || 'None'}
Use Cases: ${row.use_cases || 'None'}

JSON Path: resource.${row.fhir_element}
SQL Extract: JSONExtractString(resource, '${row.fhir_element}')
`;
  }

  private formatTableSchemaContent(table: any, columns: any[]): string {
    const columnInfo = columns.map(col => 
      `  - ${col.name}: ${col.type}${col.comment ? ` (${col.comment})` : ''}`
    ).join('\n');

    return `
ClickHouse Table: ${table.table}
Engine: ${table.engine}
Partition Key: ${table.partition_key || 'None'}
Sorting Key: ${table.sorting_key || 'None'}
Primary Key: ${table.primary_key || 'None'}

Columns:
${columnInfo}

Query Examples:
- SELECT * FROM nexuscare_analytics.${table.table} LIMIT 10
- SELECT count(*) FROM nexuscare_analytics.${table.table}
${table.partition_key ? `- SELECT * FROM nexuscare_analytics.${table.table} WHERE ${table.partition_key} = 'value'` : ''}
`;
  }
}