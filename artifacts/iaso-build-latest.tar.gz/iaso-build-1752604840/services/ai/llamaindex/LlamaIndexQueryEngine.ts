import {
  VectorStoreIndex,
  QueryEngine,
  ResponseSynthesizer,
  SimpleDirectoryReader,
  Settings,
  Document,
  SubQuestionQueryEngine,
  QueryEngineTool,
  ToolMetadata,
  RouterQueryEngine,
  LLMSingleSelector,
} from 'llamaindex';

import { healthcareLogger } from '../../monitoring/StructuredLogger';

import { VectorStoreManager, VectorStoreFactory } from './VectorStoreManager';
import { ClickHouseTool } from './ClickHouseTool';
import { RemoteEmbeddings, createEmbedding } from './RemoteEmbeddings';

const logger = healthcareLogger;

export interface QueryContext {
  sessionId: string;
  userId: string;
  tenantId: string;
  previousQueries?: string[];
  filters?: Record<string, any>;
}

export class LlamaIndexQueryEngine {
  private fhirIndex: VectorStoreIndex | null = null;
  private schemaIndex: VectorStoreIndex | null = null;
  private knowledgeIndex: VectorStoreIndex | null = null;
  private patternIndex: VectorStoreIndex | null = null;
  private queryEngine: QueryEngine | null = null;
  
  constructor() {
    // TODO: Configure your preferred LLM here
    // Settings.llm = new YourLLM({});

    // Configure Remote Embeddings
    Settings.embedModel = createEmbedding('general');
  }

  async initialize(): Promise<void> {
    try {
      logger.info('Initializing LlamaIndex Query Engine');

      // Get vector store indices
      const fhirStore = await VectorStoreFactory.getOrCreate('fhir_resources');
      const schemaStore = await VectorStoreFactory.getOrCreate('clickhouse_schema');
      const knowledgeStore = await VectorStoreFactory.getOrCreate('medical_knowledge');
      const patternStore = await VectorStoreFactory.getOrCreate('query_patterns');

      this.fhirIndex = fhirStore.getIndex();
      this.schemaIndex = schemaStore.getIndex();
      this.knowledgeIndex = knowledgeStore.getIndex();
      this.patternIndex = patternStore.getIndex();

      // Create query engines for each index
      const fhirQueryEngine = this.fhirIndex!.asQueryEngine({
        similarityTopK: 3,
      });

      const schemaQueryEngine = this.schemaIndex!.asQueryEngine({
        similarityTopK: 3,
      });

      const knowledgeQueryEngine = this.knowledgeIndex!.asQueryEngine({
        similarityTopK: 3,
      });

      const patternQueryEngine = this.patternIndex!.asQueryEngine({
        similarityTopK: 5,
      });

      // Create tools for each query engine
      const queryEngineTools: QueryEngineTool[] = [
        new QueryEngineTool({
          queryEngine: fhirQueryEngine,
          metadata: new ToolMetadata({
            name: 'fhir_metadata_search',
            description: 'Search FHIR resource metadata to understand field definitions, data types, and relationships',
          }),
        }),
        new QueryEngineTool({
          queryEngine: schemaQueryEngine,
          metadata: new ToolMetadata({
            name: 'clickhouse_schema_search',
            description: 'Search ClickHouse table schemas to understand database structure and available tables',
          }),
        }),
        new QueryEngineTool({
          queryEngine: knowledgeQueryEngine,
          metadata: new ToolMetadata({
            name: 'medical_knowledge_search',
            description: 'Search medical knowledge base for FHIR resource descriptions and medical terminology',
          }),
        }),
        new QueryEngineTool({
          queryEngine: patternQueryEngine,
          metadata: new ToolMetadata({
            name: 'query_pattern_search',
            description: 'Search for SQL query patterns and examples for similar healthcare analytics queries',
          }),
        }),
      ];

      // Add custom tools
      const clickhouseTool = new ClickHouseTool();

      // Create a router query engine that can choose the right tool
      this.queryEngine = new RouterQueryEngine({
        selector: new LLMSingleSelector(),
        queryEngineTools: [
          ...queryEngineTools,
          new QueryEngineTool({
            queryEngine: await this.createSubQuestionEngine(queryEngineTools),
            metadata: new ToolMetadata({
              name: 'multi_step_reasoning',
              description: 'Break down complex healthcare analytics questions into sub-questions and combine results',
            }),
          }),
        ],
        llm: Settings.llm,
      });

      logger.info('LlamaIndex Query Engine initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize LlamaIndex Query Engine', {
        error: error.message,
      });
      throw error;
    }
  }

  async query(
    query: string,
    context: QueryContext
  ): Promise<{
    response: string;
    sql?: string;
    data?: any[];
    sources?: any[];
    confidence: number;
  }> {
    if (!this.queryEngine) {
      throw new Error('Query engine not initialized');
    }

    try {
      logger.info('Processing query with LlamaIndex', {
        query,
        sessionId: context.sessionId,
        userId: context.userId,
      });

      // First, try to understand the query intent and gather relevant context
      const enhancedQuery = await this.enhanceQueryWithContext(query, context);

      // Execute the query
      const response = await this.queryEngine.query({
        query: enhancedQuery,
      });

      // Extract SQL if generated
      const sqlMatch = response.toString().match(/```sql\n([\s\S]*?)\n```/);
      const sql = sqlMatch ? sqlMatch[1] : undefined;

      // If SQL was generated, execute it
      let data: any[] = [];
      if (sql) {
        const clickhouseTool = new ClickHouseTool();
        const result = await clickhouseTool.executeQuery(sql, context.tenantId);
        data = result.data;
      }

      // Calculate confidence based on sources
      const confidence = this.calculateConfidence(response);

      return {
        response: response.toString(),
        sql,
        data,
        sources: response.sourceNodes?.map(node => ({
          text: node.node.text,
          score: node.score,
          metadata: node.node.metadata,
        })),
        confidence,
      };
    } catch (error) {
      logger.error('Query processing failed', {
        error: error.message,
        query,
        context,
      });
      throw error;
    }
  }

  async generateSQL(
    query: string,
    context: QueryContext
  ): Promise<{
    sql: string;
    explanation: string;
    confidence: number;
  }> {
    try {
      // Search for similar query patterns
      const patterns = await this.searchQueryPatterns(query);
      
      // Search for relevant FHIR metadata
      const metadata = await this.searchFHIRMetadata(query);
      
      // Search for schema information
      const schema = await this.searchClickHouseSchema(query);

      // Build comprehensive prompt for SQL generation
      const prompt = this.buildSQLGenerationPrompt(query, patterns, metadata, schema, context);

      // Use SQLCoder tool
      const sqlCoderTool = new SQLCoderTool();
      const result = await sqlCoderTool.generateSQL(prompt, context);

      return {
        sql: result.sql,
        explanation: result.explanation || 'SQL query generated based on healthcare analytics patterns',
        confidence: result.confidence || 0.8,
      };
    } catch (error) {
      logger.error('SQL generation failed', {
        error: error.message,
        query,
      });
      throw error;
    }
  }

  private async enhanceQueryWithContext(
    query: string,
    context: QueryContext
  ): Promise<string> {
    let enhanced = query;

    // Add tenant context
    enhanced += `\n\nContext: Tenant ID is '${context.tenantId}'.`;

    // Add previous query context if available
    if (context.previousQueries && context.previousQueries.length > 0) {
      enhanced += `\n\nPrevious queries in this session: ${context.previousQueries.join(', ')}`;
    }

    // Add any filters
    if (context.filters) {
      enhanced += `\n\nApplied filters: ${JSON.stringify(context.filters)}`;
    }

    return enhanced;
  }

  private async searchQueryPatterns(query: string): Promise<any> {
    if (!this.patternIndex) return null;

    const queryEngine = this.patternIndex.asQueryEngine({
      similarityTopK: 3,
    });

    const response = await queryEngine.query({
      query: `Find SQL query patterns similar to: ${query}`,
    });

    return response;
  }

  private async searchFHIRMetadata(query: string): Promise<any> {
    if (!this.fhirIndex) return null;

    const queryEngine = this.fhirIndex.asQueryEngine({
      similarityTopK: 5,
    });

    const response = await queryEngine.query({
      query: `Find FHIR resource fields and metadata relevant to: ${query}`,
    });

    return response;
  }

  private async searchClickHouseSchema(query: string): Promise<any> {
    if (!this.schemaIndex) return null;

    const queryEngine = this.schemaIndex.asQueryEngine({
      similarityTopK: 3,
    });

    const response = await queryEngine.query({
      query: `Find ClickHouse tables and columns for: ${query}`,
    });

    return response;
  }

  private buildSQLGenerationPrompt(
    query: string,
    patterns: any,
    metadata: any,
    schema: any,
    context: QueryContext
  ): string {
    return `
Generate a ClickHouse SQL query for the following healthcare analytics question:

Question: ${query}

Database Context:
- Tenant ID: ${context.tenantId}
- Main table: nexuscare_analytics.fhir_current (view with FINAL)
- Resource data is stored as JSON in the 'resource' column
- Use JSONExtractString, JSONExtractFloat, etc. for field access

Similar Query Patterns:
${patterns ? patterns.toString() : 'No similar patterns found'}

Relevant FHIR Metadata:
${metadata ? metadata.toString() : 'No specific metadata found'}

ClickHouse Schema Information:
${schema ? schema.toString() : 'No specific schema info found'}

Requirements:
1. Always filter by tenant_id = '${context.tenantId}'
2. Use proper JSON extraction functions
3. Handle date/time fields with parseDateTime64BestEffort
4. Join resources using reference fields (e.g., subject.reference)
5. Use appropriate aggregations for analytics queries

Generate only the SQL query without any explanation.
`;
  }

  private calculateConfidence(response: any): number {
    if (!response.sourceNodes || response.sourceNodes.length === 0) {
      return 0.5;
    }

    // Calculate average score from source nodes
    const avgScore = response.sourceNodes.reduce((sum: number, node: any) => 
      sum + (node.score || 0), 0
    ) / response.sourceNodes.length;

    // Convert to 0-1 range
    return Math.min(Math.max(avgScore, 0), 1);
  }

  private async createSubQuestionEngine(
    queryEngineTools: QueryEngineTool[]
  ): Promise<SubQuestionQueryEngine> {
    return new SubQuestionQueryEngine({
      queryEngineTools,
    });
  }

  async updateConversationMemory(
    sessionId: string,
    query: string,
    response: string
  ): Promise<void> {
    try {
      const memoryStore = await VectorStoreFactory.getOrCreate('conversation_memory');
      
      const doc = new Document({
        text: `Query: ${query}\n\nResponse: ${response}`,
        id_: `conversation_${sessionId}_${Date.now()}`,
        metadata: {
          sessionId,
          timestamp: new Date().toISOString(),
          type: 'conversation_turn',
        },
      });

      await memoryStore.addDocuments([doc]);
    } catch (error) {
      logger.error('Failed to update conversation memory', {
        error: error.message,
        sessionId,
      });
    }
  }
}