/**
 * Embeddings Service
 * 
 * Generates embeddings for clinical text using all-MiniLM-L6-v2
 * Provides efficient text-to-vector conversion for RAG system
 */

// Try to import transformers, fall back to stub if not available
let pipeline: any, Pipeline: any;
try {
  const transformers = require('@xenova/transformers');
  pipeline = transformers.pipeline;
  Pipeline = transformers.Pipeline;
} catch (error) {
  const stub = require('./stubs/TransformersStub');
  pipeline = stub.pipeline;
  Pipeline = stub.Pipeline;
}
import { logger } from '../../utils/logger';

export interface EmbeddingOptions {
  normalize?: boolean;
  pooling?: 'mean' | 'cls' | 'max';
  batchSize?: number;
}

export interface EmbeddingResult {
  embedding: number[];
  tokens: number;
  processingTimeMs: number;
}

export class EmbeddingsService {
  private model: any | null = null;
  private modelName = 'Xenova/all-MiniLM-L6-v2';
  private initialized = false;
  private initPromise: Promise<void> | null = null;

  /**
   * Initialize the embeddings model
   */
  async initialize(): Promise<void> {
    if (this.initialized) return;
    
    // Prevent multiple initialization attempts
    if (this.initPromise) {
      await this.initPromise;
      return;
    }

    this.initPromise = this._initialize();
    await this.initPromise;
  }

  private async _initialize(): Promise<void> {
    try {
      logger.info('Initializing embeddings model...');
      
      // Load the sentence embeddings pipeline
      this.model = await pipeline('feature-extraction', this.modelName, {
        quantized: true // Use quantized model for better performance
      });

      this.initialized = true;
      logger.info(`Embeddings model ${this.modelName} loaded successfully`);
    } catch (error) {
      logger.error('Failed to initialize embeddings model', error as Error);
      this.initPromise = null;
      throw error;
    }
  }

  /**
   * Generate embedding for a single text
   */
  async generateEmbedding(
    text: string,
    options: EmbeddingOptions = {}
  ): Promise<EmbeddingResult> {
    await this.initialize();

    const {
      normalize = true,
      pooling = 'mean'
    } = options;

    const startTime = Date.now();

    try {
      if (!this.model) {
        throw new Error('Model not initialized');
      }

      // Generate embeddings
      const output = await this.model(text, {
        pooling,
        normalize
      });

      // Convert to array
      const embedding = Array.from(output.data) as number[];

      const processingTimeMs = Date.now() - startTime;

      return {
        embedding,
        tokens: text.split(/\s+/).length, // Approximate token count
        processingTimeMs
      };

    } catch (error) {
      logger.error('Failed to generate embedding', error as Error);
      throw error;
    }
  }

  /**
   * Generate embeddings for multiple texts in batch
   */
  async generateBatchEmbeddings(
    texts: string[],
    options: EmbeddingOptions = {}
  ): Promise<EmbeddingResult[]> {
    await this.initialize();

    const {
      normalize = true,
      pooling = 'mean',
      batchSize = 32
    } = options;

    const results: EmbeddingResult[] = [];
    const startTime = Date.now();

    try {
      if (!this.model) {
        throw new Error('Model not initialized');
      }

      // Process in batches
      for (let i = 0; i < texts.length; i += batchSize) {
        const batch = texts.slice(i, i + batchSize);
        const batchStartTime = Date.now();

        // Generate embeddings for batch
        const outputs = await Promise.all(
          batch.map(text => this.model!(text, { pooling, normalize }))
        );

        // Convert outputs to embeddings
        const batchResults = outputs.map((output, idx) => ({
          embedding: Array.from(output.data) as number[],
          tokens: batch[idx].split(/\s+/).length,
          processingTimeMs: Date.now() - batchStartTime
        }));

        results.push(...batchResults);
      }

      logger.info(`Generated ${texts.length} embeddings in ${Date.now() - startTime}ms`);
      return results;

    } catch (error) {
      logger.error('Failed to generate batch embeddings', error as Error);
      throw error;
    }
  }

  /**
   * Calculate cosine similarity between two embeddings
   */
  cosineSimilarity(embedding1: number[], embedding2: number[]): number {
    if (embedding1.length !== embedding2.length) {
      throw new Error('Embeddings must have the same dimension');
    }

    let dotProduct = 0;
    let norm1 = 0;
    let norm2 = 0;

    for (let i = 0; i < embedding1.length; i++) {
      dotProduct += embedding1[i] * embedding2[i];
      norm1 += embedding1[i] * embedding1[i];
      norm2 += embedding2[i] * embedding2[i];
    }

    norm1 = Math.sqrt(norm1);
    norm2 = Math.sqrt(norm2);

    if (norm1 === 0 || norm2 === 0) {
      return 0;
    }

    return dotProduct / (norm1 * norm2);
  }

  /**
   * Find most similar texts from a list
   */
  async findSimilar(
    query: string,
    candidates: Array<{ id: string; text: string }>,
    topK: number = 5,
    threshold: number = 0.5
  ): Promise<Array<{ id: string; text: string; similarity: number }>> {
    // Generate query embedding
    const queryResult = await this.generateEmbedding(query);
    const queryEmbedding = queryResult.embedding;

    // Generate candidate embeddings
    const candidateTexts = candidates.map(c => c.text);
    const candidateResults = await this.generateBatchEmbeddings(candidateTexts);

    // Calculate similarities
    const similarities = candidateResults.map((result, idx) => ({
      id: candidates[idx].id,
      text: candidates[idx].text,
      similarity: this.cosineSimilarity(queryEmbedding, result.embedding)
    }));

    // Sort by similarity and filter by threshold
    return similarities
      .filter(s => s.similarity >= threshold)
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, topK);
  }

  /**
   * Semantic search with re-ranking
   */
  async semanticSearch(
    query: string,
    documents: Array<{ id: string; content: string; metadata?: any }>,
    options: {
      topK?: number;
      threshold?: number;
      rerank?: boolean;
      contextWindow?: number;
    } = {}
  ): Promise<Array<{
    id: string;
    content: string;
    score: number;
    metadata?: any;
    highlights?: string[];
  }>> {
    const {
      topK = 10,
      threshold = 0.5,
      rerank = true,
      contextWindow = 50
    } = options;

    try {
      // Initial retrieval
      const candidates = documents.map(doc => ({
        id: doc.id,
        text: doc.content
      }));

      const initialResults = await this.findSimilar(
        query,
        candidates,
        rerank ? topK * 2 : topK, // Get more results if re-ranking
        threshold
      );

      // Map back to full documents
      let results = initialResults.map(result => {
        const doc = documents.find(d => d.id === result.id)!;
        return {
          id: doc.id,
          content: doc.content,
          score: result.similarity,
          metadata: doc.metadata
        };
      });

      // Re-rank if requested
      if (rerank && results.length > 0) {
        results = await this.rerankResults(query, results, contextWindow);
      }

      // Extract highlights
      results = results.map(result => ({
        ...result,
        highlights: this.extractHighlights(query, result.content, contextWindow)
      }));

      return results.slice(0, topK);

    } catch (error) {
      logger.error('Semantic search failed', error as Error);
      throw error;
    }
  }

  /**
   * Re-rank results using more detailed analysis
   */
  private async rerankResults(
    query: string,
    results: Array<{ id: string; content: string; score: number; metadata?: any }>,
    contextWindow: number
  ): Promise<Array<{ id: string; content: string; score: number; metadata?: any }>> {
    // Extract query terms
    const queryTerms = query.toLowerCase().split(/\s+/)
      .filter(term => term.length > 2);

    // Re-score based on term frequency and position
    const rerankedResults = results.map(result => {
      const contentLower = result.content.toLowerCase();
      let boostScore = 0;

      // Check for exact phrase match
      if (contentLower.includes(query.toLowerCase())) {
        boostScore += 0.2;
      }

      // Check for all query terms
      const termMatches = queryTerms.filter(term => 
        contentLower.includes(term)
      ).length;
      boostScore += (termMatches / queryTerms.length) * 0.1;

      // Check for terms in close proximity
      const proximityBoost = this.calculateProximityScore(
        queryTerms,
        contentLower,
        contextWindow
      );
      boostScore += proximityBoost * 0.1;

      return {
        ...result,
        score: result.score + boostScore
      };
    });

    // Re-sort by new scores
    return rerankedResults.sort((a, b) => b.score - a.score);
  }

  /**
   * Calculate proximity score for query terms
   */
  private calculateProximityScore(
    queryTerms: string[],
    content: string,
    windowSize: number
  ): number {
    if (queryTerms.length < 2) return 0;

    const words = content.split(/\s+/);
    let proximityScore = 0;

    for (let i = 0; i < words.length; i++) {
      if (queryTerms.includes(words[i])) {
        // Check for other query terms within window
        const start = Math.max(0, i - windowSize);
        const end = Math.min(words.length, i + windowSize + 1);
        const window = words.slice(start, end);
        
        const matchCount = window.filter(w => 
          queryTerms.includes(w) && w !== words[i]
        ).length;
        
        proximityScore += matchCount / queryTerms.length;
      }
    }

    return Math.min(1, proximityScore / queryTerms.length);
  }

  /**
   * Extract text highlights around matching terms
   */
  private extractHighlights(
    query: string,
    content: string,
    contextWindow: number
  ): string[] {
    const highlights: string[] = [];
    const queryTerms = query.toLowerCase().split(/\s+/)
      .filter(term => term.length > 2);

    const words = content.split(/\s+/);
    const wordsLower = words.map(w => w.toLowerCase());

    for (let i = 0; i < wordsLower.length; i++) {
      if (queryTerms.some(term => wordsLower[i].includes(term))) {
        const start = Math.max(0, i - contextWindow);
        const end = Math.min(words.length, i + contextWindow + 1);
        const highlight = words.slice(start, end).join(' ');
        
        if (!highlights.some(h => h.includes(highlight))) {
          highlights.push(
            (start > 0 ? '...' : '') +
            highlight +
            (end < words.length ? '...' : '')
          );
        }
      }
    }

    return highlights.slice(0, 3); // Return top 3 highlights
  }

  /**
   * Generate embeddings for clinical concepts
   */
  async generateClinicalEmbeddings(
    concepts: Array<{
      concept: string;
      type: 'condition' | 'medication' | 'procedure' | 'lab';
      code?: string;
    }>
  ): Promise<Map<string, number[]>> {
    const embeddings = new Map<string, number[]>();

    // Create enriched text for each concept
    const enrichedTexts = concepts.map(c => {
      let text = c.concept;
      if (c.type) text += ` [${c.type}]`;
      if (c.code) text += ` (${c.code})`;
      return text;
    });

    // Generate embeddings
    const results = await this.generateBatchEmbeddings(enrichedTexts);

    // Map results
    concepts.forEach((concept, idx) => {
      const key = concept.code || concept.concept;
      embeddings.set(key, results[idx].embedding);
    });

    return embeddings;
  }

  /**
   * Check if model is ready
   */
  isReady(): boolean {
    return this.initialized && this.model !== null;
  }

  /**
   * Get model information
   */
  getModelInfo(): {
    name: string;
    ready: boolean;
    embeddingDimension: number;
  } {
    return {
      name: this.modelName,
      ready: this.isReady(),
      embeddingDimension: 384 // all-MiniLM-L6-v2 produces 384-dimensional embeddings
    };
  }
}

// Export singleton instance
export const embeddingsService = new EmbeddingsService();