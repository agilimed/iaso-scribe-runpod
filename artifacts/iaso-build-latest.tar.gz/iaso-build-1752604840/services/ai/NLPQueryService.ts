/**
 * NLP Query Service
 * 
 * Flexible natural language query processing that supports:
 * - Multiple AI models (Qwen3, GPT-4, Claude, etc.)
 * - MCP integration (optional)
 * - Direct SQL generation (fallback)
 */

import { logger } from '../../utils/logger';
import { getClickHouseClient } from '../clickhouse';

import { AIModelFactory, AIModelAdapter, AIModelConfig } from './AIModelAdapter';
import { getClickHouseMCPIntegration, ClickHouseMCPIntegration } from './ClickHouseMCPIntegration';
import { NLPQueryParser, NLPQuery, ParsedQuery } from './NLPQueryParser';

export interface NLPServiceConfig {
  // AI Model Configuration
  aiModel: {
    provider: 'gpt4' | 'claude' | 'gemini' | 'custom';
    endpoint?: string;
    apiKey?: string;
    model?: string;
    temperature?: number;
    maxTokens?: number;
  };
  
  // MCP Configuration
  mcp: {
    enabled: boolean;
    transport?: 'stdio' | 'http' | 'streamable-http' | 'sse';
    endpoint?: string;
  };
  
  // Query Processing Options
  processing: {
    useCache?: boolean;
    cacheTimeout?: number;
    maxRetries?: number;
    fallbackToDirectSQL?: boolean;
  };
}

export interface QueryExecutionResult {
  success: boolean;
  data?: any;
  sql?: string;
  explanation?: string;
  executionTime?: number;
  method: 'mcp' | 'direct' | 'fallback';
  error?: string;
  warnings?: string[];
}

export class NLPQueryService {
  private config: NLPServiceConfig;
  private aiAdapter: AIModelAdapter;
  private mcpIntegration?: ClickHouseMCPIntegration;
  private nlpParser: NLPQueryParser;
  private initialized: boolean = false;

  constructor(config?: Partial<NLPServiceConfig>) {
    // Default configuration
    this.config = {
      aiModel: {
        provider: 'qwen3',
        endpoint: process.env.AI_SERVICE_URL || 'http://localhost:8002',
        temperature: 0.3,
        maxTokens: 1000,
        ...config?.aiModel
      },
      mcp: {
        enabled: process.env.MCP_ENABLED === 'true' || false,
        transport: 'http',
        endpoint: process.env.MCP_SERVER_ENDPOINT || 'http://localhost:8003',
        ...config?.mcp
      },
      processing: {
        useCache: true,
        cacheTimeout: 300, // 5 minutes
        maxRetries: 2,
        fallbackToDirectSQL: true,
        ...config?.processing
      }
    };

    // Initialize AI adapter based on configuration
    this.aiAdapter = AIModelFactory.createAdapter({
      provider: this.config.aiModel.provider,
      endpoint: this.config.aiModel.endpoint!,
      apiKey: this.config.aiModel.apiKey,
      model: this.config.aiModel.model,
      temperature: this.config.aiModel.temperature,
      maxTokens: this.config.aiModel.maxTokens
    });

    // Initialize NLP parser (for fallback)
    this.nlpParser = new NLPQueryParser();

    logger.info('NLP Query Service initialized', {
      aiProvider: this.config.aiModel.provider,
      mcpEnabled: this.config.mcp.enabled
    });
  }

  /**
   * Initialize the service
   */
  async initialize(): Promise<void> {
    if (this.initialized) {
      return;
    }

    try {
      // Initialize MCP if enabled
      if (this.config.mcp.enabled) {
        const capabilities = this.aiAdapter.getCapabilities();
        
        if (capabilities.supportsMCP) {
          this.mcpIntegration = getClickHouseMCPIntegration();
          await this.mcpIntegration.initialize();
          
          // Register MCP tool with AI adapter
          const mcpTool = this.mcpIntegration.getToolForNLP();
          await this.aiAdapter.registerTools([mcpTool]);
          
          logger.info('MCP integration initialized successfully');
        } else {
          logger.warn(`AI provider ${this.config.aiModel.provider} does not support MCP, falling back to direct SQL`);
          this.config.mcp.enabled = false;
        }
      }

      this.initialized = true;
      logger.info('NLP Query Service initialized successfully');

    } catch (error) {
      logger.error('Failed to initialize NLP Query Service', error as Error);
      
      // If MCP initialization fails, disable it and continue
      if (this.config.mcp.enabled) {
        logger.warn('MCP initialization failed, disabling MCP');
        this.config.mcp.enabled = false;
      }
      
      this.initialized = true;
    }
  }

  /**
   * Process a natural language query
   */
  async processQuery(query: string, context?: any): Promise<QueryExecutionResult> {
    await this.initialize();

    const startTime = Date.now();
    
    try {
      // Try MCP first if enabled
      if (this.config.mcp.enabled && this.mcpIntegration) {
        try {
          const result = await this.processMCPQuery(query, context);
          if (result.success) {
            return result;
          }
          logger.warn('MCP query failed, falling back to direct SQL');
        } catch (error) {
          logger.error('MCP query error', error as Error);
        }
      }

      // Fall back to direct SQL generation
      if (this.config.processing.fallbackToDirectSQL) {
        return await this.processDirectQuery(query, context);
      }

      return {
        success: false,
        method: 'mcp',
        error: 'Query processing failed and fallback is disabled'
      };

    } catch (error) {
      logger.error('Query processing failed', error as Error);
      return {
        success: false,
        method: 'direct',
        error: (error as Error).message,
        executionTime: Date.now() - startTime
      };
    }
  }

  /**
   * Process query using MCP
   */
  private async processMCPQuery(query: string, context?: any): Promise<QueryExecutionResult> {
    const startTime = Date.now();

    try {
      // Use AI model with MCP tool
      const response = await this.aiAdapter.query({
        prompt: query,
        systemPrompt: `You are a healthcare analytics assistant with access to a ClickHouse database.
Use the clickhouse_query tool to answer questions about healthcare data.
Context: ${JSON.stringify(context || {})}`,
        tools: [this.mcpIntegration!.getToolForNLP()]
      });

      // Check if tool was called
      if (response.toolCalls && response.toolCalls.length > 0) {
        const toolCall = response.toolCalls[0];
        const result = toolCall.result || await this.mcpIntegration!.getToolForNLP().execute(toolCall.arguments);

        return {
          success: result.success,
          data: result.result,
          sql: result.sql,
          explanation: response.response,
          executionTime: Date.now() - startTime,
          method: 'mcp',
          error: result.error
        };
      }

      // No tool call, try to extract SQL from response
      const sql = await this.extractSQLFromResponse(response.response);
      if (sql) {
        const result = await this.executeSQLDirectly(sql, context?.tenantId);
        return {
          success: result.success,
          data: result.data,
          sql: sql,
          explanation: response.response,
          executionTime: Date.now() - startTime,
          method: 'mcp',
          error: result.error
        };
      }

      return {
        success: false,
        method: 'mcp',
        error: 'No SQL query generated',
        executionTime: Date.now() - startTime
      };

    } catch (error) {
      logger.error('MCP query processing failed', error as Error);
      throw error;
    }
  }

  /**
   * Process query using direct SQL generation
   */
  private async processDirectQuery(query: string, context?: any): Promise<QueryExecutionResult> {
    const startTime = Date.now();

    try {
      // Parse the natural language query
      const nlpQuery: NLPQuery = {
        query,
        context
      };
      const parsedQuery = await this.nlpParser.parseQuery(nlpQuery);

      // Generate SQL
      const sqlTranslation = await this.nlpParser.translateToSQL(parsedQuery);

      // Execute the SQL
      const result = await this.executeSQLDirectly(sqlTranslation.sql, context?.tenantId);

      return {
        success: result.success,
        data: result.data,
        sql: sqlTranslation.sql,
        explanation: sqlTranslation.explanation,
        executionTime: Date.now() - startTime,
        method: 'direct',
        error: result.error,
        warnings: sqlTranslation.warnings
      };

    } catch (error) {
      logger.error('Direct query processing failed', error as Error);
      throw error;
    }
  }

  /**
   * Execute SQL directly on ClickHouse
   */
  private async executeSQLDirectly(sql: string, tenantId?: string): Promise<any> {
    try {
      const client = getClickHouseClient();
      
      // Add tenant filter if provided
      let finalSQL = sql;
      if (tenantId && !sql.toLowerCase().includes('tenant_id')) {
        if (sql.toLowerCase().includes('where')) {
          finalSQL = sql.replace(/where/i, `WHERE tenant_id = '${tenantId}' AND`);
        } else if (sql.toLowerCase().includes('group by')) {
          finalSQL = sql.replace(/group by/i, `WHERE tenant_id = '${tenantId}' GROUP BY`);
        } else {
          finalSQL = sql + ` WHERE tenant_id = '${tenantId}'`;
        }
      }

      const result = await client.query({
        query: finalSQL,
        format: 'JSONEachRow'
      }).toPromise();

      return {
        success: true,
        data: result,
        rowCount: Array.isArray(result) ? result.length : 0
      };

    } catch (error) {
      logger.error('SQL execution failed', error as Error);
      return {
        success: false,
        error: (error as Error).message
      };
    }
  }

  /**
   * Extract SQL from AI response
   */
  private async extractSQLFromResponse(response: string): Promise<string | null> {
    // Look for SQL in code blocks
    const sqlMatch = response.match(/```sql\n([\s\S]*?)\n```/);
    if (sqlMatch) {
      return sqlMatch[1].trim();
    }

    // Look for SELECT statement
    const selectMatch = response.match(/SELECT[\s\S]*?(?:;|$)/i);
    if (selectMatch) {
      return selectMatch[0].trim();
    }

    // Ask AI to extract SQL
    try {
      const extracted = await this.aiAdapter.query({
        prompt: `Extract only the SQL query from this text: "${response}"
Return only the SQL query without any explanation or markdown.`,
      });

      const sql = extracted.response.trim();
      if (sql.toLowerCase().startsWith('select')) {
        return sql;
      }
    } catch (error) {
      logger.warn('Failed to extract SQL from response', error);
    }

    return null;
  }

  /**
   * Update configuration
   */
  updateConfig(config: Partial<NLPServiceConfig>): void {
    this.config = {
      ...this.config,
      ...config,
      aiModel: {
        ...this.config.aiModel,
        ...config.aiModel
      },
      mcp: {
        ...this.config.mcp,
        ...config.mcp
      },
      processing: {
        ...this.config.processing,
        ...config.processing
      }
    };

    // Reinitialize if AI provider changed
    if (config.aiModel?.provider && config.aiModel.provider !== this.config.aiModel.provider) {
      this.aiAdapter = AIModelFactory.createAdapter({
        provider: config.aiModel.provider,
        endpoint: this.config.aiModel.endpoint!,
        apiKey: this.config.aiModel.apiKey,
        model: this.config.aiModel.model,
        temperature: this.config.aiModel.temperature,
        maxTokens: this.config.aiModel.maxTokens
      });
      this.initialized = false;
    }

    logger.info('NLP Query Service configuration updated', this.config);
  }

  /**
   * Get current configuration
   */
  getConfig(): NLPServiceConfig {
    return { ...this.config };
  }

  /**
   * Get service status
   */
  getStatus(): {
    initialized: boolean;
    aiProvider: string;
    mcpEnabled: boolean;
    mcpConnected: boolean;
    capabilities: any;
  } {
    return {
      initialized: this.initialized,
      aiProvider: this.config.aiModel.provider,
      mcpEnabled: this.config.mcp.enabled,
      mcpConnected: this.config.mcp.enabled && !!this.mcpIntegration,
      capabilities: this.aiAdapter.getCapabilities()
    };
  }

  /**
   * Shutdown the service
   */
  async shutdown(): Promise<void> {
    if (this.mcpIntegration) {
      await this.mcpIntegration.shutdown();
    }
    this.initialized = false;
    logger.info('NLP Query Service shutdown');
  }
}

// Singleton instance
let nlpQueryService: NLPQueryService | null = null;

export function getNLPQueryService(config?: Partial<NLPServiceConfig>): NLPQueryService {
  if (!nlpQueryService) {
    nlpQueryService = new NLPQueryService(config);
  } else if (config) {
    nlpQueryService.updateConfig(config);
  }
  return nlpQueryService;
}