// Smart Query Analyzer using NLP for dynamic complexity detection
import { Document, VectorStoreIndex, serviceContextFromDefaults } from 'llamaindex';

export interface QueryAnalysis {
  complexity: 'simple' | 'medium' | 'complex' | 'very_complex';
  estimatedTokens: number;
  suggestedStrategy: QueryStrategy;
  semanticComponents: SemanticComponent[];
  requiresSplitting: boolean;
}

export interface QueryStrategy {
  approach: 'direct' | 'single_cte' | 'multi_cte' | 'chunked';
  maxTokens: number;
  chunkingStrategy?: ChunkingStrategy;
  technicalHints: string[];
}

export interface SemanticComponent {
  type: 'entity' | 'condition' | 'aggregation' | 'temporal' | 'relationship';
  value: string;
  complexity: number;
}

export interface ChunkingStrategy {
  method: 'sequential' | 'hierarchical' | 'parallel';
  chunks: QueryChunk[];
}

export interface QueryChunk {
  id: string;
  query: string;
  dependencies: string[];
  estimatedTokens: number;
}

export class SmartQueryAnalyzer {
  private static readonly TOKEN_LIMITS = {
    simple: 500,
    medium: 800,
    complex: 1200,
    very_complex: 2000
  };

  private static readonly CHUNKING_THRESHOLD = 1000;

  /**
   * Analyzes query using LlamaIndex for semantic understanding
   */
  static async analyzeWithLLM(query: string): Promise<QueryAnalysis> {
    // Create a document with the query
    const queryDoc = new Document({ text: query, id_: 'query' });
    
    // Use LlamaIndex to extract semantic components
    const analysisPrompt = `
Analyze this healthcare query and identify:
1. Main entities (patients, conditions, medications, etc.)
2. Operations (count, average, compare, etc.)
3. Relationships between entities
4. Time windows or temporal aspects
5. Complexity indicators

Query: ${query}

Return a structured analysis with complexity score (1-10).
`;

    try {
      // Use LlamaIndex for semantic analysis
      const serviceContext = serviceContextFromDefaults();
      const index = await VectorStoreIndex.fromDocuments([queryDoc], { serviceContext });
      const queryEngine = index.asQueryEngine();
      
      const response = await queryEngine.query({
        query: analysisPrompt,
      });

      // Parse the LLM response to extract components
      const components = this.parseSemanticComponents(response.toString());
      const complexity = this.calculateComplexity(components);
      const estimatedTokens = this.estimateTokens(query, components);
      
      return {
        complexity,
        estimatedTokens,
        suggestedStrategy: this.determineStrategy(complexity, estimatedTokens),
        semanticComponents: components,
        requiresSplitting: estimatedTokens > this.CHUNKING_THRESHOLD
      };
    } catch (error) {
      // Fallback to rule-based analysis if LLM fails
      return this.fallbackAnalysis(query);
    }
  }

  /**
   * Handles token limit by splitting complex queries into chunks
   */
  static createQueryChunks(query: string, components: SemanticComponent[]): ChunkingStrategy {
    // Group components by type and dependency
    const entityGroups = this.groupComponents(components);
    
    // Create execution plan
    const chunks: QueryChunk[] = [];
    
    // Chunk 1: Base entities and conditions
    if (entityGroups.entities.length > 0 || entityGroups.conditions.length > 0) {
      chunks.push({
        id: 'base_data',
        query: this.buildChunkQuery(query, ['entities', 'conditions'], entityGroups),
        dependencies: [],
        estimatedTokens: 400
      });
    }

    // Chunk 2: Aggregations
    if (entityGroups.aggregations.length > 0) {
      chunks.push({
        id: 'aggregations',
        query: this.buildChunkQuery(query, ['aggregations'], entityGroups),
        dependencies: ['base_data'],
        estimatedTokens: 300
      });
    }

    // Chunk 3: Final calculations and scoring
    if (entityGroups.relationships.length > 0) {
      chunks.push({
        id: 'final_scoring',
        query: this.buildChunkQuery(query, ['relationships'], entityGroups),
        dependencies: ['base_data', 'aggregations'],
        estimatedTokens: 300
      });
    }

    return {
      method: chunks.length > 2 ? 'hierarchical' : 'sequential',
      chunks
    };
  }

  /**
   * Generates optimized prompts based on analysis
   */
  static generateOptimizedPrompt(
    query: string, 
    analysis: QueryAnalysis,
    schemaContext: string
  ): string | string[] {
    if (!analysis.requiresSplitting) {
      // Single prompt with appropriate hints
      return `${schemaContext}

Question: ${query}

Technical guidance:
${analysis.suggestedStrategy.technicalHints.join('\n')}

Generate ${analysis.suggestedStrategy.approach === 'multi_cte' ? 'multiple CTEs' : 'SQL'} with max ${analysis.suggestedStrategy.maxTokens} tokens.

SQL:`;
    } else {
      // Multiple prompts for chunked execution
      const chunks = this.createQueryChunks(query, analysis.semanticComponents);
      return chunks.chunks.map(chunk => `${schemaContext}

Part ${chunk.id} of complex query:
${chunk.query}

${chunk.dependencies.length > 0 ? `Build upon: ${chunk.dependencies.join(', ')}` : ''}

SQL (max ${chunk.estimatedTokens} tokens):`);
    }
  }

  /**
   * Merges results from chunked queries
   */
  static async mergeChunkedResults(chunks: string[]): Promise<string> {
    const mergePrompt = `
Merge these SQL query parts into a single, cohesive query:

${chunks.map((chunk, i) => `Part ${i + 1}:\n${chunk}`).join('\n\n')}

Create a unified query using CTEs that combines all parts efficiently.
`;

    // Use LlamaIndex to merge intelligently
    const serviceContext = serviceContextFromDefaults();
    const doc = new Document({ text: mergePrompt });
    const index = await VectorStoreIndex.fromDocuments([doc], { serviceContext });
    const queryEngine = index.asQueryEngine();
    
    const response = await queryEngine.query({
      query: 'Merge the SQL parts into a single query',
    });

    return response.toString();
  }

  // Helper methods
  private static parseSemanticComponents(llmResponse: string): SemanticComponent[] {
    // Parse LLM response to extract semantic components
    // This would parse the structured response from the LLM
    const components: SemanticComponent[] = [];
    
    // Example parsing logic (would be more sophisticated in practice)
    const lines = llmResponse.split('\n');
    for (const line of lines) {
      if (line.includes('entity:')) {
        components.push({
          type: 'entity',
          value: line.split(':')[1].trim(),
          complexity: 1
        });
      } else if (line.includes('condition:')) {
        components.push({
          type: 'condition',
          value: line.split(':')[1].trim(),
          complexity: 2
        });
      }
      // ... more parsing
    }
    
    return components;
  }

  private static calculateComplexity(components: SemanticComponent[]): 'simple' | 'medium' | 'complex' | 'very_complex' {
    const totalComplexity = components.reduce((sum, c) => sum + c.complexity, 0);
    
    if (totalComplexity <= 3) return 'simple';
    if (totalComplexity <= 6) return 'medium';
    if (totalComplexity <= 10) return 'complex';
    return 'very_complex';
  }

  private static estimateTokens(query: string, components: SemanticComponent[]): number {
    // Base tokens for query structure
    let tokens = query.split(' ').length * 2;
    
    // Add tokens for each component type
    components.forEach(component => {
      switch (component.type) {
        case 'entity':
          tokens += 50;
          break;
        case 'condition':
          tokens += 100;
          break;
        case 'aggregation':
          tokens += 150;
          break;
        case 'temporal':
          tokens += 80;
          break;
        case 'relationship':
          tokens += 200;
          break;
      }
    });
    
    return tokens;
  }

  private static determineStrategy(
    complexity: 'simple' | 'medium' | 'complex' | 'very_complex',
    estimatedTokens: number
  ): QueryStrategy {
    const strategy: QueryStrategy = {
      approach: 'direct',
      maxTokens: this.TOKEN_LIMITS[complexity],
      technicalHints: []
    };

    switch (complexity) {
      case 'simple':
        strategy.approach = 'direct';
        strategy.technicalHints = ['Use straightforward SELECT'];
        break;
      case 'medium':
        strategy.approach = 'single_cte';
        strategy.technicalHints = ['Use a CTE for clarity'];
        break;
      case 'complex':
        strategy.approach = 'multi_cte';
        strategy.technicalHints = ['Use multiple CTEs', 'Break down into steps'];
        break;
      case 'very_complex':
        strategy.approach = 'chunked';
        strategy.technicalHints = ['Complex query requiring chunking'];
        break;
    }

    // Adjust max tokens if needed
    if (estimatedTokens > strategy.maxTokens) {
      strategy.maxTokens = Math.min(estimatedTokens + 200, 2000);
    }

    return strategy;
  }

  private static fallbackAnalysis(query: string): QueryAnalysis {
    // Simple rule-based fallback
    const wordCount = query.split(' ').length;
    const hasMultipleSteps = /then|after|finally|based on/i.test(query);
    const hasAggregations = /count|average|sum|total/i.test(query);
    
    let complexity: 'simple' | 'medium' | 'complex' | 'very_complex' = 'simple';
    if (wordCount > 30 || hasMultipleSteps) complexity = 'complex';
    else if (wordCount > 20 || hasAggregations) complexity = 'medium';
    
    return {
      complexity,
      estimatedTokens: wordCount * 15,
      suggestedStrategy: this.determineStrategy(complexity, wordCount * 15),
      semanticComponents: [],
      requiresSplitting: wordCount > 50
    };
  }

  private static groupComponents(components: SemanticComponent[]) {
    return {
      entities: components.filter(c => c.type === 'entity'),
      conditions: components.filter(c => c.type === 'condition'),
      aggregations: components.filter(c => c.type === 'aggregation'),
      temporal: components.filter(c => c.type === 'temporal'),
      relationships: components.filter(c => c.type === 'relationship')
    };
  }

  private static buildChunkQuery(
    originalQuery: string, 
    componentTypes: string[], 
    groups: any
  ): string {
    // Extract relevant parts of the query for this chunk
    let chunkQuery = originalQuery;
    
    // This would be more sophisticated in practice
    // For now, return a simplified version focusing on the component types
    if (componentTypes.includes('entities')) {
      chunkQuery = 'Find all relevant patients and their conditions';
    } else if (componentTypes.includes('aggregations')) {
      chunkQuery = 'Calculate counts and aggregations from the base data';
    } else if (componentTypes.includes('relationships')) {
      chunkQuery = 'Compute final scores and relationships';
    }
    
    return chunkQuery;
  }
}