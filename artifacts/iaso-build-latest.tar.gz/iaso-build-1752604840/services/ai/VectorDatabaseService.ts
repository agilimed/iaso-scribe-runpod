/**
 * Vector Database Service
 * 
 * Manages vector storage and retrieval for clinical documents
 * using ChromaDB for the RAG system
 */

// Try to import ChromaDB, fall back to stub if not available
let ChromaClient: any, Collection: any, QueryResponse: any;
try {
  const chromadb = require('chromadb');
  ChromaClient = chromadb.ChromaClient;
  Collection = chromadb.Collection;
  QueryResponse = chromadb.QueryResponse;
} catch (error) {
  const stub = require('./stubs/ChromaDBStub');
  ChromaClient = stub.ChromaClient;
  Collection = stub.Collection;
  QueryResponse = stub.QueryResponse;
}
import { v4 as uuidv4 } from 'uuid';

import { logger } from '../../utils/logger';

export interface VectorDocument {
  id: string;
  content: string;
  metadata: {
    source: string;
    type: 'clinical_guideline' | 'protocol' | 'drug_info' | 'procedure' | 'policy' | 'research';
    specialty?: string;
    lastUpdated: Date;
    tenantId?: string;
    tags?: string[];
    [key: string]: any;
  };
  embedding?: number[];
}

export interface SearchOptions {
  k?: number; // Number of results to return
  filter?: Record<string, any>;
  includeMetadata?: boolean;
  includeDistances?: boolean;
  tenantId?: string;
}

export interface SearchResult {
  document: VectorDocument;
  score: number;
  distance?: number;
}

export class VectorDatabaseService {
  private client: ChromaClient;
  private collections: Map<string, Collection> = new Map();
  private initialized: boolean = false;

  constructor() {
    // ChromaDB will be initialized lazily
  }

  /**
   * Initialize the vector database connection
   */
  async initialize(): Promise<void> {
    if (this.initialized) return;

    try {
      // Initialize ChromaDB client
      // In production, this would connect to a ChromaDB server
      // For now, we'll use the embedded version
      this.client = new ChromaClient({
        path: process.env.CHROMA_PATH || './data/chroma'
      });

      // Create or get default collections
      await this.ensureCollections();

      this.initialized = true;
      logger.info('Vector database service initialized');
    } catch (error) {
      logger.error('Failed to initialize vector database', error as Error);
      throw error;
    }
  }

  /**
   * Ensure required collections exist
   */
  private async ensureCollections(): Promise<void> {
    const collections = [
      'clinical_guidelines',
      'medical_protocols',
      'drug_information',
      'procedures',
      'policies',
      'research_papers'
    ];

    for (const collectionName of collections) {
      try {
        const collection = await this.client.getOrCreateCollection({
          name: collectionName,
          metadata: {
            description: `Collection for ${collectionName.replace('_', ' ')}`,
            created_at: new Date().toISOString()
          }
        });
        this.collections.set(collectionName, collection);
      } catch (error) {
        logger.error(`Failed to create collection ${collectionName}`, error as Error);
      }
    }
  }

  /**
   * Add documents to the vector database
   */
  async addDocuments(
    documents: VectorDocument[],
    collectionName?: string
  ): Promise<string[]> {
    await this.initialize();

    const collection = collectionName 
      ? this.collections.get(collectionName) 
      : this.collections.get('clinical_guidelines');

    if (!collection) {
      throw new Error(`Collection ${collectionName} not found`);
    }

    const ids: string[] = [];
    const contents: string[] = [];
    const metadatas: any[] = [];

    for (const doc of documents) {
      const id = doc.id || uuidv4();
      ids.push(id);
      contents.push(doc.content);
      metadatas.push({
        ...doc.metadata,
        lastUpdated: doc.metadata.lastUpdated.toISOString()
      });
    }

    try {
      // Add documents to the collection
      // ChromaDB will automatically generate embeddings
      await collection.add({
        ids,
        documents: contents,
        metadatas
      });

      logger.info(`Added ${documents.length} documents to ${collectionName || 'default'} collection`);
      return ids;
    } catch (error) {
      logger.error('Failed to add documents to vector database', error as Error);
      throw error;
    }
  }

  /**
   * Search for similar documents
   */
  async search(
    query: string,
    options: SearchOptions = {}
  ): Promise<SearchResult[]> {
    await this.initialize();

    const {
      k = 5,
      filter,
      includeMetadata = true,
      includeDistances = true,
      tenantId
    } = options;

    try {
      const results: SearchResult[] = [];

      // Search across all collections or specific ones based on filter
      const collectionsToSearch = filter?.collections 
        ? filter.collections.map((name: string) => this.collections.get(name)).filter(Boolean)
        : Array.from(this.collections.values());

      for (const collection of collectionsToSearch) {
        // Build query filter
        const queryFilter: any = {};
        if (tenantId) {
          queryFilter.tenantId = { $eq: tenantId };
        }
        if (filter?.type) {
          queryFilter.type = { $eq: filter.type };
        }
        if (filter?.specialty) {
          queryFilter.specialty = { $eq: filter.specialty };
        }
        if (filter?.tags) {
          queryFilter.tags = { $in: filter.tags };
        }

        // Query the collection
        const queryResults = await collection.query({
          queryTexts: [query],
          nResults: k,
          where: Object.keys(queryFilter).length > 0 ? queryFilter : undefined,
          include: ['metadatas', 'documents', 'distances']
        });

        // Process results
        if (queryResults.documents && queryResults.documents[0]) {
          for (let i = 0; i < queryResults.documents[0].length; i++) {
            const doc: VectorDocument = {
              id: queryResults.ids[0][i],
              content: queryResults.documents[0][i] || '',
              metadata: queryResults.metadatas?.[0]?.[i] || {}
            };

            results.push({
              document: doc,
              score: 1 - (queryResults.distances?.[0]?.[i] || 0), // Convert distance to similarity score
              distance: includeDistances ? queryResults.distances?.[0]?.[i] : undefined
            });
          }
        }
      }

      // Sort by score (highest first) and limit to k results
      results.sort((a, b) => b.score - a.score);
      return results.slice(0, k);

    } catch (error) {
      logger.error('Failed to search vector database', error as Error);
      throw error;
    }
  }

  /**
   * Update a document in the vector database
   */
  async updateDocument(
    documentId: string,
    updates: Partial<VectorDocument>,
    collectionName?: string
  ): Promise<void> {
    await this.initialize();

    const collection = collectionName 
      ? this.collections.get(collectionName) 
      : this.collections.get('clinical_guidelines');

    if (!collection) {
      throw new Error(`Collection ${collectionName} not found`);
    }

    try {
      // Update the document
      await collection.update({
        ids: [documentId],
        documents: updates.content ? [updates.content] : undefined,
        metadatas: updates.metadata ? [{
          ...updates.metadata,
          lastUpdated: new Date().toISOString()
        }] : undefined
      });

      logger.info(`Updated document ${documentId} in ${collectionName || 'default'} collection`);
    } catch (error) {
      logger.error('Failed to update document in vector database', error as Error);
      throw error;
    }
  }

  /**
   * Delete documents from the vector database
   */
  async deleteDocuments(
    documentIds: string[],
    collectionName?: string
  ): Promise<void> {
    await this.initialize();

    const collection = collectionName 
      ? this.collections.get(collectionName) 
      : this.collections.get('clinical_guidelines');

    if (!collection) {
      throw new Error(`Collection ${collectionName} not found`);
    }

    try {
      await collection.delete({
        ids: documentIds
      });

      logger.info(`Deleted ${documentIds.length} documents from ${collectionName || 'default'} collection`);
    } catch (error) {
      logger.error('Failed to delete documents from vector database', error as Error);
      throw error;
    }
  }

  /**
   * Get document by ID
   */
  async getDocument(
    documentId: string,
    collectionName?: string
  ): Promise<VectorDocument | null> {
    await this.initialize();

    const collection = collectionName 
      ? this.collections.get(collectionName) 
      : this.collections.get('clinical_guidelines');

    if (!collection) {
      throw new Error(`Collection ${collectionName} not found`);
    }

    try {
      const result = await collection.get({
        ids: [documentId],
        include: ['metadatas', 'documents']
      });

      if (result.documents && result.documents.length > 0) {
        return {
          id: result.ids[0],
          content: result.documents[0] || '',
          metadata: result.metadatas?.[0] || {}
        };
      }

      return null;
    } catch (error) {
      logger.error('Failed to get document from vector database', error as Error);
      throw error;
    }
  }

  /**
   * Create a new collection
   */
  async createCollection(
    name: string,
    metadata?: Record<string, any>
  ): Promise<void> {
    await this.initialize();

    try {
      const collection = await this.client.createCollection({
        name,
        metadata: {
          ...metadata,
          created_at: new Date().toISOString()
        }
      });

      this.collections.set(name, collection);
      logger.info(`Created new collection: ${name}`);
    } catch (error) {
      logger.error(`Failed to create collection ${name}`, error as Error);
      throw error;
    }
  }

  /**
   * Delete a collection
   */
  async deleteCollection(name: string): Promise<void> {
    await this.initialize();

    try {
      await this.client.deleteCollection({ name });
      this.collections.delete(name);
      logger.info(`Deleted collection: ${name}`);
    } catch (error) {
      logger.error(`Failed to delete collection ${name}`, error as Error);
      throw error;
    }
  }

  /**
   * Get collection statistics
   */
  async getCollectionStats(collectionName?: string): Promise<any> {
    await this.initialize();

    if (collectionName) {
      const collection = this.collections.get(collectionName);
      if (!collection) {
        throw new Error(`Collection ${collectionName} not found`);
      }

      const count = await collection.count();
      return {
        name: collectionName,
        count,
        metadata: await collection.get({ limit: 0 })
      };
    }

    // Get stats for all collections
    const stats: any[] = [];
    for (const [name, collection] of this.collections) {
      const count = await collection.count();
      stats.push({
        name,
        count
      });
    }

    return stats;
  }

  /**
   * Perform hybrid search (semantic + keyword)
   */
  async hybridSearch(
    query: string,
    keywords: string[],
    options: SearchOptions = {}
  ): Promise<SearchResult[]> {
    await this.initialize();

    // First, perform semantic search
    const semanticResults = await this.search(query, {
      ...options,
      k: (options.k || 5) * 2 // Get more results for filtering
    });

    // Then filter by keywords
    const keywordFilteredResults = semanticResults.filter(result => {
      const content = result.document.content.toLowerCase();
      return keywords.some(keyword => content.includes(keyword.toLowerCase()));
    });

    // If we don't have enough results, add some semantic-only results
    const finalResults = keywordFilteredResults.slice(0, options.k || 5);
    if (finalResults.length < (options.k || 5)) {
      const remaining = (options.k || 5) - finalResults.length;
      const additionalResults = semanticResults
        .filter(r => !keywordFilteredResults.includes(r))
        .slice(0, remaining);
      finalResults.push(...additionalResults);
    }

    return finalResults;
  }

  /**
   * Bulk import documents from various sources
   */
  async bulkImport(
    documents: VectorDocument[],
    batchSize: number = 100
  ): Promise<{ imported: number; failed: number; errors: string[] }> {
    await this.initialize();

    const results = {
      imported: 0,
      failed: 0,
      errors: [] as string[]
    };

    // Process in batches
    for (let i = 0; i < documents.length; i += batchSize) {
      const batch = documents.slice(i, i + batchSize);
      
      try {
        // Group by collection type
        const grouped = batch.reduce((acc, doc) => {
          const collection = this.getCollectionForType(doc.metadata.type);
          if (!acc[collection]) acc[collection] = [];
          acc[collection].push(doc);
          return acc;
        }, {} as Record<string, VectorDocument[]>);

        // Import each group
        for (const [collectionName, docs] of Object.entries(grouped)) {
          await this.addDocuments(docs, collectionName);
          results.imported += docs.length;
        }
      } catch (error) {
        results.failed += batch.length;
        results.errors.push(`Batch ${i / batchSize + 1}: ${(error as Error).message}`);
        logger.error(`Failed to import batch ${i / batchSize + 1}`, error as Error);
      }
    }

    return results;
  }

  /**
   * Get collection name for document type
   */
  private getCollectionForType(type: string): string {
    const typeToCollection: Record<string, string> = {
      'clinical_guideline': 'clinical_guidelines',
      'protocol': 'medical_protocols',
      'drug_info': 'drug_information',
      'procedure': 'procedures',
      'policy': 'policies',
      'research': 'research_papers'
    };

    return typeToCollection[type] || 'clinical_guidelines';
  }
}

// Export singleton instance
export const vectorDatabaseService = new VectorDatabaseService();