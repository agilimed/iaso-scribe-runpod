/**
 * NLP Query Parser Service
 * 
 * This service handles natural language query processing for the NexusCare Insights Engine.
 * It integrates with Qwen3-4B for intent recognition, entity extraction, and query translation.
 */

import axios from 'axios';

import { logger } from '../../utils/logger';
import { ClickHouseQueryBuilder } from '../../utils/clickhouse-helpers';

import { getClickHouseMCPIntegration } from './ClickHouseMCPIntegration';
// RAG and embeddings services will be loaded lazily to avoid startup issues
// import { ragService } from './RAGService';
// import { embeddingsService } from './EmbeddingsService';

export interface NLPQuery {
  query: string;
  context?: {
    userId: string;
    tenantId: string;
    previousQueries?: string[];
    userRole?: string;
  };
}

export interface QueryIntent {
  type: 'metric' | 'comparison' | 'trend' | 'aggregation' | 'detail' | 'alert' | 'unknown';
  confidence: number;
  subType?: string;
}

export interface MedicalEntity {
  text: string;
  type: 'condition' | 'medication' | 'procedure' | 'lab' | 'vital' | 'department' | 'time' | 'metric';
  value?: string;
  code?: string;
  system?: string;
}

export interface ParsedQuery {
  originalQuery: string;
  intent: QueryIntent;
  entities: MedicalEntity[];
  timeRange?: {
    start?: Date;
    end?: Date;
    period?: string;
  };
  filters?: Record<string, any>;
  aggregations?: string[];
  resourceTypes?: string[];
  metrics?: string[];
}

export interface SQLTranslation {
  sql: string;
  explanation: string;
  estimatedCost: number;
  warnings?: string[];
}

export class NLPQueryParser {
  private qwen3Endpoint: string;
  private medicalTermMappings: Map<string, MedicalEntity> = new Map();
  private commonQueryPatterns: Map<RegExp, QueryIntent> = new Map();
  private useRAG: boolean;
  private ragCache: Map<string, any> = new Map();

  constructor() {
    // Initialize with Qwen3 endpoint (will be configured via env)
    this.qwen3Endpoint = process.env.QWEN3_SERVICE_URL || 'http://localhost:8002';
    
    // Enable RAG for enhanced query understanding
    this.useRAG = process.env.ENABLE_RAG !== 'false'; // Default to true
    
    // Initialize medical term mappings
    this.initializeMedicalMappings();
    
    // Initialize common query patterns
    this.initializeQueryPatterns();
  }

  /**
   * Initialize medical term mappings for entity recognition
   */
  private initializeMedicalMappings(): void {
    this.medicalTermMappings = new Map([
      // Conditions
      ['diabetes', { text: 'diabetes', type: 'condition', code: 'E11', system: 'ICD10' }],
      ['hypertension', { text: 'hypertension', type: 'condition', code: 'I10', system: 'ICD10' }],
      ['sepsis', { text: 'sepsis', type: 'condition', code: 'A41.9', system: 'ICD10' }],
      ['pneumonia', { text: 'pneumonia', type: 'condition', code: 'J18.9', system: 'ICD10' }],
      
      // Medications
      ['insulin', { text: 'insulin', type: 'medication', code: '310534', system: 'RxNorm' }],
      ['metformin', { text: 'metformin', type: 'medication', code: '4337', system: 'RxNorm' }],
      ['antibiotics', { text: 'antibiotics', type: 'medication' }],
      
      // Labs
      ['glucose', { text: 'glucose', type: 'lab', code: '2339-0', system: 'LOINC' }],
      ['hemoglobin', { text: 'hemoglobin', type: 'lab', code: '718-7', system: 'LOINC' }],
      ['creatinine', { text: 'creatinine', type: 'lab', code: '2160-0', system: 'LOINC' }],
      
      // Vitals
      ['blood pressure', { text: 'blood pressure', type: 'vital', code: '85354-9', system: 'LOINC' }],
      ['heart rate', { text: 'heart rate', type: 'vital', code: '8867-4', system: 'LOINC' }],
      ['temperature', { text: 'temperature', type: 'vital', code: '8310-5', system: 'LOINC' }],
      
      // Departments
      ['emergency', { text: 'emergency', type: 'department', value: 'ED' }],
      ['icu', { text: 'icu', type: 'department', value: 'ICU' }],
      ['cardiology', { text: 'cardiology', type: 'department', value: 'CARD' }],
    ]);
  }

  /**
   * Initialize common query patterns for intent recognition
   */
  private initializeQueryPatterns(): void {
    this.commonQueryPatterns = new Map([
      [/show\s+me\s+all\s+(\w+)/i, { type: 'metric', confidence: 0.8 }],
      [/how\s+many\s+(\w+)/i, { type: 'aggregation', confidence: 0.9, subType: 'count' }],
      [/average\s+(\w+)/i, { type: 'aggregation', confidence: 0.9, subType: 'average' }],
      [/compare\s+(\w+)\s+(?:between|and)/i, { type: 'comparison', confidence: 0.85 }],
      [/trend\s+(?:of|in)\s+(\w+)/i, { type: 'trend', confidence: 0.9 }],
      [/alert\s+(?:me|when)\s+(\w+)/i, { type: 'alert', confidence: 0.85 }],
      [/(?:last|past)\s+(\d+)\s+(hour|day|week|month)/i, { type: 'metric', confidence: 0.7 }],
    ]);
  }

  /**
   * Parse a natural language query
   */
  async parseQuery(nlpQuery: NLPQuery): Promise<ParsedQuery> {
    try {
      logger.info('Parsing NLP query');

      // Step 1: Use RAG to enhance query understanding if enabled
      let enhancedContext: any = {};
      if (this.useRAG) {
        enhancedContext = await this.enhanceQueryWithRAG(nlpQuery);
      }

      // Step 2: Recognize intent (with RAG enhancement)
      const intent = await this.recognizeIntent(nlpQuery.query, enhancedContext);
      
      // Step 3: Extract entities (with medical knowledge from RAG)
      const entities = await this.extractEntities(nlpQuery.query, enhancedContext);
      
      // Step 4: Extract time range
      const timeRange = this.extractTimeRange(nlpQuery.query);
      
      // Step 5: Determine resource types and metrics
      const { resourceTypes, metrics } = this.determineResourcesAndMetrics(entities, intent);
      
      // Step 6: Build filters (enhanced with RAG context)
      const filters = this.buildFilters(entities, nlpQuery.context, enhancedContext);

      return {
        originalQuery: nlpQuery.query,
        intent,
        entities,
        timeRange,
        filters,
        resourceTypes,
        metrics,
        aggregations: this.getAggregations(intent)
      };
    } catch (error) {
      logger.error('Failed to parse NLP query', error as Error);
      throw error;
    }
  }

  /**
   * Enhance query with RAG context
   */
  private async enhanceQueryWithRAG(nlpQuery: NLPQuery): Promise<any> {
    try {
      // Check cache first
      const cacheKey = `rag_${nlpQuery.query}_${JSON.stringify(nlpQuery.context)}`;
      if (this.ragCache.has(cacheKey)) {
        return this.ragCache.get(cacheKey);
      }

      // Lazy load RAG service
      let ragService: any;
      try {
        const module = await import('./RAGService');
        ragService = module.ragService;
      } catch (error) {
        logger.warn('RAG service not available, using mock');
        // Return empty context if RAG is not available
        return {};
      }

      // Query RAG for relevant clinical context
      const ragResponse = await ragService.query({
        query: nlpQuery.query,
        context: {
          ...nlpQuery.context,
          useCase: 'clinical_decision'
        },
        options: {
          topK: 3,
          includeMetadata: true,
          hybridSearch: true
        }
      });

      // Extract key concepts and medical terms from RAG results
      const enhancedContext = {
        relatedConcepts: this.extractConceptsFromRAG(ragResponse),
        medicalTerms: this.extractMedicalTermsFromRAG(ragResponse),
        suggestedFilters: this.extractFiltersFromRAG(ragResponse),
        contextualKnowledge: ragResponse.sources.map((s: any) => ({
          content: (s as any).content.substring(0, 200),
          metadata: s.metadata
        }))
      };

      // Cache the result
      this.ragCache.set(cacheKey, enhancedContext);
      
      // Clear old cache entries if too large
      if (this.ragCache.size > 100) {
        const firstKey = this.ragCache.keys().next().value;
        if (firstKey) {
          this.ragCache.delete(firstKey);
        }
      }

      return enhancedContext;
    } catch (error) {
      logger.warn('RAG enhancement failed, continuing without it');
      return {};
    }
  }

  /**
   * Extract concepts from RAG response
   */
  private extractConceptsFromRAG(ragResponse: any): string[] {
    const concepts: Set<string> = new Set();
    
    // Extract from answer
    const medicalPatterns = [
      /\b(?:diagnosis|treatment|procedure|medication|condition)\s+(?:of|for)?\s+(\w+(?:\s+\w+)?)/gi,
      /\b([\w\s]+?)\s+(?:patients?|cases?|conditions?)/gi
    ];

    for (const pattern of medicalPatterns) {
      const matches = ragResponse.answer.matchAll(pattern);
      for (const match of matches) {
        if (match[1]) concepts.add(match[1].trim().toLowerCase());
      }
    }

    // Extract from source metadata
    ragResponse.sources.forEach((source: any) => {
      if (source.metadata?.keywords) {
        source.metadata.keywords.forEach((keyword: string) => 
          concepts.add(keyword.toLowerCase())
        );
      }
    });

    return Array.from(concepts);
  }

  /**
   * Extract medical terms from RAG response
   */
  private extractMedicalTermsFromRAG(ragResponse: any): MedicalEntity[] {
    const terms: MedicalEntity[] = [];
    
    ragResponse.sources.forEach((source: any) => {
      // Extract ICD codes
      if (source.metadata?.icd10Codes) {
        source.metadata.icd10Codes.forEach((code: string) => {
          terms.push({
            text: code,
            type: 'condition',
            code: code,
            system: 'ICD10'
          });
        });
      }

      // Extract medications
      if (source.metadata?.medications) {
        source.metadata.medications.forEach((med: string) => {
          terms.push({
            text: med.toLowerCase(),
            type: 'medication'
          });
        });
      }

      // Extract from highlights
      if (source.highlights) {
        source.highlights.forEach((highlight: string) => {
          // Look for medical terms in highlights
          const medTerms = this.extractMedicalTermsFromText(highlight);
          terms.push(...medTerms);
        });
      }
    });

    return terms;
  }

  /**
   * Extract suggested filters from RAG response
   */
  private extractFiltersFromRAG(ragResponse: any): Record<string, any> {
    const filters: Record<string, any> = {};

    // Analyze source metadata for common patterns
    const specialties = new Set<string>();
    const departments = new Set<string>();
    
    ragResponse.sources.forEach((source: any) => {
      if (source.metadata?.specialty) {
        specialties.add(source.metadata.specialty);
      }
      if (source.metadata?.department) {
        departments.add(source.metadata.department);
      }
    });

    if (specialties.size === 1) {
      filters.specialty = Array.from(specialties)[0];
    }
    if (departments.size === 1) {
      filters.department = Array.from(departments)[0];
    }

    return filters;
  }

  /**
   * Extract medical terms from text
   */
  private extractMedicalTermsFromText(text: string): MedicalEntity[] {
    const terms: MedicalEntity[] = [];
    const textLower = text.toLowerCase();

    // Check against known medical terms
    for (const [term, entity] of this.medicalTermMappings) {
      if (textLower.includes(term)) {
        terms.push(entity);
      }
    }

    return terms;
  }

  /**
   * Recognize query intent using patterns and Qwen3
   */
  private async recognizeIntent(query: string, enhancedContext: any = {}): Promise<QueryIntent> {
    // First try pattern matching
    for (const [pattern, intent] of this.commonQueryPatterns) {
      if (pattern.test(query)) {
        return intent;
      }
    }

    // Check if RAG context suggests a specific intent
    if (enhancedContext.relatedConcepts) {
      const concepts = enhancedContext.relatedConcepts.join(' ');
      if (concepts.includes('trend') || concepts.includes('over time')) {
        return { type: 'trend', confidence: 0.85 };
      }
      if (concepts.includes('compare') || concepts.includes('versus')) {
        return { type: 'comparison', confidence: 0.85 };
      }
      if (concepts.includes('total') || concepts.includes('count')) {
        return { type: 'aggregation', confidence: 0.85, subType: 'count' };
      }
    }

    // Fall back to Qwen3 for complex queries
    try {
      const contextualPrompt = enhancedContext.contextualKnowledge
        ? `\nContext from knowledge base:\n${enhancedContext.contextualKnowledge.map((k: any) => k.content).join('\n')}`
        : '';

      const response = await axios.post(`${this.qwen3Endpoint}/analyze`, {
        prompt: `Classify this healthcare query intent:
Query: "${query}"
${contextualPrompt}

Intent types: metric, comparison, trend, aggregation, detail, alert
Respond with JSON: {"type": "...", "confidence": 0.0-1.0, "subType": "..."}`,
        max_tokens: 100,
        temperature: 0.1
      });

      return JSON.parse(response.data.response);
    } catch (error) {
      logger.warn('Qwen3 intent recognition failed, using default');
      return { type: 'metric', confidence: 0.5 };
    }
  }

  /**
   * Extract medical entities from the query
   */
  private async extractEntities(query: string, enhancedContext: any = {}): Promise<MedicalEntity[]> {
    const entities: MedicalEntity[] = [];
    const lowerQuery = query.toLowerCase();

    // Add entities from RAG context if available
    if (enhancedContext.medicalTerms) {
      entities.push(...enhancedContext.medicalTerms);
    }

    // Extract known medical terms
    for (const [term, entity] of this.medicalTermMappings) {
      if (lowerQuery.includes(term)) {
        // Check if not already added from RAG
        const exists = entities.some(e => 
          e.text === entity.text && e.type === entity.type
        );
        if (!exists) {
          entities.push({ ...entity });
        }
      }
    }

    // Extract time entities
    const timePatterns = [
      { pattern: /today/i, entity: { text: 'today', type: 'time' as const, value: 'today' } },
      { pattern: /yesterday/i, entity: { text: 'yesterday', type: 'time' as const, value: 'yesterday' } },
      { pattern: /this\s+week/i, entity: { text: 'this week', type: 'time' as const, value: 'this_week' } },
      { pattern: /last\s+(\d+)\s+(hour|day|week|month)s?/i, entity: { text: '', type: 'time' as const } }
    ];

    for (const { pattern, entity } of timePatterns) {
      const match = query.match(pattern);
      if (match) {
        entities.push({
          ...entity,
          text: match[0],
          value: match[1] && match[2] ? `last_${match[1]}_${match[2]}` : entity.value
        });
      }
    }

    // Use Qwen3 for advanced entity extraction if needed
    if (entities.length === 0) {
      try {
        const response = await axios.post(`${this.qwen3Endpoint}/extract`, {
          prompt: `Extract medical entities from: "${query}"
Return JSON array of entities with: text, type (condition/medication/procedure/lab/vital/department/time/metric), value, code, system`,
          max_tokens: 200,
          temperature: 0.1
        });

        const extractedEntities = JSON.parse(response.data.response);
        entities.push(...extractedEntities);
      } catch (error) {
        logger.warn('Qwen3 entity extraction failed');
      }
    }

    return entities;
  }

  /**
   * Extract time range from query
   */
  private extractTimeRange(query: string): ParsedQuery['timeRange'] {
    const now = new Date();
    const timeRange: ParsedQuery['timeRange'] = {};

    // Common time patterns
    if (/today/i.test(query)) {
      timeRange.start = new Date(now.setHours(0, 0, 0, 0));
      timeRange.end = new Date();
    } else if (/yesterday/i.test(query)) {
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      timeRange.start = new Date(yesterday.setHours(0, 0, 0, 0));
      timeRange.end = new Date(yesterday.setHours(23, 59, 59, 999));
    } else if (/this\s+week/i.test(query)) {
      const weekStart = new Date(now);
      weekStart.setDate(weekStart.getDate() - weekStart.getDay());
      timeRange.start = new Date(weekStart.setHours(0, 0, 0, 0));
      timeRange.end = new Date();
    }

    // Last N time period
    const lastMatch = query.match(/last\s+(\d+)\s+(hour|day|week|month)s?/i);
    if (lastMatch) {
      const amount = parseInt(lastMatch[1]);
      const unit = lastMatch[2].toLowerCase();
      timeRange.end = new Date();
      timeRange.start = new Date();
      
      switch (unit) {
        case 'hour':
          timeRange.start.setHours(timeRange.start.getHours() - amount);
          break;
        case 'day':
          timeRange.start.setDate(timeRange.start.getDate() - amount);
          break;
        case 'week':
          timeRange.start.setDate(timeRange.start.getDate() - (amount * 7));
          break;
        case 'month':
          timeRange.start.setMonth(timeRange.start.getMonth() - amount);
          break;
      }
      
      timeRange.period = `${amount}_${unit}`;
    }

    return Object.keys(timeRange).length > 0 ? timeRange : undefined;
  }

  /**
   * Determine resource types and metrics based on entities and intent
   */
  private determineResourcesAndMetrics(
    entities: MedicalEntity[], 
    intent: QueryIntent
  ): { resourceTypes: string[], metrics: string[] } {
    const resourceTypes = new Set<string>();
    const metrics = new Set<string>();

    // Map entity types to FHIR resources
    const entityToResource: Record<string, string[]> = {
      condition: ['Condition', 'Encounter'],
      medication: ['MedicationRequest', 'MedicationAdministration'],
      procedure: ['Procedure', 'Encounter'],
      lab: ['Observation', 'DiagnosticReport'],
      vital: ['Observation'],
      department: ['Encounter', 'Location']
    };

    // Add resource types based on entities
    for (const entity of entities) {
      const resources = entityToResource[entity.type];
      if (resources) {
        resources.forEach(r => resourceTypes.add(r));
      }
    }

    // Add metrics based on intent
    if (intent.type === 'aggregation' && intent.subType === 'count') {
      metrics.add('count');
    } else if (intent.type === 'aggregation' && intent.subType === 'average') {
      metrics.add('average');
    } else if (intent.type === 'trend') {
      metrics.add('trend_analysis');
    }

    // Default to common resources if none found
    if (resourceTypes.size === 0) {
      resourceTypes.add('Encounter');
      resourceTypes.add('Observation');
    }

    return {
      resourceTypes: Array.from(resourceTypes),
      metrics: Array.from(metrics)
    };
  }

  /**
   * Build filters from entities and context
   */
  private buildFilters(entities: MedicalEntity[], context?: NLPQuery['context'], enhancedContext: any = {}): Record<string, any> {
    const filters: Record<string, any> = {};

    // Add RAG suggested filters
    if (enhancedContext.suggestedFilters) {
      Object.assign(filters, enhancedContext.suggestedFilters);
    }

    // Add tenant filter
    if (context?.tenantId) {
      filters.tenant_id = context.tenantId;
    }

    // Add entity-based filters
    for (const entity of entities) {
      switch (entity.type) {
        case 'condition':
          filters.condition_code = entity.code;
          break;
        case 'medication':
          filters.medication_code = entity.code;
          break;
        case 'department':
          filters.department = entity.value;
          break;
        case 'lab':
          filters.lab_code = entity.code;
          break;
      }
    }

    return filters;
  }

  /**
   * Get aggregations based on intent
   */
  private getAggregations(intent: QueryIntent): string[] {
    const aggregations: string[] = [];

    switch (intent.type) {
      case 'aggregation':
        if (intent.subType) {
          aggregations.push(intent.subType);
        }
        break;
      case 'trend':
        aggregations.push('time_series');
        break;
      case 'comparison':
        aggregations.push('group_by');
        break;
    }

    return aggregations;
  }

  /**
   * Translate parsed query to SQL
   */
  async translateToSQL(parsedQuery: ParsedQuery): Promise<SQLTranslation> {
    try {
      const qb = new ClickHouseQueryBuilder();
      
      // Build base query
      qb.select(['resource_type', 'COUNT(*) as count'])
        .from('nexuscare_analytics.fhir_events');

      // Add filters
      if (parsedQuery.filters?.tenant_id) {
        qb.where(`tenant_id = '${parsedQuery.filters.tenant_id}'`);
      }

      // Add time range
      if (parsedQuery.timeRange?.start) {
        qb.and(`event_time >= '${parsedQuery.timeRange.start.toISOString()}'`);
      }
      if (parsedQuery.timeRange?.end) {
        qb.and(`event_time <= '${parsedQuery.timeRange.end.toISOString()}'`);
      }

      // Add resource type filters
      if (parsedQuery.resourceTypes && parsedQuery.resourceTypes.length > 0) {
        const resourceFilter = parsedQuery.resourceTypes
          .map(rt => `'${rt}'`)
          .join(', ');
        qb.and(`resource_type IN (${resourceFilter})`);
      }

      // Add grouping
      qb.groupBy('resource_type')
        .orderBy('count', 'DESC')
        .limit(100);

      const { sql } = qb.build();

      // Generate explanation using Qwen3
      const explanation = await this.generateSQLExplanation(parsedQuery, sql);

      return {
        sql,
        explanation,
        estimatedCost: this.estimateQueryCost(parsedQuery),
        warnings: this.getQueryWarnings(parsedQuery)
      };
    } catch (error) {
      logger.error('Failed to translate query to SQL', error as Error);
      throw error;
    }
  }

  /**
   * Generate human-readable explanation of SQL query
   */
  private async generateSQLExplanation(
    parsedQuery: ParsedQuery, 
    sql: string
  ): Promise<string> {
    // Simple explanation generation (can be enhanced with Qwen3)
    let explanation = 'This query will ';

    switch (parsedQuery.intent.type) {
      case 'aggregation':
        explanation += `calculate the ${parsedQuery.intent.subType || 'count'} of `;
        break;
      case 'trend':
        explanation += 'analyze trends in ';
        break;
      case 'comparison':
        explanation += 'compare ';
        break;
      default:
        explanation += 'retrieve ';
    }

    if (parsedQuery.resourceTypes && parsedQuery.resourceTypes.length > 0) {
      explanation += `${parsedQuery.resourceTypes.join(', ')} records `;
    }

    if (parsedQuery.timeRange?.period) {
      explanation += `from the last ${parsedQuery.timeRange.period.replace('_', ' ')}`;
    }

    return explanation;
  }

  /**
   * Estimate query cost (simplified)
   */
  private estimateQueryCost(parsedQuery: ParsedQuery): number {
    let cost = 1.0; // Base cost

    // Increase cost for complex operations
    if (parsedQuery.intent.type === 'trend') cost *= 2;
    if (parsedQuery.intent.type === 'comparison') cost *= 1.5;
    
    // Increase cost for large time ranges
    if (parsedQuery.timeRange?.period?.includes('month')) cost *= 2;
    if (parsedQuery.timeRange?.period?.includes('year')) cost *= 5;

    return Math.round(cost * 10) / 10;
  }

  /**
   * Get query warnings
   */
  private getQueryWarnings(parsedQuery: ParsedQuery): string[] {
    const warnings: string[] = [];

    // Warn about missing time range
    if (!parsedQuery.timeRange) {
      warnings.push('No time range specified - query may scan large amounts of data');
    }

    // Warn about broad resource types
    if (!parsedQuery.resourceTypes || parsedQuery.resourceTypes.length === 0) {
      warnings.push('No specific resource types - query will scan all resources');
    }

    return warnings;
  }
}

export default NLPQueryParser;