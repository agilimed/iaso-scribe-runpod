import axios from 'axios';

import { healthcareLogger } from '../monitoring/StructuredLogger';
import ClickHouseService from '../analytics/ClickHouseService';
import config from '../../config';

import { LlamaIndexConversationalService } from './LlamaIndexConversationalService';

// Removed RasaNLUResponse interface - RASA NLU no longer used

interface QueryIntent {
  type: 'metric_query' | 'comparison_query' | 'trend_analysis' | 'aggregation_query' | 'filter_query' | 'department_query' | 'patient_query' | 'cost_query' | 'quality_query' | 'capacity_query' | 'historical_query' | 'real_time_query' | 'unknown';
  entities: {
    metrics?: string[];
    departments?: string[];
    patientGroups?: string[];
    filters?: Array<{ field: string; operator: string; value: any }>;
    timeRange?: { start?: string; end?: string; granularity?: string };
    aggregations?: string[];
    comparison?: { type: string; baseline: string };
  };
  confidence: number;
  // rawRasaResponse removed - RASA NLU no longer used
}

interface ConversationContext {
  sessionId: string;
  userId: string;
  tenantId: string;
  history: Array<{
    query: string;
    intent: QueryIntent;
    sql: string;
    results: any;
    timestamp: string;
  }>;
}

interface AnalyticsResponse {
  query: string;
  interpretation: string;
  sql: string;
  results: any[];
  insights: string[];
  suggestions: string[];
  visualizationType?: 'bar' | 'line' | 'pie' | 'table' | 'metric';
  confidence: number;
}

export class ConversationalAnalyticsService {
  private logger = healthcareLogger;
  private clickhouse = new ClickHouseService();
  private contexts: Map<string, ConversationContext> = new Map();
  private aiGatewayUrl: string;
  // private rasaNLUUrl: string; // RASA NLU removed
  // private qwen3Url: string; // Qwen3 removed
  private llamaIndexService: LlamaIndexConversationalService;
  private useLlamaIndex: boolean;

  constructor() {
    this.aiGatewayUrl = process.env.AI_GATEWAY_URL || 'http://localhost:8000';
    // this.rasaNLUUrl = config.ai.rasaNluUrl; // RASA NLU removed
    // this.qwen3Url = config.ai.qwen3Url; // Qwen3 removed
    this.llamaIndexService = new LlamaIndexConversationalService();
    this.useLlamaIndex = true; // Always use LlamaIndex now
    
    // Initialize the LlamaIndex service asynchronously
    this.initializeLlamaIndex();
  }

  private async initializeLlamaIndex(): Promise<void> {
    try {
      await this.llamaIndexService.initialize();
      this.logger.info('LlamaIndex service initialized successfully');
    } catch (error) {
      this.logger.warn('Failed to initialize LlamaIndex service, continuing without vector search', {
        metadata: { error: (error as Error).message }
      });
    }
  }

  /**
   * Process a natural language query and return analytics results
   */
  async processQuery(
    query: string,
    sessionId: string,
    userId: string,
    tenantId: string
  ): Promise<AnalyticsResponse> {
    try {
      // Use LlamaIndex with SQLCoder
      if (this.useLlamaIndex) {
        console.log('🤖 [DEBUG] Using LlamaIndex + SQLCoder for query processing');
        return await this.llamaIndexService.processQuery(query, sessionId, userId, tenantId);
      }

      console.log('🔍 [DEBUG] Processing conversational analytics query');
      console.log(`   Query: "${query}"`);
      console.log(`   Session: ${sessionId}`);
      console.log(`   User: ${userId}`);
      console.log(`   Tenant: ${tenantId}`);
      // console.log(`   RASA URL: ${this.rasaNLUUrl}`); // RASA NLU removed
      // console.log(`   Qwen3 URL: ${this.qwen3Url}`); // Qwen3 removed
      
      this.logger.info('Processing conversational analytics query', {
        sessionId,
        userId,
        tenantId,
        metadata: { queryLength: query.length }
      });

      // Get or create conversation context
      const context = this.getOrCreateContext(sessionId, userId, tenantId);

      // Step 1: Extract intent and entities from the query
      console.log('🧠 [DEBUG] Step 1: Extracting intent from query...');
      const intent = await this.extractQueryIntent(query, context);
      console.log(`   Intent Type: ${intent.type}`);
      console.log(`   Confidence: ${intent.confidence}`);
      console.log('   Entities:', JSON.stringify(intent.entities, null, 2));
      
      // Step 2: Retrieve relevant metadata
      console.log('📋 [DEBUG] Step 2: Retrieving metadata...');
      const metadata = await this.retrieveRelevantMetadata(intent, tenantId);
      console.log(`   Metadata found: ${metadata.length} items`);
      
      // Step 3: Generate SQL query
      console.log('⚡ [DEBUG] Step 3: Generating SQL...');
      const sql = await this.generateSQL(intent, metadata, context);
      console.log(`   Generated SQL: ${sql}`);
      
      // Step 4: Execute query
      const results = await this.executeQuery(sql, tenantId);
      
      // Step 5: Generate insights
      const insights = await this.generateInsights(query, results, context);
      
      // Step 6: Generate suggestions for follow-up
      const suggestions = await this.generateSuggestions(query, results, context);
      
      // Step 7: Determine best visualization
      const visualizationType = this.determineVisualization(intent, results);
      
      // Update conversation context
      context.history.push({
        query,
        intent,
        sql,
        results,
        timestamp: new Date().toISOString()
      });

      // Limit history to last 10 interactions
      if (context.history.length > 10) {
        context.history = context.history.slice(-10);
      }

      return {
        query,
        interpretation: this.generateInterpretation(intent),
        sql,
        results,
        insights,
        suggestions,
        visualizationType,
        confidence: intent.confidence
      };

    } catch (error) {
      this.logger.error('Error processing conversational query', {
        sessionId,
        metadata: { 
          errorMessage: (error as Error).message,
          queryText: query
        }
      });
      throw error;
    }
  }

  /**
   * Extract intent and entities from natural language query
   * Now uses rule-based extraction since RASA NLU has been removed
   */
  private async extractQueryIntent(
    query: string,
    context: ConversationContext
  ): Promise<QueryIntent> {
    console.log(`🤖 [DEBUG] Extracting intent from query using rule-based approach`);
    this.logger.info('Extracting intent using rule-based approach', {
      sessionId: context.sessionId,
      metadata: { queryText: query.substring(0, 100) }
    });

    // Use rule-based intent extraction
    const intent = await this.fallbackIntentExtraction(query);
    
    // Enhance with conversation context
    this.enhanceWithConversationContext(intent, context);

    console.log('   Extracted Intent:', JSON.stringify(intent, null, 2));
    return intent;
  }

  // Removed transformRasaToQueryIntent method - RASA NLU no longer used

  /**
   * Enhance intent with conversation context and carryover
   */
  private enhanceWithConversationContext(
    intent: QueryIntent,
    context: ConversationContext
  ): void {
    // If current query lacks context, try to inherit from previous queries
    if (context.history.length > 0) {
      const lastQuery = context.history[context.history.length - 1];
      
      // Carry over department if not specified
      if (!intent.entities.departments?.length && lastQuery.intent.entities.departments?.length) {
        intent.entities.departments = lastQuery.intent.entities.departments;
        this.logger.info('Carried over department from previous query', {
          metadata: { 
            departments: intent.entities.departments?.join(', ')
          }
        });
      }
      
      // Carry over time range for comparative queries
      if (intent.type === 'comparison_query' && !intent.entities.timeRange?.start && lastQuery.intent.entities.timeRange) {
        intent.entities.timeRange = { ...lastQuery.intent.entities.timeRange };
      }
      
      // For trend analysis without explicit metric, use last metric
      if (intent.type === 'trend_analysis' && !intent.entities.metrics?.length && lastQuery.intent.entities.metrics?.length) {
        intent.entities.metrics = lastQuery.intent.entities.metrics;
      }
    }
  }

  /**
   * Retrieve relevant metadata for query generation
   */
  private async retrieveRelevantMetadata(
    intent: QueryIntent,
    tenantId: string
  ): Promise<any> {
    const relevantFields = new Set<string>();
    
    // Add metric fields
    if (intent.entities.metrics) {
      intent.entities.metrics.forEach(m => relevantFields.add(m));
    }
    
    // Add department fields
    if (intent.entities.departments) {
      intent.entities.departments.forEach(d => relevantFields.add(d));
    }
    
    // Add filter fields
    if (intent.entities.filters) {
      intent.entities.filters.forEach(f => relevantFields.add(f.field));
    }

    // Query metadata for these fields
    const fieldList = Array.from(relevantFields);
    if (fieldList.length === 0) {
      return this.getCommonMetadata(tenantId);
    }

    const metadataQuery = `
      SELECT 
        metadata_id,
        resource_type,
        fhir_element,
        display_name,
        data_type,
        category,
        aggregation_hints,
        common_codes
      FROM nexuscare_analytics.fhir_metadata
      WHERE tenant_id = {tenantId:String}
        AND (
          ${fieldList.map((_, i) => `display_name ILIKE {field${i}:String}`).join(' OR ')}
        )
    `;

    const params: any = { tenantId };
    fieldList.forEach((field, i) => {
      params[`field${i}`] = `%${field}%`;
    });

    const result = await this.clickhouse.query(metadataQuery, params);
    return result.data;
  }

  /**
   * Generate SQL query from intent and metadata
   * Now uses template-based generation since Qwen3 has been removed
   */
  private async generateSQL(
    intent: QueryIntent,
    metadata: any[],
    context: ConversationContext
  ): Promise<string> {
    console.log(`🧠 [DEBUG] Generating SQL using template-based approach`);
    this.logger.info('Generating SQL using template-based approach', {
      sessionId: context.sessionId,
      metadata: {
        intentType: intent.type,
        confidence: intent.confidence
      }
    });

    // Use template-based SQL generation
    const generatedSQL = this.generateTemplateSQL(intent, metadata, context.tenantId);
    
    console.log(`✅ [DEBUG] Generated SQL: ${generatedSQL}`);

    // Validate and sanitize the SQL
    this.validateSQL(generatedSQL, context.tenantId);

    return generatedSQL;
  }

  // Removed buildSQLGenerationPrompt method - Qwen3 no longer used

  // Removed getHealthcareAnalyticsSystemPrompt method - Qwen3 no longer used

  // Removed extractSQLFromText method - Qwen3 no longer used

  /**
   * Execute the generated SQL query
   */
  private async executeQuery(sql: string, tenantId: string): Promise<any[]> {
    try {
      // Add query timeout and resource limits - SETTINGS must come after the query in ClickHouse
      const wrappedSQL = `
        ${sql}
        SETTINGS 
          max_execution_time = 30,
          max_memory_usage = 10000000000,
          max_rows_to_read = 1000000
      `;

      const result = await this.clickhouse.query(wrappedSQL, { tenantId });
      return result.data;

    } catch (error) {
      this.logger.error('Query execution failed', {
        metadata: {
          errorMessage: (error as Error).message,
          sql
        }
      });
      throw new Error('Failed to execute analytics query. Please try rephrasing your question.');
    }
  }

  /**
   * Generate insights from query results
   */
  private async generateInsights(
    query: string,
    results: any[],
    context: ConversationContext
  ): Promise<string[]> {
    if (!results || results.length === 0) {
      return ['No data found for your query. Try adjusting the time range or filters.'];
    }

    try {
      // Prepare data summary for insight generation
      const dataSummary = {
        query,
        resultCount: results.length,
        columns: Object.keys(results[0] || {}),
        sampleData: results.slice(0, 5),
        statistics: this.calculateBasicStats(results)
      };

      // Call AI Gateway for insight generation
      const response = await axios.post(`${this.aiGatewayUrl}/api/generate-insights`, {
        dataSummary,
        domain: 'healthcare',
        insightTypes: ['trends', 'anomalies', 'comparisons', 'recommendations'],
        maxInsights: 5
      });

      return response.data.insights || [];

    } catch (error) {
      this.logger.warn('Failed to generate AI insights, using basic analysis', {
        metadata: {
          errorMessage: (error as Error).message
        }
      });
      return this.generateBasicInsights(results);
    }
  }

  /**
   * Generate follow-up query suggestions
   */
  private async generateSuggestions(
    query: string,
    results: any[],
    context: ConversationContext
  ): Promise<string[]> {
    const suggestions: string[] = [];

    // Time-based suggestions
    if (!query.toLowerCase().includes('trend') && results.length > 1) {
      suggestions.push('Show me the trend over the last 30 days');
    }

    // Comparison suggestions
    if (!query.toLowerCase().includes('compar')) {
      suggestions.push('Compare this with the previous period');
    }

    // Drill-down suggestions
    if (results.length > 10) {
      suggestions.push('Show me the top 5 by value');
      suggestions.push('Break this down by department');
    }

    // Context-aware suggestions based on previous queries
    if (context.history.length > 0) {
      const lastIntent = context.history[context.history.length - 1].intent;
      if (lastIntent.entities.metrics?.includes('wait_time')) {
        suggestions.push('What factors are contributing to long wait times?');
      }
      if (lastIntent.entities.metrics?.includes('cost')) {
        suggestions.push('Show me cost optimization opportunities');
      }
    }

    return suggestions.slice(0, 3);
  }

  /**
   * Helper methods
   */

  private parseTimeEntity(timeValue: string, timeRange: any): void {
    const lowerValue = timeValue.toLowerCase();
    const now = new Date();
    
    if (lowerValue.includes('today')) {
      timeRange.start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
      timeRange.end = now.toISOString();
    } else if (lowerValue.includes('yesterday')) {
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      timeRange.start = new Date(yesterday.getFullYear(), yesterday.getMonth(), yesterday.getDate()).toISOString();
      timeRange.end = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
    } else if (lowerValue.includes('last week')) {
      const lastWeek = new Date(now);
      lastWeek.setDate(lastWeek.getDate() - 7);
      timeRange.start = lastWeek.toISOString();
      timeRange.end = now.toISOString();
    } else if (lowerValue.includes('last month')) {
      const lastMonth = new Date(now);
      lastMonth.setMonth(lastMonth.getMonth() - 1);
      timeRange.start = lastMonth.toISOString();
      timeRange.end = now.toISOString();
    } else if (lowerValue.includes('this month')) {
      timeRange.start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
      timeRange.end = now.toISOString();
    }
  }

  private processFilterEntity(entity: any, filters: Array<{ field: string; operator: string; value: any }>): void {
    // For now, create a simple filter structure
    // This could be enhanced to group related filter entities
    const existingFilter = filters.find(f => f.field === entity.value);
    
    if (entity.entity === 'filter_field') {
      if (!existingFilter) {
        filters.push({
          field: entity.value,
          operator: '=',
          value: ''
        });
      }
    } else if (entity.entity === 'filter_operator') {
      const lastFilter = filters[filters.length - 1];
      if (lastFilter) {
        lastFilter.operator = entity.value;
      }
    } else if (entity.entity === 'filter_value') {
      const lastFilter = filters[filters.length - 1];
      if (lastFilter) {
        lastFilter.value = entity.value;
      }
    }
  }

  private getOrCreateContext(
    sessionId: string,
    userId: string,
    tenantId: string
  ): ConversationContext {
    if (!this.contexts.has(sessionId)) {
      this.contexts.set(sessionId, {
        sessionId,
        userId,
        tenantId,
        history: []
      });
    }
    return this.contexts.get(sessionId)!;
  }

  private classifyQueryType(query: string, extracted: any): QueryIntent['type'] {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('compar') || lowerQuery.includes('versus')) {
      return 'comparison_query';
    }
    if (lowerQuery.includes('trend') || lowerQuery.includes('over time')) {
      return 'trend_analysis';
    }
    if (lowerQuery.includes('total') || lowerQuery.includes('sum') || lowerQuery.includes('count')) {
      return 'aggregation_query';
    }
    if (lowerQuery.includes('filter') || lowerQuery.includes('where') || lowerQuery.includes('only')) {
      return 'filter_query';
    }
    if (extracted.metrics && extracted.metrics.length > 0) {
      return 'metric_query';
    }
    
    return 'unknown';
  }

  private parseFilters(filters: any[]): Array<{ field: string; operator: string; value: any }> {
    return filters.map(f => ({
      field: f.field || f.name,
      operator: f.operator || '=',
      value: f.value
    }));
  }

  private parseTimeRange(timeExpressions: any[]): { start?: string; end?: string; granularity?: string } {
    // Simple time range parsing - can be enhanced with more sophisticated NLP
    const range: any = {};
    
    timeExpressions.forEach(expr => {
      if (expr.type === 'absolute') {
        if (expr.role === 'start') range.start = expr.value;
        if (expr.role === 'end') range.end = expr.value;
      }
      if (expr.type === 'relative') {
        // Handle "last 30 days", "this month", etc.
        const now = new Date();
        if (expr.value.includes('day')) {
          const days = parseInt(expr.value.match(/\d+/)?.[0] || '1');
          range.start = new Date(now.getTime() - days * 24 * 60 * 60 * 1000).toISOString();
          range.end = now.toISOString();
        }
      }
      if (expr.granularity) {
        range.granularity = expr.granularity;
      }
    });
    
    return range;
  }

  private enhanceWithHealthcareContext(intent: QueryIntent, query: string): void {
    const lowerQuery = query.toLowerCase();
    
    // Healthcare-specific metric recognition
    const healthcareMetrics = {
      'wait time': ['wait_time', 'ed_wait_time'],
      'length of stay': ['los', 'length_of_stay'],
      'readmission': ['readmission_rate', '30_day_readmission'],
      'mortality': ['mortality_rate', 'death_rate'],
      'infection': ['infection_rate', 'hai_rate'],
      'satisfaction': ['patient_satisfaction', 'hcahps_score']
    };

    Object.entries(healthcareMetrics).forEach(([term, metrics]) => {
      if (lowerQuery.includes(term) && !intent.entities.metrics?.length) {
        intent.entities.metrics = metrics;
      }
    });

    // Department recognition
    const departments = ['emergency', 'icu', 'surgery', 'cardiology', 'radiology'];
    departments.forEach(dept => {
      if (lowerQuery.includes(dept)) {
        intent.entities.filters = intent.entities.filters || [];
        intent.entities.filters.push({
          field: 'department',
          operator: '=',
          value: dept
        });
      }
    });
  }

  private async fallbackIntentExtraction(query: string): Promise<QueryIntent> {
    // Enhanced rule-based intent extraction as fallback
    const intent: QueryIntent = {
      type: 'aggregation_query',
      entities: {
        metrics: [],
        departments: [],
        patientGroups: [],
        filters: [],
        timeRange: {},
        aggregations: ['count'],
        comparison: undefined
      },
      confidence: 0.7
    };

    const lowerQuery = query.toLowerCase();

    // Patient queries
    if (lowerQuery.includes('patient')) {
      if (lowerQuery.includes('count') || lowerQuery.includes('total') || lowerQuery.includes('how many')) {
        intent.entities.metrics = ['patient_count'];
        intent.type = 'aggregation_query';
      }
    }

    // Encounter queries
    if (lowerQuery.includes('encounter')) {
      intent.entities.metrics = ['encounter_count'];
      intent.type = 'aggregation_query';
    }

    // Bed/Capacity queries
    if (lowerQuery.includes('bed') || lowerQuery.includes('capacity') || lowerQuery.includes('icu') || lowerQuery.includes('room')) {
      intent.entities.metrics = ['bed_capacity'];
      intent.type = 'capacity_query';
    }

    // Observation queries
    if (lowerQuery.includes('observation') || lowerQuery.includes('vital') || lowerQuery.includes('lab')) {
      intent.entities.metrics = ['observation_count'];
      intent.type = 'aggregation_query';
    }

    // Resource type queries
    if (lowerQuery.includes('resource') || lowerQuery.includes('type')) {
      intent.entities.metrics = ['resource_summary'];
      intent.type = 'aggregation_query';
    }

    // Default to total count if no specific metric found
    if (!intent.entities.metrics?.length) {
      intent.entities.metrics = ['total_count'];
    }

    return intent;
  }

  private async getCommonMetadata(tenantId: string): Promise<any[]> {
    const query = `
      SELECT 
        metadata_id,
        resource_type,
        fhir_element,
        display_name,
        data_type,
        category,
        aggregation_hints
      FROM nexuscare_analytics.fhir_metadata
      WHERE tenant_id = {tenantId:String}
        AND resource_type IN ('Patient', 'Encounter', 'Observation')
      LIMIT 50
    `;
    
    const result = await this.clickhouse.query(query, { tenantId });
    return result.data;
  }

  private validateSQL(sql: string, tenantId: string): void {
    const lowerSQL = sql.toLowerCase();
    
    // Security checks
    if (lowerSQL.includes('drop') || lowerSQL.includes('delete') || lowerSQL.includes('truncate')) {
      throw new Error('Destructive operations are not allowed');
    }
    
    // Ensure tenant isolation
    if (!sql.includes('tenant_id')) {
      throw new Error('Query must include tenant isolation');
    }
    
    // Check for valid tenant ID
    if (!sql.includes(tenantId)) {
      throw new Error('Query must be scoped to current tenant');
    }
  }

  private generateTemplateSQL(
    intent: QueryIntent,
    metadata: any[],
    tenantId: string
  ): string {
    // Enhanced pattern-based SQL generation for healthcare queries
    const metrics = intent.entities.metrics || [];
    const primaryMetric = metrics[0] || '';
    
    // Patient count queries
    if (primaryMetric === 'patient_count' || primaryMetric.includes('patient')) {
      return `SELECT COUNT(*) as patient_count FROM nexuscare_analytics.fhir_events WHERE tenant_id = '${tenantId}' AND resource_type = 'Patient'`;
    }
    
    // Encounter queries
    if (primaryMetric === 'encounter_count' || primaryMetric.includes('encounter')) {
      return `SELECT COUNT(*) as encounter_count FROM nexuscare_analytics.fhir_events WHERE tenant_id = '${tenantId}' AND resource_type = 'Encounter'`;
    }
    
    // Bed/Capacity queries - For now, return location/bed data
    if (primaryMetric === 'bed_capacity' || primaryMetric.includes('bed') || primaryMetric.includes('capacity') || primaryMetric.includes('icu')) {
      return `SELECT COUNT(*) as bed_capacity, 'Mock ICU beds available' as note FROM nexuscare_analytics.fhir_events WHERE tenant_id = '${tenantId}' AND resource_type = 'Location'`;
    }
    
    // Observation queries
    if (primaryMetric === 'observation_count' || primaryMetric.includes('observation') || primaryMetric.includes('vital') || primaryMetric.includes('lab')) {
      return `SELECT COUNT(*) as observation_count FROM nexuscare_analytics.fhir_events WHERE tenant_id = '${tenantId}' AND resource_type = 'Observation'`;
    }
    
    // Resource type summary
    if (primaryMetric === 'resource_summary' || primaryMetric.includes('resource') || primaryMetric.includes('type') || primaryMetric.includes('summary')) {
      return `SELECT resource_type, COUNT(*) as count FROM nexuscare_analytics.fhir_events WHERE tenant_id = '${tenantId}' GROUP BY resource_type ORDER BY count DESC`;
    }
    
    // Default: total count of all events
    return `SELECT COUNT(*) as total_count FROM nexuscare_analytics.fhir_events WHERE tenant_id = '${tenantId}'`;
  }

  private calculateBasicStats(results: any[]): any {
    if (!results.length) return {};
    
    const stats: any = {};
    const columns = Object.keys(results[0]);
    
    columns.forEach(col => {
      const values = results.map(r => r[col]).filter(v => typeof v === 'number');
      if (values.length > 0) {
        stats[col] = {
          min: Math.min(...values),
          max: Math.max(...values),
          avg: values.reduce((a, b) => a + b, 0) / values.length,
          count: values.length
        };
      }
    });
    
    return stats;
  }

  private generateBasicInsights(results: any[]): string[] {
    const insights: string[] = [];
    
    if (results.length === 0) {
      return ['No data found for the specified criteria.'];
    }
    
    // Generate basic statistical insights
    const stats = this.calculateBasicStats(results);
    Object.entries(stats).forEach(([col, stat]: [string, any]) => {
      if (stat.avg) {
        insights.push(`Average ${col}: ${stat.avg.toFixed(2)} (range: ${stat.min} - ${stat.max})`);
      }
    });
    
    // Add result count insight
    insights.push(`Found ${results.length} matching records.`);
    
    return insights.slice(0, 3);
  }

  private generateInterpretation(intent: QueryIntent): string {
    const parts: string[] = [];
    
    parts.push(`I understood your query as a ${intent.type} request`);
    
    if (intent.entities.metrics?.length) {
      parts.push(`for ${intent.entities.metrics.join(', ')}`);
    }
    
    if (intent.entities.filters?.length) {
      const filterDesc = intent.entities.filters
        .map(f => `${f.field} ${f.operator} ${f.value}`)
        .join(' and ');
      parts.push(`filtered by ${filterDesc}`);
    }
    
    if (intent.entities.timeRange?.start) {
      parts.push(`from ${intent.entities.timeRange.start} to ${intent.entities.timeRange.end || 'now'}`);
    }
    
    return parts.join(' ') + '.';
  }

  private determineVisualization(
    intent: QueryIntent,
    results: any[]
  ): 'bar' | 'line' | 'pie' | 'table' | 'metric' {
    // Single value - use metric display
    if (results.length === 1 && Object.keys(results[0]).length === 1) {
      return 'metric';
    }
    
    // Time series - use line chart
    if (intent.type === 'trend_analysis' || intent.entities.timeRange?.granularity) {
      return 'line';
    }
    
    // Comparison or distribution - use bar chart
    if (intent.type === 'comparison_query' || intent.entities.departments?.length) {
      return 'bar';
    }
    
    // Proportions - use pie chart
    if (results.length <= 10 && intent.entities.aggregations?.includes('percentage')) {
      return 'pie';
    }
    
    // Default to table for complex data
    return 'table';
  }

  /**
   * Clear conversation context for a session
   */
  clearContext(sessionId: string): void {
    if (this.useLlamaIndex) {
      this.llamaIndexService.clearContext(sessionId);
    }
    this.contexts.delete(sessionId);
  }

  /**
   * Get conversation history for a session
   */
  getHistory(sessionId: string): Array<any> {
    if (this.useLlamaIndex) {
      return this.llamaIndexService.getHistory(sessionId);
    }
    const context = this.contexts.get(sessionId);
    return context?.history || [];
  }

  /**
   * Get service health status
   */
  async getHealth(): Promise<any> {
    if (this.useLlamaIndex) {
      return await this.llamaIndexService.getHealth();
    }
    
    return {
      service: 'ConversationalAnalytics',
      status: 'healthy',
      mode: 'llamaindex'
    };
  }
}