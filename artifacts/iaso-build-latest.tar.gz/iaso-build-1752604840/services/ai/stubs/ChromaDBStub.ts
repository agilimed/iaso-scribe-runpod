/**
 * ChromaDB Stub
 * 
 * Provides mock implementation when chromadb package is not installed
 */

export class ChromaClient {
  constructor() {
    console.warn('Using ChromaDB stub - install chromadb package for full functionality');
  }

  async heartbeat() {
    return { status: 'mock' };
  }

  async createCollection() {
    return new Collection();
  }

  async getOrCreateCollection() {
    return new Collection();
  }

  async listCollections() {
    return [];
  }

  async deleteCollection() {
    return;
  }
}

export class Collection {
  name = 'mock-collection';

  async add() {
    return;
  }

  async get() {
    return {
      ids: [],
      embeddings: null,
      metadatas: null,
      documents: null
    };
  }

  async query() {
    return {
      ids: [[]],
      embeddings: null,
      metadatas: [[]],
      documents: [[]],
      distances: [[]]
    };
  }

  async delete() {
    return;
  }

  async update() {
    return;
  }

  async count() {
    return 0;
  }
}

export interface QueryResponse {
  ids: string[][];
  embeddings: number[][][] | null;
  metadatas: (Record<string, any> | null)[][] | null;
  documents: (string | null)[][] | null;
  distances: number[][] | null;
}