/**
 * Transformers Stub
 * 
 * Provides mock implementation when @xenova/transformers package is not installed
 */

export async function pipeline(task: string, model: string, options?: any) {
  console.warn('Using Transformers stub - install @xenova/transformers package for full functionality');
  
  // Return a mock pipeline function
  return async function(text: string, options?: any) {
    // Return mock embeddings
    const mockEmbedding = new Float32Array(384).fill(0.1); // all-MiniLM-L6-v2 has 384 dimensions
    return {
      data: mockEmbedding,
      pooling: options?.pooling || 'mean',
      normalize: options?.normalize || true
    };
  };
}

export type Pipeline = ReturnType<typeof pipeline>;