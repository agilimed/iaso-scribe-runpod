/**
 * Clinical Document Processor
 * 
 * Processes and chunks clinical documents for the RAG system
 * with healthcare-specific context preservation
 */

import { logger } from '../../utils/logger';

import { VectorDocument } from './VectorDatabaseService';

export interface ProcessingOptions {
  chunkSize?: number;
  chunkOverlap?: number;
  preserveContext?: boolean;
  extractMetadata?: boolean;
  cleanText?: boolean;
}

export interface DocumentChunk {
  content: string;
  metadata: {
    chunkIndex: number;
    totalChunks: number;
    startOffset: number;
    endOffset: number;
    section?: string;
    subsection?: string;
    clinicalContext?: string[];
    [key: string]: any;
  };
}

export interface ProcessedDocument {
  chunks: DocumentChunk[];
  metadata: {
    title?: string;
    type: string;
    specialty?: string;
    version?: string;
    effectiveDate?: Date;
    keywords?: string[];
    icd10Codes?: string[];
    cptCodes?: string[];
    medications?: string[];
    [key: string]: any;
  };
}

export class ClinicalDocumentProcessor {
  private readonly defaultChunkSize = 512;
  private readonly defaultOverlap = 50;
  
  // Medical terminology patterns
  private readonly medicalPatterns = {
    icd10: /\b[A-Z]\d{2}(?:\.\d{1,2})?\b/g,
    cpt: /\b\d{5}\b/g,
    medication: /\b(?:[A-Z][a-z]+(?:azole|mycin|cillin|pril|sartan|statin|olol|azepam|pam|zolam))\b/g,
    dosage: /\b\d+(?:\.\d+)?\s*(?:mg|mcg|g|ml|units?|IU)\b/gi,
    vital: /\b(?:BP|HR|RR|Temp|O2|SpO2)\s*:?\s*\d+/gi
  };

  // Section headers commonly found in clinical documents
  private readonly sectionHeaders = [
    'Chief Complaint',
    'History of Present Illness',
    'Past Medical History',
    'Medications',
    'Allergies',
    'Physical Examination',
    'Assessment',
    'Plan',
    'Diagnosis',
    'Treatment',
    'Procedure',
    'Findings',
    'Recommendations',
    'Follow-up',
    'Contraindications',
    'Warnings',
    'Dosage and Administration',
    'Adverse Reactions',
    'Clinical Pharmacology'
  ];

  /**
   * Process a clinical document into chunks
   */
  async processDocument(
    content: string,
    documentType: string,
    options: ProcessingOptions = {}
  ): Promise<ProcessedDocument> {
    const {
      chunkSize = this.defaultChunkSize,
      chunkOverlap = this.defaultOverlap,
      preserveContext = true,
      extractMetadata = true,
      cleanText = true
    } = options;

    try {
      // Clean and normalize text if requested
      const processedContent = cleanText ? this.cleanText(content) : content;

      // Extract metadata from document
      const metadata = extractMetadata 
        ? await this.extractMetadata(processedContent, documentType)
        : { type: documentType };

      // Extract sections
      const sections = this.extractSections(processedContent);

      // Create chunks
      const chunks: DocumentChunk[] = [];
      
      if (preserveContext && sections.length > 0) {
        // Chunk by sections to preserve context
        chunks.push(...this.chunkBySections(sections, chunkSize, chunkOverlap));
      } else {
        // Simple chunking
        chunks.push(...this.simpleChunk(processedContent, chunkSize, chunkOverlap));
      }

      // Enhance chunks with clinical context
      const enhancedChunks = chunks.map(chunk => 
        this.enhanceChunkWithContext(chunk, processedContent)
      );

      return {
        chunks: enhancedChunks,
        metadata
      };

    } catch (error) {
      logger.error('Failed to process clinical document', error as Error);
      throw error;
    }
  }

  /**
   * Clean and normalize text
   */
  private cleanText(text: string): string {
    return text
      // Remove excessive whitespace
      .replace(/\s+/g, ' ')
      // Remove special characters but preserve medical notation
      .replace(/[^\w\s\-\.,:;\/\(\)\[\]%°]/g, '')
      // Normalize line breaks
      .replace(/\r\n/g, '\n')
      .replace(/\n+/g, '\n')
      .trim();
  }

  /**
   * Extract metadata from document content
   */
  private async extractMetadata(
    content: string,
    documentType: string
  ): Promise<ProcessedDocument['metadata']> {
    const metadata: ProcessedDocument['metadata'] = {
      type: documentType
    };

    // Extract title (usually first line or after "Title:")
    const titleMatch = content.match(/^(?:Title:\s*)?(.+?)[\n\r]/);
    if (titleMatch) {
      metadata.title = titleMatch[1].trim();
    }

    // Extract version
    const versionMatch = content.match(/Version:\s*([^\n\r]+)/i);
    if (versionMatch) {
      metadata.version = versionMatch[1].trim();
    }

    // Extract effective date
    const dateMatch = content.match(/(?:Effective|Date|Updated):\s*(\d{1,2}\/\d{1,2}\/\d{4})/i);
    if (dateMatch) {
      metadata.effectiveDate = new Date(dateMatch[1]);
    }

    // Extract ICD-10 codes
    const icd10Codes = Array.from(content.matchAll(this.medicalPatterns.icd10))
      .map(match => match[0]);
    if (icd10Codes.length > 0) {
      metadata.icd10Codes = [...new Set(icd10Codes)];
    }

    // Extract CPT codes
    const cptCodes = Array.from(content.matchAll(this.medicalPatterns.cpt))
      .map(match => match[0]);
    if (cptCodes.length > 0) {
      metadata.cptCodes = [...new Set(cptCodes)];
    }

    // Extract medications
    const medications = Array.from(content.matchAll(this.medicalPatterns.medication))
      .map(match => match[0]);
    if (medications.length > 0) {
      metadata.medications = [...new Set(medications)];
    }

    // Extract keywords based on frequency
    metadata.keywords = this.extractKeywords(content);

    // Determine specialty based on content
    metadata.specialty = this.inferSpecialty(content);

    return metadata;
  }

  /**
   * Extract sections from document
   */
  private extractSections(content: string): Array<{header: string, content: string}> {
    const sections: Array<{header: string, content: string}> = [];
    
    // Create regex pattern for section headers
    const headerPattern = new RegExp(
      `^(${this.sectionHeaders.join('|')}):?\\s*$`,
      'gmi'
    );

    const lines = content.split('\n');
    let currentSection: {header: string, content: string} | null = null;

    for (const line of lines) {
      const headerMatch = line.match(headerPattern);
      
      if (headerMatch) {
        if (currentSection) {
          sections.push(currentSection);
        }
        currentSection = {
          header: headerMatch[1],
          content: ''
        };
      } else if (currentSection) {
        currentSection.content += line + '\n';
      }
    }

    if (currentSection) {
      sections.push(currentSection);
    }

    return sections;
  }

  /**
   * Chunk document by sections
   */
  private chunkBySections(
    sections: Array<{header: string, content: string}>,
    chunkSize: number,
    overlap: number
  ): DocumentChunk[] {
    const chunks: DocumentChunk[] = [];
    let chunkIndex = 0;
    let globalOffset = 0;

    for (const section of sections) {
      const sectionChunks = this.simpleChunk(
        section.content,
        chunkSize,
        overlap,
        globalOffset
      );

      for (const chunk of sectionChunks) {
        chunks.push({
          ...chunk,
          metadata: {
            ...chunk.metadata,
            chunkIndex: chunkIndex++,
            section: section.header
          }
        });
      }

      globalOffset += section.content.length;
    }

    // Update total chunks count
    chunks.forEach(chunk => {
      chunk.metadata.totalChunks = chunks.length;
    });

    return chunks;
  }

  /**
   * Simple text chunking
   */
  private simpleChunk(
    text: string,
    chunkSize: number,
    overlap: number,
    startOffset: number = 0
  ): DocumentChunk[] {
    const chunks: DocumentChunk[] = [];
    const sentences = this.splitIntoSentences(text);
    
    let currentChunk = '';
    let currentOffset = startOffset;
    let chunkStartOffset = startOffset;

    for (const sentence of sentences) {
      if (currentChunk.length + sentence.length <= chunkSize) {
        currentChunk += sentence + ' ';
        currentOffset += sentence.length + 1;
      } else {
        if (currentChunk.trim()) {
          chunks.push({
            content: currentChunk.trim(),
            metadata: {
              chunkIndex: 0, // Will be updated later
              totalChunks: 0, // Will be updated later
              startOffset: chunkStartOffset,
              endOffset: currentOffset
            }
          });
        }

        // Start new chunk with overlap
        const overlapText = this.getOverlapText(currentChunk, overlap);
        currentChunk = overlapText + sentence + ' ';
        chunkStartOffset = currentOffset - overlapText.length;
        currentOffset += sentence.length + 1;
      }
    }

    // Add last chunk
    if (currentChunk.trim()) {
      chunks.push({
        content: currentChunk.trim(),
        metadata: {
          chunkIndex: 0,
          totalChunks: 0,
          startOffset: chunkStartOffset,
          endOffset: currentOffset
        }
      });
    }

    return chunks;
  }

  /**
   * Split text into sentences
   */
  private splitIntoSentences(text: string): string[] {
    // Clinical text often has abbreviations, so we need careful sentence splitting
    const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];
    
    // Post-process to handle medical abbreviations
    const processed: string[] = [];
    let current = '';
    
    for (const sentence of sentences) {
      // Check if this might be an abbreviation
      if (sentence.match(/\b(?:Dr|Mr|Mrs|Ms|Prof|Sr|Jr|vs|etc|i\.e|e\.g)\./i)) {
        current += sentence + ' ';
      } else {
        if (current) {
          processed.push(current + sentence);
          current = '';
        } else {
          processed.push(sentence);
        }
      }
    }
    
    if (current) {
      processed.push(current);
    }
    
    return processed;
  }

  /**
   * Get overlap text from end of chunk
   */
  private getOverlapText(chunk: string, overlapSize: number): string {
    const words = chunk.trim().split(/\s+/);
    const overlapWords = Math.ceil(overlapSize / 5); // Assuming average word length of 5
    return words.slice(-overlapWords).join(' ') + ' ';
  }

  /**
   * Enhance chunk with clinical context
   */
  private enhanceChunkWithContext(
    chunk: DocumentChunk,
    fullDocument: string
  ): DocumentChunk {
    const enhancedChunk = { ...chunk };
    const clinicalContext: string[] = [];

    // Extract medical codes from chunk
    const icd10Matches = chunk.content.match(this.medicalPatterns.icd10);
    if (icd10Matches) {
      clinicalContext.push(...icd10Matches.map(code => `ICD-10: ${code}`));
    }

    const cptMatches = chunk.content.match(this.medicalPatterns.cpt);
    if (cptMatches) {
      clinicalContext.push(...cptMatches.map(code => `CPT: ${code}`));
    }

    // Extract medications with dosages
    const medMatches = chunk.content.match(this.medicalPatterns.medication);
    const doseMatches = chunk.content.match(this.medicalPatterns.dosage);
    if (medMatches) {
      clinicalContext.push(...medMatches.map(med => `Medication: ${med}`));
    }

    // Extract vital signs
    const vitalMatches = chunk.content.match(this.medicalPatterns.vital);
    if (vitalMatches) {
      clinicalContext.push(...vitalMatches.map(vital => `Vital: ${vital}`));
    }

    if (clinicalContext.length > 0) {
      enhancedChunk.metadata.clinicalContext = clinicalContext;
    }

    return enhancedChunk;
  }

  /**
   * Extract keywords using TF-IDF-like approach
   */
  private extractKeywords(text: string, topK: number = 10): string[] {
    // Simple keyword extraction based on frequency
    const words = text.toLowerCase()
      .split(/\s+/)
      .filter(word => word.length > 3)
      .filter(word => !this.isStopWord(word));

    const frequency: Record<string, number> = {};
    for (const word of words) {
      frequency[word] = (frequency[word] || 0) + 1;
    }

    return Object.entries(frequency)
      .sort((a, b) => b[1] - a[1])
      .slice(0, topK)
      .map(([word]) => word);
  }

  /**
   * Check if word is a stop word
   */
  private isStopWord(word: string): boolean {
    const stopWords = new Set([
      'the', 'is', 'at', 'which', 'on', 'and', 'a', 'an',
      'as', 'are', 'been', 'be', 'have', 'has', 'had',
      'were', 'was', 'will', 'with', 'can', 'could',
      'should', 'would', 'may', 'might', 'must', 'shall',
      'to', 'of', 'in', 'for', 'from', 'by', 'about'
    ]);
    return stopWords.has(word);
  }

  /**
   * Infer medical specialty from content
   */
  private inferSpecialty(content: string): string | undefined {
    const specialtyKeywords: Record<string, string[]> = {
      'cardiology': ['cardiac', 'heart', 'ecg', 'ekg', 'myocardial', 'coronary', 'arrhythmia'],
      'neurology': ['neurological', 'brain', 'seizure', 'stroke', 'migraine', 'neuropathy'],
      'oncology': ['cancer', 'tumor', 'chemotherapy', 'radiation', 'metastasis', 'malignant'],
      'pediatrics': ['pediatric', 'child', 'infant', 'adolescent', 'developmental', 'growth'],
      'psychiatry': ['psychiatric', 'mental', 'depression', 'anxiety', 'psychosis', 'therapy'],
      'orthopedics': ['fracture', 'bone', 'joint', 'arthritis', 'spine', 'orthopedic'],
      'emergency': ['emergency', 'trauma', 'acute', 'critical', 'urgent', 'triage']
    };

    const contentLower = content.toLowerCase();
    let bestMatch = { specialty: '', score: 0 };

    for (const [specialty, keywords] of Object.entries(specialtyKeywords)) {
      const score = keywords.filter(keyword => 
        contentLower.includes(keyword)
      ).length;

      if (score > bestMatch.score) {
        bestMatch = { specialty, score };
      }
    }

    return bestMatch.score > 0 ? bestMatch.specialty : undefined;
  }

  /**
   * Convert processed document to vector documents
   */
  toVectorDocuments(
    processedDoc: ProcessedDocument,
    baseMetadata: Partial<VectorDocument['metadata']> = {}
  ): VectorDocument[] {
    return processedDoc.chunks.map((chunk, index) => ({
      id: `${baseMetadata.source || 'unknown'}_chunk_${index}`,
      content: chunk.content,
      metadata: {
        ...baseMetadata,
        ...processedDoc.metadata,
        ...chunk.metadata,
        source: baseMetadata.source || 'clinical_document',
        type: processedDoc.metadata.type as any,
        lastUpdated: new Date()
      }
    }));
  }
}

// Export singleton instance
export const clinicalDocumentProcessor = new ClinicalDocumentProcessor();