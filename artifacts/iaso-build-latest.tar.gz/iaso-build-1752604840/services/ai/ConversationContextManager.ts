/**
 * Conversation Context Manager
 * 
 * Manages conversation state, history, and context for multi-turn conversations
 * in the NexusCare Insights Engine.
 */

import { v4 as uuidv4 } from 'uuid';

import { logger } from '../../utils/logger';
import { getClickHouseClient } from '../clickhouse';
import { RedisService } from '../cache/RedisService';

export interface ConversationContext {
  conversationId: string;
  tenantId: string;
  userId: string;
  startTime: Date;
  lastUpdateTime: Date;
  turnCount: number;
  entities: Map<string, any>;
  topics: string[];
  currentIntent?: string;
  previousQueries: QueryTurn[];
  userPreferences: UserPreferences;
  sessionData: Map<string, any>;
}

export interface QueryTurn {
  turnId: string;
  query: string;
  intent: string;
  entities: any[];
  response: any;
  timestamp: Date;
  executionTimeMs: number;
  wasSuccessful: boolean;
}

export interface UserPreferences {
  preferredVisualization?: 'chart' | 'table' | 'both';
  timeZone?: string;
  dateFormat?: string;
  defaultTimeRange?: string;
  favoriteMetrics?: string[];
}

export interface ContextUpdate {
  entities?: Record<string, any>;
  topics?: string[];
  intent?: string;
  sessionData?: Record<string, any>;
}

export class ConversationContextManager {
  private redis: RedisService;
  private contextTTL: number = 3600; // 1 hour default
  private maxTurns: number = 20; // Maximum conversation turns to keep

  constructor() {
    this.redis = new RedisService();
  }

  /**
   * Initialize a new conversation context
   */
  async initializeContext(
    tenantId: string, 
    userId: string,
    initialData?: Partial<ConversationContext>
  ): Promise<ConversationContext> {
    const conversationId = `conv_${Date.now()}_${uuidv4().substr(0, 8)}`;
    
    const context: ConversationContext = {
      conversationId,
      tenantId,
      userId,
      startTime: new Date(),
      lastUpdateTime: new Date(),
      turnCount: 0,
      entities: new Map(),
      topics: [],
      previousQueries: [],
      userPreferences: await this.loadUserPreferences(userId),
      sessionData: new Map(),
      ...initialData
    };

    // Store in Redis
    await this.saveContext(context);
    
    // Log conversation start
    await this.logConversationEvent(context, 'conversation_started');

    logger.info('Initialized conversation context', { conversationId, userId });
    
    return context;
  }

  /**
   * Get or create conversation context
   */
  async getOrCreateContext(
    conversationId: string | null,
    tenantId: string,
    userId: string
  ): Promise<ConversationContext> {
    if (conversationId) {
      const context = await this.getContext(conversationId);
      if (context) {
        return context;
      }
    }
    
    return this.initializeContext(tenantId, userId);
  }

  /**
   * Get existing conversation context
   */
  async getContext(conversationId: string): Promise<ConversationContext | null> {
    try {
      const data = await this.redis.get(`conversation:${conversationId}`);
      if (!data) {
        return null;
      }

      // Reconstruct Maps from stored data
      const parsed = JSON.parse(data);
      return {
        ...parsed,
        entities: new Map(Object.entries(parsed.entities || {})),
        sessionData: new Map(Object.entries(parsed.sessionData || {})),
        startTime: new Date(parsed.startTime),
        lastUpdateTime: new Date(parsed.lastUpdateTime),
        previousQueries: parsed.previousQueries.map((q: any) => ({
          ...q,
          timestamp: new Date(q.timestamp)
        }))
      };
    } catch (error) {
      logger.error('Failed to get conversation context', error as Error);
      return null;
    }
  }

  /**
   * Update conversation context
   */
  async updateContext(
    conversationId: string,
    update: ContextUpdate
  ): Promise<ConversationContext | null> {
    const context = await this.getContext(conversationId);
    if (!context) {
      logger.warn('Context not found for update', { conversationId });
      return null;
    }

    // Update entities
    if (update.entities) {
      Object.entries(update.entities).forEach(([key, value]) => {
        context.entities.set(key, value);
      });
    }

    // Update topics
    if (update.topics) {
      context.topics = [...new Set([...context.topics, ...update.topics])];
    }

    // Update intent
    if (update.intent) {
      context.currentIntent = update.intent;
    }

    // Update session data
    if (update.sessionData) {
      Object.entries(update.sessionData).forEach(([key, value]) => {
        context.sessionData.set(key, value);
      });
    }

    context.lastUpdateTime = new Date();

    await this.saveContext(context);
    return context;
  }

  /**
   * Add a query turn to the conversation
   */
  async addTurn(
    conversationId: string,
    turn: Omit<QueryTurn, 'turnId'>
  ): Promise<ConversationContext | null> {
    const context = await this.getContext(conversationId);
    if (!context) {
      return null;
    }

    const newTurn: QueryTurn = {
      ...turn,
      turnId: `turn_${context.turnCount + 1}_${Date.now()}`
    };

    context.previousQueries.push(newTurn);
    context.turnCount++;
    
    // Keep only the last N turns
    if (context.previousQueries.length > this.maxTurns) {
      context.previousQueries = context.previousQueries.slice(-this.maxTurns);
    }

    // Extract and merge entities from the new turn
    if (turn.entities && turn.entities.length > 0) {
      turn.entities.forEach(entity => {
        if (entity.type && entity.value) {
          context.entities.set(entity.type, entity.value);
        }
      });
    }

    context.lastUpdateTime = new Date();
    await this.saveContext(context);

    // Store turn in ClickHouse for analytics
    await this.storeTurnInClickHouse(context, newTurn);

    return context;
  }

  /**
   * Get conversation summary
   */
  async getConversationSummary(conversationId: string): Promise<any> {
    const context = await this.getContext(conversationId);
    if (!context) {
      return null;
    }

    const summary = {
      conversationId,
      duration: Date.now() - context.startTime.getTime(),
      turnCount: context.turnCount,
      topics: context.topics,
      entities: Object.fromEntries(context.entities),
      successRate: this.calculateSuccessRate(context.previousQueries),
      averageResponseTime: this.calculateAverageResponseTime(context.previousQueries),
      lastQuery: context.previousQueries[context.previousQueries.length - 1]
    };

    return summary;
  }

  /**
   * Clear context for a conversation
   */
  async clearContext(conversationId: string): Promise<void> {
    const context = await this.getContext(conversationId);
    if (context) {
      await this.logConversationEvent(context, 'conversation_ended');
    }
    
    await this.redis.delete(`conversation:${conversationId}`);
    logger.info('Cleared conversation context', { conversationId });
  }

  /**
   * Get recent conversations for a user
   */
  async getUserConversations(
    userId: string,
    limit: number = 10
  ): Promise<any[]> {
    try {
      const clickhouse = getClickHouseClient();
      const conversations = await clickhouse.query({
        query: `
          SELECT 
            conversation_id,
            MIN(query_time) as start_time,
            MAX(query_time) as end_time,
            COUNT(*) as turn_count,
            arrayDistinct(groupArray(query_intent)) as intents,
            AVG(execution_time_ms) as avg_response_time
          FROM nexuscare_analytics.conversation_history
          WHERE user_id = {userId:String}
            AND query_time >= now() - INTERVAL 7 DAY
          GROUP BY conversation_id
          ORDER BY end_time DESC
          LIMIT {limit:UInt32}
        `,
        query_params: { userId, limit },
        format: 'JSONEachRow'
      }).toPromise();

      return conversations;
    } catch (error) {
      logger.error('Failed to get user conversations', error as Error);
      return [];
    }
  }

  /**
   * Private helper methods
   */

  private async saveContext(context: ConversationContext): Promise<void> {
    const data = {
      ...context,
      entities: Object.fromEntries(context.entities),
      sessionData: Object.fromEntries(context.sessionData)
    };

    await this.redis.setex(
      `conversation:${context.conversationId}`,
      this.contextTTL,
      JSON.stringify(data)
    );
  }

  private async loadUserPreferences(userId: string): Promise<UserPreferences> {
    try {
      const prefs = await this.redis.get(`user_preferences:${userId}`);
      return prefs ? JSON.parse(prefs) : {};
    } catch (error) {
      return {};
    }
  }

  private async storeTurnInClickHouse(
    context: ConversationContext,
    turn: QueryTurn
  ): Promise<void> {
    try {
      const clickhouse = getClickHouseClient();
      await clickhouse.insert({
        table: 'nexuscare_analytics.conversation_history',
        values: [{
          conversation_id: context.conversationId,
          tenant_id: context.tenantId,
          user_id: context.userId,
          turn_id: turn.turnId,
          query_text: turn.query,
          query_intent: turn.intent,
          query_entities: JSON.stringify(turn.entities),
          response_summary: JSON.stringify({
            success: turn.wasSuccessful,
            dataPoints: turn.response?.results?.rowCount || 0
          }),
          execution_time_ms: turn.executionTimeMs,
          query_time: turn.timestamp
        }],
        format: 'JSONEachRow'
      });
    } catch (error) {
      logger.error('Failed to store turn in ClickHouse', error as Error);
    }
  }

  private async logConversationEvent(
    context: ConversationContext,
    event: string
  ): Promise<void> {
    try {
      const clickhouse = getClickHouseClient();
      await clickhouse.insert({
        table: 'nexuscare_analytics.audit_log',
        values: [{
          event_time: new Date(),
          tenant_id: context.tenantId,
          user_id: context.userId,
          event_type: event,
          resource_type: 'conversation',
          resource_id: context.conversationId,
          action: event,
          details: JSON.stringify({
            turnCount: context.turnCount,
            topics: context.topics
          })
        }],
        format: 'JSONEachRow'
      });
    } catch (error) {
      logger.error('Failed to log conversation event', error as Error);
    }
  }

  private calculateSuccessRate(turns: QueryTurn[]): number {
    if (turns.length === 0) return 0;
    const successful = turns.filter(t => t.wasSuccessful).length;
    return Math.round((successful / turns.length) * 100);
  }

  private calculateAverageResponseTime(turns: QueryTurn[]): number {
    if (turns.length === 0) return 0;
    const total = turns.reduce((sum, t) => sum + t.executionTimeMs, 0);
    return Math.round(total / turns.length);
  }

  /**
   * Advanced context features
   */

  /**
   * Infer user intent from conversation history
   */
  async inferIntent(context: ConversationContext): Promise<string> {
    // Analyze recent queries to infer overall intent
    const recentQueries = context.previousQueries.slice(-5);
    const intents = recentQueries.map(q => q.intent);
    
    // Find most common intent
    const intentCounts = intents.reduce((acc, intent) => {
      acc[intent] = (acc[intent] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const dominantIntent = Object.entries(intentCounts)
      .sort(([, a], [, b]) => b - a)[0]?.[0];

    return dominantIntent || 'exploration';
  }

  /**
   * Get contextual suggestions based on conversation history
   */
  async getContextualSuggestions(
    context: ConversationContext
  ): Promise<string[]> {
    const suggestions: string[] = [];

    // Based on entities in context
    if (context.entities.has('condition')) {
      const condition = context.entities.get('condition');
      suggestions.push(`Show me treatment outcomes for ${condition}`);
      suggestions.push(`What's the average length of stay for ${condition} patients?`);
    }

    if (context.entities.has('department')) {
      const dept = context.entities.get('department');
      suggestions.push(`Compare ${dept} performance to other departments`);
      suggestions.push(`Show ${dept} staffing levels over time`);
    }

    // Based on recent queries
    const lastQuery = context.previousQueries[context.previousQueries.length - 1];
    if (lastQuery?.intent === 'trend') {
      suggestions.push('Compare this trend to the same period last year');
      suggestions.push('What factors might be driving this trend?');
    }

    // Time-based suggestions
    if (!context.entities.has('timeRange')) {
      suggestions.push('Show me the same data for last month');
      suggestions.push('How does this compare to our yearly average?');
    }

    return suggestions.slice(0, 3); // Return top 3 suggestions
  }
}

export default ConversationContextManager;