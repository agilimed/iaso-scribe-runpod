import { ResourceTemplateService } from './ResourceTemplateService';
import { PatientTemplate } from './templates/PatientTemplate';
import { ObservationTemplate } from './templates/ObservationTemplate';
import { ConditionTemplate } from './templates/ConditionTemplate';
import { logger } from '../../../utils/logger';

/**
 * Central registry for all FHIR resource templates
 * Manages template registration and provides easy access to the template service
 */
export class TemplateRegistry {
  private static instance: TemplateRegistry;
  private templateService: ResourceTemplateService;

  private constructor() {
    this.templateService = new ResourceTemplateService();
    this.registerAllTemplates();
  }

  static getInstance(): TemplateRegistry {
    if (!TemplateRegistry.instance) {
      TemplateRegistry.instance = new TemplateRegistry();
    }
    return TemplateRegistry.instance;
  }

  getTemplateService(): ResourceTemplateService {
    return this.templateService;
  }

  private registerAllTemplates(): void {
    logger.info('[TemplateRegistry] Registering FHIR resource templates...');
    
    // Register administrative resources
    this.templateService.registerTemplate(new PatientTemplate());
    
    // Register clinical resources
    this.templateService.registerTemplate(new ObservationTemplate());
    this.templateService.registerTemplate(new ConditionTemplate());
    
    // TODO: Register additional templates as they are implemented
    // this.templateService.registerTemplate(new PractitionerTemplate());
    // this.templateService.registerTemplate(new OrganizationTemplate());
    // this.templateService.registerTemplate(new LocationTemplate());
    // this.templateService.registerTemplate(new EncounterTemplate());
    // this.templateService.registerTemplate(new ProcedureTemplate());
    // this.templateService.registerTemplate(new MedicationRequestTemplate());
    // this.templateService.registerTemplate(new MedicationAdministrationTemplate());
    // this.templateService.registerTemplate(new DiagnosticReportTemplate());
    // this.templateService.registerTemplate(new AllergyIntoleranceTemplate());
    
    const registeredCount = this.templateService.getSupportedResourceTypes().length;
    logger.info(`[TemplateRegistry] Successfully registered ${registeredCount} FHIR resource templates`, {
      supportedResourceTypes: this.templateService.getSupportedResourceTypes()
    });
  }

  // Helper method to get template statistics
  getTemplateStats(): {
    totalTemplates: number;
    supportedResourceTypes: string[];
    templatesByPriority: Record<string, number>;
    templatesByChunkType: Record<string, number>;
  } {
    const templates = this.templateService.getAllTemplates();
    const supportedResourceTypes = this.templateService.getSupportedResourceTypes();
    
    const templatesByPriority = templates.reduce((acc, template) => {
      acc[template.priority] = (acc[template.priority] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const templatesByChunkType = templates.reduce((acc, template) => {
      template.chunkTypes.forEach(chunkType => {
        acc[chunkType] = (acc[chunkType] || 0) + 1;
      });
      return acc;
    }, {} as Record<string, number>);
    
    return {
      totalTemplates: templates.length,
      supportedResourceTypes,
      templatesByPriority,
      templatesByChunkType
    };
  }
}

// Export singleton instance for easy access
export const templateRegistry = TemplateRegistry.getInstance();
export const templateService = templateRegistry.getTemplateService();