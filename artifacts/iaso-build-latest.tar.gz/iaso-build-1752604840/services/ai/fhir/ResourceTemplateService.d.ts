export interface ResourceTemplate {
    resourceType: string;
    priority: 'critical' | 'high' | 'medium' | 'low';
    chunkTypes: ChunkType[];
    generateChunks: (resource: any) => ResourceChunk[];
    extractMetadata: (resource: any) => ChunkMetadata;
    clinicalSignificance: (resource: any) => 'critical' | 'abnormal' | 'normal';
}
export interface ResourceChunk {
    id: string;
    content: string;
    type: 'granular_fact' | 'resource_summary' | 'ips_summary';
    clinical_significance: 'critical' | 'abnormal' | 'normal';
    searchable_terms: string[];
    temporal_context: {
        date: string;
        encounter_id?: string;
        episode_id?: string;
    };
    clinical_codes: {
        loinc?: string[];
        icd10?: string[];
        rxnorm?: string[];
        snomed?: string[];
    };
}
export interface ChunkMetadata {
    patient_id: string;
    resource_type: string;
    resource_id: string;
    tenant_id: string;
    clinical_domain: 'labs' | 'medications' | 'procedures' | 'conditions' | 'admin';
    clinical_significance: 'critical' | 'abnormal' | 'normal';
    temporal_context: {
        date: string;
        encounter_id?: string;
        episode_id?: string;
    };
    chunk_type: 'granular_fact' | 'resource_summary' | 'ips_summary';
    chunk_level: 'observation' | 'encounter' | 'patient';
    searchable_codes: string[];
    searchable_values: number[];
    searchable_units: string[];
    reference_ranges?: {
        low?: number;
        high?: number;
        unit?: string;
        interpretation?: string;
    };
}
export type ChunkType = 'granular_fact' | 'resource_summary' | 'ips_summary';
export type ClinicalDomain = 'labs' | 'medications' | 'procedures' | 'conditions' | 'admin';
export type ClinicalSignificance = 'critical' | 'abnormal' | 'normal';
export declare abstract class BaseResourceTemplate implements ResourceTemplate {
    abstract resourceType: string;
    abstract priority: 'critical' | 'high' | 'medium' | 'low';
    abstract chunkTypes: ChunkType[];
    abstract generateChunks(resource: any): ResourceChunk[];
    abstract extractMetadata(resource: any): ChunkMetadata;
    abstract clinicalSignificance(resource: any): ClinicalSignificance;
    protected extractPatientId(resource: any): string;
    protected extractDate(resource: any): string;
    protected extractEncounterId(resource: any): string | undefined;
    protected extractEpisodeId(resource: any): string | undefined;
    protected extractClinicalCodes(resource: any): ResourceChunk['clinical_codes'];
    protected extractSearchableTerms(resource: any): string[];
    protected getNestedValue(obj: any, path: string): any;
    protected createChunk(content: string, type: ChunkType, resource: any, clinical_significance?: ClinicalSignificance): ResourceChunk;
    protected getClinicalDomain(resourceType: string): ClinicalDomain;
}
export declare class ResourceTemplateService {
    private templates;
    constructor();
    private initializeTemplates;
    registerTemplate(template: ResourceTemplate): void;
    getTemplate(resourceType: string): ResourceTemplate | undefined;
    getAllTemplates(): ResourceTemplate[];
    getSupportedResourceTypes(): string[];
    generateChunks(resource: any): Promise<ResourceChunk[]>;
    extractMetadata(resource: any): Promise<ChunkMetadata | null>;
    assessClinicalSignificance(resource: any): Promise<ClinicalSignificance>;
}
//# sourceMappingURL=ResourceTemplateService.d.ts.map