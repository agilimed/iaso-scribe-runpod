"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResourceTemplateService = exports.BaseResourceTemplate = void 0;
const uuid_1 = require("uuid");
const logger_1 = require("../../../utils/logger");
// Base template class
class BaseResourceTemplate {
    // Common utility methods
    extractPatientId(resource) {
        if (resource.resourceType === 'Patient') {
            return resource.id;
        }
        // Handle reference formats
        const patientRef = resource.subject?.reference || resource.patient?.reference;
        if (patientRef) {
            return patientRef.replace('Patient/', '');
        }
        return '';
    }
    extractDate(resource) {
        const dateFields = [
            'effectiveDateTime',
            'onsetDateTime',
            'recordedDate',
            'performedDateTime',
            'authoredOn',
            'date',
            'period?.start',
            'meta?.lastUpdated'
        ];
        for (const field of dateFields) {
            const value = this.getNestedValue(resource, field);
            if (value) {
                return new Date(value).toISOString().split('T')[0];
            }
        }
        return new Date().toISOString().split('T')[0];
    }
    extractEncounterId(resource) {
        const encounterRef = resource.encounter?.reference || resource.context?.reference;
        return encounterRef?.replace('Encounter/', '');
    }
    extractEpisodeId(resource) {
        const episodeRef = resource.episodeOfCare?.reference;
        return episodeRef?.replace('EpisodeOfCare/', '');
    }
    extractClinicalCodes(resource) {
        const codes = {};
        // Extract from code field
        const codeFields = [resource.code, resource.medicationCodeableConcept];
        for (const codeField of codeFields) {
            if (codeField?.coding) {
                for (const coding of codeField.coding) {
                    if (coding.system?.includes('loinc')) {
                        codes.loinc = codes.loinc || [];
                        codes.loinc.push(coding.code);
                    }
                    else if (coding.system?.includes('icd')) {
                        codes.icd10 = codes.icd10 || [];
                        codes.icd10.push(coding.code);
                    }
                    else if (coding.system?.includes('rxnorm')) {
                        codes.rxnorm = codes.rxnorm || [];
                        codes.rxnorm.push(coding.code);
                    }
                    else if (coding.system?.includes('snomed')) {
                        codes.snomed = codes.snomed || [];
                        codes.snomed.push(coding.code);
                    }
                }
            }
        }
        return codes;
    }
    extractSearchableTerms(resource) {
        const terms = [];
        // Extract display names from codings
        const extractFromCoding = (coding) => {
            if (Array.isArray(coding)) {
                coding.forEach(c => {
                    if (c.display)
                        terms.push(c.display.toLowerCase());
                    if (c.code)
                        terms.push(c.code.toLowerCase());
                });
            }
        };
        if (resource.code?.coding) {
            extractFromCoding(resource.code.coding);
        }
        // Extract text values
        if (resource.code?.text) {
            terms.push(resource.code.text.toLowerCase());
        }
        // Extract from value fields
        if (resource.valueString) {
            terms.push(resource.valueString.toLowerCase());
        }
        return [...new Set(terms)]; // Remove duplicates
    }
    getNestedValue(obj, path) {
        return path.split('.').reduce((current, key) => {
            if (key.includes('?')) {
                key = key.replace('?', '');
            }
            return current && current[key];
        }, obj);
    }
    createChunk(content, type, resource, clinical_significance = 'normal') {
        return {
            id: (0, uuid_1.v4)(),
            content,
            type,
            clinical_significance,
            searchable_terms: this.extractSearchableTerms(resource),
            temporal_context: {
                date: this.extractDate(resource),
                encounter_id: this.extractEncounterId(resource),
                episode_id: this.extractEpisodeId(resource)
            },
            clinical_codes: this.extractClinicalCodes(resource)
        };
    }
    getClinicalDomain(resourceType) {
        const domainMap = {
            'Observation': 'labs',
            'DiagnosticReport': 'labs',
            'Medication': 'medications',
            'MedicationRequest': 'medications',
            'MedicationAdministration': 'medications',
            'MedicationDispense': 'medications',
            'MedicationStatement': 'medications',
            'Procedure': 'procedures',
            'Condition': 'conditions',
            'AllergyIntolerance': 'conditions',
            'Patient': 'admin',
            'Practitioner': 'admin',
            'Organization': 'admin',
            'Location': 'admin',
            'Encounter': 'admin',
            'EpisodeOfCare': 'admin'
        };
        return domainMap[resourceType] || 'admin';
    }
}
exports.BaseResourceTemplate = BaseResourceTemplate;
// Service to manage all resource templates
class ResourceTemplateService {
    templates = new Map();
    constructor() {
        this.initializeTemplates();
    }
    initializeTemplates() {
        // Import and register all FHIR resource templates
        const { PatientTemplate } = require('./templates/PatientTemplate');
        const { ObservationTemplate } = require('./templates/ObservationTemplate');
        const { ConditionTemplate } = require('./templates/ConditionTemplate');
        const { PractitionerTemplate } = require('./templates/PractitionerTemplate');
        const { OrganizationTemplate } = require('./templates/OrganizationTemplate');
        const { LocationTemplate } = require('./templates/LocationTemplate');
        const { EncounterTemplate } = require('./templates/EncounterTemplate');
        const { ProcedureTemplate } = require('./templates/ProcedureTemplate');
        const { MedicationRequestTemplate } = require('./templates/MedicationRequestTemplate');
        const { AllergyIntoleranceTemplate } = require('./templates/AllergyIntoleranceTemplate');
        const { AppointmentTemplate } = require('./templates/AppointmentTemplate');
        const { DiagnosticReportTemplate } = require('./templates/DiagnosticReportTemplate');
        const { ImmunizationTemplate } = require('./templates/ImmunizationTemplate');
        const { CarePlanTemplate } = require('./templates/CarePlanTemplate');
        const { GoalTemplate } = require('./templates/GoalTemplate');
        const { ServiceRequestTemplate } = require('./templates/ServiceRequestTemplate');
        const { CompositionTemplate } = require('./templates/CompositionTemplate');
        const { TaskTemplate } = require('./templates/TaskTemplate');
        const { MedicationTemplate } = require('./templates/MedicationTemplate');
        const { MedicationStatementTemplate } = require('./templates/MedicationStatementTemplate');
        const { ClinicalImpressionTemplate } = require('./templates/ClinicalImpressionTemplate');
        const { DocumentReferenceTemplate } = require('./templates/DocumentReferenceTemplate');
        const { EpisodeOfCareTemplate } = require('./templates/EpisodeOfCareTemplate');
        const { ChargeItemTemplate } = require('./templates/ChargeItemTemplate');
        const { HealthcareServiceTemplate } = require('./templates/HealthcareServiceTemplate');
        const { MedicationAdministrationTemplate } = require('./templates/MedicationAdministrationTemplate');
        const { MedicationDispenseTemplate } = require('./templates/MedicationDispenseTemplate');
        const { PractitionerRoleTemplate } = require('./templates/PractitionerRoleTemplate');
        const { QuestionnaireResponseTemplate } = require('./templates/QuestionnaireResponseTemplate');
        const { SupplyDeliveryTemplate } = require('./templates/SupplyDeliveryTemplate');
        const { SubscriptionTemplate } = require('./templates/SubscriptionTemplate');
        // Import business resource templates
        const { AccountTemplate } = require('./templates/business/AccountTemplate');
        const { InvoiceTemplate } = require('./templates/business/InvoiceTemplate');
        const { EmployeeTemplate } = require('./templates/business/EmployeeTemplate');
        const { SupplyItemTemplate } = require('./templates/business/SupplyItemTemplate');
        const { TimeEntryTemplate } = require('./templates/business/TimeEntryTemplate');
        const { IncidentTemplate } = require('./templates/business/IncidentTemplate');
        const { ConsumerExperienceTemplate } = require('./templates/business/ConsumerExperienceTemplate');
        const { CostCenterTemplate } = require('./templates/business/CostCenterTemplate');
        const { MeasureReportTemplate } = require('./templates/business/MeasureReportTemplate');
        const { QualityMeasureTemplate } = require('./templates/business/QualityMeasureTemplate');
        const { ResourceUtilizationTemplate } = require('./templates/business/ResourceUtilizationTemplate');
        const { SupplyRequestTemplate } = require('./templates/business/SupplyRequestTemplate');
        const { CoverageTemplate } = require('./templates/business/CoverageTemplate');
        const { EmployeeFHIRTemplate } = require('./templates/business/EmployeeFHIRTemplate');
        const { InvoiceFHIRTemplate } = require('./templates/business/InvoiceFHIRTemplate');
        const { TimeEntryFHIRTemplate } = require('./templates/business/TimeEntryFHIRTemplate');
        // Register all templates
        this.registerTemplate(new PatientTemplate());
        this.registerTemplate(new ObservationTemplate());
        this.registerTemplate(new ConditionTemplate());
        this.registerTemplate(new PractitionerTemplate());
        this.registerTemplate(new OrganizationTemplate());
        this.registerTemplate(new LocationTemplate());
        this.registerTemplate(new EncounterTemplate());
        this.registerTemplate(new ProcedureTemplate());
        this.registerTemplate(new MedicationRequestTemplate());
        this.registerTemplate(new AllergyIntoleranceTemplate());
        this.registerTemplate(new AppointmentTemplate());
        this.registerTemplate(new DiagnosticReportTemplate());
        this.registerTemplate(new ImmunizationTemplate());
        this.registerTemplate(new CarePlanTemplate());
        this.registerTemplate(new GoalTemplate());
        this.registerTemplate(new ServiceRequestTemplate());
        this.registerTemplate(new CompositionTemplate());
        this.registerTemplate(new TaskTemplate());
        this.registerTemplate(new MedicationTemplate());
        this.registerTemplate(new MedicationStatementTemplate());
        this.registerTemplate(new ClinicalImpressionTemplate());
        this.registerTemplate(new DocumentReferenceTemplate());
        this.registerTemplate(new EpisodeOfCareTemplate());
        this.registerTemplate(new ChargeItemTemplate());
        this.registerTemplate(new HealthcareServiceTemplate());
        this.registerTemplate(new MedicationAdministrationTemplate());
        this.registerTemplate(new MedicationDispenseTemplate());
        this.registerTemplate(new PractitionerRoleTemplate());
        this.registerTemplate(new QuestionnaireResponseTemplate());
        this.registerTemplate(new SupplyDeliveryTemplate());
        this.registerTemplate(new SubscriptionTemplate());
        // Register business templates
        this.registerTemplate(new AccountTemplate());
        this.registerTemplate(new InvoiceTemplate());
        this.registerTemplate(new EmployeeTemplate());
        this.registerTemplate(new SupplyItemTemplate());
        this.registerTemplate(new TimeEntryTemplate());
        this.registerTemplate(new IncidentTemplate());
        this.registerTemplate(new ConsumerExperienceTemplate());
        this.registerTemplate(new CostCenterTemplate());
        this.registerTemplate(new MeasureReportTemplate());
        this.registerTemplate(new QualityMeasureTemplate());
        this.registerTemplate(new ResourceUtilizationTemplate());
        this.registerTemplate(new SupplyRequestTemplate());
        this.registerTemplate(new CoverageTemplate());
        this.registerTemplate(new EmployeeFHIRTemplate());
        this.registerTemplate(new InvoiceFHIRTemplate());
        this.registerTemplate(new TimeEntryFHIRTemplate());
        logger_1.logger.info(`[ResourceTemplateService] Initialized with ${this.templates.size} templates`);
    }
    registerTemplate(template) {
        this.templates.set(template.resourceType, template);
        logger_1.logger.info(`[ResourceTemplateService] Registered template for ${template.resourceType}`);
    }
    getTemplate(resourceType) {
        return this.templates.get(resourceType);
    }
    getAllTemplates() {
        return Array.from(this.templates.values());
    }
    getSupportedResourceTypes() {
        return Array.from(this.templates.keys());
    }
    async generateChunks(resource) {
        const template = this.getTemplate(resource.resourceType);
        if (!template) {
            logger_1.logger.warn(`[ResourceTemplateService] No template found for ${resource.resourceType}`);
            return [];
        }
        try {
            const chunks = template.generateChunks(resource);
            logger_1.logger.debug(`[ResourceTemplateService] Generated ${chunks.length} chunks for ${resource.resourceType}/${resource.id}`);
            return chunks;
        }
        catch (error) {
            logger_1.logger.error(`[ResourceTemplateService] Error generating chunks for ${resource.resourceType}/${resource.id}:`, error);
            return [];
        }
    }
    async extractMetadata(resource) {
        const template = this.getTemplate(resource.resourceType);
        if (!template) {
            return null;
        }
        try {
            return template.extractMetadata(resource);
        }
        catch (error) {
            logger_1.logger.error(`[ResourceTemplateService] Error extracting metadata for ${resource.resourceType}/${resource.id}:`, error);
            return null;
        }
    }
    async assessClinicalSignificance(resource) {
        const template = this.getTemplate(resource.resourceType);
        if (!template) {
            return 'normal';
        }
        try {
            return template.clinicalSignificance(resource);
        }
        catch (error) {
            logger_1.logger.error(`[ResourceTemplateService] Error assessing clinical significance for ${resource.resourceType}/${resource.id}:`, error);
            return 'normal';
        }
    }
}
exports.ResourceTemplateService = ResourceTemplateService;
//# sourceMappingURL=ResourceTemplateService.js.map