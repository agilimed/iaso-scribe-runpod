import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../ResourceTemplateService';

export class QuestionnaireResponseTemplate extends BaseResourceTemplate {
  resourceType = 'QuestionnaireResponse';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.status) {
      chunks.push({
        id: `${resource.id}-status`,
        type: 'granular_fact',
        content: `Response status: ${resource.status}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.questionnaire) {
      chunks.push({
        id: `${resource.id}-questionnaire`,
        type: 'granular_fact',
        content: `Questionnaire: ${resource.questionnaire}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.authored) {
      chunks.push({
        id: `${resource.id}-authored`,
        type: 'granular_fact',
        content: `Completed on: ${resource.authored}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.author) {
      chunks.push({
        id: `${resource.id}-author`,
        type: 'granular_fact',
        content: `Completed by: ${resource.author.display || resource.author.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.source) {
      chunks.push({
        id: `${resource.id}-source`,
        type: 'granular_fact',
        content: `Source: ${resource.source.display || resource.source.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    // Process items recursively
    if (resource.item) {
      this.processItems(resource.item, chunks, resource, '');
    }
    
    // Resource summary
    const totalQuestions = this.countItems(resource.item || []);
    const answeredQuestions = this.countAnsweredItems(resource.item || []);
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Questionnaire Response: ${resource.questionnaire || 'Survey'} for ${resource.subject?.display || 'patient'} - Status: ${resource.status}, ${answeredQuestions}/${totalQuestions} questions answered`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Patient Assessment: ${resource.questionnaire || 'N/A'} - ${resource.status}, Completed: ${resource.authored || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  private processItems(items: any[], chunks: ResourceChunk[], resource: any, prefix: string): void {
    items.forEach((item: any, index: number) => {
      const itemPrefix = prefix ? `${prefix}.${index + 1}` : `${index + 1}`;
      
      if (item.answer && item.answer.length > 0) {
        const answerText = this.formatAnswer(item.answer[0]);
        chunks.push({
          id: `${resource.id}-item-${itemPrefix}`,
          type: 'granular_fact',
          content: `Q${itemPrefix} (${item.linkId}): ${item.text || 'Question'} - Answer: ${answerText}`,
          metadata: this.extractMetadata(resource)
        });
      }
      
      // Process nested items
      if (item.item) {
        this.processItems(item.item, chunks, resource, itemPrefix);
      }
    });
  }

  private formatAnswer(answer: any): string {
    if (answer.valueBoolean !== undefined) return answer.valueBoolean ? 'Yes' : 'No';
    if (answer.valueDecimal !== undefined) return answer.valueDecimal.toString();
    if (answer.valueInteger !== undefined) return answer.valueInteger.toString();
    if (answer.valueDate) return answer.valueDate;
    if (answer.valueDateTime) return answer.valueDateTime;
    if (answer.valueTime) return answer.valueTime;
    if (answer.valueString) return answer.valueString;
    if (answer.valueUri) return answer.valueUri;
    if (answer.valueAttachment) return `Attachment: ${answer.valueAttachment.title || 'File'}`;
    if (answer.valueCoding) return answer.valueCoding.display || answer.valueCoding.code;
    if (answer.valueQuantity) return `${answer.valueQuantity.value} ${answer.valueQuantity.unit || ''}`;
    if (answer.valueReference) return answer.valueReference.display || answer.valueReference.reference;
    return 'No answer';
  }

  private countItems(items: any[]): number {
    let count = 0;
    items.forEach((item: any) => {
      count++;
      if (item.item) {
        count += this.countItems(item.item);
      }
    });
    return count;
  }

  private countAnsweredItems(items: any[]): number {
    let count = 0;
    items.forEach((item: any) => {
      if (item.answer && item.answer.length > 0) {
        count++;
      }
      if (item.item) {
        count += this.countAnsweredItems(item.item);
      }
    });
    return count;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract answer coding values
    const extractAnswerCodes = (items: any[]) => {
      items.forEach((item: any) => {
        if (item.answer) {
          item.answer.forEach((answer: any) => {
            if (answer.valueCoding) {
              codes.push({
                system: answer.valueCoding.system,
                code: answer.valueCoding.code,
                display: answer.valueCoding.display
              });
            }
          });
        }
        if (item.item) {
          extractAnswerCodes(item.item);
        }
      });
    };
    
    if (resource.item) {
      extractAnswerCodes(resource.item);
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.authored,
      clinicalCodes: codes,
      references: [
        ...(resource.subject ? [`${resource.subject.reference}`] : []),
        ...(resource.encounter ? [`${resource.encounter.reference}`] : []),
        ...(resource.author ? [`${resource.author.reference}`] : []),
        ...(resource.source ? [`${resource.source.reference}`] : []),
        ...(resource.basedOn ? resource.basedOn.map((b: any) => b.reference) : []),
        ...(resource.partOf ? resource.partOf.map((p: any) => p.reference) : [])
      ],
      tags: [
        'questionnaire-response',
        'patient-assessment',
        'survey-response',
        ...(resource.status ? [resource.status] : []),
        ...(resource.questionnaire ? ['has-questionnaire'] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    // Incomplete responses
    if (resource.status === 'in-progress' || resource.status === 'stopped') return 'abnormal';
    
    // Error responses
    if (resource.status === 'entered-in-error') return 'abnormal';
    
    // Check for critical answers (looking for specific patterns in answers)
    let hasCriticalAnswer = false;
    const checkAnswers = (items: any[]) => {
      items.forEach((item: any) => {
        if (item.answer) {
          item.answer.forEach((answer: any) => {
            // Check for high scores or concerning text
            if (answer.valueInteger && answer.valueInteger > 8 && item.text?.toLowerCase().includes('pain')) {
              hasCriticalAnswer = true;
            }
            if (answer.valueString) {
              const text = answer.valueString.toLowerCase();
              if (text.includes('severe') || text.includes('emergency') || text.includes('urgent')) {
                hasCriticalAnswer = true;
              }
            }
            if (answer.valueCoding?.display) {
              const display = answer.valueCoding.display.toLowerCase();
              if (display.includes('severe') || display.includes('critical')) {
                hasCriticalAnswer = true;
              }
            }
          });
        }
        if (item.item) {
          checkAnswers(item.item);
        }
      });
    };
    
    if (resource.item) {
      checkAnswers(resource.item);
    }
    
    if (hasCriticalAnswer) return 'critical';
    
    if (resource.status === 'completed') return 'normal';
    
    return 'normal';
  }
}