import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../ResourceTemplateService';

export class SupplyDeliveryTemplate extends BaseResourceTemplate {
  resourceType = 'SupplyDelivery';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.status) {
      chunks.push({
        id: `${resource.id}-status`,
        type: 'granular_fact',
        content: `Delivery status: ${resource.status}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.type) {
      chunks.push({
        id: `${resource.id}-type`,
        type: 'granular_fact',
        content: `Delivery type: ${resource.type.text || resource.type.coding?.[0]?.display}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.suppliedItem) {
      const item = resource.suppliedItem;
      chunks.push({
        id: `${resource.id}-item`,
        type: 'granular_fact',
        content: `Supplied item: ${item.itemCodeableConcept?.text || item.itemCodeableConcept?.coding?.[0]?.display || item.itemReference?.display || 'Unknown item'} - Quantity: ${item.quantity?.value || 'N/A'} ${item.quantity?.unit || ''}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.occurrencePeriod) {
      chunks.push({
        id: `${resource.id}-occurrence`,
        type: 'granular_fact',
        content: `Delivery period: ${resource.occurrencePeriod.start} to ${resource.occurrencePeriod.end || 'ongoing'}`,
        metadata: this.extractMetadata(resource)
      });
    } else if (resource.occurrenceDateTime) {
      chunks.push({
        id: `${resource.id}-occurrence`,
        type: 'granular_fact',
        content: `Delivered on: ${resource.occurrenceDateTime}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.supplier) {
      chunks.push({
        id: `${resource.id}-supplier`,
        type: 'granular_fact',
        content: `Supplier: ${resource.supplier.display || resource.supplier.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.destination) {
      chunks.push({
        id: `${resource.id}-destination`,
        type: 'granular_fact',
        content: `Destination: ${resource.destination.display || resource.destination.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.receiver) {
      resource.receiver.forEach((rec: any, index: number) => {
        chunks.push({
          id: `${resource.id}-receiver-${index}`,
          type: 'granular_fact',
          content: `Receiver ${index + 1}: ${rec.display || rec.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.basedOn) {
      resource.basedOn.forEach((based: any, index: number) => {
        chunks.push({
          id: `${resource.id}-based-on-${index}`,
          type: 'granular_fact',
          content: `Based on: ${based.display || based.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.partOf) {
      resource.partOf.forEach((part: any, index: number) => {
        chunks.push({
          id: `${resource.id}-part-of-${index}`,
          type: 'granular_fact',
          content: `Part of: ${part.display || part.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Supply Delivery: ${resource.suppliedItem?.itemCodeableConcept?.text || 'Supply'} - ${resource.suppliedItem?.quantity?.value || 'N/A'} ${resource.suppliedItem?.quantity?.unit || ''} delivered to ${resource.destination?.display || resource.patient?.display || 'recipient'}, Status: ${resource.status}`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Supply Delivery: ${resource.suppliedItem?.itemCodeableConcept?.text || 'N/A'} - Quantity: ${resource.suppliedItem?.quantity?.value || 0} ${resource.suppliedItem?.quantity?.unit || 'units'}, ${resource.status}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract type codes
    if (resource.type) {
      codes.push(...this.extractClinicalCodes(resource.type));
    }
    
    // Extract supplied item codes
    if (resource.suppliedItem?.itemCodeableConcept) {
      codes.push(...this.extractClinicalCodes(resource.suppliedItem.itemCodeableConcept));
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.occurrenceDateTime || resource.occurrencePeriod?.start,
      clinicalCodes: codes,
      references: [
        ...(resource.patient ? [`${resource.patient.reference}`] : []),
        ...(resource.supplier ? [`${resource.supplier.reference}`] : []),
        ...(resource.destination ? [`${resource.destination.reference}`] : []),
        ...(resource.receiver ? resource.receiver.map((r: any) => r.reference) : []),
        ...(resource.basedOn ? resource.basedOn.map((b: any) => b.reference) : []),
        ...(resource.partOf ? resource.partOf.map((p: any) => p.reference) : []),
        ...(resource.suppliedItem?.itemReference ? [`${resource.suppliedItem.itemReference.reference}`] : [])
      ],
      tags: [
        'supply-delivery',
        'inventory-management',
        'supply-chain',
        ...(resource.status ? [resource.status] : []),
        ...(resource.type?.text ? [resource.type.text.toLowerCase().replace(/\s+/g, '-')] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    // Failed or abandoned deliveries
    if (resource.status === 'abandoned' || resource.status === 'entered-in-error') return 'abnormal';
    
    // Check for critical supplies
    const itemText = resource.suppliedItem?.itemCodeableConcept?.text?.toLowerCase() || 
                    resource.suppliedItem?.itemCodeableConcept?.coding?.[0]?.display?.toLowerCase() || '';
    const criticalSupplies = ['blood', 'oxygen', 'emergency', 'life support', 'resuscitation'];
    if (criticalSupplies.some(supply => itemText.includes(supply))) return 'critical';
    
    // In-progress deliveries of medical supplies
    if (resource.status === 'in-progress' && resource.type?.text?.toLowerCase().includes('medical')) return 'abnormal';
    
    if (resource.status === 'completed') return 'normal';
    
    return 'normal';
  }
}