import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../ResourceTemplateService';

export class ClinicalImpressionTemplate extends BaseResourceTemplate {
  resourceType = 'ClinicalImpression';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.status) {
      chunks.push({
        id: `${resource.id}-status`,
        type: 'granular_fact',
        content: `Clinical impression status: ${resource.status}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.description) {
      chunks.push({
        id: `${resource.id}-description`,
        type: 'granular_fact',
        content: `Clinical impression: ${resource.description}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.effectivePeriod) {
      chunks.push({
        id: `${resource.id}-period`,
        type: 'granular_fact',
        content: `Assessment period: ${resource.effectivePeriod.start} to ${resource.effectivePeriod.end || 'ongoing'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.assessor) {
      chunks.push({
        id: `${resource.id}-assessor`,
        type: 'granular_fact',
        content: `Assessed by: ${resource.assessor.display || resource.assessor.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.finding) {
      resource.finding.forEach((finding: any, index: number) => {
        chunks.push({
          id: `${resource.id}-finding-${index}`,
          type: 'granular_fact',
          content: `Finding: ${finding.itemCodeableConcept?.text || finding.itemCodeableConcept?.coding?.[0]?.display || 'Unknown'} - ${finding.basis || ''}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.prognosisCodeableConcept) {
      resource.prognosisCodeableConcept.forEach((prognosis: any, index: number) => {
        chunks.push({
          id: `${resource.id}-prognosis-${index}`,
          type: 'granular_fact',
          content: `Prognosis: ${prognosis.text || prognosis.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.protocol) {
      resource.protocol.forEach((protocol: any, index: number) => {
        chunks.push({
          id: `${resource.id}-protocol-${index}`,
          type: 'granular_fact',
          content: `Protocol used: ${protocol}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.summary) {
      chunks.push({
        id: `${resource.id}-summary-text`,
        type: 'granular_fact',
        content: `Summary: ${resource.summary}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Clinical Impression: ${resource.description || 'Assessment'} for ${resource.subject?.display || 'patient'} - Status: ${resource.status}, ${resource.finding?.length || 0} findings`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Clinical Assessment: ${resource.description || 'N/A'} - ${resource.finding?.length || 0} findings, Prognosis: ${resource.prognosisCodeableConcept?.[0]?.text || 'Not specified'}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract finding codes
    if (resource.finding) {
      resource.finding.forEach((finding: any) => {
        if (finding.itemCodeableConcept?.coding) {
          finding.itemCodeableConcept.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    // Extract prognosis codes
    if (resource.prognosisCodeableConcept) {
      resource.prognosisCodeableConcept.forEach((prognosis: any) => {
        if (prognosis.coding) {
          prognosis.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'procedures',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'encounter',
      searchable_codes: codes,
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    // Check for critical findings
    if (resource.finding) {
      const hasCriticalFinding = resource.finding.some((finding: any) => {
        const displayText = finding.itemCodeableConcept?.text?.toLowerCase() || 
                          finding.itemCodeableConcept?.coding?.[0]?.display?.toLowerCase() || '';
        return displayText.includes('critical') || 
               displayText.includes('emergency') || 
               displayText.includes('urgent');
      });
      if (hasCriticalFinding) return 'critical';
    }
    
    // Check prognosis
    if (resource.prognosisCodeableConcept) {
      const hasNegativePrognosis = resource.prognosisCodeableConcept.some((prognosis: any) => {
        const prognosisText = prognosis.text?.toLowerCase() || 
                             prognosis.coding?.[0]?.display?.toLowerCase() || '';
        return prognosisText.includes('poor') || 
               prognosisText.includes('guarded') || 
               prognosisText.includes('terminal');
      });
      if (hasNegativePrognosis) return 'critical';
    }
    
    if (resource.status === 'in-progress' || resource.status === 'completed') return 'normal';
    
    return 'abnormal';
  }
}