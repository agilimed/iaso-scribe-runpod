import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class CarePlanTemplate extends BaseResourceTemplate {
  resourceType = 'CarePlan';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const careplanSummary = this.generateCarePlanSummary(resource);
    chunks.push(this.createChunk(careplanSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'care_management',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'patient',
      searchable_codes: this.extractCarePlanCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Active care plans for critical conditions
    if (resource.status === 'active' || resource.status === 'on-hold') {
      // Check for critical conditions in addresses
      if (resource.addresses?.some((addr: any) => this.isCriticalCondition(addr))) {
        return 'critical';
      }
    }
    
    // Cancelled or suspended care plans
    if (resource.status === 'cancelled' || resource.status === 'stopped') {
      return 'abnormal';
    }
    
    // Active care plans are generally normal
    if (resource.status === 'active') {
      return 'normal';
    }
    
    return 'normal';
  }

  private generateCarePlanSummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const title = resource.title || 'Care plan';
    const status = resource.status || 'unknown';
    const intent = resource.intent || 'plan';
    const period = this.extractPeriod(resource);
    const categories = this.extractCategories(resource);
    
    let summary = `Patient ${patientId} has ${intent} "${title}"`;
    
    if (categories.length > 0) {
      summary += ` for ${categories.join(', ')}`;
    }
    
    if (period) {
      summary += ` (${period})`;
    }
    
    summary += ` - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Title
    if (resource.title) {
      facts.push(this.createChunk(
        `Title: ${resource.title}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Intent
    if (resource.intent) {
      facts.push(this.createChunk(
        `Intent: ${resource.intent}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Categories
    if (resource.category?.length > 0) {
      resource.category.forEach((category: any) => {
        const display = category.coding?.[0]?.display || category.text;
        facts.push(this.createChunk(
          `Category: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Description
    if (resource.description) {
      facts.push(this.createChunk(
        `Description: ${resource.description}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Period
    if (resource.period) {
      if (resource.period.start) {
        facts.push(this.createChunk(
          `Start date: ${new Date(resource.period.start).toISOString().split('T')[0]}`,
          'granular_fact',
          resource,
          significance
        ));
      }
      
      if (resource.period.end) {
        facts.push(this.createChunk(
          `End date: ${new Date(resource.period.end).toISOString().split('T')[0]}`,
          'granular_fact',
          resource,
          significance
        ));
      }
    }
    
    // Created date
    if (resource.created) {
      facts.push(this.createChunk(
        `Created: ${new Date(resource.created).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Author
    if (resource.author) {
      const author = resource.author.display || resource.author.reference;
      facts.push(this.createChunk(
        `Author: ${author}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Contributors
    if (resource.contributor?.length > 0) {
      resource.contributor.forEach((contributor: any) => {
        const name = contributor.display || contributor.reference;
        facts.push(this.createChunk(
          `Contributor: ${name}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Care team
    if (resource.careTeam?.length > 0) {
      resource.careTeam.forEach((team: any) => {
        const teamName = team.display || team.reference;
        facts.push(this.createChunk(
          `Care team: ${teamName}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Addresses (conditions)
    if (resource.addresses?.length > 0) {
      resource.addresses.forEach((addr: any) => {
        const condition = addr.display || addr.reference;
        facts.push(this.createChunk(
          `Addresses: ${condition}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Supporting info
    if (resource.supportingInfo?.length > 0) {
      resource.supportingInfo.forEach((info: any) => {
        const supportingInfo = info.display || info.reference;
        facts.push(this.createChunk(
          `Supporting info: ${supportingInfo}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Goals
    if (resource.goal?.length > 0) {
      resource.goal.forEach((goal: any) => {
        const goalRef = goal.display || goal.reference;
        facts.push(this.createChunk(
          `Goal: ${goalRef}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Activities
    if (resource.activity?.length > 0) {
      resource.activity.forEach((activity: any, index: number) => {
        // Detail
        if (activity.detail) {
          const detail = activity.detail;
          
          if (detail.description) {
            facts.push(this.createChunk(
              `Activity ${index + 1}: ${detail.description}`,
              'granular_fact',
              resource,
              significance
            ));
          }
          
          if (detail.status) {
            facts.push(this.createChunk(
              `Activity ${index + 1} status: ${detail.status}`,
              'granular_fact',
              resource,
              significance
            ));
          }
          
          if (detail.scheduledTiming) {
            facts.push(this.createChunk(
              `Activity ${index + 1} scheduled: ${detail.scheduledTiming}`,
              'granular_fact',
              resource,
              significance
            ));
          }
        }
        
        // Reference
        if (activity.reference) {
          const ref = activity.reference.display || activity.reference.reference;
          facts.push(this.createChunk(
            `Activity reference: ${ref}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    // Notes
    if (resource.note?.length > 0) {
      resource.note.forEach((note: any) => {
        if (note.text) {
          facts.push(this.createChunk(
            `Note: ${note.text}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    return facts;
  }

  private extractPeriod(resource: any): string | null {
    if (resource.period) {
      const start = resource.period.start ? new Date(resource.period.start).toISOString().split('T')[0] : null;
      const end = resource.period.end ? new Date(resource.period.end).toISOString().split('T')[0] : null;
      
      if (start && end) {
        return `${start} to ${end}`;
      } else if (start) {
        return `from ${start}`;
      } else if (end) {
        return `until ${end}`;
      }
    }
    
    return null;
  }

  private extractCategories(resource: any): string[] {
    const categories: string[] = [];
    
    if (resource.category?.length > 0) {
      resource.category.forEach((category: any) => {
        const display = category.coding?.[0]?.display || category.text;
        if (display) {
          categories.push(display);
        }
      });
    }
    
    return categories;
  }

  private extractCarePlanCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Category codes
    if (resource.category?.length > 0) {
      resource.category.forEach((category: any) => {
        if (category.coding) {
          category.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    return codes;
  }

  private isCriticalCondition(conditionRef: any): boolean {
    // This would ideally check the referenced condition
    // For now, check if the display contains critical terms
    const display = conditionRef.display || '';
    const criticalTerms = ['cancer', 'malignant', 'acute', 'severe', 'critical', 'emergency'];
    
    return criticalTerms.some(term => display.toLowerCase().includes(term));
  }
}
