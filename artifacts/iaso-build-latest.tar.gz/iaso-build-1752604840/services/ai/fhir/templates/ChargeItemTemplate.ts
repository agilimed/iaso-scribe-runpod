import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../ResourceTemplateService';

export class ChargeItemTemplate extends BaseResourceTemplate {
  resourceType = 'ChargeItem';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.status) {
      chunks.push({
        id: `${resource.id}-status`,
        type: 'granular_fact',
        content: `Charge status: ${resource.status}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.code) {
      chunks.push({
        id: `${resource.id}-code`,
        type: 'granular_fact',
        content: `Charge code: ${resource.code.text || resource.code.coding?.[0]?.display} (${resource.code.coding?.[0]?.code || 'N/A'})`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.quantity) {
      chunks.push({
        id: `${resource.id}-quantity`,
        type: 'granular_fact',
        content: `Quantity: ${resource.quantity.value} ${resource.quantity.unit || resource.quantity.code || ''}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.priceOverride) {
      chunks.push({
        id: `${resource.id}-price`,
        type: 'granular_fact',
        content: `Price override: ${resource.priceOverride.value} ${resource.priceOverride.currency}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.factorOverride) {
      chunks.push({
        id: `${resource.id}-factor`,
        type: 'granular_fact',
        content: `Factor override: ${resource.factorOverride}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.occurrencePeriod) {
      chunks.push({
        id: `${resource.id}-occurrence`,
        type: 'granular_fact',
        content: `Occurrence: ${resource.occurrencePeriod.start} to ${resource.occurrencePeriod.end || 'ongoing'}`,
        metadata: this.extractMetadata(resource)
      });
    } else if (resource.occurrenceDateTime) {
      chunks.push({
        id: `${resource.id}-occurrence`,
        type: 'granular_fact',
        content: `Occurrence: ${resource.occurrenceDateTime}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.performingOrganization) {
      chunks.push({
        id: `${resource.id}-performing-org`,
        type: 'granular_fact',
        content: `Performing organization: ${resource.performingOrganization.display || resource.performingOrganization.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.costCenter) {
      chunks.push({
        id: `${resource.id}-cost-center`,
        type: 'granular_fact',
        content: `Cost center: ${resource.costCenter.display || resource.costCenter.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.enteredDate) {
      chunks.push({
        id: `${resource.id}-entered`,
        type: 'granular_fact',
        content: `Entered on: ${resource.enteredDate}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.reason) {
      resource.reason.forEach((reason: any, index: number) => {
        chunks.push({
          id: `${resource.id}-reason-${index}`,
          type: 'granular_fact',
          content: `Reason: ${reason.text || reason.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.service) {
      resource.service.forEach((service: any, index: number) => {
        chunks.push({
          id: `${resource.id}-service-${index}`,
          type: 'granular_fact',
          content: `Service: ${service.display || service.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.product) {
      resource.product.forEach((product: any, index: number) => {
        chunks.push({
          id: `${resource.id}-product-${index}`,
          type: 'granular_fact',
          content: `Product: ${product.display || product.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.account) {
      resource.account.forEach((account: any, index: number) => {
        chunks.push({
          id: `${resource.id}-account-${index}`,
          type: 'granular_fact',
          content: `Account: ${account.display || account.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Charge Item: ${resource.code?.text || 'Service'} for ${resource.subject?.display || 'patient'} - Quantity: ${resource.quantity?.value || 1} ${resource.quantity?.unit || ''}, Status: ${resource.status}`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Billing Charge: ${resource.code?.text || 'N/A'} - ${resource.quantity?.value || 1} ${resource.quantity?.unit || 'units'}, ${resource.priceOverride ? `$${resource.priceOverride.value}` : 'Standard pricing'}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract charge codes
    if (resource.code) {
      codes.push(...this.extractClinicalCodes(resource.code));
    }
    
    // Extract reason codes
    if (resource.reason) {
      resource.reason.forEach((reason: any) => {
        codes.push(...this.extractClinicalCodes(reason));
      });
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.enteredDate,
      clinicalCodes: codes,
      references: [
        ...(resource.subject ? [`${resource.subject.reference}`] : []),
        ...(resource.context ? [`${resource.context.reference}`] : []),
        ...(resource.performingOrganization ? [`${resource.performingOrganization.reference}`] : []),
        ...(resource.requestingOrganization ? [`${resource.requestingOrganization.reference}`] : []),
        ...(resource.costCenter ? [`${resource.costCenter.reference}`] : []),
        ...(resource.service ? resource.service.map((s: any) => s.reference) : []),
        ...(resource.product ? resource.product.map((p: any) => p.reference) : []),
        ...(resource.account ? resource.account.map((a: any) => a.reference) : [])
      ],
      tags: [
        'billing',
        'charge-item',
        'financial',
        ...(resource.status ? [resource.status] : []),
        ...(resource.code?.text ? [resource.code.text.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.priceOverride ? ['price-override'] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    // High-value charges
    if (resource.priceOverride?.value > 10000) return 'critical';
    
    // Cancelled or error charges
    if (resource.status === 'cancelled' || resource.status === 'entered-in-error') return 'abnormal';
    
    // Charges with significant factor overrides
    if (resource.factorOverride && (resource.factorOverride > 2 || resource.factorOverride < 0.5)) return 'abnormal';
    
    // Not billable charges
    if (resource.status === 'not-billable') return 'abnormal';
    
    return 'normal';
  }
}