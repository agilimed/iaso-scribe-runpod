import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class ServiceRequestTemplate extends BaseResourceTemplate {
  resourceType = 'ServiceRequest';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const serviceSummary = this.generateServiceSummary(resource);
    chunks.push(this.createChunk(serviceSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'orders',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'encounter',
      searchable_codes: this.extractServiceCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Urgent or stat orders
    if (resource.priority === 'urgent' || resource.priority === 'stat') {
      return 'critical';
    }
    
    // Emergency services
    if (this.isEmergencyService(resource)) {
      return 'critical';
    }
    
    // Cancelled or failed orders
    if (resource.status === 'cancelled' || resource.status === 'revoked') {
      return 'abnormal';
    }
    
    // Active orders are normal
    if (resource.status === 'active' || resource.status === 'completed') {
      return 'normal';
    }
    
    return 'normal';
  }

  private generateServiceSummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const service = this.extractServiceName(resource);
    const status = resource.status || 'unknown';
    const priority = resource.priority || 'routine';
    const date = this.extractDate(resource);
    
    let summary = `Patient ${patientId} has ${priority} service request for ${service}`;
    
    if (date) {
      summary += ` ordered on ${date}`;
    }
    
    summary += ` - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Service name
    const service = this.extractServiceName(resource);
    facts.push(this.createChunk(
      `Service: ${service}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Intent
    if (resource.intent) {
      facts.push(this.createChunk(
        `Intent: ${resource.intent}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Priority
    if (resource.priority) {
      facts.push(this.createChunk(
        `Priority: ${resource.priority}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Category
    if (resource.category?.length > 0) {
      resource.category.forEach((category: any) => {
        const display = category.coding?.[0]?.display || category.text;
        facts.push(this.createChunk(
          `Category: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Authored on
    if (resource.authoredOn) {
      facts.push(this.createChunk(
        `Authored on: ${new Date(resource.authoredOn).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Requester
    if (resource.requester) {
      const requester = resource.requester.display || resource.requester.reference;
      facts.push(this.createChunk(
        `Requested by: ${requester}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Performer type
    if (resource.performerType) {
      const performerType = resource.performerType.coding?.[0]?.display || resource.performerType.text;
      facts.push(this.createChunk(
        `Performer type: ${performerType}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Performer
    if (resource.performer?.length > 0) {
      resource.performer.forEach((performer: any) => {
        const name = performer.display || performer.reference;
        facts.push(this.createChunk(
          `Performer: ${name}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Location reference
    if (resource.locationReference?.length > 0) {
      resource.locationReference.forEach((location: any) => {
        const loc = location.display || location.reference;
        facts.push(this.createChunk(
          `Location: ${loc}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Reason code
    if (resource.reasonCode?.length > 0) {
      resource.reasonCode.forEach((reason: any) => {
        const display = reason.coding?.[0]?.display || reason.text;
        facts.push(this.createChunk(
          `Reason: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Reason reference
    if (resource.reasonReference?.length > 0) {
      resource.reasonReference.forEach((ref: any) => {
        const reason = ref.display || ref.reference;
        facts.push(this.createChunk(
          `Reason reference: ${reason}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Supporting info
    if (resource.supportingInfo?.length > 0) {
      resource.supportingInfo.forEach((info: any) => {
        const support = info.display || info.reference;
        facts.push(this.createChunk(
          `Supporting info: ${support}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Specimen
    if (resource.specimen?.length > 0) {
      resource.specimen.forEach((specimen: any) => {
        const spec = specimen.display || specimen.reference;
        facts.push(this.createChunk(
          `Specimen: ${spec}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Body site
    if (resource.bodySite?.length > 0) {
      resource.bodySite.forEach((site: any) => {
        const bodySite = site.coding?.[0]?.display || site.text;
        facts.push(this.createChunk(
          `Body site: ${bodySite}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Occurrence
    if (resource.occurrenceDateTime) {
      facts.push(this.createChunk(
        `Occurrence: ${new Date(resource.occurrenceDateTime).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    } else if (resource.occurrencePeriod) {
      const start = resource.occurrencePeriod.start ? new Date(resource.occurrencePeriod.start).toISOString().split('T')[0] : '';
      const end = resource.occurrencePeriod.end ? new Date(resource.occurrencePeriod.end).toISOString().split('T')[0] : '';
      
      if (start && end) {
        facts.push(this.createChunk(
          `Occurrence period: ${start} to ${end}`,
          'granular_fact',
          resource,
          significance
        ));
      } else if (start) {
        facts.push(this.createChunk(
          `Occurrence from: ${start}`,
          'granular_fact',
          resource,
          significance
        ));
      }
    }
    
    // As needed
    if (resource.asNeededBoolean !== undefined) {
      facts.push(this.createChunk(
        `As needed: ${resource.asNeededBoolean}`,
        'granular_fact',
        resource,
        significance
      ));
    } else if (resource.asNeededCodeableConcept) {
      const asNeeded = resource.asNeededCodeableConcept.coding?.[0]?.display || resource.asNeededCodeableConcept.text;
      facts.push(this.createChunk(
        `As needed: ${asNeeded}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Quantity
    if (resource.quantityQuantity) {
      facts.push(this.createChunk(
        `Quantity: ${resource.quantityQuantity.value} ${resource.quantityQuantity.unit}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Instructions
    if (resource.patientInstruction) {
      facts.push(this.createChunk(
        `Patient instruction: ${resource.patientInstruction}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Notes
    if (resource.note?.length > 0) {
      resource.note.forEach((note: any) => {
        if (note.text) {
          facts.push(this.createChunk(
            `Note: ${note.text}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    return facts;
  }

  private extractServiceName(resource: any): string {
    if (resource.code?.coding?.length > 0) {
      return resource.code.coding[0].display || resource.code.coding[0].code || 'Unknown service';
    }
    
    if (resource.code?.text) {
      return resource.code.text;
    }
    
    return 'Unknown service';
  }

  private extractServiceCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Service codes
    if (resource.code?.coding) {
      resource.code.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    if (resource.code?.text) {
      codes.push(resource.code.text.toLowerCase());
    }
    
    // Category codes
    if (resource.category?.length > 0) {
      resource.category.forEach((category: any) => {
        if (category.coding) {
          category.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    return codes;
  }

  private isEmergencyService(resource: any): boolean {
    const service = this.extractServiceName(resource).toLowerCase();
    const emergencyTerms = ['emergency', 'urgent', 'trauma', 'resuscitation', 'code', 'stat'];
    
    return emergencyTerms.some(term => service.includes(term));
  }
}
