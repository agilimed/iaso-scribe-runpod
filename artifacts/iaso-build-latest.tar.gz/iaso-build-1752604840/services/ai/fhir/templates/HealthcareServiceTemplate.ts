import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../ResourceTemplateService';

export class HealthcareServiceTemplate extends BaseResourceTemplate {
  resourceType = 'HealthcareService';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.active !== undefined) {
      chunks.push({
        id: `${resource.id}-active`,
        type: 'granular_fact',
        content: `Service active: ${resource.active ? 'Yes' : 'No'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.name) {
      chunks.push({
        id: `${resource.id}-name`,
        type: 'granular_fact',
        content: `Healthcare service: ${resource.name}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.category) {
      resource.category.forEach((cat: any, index: number) => {
        chunks.push({
          id: `${resource.id}-category-${index}`,
          type: 'granular_fact',
          content: `Category: ${cat.text || cat.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.type) {
      resource.type.forEach((type: any, index: number) => {
        chunks.push({
          id: `${resource.id}-type-${index}`,
          type: 'granular_fact',
          content: `Service type: ${type.text || type.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.specialty) {
      resource.specialty.forEach((specialty: any, index: number) => {
        chunks.push({
          id: `${resource.id}-specialty-${index}`,
          type: 'granular_fact',
          content: `Specialty: ${specialty.text || specialty.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.location) {
      resource.location.forEach((loc: any, index: number) => {
        chunks.push({
          id: `${resource.id}-location-${index}`,
          type: 'granular_fact',
          content: `Location: ${loc.display || loc.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.telecom) {
      resource.telecom.forEach((contact: any, index: number) => {
        chunks.push({
          id: `${resource.id}-telecom-${index}`,
          type: 'granular_fact',
          content: `Contact ${contact.system}: ${contact.value} (${contact.use || 'N/A'})`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.serviceProvisionCode) {
      resource.serviceProvisionCode.forEach((code: any, index: number) => {
        chunks.push({
          id: `${resource.id}-provision-${index}`,
          type: 'granular_fact',
          content: `Service provision: ${code.text || code.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.eligibility) {
      resource.eligibility.forEach((elig: any, index: number) => {
        chunks.push({
          id: `${resource.id}-eligibility-${index}`,
          type: 'granular_fact',
          content: `Eligibility: ${elig.code?.text || elig.code?.coding?.[0]?.display} - ${elig.comment || ''}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.program) {
      resource.program.forEach((prog: any, index: number) => {
        chunks.push({
          id: `${resource.id}-program-${index}`,
          type: 'granular_fact',
          content: `Program: ${prog.text || prog.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.characteristic) {
      resource.characteristic.forEach((char: any, index: number) => {
        chunks.push({
          id: `${resource.id}-characteristic-${index}`,
          type: 'granular_fact',
          content: `Characteristic: ${char.text || char.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.referralMethod) {
      resource.referralMethod.forEach((method: any, index: number) => {
        chunks.push({
          id: `${resource.id}-referral-${index}`,
          type: 'granular_fact',
          content: `Referral method: ${method.text || method.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.appointmentRequired !== undefined) {
      chunks.push({
        id: `${resource.id}-appointment`,
        type: 'granular_fact',
        content: `Appointment required: ${resource.appointmentRequired ? 'Yes' : 'No'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.availableTime) {
      resource.availableTime.forEach((time: any, index: number) => {
        chunks.push({
          id: `${resource.id}-available-${index}`,
          type: 'granular_fact',
          content: `Available: ${time.daysOfWeek?.join(', ') || 'All days'} ${time.allDay ? 'All day' : `${time.availableStartTime || ''} - ${time.availableEndTime || ''}`}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.notAvailable) {
      resource.notAvailable.forEach((notAvail: any, index: number) => {
        chunks.push({
          id: `${resource.id}-not-available-${index}`,
          type: 'granular_fact',
          content: `Not available: ${notAvail.description} (${notAvail.during?.start} to ${notAvail.during?.end || 'N/A'})`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.availabilityExceptions) {
      chunks.push({
        id: `${resource.id}-exceptions`,
        type: 'granular_fact',
        content: `Availability exceptions: ${resource.availabilityExceptions}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Healthcare Service: ${resource.name || 'N/A'} - ${resource.type?.[0]?.text || 'Service'}, ${resource.active ? 'Active' : 'Inactive'}, ${resource.location?.length || 0} locations`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Healthcare Service: ${resource.name || 'N/A'} - ${resource.specialty?.[0]?.text || 'General'}, ${resource.active ? 'Currently available' : 'Not available'}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract category codes
    if (resource.category) {
      resource.category.forEach((cat: any) => {
        codes.push(...this.extractClinicalCodes(cat));
      });
    }
    
    // Extract type codes
    if (resource.type) {
      resource.type.forEach((type: any) => {
        codes.push(...this.extractClinicalCodes(type));
      });
    }
    
    // Extract specialty codes
    if (resource.specialty) {
      resource.specialty.forEach((specialty: any) => {
        codes.push(...this.extractClinicalCodes(specialty));
      });
    }
    
    // Extract program codes
    if (resource.program) {
      resource.program.forEach((prog: any) => {
        codes.push(...this.extractClinicalCodes(prog));
      });
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated,
      clinicalCodes: codes,
      references: [
        ...(resource.providedBy ? [`${resource.providedBy.reference}`] : []),
        ...(resource.location ? resource.location.map((l: any) => l.reference) : []),
        ...(resource.coverageArea ? resource.coverageArea.map((c: any) => c.reference) : []),
        ...(resource.endpoint ? resource.endpoint.map((e: any) => e.reference) : [])
      ],
      tags: [
        'healthcare-service',
        'service-directory',
        'provider-services',
        ...(resource.active ? ['active-service'] : ['inactive-service']),
        ...(resource.appointmentRequired ? ['appointment-required'] : ['walk-in']),
        ...(resource.category ? resource.category.map((c: any) => c.text?.toLowerCase().replace(/\s+/g, '-')).filter(Boolean) : []),
        ...(resource.type ? resource.type.map((t: any) => t.text?.toLowerCase().replace(/\s+/g, '-')).filter(Boolean) : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    // Inactive services
    if (!resource.active) return 'abnormal';
    
    // Emergency services
    if (resource.category?.some((c: any) => {
      const text = c.text?.toLowerCase() || c.coding?.[0]?.display?.toLowerCase() || '';
      return text.includes('emergency') || text.includes('urgent');
    })) return 'critical';
    
    // Services with no availability
    if (resource.availableTime?.length === 0 && resource.notAvailable?.length > 0) return 'abnormal';
    
    return 'normal';
  }
}