import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class EncounterTemplate extends BaseResourceTemplate {
  resourceType = 'Encounter';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Main encounter summary chunk
    const encounterSummary = this.generateEncounterSummary(resource);
    chunks.push(this.createChunk(encounterSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    // Granular fact chunks
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const lengthOfStay = this.calculateLengthOfStay(resource);
    
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'admin',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: resource.id,
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'encounter',
      searchable_codes: this.extractEncounterCodes(resource),
      searchable_values: lengthOfStay ? [lengthOfStay] : [],
      searchable_units: lengthOfStay ? ['days'] : [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Emergency encounters are often critical
    const encounterClass = resource.class?.code;
    if (encounterClass === 'EMER' || encounterClass === 'emergency') {
      return 'critical';
    }
    
    // Inpatient encounters might be abnormal
    if (encounterClass === 'IMP' || encounterClass === 'inpatient') {
      return 'abnormal';
    }
    
    // Check for critical diagnosis codes
    if (resource.diagnosis?.length > 0) {
      const hasCriticalDiagnosis = resource.diagnosis.some((diag: any) => 
        this.isCriticalDiagnosis(diag.condition?.reference)
      );
      
      if (hasCriticalDiagnosis) {
        return 'critical';
      }
    }
    
    return 'normal';
  }

  private generateEncounterSummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const encounterType = this.extractEncounterType(resource);
    const encounterClass = this.extractEncounterClass(resource);
    const location = this.extractLocation(resource);
    const period = this.extractPeriod(resource);
    const status = resource.status || 'unknown';
    
    let summary = `Encounter ${resource.id} for Patient ${patientId}`;
    
    if (encounterType || encounterClass) {
      summary += ` was ${encounterType || encounterClass}`;
      if (encounterClass && encounterType && encounterClass !== encounterType) {
        summary += ` (${encounterClass})`;
      }
    }
    
    if (period) {
      summary += ` ${period}`;
    }
    
    if (location) {
      summary += ` at ${location}`;
    }
    
    summary += ` - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Status fact
    if (resource.status) {
      facts.push(this.createChunk(
        `Encounter status: ${resource.status}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Class fact
    const encounterClass = this.extractEncounterClass(resource);
    if (encounterClass) {
      facts.push(this.createChunk(
        `Encounter class: ${encounterClass}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Type facts
    if (resource.type?.length > 0) {
      resource.type.forEach((type: any) => {
        const typeDisplay = type.coding?.[0]?.display || type.text;
        if (typeDisplay) {
          facts.push(this.createChunk(
            `Encounter type: ${typeDisplay}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    // Service type fact
    if (resource.serviceType) {
      const serviceType = resource.serviceType.coding?.[0]?.display || 
                         resource.serviceType.text;
      facts.push(this.createChunk(
        `Service type: ${serviceType}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Priority fact
    if (resource.priority) {
      const priority = resource.priority.coding?.[0]?.display || 
                      resource.priority.text;
      facts.push(this.createChunk(
        `Priority: ${priority}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Period facts
    if (resource.period) {
      if (resource.period.start) {
        facts.push(this.createChunk(
          `Admission date: ${new Date(resource.period.start).toISOString().split('T')[0]}`,
          'granular_fact',
          resource,
          significance
        ));
      }
      
      if (resource.period.end) {
        facts.push(this.createChunk(
          `Discharge date: ${new Date(resource.period.end).toISOString().split('T')[0]}`,
          'granular_fact',
          resource,
          significance
        ));
      }
      
      const lengthOfStay = this.calculateLengthOfStay(resource);
      if (lengthOfStay) {
        facts.push(this.createChunk(
          `Length of stay: ${lengthOfStay} days`,
          'granular_fact',
          resource,
          significance
        ));
      }
    }
    
    // Subject fact
    if (resource.subject) {
      const subject = resource.subject.display || resource.subject.reference;
      facts.push(this.createChunk(
        `Patient: ${subject}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Episode of care fact
    if (resource.episodeOfCare?.length > 0) {
      resource.episodeOfCare.forEach((episode: any) => {
        const episodeRef = episode.display || episode.reference;
        facts.push(this.createChunk(
          `Episode of care: ${episodeRef}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Participant facts
    if (resource.participant?.length > 0) {
      resource.participant.forEach((participant: any) => {
        const individual = participant.individual?.display || 
                          participant.individual?.reference;
        const type = participant.type?.[0]?.coding?.[0]?.display || 
                    participant.type?.[0]?.text || 
                    'participant';
        
        if (individual) {
          facts.push(this.createChunk(
            `${type}: ${individual}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    // Appointment fact
    if (resource.appointment?.length > 0) {
      resource.appointment.forEach((appt: any) => {
        const apptRef = appt.display || appt.reference;
        facts.push(this.createChunk(
          `Appointment: ${apptRef}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Reason facts
    if (resource.reasonCode?.length > 0) {
      resource.reasonCode.forEach((reason: any) => {
        const reasonDisplay = reason.coding?.[0]?.display || reason.text;
        if (reasonDisplay) {
          facts.push(this.createChunk(
            `Reason: ${reasonDisplay}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    // Diagnosis facts
    if (resource.diagnosis?.length > 0) {
      resource.diagnosis.forEach((diag: any, index: number) => {
        const condition = diag.condition?.display || diag.condition?.reference;
        const use = diag.use?.coding?.[0]?.display || diag.use?.text || 'diagnosis';
        const rank = diag.rank ? ` (rank ${diag.rank})` : '';
        
        if (condition) {
          facts.push(this.createChunk(
            `${use}${rank}: ${condition}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    // Account fact
    if (resource.account?.length > 0) {
      resource.account.forEach((account: any) => {
        const accountRef = account.display || account.reference;
        facts.push(this.createChunk(
          `Account: ${accountRef}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Hospitalization facts
    if (resource.hospitalization) {
      const hosp = resource.hospitalization;
      
      if (hosp.preAdmissionIdentifier) {
        facts.push(this.createChunk(
          `Pre-admission ID: ${hosp.preAdmissionIdentifier.value}`,
          'granular_fact',
          resource,
          significance
        ));
      }
      
      if (hosp.origin) {
        const origin = hosp.origin.display || hosp.origin.reference;
        facts.push(this.createChunk(
          `Admitted from: ${origin}`,
          'granular_fact',
          resource,
          significance
        ));
      }
      
      if (hosp.admitSource) {
        const admitSource = hosp.admitSource.coding?.[0]?.display || 
                           hosp.admitSource.text;
        facts.push(this.createChunk(
          `Admit source: ${admitSource}`,
          'granular_fact',
          resource,
          significance
        ));
      }
      
      if (hosp.reAdmission) {
        const reAdmission = hosp.reAdmission.coding?.[0]?.display || 
                           hosp.reAdmission.text;
        facts.push(this.createChunk(
          `Re-admission: ${reAdmission}`,
          'granular_fact',
          resource,
          significance
        ));
      }
      
      if (hosp.dischargeDisposition) {
        const discharge = hosp.dischargeDisposition.coding?.[0]?.display || 
                         hosp.dischargeDisposition.text;
        facts.push(this.createChunk(
          `Discharge disposition: ${discharge}`,
          'granular_fact',
          resource,
          significance
        ));
      }
      
      if (hosp.destination) {
        const destination = hosp.destination.display || hosp.destination.reference;
        facts.push(this.createChunk(
          `Discharged to: ${destination}`,
          'granular_fact',
          resource,
          significance
        ));
      }
    }
    
    // Location facts
    if (resource.location?.length > 0) {
      resource.location.forEach((loc: any) => {
        const location = loc.location?.display || loc.location?.reference;
        const status = loc.status || 'active';
        const period = loc.period ? 
          `${loc.period.start || ''} - ${loc.period.end || 'ongoing'}` : 
          '';
        
        if (location) {
          facts.push(this.createChunk(
            `Location: ${location} (${status}${period ? ', ' + period : ''})`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    return facts;
  }

  private extractEncounterType(resource: any): string | null {
    if (resource.type?.length > 0) {
      return resource.type[0].coding?.[0]?.display || 
             resource.type[0].text || 
             null;
    }
    
    return null;
  }

  private extractEncounterClass(resource: any): string | null {
    if (resource.class) {
      return resource.class.display || resource.class.code || null;
    }
    
    return null;
  }

  private extractLocation(resource: any): string | null {
    if (resource.location?.length > 0) {
      return resource.location[0].location?.display || 
             resource.location[0].location?.reference || 
             null;
    }
    
    return null;
  }

  private extractPeriod(resource: any): string | null {
    if (resource.period) {
      const start = resource.period.start ? 
        new Date(resource.period.start).toISOString().split('T')[0] : 
        null;
      const end = resource.period.end ? 
        new Date(resource.period.end).toISOString().split('T')[0] : 
        null;
      
      if (start && end) {
        return `from ${start} to ${end}`;
      } else if (start) {
        return `from ${start}`;
      } else if (end) {
        return `until ${end}`;
      }
    }
    
    return null;
  }

  private calculateLengthOfStay(resource: any): number | null {
    if (resource.period?.start && resource.period?.end) {
      const start = new Date(resource.period.start);
      const end = new Date(resource.period.end);
      const diffTime = Math.abs(end.getTime() - start.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
    }
    
    return null;
  }

  private isCriticalDiagnosis(conditionRef: string | undefined): boolean {
    if (!conditionRef) return false;
    
    // This would need to be enhanced with actual condition severity lookup
    // For now, check for common critical condition patterns
    const criticalPatterns = ['sepsis', 'stroke', 'myocardial', 'cardiac arrest', 'respiratory failure'];
    
    return criticalPatterns.some(pattern => 
      conditionRef.toLowerCase().includes(pattern)
    );
  }

  private extractEncounterCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Extract identifier values
    if (resource.identifier?.length > 0) {
      resource.identifier.forEach((id: any) => {
        if (id.value) codes.push(id.value);
      });
    }
    
    // Extract type codes
    if (resource.type?.length > 0) {
      resource.type.forEach((type: any) => {
        if (type.coding) {
          type.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    // Extract class codes
    if (resource.class?.code) {
      codes.push(resource.class.code);
    }
    
    // Extract service type codes
    if (resource.serviceType?.coding) {
      resource.serviceType.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
      });
    }
    
    // Extract reason codes
    if (resource.reasonCode?.length > 0) {
      resource.reasonCode.forEach((reason: any) => {
        if (reason.coding) {
          reason.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    return codes;
  }
}