import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class ObservationTemplate extends BaseResourceTemplate {
  resourceType = 'Observation';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'critical';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Main observation summary chunk
    const observationSummary = this.generateObservationSummary(resource);
    chunks.push(this.createChunk(observationSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    // Granular fact chunks
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const value = this.extractNumericValue(resource);
    const unit = this.extractUnit(resource);
    const referenceRange = this.extractReferenceRange(resource);
    
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'labs',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'observation',
      searchable_codes: this.extractObservationCodes(resource),
      searchable_values: value !== null ? [value] : [],
      searchable_units: unit ? [unit] : [],
      reference_ranges: referenceRange
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Check interpretation first
    const interpretation = resource.interpretation?.[0]?.coding?.[0]?.code;
    
    if (interpretation) {
      const criticalCodes = ['HH', 'LL', 'AA', 'POS', 'NEG'];
      const abnormalCodes = ['H', 'L', 'A', 'AB'];
      
      if (criticalCodes.includes(interpretation)) {
        return 'critical';
      }
      
      if (abnormalCodes.includes(interpretation)) {
        return 'abnormal';
      }
    }
    
    // Check reference ranges
    const value = this.extractNumericValue(resource);
    const referenceRange = this.extractReferenceRange(resource);
    
    if (value !== null && referenceRange) {
      if (referenceRange.low !== undefined && value < referenceRange.low) {
        return 'abnormal';
      }
      if (referenceRange.high !== undefined && value > referenceRange.high) {
        return 'abnormal';
      }
    }
    
    // Check for critical lab values (common lab tests)
    const labCode = resource.code?.coding?.[0]?.code;
    if (labCode && value !== null) {
      const criticalValue = this.checkCriticalLabValue(labCode, value);
      if (criticalValue) {
        return 'critical';
      }
    }
    
    return 'normal';
  }

  private generateObservationSummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const testName = this.extractTestName(resource);
    const value = this.extractValueString(resource);
    const date = this.extractDate(resource);
    const interpretation = this.extractInterpretation(resource);
    
    let summary = `Patient ${patientId} had ${testName}`;
    
    if (value) {
      summary += ` of ${value}`;
    }
    
    summary += ` on ${date}`;
    
    if (interpretation) {
      summary += ` (${interpretation})`;
    }
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Test name fact
    const testName = this.extractTestName(resource);
    if (testName) {
      facts.push(this.createChunk(
        `Lab test: ${testName}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Value fact
    const value = this.extractValueString(resource);
    if (value) {
      facts.push(this.createChunk(
        `Test result: ${value}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Reference range fact
    const referenceRange = this.extractReferenceRange(resource);
    if (referenceRange) {
      let rangeText = 'Reference range: ';
      if (referenceRange.low !== undefined) {
        rangeText += `${referenceRange.low}`;
      }
      if (referenceRange.high !== undefined) {
        rangeText += ` - ${referenceRange.high}`;
      }
      if (referenceRange.unit) {
        rangeText += ` ${referenceRange.unit}`;
      }
      
      facts.push(this.createChunk(
        rangeText,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Interpretation fact
    const interpretation = this.extractInterpretation(resource);
    if (interpretation) {
      facts.push(this.createChunk(
        `Interpretation: ${interpretation}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Status fact
    if (resource.status) {
      facts.push(this.createChunk(
        `Test status: ${resource.status}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Performer fact
    if (resource.performer?.length > 0) {
      const performer = resource.performer[0].display || resource.performer[0].reference;
      facts.push(this.createChunk(
        `Performed by: ${performer}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    return facts;
  }

  private extractTestName(resource: any): string {
    return resource.code?.coding?.[0]?.display || 
           resource.code?.text || 
           'Unknown test';
  }

  private extractValueString(resource: any): string | null {
    if (resource.valueQuantity) {
      const value = resource.valueQuantity.value;
      const unit = resource.valueQuantity.unit || resource.valueQuantity.code;
      return `${value}${unit ? ' ' + unit : ''}`;
    }
    
    if (resource.valueString) {
      return resource.valueString;
    }
    
    if (resource.valueBoolean !== undefined) {
      return resource.valueBoolean.toString();
    }
    
    if (resource.valueCodeableConcept) {
      return resource.valueCodeableConcept.coding?.[0]?.display || 
             resource.valueCodeableConcept.text || 
             'coded value';
    }
    
    return null;
  }

  private extractNumericValue(resource: any): number | null {
    if (resource.valueQuantity?.value !== undefined) {
      return parseFloat(resource.valueQuantity.value);
    }
    
    return null;
  }

  private extractUnit(resource: any): string | null {
    if (resource.valueQuantity?.unit) {
      return resource.valueQuantity.unit;
    }
    
    if (resource.valueQuantity?.code) {
      return resource.valueQuantity.code;
    }
    
    return null;
  }

  private extractReferenceRange(resource: any): ChunkMetadata['reference_ranges'] | null {
    if (resource.referenceRange?.length > 0) {
      const range = resource.referenceRange[0];
      return {
        low: range.low?.value ? parseFloat(range.low.value) : undefined,
        high: range.high?.value ? parseFloat(range.high.value) : undefined,
        unit: range.low?.unit || range.high?.unit || undefined,
        interpretation: range.text || undefined
      };
    }
    
    return null;
  }

  private extractInterpretation(resource: any): string | null {
    if (resource.interpretation?.length > 0) {
      return resource.interpretation[0].coding?.[0]?.display || 
             resource.interpretation[0].text || 
             null;
    }
    
    return null;
  }

  private extractObservationCodes(resource: any): string[] {
    const codes: string[] = [];
    
    if (resource.code?.coding) {
      resource.code.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    if (resource.code?.text) {
      codes.push(resource.code.text.toLowerCase());
    }
    
    return codes;
  }

  private checkCriticalLabValue(labCode: string, value: number): boolean {
    // Common critical lab values (simplified)
    const criticalValues: Record<string, { low?: number; high?: number }> = {
      // Potassium (LOINC: 33747-0)
      '33747-0': { low: 2.8, high: 6.0 },
      // Sodium (LOINC: 33746-2)
      '33746-2': { low: 125, high: 155 },
      // Glucose (LOINC: 33743-9)
      '33743-9': { low: 50, high: 400 },
      // Hemoglobin (LOINC: 33734-8)
      '33734-8': { low: 7.0, high: 20.0 },
      // White Blood Cell Count (LOINC: 33747-0)
      '33747-0': { low: 2.0, high: 30.0 },
      // Creatinine (LOINC: 33744-7)
      '33744-7': { high: 3.0 }
    };
    
    const range = criticalValues[labCode];
    if (range) {
      if (range.low !== undefined && value < range.low) {
        return true;
      }
      if (range.high !== undefined && value > range.high) {
        return true;
      }
    }
    
    return false;
  }
}