import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class LocationTemplate extends BaseResourceTemplate {
  resourceType = 'Location';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Main location summary chunk
    const locationSummary = this.generateLocationSummary(resource);
    chunks.push(this.createChunk(locationSummary, 'resource_summary', resource));
    
    // Granular fact chunks
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const capacity = this.extractCapacity(resource);
    
    return {
      patient_id: '', // Locations don't have patients
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'admin',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: resource.meta?.lastUpdated?.split('T')[0] || new Date().toISOString().split('T')[0],
        encounter_id: undefined,
        episode_id: undefined
      },
      chunk_type: 'resource_summary',
      chunk_level: 'patient',
      searchable_codes: this.extractLocationCodes(resource),
      searchable_values: capacity ? [capacity] : [],
      searchable_units: capacity ? ['beds'] : [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Inactive locations might be abnormal
    if (resource.status === 'inactive' || resource.status === 'suspended') {
      return 'abnormal';
    }
    
    // Critical care areas might be marked as critical
    const locationType = resource.type?.[0]?.coding?.[0]?.code;
    const criticalLocationCodes = ['ICU', 'CCU', 'ER', 'OR'];
    
    if (criticalLocationCodes.includes(locationType)) {
      return 'critical';
    }
    
    return 'normal';
  }

  private generateLocationSummary(resource: any): string {
    const name = resource.name || 'Unknown Location';
    const type = this.extractLocationType(resource);
    const organization = this.extractOrganization(resource);
    const capacity = this.extractCapacity(resource);
    const status = resource.status || 'active';
    
    let summary = `${name}`;
    
    if (type) {
      summary += ` is a ${type} location`;
    }
    
    if (organization) {
      summary += ` within ${organization}`;
    }
    
    if (capacity) {
      summary += ` with ${capacity} capacity`;
    }
    
    summary += ` - ${status} status`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    
    // Name fact
    if (resource.name) {
      facts.push(this.createChunk(
        `Location name: ${resource.name}`,
        'granular_fact',
        resource
      ));
    }
    
    // Alias facts
    if (resource.alias?.length > 0) {
      resource.alias.forEach((alias: string) => {
        facts.push(this.createChunk(
          `Location alias: ${alias}`,
          'granular_fact',
          resource
        ));
      });
    }
    
    // Status fact
    if (resource.status) {
      facts.push(this.createChunk(
        `Location status: ${resource.status}`,
        'granular_fact',
        resource
      ));
    }
    
    // Operational status fact
    if (resource.operationalStatus) {
      const opStatus = resource.operationalStatus.coding?.[0]?.display || 
                      resource.operationalStatus.coding?.[0]?.code;
      facts.push(this.createChunk(
        `Operational status: ${opStatus}`,
        'granular_fact',
        resource
      ));
    }
    
    // Mode fact
    if (resource.mode) {
      facts.push(this.createChunk(
        `Location mode: ${resource.mode}`,
        'granular_fact',
        resource
      ));
    }
    
    // Type facts
    if (resource.type?.length > 0) {
      resource.type.forEach((type: any) => {
        const typeDisplay = type.coding?.[0]?.display || type.text;
        if (typeDisplay) {
          facts.push(this.createChunk(
            `Location type: ${typeDisplay}`,
            'granular_fact',
            resource
          ));
        }
      });
    }
    
    // Physical type fact
    if (resource.physicalType) {
      const physicalType = resource.physicalType.coding?.[0]?.display || 
                          resource.physicalType.text;
      facts.push(this.createChunk(
        `Physical type: ${physicalType}`,
        'granular_fact',
        resource
      ));
    }
    
    // Contact facts
    if (resource.telecom?.length > 0) {
      resource.telecom.forEach((contact: any) => {
        facts.push(this.createChunk(
          `Contact ${contact.system}: ${contact.value}`,
          'granular_fact',
          resource
        ));
      });
    }
    
    // Address fact
    if (resource.address) {
      const addressText = this.formatAddress(resource.address);
      facts.push(this.createChunk(
        `Address: ${addressText}`,
        'granular_fact',
        resource
      ));
    }
    
    // Position fact
    if (resource.position) {
      facts.push(this.createChunk(
        `Position: Lat ${resource.position.latitude}, Lng ${resource.position.longitude}`,
        'granular_fact',
        resource
      ));
    }
    
    // Managing organization fact
    if (resource.managingOrganization) {
      const org = resource.managingOrganization.display || 
                 resource.managingOrganization.reference;
      facts.push(this.createChunk(
        `Managing organization: ${org}`,
        'granular_fact',
        resource
      ));
    }
    
    // Part of fact
    if (resource.partOf) {
      const parentLocation = resource.partOf.display || resource.partOf.reference;
      facts.push(this.createChunk(
        `Part of: ${parentLocation}`,
        'granular_fact',
        resource
      ));
    }
    
    // Hours of operation facts
    if (resource.hoursOfOperation?.length > 0) {
      resource.hoursOfOperation.forEach((hours: any) => {
        const days = hours.daysOfWeek?.join(', ') || 'unspecified days';
        const times = `${hours.openingTime || 'unknown'} - ${hours.closingTime || 'unknown'}`;
        facts.push(this.createChunk(
          `Hours (${days}): ${times}`,
          'granular_fact',
          resource
        ));
      });
    }
    
    // Availability exceptions facts
    if (resource.availabilityExceptions) {
      facts.push(this.createChunk(
        `Availability exceptions: ${resource.availabilityExceptions}`,
        'granular_fact',
        resource
      ));
    }
    
    // Endpoint facts
    if (resource.endpoint?.length > 0) {
      resource.endpoint.forEach((endpoint: any) => {
        const endpointRef = endpoint.display || endpoint.reference;
        facts.push(this.createChunk(
          `Endpoint: ${endpointRef}`,
          'granular_fact',
          resource
        ));
      });
    }
    
    return facts;
  }

  private extractLocationType(resource: any): string | null {
    if (resource.type?.length > 0) {
      return resource.type[0].coding?.[0]?.display || 
             resource.type[0].text || 
             null;
    }
    
    return null;
  }

  private extractOrganization(resource: any): string | null {
    if (resource.managingOrganization) {
      return resource.managingOrganization.display || 
             resource.managingOrganization.reference?.replace('Organization/', '') ||
             null;
    }
    
    return null;
  }

  private extractCapacity(resource: any): number | null {
    // Look for capacity in extensions or operationalStatus
    if (resource.extension?.length > 0) {
      const capacityExt = resource.extension.find((ext: any) => 
        ext.url?.includes('capacity') || ext.url?.includes('bed')
      );
      
      if (capacityExt?.valueInteger) {
        return capacityExt.valueInteger;
      }
    }
    
    return null;
  }

  private formatAddress(address: any): string {
    const parts = [];
    
    if (address.line?.length) {
      parts.push(address.line.join(' '));
    }
    
    if (address.city) parts.push(address.city);
    if (address.state) parts.push(address.state);
    if (address.postalCode) parts.push(address.postalCode);
    if (address.country) parts.push(address.country);
    
    return parts.join(', ') || 'Unknown address';
  }

  private extractLocationCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Extract identifier values
    if (resource.identifier?.length > 0) {
      resource.identifier.forEach((id: any) => {
        if (id.value) codes.push(id.value);
        if (id.type?.coding?.[0]?.code) codes.push(id.type.coding[0].code);
      });
    }
    
    // Extract type codes
    if (resource.type?.length > 0) {
      resource.type.forEach((type: any) => {
        if (type.coding) {
          type.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    // Extract physical type codes
    if (resource.physicalType?.coding) {
      resource.physicalType.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
      });
    }
    
    // Extract location name for search
    if (resource.name) {
      codes.push(resource.name.toLowerCase());
    }
    
    // Extract aliases
    if (resource.alias?.length > 0) {
      resource.alias.forEach((alias: string) => {
        codes.push(alias.toLowerCase());
      });
    }
    
    return codes;
  }
}