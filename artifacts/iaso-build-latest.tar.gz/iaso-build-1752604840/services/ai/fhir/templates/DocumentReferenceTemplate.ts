import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../ResourceTemplateService';

export class DocumentReferenceTemplate extends BaseResourceTemplate {
  resourceType = 'DocumentReference';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.status) {
      chunks.push({
        id: `${resource.id}-status`,
        type: 'granular_fact',
        content: `Document status: ${resource.status}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.type) {
      chunks.push({
        id: `${resource.id}-type`,
        type: 'granular_fact',
        content: `Document type: ${resource.type.text || resource.type.coding?.[0]?.display}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.category) {
      resource.category.forEach((cat: any, index: number) => {
        chunks.push({
          id: `${resource.id}-category-${index}`,
          type: 'granular_fact',
          content: `Category: ${cat.text || cat.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.date) {
      chunks.push({
        id: `${resource.id}-date`,
        type: 'granular_fact',
        content: `Document date: ${resource.date}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.author) {
      resource.author.forEach((author: any, index: number) => {
        chunks.push({
          id: `${resource.id}-author-${index}`,
          type: 'granular_fact',
          content: `Author: ${author.display || author.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.authenticator) {
      chunks.push({
        id: `${resource.id}-authenticator`,
        type: 'granular_fact',
        content: `Authenticated by: ${resource.authenticator.display || resource.authenticator.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.custodian) {
      chunks.push({
        id: `${resource.id}-custodian`,
        type: 'granular_fact',
        content: `Custodian: ${resource.custodian.display || resource.custodian.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.description) {
      chunks.push({
        id: `${resource.id}-description`,
        type: 'granular_fact',
        content: `Description: ${resource.description}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.content) {
      resource.content.forEach((content: any, index: number) => {
        chunks.push({
          id: `${resource.id}-content-${index}`,
          type: 'granular_fact',
          content: `Attachment: ${content.attachment.title || content.attachment.contentType} (${content.attachment.size || 'size unknown'} bytes)`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.context?.period) {
      chunks.push({
        id: `${resource.id}-context-period`,
        type: 'granular_fact',
        content: `Context period: ${resource.context.period.start} to ${resource.context.period.end || 'ongoing'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Document Reference: ${resource.type?.text || 'Document'} for ${resource.subject?.display || 'patient'} - Status: ${resource.status}, Date: ${resource.date || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Clinical Document: ${resource.type?.text || 'N/A'} - ${resource.description || 'No description'}, Status: ${resource.status}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract type codes
    if (resource.type) {
      codes.push(...this.extractClinicalCodes(resource.type));
    }
    
    // Extract category codes
    if (resource.category) {
      resource.category.forEach((cat: any) => {
        codes.push(...this.extractClinicalCodes(cat));
      });
    }
    
    // Extract security label codes
    if (resource.securityLabel) {
      resource.securityLabel.forEach((label: any) => {
        codes.push(...this.extractClinicalCodes(label));
      });
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.date,
      clinicalCodes: codes,
      references: [
        ...(resource.subject ? [`${resource.subject.reference}`] : []),
        ...(resource.author ? resource.author.map((a: any) => a.reference) : []),
        ...(resource.authenticator ? [`${resource.authenticator.reference}`] : []),
        ...(resource.custodian ? [`${resource.custodian.reference}`] : []),
        ...(resource.context?.encounter ? resource.context.encounter.map((e: any) => e.reference) : [])
      ],
      tags: [
        'clinical-document',
        'medical-record',
        ...(resource.status ? [resource.status] : []),
        ...(resource.type?.text ? [resource.type.text.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.docStatus ? [resource.docStatus] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    // Check document type for critical documents
    const criticalTypes = ['discharge summary', 'emergency', 'critical', 'urgent'];
    const typeText = resource.type?.text?.toLowerCase() || resource.type?.coding?.[0]?.display?.toLowerCase() || '';
    
    if (criticalTypes.some(t => typeText.includes(t))) return 'critical';
    
    // Check if superseded or entered in error
    if (resource.status === 'entered-in-error') return 'abnormal';
    if (resource.docStatus === 'preliminary') return 'abnormal';
    
    return 'normal';
  }
}