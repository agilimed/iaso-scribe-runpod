import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class OrganizationTemplate extends BaseResourceTemplate {
  resourceType = 'Organization';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'critical';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Main organization summary chunk
    const organizationSummary = this.generateOrganizationSummary(resource);
    chunks.push(this.createChunk(organizationSummary, 'resource_summary', resource));
    
    // Granular fact chunks
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: '', // Organizations don't have patients
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'admin',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: resource.meta?.lastUpdated?.split('T')[0] || new Date().toISOString().split('T')[0],
        encounter_id: undefined,
        episode_id: undefined
      },
      chunk_type: 'resource_summary',
      chunk_level: 'patient',
      searchable_codes: this.extractOrganizationCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Inactive organizations might be abnormal
    if (resource.active === false) {
      return 'abnormal';
    }
    
    return 'normal';
  }

  private generateOrganizationSummary(resource: any): string {
    const name = resource.name || 'Unknown Organization';
    const type = this.extractOrganizationType(resource);
    const contact = this.extractPrimaryContact(resource);
    const active = resource.active !== false ? 'active' : 'inactive';
    
    let summary = `${name}`;
    
    if (type) {
      summary += ` is a ${type} organization`;
    }
    
    if (contact) {
      summary += ` with ${contact} contact information`;
    }
    
    summary += ` - ${active} status`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    
    // Name fact
    if (resource.name) {
      facts.push(this.createChunk(
        `Organization name: ${resource.name}`,
        'granular_fact',
        resource
      ));
    }
    
    // Alias facts
    if (resource.alias?.length > 0) {
      resource.alias.forEach((alias: string) => {
        facts.push(this.createChunk(
          `Organization alias: ${alias}`,
          'granular_fact',
          resource
        ));
      });
    }
    
    // Type facts
    if (resource.type?.length > 0) {
      resource.type.forEach((type: any) => {
        const typeDisplay = type.coding?.[0]?.display || type.text;
        if (typeDisplay) {
          facts.push(this.createChunk(
            `Organization type: ${typeDisplay}`,
            'granular_fact',
            resource
          ));
        }
      });
    }
    
    // Identifier facts
    if (resource.identifier?.length > 0) {
      resource.identifier.forEach((id: any) => {
        const system = id.system || 'unknown system';
        const value = id.value;
        const type = id.type?.coding?.[0]?.display || id.type?.text || 'identifier';
        
        facts.push(this.createChunk(
          `${type}: ${value} (${system})`,
          'granular_fact',
          resource
        ));
      });
    }
    
    // Contact facts
    if (resource.telecom?.length > 0) {
      resource.telecom.forEach((contact: any) => {
        facts.push(this.createChunk(
          `Contact ${contact.system}: ${contact.value}`,
          'granular_fact',
          resource
        ));
      });
    }
    
    // Address facts
    if (resource.address?.length > 0) {
      resource.address.forEach((addr: any, index: number) => {
        const addressText = this.formatAddress(addr);
        const useType = addr.use || 'primary';
        facts.push(this.createChunk(
          `${useType} address: ${addressText}`,
          'granular_fact',
          resource
        ));
      });
    }
    
    // Part of fact
    if (resource.partOf) {
      const parentOrg = resource.partOf.display || resource.partOf.reference;
      facts.push(this.createChunk(
        `Part of: ${parentOrg}`,
        'granular_fact',
        resource
      ));
    }
    
    // Contact person facts
    if (resource.contact?.length > 0) {
      resource.contact.forEach((contact: any) => {
        const name = contact.name?.family || 
                   contact.name?.given?.join(' ') || 
                   'Unknown contact';
        const purpose = contact.purpose?.coding?.[0]?.display || 
                       contact.purpose?.text || 
                       'general contact';
        
        facts.push(this.createChunk(
          `Contact person (${purpose}): ${name}`,
          'granular_fact',
          resource
        ));
      });
    }
    
    // Endpoint facts
    if (resource.endpoint?.length > 0) {
      resource.endpoint.forEach((endpoint: any) => {
        const endpointRef = endpoint.display || endpoint.reference;
        facts.push(this.createChunk(
          `Endpoint: ${endpointRef}`,
          'granular_fact',
          resource
        ));
      });
    }
    
    return facts;
  }

  private extractOrganizationType(resource: any): string | null {
    if (resource.type?.length > 0) {
      return resource.type[0].coding?.[0]?.display || 
             resource.type[0].text || 
             null;
    }
    
    return null;
  }

  private extractPrimaryContact(resource: any): string | null {
    if (resource.telecom?.length > 0) {
      const primaryContact = resource.telecom[0];
      return `${primaryContact.system} ${primaryContact.value}`;
    }
    
    return null;
  }

  private formatAddress(address: any): string {
    const parts = [];
    
    if (address.line?.length) {
      parts.push(address.line.join(' '));
    }
    
    if (address.city) parts.push(address.city);
    if (address.state) parts.push(address.state);
    if (address.postalCode) parts.push(address.postalCode);
    if (address.country) parts.push(address.country);
    
    return parts.join(', ') || 'Unknown address';
  }

  private extractOrganizationCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Extract identifier values
    if (resource.identifier?.length > 0) {
      resource.identifier.forEach((id: any) => {
        if (id.value) codes.push(id.value);
        if (id.type?.coding?.[0]?.code) codes.push(id.type.coding[0].code);
      });
    }
    
    // Extract type codes
    if (resource.type?.length > 0) {
      resource.type.forEach((type: any) => {
        if (type.coding) {
          type.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    // Extract organization name for search
    if (resource.name) {
      codes.push(resource.name.toLowerCase());
    }
    
    // Extract aliases
    if (resource.alias?.length > 0) {
      resource.alias.forEach((alias: string) => {
        codes.push(alias.toLowerCase());
      });
    }
    
    return codes;
  }
}