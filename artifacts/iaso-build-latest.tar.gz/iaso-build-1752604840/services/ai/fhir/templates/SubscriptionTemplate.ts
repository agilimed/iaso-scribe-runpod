import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../ResourceTemplateService';

export class SubscriptionTemplate extends BaseResourceTemplate {
  resourceType = 'Subscription';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'low';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.status) {
      chunks.push({
        id: `${resource.id}-status`,
        type: 'granular_fact',
        content: `Subscription status: ${resource.status}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.reason) {
      chunks.push({
        id: `${resource.id}-reason`,
        type: 'granular_fact',
        content: `Subscription reason: ${resource.reason}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.criteria) {
      chunks.push({
        id: `${resource.id}-criteria`,
        type: 'granular_fact',
        content: `Criteria: ${resource.criteria}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.channel) {
      chunks.push({
        id: `${resource.id}-channel`,
        type: 'granular_fact',
        content: `Channel type: ${resource.channel.type}, Endpoint: ${resource.channel.endpoint || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.end) {
      chunks.push({
        id: `${resource.id}-end`,
        type: 'granular_fact',
        content: `Ends on: ${resource.end}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.contact) {
      resource.contact.forEach((contact: any, index: number) => {
        chunks.push({
          id: `${resource.id}-contact-${index}`,
          type: 'granular_fact',
          content: `Contact ${index + 1}: ${contact.system} - ${contact.value}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.error) {
      chunks.push({
        id: `${resource.id}-error`,
        type: 'granular_fact',
        content: `Error: ${resource.error}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.tag) {
      resource.tag.forEach((tag: any, index: number) => {
        chunks.push({
          id: `${resource.id}-tag-${index}`,
          type: 'granular_fact',
          content: `Tag: ${tag.system} - ${tag.code}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Subscription: ${resource.reason || 'Event notification'} - Status: ${resource.status}, Channel: ${resource.channel?.type || 'N/A'}, Criteria: ${resource.criteria || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Event Subscription: ${resource.reason || 'N/A'} - ${resource.status}, ${resource.channel?.type || 'N/A'} channel`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract tag codes
    if (resource.tag) {
      resource.tag.forEach((tag: any) => {
        codes.push({
          system: tag.system,
          code: tag.code,
          display: tag.display
        });
      });
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated,
      clinicalCodes: codes,
      references: [],
      tags: [
        'subscription',
        'event-notification',
        'real-time',
        ...(resource.status ? [resource.status] : []),
        ...(resource.channel?.type ? [resource.channel.type.toLowerCase()] : []),
        ...(resource.error ? ['has-error'] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    // Error state subscriptions
    if (resource.status === 'error') return 'abnormal';
    
    // Off status
    if (resource.status === 'off') return 'abnormal';
    
    // Expired subscriptions
    if (resource.end && new Date(resource.end) < new Date()) return 'abnormal';
    
    // Critical event subscriptions (based on criteria)
    if (resource.criteria) {
      const criteriaLower = resource.criteria.toLowerCase();
      if (criteriaLower.includes('critical') || 
          criteriaLower.includes('emergency') || 
          criteriaLower.includes('alert')) {
        return 'critical';
      }
    }
    
    if (resource.status === 'active' || resource.status === 'requested') return 'normal';
    
    return 'normal';
  }
}