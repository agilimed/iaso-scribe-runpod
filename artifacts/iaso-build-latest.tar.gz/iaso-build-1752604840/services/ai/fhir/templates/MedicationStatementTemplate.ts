import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class MedicationStatementTemplate extends BaseResourceTemplate {
  resourceType = 'MedicationStatement';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const statementSummary = this.generateStatementSummary(resource);
    chunks.push(this.createChunk(statementSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'medications',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'patient',
      searchable_codes: this.extractMedicationCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // High-alert medications
    if (this.isHighAlertMedication(resource)) {
      return 'critical';
    }
    
    // Stopped medications due to adverse events
    if (resource.status === 'stopped' && this.hasAdverseEventReason(resource)) {
      return 'critical';
    }
    
    // Not taken as prescribed
    if (resource.status === 'not-taken' || resource.adherence === 'poor') {
      return 'abnormal';
    }
    
    return 'normal';
  }

  private generateStatementSummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const medication = this.extractMedicationName(resource);
    const status = resource.status || 'unknown';
    const effective = this.extractEffectivePeriod(resource);
    
    let summary = `Patient ${patientId} medication statement: ${medication}`;
    
    if (effective) {
      summary += ` (${effective})`;
    }
    
    summary += ` - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Medication name
    const medication = this.extractMedicationName(resource);
    facts.push(this.createChunk(
      `Medication: ${medication}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Category
    if (resource.category) {
      const category = resource.category.coding?.[0]?.display || resource.category.text;
      facts.push(this.createChunk(
        `Category: ${category}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Effective period
    if (resource.effectiveDateTime) {
      facts.push(this.createChunk(
        `Effective date: ${new Date(resource.effectiveDateTime).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    } else if (resource.effectivePeriod) {
      const start = resource.effectivePeriod.start ? new Date(resource.effectivePeriod.start).toISOString().split('T')[0] : '';
      const end = resource.effectivePeriod.end ? new Date(resource.effectivePeriod.end).toISOString().split('T')[0] : '';
      
      if (start && end) {
        facts.push(this.createChunk(
          `Effective period: ${start} to ${end}`,
          'granular_fact',
          resource,
          significance
        ));
      } else if (start) {
        facts.push(this.createChunk(
          `Effective from: ${start}`,
          'granular_fact',
          resource,
          significance
        ));
      }
    }
    
    // Date asserted
    if (resource.dateAsserted) {
      facts.push(this.createChunk(
        `Date asserted: ${new Date(resource.dateAsserted).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Information source
    if (resource.informationSource) {
      const source = resource.informationSource.display || resource.informationSource.reference;
      facts.push(this.createChunk(
        `Information source: ${source}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Derived from
    if (resource.derivedFrom?.length > 0) {
      resource.derivedFrom.forEach((derived: any) => {
        const source = derived.display || derived.reference;
        facts.push(this.createChunk(
          `Derived from: ${source}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Reason code
    if (resource.reasonCode?.length > 0) {
      resource.reasonCode.forEach((reason: any) => {
        const reasonDisplay = reason.coding?.[0]?.display || reason.text;
        facts.push(this.createChunk(
          `Reason: ${reasonDisplay}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Reason reference
    if (resource.reasonReference?.length > 0) {
      resource.reasonReference.forEach((ref: any) => {
        const reason = ref.display || ref.reference;
        facts.push(this.createChunk(
          `Reason reference: ${reason}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Dosage
    if (resource.dosage?.length > 0) {
      resource.dosage.forEach((dosage: any, index: number) => {
        if (dosage.text) {
          facts.push(this.createChunk(
            `Dosage ${index + 1}: ${dosage.text}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (dosage.timing?.repeat) {
          const repeat = dosage.timing.repeat;
          if (repeat.frequency && repeat.period) {
            facts.push(this.createChunk(
              `Dosage ${index + 1} frequency: ${repeat.frequency} times per ${repeat.periodUnit || repeat.period}`,
              'granular_fact',
              resource,
              significance
            ));
          }
        }
        
        if (dosage.route) {
          const route = dosage.route.coding?.[0]?.display || dosage.route.text;
          facts.push(this.createChunk(
            `Dosage ${index + 1} route: ${route}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (dosage.doseAndRate?.length > 0) {
          dosage.doseAndRate.forEach((dar: any) => {
            if (dar.doseQuantity) {
              facts.push(this.createChunk(
                `Dosage ${index + 1} dose: ${dar.doseQuantity.value} ${dar.doseQuantity.unit}`,
                'granular_fact',
                resource,
                significance
              ));
            }
          });
        }
      });
    }
    
    // Notes
    if (resource.note?.length > 0) {
      resource.note.forEach((note: any) => {
        if (note.text) {
          facts.push(this.createChunk(
            `Note: ${note.text}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    return facts;
  }

  private extractMedicationName(resource: any): string {
    if (resource.medicationCodeableConcept) {
      return resource.medicationCodeableConcept.coding?.[0]?.display || 
             resource.medicationCodeableConcept.text || 
             'Unknown medication';
    }
    
    if (resource.medicationReference) {
      return resource.medicationReference.display || 
             resource.medicationReference.reference || 
             'Unknown medication';
    }
    
    return 'Unknown medication';
  }

  private extractEffectivePeriod(resource: any): string | null {
    if (resource.effectiveDateTime) {
      return new Date(resource.effectiveDateTime).toISOString().split('T')[0];
    }
    
    if (resource.effectivePeriod) {
      const start = resource.effectivePeriod.start ? new Date(resource.effectivePeriod.start).toISOString().split('T')[0] : '';
      const end = resource.effectivePeriod.end ? new Date(resource.effectivePeriod.end).toISOString().split('T')[0] : '';
      
      if (start && end) {
        return `${start} to ${end}`;
      } else if (start) {
        return `from ${start}`;
      } else if (end) {
        return `until ${end}`;
      }
    }
    
    return null;
  }

  private extractMedicationCodes(resource: any): string[] {
    const codes: string[] = [];
    
    if (resource.medicationCodeableConcept?.coding) {
      resource.medicationCodeableConcept.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    if (resource.medicationCodeableConcept?.text) {
      codes.push(resource.medicationCodeableConcept.text.toLowerCase());
    }
    
    return codes;
  }

  private isHighAlertMedication(resource: any): boolean {
    const medicationName = this.extractMedicationName(resource).toLowerCase();
    const highAlertMedications = [
      'insulin', 'warfarin', 'heparin', 'digoxin', 'lithium',
      'metformin', 'chemotherapy', 'morphine', 'fentanyl'
    ];
    
    return highAlertMedications.some(med => medicationName.includes(med));
  }

  private hasAdverseEventReason(resource: any): boolean {
    if (resource.reasonCode?.length > 0) {
      return resource.reasonCode.some((reason: any) => {
        const reasonText = reason.coding?.[0]?.display || reason.text || '';
        return reasonText.toLowerCase().includes('adverse') || 
               reasonText.toLowerCase().includes('reaction') ||
               reasonText.toLowerCase().includes('allergy');
      });
    }
    
    return false;
  }
}
