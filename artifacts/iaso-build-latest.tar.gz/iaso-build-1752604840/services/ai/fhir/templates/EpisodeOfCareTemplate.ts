import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../ResourceTemplateService';

export class EpisodeOfCareTemplate extends BaseResourceTemplate {
  resourceType = 'EpisodeOfCare';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.status) {
      chunks.push({
        id: `${resource.id}-status`,
        type: 'granular_fact',
        content: `Episode status: ${resource.status}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.type) {
      resource.type.forEach((type: any, index: number) => {
        chunks.push({
          id: `${resource.id}-type-${index}`,
          type: 'granular_fact',
          content: `Episode type: ${type.text || type.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.diagnosis) {
      resource.diagnosis.forEach((diag: any, index: number) => {
        chunks.push({
          id: `${resource.id}-diagnosis-${index}`,
          type: 'granular_fact',
          content: `Diagnosis ${index + 1}: ${diag.condition.display || diag.condition.reference} (Role: ${diag.role?.text || 'N/A'}, Rank: ${diag.rank || 'N/A'})`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.period) {
      chunks.push({
        id: `${resource.id}-period`,
        type: 'granular_fact',
        content: `Episode period: ${resource.period.start} to ${resource.period.end || 'ongoing'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.managingOrganization) {
      chunks.push({
        id: `${resource.id}-managing-org`,
        type: 'granular_fact',
        content: `Managing organization: ${resource.managingOrganization.display || resource.managingOrganization.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.careManager) {
      chunks.push({
        id: `${resource.id}-care-manager`,
        type: 'granular_fact',
        content: `Care manager: ${resource.careManager.display || resource.careManager.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.team) {
      resource.team.forEach((team: any, index: number) => {
        chunks.push({
          id: `${resource.id}-team-${index}`,
          type: 'granular_fact',
          content: `Care team: ${team.display || team.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.statusHistory) {
      resource.statusHistory.forEach((history: any, index: number) => {
        chunks.push({
          id: `${resource.id}-status-history-${index}`,
          type: 'granular_fact',
          content: `Status history: ${history.status} from ${history.period.start} to ${history.period.end || 'current'}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.referralRequest) {
      resource.referralRequest.forEach((referral: any, index: number) => {
        chunks.push({
          id: `${resource.id}-referral-${index}`,
          type: 'granular_fact',
          content: `Referral: ${referral.display || referral.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    // Resource summary
    const duration = resource.period ? this.calculateDuration(resource.period.start, resource.period.end) : 'N/A';
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Episode of Care: ${resource.type?.[0]?.text || 'Care episode'} for ${resource.patient?.display || 'patient'} - Status: ${resource.status}, Duration: ${duration}, ${resource.diagnosis?.length || 0} diagnoses`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Care Episode: ${resource.type?.[0]?.text || 'N/A'} - ${resource.status}, Primary diagnosis: ${resource.diagnosis?.[0]?.condition.display || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract type codes
    if (resource.type) {
      resource.type.forEach((type: any) => {
        codes.push(...this.extractClinicalCodes(type));
      });
    }
    
    // Extract diagnosis role codes
    if (resource.diagnosis) {
      resource.diagnosis.forEach((diag: any) => {
        if (diag.role) {
          codes.push(...this.extractClinicalCodes(diag.role));
        }
      });
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.period?.start,
      clinicalCodes: codes,
      references: [
        ...(resource.patient ? [`${resource.patient.reference}`] : []),
        ...(resource.managingOrganization ? [`${resource.managingOrganization.reference}`] : []),
        ...(resource.careManager ? [`${resource.careManager.reference}`] : []),
        ...(resource.team ? resource.team.map((t: any) => t.reference) : []),
        ...(resource.diagnosis ? resource.diagnosis.map((d: any) => d.condition.reference) : []),
        ...(resource.referralRequest ? resource.referralRequest.map((r: any) => r.reference) : [])
      ],
      tags: [
        'episode-of-care',
        'care-coordination',
        'patient-journey',
        ...(resource.status ? [resource.status] : []),
        ...(resource.type ? resource.type.map((t: any) => t.text?.toLowerCase().replace(/\s+/g, '-')).filter(Boolean) : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    // Active episodes with multiple diagnoses
    if (resource.status === 'active' && resource.diagnosis?.length > 3) return 'abnormal';
    
    // Episodes with high-rank diagnoses
    if (resource.diagnosis?.some((d: any) => d.rank === 1 && d.role?.text?.toLowerCase().includes('primary'))) {
      return 'abnormal';
    }
    
    // Long-running episodes
    if (resource.period?.start) {
      const duration = this.calculateDurationInDays(resource.period.start, resource.period.end || new Date().toISOString());
      if (duration > 180) return 'abnormal'; // Episodes longer than 6 months
    }
    
    if (resource.status === 'finished' || resource.status === 'cancelled') return 'normal';
    
    return 'normal';
  }

  private calculateDuration(start: string, end?: string): string {
    const startDate = new Date(start);
    const endDate = end ? new Date(end) : new Date();
    const days = Math.floor((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    
    if (days < 7) return `${days} days`;
    if (days < 30) return `${Math.floor(days / 7)} weeks`;
    if (days < 365) return `${Math.floor(days / 30)} months`;
    return `${Math.floor(days / 365)} years`;
  }

  private calculateDurationInDays(start: string, end: string): number {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return Math.floor((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
  }
}