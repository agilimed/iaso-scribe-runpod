import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class MedicationRequestTemplate extends BaseResourceTemplate {
  resourceType = 'MedicationRequest';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const medicationSummary = this.generateMedicationSummary(resource);
    chunks.push(this.createChunk(medicationSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'medications',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'encounter',
      searchable_codes: this.extractMedicationCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // High-alert medications
    const medicationCode = this.getMedicationCode(resource);
    if (medicationCode && this.isHighAlertMedication(medicationCode)) {
      return 'critical';
    }
    
    // Controlled substances
    if (this.isControlledSubstance(resource)) {
      return 'abnormal';
    }
    
    // Priority prescriptions
    if (resource.priority === 'urgent' || resource.priority === 'stat') {
      return 'critical';
    }
    
    return 'normal';
  }

  private generateMedicationSummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const medication = this.extractMedicationName(resource);
    const dosage = this.extractDosage(resource);
    const frequency = this.extractFrequency(resource);
    const date = this.extractDate(resource);
    const status = resource.status || 'unknown';
    
    let summary = `Patient ${patientId} was prescribed ${medication}`;
    
    if (dosage) {
      summary += ` ${dosage}`;
    }
    
    if (frequency) {
      summary += ` ${frequency}`;
    }
    
    if (date) {
      summary += ` on ${date}`;
    }
    
    summary += ` - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Medication name
    const medication = this.extractMedicationName(resource);
    facts.push(this.createChunk(
      `Medication: ${medication}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Intent
    if (resource.intent) {
      facts.push(this.createChunk(
        `Intent: ${resource.intent}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Priority
    if (resource.priority) {
      facts.push(this.createChunk(
        `Priority: ${resource.priority}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Category
    if (resource.category?.length > 0) {
      resource.category.forEach((cat: any) => {
        const category = cat.coding?.[0]?.display || cat.text;
        facts.push(this.createChunk(
          `Category: ${category}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Dosage instructions
    if (resource.dosageInstruction?.length > 0) {
      resource.dosageInstruction.forEach((dosage: any, index: number) => {
        if (dosage.text) {
          facts.push(this.createChunk(
            `Dosage instruction: ${dosage.text}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (dosage.route) {
          const route = dosage.route.coding?.[0]?.display || dosage.route.text;
          facts.push(this.createChunk(
            `Route: ${route}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (dosage.doseAndRate?.length > 0) {
          dosage.doseAndRate.forEach((dar: any) => {
            if (dar.doseQuantity) {
              facts.push(this.createChunk(
                `Dose: ${dar.doseQuantity.value} ${dar.doseQuantity.unit}`,
                'granular_fact',
                resource,
                significance
              ));
            }
          });
        }
      });
    }
    
    // Reason
    if (resource.reasonCode?.length > 0) {
      resource.reasonCode.forEach((reason: any) => {
        const reasonDisplay = reason.coding?.[0]?.display || reason.text;
        facts.push(this.createChunk(
          `Reason: ${reasonDisplay}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Requester
    if (resource.requester) {
      const requester = resource.requester.display || resource.requester.reference;
      facts.push(this.createChunk(
        `Prescribed by: ${requester}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Substitution
    if (resource.substitution) {
      const allowedValue = resource.substitution.allowedBoolean !== undefined ? 
        resource.substitution.allowedBoolean : 
        resource.substitution.allowedCodeableConcept?.coding?.[0]?.display;
      
      facts.push(this.createChunk(
        `Substitution allowed: ${allowedValue}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Dispense request
    if (resource.dispenseRequest) {
      const dr = resource.dispenseRequest;
      
      if (dr.quantity) {
        facts.push(this.createChunk(
          `Dispense quantity: ${dr.quantity.value} ${dr.quantity.unit}`,
          'granular_fact',
          resource,
          significance
        ));
      }
      
      if (dr.numberOfRepeatsAllowed !== undefined) {
        facts.push(this.createChunk(
          `Refills allowed: ${dr.numberOfRepeatsAllowed}`,
          'granular_fact',
          resource,
          significance
        ));
      }
      
      if (dr.expectedSupplyDuration) {
        facts.push(this.createChunk(
          `Supply duration: ${dr.expectedSupplyDuration.value} ${dr.expectedSupplyDuration.unit}`,
          'granular_fact',
          resource,
          significance
        ));
      }
    }
    
    return facts;
  }

  private extractMedicationName(resource: any): string {
    // Check medicationCodeableConcept first
    if (resource.medicationCodeableConcept) {
      return resource.medicationCodeableConcept.coding?.[0]?.display || 
             resource.medicationCodeableConcept.text || 
             'Unknown medication';
    }
    
    // Check medicationReference
    if (resource.medicationReference) {
      return resource.medicationReference.display || 
             resource.medicationReference.reference || 
             'Unknown medication';
    }
    
    return 'Unknown medication';
  }

  private extractDosage(resource: any): string | null {
    if (resource.dosageInstruction?.length > 0) {
      const dosage = resource.dosageInstruction[0];
      
      if (dosage.doseAndRate?.length > 0) {
        const dar = dosage.doseAndRate[0];
        if (dar.doseQuantity) {
          return `${dar.doseQuantity.value} ${dar.doseQuantity.unit}`;
        }
      }
      
      // Fallback to text instruction
      if (dosage.text) {
        return dosage.text;
      }
    }
    
    return null;
  }

  private extractFrequency(resource: any): string | null {
    if (resource.dosageInstruction?.length > 0) {
      const dosage = resource.dosageInstruction[0];
      
      if (dosage.timing?.repeat) {
        const repeat = dosage.timing.repeat;
        
        if (repeat.frequency && repeat.period) {
          return `${repeat.frequency} times per ${repeat.periodUnit || repeat.period}`;
        }
      }
      
      // Check for common frequency codes
      if (dosage.timing?.code) {
        return dosage.timing.code.coding?.[0]?.display || 
               dosage.timing.code.text || 
               null;
      }
    }
    
    return null;
  }

  private getMedicationCode(resource: any): string | null {
    if (resource.medicationCodeableConcept?.coding?.length > 0) {
      return resource.medicationCodeableConcept.coding[0].code;
    }
    
    return null;
  }

  private extractMedicationCodes(resource: any): string[] {
    const codes: string[] = [];
    
    if (resource.medicationCodeableConcept?.coding) {
      resource.medicationCodeableConcept.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    if (resource.medicationCodeableConcept?.text) {
      codes.push(resource.medicationCodeableConcept.text.toLowerCase());
    }
    
    return codes;
  }

  private isHighAlertMedication(code: string): boolean {
    // High-alert medication codes (simplified list)
    const highAlertCodes = [
      // Insulin
      '5856', '51428',
      // Warfarin  
      '11289',
      // Digoxin
      '3407',
      // Heparin
      '4603',
      // Chemotherapy agents
      '40048', '56946'
    ];
    
    return highAlertCodes.includes(code);
  }

  private isControlledSubstance(resource: any): boolean {
    // Check for controlled substance categories or codes
    const categories = resource.category || [];
    
    return categories.some((cat: any) => {
      const code = cat.coding?.[0]?.code;
      return code && ['controlled', 'narcotic', 'schedule-ii'].includes(code);
    });
  }
}