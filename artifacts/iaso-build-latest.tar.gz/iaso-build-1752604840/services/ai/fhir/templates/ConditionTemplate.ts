import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class ConditionTemplate extends BaseResourceTemplate {
  resourceType = 'Condition';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Main condition summary chunk
    const conditionSummary = this.generateConditionSummary(resource);
    chunks.push(this.createChunk(conditionSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    // Granular fact chunks
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'conditions',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'encounter',
      searchable_codes: this.extractConditionCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Check severity
    const severity = resource.severity?.coding?.[0]?.code;
    if (severity) {
      const criticalSeverities = ['24484000', '6736007']; // severe, moderate-severe
      const abnormalSeverities = ['255604002', '371923003']; // mild, moderate
      
      if (criticalSeverities.includes(severity)) {
        return 'critical';
      }
      
      if (abnormalSeverities.includes(severity)) {
        return 'abnormal';
      }
    }
    
    // Check clinical status
    const clinicalStatus = resource.clinicalStatus?.coding?.[0]?.code;
    if (clinicalStatus === 'active') {
      // Active conditions are at least abnormal
      return 'abnormal';
    }
    
    // Check for critical condition codes
    const conditionCode = resource.code?.coding?.[0]?.code;
    if (conditionCode && this.isCriticalCondition(conditionCode)) {
      return 'critical';
    }
    
    return 'normal';
  }

  private generateConditionSummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const conditionName = this.extractConditionName(resource);
    const severity = this.extractSeverity(resource);
    const clinicalStatus = this.extractClinicalStatus(resource);
    const onsetDate = this.extractOnsetDate(resource);
    
    let summary = `Patient ${patientId} has ${severity ? severity + ' ' : ''}${conditionName}`;
    
    if (onsetDate) {
      summary += ` diagnosed on ${onsetDate}`;
    }
    
    summary += `, status: ${clinicalStatus}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Condition name fact
    const conditionName = this.extractConditionName(resource);
    if (conditionName) {
      facts.push(this.createChunk(
        `Condition: ${conditionName}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Severity fact
    const severity = this.extractSeverity(resource);
    if (severity) {
      facts.push(this.createChunk(
        `Severity: ${severity}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Clinical status fact
    const clinicalStatus = this.extractClinicalStatus(resource);
    if (clinicalStatus) {
      facts.push(this.createChunk(
        `Clinical status: ${clinicalStatus}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Verification status fact
    const verificationStatus = this.extractVerificationStatus(resource);
    if (verificationStatus) {
      facts.push(this.createChunk(
        `Verification status: ${verificationStatus}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Onset date fact
    const onsetDate = this.extractOnsetDate(resource);
    if (onsetDate) {
      facts.push(this.createChunk(
        `Onset date: ${onsetDate}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Body site fact
    if (resource.bodySite?.length > 0) {
      const bodySite = resource.bodySite[0].coding?.[0]?.display || 
                     resource.bodySite[0].text || 
                     'unspecified location';
      facts.push(this.createChunk(
        `Body site: ${bodySite}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Category fact
    if (resource.category?.length > 0) {
      const category = resource.category[0].coding?.[0]?.display || 
                      resource.category[0].text || 
                      'unspecified category';
      facts.push(this.createChunk(
        `Category: ${category}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Asserter fact
    if (resource.asserter) {
      const asserter = resource.asserter.display || resource.asserter.reference;
      facts.push(this.createChunk(
        `Diagnosed by: ${asserter}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Notes fact
    if (resource.note?.length > 0) {
      resource.note.forEach((note: any) => {
        if (note.text) {
          facts.push(this.createChunk(
            `Note: ${note.text}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    return facts;
  }

  private extractConditionName(resource: any): string {
    return resource.code?.coding?.[0]?.display || 
           resource.code?.text || 
           'Unknown condition';
  }

  private extractSeverity(resource: any): string | null {
    if (resource.severity?.coding?.[0]?.display) {
      return resource.severity.coding[0].display;
    }
    
    if (resource.severity?.text) {
      return resource.severity.text;
    }
    
    return null;
  }

  private extractClinicalStatus(resource: any): string {
    return resource.clinicalStatus?.coding?.[0]?.display || 
           resource.clinicalStatus?.coding?.[0]?.code || 
           'unknown';
  }

  private extractVerificationStatus(resource: any): string | null {
    return resource.verificationStatus?.coding?.[0]?.display || 
           resource.verificationStatus?.coding?.[0]?.code || 
           null;
  }

  private extractOnsetDate(resource: any): string | null {
    if (resource.onsetDateTime) {
      return new Date(resource.onsetDateTime).toISOString().split('T')[0];
    }
    
    if (resource.onsetPeriod?.start) {
      return new Date(resource.onsetPeriod.start).toISOString().split('T')[0];
    }
    
    if (resource.onsetString) {
      return resource.onsetString;
    }
    
    return null;
  }

  private extractConditionCodes(resource: any): string[] {
    const codes: string[] = [];
    
    if (resource.code?.coding) {
      resource.code.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    if (resource.code?.text) {
      codes.push(resource.code.text.toLowerCase());
    }
    
    // Add category codes
    if (resource.category?.length > 0) {
      resource.category.forEach((category: any) => {
        if (category.coding) {
          category.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
            if (coding.display) codes.push(coding.display.toLowerCase());
          });
        }
      });
    }
    
    return codes;
  }

  private isCriticalCondition(conditionCode: string): boolean {
    // Common critical condition codes (ICD-10 and SNOMED)
    const criticalConditions = [
      // Myocardial infarction
      'I21', 'I22', '22298006',
      // Stroke
      'I63', 'I64', '230690007',
      // Sepsis
      'A41', 'R65', '91302008',
      // Respiratory failure
      'J96', '65710008',
      // Diabetic ketoacidosis
      'E10.1', 'E11.1', '420662003',
      // Pulmonary embolism
      'I26', '59282003',
      // Cardiac arrest
      'I46', '410546004',
      // Acute kidney injury
      'N17', '14669001'
    ];
    
    return criticalConditions.some(code => conditionCode.startsWith(code));
  }
}