import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class AllergyIntoleranceTemplate extends BaseResourceTemplate {
  resourceType = 'AllergyIntolerance';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'critical';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const allergySummary = this.generateAllergySummary(resource);
    chunks.push(this.createChunk(allergySummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'conditions',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'patient',
      searchable_codes: this.extractAllergyCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Severe or life-threatening allergies
    const criticality = resource.criticality;
    if (criticality === 'high' || criticality === 'critical') {
      return 'critical';
    }
    
    // Check for severe reactions
    if (resource.reaction?.length > 0) {
      const hasSevereReaction = resource.reaction.some((reaction: any) => {
        const severity = reaction.severity;
        return severity === 'severe' || severity === 'life-threatening';
      });
      
      if (hasSevereReaction) {
        return 'critical';
      }
    }
    
    // Active allergies are generally abnormal
    if (resource.clinicalStatus?.coding?.[0]?.code === 'active') {
      return 'abnormal';
    }
    
    return 'normal';
  }

  private generateAllergySummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const substance = this.extractSubstance(resource);
    const criticality = resource.criticality || 'unknown criticality';
    const clinicalStatus = resource.clinicalStatus?.coding?.[0]?.display || 'unknown status';
    const reactions = this.extractReactionSummary(resource);
    
    let summary = `Patient ${patientId} has ${criticality} allergy to ${substance}`;
    
    if (reactions) {
      summary += ` with ${reactions} reactions`;
    }
    
    summary += ` - ${clinicalStatus}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Substance/allergen
    const substance = this.extractSubstance(resource);
    facts.push(this.createChunk(
      `Allergen: ${substance}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Clinical status
    if (resource.clinicalStatus) {
      const status = resource.clinicalStatus.coding?.[0]?.display || resource.clinicalStatus.coding?.[0]?.code;
      facts.push(this.createChunk(
        `Clinical status: ${status}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Verification status
    if (resource.verificationStatus) {
      const verification = resource.verificationStatus.coding?.[0]?.display || resource.verificationStatus.coding?.[0]?.code;
      facts.push(this.createChunk(
        `Verification status: ${verification}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Type
    if (resource.type) {
      facts.push(this.createChunk(
        `Type: ${resource.type}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Category
    if (resource.category?.length > 0) {
      resource.category.forEach((category: string) => {
        facts.push(this.createChunk(
          `Category: ${category}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Criticality
    if (resource.criticality) {
      facts.push(this.createChunk(
        `Criticality: ${resource.criticality}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Onset
    if (resource.onsetDateTime) {
      facts.push(this.createChunk(
        `Onset: ${new Date(resource.onsetDateTime).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    } else if (resource.onsetString) {
      facts.push(this.createChunk(
        `Onset: ${resource.onsetString}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Recorder
    if (resource.recorder) {
      const recorder = resource.recorder.display || resource.recorder.reference;
      facts.push(this.createChunk(
        `Recorded by: ${recorder}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Asserter
    if (resource.asserter) {
      const asserter = resource.asserter.display || resource.asserter.reference;
      facts.push(this.createChunk(
        `Reported by: ${asserter}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Last occurrence
    if (resource.lastOccurrence) {
      facts.push(this.createChunk(
        `Last occurrence: ${new Date(resource.lastOccurrence).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Reactions
    if (resource.reaction?.length > 0) {
      resource.reaction.forEach((reaction: any, index: number) => {
        // Manifestations
        if (reaction.manifestation?.length > 0) {
          reaction.manifestation.forEach((manifestation: any) => {
            const display = manifestation.coding?.[0]?.display || manifestation.text;
            facts.push(this.createChunk(
              `Reaction: ${display}`,
              'granular_fact',
              resource,
              significance
            ));
          });
        }
        
        // Severity
        if (reaction.severity) {
          facts.push(this.createChunk(
            `Reaction severity: ${reaction.severity}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        // Exposure route
        if (reaction.exposureRoute) {
          const route = reaction.exposureRoute.coding?.[0]?.display || reaction.exposureRoute.text;
          facts.push(this.createChunk(
            `Exposure route: ${route}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        // Description
        if (reaction.description) {
          facts.push(this.createChunk(
            `Reaction description: ${reaction.description}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        // Onset
        if (reaction.onset) {
          facts.push(this.createChunk(
            `Reaction onset: ${reaction.onset}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    // Notes
    if (resource.note?.length > 0) {
      resource.note.forEach((note: any) => {
        if (note.text) {
          facts.push(this.createChunk(
            `Note: ${note.text}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    return facts;
  }

  private extractSubstance(resource: any): string {
    if (resource.code?.coding?.length > 0) {
      return resource.code.coding[0].display || resource.code.coding[0].code || 'Unknown substance';
    }
    
    if (resource.code?.text) {
      return resource.code.text;
    }
    
    return 'Unknown substance';
  }

  private extractReactionSummary(resource: any): string | null {
    if (resource.reaction?.length > 0) {
      const reactions = resource.reaction
        .map((reaction: any) => {
          if (reaction.manifestation?.length > 0) {
            return reaction.manifestation
              .map((m: any) => m.coding?.[0]?.display || m.text)
              .filter(Boolean)
              .join(', ');
          }
          return null;
        })
        .filter(Boolean);
      
      return reactions.length > 0 ? reactions.join('; ') : null;
    }
    
    return null;
  }

  private extractAllergyCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Substance codes
    if (resource.code?.coding) {
      resource.code.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    if (resource.code?.text) {
      codes.push(resource.code.text.toLowerCase());
    }
    
    // Reaction manifestation codes
    if (resource.reaction?.length > 0) {
      resource.reaction.forEach((reaction: any) => {
        if (reaction.manifestation?.length > 0) {
          reaction.manifestation.forEach((manifestation: any) => {
            if (manifestation.coding) {
              manifestation.coding.forEach((coding: any) => {
                if (coding.code) codes.push(coding.code);
                if (coding.display) codes.push(coding.display.toLowerCase());
              });
            }
            if (manifestation.text) {
              codes.push(manifestation.text.toLowerCase());
            }
          });
        }
      });
    }
    
    return codes;
  }
}