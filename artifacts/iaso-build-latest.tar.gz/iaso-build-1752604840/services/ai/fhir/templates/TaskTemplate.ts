import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class TaskTemplate extends BaseResourceTemplate {
  resourceType = 'Task';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const taskSummary = this.generateTaskSummary(resource);
    chunks.push(this.createChunk(taskSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientFromFor(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'workflow',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'encounter',
      searchable_codes: this.extractTaskCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // High priority tasks
    if (resource.priority === 'urgent' || resource.priority === 'stat') {
      return 'critical';
    }
    
    // Failed or cancelled tasks
    if (resource.status === 'failed' || resource.status === 'cancelled') {
      return 'abnormal';
    }
    
    // Completed tasks are normal
    if (resource.status === 'completed') {
      return 'normal';
    }
    
    return 'normal';
  }

  private generateTaskSummary(resource: any): string {
    const patientId = this.extractPatientFromFor(resource);
    const description = resource.description || this.extractTaskCode(resource);
    const status = resource.status || 'unknown';
    const priority = resource.priority || 'routine';
    
    let summary = `Task "${description}" for Patient ${patientId}`;
    
    if (priority !== 'routine') {
      summary += ` (${priority})`;
    }
    
    summary += ` - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Description
    if (resource.description) {
      facts.push(this.createChunk(
        `Description: ${resource.description}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Intent
    if (resource.intent) {
      facts.push(this.createChunk(
        `Intent: ${resource.intent}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Priority
    if (resource.priority) {
      facts.push(this.createChunk(
        `Priority: ${resource.priority}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Code
    if (resource.code) {
      const code = resource.code.coding?.[0]?.display || resource.code.text;
      facts.push(this.createChunk(
        `Code: ${code}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Business status
    if (resource.businessStatus) {
      const businessStatus = resource.businessStatus.coding?.[0]?.display || resource.businessStatus.text;
      facts.push(this.createChunk(
        `Business status: ${businessStatus}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Authored on
    if (resource.authoredOn) {
      facts.push(this.createChunk(
        `Authored on: ${new Date(resource.authoredOn).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Last modified
    if (resource.lastModified) {
      facts.push(this.createChunk(
        `Last modified: ${new Date(resource.lastModified).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Requester
    if (resource.requester) {
      const requester = resource.requester.display || resource.requester.reference;
      facts.push(this.createChunk(
        `Requester: ${requester}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Owner
    if (resource.owner) {
      const owner = resource.owner.display || resource.owner.reference;
      facts.push(this.createChunk(
        `Owner: ${owner}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Location
    if (resource.location) {
      const location = resource.location.display || resource.location.reference;
      facts.push(this.createChunk(
        `Location: ${location}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Reason code
    if (resource.reasonCode) {
      const reason = resource.reasonCode.coding?.[0]?.display || resource.reasonCode.text;
      facts.push(this.createChunk(
        `Reason: ${reason}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Reason reference
    if (resource.reasonReference) {
      const reasonRef = resource.reasonReference.display || resource.reasonReference.reference;
      facts.push(this.createChunk(
        `Reason reference: ${reasonRef}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Focus
    if (resource.focus) {
      const focus = resource.focus.display || resource.focus.reference;
      facts.push(this.createChunk(
        `Focus: ${focus}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Execution period
    if (resource.executionPeriod) {
      const start = resource.executionPeriod.start ? new Date(resource.executionPeriod.start).toISOString().split('T')[0] : '';
      const end = resource.executionPeriod.end ? new Date(resource.executionPeriod.end).toISOString().split('T')[0] : '';
      
      if (start && end) {
        facts.push(this.createChunk(
          `Execution period: ${start} to ${end}`,
          'granular_fact',
          resource,
          significance
        ));
      } else if (start) {
        facts.push(this.createChunk(
          `Execution start: ${start}`,
          'granular_fact',
          resource,
          significance
        ));
      }
    }
    
    // Restriction
    if (resource.restriction) {
      const restriction = resource.restriction;
      
      if (restriction.repetitions) {
        facts.push(this.createChunk(
          `Repetitions: ${restriction.repetitions}`,
          'granular_fact',
          resource,
          significance
        ));
      }
      
      if (restriction.period) {
        const start = restriction.period.start ? new Date(restriction.period.start).toISOString().split('T')[0] : '';
        const end = restriction.period.end ? new Date(restriction.period.end).toISOString().split('T')[0] : '';
        
        if (start && end) {
          facts.push(this.createChunk(
            `Restriction period: ${start} to ${end}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      }
    }
    
    // Input
    if (resource.input?.length > 0) {
      resource.input.forEach((input: any, index: number) => {
        if (input.type) {
          const type = input.type.coding?.[0]?.display || input.type.text;
          facts.push(this.createChunk(
            `Input ${index + 1} type: ${type}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (input.valueString) {
          facts.push(this.createChunk(
            `Input ${index + 1} value: ${input.valueString}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    // Output
    if (resource.output?.length > 0) {
      resource.output.forEach((output: any, index: number) => {
        if (output.type) {
          const type = output.type.coding?.[0]?.display || output.type.text;
          facts.push(this.createChunk(
            `Output ${index + 1} type: ${type}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (output.valueString) {
          facts.push(this.createChunk(
            `Output ${index + 1} value: ${output.valueString}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    // Notes
    if (resource.note?.length > 0) {
      resource.note.forEach((note: any) => {
        if (note.text) {
          facts.push(this.createChunk(
            `Note: ${note.text}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    return facts;
  }

  private extractPatientFromFor(resource: any): string {
    if (resource.for?.reference?.startsWith('Patient/')) {
      return resource.for.reference.replace('Patient/', '');
    }
    
    if (resource.for?.display) {
      return resource.for.display;
    }
    
    return 'Unknown patient';
  }

  private extractTaskCode(resource: any): string {
    if (resource.code?.coding?.length > 0) {
      return resource.code.coding[0].display || resource.code.coding[0].code || 'Unknown task';
    }
    
    if (resource.code?.text) {
      return resource.code.text;
    }
    
    return 'Unknown task';
  }

  private extractTaskCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Task codes
    if (resource.code?.coding) {
      resource.code.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    if (resource.code?.text) {
      codes.push(resource.code.text.toLowerCase());
    }
    
    return codes;
  }
}
