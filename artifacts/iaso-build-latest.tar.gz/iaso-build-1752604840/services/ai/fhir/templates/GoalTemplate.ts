import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class GoalTemplate extends BaseResourceTemplate {
  resourceType = 'Goal';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const goalSummary = this.generateGoalSummary(resource);
    chunks.push(this.createChunk(goalSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'care_management',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'patient',
      searchable_codes: this.extractGoalCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // High priority goals
    if (resource.priority?.coding?.[0]?.code === 'high' || resource.priority?.coding?.[0]?.code === 'urgent') {
      return 'critical';
    }
    
    // Goals that are not achieved or on hold
    if (resource.lifecycleStatus === 'cancelled' || resource.lifecycleStatus === 'on-hold') {
      return 'abnormal';
    }
    
    // Active goals are normal
    if (resource.lifecycleStatus === 'active' || resource.lifecycleStatus === 'accepted') {
      return 'normal';
    }
    
    return 'normal';
  }

  private generateGoalSummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const description = this.extractDescription(resource);
    const status = resource.lifecycleStatus || 'unknown';
    const achievement = resource.achievementStatus?.coding?.[0]?.display || '';
    const priority = resource.priority?.coding?.[0]?.display || '';
    
    let summary = `Patient ${patientId} has ${priority} goal: "${description}"`;
    
    if (achievement) {
      summary += ` - ${achievement}`;
    }
    
    summary += ` (${status})`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Description
    const description = this.extractDescription(resource);
    facts.push(this.createChunk(
      `Description: ${description}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Lifecycle status
    facts.push(this.createChunk(
      `Lifecycle status: ${resource.lifecycleStatus}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Achievement status
    if (resource.achievementStatus) {
      const achievement = resource.achievementStatus.coding?.[0]?.display || resource.achievementStatus.text;
      facts.push(this.createChunk(
        `Achievement status: ${achievement}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Priority
    if (resource.priority) {
      const priority = resource.priority.coding?.[0]?.display || resource.priority.text;
      facts.push(this.createChunk(
        `Priority: ${priority}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Category
    if (resource.category?.length > 0) {
      resource.category.forEach((category: any) => {
        const display = category.coding?.[0]?.display || category.text;
        facts.push(this.createChunk(
          `Category: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Start date
    if (resource.startDate) {
      facts.push(this.createChunk(
        `Start date: ${new Date(resource.startDate).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Status date
    if (resource.statusDate) {
      facts.push(this.createChunk(
        `Status date: ${new Date(resource.statusDate).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Status reason
    if (resource.statusReason) {
      facts.push(this.createChunk(
        `Status reason: ${resource.statusReason}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Expressed by
    if (resource.expressedBy) {
      const expressedBy = resource.expressedBy.display || resource.expressedBy.reference;
      facts.push(this.createChunk(
        `Expressed by: ${expressedBy}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Addresses
    if (resource.addresses?.length > 0) {
      resource.addresses.forEach((addr: any) => {
        const condition = addr.display || addr.reference;
        facts.push(this.createChunk(
          `Addresses: ${condition}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Targets
    if (resource.target?.length > 0) {
      resource.target.forEach((target: any, index: number) => {
        if (target.measure) {
          const measure = target.measure.coding?.[0]?.display || target.measure.text;
          facts.push(this.createChunk(
            `Target ${index + 1} measure: ${measure}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (target.detailQuantity) {
          facts.push(this.createChunk(
            `Target ${index + 1} value: ${target.detailQuantity.value} ${target.detailQuantity.unit}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (target.detailString) {
          facts.push(this.createChunk(
            `Target ${index + 1} detail: ${target.detailString}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (target.dueDate) {
          facts.push(this.createChunk(
            `Target ${index + 1} due: ${new Date(target.dueDate).toISOString().split('T')[0]}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    // Outcome code
    if (resource.outcomeCode?.length > 0) {
      resource.outcomeCode.forEach((outcome: any) => {
        const display = outcome.coding?.[0]?.display || outcome.text;
        facts.push(this.createChunk(
          `Outcome: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Outcome reference
    if (resource.outcomeReference?.length > 0) {
      resource.outcomeReference.forEach((ref: any) => {
        const outcome = ref.display || ref.reference;
        facts.push(this.createChunk(
          `Outcome reference: ${outcome}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Notes
    if (resource.note?.length > 0) {
      resource.note.forEach((note: any) => {
        if (note.text) {
          facts.push(this.createChunk(
            `Note: ${note.text}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    return facts;
  }

  private extractDescription(resource: any): string {
    if (resource.description?.text) {
      return resource.description.text;
    }
    
    if (resource.description?.coding?.length > 0) {
      return resource.description.coding[0].display || resource.description.coding[0].code || 'Unknown goal';
    }
    
    return 'Unknown goal';
  }

  private extractGoalCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Description codes
    if (resource.description?.coding) {
      resource.description.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    // Category codes
    if (resource.category?.length > 0) {
      resource.category.forEach((category: any) => {
        if (category.coding) {
          category.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    // Target measure codes
    if (resource.target?.length > 0) {
      resource.target.forEach((target: any) => {
        if (target.measure?.coding) {
          target.measure.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    return codes;
  }
}
