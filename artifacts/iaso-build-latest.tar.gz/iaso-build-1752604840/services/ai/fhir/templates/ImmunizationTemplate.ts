import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class ImmunizationTemplate extends BaseResourceTemplate {
  resourceType = 'Immunization';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const immunizationSummary = this.generateImmunizationSummary(resource);
    chunks.push(this.createChunk(immunizationSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'immunizations',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'encounter',
      searchable_codes: this.extractImmunizationCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Contraindicated immunizations are critical
    if (resource.status === 'entered-in-error' || resource.status === 'not-done') {
      if (resource.statusReason?.coding?.some((coding: any) => 
        coding.code === 'contraindicated' || coding.display?.toLowerCase().includes('contraindicated'))) {
        return 'critical';
      }
    }
    
    // Missed or overdue immunizations
    if (resource.status === 'not-done') {
      return 'abnormal';
    }
    
    // Completed immunizations are normal
    if (resource.status === 'completed') {
      return 'normal';
    }
    
    return 'normal';
  }

  private generateImmunizationSummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const vaccine = this.extractVaccineName(resource);
    const date = this.extractDate(resource);
    const status = resource.status || 'unknown';
    const lotNumber = resource.lotNumber || '';
    
    let summary = `Patient ${patientId} received ${vaccine} immunization`;
    
    if (date) {
      summary += ` on ${date}`;
    }
    
    if (lotNumber) {
      summary += ` (lot: ${lotNumber})`;
    }
    
    summary += ` - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Vaccine name
    const vaccine = this.extractVaccineName(resource);
    facts.push(this.createChunk(
      `Vaccine: ${vaccine}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Occurrence date
    if (resource.occurrenceDateTime) {
      facts.push(this.createChunk(
        `Occurrence: ${new Date(resource.occurrenceDateTime).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Lot number
    if (resource.lotNumber) {
      facts.push(this.createChunk(
        `Lot number: ${resource.lotNumber}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Expiration date
    if (resource.expirationDate) {
      facts.push(this.createChunk(
        `Expiration: ${new Date(resource.expirationDate).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Site
    if (resource.site) {
      const site = resource.site.coding?.[0]?.display || resource.site.text;
      facts.push(this.createChunk(
        `Site: ${site}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Route
    if (resource.route) {
      const route = resource.route.coding?.[0]?.display || resource.route.text;
      facts.push(this.createChunk(
        `Route: ${route}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Dose quantity
    if (resource.doseQuantity) {
      facts.push(this.createChunk(
        `Dose: ${resource.doseQuantity.value} ${resource.doseQuantity.unit}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Performer
    if (resource.performer?.length > 0) {
      resource.performer.forEach((performer: any) => {
        const actor = performer.actor?.display || performer.actor?.reference;
        facts.push(this.createChunk(
          `Administered by: ${actor}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Manufacturer
    if (resource.manufacturer) {
      const manufacturer = resource.manufacturer.display || resource.manufacturer.reference;
      facts.push(this.createChunk(
        `Manufacturer: ${manufacturer}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Reason
    if (resource.reasonCode?.length > 0) {
      resource.reasonCode.forEach((reason: any) => {
        const reasonDisplay = reason.coding?.[0]?.display || reason.text;
        facts.push(this.createChunk(
          `Reason: ${reasonDisplay}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Status reason
    if (resource.statusReason) {
      const statusReason = resource.statusReason.coding?.[0]?.display || resource.statusReason.text;
      facts.push(this.createChunk(
        `Status reason: ${statusReason}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Reactions
    if (resource.reaction?.length > 0) {
      resource.reaction.forEach((reaction: any) => {
        if (reaction.detail) {
          const detail = reaction.detail.display || reaction.detail.reference;
          facts.push(this.createChunk(
            `Reaction: ${detail}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (reaction.reported !== undefined) {
          facts.push(this.createChunk(
            `Reaction reported: ${reaction.reported}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    // Protocol applied
    if (resource.protocolApplied?.length > 0) {
      resource.protocolApplied.forEach((protocol: any) => {
        if (protocol.series) {
          facts.push(this.createChunk(
            `Series: ${protocol.series}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (protocol.doseNumberPositiveInt) {
          facts.push(this.createChunk(
            `Dose number: ${protocol.doseNumberPositiveInt}`,
            'granular_fact',
            resource,
            significance
          ));
        }
      });
    }
    
    return facts;
  }

  private extractVaccineName(resource: any): string {
    if (resource.vaccineCode?.coding?.length > 0) {
      return resource.vaccineCode.coding[0].display || resource.vaccineCode.coding[0].code || 'Unknown vaccine';
    }
    
    if (resource.vaccineCode?.text) {
      return resource.vaccineCode.text;
    }
    
    return 'Unknown vaccine';
  }

  private extractImmunizationCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Vaccine codes
    if (resource.vaccineCode?.coding) {
      resource.vaccineCode.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    if (resource.vaccineCode?.text) {
      codes.push(resource.vaccineCode.text.toLowerCase());
    }
    
    return codes;
  }
}
