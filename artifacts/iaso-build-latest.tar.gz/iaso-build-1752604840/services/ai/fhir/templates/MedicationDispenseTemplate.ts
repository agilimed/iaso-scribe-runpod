import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../ResourceTemplateService';

export class MedicationDispenseTemplate extends BaseResourceTemplate {
  resourceType = 'MedicationDispense';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.status) {
      chunks.push({
        id: `${resource.id}-status`,
        type: 'granular_fact',
        content: `Dispense status: ${resource.status}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.medicationCodeableConcept) {
      chunks.push({
        id: `${resource.id}-medication`,
        type: 'granular_fact',
        content: `Medication dispensed: ${resource.medicationCodeableConcept.text || resource.medicationCodeableConcept.coding?.[0]?.display}`,
        metadata: this.extractMetadata(resource)
      });
    } else if (resource.medicationReference) {
      chunks.push({
        id: `${resource.id}-medication`,
        type: 'granular_fact',
        content: `Medication dispensed: ${resource.medicationReference.display || resource.medicationReference.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.quantity) {
      chunks.push({
        id: `${resource.id}-quantity`,
        type: 'granular_fact',
        content: `Quantity dispensed: ${resource.quantity.value} ${resource.quantity.unit || resource.quantity.code || ''}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.daysSupply) {
      chunks.push({
        id: `${resource.id}-days-supply`,
        type: 'granular_fact',
        content: `Days supply: ${resource.daysSupply.value} ${resource.daysSupply.unit || 'days'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.whenPrepared) {
      chunks.push({
        id: `${resource.id}-prepared`,
        type: 'granular_fact',
        content: `Prepared on: ${resource.whenPrepared}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.whenHandedOver) {
      chunks.push({
        id: `${resource.id}-handed-over`,
        type: 'granular_fact',
        content: `Handed over: ${resource.whenHandedOver}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.destination) {
      chunks.push({
        id: `${resource.id}-destination`,
        type: 'granular_fact',
        content: `Destination: ${resource.destination.display || resource.destination.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.receiver) {
      resource.receiver.forEach((rec: any, index: number) => {
        chunks.push({
          id: `${resource.id}-receiver-${index}`,
          type: 'granular_fact',
          content: `Received by: ${rec.display || rec.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.dosageInstruction) {
      resource.dosageInstruction.forEach((dosage: any, index: number) => {
        chunks.push({
          id: `${resource.id}-dosage-${index}`,
          type: 'granular_fact',
          content: `Dosage instruction ${index + 1}: ${dosage.text || `${dosage.doseAndRate?.[0]?.doseQuantity?.value || ''} ${dosage.doseAndRate?.[0]?.doseQuantity?.unit || ''} ${dosage.timing?.repeat?.frequency || ''} times ${dosage.timing?.repeat?.period || ''} ${dosage.timing?.repeat?.periodUnit || ''}`}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.substitution) {
      chunks.push({
        id: `${resource.id}-substitution`,
        type: 'granular_fact',
        content: `Substitution: ${resource.substitution.wasSubstituted ? 'Yes' : 'No'} - ${resource.substitution.type?.text || resource.substitution.type?.coding?.[0]?.display || 'N/A'} ${resource.substitution.reason?.[0]?.text || ''}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.type) {
      chunks.push({
        id: `${resource.id}-type`,
        type: 'granular_fact',
        content: `Dispense type: ${resource.type.text || resource.type.coding?.[0]?.display}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.note) {
      resource.note.forEach((note: any, index: number) => {
        chunks.push({
          id: `${resource.id}-note-${index}`,
          type: 'granular_fact',
          content: `Note: ${note.text}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Medication Dispense: ${resource.medicationCodeableConcept?.text || resource.medicationReference?.display || 'Medication'} - ${resource.quantity?.value || 'N/A'} ${resource.quantity?.unit || ''} dispensed for ${resource.subject?.display || 'patient'}, ${resource.daysSupply?.value || 'N/A'} days supply`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Pharmacy Dispense: ${resource.medicationCodeableConcept?.text || resource.medicationReference?.display || 'N/A'} - ${resource.quantity?.value || 'N/A'} ${resource.quantity?.unit || 'units'}, ${resource.daysSupply?.value || 'N/A'} days`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract medication codes
    if (resource.medicationCodeableConcept) {
      codes.push(...this.extractClinicalCodes(resource.medicationCodeableConcept));
    }
    
    // Extract type codes
    if (resource.type) {
      codes.push(...this.extractClinicalCodes(resource.type));
    }
    
    // Extract substitution codes
    if (resource.substitution?.type) {
      codes.push(...this.extractClinicalCodes(resource.substitution.type));
    }
    
    // Extract dosage route codes
    if (resource.dosageInstruction) {
      resource.dosageInstruction.forEach((dosage: any) => {
        if (dosage.route) {
          codes.push(...this.extractClinicalCodes(dosage.route));
        }
      });
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.whenHandedOver || resource.whenPrepared,
      clinicalCodes: codes,
      references: [
        ...(resource.subject ? [`${resource.subject.reference}`] : []),
        ...(resource.context ? [`${resource.context.reference}`] : []),
        ...(resource.medicationReference ? [`${resource.medicationReference.reference}`] : []),
        ...(resource.authorizingPrescription ? resource.authorizingPrescription.map((p: any) => p.reference) : []),
        ...(resource.performer ? resource.performer.map((p: any) => p.actor.reference) : []),
        ...(resource.location ? [`${resource.location.reference}`] : []),
        ...(resource.receiver ? resource.receiver.map((r: any) => r.reference) : [])
      ],
      tags: [
        'medication-dispense',
        'pharmacy',
        'medication-supply',
        ...(resource.status ? [resource.status] : []),
        ...(resource.type?.text ? [resource.type.text.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.substitution?.wasSubstituted ? ['substituted'] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    // Cancelled or error dispenses
    if (resource.status === 'cancelled' || resource.status === 'entered-in-error') return 'abnormal';
    
    // Declined dispenses
    if (resource.status === 'declined') return 'abnormal';
    
    // Substitutions that might need attention
    if (resource.substitution?.wasSubstituted && resource.substitution.type?.coding?.[0]?.code === 'therapeutic') {
      return 'abnormal';
    }
    
    // Check for controlled substances
    const medicationText = resource.medicationCodeableConcept?.text?.toLowerCase() || 
                          resource.medicationCodeableConcept?.coding?.[0]?.display?.toLowerCase() || '';
    const controlledSubstances = ['oxycodone', 'morphine', 'fentanyl', 'hydrocodone', 'alprazolam', 'diazepam'];
    if (controlledSubstances.some(med => medicationText.includes(med))) return 'critical';
    
    // Large quantities that might indicate error
    if (resource.quantity?.value > 180 && resource.quantity?.unit?.toLowerCase().includes('tablet')) return 'abnormal';
    
    if (resource.status === 'completed') return 'normal';
    
    return 'normal';
  }
}