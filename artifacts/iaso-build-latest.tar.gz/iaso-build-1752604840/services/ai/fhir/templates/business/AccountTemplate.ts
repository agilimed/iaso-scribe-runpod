import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../../ResourceTemplateService';

export class AccountTemplate extends BaseResourceTemplate {
  resourceType = 'Account';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const accountSummary = this.generateAccountSummary(resource);
    chunks.push(this.createChunk(accountSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientFromSubject(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'business',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: undefined,
        episode_id: undefined
      },
      chunk_type: 'resource_summary',
      chunk_level: 'patient',
      searchable_codes: this.extractAccountCodes(resource),
      searchable_values: [resource.balance?.toString() || ''],
      searchable_units: [resource.currencyCode || ''],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Overdue accounts or high balances
    if (resource.balance && parseFloat(resource.balance) > 50000) {
      return 'critical';
    }
    
    // Inactive or on-hold accounts
    if (resource.status === 'inactive' || resource.status === 'on-hold') {
      return 'abnormal';
    }
    
    // Error accounts
    if (resource.status === 'entered-in-error') {
      return 'critical';
    }
    
    return 'normal';
  }

  private generateAccountSummary(resource: any): string {
    const patientId = this.extractPatientFromSubject(resource);
    const accountNumber = resource.accountNumber || resource.id;
    const balance = resource.balance ? parseFloat(resource.balance) : 0;
    const currency = resource.currencyCode || 'USD';
    const status = resource.status || 'unknown';
    
    let summary = `Account ${accountNumber} for ${resource.name}`;
    
    if (patientId) {
      summary += ` (Patient: ${patientId})`;
    }
    
    summary += ` - Balance: ${currency} ${balance.toFixed(2)} - Status: ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Account name
    facts.push(this.createChunk(
      `Account name: ${resource.name}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Account number
    if (resource.accountNumber) {
      facts.push(this.createChunk(
        `Account number: ${resource.accountNumber}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Account type
    if (resource.type) {
      const type = resource.type.coding?.[0]?.display || resource.type.text || resource.accountTypeCode;
      facts.push(this.createChunk(
        `Account type: ${type}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Balance
    if (resource.balance !== undefined) {
      const currency = resource.currencyCode || 'USD';
      facts.push(this.createChunk(
        `Balance: ${currency} ${parseFloat(resource.balance).toFixed(2)}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Service period
    if (resource.servicePeriod) {
      if (resource.servicePeriod.start) {
        facts.push(this.createChunk(
          `Service start: ${new Date(resource.servicePeriod.start).toISOString().split('T')[0]}`,
          'granular_fact',
          resource,
          significance
        ));
      }
      
      if (resource.servicePeriod.end) {
        facts.push(this.createChunk(
          `Service end: ${new Date(resource.servicePeriod.end).toISOString().split('T')[0]}`,
          'granular_fact',
          resource,
          significance
        ));
      }
    }
    
    // Owner
    if (resource.owner) {
      facts.push(this.createChunk(
        `Owner: ${resource.owner}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Description
    if (resource.description) {
      facts.push(this.createChunk(
        `Description: ${resource.description}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Subjects (patients)
    if (resource.subject?.length > 0) {
      resource.subject.forEach((subject: string) => {
        facts.push(this.createChunk(
          `Subject: ${subject}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Coverage
    if (resource.coverage?.length > 0) {
      resource.coverage.forEach((cov: any, index: number) => {
        facts.push(this.createChunk(
          `Coverage ${index + 1}: ${cov.coverage} (Priority: ${cov.priority || 'N/A'})`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Guarantor
    if (resource.guarantor?.length > 0) {
      resource.guarantor.forEach((guarantor: any, index: number) => {
        facts.push(this.createChunk(
          `Guarantor ${index + 1}: ${guarantor.party} (On hold: ${guarantor.onHold || false})`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Part of (parent account)
    if (resource.partOf) {
      facts.push(this.createChunk(
        `Part of account: ${resource.partOf}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    return facts;
  }

  private extractPatientFromSubject(resource: any): string {
    if (resource.subject?.length > 0) {
      const patientSubject = resource.subject.find((s: string) => s.startsWith('Patient/'));
      if (patientSubject) {
        return patientSubject.replace('Patient/', '');
      }
      return resource.subject[0];
    }
    
    return '';
  }

  private extractAccountCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Account type codes
    if (resource.type?.coding) {
      resource.type.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    if (resource.accountTypeCode) {
      codes.push(resource.accountTypeCode.toLowerCase());
    }
    
    // Account name and number
    if (resource.name) {
      codes.push(resource.name.toLowerCase());
    }
    
    if (resource.accountNumber) {
      codes.push(resource.accountNumber.toLowerCase());
    }
    
    return codes;
  }

  protected extractDate(resource: any): string | undefined {
    if (resource.servicePeriod?.start) {
      return new Date(resource.servicePeriod.start).toISOString().split('T')[0];
    }
    
    if (resource.meta?.lastUpdated) {
      return new Date(resource.meta.lastUpdated).toISOString().split('T')[0];
    }
    
    return undefined;
  }
}
