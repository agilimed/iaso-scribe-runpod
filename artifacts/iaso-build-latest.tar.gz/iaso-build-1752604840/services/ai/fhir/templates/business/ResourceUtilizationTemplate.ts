import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../../ResourceTemplateService';

export class ResourceUtilizationTemplate extends BaseResourceTemplate {
  resourceType = 'ResourceUtilization';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.resourceType) {
      chunks.push({
        id: `${resource.id}-resource-type`,
        type: 'granular_fact',
        content: `Resource type: ${resource.resourceType}, Category: ${resource.category || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.utilizationMetrics) {
      chunks.push({
        id: `${resource.id}-metrics`,
        type: 'granular_fact',
        content: `Utilization: ${resource.utilizationMetrics.percentage}% (${resource.utilizationMetrics.used}/${resource.utilizationMetrics.total})`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.period) {
      chunks.push({
        id: `${resource.id}-period`,
        type: 'granular_fact',
        content: `Period: ${resource.period.start} to ${resource.period.end}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.location) {
      chunks.push({
        id: `${resource.id}-location`,
        type: 'granular_fact',
        content: `Location: ${resource.location}, Department: ${resource.department || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.capacity) {
      chunks.push({
        id: `${resource.id}-capacity`,
        type: 'granular_fact',
        content: `Capacity: ${resource.capacity.total} total, ${resource.capacity.available} available, ${resource.capacity.occupied} occupied`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.peakUsage) {
      chunks.push({
        id: `${resource.id}-peak`,
        type: 'granular_fact',
        content: `Peak usage: ${resource.peakUsage.percentage}% at ${resource.peakUsage.time}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.turnoverRate) {
      chunks.push({
        id: `${resource.id}-turnover`,
        type: 'granular_fact',
        content: `Turnover rate: ${resource.turnoverRate.rate} per ${resource.turnoverRate.period}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.efficiency) {
      chunks.push({
        id: `${resource.id}-efficiency`,
        type: 'granular_fact',
        content: `Efficiency: ${resource.efficiency.score}% (${resource.efficiency.rating})`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.costMetrics) {
      chunks.push({
        id: `${resource.id}-cost`,
        type: 'granular_fact',
        content: `Cost per unit: $${resource.costMetrics.perUnit}, Total cost: $${resource.costMetrics.total}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Resource Utilization: ${resource.resourceType} at ${resource.location || 'N/A'} - ${resource.utilizationMetrics?.percentage || 0}% utilization, ${resource.efficiency?.score || 0}% efficiency`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Resource Management: ${resource.resourceType} - ${resource.utilizationMetrics?.percentage || 0}% utilized, ${resource.capacity?.total || 0} total capacity`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.period?.end,
      clinicalCodes: [],
      references: [
        ...(resource.location ? [`Location/${resource.location}`] : []),
        ...(resource.department ? [`Organization/${resource.department}`] : [])
      ],
      tags: [
        'resource-utilization',
        'operational-metrics',
        'capacity-management',
        ...(resource.resourceType ? [resource.resourceType.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.utilizationMetrics?.percentage > 90 ? ['high-utilization'] : []),
        ...(resource.utilizationMetrics?.percentage < 70 ? ['low-utilization'] : []),
        ...(resource.efficiency?.score > 85 ? ['high-efficiency'] : []),
        ...(resource.efficiency?.score < 70 ? ['low-efficiency'] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    const utilization = resource.utilizationMetrics?.percentage;
    const efficiency = resource.efficiency?.score;
    
    if (utilization && (utilization > 95 || utilization < 50)) return 'abnormal';
    if (efficiency && efficiency < 60) return 'abnormal';
    if (resource.capacity?.available === 0) return 'critical';
    
    return 'normal';
  }
}