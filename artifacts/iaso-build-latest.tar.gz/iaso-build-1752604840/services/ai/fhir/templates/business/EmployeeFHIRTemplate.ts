import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../../ResourceTemplateService';

export class EmployeeFHIRTemplate extends BaseResourceTemplate {
  resourceType = 'EmployeeFHIR';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.identifier) {
      chunks.push({
        id: `${resource.id}-identifier`,
        type: 'granular_fact',
        content: `Employee ID: ${resource.identifier.value} (${resource.identifier.type?.text || 'N/A'})`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.name) {
      chunks.push({
        id: `${resource.id}-name`,
        type: 'granular_fact',
        content: `Name: ${resource.name.text || `${resource.name.family}, ${resource.name.given?.join(' ')}`}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.qualification) {
      resource.qualification.forEach((qual: any, index: number) => {
        chunks.push({
          id: `${resource.id}-qualification-${index}`,
          type: 'granular_fact',
          content: `Qualification ${index + 1}: ${qual.code?.text || qual.code?.coding?.[0]?.display} - ${qual.issuer?.display || 'N/A'}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.extension) {
      const departmentExt = resource.extension.find((ext: any) => ext.url.includes('department'));
      if (departmentExt) {
        chunks.push({
          id: `${resource.id}-department`,
          type: 'granular_fact',
          content: `Department: ${departmentExt.valueString || departmentExt.valueCodeableConcept?.text}`,
          metadata: this.extractMetadata(resource)
        });
      }
      
      const roleExt = resource.extension.find((ext: any) => ext.url.includes('role'));
      if (roleExt) {
        chunks.push({
          id: `${resource.id}-role`,
          type: 'granular_fact',
          content: `Role: ${roleExt.valueString || roleExt.valueCodeableConcept?.text}`,
          metadata: this.extractMetadata(resource)
        });
      }
      
      const employmentStatusExt = resource.extension.find((ext: any) => ext.url.includes('employment-status'));
      if (employmentStatusExt) {
        chunks.push({
          id: `${resource.id}-employment-status`,
          type: 'granular_fact',
          content: `Employment status: ${employmentStatusExt.valueString || employmentStatusExt.valueCodeableConcept?.text}`,
          metadata: this.extractMetadata(resource)
        });
      }
    }
    
    if (resource.telecom) {
      resource.telecom.forEach((contact: any, index: number) => {
        chunks.push({
          id: `${resource.id}-telecom-${index}`,
          type: 'granular_fact',
          content: `${contact.system}: ${contact.value} (${contact.use || 'N/A'})`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.practitionerRole) {
      resource.practitionerRole.forEach((role: any, index: number) => {
        chunks.push({
          id: `${resource.id}-practitioner-role-${index}`,
          type: 'granular_fact',
          content: `Practitioner role ${index + 1}: ${role.code?.text || role.code?.coding?.[0]?.display} at ${role.location?.display || 'N/A'}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.period) {
      chunks.push({
        id: `${resource.id}-period`,
        type: 'granular_fact',
        content: `Employment period: ${resource.period.start} to ${resource.period.end || 'ongoing'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Employee (FHIR): ${resource.name?.text || 'N/A'} - ID: ${resource.identifier?.value || resource.id}, ${resource.qualification?.length || 0} qualifications`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Healthcare Employee: ${resource.name?.text || 'N/A'} - ${resource.qualification?.length || 0} qualifications, ${resource.practitionerRole?.length || 0} roles`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract qualification codes
    if (resource.qualification) {
      resource.qualification.forEach((qual: any) => {
        if (qual.code) {
          codes.push(...this.extractClinicalCodes(qual.code));
        }
      });
    }
    
    // Extract practitioner role codes
    if (resource.practitionerRole) {
      resource.practitionerRole.forEach((role: any) => {
        if (role.code) {
          codes.push(...this.extractClinicalCodes(role.code));
        }
      });
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.period?.start,
      clinicalCodes: codes,
      references: [
        ...(resource.practitionerRole ? resource.practitionerRole.map((role: any) => role.location?.reference).filter(Boolean) : [])
      ],
      tags: [
        'employee-management',
        'human-resources',
        'fhir-employee',
        ...(resource.qualification ? resource.qualification.map((qual: any) => qual.code?.text?.toLowerCase().replace(/\s+/g, '-')).filter(Boolean) : []),
        ...(resource.extension ? resource.extension.map((ext: any) => ext.url.split('/').pop()).filter(Boolean) : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    if (resource.period?.end && new Date(resource.period.end) < new Date()) return 'abnormal';
    if (!resource.qualification || resource.qualification.length === 0) return 'abnormal';
    if (resource.active === false) return 'abnormal';
    
    return 'normal';
  }
}