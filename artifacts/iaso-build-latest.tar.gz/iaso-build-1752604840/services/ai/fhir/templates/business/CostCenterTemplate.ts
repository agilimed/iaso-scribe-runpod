import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../../ResourceTemplateService';

export class CostCenterTemplate extends BaseResourceTemplate {
  resourceType = 'CostCenter';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.code) {
      chunks.push({
        id: `${resource.id}-code`,
        type: 'granular_fact',
        content: `Cost center code: ${resource.code} - ${resource.name || resource.displayName}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.annualBudget) {
      chunks.push({
        id: `${resource.id}-budget`,
        type: 'granular_fact',
        content: `Annual budget: $${resource.annualBudget.toLocaleString()}, Current period budget: $${resource.currentPeriodBudget?.toLocaleString() || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.budgetUtilization) {
      chunks.push({
        id: `${resource.id}-utilization`,
        type: 'granular_fact',
        content: `Budget utilization: ${resource.budgetUtilization.percentage}% ($${resource.budgetUtilization.spent.toLocaleString()} of $${resource.budgetUtilization.allocated.toLocaleString()})`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.department) {
      chunks.push({
        id: `${resource.id}-department`,
        type: 'granular_fact',
        content: `Department: ${resource.department}, Service line: ${resource.serviceLine || 'N/A'}, Manager: ${resource.manager || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.costType) {
      chunks.push({
        id: `${resource.id}-type`,
        type: 'granular_fact',
        content: `Cost center type: ${resource.costType}, Category: ${resource.category || 'N/A'}, Active: ${resource.active ? 'Yes' : 'No'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Cost Center ${resource.code} (${resource.name}): Annual budget $${resource.annualBudget?.toLocaleString() || 'N/A'}, ${resource.budgetUtilization?.percentage || 0}% utilized, Department: ${resource.department || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Financial Management - Cost Center ${resource.code}: Budget $${resource.annualBudget?.toLocaleString() || 'N/A'}, ${resource.budgetUtilization?.percentage || 0}% utilized, ${resource.costType || 'N/A'} type`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.updatedAt,
      clinicalCodes: [],
      references: [
        ...(resource.department ? [`Department/${resource.department}`] : []),
        ...(resource.parentCostCenter ? [`CostCenter/${resource.parentCostCenter}`] : [])
      ],
      tags: [
        'financial-management',
        'cost-center',
        'budget',
        ...(resource.active ? ['active'] : ['inactive']),
        ...(resource.costType ? [resource.costType.toLowerCase()] : []),
        ...(resource.budgetUtilization?.percentage > 90 ? ['budget-high-utilization'] : []),
        ...(resource.budgetUtilization?.percentage > 100 ? ['budget-overrun'] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    const utilization = resource.budgetUtilization?.percentage;
    
    if (utilization && utilization > 100) return 'critical';
    if (utilization && utilization > 90) return 'abnormal';
    if (!resource.active) return 'abnormal';
    
    return 'normal';
  }
}