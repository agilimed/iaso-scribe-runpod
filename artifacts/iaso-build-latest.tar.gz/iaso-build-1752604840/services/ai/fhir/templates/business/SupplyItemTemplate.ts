import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../../ResourceTemplateService';

export class SupplyItemTemplate extends BaseResourceTemplate {
  resourceType = 'SupplyItem';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const supplySummary = this.generateSupplySummary(resource);
    chunks.push(this.createChunk(supplySummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: '',
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'business',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: undefined,
        episode_id: undefined
      },
      chunk_type: 'resource_summary',
      chunk_level: 'system',
      searchable_codes: this.extractSupplyCodes(resource),
      searchable_values: [resource.unitCost?.toString() || '', resource.quantityOnHand?.toString() || ''],
      searchable_units: [resource.unitOfMeasure || ''],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Critical/emergency supplies
    if (this.isCriticalSupply(resource)) {
      return 'critical';
    }
    
    // Low stock items
    if (this.isLowStock(resource)) {
      return 'abnormal';
    }
    
    // Expired items
    if (this.isExpired(resource)) {
      return 'critical';
    }
    
    // Inactive items
    if (resource.status === 'inactive' || resource.status === 'discontinued') {
      return 'abnormal';
    }
    
    return 'normal';
  }

  private generateSupplySummary(resource: any): string {
    const name = resource.name || 'Unknown supply';
    const sku = resource.sku || resource.id;
    const category = resource.category || 'Uncategorized';
    const quantity = resource.quantityOnHand || 0;
    const unit = resource.unitOfMeasure || 'units';
    const status = resource.status || 'unknown';
    
    let summary = `Supply: ${name} (${sku}) - ${category}`;
    
    summary += ` - ${quantity} ${unit} in stock - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Supply name
    facts.push(this.createChunk(
      `Name: ${resource.name}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // SKU
    if (resource.sku) {
      facts.push(this.createChunk(
        `SKU: ${resource.sku}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Category
    if (resource.category) {
      facts.push(this.createChunk(
        `Category: ${resource.category}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Description
    if (resource.description) {
      facts.push(this.createChunk(
        `Description: ${resource.description}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Quantity on hand
    if (resource.quantityOnHand !== undefined) {
      const unit = resource.unitOfMeasure || 'units';
      facts.push(this.createChunk(
        `Quantity on hand: ${resource.quantityOnHand} ${unit}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Unit cost
    if (resource.unitCost !== undefined) {
      const currency = resource.currency || 'USD';
      facts.push(this.createChunk(
        `Unit cost: ${currency} ${parseFloat(resource.unitCost).toFixed(2)}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Reorder level
    if (resource.reorderLevel !== undefined) {
      facts.push(this.createChunk(
        `Reorder level: ${resource.reorderLevel}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Reorder quantity
    if (resource.reorderQuantity !== undefined) {
      facts.push(this.createChunk(
        `Reorder quantity: ${resource.reorderQuantity}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Supplier
    if (resource.supplier) {
      facts.push(this.createChunk(
        `Supplier: ${resource.supplier}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Manufacturer
    if (resource.manufacturer) {
      facts.push(this.createChunk(
        `Manufacturer: ${resource.manufacturer}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Expiration date
    if (resource.expirationDate) {
      facts.push(this.createChunk(
        `Expiration date: ${new Date(resource.expirationDate).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Lot number
    if (resource.lotNumber) {
      facts.push(this.createChunk(
        `Lot number: ${resource.lotNumber}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Storage location
    if (resource.storageLocation) {
      facts.push(this.createChunk(
        `Storage location: ${resource.storageLocation}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Temperature requirements
    if (resource.temperatureRequirement) {
      facts.push(this.createChunk(
        `Temperature requirement: ${resource.temperatureRequirement}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Hazardous material
    if (resource.isHazardous !== undefined) {
      facts.push(this.createChunk(
        `Hazardous material: ${resource.isHazardous}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Controlled substance
    if (resource.isControlled !== undefined) {
      facts.push(this.createChunk(
        `Controlled substance: ${resource.isControlled}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    return facts;
  }

  private extractSupplyCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // SKU
    if (resource.sku) {
      codes.push(resource.sku.toLowerCase());
    }
    
    // Name
    if (resource.name) {
      codes.push(resource.name.toLowerCase());
    }
    
    // Category
    if (resource.category) {
      codes.push(resource.category.toLowerCase());
    }
    
    // Manufacturer
    if (resource.manufacturer) {
      codes.push(resource.manufacturer.toLowerCase());
    }
    
    return codes;
  }

  private isCriticalSupply(resource: any): boolean {
    if (resource.category) {
      const criticalCategories = [
        'emergency', 'critical care', 'life support', 'medication',
        'surgical', 'trauma', 'icu', 'emergency room'
      ];
      
      return criticalCategories.some(cat => 
        resource.category.toLowerCase().includes(cat)
      );
    }
    
    return false;
  }

  private isLowStock(resource: any): boolean {
    if (resource.quantityOnHand !== undefined && resource.reorderLevel !== undefined) {
      return resource.quantityOnHand <= resource.reorderLevel;
    }
    
    // If no reorder level set, consider less than 10 as low stock
    if (resource.quantityOnHand !== undefined) {
      return resource.quantityOnHand < 10;
    }
    
    return false;
  }

  private isExpired(resource: any): boolean {
    if (resource.expirationDate) {
      const expDate = new Date(resource.expirationDate);
      const now = new Date();
      return expDate < now;
    }
    
    return false;
  }

  protected extractDate(resource: any): string | undefined {
    if (resource.expirationDate) {
      return new Date(resource.expirationDate).toISOString().split('T')[0];
    }
    
    if (resource.meta?.lastUpdated) {
      return new Date(resource.meta.lastUpdated).toISOString().split('T')[0];
    }
    
    return undefined;
  }
}
