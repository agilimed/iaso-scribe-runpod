import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../../ResourceTemplateService';

export class ConsumerExperienceTemplate extends BaseResourceTemplate {
  resourceType = 'ConsumerExperience';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.scores?.overallSatisfaction) {
      chunks.push({
        id: `${resource.id}-overall-satisfaction`,
        type: 'granular_fact',
        content: `Patient satisfaction score: ${resource.scores.overallSatisfaction.score} (${resource.scores.overallSatisfaction.responseCount} responses) - ${resource.scores.overallSatisfaction.trend}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.scores?.nps) {
      chunks.push({
        id: `${resource.id}-nps`,
        type: 'granular_fact',
        content: `Net Promoter Score (NPS): ${resource.scores.nps.score} (${resource.scores.nps.promoters} promoters, ${resource.scores.nps.detractors} detractors)`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.scores?.hcahps) {
      const hcahps = resource.scores.hcahps;
      chunks.push({
        id: `${resource.id}-hcahps`,
        type: 'granular_fact',
        content: `HCAHPS scores - Communication with nurses: ${hcahps.communicationNurses}%, Communication with doctors: ${hcahps.communicationDoctors}%, Staff responsiveness: ${hcahps.staffResponsiveness}%, Overall rating: ${hcahps.overallRating}%`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.feedbackAnalysis?.sentimentDistribution) {
      chunks.push({
        id: `${resource.id}-sentiment`,
        type: 'granular_fact',
        content: `Sentiment analysis: ${resource.feedbackAnalysis.sentimentDistribution.positive.percentage}% positive, ${resource.feedbackAnalysis.sentimentDistribution.negative.percentage}% negative feedback`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Consumer Experience for ${resource.period || 'current period'}: Overall satisfaction ${resource.scores?.overallSatisfaction?.score || 'N/A'}, NPS ${resource.scores?.nps?.score || 'N/A'}, ${resource.feedbackAnalysis?.totalFeedback || 0} feedback items analyzed`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Patient Experience Summary: ${resource.scores?.overallSatisfaction?.score || 'N/A'} satisfaction score, ${resource.scores?.nps?.score || 'N/A'} NPS, improvement opportunities identified: ${resource.scores?.improvementOpportunities?.length || 0}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.generatedAt,
      clinicalCodes: [],
      references: [],
      tags: [
        'patient-experience',
        'satisfaction',
        'quality-metrics',
        ...(resource.scores?.overallSatisfaction?.score >= 80 ? ['high-satisfaction'] : []),
        ...(resource.scores?.nps?.score >= 50 ? ['promoter-strong'] : []),
        ...(resource.scores?.hcahps?.overallRating >= 80 ? ['hcahps-high'] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    const satisfaction = resource.scores?.overallSatisfaction?.score;
    const nps = resource.scores?.nps?.score;
    
    if (satisfaction && satisfaction < 60) return 'abnormal';
    if (nps && nps < 0) return 'abnormal';
    if (resource.scores?.qualityFlags?.length > 0) return 'abnormal';
    
    return 'normal';
  }
}