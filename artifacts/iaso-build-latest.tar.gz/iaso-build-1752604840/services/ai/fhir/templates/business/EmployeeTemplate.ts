import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../../ResourceTemplateService';

export class EmployeeTemplate extends BaseResourceTemplate {
  resourceType = 'Employee';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const employeeSummary = this.generateEmployeeSummary(resource);
    chunks.push(this.createChunk(employeeSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'business',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: undefined,
        episode_id: undefined
      },
      chunk_type: 'resource_summary',
      chunk_level: 'system',
      searchable_codes: this.extractEmployeeCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Terminated employees or suspended
    if (resource.status === 'terminated' || resource.status === 'suspended') {
      return 'abnormal';
    }
    
    // Error status
    if (resource.status === 'entered-in-error') {
      return 'critical';
    }
    
    // Inactive employees
    if (resource.status === 'inactive') {
      return 'abnormal';
    }
    
    return 'normal';
  }

  private generateEmployeeSummary(resource: any): string {
    const name = this.extractEmployeeName(resource);
    const employeeNumber = resource.employeeNumber || resource.id;
    const department = resource.department || 'Unknown department';
    const status = resource.status || 'unknown';
    const role = this.extractRole(resource);
    
    let summary = `Employee ${name} (${employeeNumber})`;
    
    if (role) {
      summary += ` - ${role}`;
    }
    
    summary += ` in ${department} - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Employee name
    const name = this.extractEmployeeName(resource);
    facts.push(this.createChunk(
      `Name: ${name}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Employee number
    if (resource.employeeNumber) {
      facts.push(this.createChunk(
        `Employee number: ${resource.employeeNumber}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Department
    if (resource.department) {
      facts.push(this.createChunk(
        `Department: ${resource.department}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Role/Position
    const role = this.extractRole(resource);
    if (role) {
      facts.push(this.createChunk(
        `Role: ${role}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Employment period
    if (resource.employmentPeriod) {
      if (resource.employmentPeriod.start) {
        facts.push(this.createChunk(
          `Employment start: ${new Date(resource.employmentPeriod.start).toISOString().split('T')[0]}`,
          'granular_fact',
          resource,
          significance
        ));
      }
      
      if (resource.employmentPeriod.end) {
        facts.push(this.createChunk(
          `Employment end: ${new Date(resource.employmentPeriod.end).toISOString().split('T')[0]}`,
          'granular_fact',
          resource,
          significance
        ));
      }
    }
    
    // Contact information
    if (resource.telecom?.length > 0) {
      resource.telecom.forEach((contact: any) => {
        const system = contact.system || 'contact';
        facts.push(this.createChunk(
          `${system}: ${contact.value}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Address
    if (resource.address?.length > 0) {
      resource.address.forEach((addr: any, index: number) => {
        const addressText = this.formatAddress(addr);
        facts.push(this.createChunk(
          `Address ${index + 1}: ${addressText}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Birth date
    if (resource.birthDate) {
      facts.push(this.createChunk(
        `Birth date: ${resource.birthDate}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Gender
    if (resource.gender) {
      facts.push(this.createChunk(
        `Gender: ${resource.gender}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Supervisor
    if (resource.supervisor) {
      facts.push(this.createChunk(
        `Supervisor: ${resource.supervisor}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Practitioner reference
    if (resource.practitioner) {
      facts.push(this.createChunk(
        `Practitioner: ${resource.practitioner}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Skills/Qualifications
    if (resource.qualification?.length > 0) {
      resource.qualification.forEach((qual: any, index: number) => {
        const qualName = qual.code?.coding?.[0]?.display || qual.code?.text || `Qualification ${index + 1}`;
        facts.push(this.createChunk(
          `Qualification: ${qualName}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Emergency contact
    if (resource.emergencyContact) {
      facts.push(this.createChunk(
        `Emergency contact: ${resource.emergencyContact}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Work schedule
    if (resource.workSchedule) {
      facts.push(this.createChunk(
        `Work schedule: ${resource.workSchedule}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    return facts;
  }

  private extractEmployeeName(resource: any): string {
    if (resource.name?.length > 0) {
      const name = resource.name[0];
      const parts = [];
      
      if (name.given?.length > 0) {
        parts.push(name.given.join(' '));
      }
      
      if (name.family) {
        parts.push(name.family);
      }
      
      if (parts.length > 0) {
        return parts.join(' ');
      }
      
      if (name.text) {
        return name.text;
      }
    }
    
    return 'Unknown Employee';
  }

  private extractRole(resource: any): string | null {
    if (resource.position) {
      return resource.position;
    }
    
    if (resource.role?.coding?.length > 0) {
      return resource.role.coding[0].display || resource.role.coding[0].code;
    }
    
    if (resource.role?.text) {
      return resource.role.text;
    }
    
    return null;
  }

  private formatAddress(address: any): string {
    const parts = [];
    
    if (address.line?.length > 0) {
      parts.push(address.line.join(', '));
    }
    
    if (address.city) {
      parts.push(address.city);
    }
    
    if (address.state) {
      parts.push(address.state);
    }
    
    if (address.postalCode) {
      parts.push(address.postalCode);
    }
    
    if (address.country) {
      parts.push(address.country);
    }
    
    return parts.join(', ') || 'Address not specified';
  }

  private extractEmployeeCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Employee number
    if (resource.employeeNumber) {
      codes.push(resource.employeeNumber.toLowerCase());
    }
    
    // Department
    if (resource.department) {
      codes.push(resource.department.toLowerCase());
    }
    
    // Position/Role
    const role = this.extractRole(resource);
    if (role) {
      codes.push(role.toLowerCase());
    }
    
    // Name
    const name = this.extractEmployeeName(resource);
    codes.push(name.toLowerCase());
    
    return codes;
  }

  private extractPatientId(resource: any): string {
    // Employees might be linked to practitioners who treat patients
    // but they don't directly have patient IDs
    return '';
  }

  protected extractDate(resource: any): string | undefined {
    if (resource.employmentPeriod?.start) {
      return new Date(resource.employmentPeriod.start).toISOString().split('T')[0];
    }
    
    if (resource.meta?.lastUpdated) {
      return new Date(resource.meta.lastUpdated).toISOString().split('T')[0];
    }
    
    return undefined;
  }
}
