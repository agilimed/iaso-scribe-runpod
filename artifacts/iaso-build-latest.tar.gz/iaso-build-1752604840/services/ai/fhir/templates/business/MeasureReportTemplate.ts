import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../../ResourceTemplateService';

export class MeasureReportTemplate extends BaseResourceTemplate {
  resourceType = 'MeasureReport';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.measureTitle) {
      chunks.push({
        id: `${resource.id}-measure`,
        type: 'granular_fact',
        content: `Measure: ${resource.measureTitle} (${resource.measureId}), Type: ${resource.measureType || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.reportingPeriod) {
      chunks.push({
        id: `${resource.id}-period`,
        type: 'granular_fact',
        content: `Reporting period: ${resource.reportingPeriod.start} to ${resource.reportingPeriod.end}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.score) {
      chunks.push({
        id: `${resource.id}-score`,
        type: 'granular_fact',
        content: `Score: ${resource.score.value}${resource.score.unit ? ` ${resource.score.unit}` : ''} (${resource.score.interpretation || 'N/A'})`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.populationData) {
      chunks.push({
        id: `${resource.id}-population`,
        type: 'granular_fact',
        content: `Population: Initial ${resource.populationData.initial || 0}, Denominator ${resource.populationData.denominator || 0}, Numerator ${resource.populationData.numerator || 0}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.improvementNotation) {
      chunks.push({
        id: `${resource.id}-improvement`,
        type: 'granular_fact',
        content: `Improvement notation: ${resource.improvementNotation}, Target: ${resource.target || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.stratification) {
      chunks.push({
        id: `${resource.id}-stratification`,
        type: 'granular_fact',
        content: `Stratification: ${resource.stratification.length} strata analyzed`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Measure Report: ${resource.measureTitle} scored ${resource.score?.value || 'N/A'} for period ${resource.reportingPeriod?.start || 'N/A'} to ${resource.reportingPeriod?.end || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Quality Measure: ${resource.measureTitle} - Score: ${resource.score?.value || 'N/A'}, Performance: ${resource.score?.interpretation || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.date,
      clinicalCodes: [
        ...(resource.measureId ? [resource.measureId] : []),
        ...(resource.measureType ? [resource.measureType] : [])
      ],
      references: [
        ...(resource.subject ? [`${resource.subject.reference}`] : []),
        ...(resource.reporter ? [`${resource.reporter.reference}`] : [])
      ],
      tags: [
        'quality-measure',
        'performance-metrics',
        'clinical-quality',
        ...(resource.measureType ? [resource.measureType.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.score?.interpretation ? [resource.score.interpretation.toLowerCase()] : []),
        ...(resource.improvementNotation ? [resource.improvementNotation.toLowerCase()] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    if (resource.score?.interpretation === 'below-target') return 'abnormal';
    if (resource.score?.interpretation === 'significantly-below-target') return 'critical';
    if (resource.score?.interpretation === 'above-target') return 'normal';
    
    return 'normal';
  }
}