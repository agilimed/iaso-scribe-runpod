import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../../ResourceTemplateService';

export class TimeEntryFHIRTemplate extends BaseResourceTemplate {
  resourceType = 'TimeEntryFHIR';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.identifier) {
      chunks.push({
        id: `${resource.id}-identifier`,
        type: 'granular_fact',
        content: `Time entry ID: ${resource.identifier.value} (${resource.identifier.type?.text || 'N/A'})`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.status) {
      chunks.push({
        id: `${resource.id}-status`,
        type: 'granular_fact',
        content: `Status: ${resource.status}, Category: ${resource.category?.text || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.code) {
      chunks.push({
        id: `${resource.id}-code`,
        type: 'granular_fact',
        content: `Activity code: ${resource.code.text || resource.code.coding?.[0]?.display} (${resource.code.coding?.[0]?.code || 'N/A'})`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.subject) {
      chunks.push({
        id: `${resource.id}-subject`,
        type: 'granular_fact',
        content: `Subject: ${resource.subject.display || resource.subject.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.performedPeriod) {
      chunks.push({
        id: `${resource.id}-performed-period`,
        type: 'granular_fact',
        content: `Performed: ${resource.performedPeriod.start} to ${resource.performedPeriod.end || 'ongoing'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.performer) {
      resource.performer.forEach((performer: any, index: number) => {
        chunks.push({
          id: `${resource.id}-performer-${index}`,
          type: 'granular_fact',
          content: `Performer ${index + 1}: ${performer.function?.text || 'N/A'} - ${performer.actor?.display || performer.actor?.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.location) {
      chunks.push({
        id: `${resource.id}-location`,
        type: 'granular_fact',
        content: `Location: ${resource.location.display || resource.location.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.extension) {
      const durationExt = resource.extension.find((ext: any) => ext.url.includes('duration'));
      if (durationExt) {
        chunks.push({
          id: `${resource.id}-duration`,
          type: 'granular_fact',
          content: `Duration: ${durationExt.valueDuration?.value || durationExt.valueQuantity?.value} ${durationExt.valueDuration?.unit || durationExt.valueQuantity?.unit || 'minutes'}`,
          metadata: this.extractMetadata(resource)
        });
      }
      
      const costCenterExt = resource.extension.find((ext: any) => ext.url.includes('cost-center'));
      if (costCenterExt) {
        chunks.push({
          id: `${resource.id}-cost-center`,
          type: 'granular_fact',
          content: `Cost center: ${costCenterExt.valueString || costCenterExt.valueCodeableConcept?.text}`,
          metadata: this.extractMetadata(resource)
        });
      }
      
      const rateExt = resource.extension.find((ext: any) => ext.url.includes('rate'));
      if (rateExt) {
        chunks.push({
          id: `${resource.id}-rate`,
          type: 'granular_fact',
          content: `Rate: ${rateExt.valueMoney?.value || rateExt.valueQuantity?.value} ${rateExt.valueMoney?.currency || rateExt.valueQuantity?.unit || 'per hour'}`,
          metadata: this.extractMetadata(resource)
        });
      }
    }
    
    if (resource.reasonCode) {
      resource.reasonCode.forEach((reason: any, index: number) => {
        chunks.push({
          id: `${resource.id}-reason-${index}`,
          type: 'granular_fact',
          content: `Reason ${index + 1}: ${reason.text || reason.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.note) {
      resource.note.forEach((note: any, index: number) => {
        chunks.push({
          id: `${resource.id}-note-${index}`,
          type: 'granular_fact',
          content: `Note ${index + 1}: ${note.text}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    // Resource summary
    const duration = resource.extension?.find((ext: any) => ext.url.includes('duration'));
    const performer = resource.performer?.[0];
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Time Entry (FHIR): ${resource.code?.text || 'N/A'} by ${performer?.actor?.display || 'N/A'} - ${duration?.valueDuration?.value || duration?.valueQuantity?.value || 0} ${duration?.valueDuration?.unit || duration?.valueQuantity?.unit || 'minutes'} - ${resource.status || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Healthcare Time Entry: ${resource.code?.text || 'N/A'} - Duration: ${duration?.valueDuration?.value || duration?.valueQuantity?.value || 0} ${duration?.valueDuration?.unit || duration?.valueQuantity?.unit || 'minutes'}, Status: ${resource.status || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract activity codes
    if (resource.code) {
      codes.push(...this.extractClinicalCodes(resource.code));
    }
    
    // Extract category codes
    if (resource.category) {
      codes.push(...this.extractClinicalCodes(resource.category));
    }
    
    // Extract reason codes
    if (resource.reasonCode) {
      resource.reasonCode.forEach((reason: any) => {
        codes.push(...this.extractClinicalCodes(reason));
      });
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.performedPeriod?.start,
      clinicalCodes: codes,
      references: [
        ...(resource.subject ? [`${resource.subject.reference}`] : []),
        ...(resource.performer ? resource.performer.map((p: any) => p.actor?.reference).filter(Boolean) : []),
        ...(resource.location ? [`${resource.location.reference}`] : [])
      ],
      tags: [
        'time-entry',
        'workforce-management',
        'fhir-time-entry',
        ...(resource.code?.text ? [resource.code.text.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.category?.text ? [resource.category.text.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.status ? [resource.status.toLowerCase()] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    const duration = resource.extension?.find((ext: any) => ext.url.includes('duration'));
    const durationValue = duration?.valueDuration?.value || duration?.valueQuantity?.value || 0;
    
    if (resource.status === 'cancelled' || resource.status === 'entered-in-error') return 'abnormal';
    if (durationValue > 480) return 'abnormal'; // More than 8 hours
    if (durationValue < 15) return 'abnormal'; // Less than 15 minutes
    if (resource.status === 'draft') return 'abnormal';
    
    return 'normal';
  }
}