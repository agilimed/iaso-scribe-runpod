import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../../ResourceTemplateService';

export class CoverageTemplate extends BaseResourceTemplate {
  resourceType = 'Coverage';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.identifier) {
      chunks.push({
        id: `${resource.id}-identifier`,
        type: 'granular_fact',
        content: `Coverage identifier: ${resource.identifier.value} (${resource.identifier.type?.text || 'N/A'})`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.status) {
      chunks.push({
        id: `${resource.id}-status`,
        type: 'granular_fact',
        content: `Status: ${resource.status}, Type: ${resource.type?.text || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.policyHolder) {
      chunks.push({
        id: `${resource.id}-policyholder`,
        type: 'granular_fact',
        content: `Policy holder: ${resource.policyHolder.display || resource.policyHolder.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.subscriber) {
      chunks.push({
        id: `${resource.id}-subscriber`,
        type: 'granular_fact',
        content: `Subscriber: ${resource.subscriber.display || resource.subscriber.reference}, Relationship: ${resource.relationship?.text || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.beneficiary) {
      chunks.push({
        id: `${resource.id}-beneficiary`,
        type: 'granular_fact',
        content: `Beneficiary: ${resource.beneficiary.display || resource.beneficiary.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.period) {
      chunks.push({
        id: `${resource.id}-period`,
        type: 'granular_fact',
        content: `Coverage period: ${resource.period.start} to ${resource.period.end || 'ongoing'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.payor) {
      chunks.push({
        id: `${resource.id}-payor`,
        type: 'granular_fact',
        content: `Payor: ${resource.payor.display || resource.payor.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.class) {
      resource.class.forEach((cls: any, index: number) => {
        chunks.push({
          id: `${resource.id}-class-${index}`,
          type: 'granular_fact',
          content: `Class ${index + 1}: ${cls.type?.text || 'N/A'} - ${cls.value} (${cls.name || 'N/A'})`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.costToBeneficiary) {
      resource.costToBeneficiary.forEach((cost: any, index: number) => {
        chunks.push({
          id: `${resource.id}-cost-${index}`,
          type: 'granular_fact',
          content: `Cost to beneficiary ${index + 1}: ${cost.type?.text || 'N/A'} - ${cost.value?.value || 0} ${cost.value?.currency || ''}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.contract) {
      chunks.push({
        id: `${resource.id}-contract`,
        type: 'granular_fact',
        content: `Contract: ${resource.contract.display || resource.contract.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Coverage ${resource.identifier?.value || resource.id}: ${resource.type?.text || 'N/A'} coverage for ${resource.beneficiary?.display || 'N/A'} - ${resource.status || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Insurance Coverage: ${resource.type?.text || 'N/A'} - Status: ${resource.status || 'N/A'}, Payor: ${resource.payor?.display || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract coverage type codes
    if (resource.type) {
      codes.push(...this.extractClinicalCodes(resource.type));
    }
    
    // Extract relationship codes
    if (resource.relationship) {
      codes.push(...this.extractClinicalCodes(resource.relationship));
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.period?.start,
      clinicalCodes: codes,
      references: [
        ...(resource.policyHolder ? [`${resource.policyHolder.reference}`] : []),
        ...(resource.subscriber ? [`${resource.subscriber.reference}`] : []),
        ...(resource.beneficiary ? [`${resource.beneficiary.reference}`] : []),
        ...(resource.payor ? [`${resource.payor.reference}`] : [])
      ],
      tags: [
        'insurance-coverage',
        'financial-coverage',
        'benefits',
        ...(resource.type?.text ? [resource.type.text.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.status ? [resource.status.toLowerCase()] : []),
        ...(resource.relationship?.text ? [resource.relationship.text.toLowerCase().replace(/\s+/g, '-')] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    if (resource.status === 'cancelled' || resource.status === 'entered-in-error') return 'abnormal';
    if (resource.period?.end && new Date(resource.period.end) < new Date()) return 'abnormal';
    if (resource.status === 'draft') return 'abnormal';
    
    return 'normal';
  }
}