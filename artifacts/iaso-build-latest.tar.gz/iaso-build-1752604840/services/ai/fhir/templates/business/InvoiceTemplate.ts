import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../../ResourceTemplateService';

export class InvoiceTemplate extends BaseResourceTemplate {
  resourceType = 'Invoice';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const invoiceSummary = this.generateInvoiceSummary(resource);
    chunks.push(this.createChunk(invoiceSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'business',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: undefined,
        episode_id: undefined
      },
      chunk_type: 'resource_summary',
      chunk_level: 'encounter',
      searchable_codes: this.extractInvoiceCodes(resource),
      searchable_values: [this.extractTotalAmount(resource)],
      searchable_units: [this.extractCurrency(resource)],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Cancelled or error invoices
    if (resource.status === 'cancelled' || resource.status === 'entered-in-error') {
      return 'critical';
    }
    
    // High-value invoices
    const totalAmount = this.parseAmount(resource.totalGross);
    if (totalAmount > 100000) {
      return 'critical';
    }
    
    // Overdue invoices (would need due date calculation)
    if (resource.status === 'issued' && this.isOverdue(resource)) {
      return 'abnormal';
    }
    
    return 'normal';
  }

  private generateInvoiceSummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const invoiceNumber = resource.invoiceNumber || resource.id;
    const totalAmount = this.extractTotalAmount(resource);
    const currency = this.extractCurrency(resource);
    const status = resource.status || 'unknown';
    const date = this.extractDate(resource);
    
    let summary = `Invoice ${invoiceNumber}`;
    
    if (patientId) {
      summary += ` for Patient ${patientId}`;
    }
    
    summary += ` - ${currency} ${totalAmount}`;
    
    if (date) {
      summary += ` dated ${date}`;
    }
    
    summary += ` - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Invoice number
    if (resource.invoiceNumber) {
      facts.push(this.createChunk(
        `Invoice number: ${resource.invoiceNumber}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Type
    if (resource.type) {
      const type = resource.type.coding?.[0]?.display || resource.type.text;
      facts.push(this.createChunk(
        `Type: ${type}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Date
    if (resource.date) {
      facts.push(this.createChunk(
        `Date: ${new Date(resource.date).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Subject (patient)
    if (resource.subject) {
      facts.push(this.createChunk(
        `Subject: ${resource.subject}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Recipient
    if (resource.recipient) {
      facts.push(this.createChunk(
        `Recipient: ${resource.recipient}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Issuer
    if (resource.issuer) {
      facts.push(this.createChunk(
        `Issuer: ${resource.issuer}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Account
    if (resource.account) {
      facts.push(this.createChunk(
        `Account: ${resource.account}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Participants
    if (resource.participant?.length > 0) {
      resource.participant.forEach((participant: any, index: number) => {
        const role = participant.role?.coding?.[0]?.display || participant.role?.text || 'participant';
        facts.push(this.createChunk(
          `${role}: ${participant.actor}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Line items
    if (resource.lineItem?.length > 0) {
      resource.lineItem.forEach((item: any, index: number) => {
        if (item.chargeItem) {
          facts.push(this.createChunk(
            `Line item ${index + 1}: ${item.chargeItem}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        // Price components
        if (item.priceComponent?.length > 0) {
          item.priceComponent.forEach((pc: any) => {
            const amount = this.parseAmount(pc.amount);
            facts.push(this.createChunk(
              `${pc.type}: ${amount}`,
              'granular_fact',
              resource,
              significance
            ));
          });
        }
      });
    }
    
    // Totals
    if (resource.totalPreTax) {
      const preTax = this.parseAmount(resource.totalPreTax);
      facts.push(this.createChunk(
        `Total pre-tax: ${preTax}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    if (resource.totalTax) {
      const tax = this.parseAmount(resource.totalTax);
      facts.push(this.createChunk(
        `Total tax: ${tax}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    if (resource.totalGross) {
      const gross = this.parseAmount(resource.totalGross);
      facts.push(this.createChunk(
        `Total gross: ${gross}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    if (resource.totalNet) {
      const net = this.parseAmount(resource.totalNet);
      facts.push(this.createChunk(
        `Total net: ${net}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Payment terms
    if (resource.paymentTerms) {
      facts.push(this.createChunk(
        `Payment terms: ${resource.paymentTerms}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Cancelled reason
    if (resource.cancelledReason) {
      facts.push(this.createChunk(
        `Cancelled reason: ${resource.cancelledReason}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Notes
    if (resource.note?.length > 0) {
      resource.note.forEach((note: any, index: number) => {
        facts.push(this.createChunk(
          `Note ${index + 1}: ${note.text}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    return facts;
  }

  private extractPatientId(resource: any): string {
    if (resource.subject?.startsWith('Patient/')) {
      return resource.subject.replace('Patient/', '');
    }
    
    return resource.subject || '';
  }

  private extractTotalAmount(resource: any): string {
    if (resource.totalGross) {
      return this.parseAmount(resource.totalGross);
    }
    
    if (resource.totalNet) {
      return this.parseAmount(resource.totalNet);
    }
    
    return '0.00';
  }

  private extractCurrency(resource: any): string {
    if (resource.totalGross?.currency) {
      return resource.totalGross.currency;
    }
    
    if (resource.totalNet?.currency) {
      return resource.totalNet.currency;
    }
    
    return 'USD';
  }

  private parseAmount(amountObj: any): string {
    if (!amountObj) return '0.00';
    
    if (typeof amountObj === 'number') {
      return amountObj.toFixed(2);
    }
    
    if (amountObj.value !== undefined) {
      return parseFloat(amountObj.value).toFixed(2);
    }
    
    return '0.00';
  }

  private extractInvoiceCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Invoice number
    if (resource.invoiceNumber) {
      codes.push(resource.invoiceNumber.toLowerCase());
    }
    
    // Type codes
    if (resource.type?.coding) {
      resource.type.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    return codes;
  }

  private isOverdue(resource: any): boolean {
    // Simplified overdue check - would need proper due date calculation
    if (resource.date) {
      const invoiceDate = new Date(resource.date);
      const now = new Date();
      const daysDiff = (now.getTime() - invoiceDate.getTime()) / (1000 * 3600 * 24);
      
      // Consider overdue if more than 30 days old and still issued
      return daysDiff > 30;
    }
    
    return false;
  }

  protected extractDate(resource: any): string | undefined {
    if (resource.date) {
      return new Date(resource.date).toISOString().split('T')[0];
    }
    
    if (resource.meta?.lastUpdated) {
      return new Date(resource.meta.lastUpdated).toISOString().split('T')[0];
    }
    
    return undefined;
  }
}
