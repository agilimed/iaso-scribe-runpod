import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../../ResourceTemplateService';

export class InvoiceFHIRTemplate extends BaseResourceTemplate {
  resourceType = 'InvoiceFHIR';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.identifier) {
      chunks.push({
        id: `${resource.id}-identifier`,
        type: 'granular_fact',
        content: `Invoice number: ${resource.identifier.value} (${resource.identifier.type?.text || 'N/A'})`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.status) {
      chunks.push({
        id: `${resource.id}-status`,
        type: 'granular_fact',
        content: `Status: ${resource.status}, Type: ${resource.type?.text || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.subject) {
      chunks.push({
        id: `${resource.id}-subject`,
        type: 'granular_fact',
        content: `Subject: ${resource.subject.display || resource.subject.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.recipient) {
      chunks.push({
        id: `${resource.id}-recipient`,
        type: 'granular_fact',
        content: `Recipient: ${resource.recipient.display || resource.recipient.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.date) {
      chunks.push({
        id: `${resource.id}-date`,
        type: 'granular_fact',
        content: `Invoice date: ${resource.date}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.participant) {
      resource.participant.forEach((part: any, index: number) => {
        chunks.push({
          id: `${resource.id}-participant-${index}`,
          type: 'granular_fact',
          content: `Participant ${index + 1}: ${part.role?.text || 'N/A'} - ${part.actor?.display || part.actor?.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.issuer) {
      chunks.push({
        id: `${resource.id}-issuer`,
        type: 'granular_fact',
        content: `Issuer: ${resource.issuer.display || resource.issuer.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.account) {
      chunks.push({
        id: `${resource.id}-account`,
        type: 'granular_fact',
        content: `Account: ${resource.account.display || resource.account.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.lineItem) {
      resource.lineItem.forEach((item: any, index: number) => {
        chunks.push({
          id: `${resource.id}-lineitem-${index}`,
          type: 'granular_fact',
          content: `Line item ${index + 1}: ${item.chargeItem?.display || item.chargeItem?.reference} - ${item.priceComponent?.amount?.value || 0} ${item.priceComponent?.amount?.currency || ''}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.totalPriceComponent) {
      resource.totalPriceComponent.forEach((total: any, index: number) => {
        chunks.push({
          id: `${resource.id}-total-${index}`,
          type: 'granular_fact',
          content: `${total.type?.text || 'Total'}: ${total.amount?.value || 0} ${total.amount?.currency || ''}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.totalNet) {
      chunks.push({
        id: `${resource.id}-total-net`,
        type: 'granular_fact',
        content: `Total net: ${resource.totalNet.value} ${resource.totalNet.currency}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.totalGross) {
      chunks.push({
        id: `${resource.id}-total-gross`,
        type: 'granular_fact',
        content: `Total gross: ${resource.totalGross.value} ${resource.totalGross.currency}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.paymentTerms) {
      chunks.push({
        id: `${resource.id}-payment-terms`,
        type: 'granular_fact',
        content: `Payment terms: ${resource.paymentTerms}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.note) {
      resource.note.forEach((note: any, index: number) => {
        chunks.push({
          id: `${resource.id}-note-${index}`,
          type: 'granular_fact',
          content: `Note ${index + 1}: ${note.text}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Invoice (FHIR) ${resource.identifier?.value || resource.id}: ${resource.type?.text || 'N/A'} - ${resource.totalGross?.value || resource.totalNet?.value || 0} ${resource.totalGross?.currency || resource.totalNet?.currency || ''} - ${resource.status || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Healthcare Invoice: ${resource.identifier?.value || resource.id} - Amount: ${resource.totalGross?.value || resource.totalNet?.value || 0} ${resource.totalGross?.currency || resource.totalNet?.currency || ''}, Status: ${resource.status || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract invoice type codes
    if (resource.type) {
      codes.push(...this.extractClinicalCodes(resource.type));
    }
    
    // Extract line item codes
    if (resource.lineItem) {
      resource.lineItem.forEach((item: any) => {
        if (item.chargeItem?.code) {
          codes.push(...this.extractClinicalCodes(item.chargeItem.code));
        }
      });
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.date,
      clinicalCodes: codes,
      references: [
        ...(resource.subject ? [`${resource.subject.reference}`] : []),
        ...(resource.recipient ? [`${resource.recipient.reference}`] : []),
        ...(resource.issuer ? [`${resource.issuer.reference}`] : []),
        ...(resource.account ? [`${resource.account.reference}`] : []),
        ...(resource.lineItem ? resource.lineItem.map((item: any) => item.chargeItem?.reference).filter(Boolean) : [])
      ],
      tags: [
        'invoice-management',
        'financial-billing',
        'fhir-invoice',
        ...(resource.type?.text ? [resource.type.text.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.status ? [resource.status.toLowerCase()] : []),
        ...(resource.totalGross?.value > 10000 ? ['high-value'] : []),
        ...(resource.totalGross?.value < 100 ? ['low-value'] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    if (resource.status === 'cancelled' || resource.status === 'entered-in-error') return 'abnormal';
    if (resource.status === 'draft') return 'abnormal';
    if (resource.totalGross?.value > 50000) return 'abnormal'; // High value invoices
    if (resource.status === 'balanced') return 'normal';
    
    return 'normal';
  }
}