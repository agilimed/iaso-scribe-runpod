import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../../ResourceTemplateService';

export class TimeEntryTemplate extends BaseResourceTemplate {
  resourceType = 'TimeEntry';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'low';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const timeSummary = this.generateTimeSummary(resource);
    chunks.push(this.createChunk(timeSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'business',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: undefined,
        episode_id: undefined
      },
      chunk_type: 'resource_summary',
      chunk_level: 'encounter',
      searchable_codes: this.extractTimeCodes(resource),
      searchable_values: [resource.hours?.toString() || ''],
      searchable_units: ['hours'],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Excessive overtime (> 12 hours in a day)
    if (resource.hours && parseFloat(resource.hours) > 12) {
      return 'abnormal';
    }
    
    // Rejected time entries
    if (resource.status === 'rejected') {
      return 'abnormal';
    }
    
    // Error entries
    if (resource.status === 'entered-in-error') {
      return 'critical';
    }
    
    return 'normal';
  }

  private generateTimeSummary(resource: any): string {
    const employee = resource.employee || 'Unknown employee';
    const date = this.extractDate(resource);
    const hours = resource.hours || 0;
    const projectCode = resource.projectCode || 'General';
    const status = resource.status || 'unknown';
    
    let summary = `Time entry for ${employee}`;
    
    if (date) {
      summary += ` on ${date}`;
    }
    
    summary += ` - ${hours} hours on ${projectCode} - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Employee
    if (resource.employee) {
      facts.push(this.createChunk(
        `Employee: ${resource.employee}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Date
    if (resource.date) {
      facts.push(this.createChunk(
        `Date: ${new Date(resource.date).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Hours
    if (resource.hours !== undefined) {
      facts.push(this.createChunk(
        `Hours: ${resource.hours}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Project code
    if (resource.projectCode) {
      facts.push(this.createChunk(
        `Project code: ${resource.projectCode}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Activity type
    if (resource.activityType) {
      facts.push(this.createChunk(
        `Activity type: ${resource.activityType}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Start time
    if (resource.startTime) {
      facts.push(this.createChunk(
        `Start time: ${resource.startTime}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // End time
    if (resource.endTime) {
      facts.push(this.createChunk(
        `End time: ${resource.endTime}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Break time
    if (resource.breakTime !== undefined) {
      facts.push(this.createChunk(
        `Break time: ${resource.breakTime} hours`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Overtime hours
    if (resource.overtimeHours !== undefined) {
      facts.push(this.createChunk(
        `Overtime hours: ${resource.overtimeHours}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Location
    if (resource.location) {
      facts.push(this.createChunk(
        `Location: ${resource.location}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Department
    if (resource.department) {
      facts.push(this.createChunk(
        `Department: ${resource.department}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Cost center
    if (resource.costCenter) {
      facts.push(this.createChunk(
        `Cost center: ${resource.costCenter}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Billable
    if (resource.billable !== undefined) {
      facts.push(this.createChunk(
        `Billable: ${resource.billable}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Rate
    if (resource.rate !== undefined) {
      const currency = resource.currency || 'USD';
      facts.push(this.createChunk(
        `Rate: ${currency} ${parseFloat(resource.rate).toFixed(2)}/hour`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Approved by
    if (resource.approvedBy) {
      facts.push(this.createChunk(
        `Approved by: ${resource.approvedBy}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Approval date
    if (resource.approvalDate) {
      facts.push(this.createChunk(
        `Approval date: ${new Date(resource.approvalDate).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Submission date
    if (resource.submissionDate) {
      facts.push(this.createChunk(
        `Submission date: ${new Date(resource.submissionDate).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Description
    if (resource.description) {
      facts.push(this.createChunk(
        `Description: ${resource.description}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Comments
    if (resource.comments) {
      facts.push(this.createChunk(
        `Comments: ${resource.comments}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Rejection reason
    if (resource.rejectionReason) {
      facts.push(this.createChunk(
        `Rejection reason: ${resource.rejectionReason}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    return facts;
  }

  private extractTimeCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Employee
    if (resource.employee) {
      codes.push(resource.employee.toLowerCase());
    }
    
    // Project code
    if (resource.projectCode) {
      codes.push(resource.projectCode.toLowerCase());
    }
    
    // Activity type
    if (resource.activityType) {
      codes.push(resource.activityType.toLowerCase());
    }
    
    // Department
    if (resource.department) {
      codes.push(resource.department.toLowerCase());
    }
    
    // Location
    if (resource.location) {
      codes.push(resource.location.toLowerCase());
    }
    
    return codes;
  }

  private extractPatientId(resource: any): string {
    // Time entries might be linked to patient care activities
    if (resource.patientReference) {
      if (resource.patientReference.startsWith('Patient/')) {
        return resource.patientReference.replace('Patient/', '');
      }
      return resource.patientReference;
    }
    
    return '';
  }

  protected extractDate(resource: any): string | undefined {
    if (resource.date) {
      return new Date(resource.date).toISOString().split('T')[0];
    }
    
    if (resource.submissionDate) {
      return new Date(resource.submissionDate).toISOString().split('T')[0];
    }
    
    if (resource.meta?.lastUpdated) {
      return new Date(resource.meta.lastUpdated).toISOString().split('T')[0];
    }
    
    return undefined;
  }
}
