import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../../ResourceTemplateService';

export class QualityMeasureTemplate extends BaseResourceTemplate {
  resourceType = 'QualityMeasure';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.title) {
      chunks.push({
        id: `${resource.id}-title`,
        type: 'granular_fact',
        content: `Quality measure: ${resource.title} (${resource.identifier || resource.id})`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.description) {
      chunks.push({
        id: `${resource.id}-description`,
        type: 'granular_fact',
        content: `Description: ${resource.description.substring(0, 200)}${resource.description.length > 200 ? '...' : ''}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.measureType) {
      chunks.push({
        id: `${resource.id}-type`,
        type: 'granular_fact',
        content: `Measure type: ${resource.measureType}, Category: ${resource.category || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.scoring) {
      chunks.push({
        id: `${resource.id}-scoring`,
        type: 'granular_fact',
        content: `Scoring: ${resource.scoring.type}, Unit: ${resource.scoring.unit || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.clinicalDomain) {
      chunks.push({
        id: `${resource.id}-domain`,
        type: 'granular_fact',
        content: `Clinical domain: ${resource.clinicalDomain}, Specialty: ${resource.specialty || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.riskAdjustment) {
      chunks.push({
        id: `${resource.id}-risk`,
        type: 'granular_fact',
        content: `Risk adjustment: ${resource.riskAdjustment ? 'Yes' : 'No'}, Stratification: ${resource.stratification ? 'Yes' : 'No'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.purpose) {
      chunks.push({
        id: `${resource.id}-purpose`,
        type: 'granular_fact',
        content: `Purpose: ${resource.purpose}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.population) {
      chunks.push({
        id: `${resource.id}-population`,
        type: 'granular_fact',
        content: `Population: ${resource.population.description || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.improvementNotation) {
      chunks.push({
        id: `${resource.id}-improvement`,
        type: 'granular_fact',
        content: `Improvement notation: ${resource.improvementNotation}, Target: ${resource.target || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Quality Measure: ${resource.title} (${resource.measureType}) - ${resource.clinicalDomain || 'N/A'} domain, ${resource.scoring?.type || 'N/A'} scoring`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Quality Measure Definition: ${resource.title} - ${resource.measureType || 'N/A'} type, ${resource.clinicalDomain || 'N/A'} domain`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.date,
      clinicalCodes: [
        ...(resource.identifier ? [resource.identifier] : []),
        ...(resource.version ? [resource.version] : [])
      ],
      references: [
        ...(resource.author ? [`${resource.author.reference}`] : []),
        ...(resource.publisher ? [`Organization/${resource.publisher}`] : [])
      ],
      tags: [
        'quality-measure',
        'performance-metrics',
        'clinical-quality',
        ...(resource.measureType ? [resource.measureType.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.clinicalDomain ? [resource.clinicalDomain.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.category ? [resource.category.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.riskAdjustment ? ['risk-adjusted'] : []),
        ...(resource.stratification ? ['stratified'] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    if (resource.status === 'draft') return 'abnormal';
    if (resource.status === 'retired') return 'abnormal';
    if (resource.experimental) return 'abnormal';
    
    return 'normal';
  }
}