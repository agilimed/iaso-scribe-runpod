import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../../ResourceTemplateService';

export class SupplyRequestTemplate extends BaseResourceTemplate {
  resourceType = 'SupplyRequest';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.identifier) {
      chunks.push({
        id: `${resource.id}-identifier`,
        type: 'granular_fact',
        content: `Supply request: ${resource.identifier} (${resource.status || 'N/A'})`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.category) {
      chunks.push({
        id: `${resource.id}-category`,
        type: 'granular_fact',
        content: `Category: ${resource.category}, Priority: ${resource.priority || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.itemCodeableConcept) {
      chunks.push({
        id: `${resource.id}-item`,
        type: 'granular_fact',
        content: `Item: ${resource.itemCodeableConcept.text || resource.itemCodeableConcept.coding?.[0]?.display}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.quantity) {
      chunks.push({
        id: `${resource.id}-quantity`,
        type: 'granular_fact',
        content: `Quantity: ${resource.quantity.value} ${resource.quantity.unit || resource.quantity.code || ''}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.requestedBy) {
      chunks.push({
        id: `${resource.id}-requester`,
        type: 'granular_fact',
        content: `Requested by: ${resource.requestedBy.display || resource.requestedBy.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.deliverFrom) {
      chunks.push({
        id: `${resource.id}-delivery`,
        type: 'granular_fact',
        content: `Deliver from: ${resource.deliverFrom.display || resource.deliverFrom.reference} to ${resource.deliverTo?.display || resource.deliverTo?.reference || 'N/A'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.occurrence) {
      chunks.push({
        id: `${resource.id}-occurrence`,
        type: 'granular_fact',
        content: `Occurrence: ${resource.occurrence.start} to ${resource.occurrence.end}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.reasonCode) {
      chunks.push({
        id: `${resource.id}-reason`,
        type: 'granular_fact',
        content: `Reason: ${resource.reasonCode.text || resource.reasonCode.coding?.[0]?.display}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.supplierSelected) {
      chunks.push({
        id: `${resource.id}-supplier`,
        type: 'granular_fact',
        content: `Supplier: ${resource.supplierSelected.display || resource.supplierSelected.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Supply Request ${resource.identifier}: ${resource.itemCodeableConcept?.text || 'N/A'} (${resource.quantity?.value || 0} ${resource.quantity?.unit || 'units'}) - ${resource.status || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Supply Request: ${resource.itemCodeableConcept?.text || 'N/A'} - Quantity: ${resource.quantity?.value || 0}, Status: ${resource.status || 'N/A'}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract item codes
    if (resource.itemCodeableConcept) {
      codes.push(...this.extractClinicalCodes(resource.itemCodeableConcept));
    }
    
    // Extract reason codes
    if (resource.reasonCode) {
      codes.push(...this.extractClinicalCodes(resource.reasonCode));
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.authoredOn,
      clinicalCodes: codes,
      references: [
        ...(resource.requestedBy ? [`${resource.requestedBy.reference}`] : []),
        ...(resource.deliverFrom ? [`${resource.deliverFrom.reference}`] : []),
        ...(resource.deliverTo ? [`${resource.deliverTo.reference}`] : []),
        ...(resource.supplierSelected ? [`${resource.supplierSelected.reference}`] : [])
      ],
      tags: [
        'supply-management',
        'procurement',
        'inventory',
        ...(resource.category ? [resource.category.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.priority ? [resource.priority.toLowerCase()] : []),
        ...(resource.status ? [resource.status.toLowerCase()] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    if (resource.priority === 'urgent' || resource.priority === 'stat') return 'critical';
    if (resource.status === 'active' && resource.priority === 'high') return 'abnormal';
    if (resource.status === 'cancelled' || resource.status === 'entered-in-error') return 'abnormal';
    
    return 'normal';
  }
}