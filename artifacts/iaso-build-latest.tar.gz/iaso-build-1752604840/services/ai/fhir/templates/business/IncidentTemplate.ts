import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../../ResourceTemplateService';

export class IncidentTemplate extends BaseResourceTemplate {
  resourceType = 'Incident';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'critical';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const incidentSummary = this.generateIncidentSummary(resource);
    chunks.push(this.createChunk(incidentSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'safety',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: undefined,
        episode_id: undefined
      },
      chunk_type: 'resource_summary',
      chunk_level: 'system',
      searchable_codes: this.extractIncidentCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // All incidents are significant by nature
    const severity = resource.severity?.toLowerCase() || '';
    
    // High severity incidents
    if (severity === 'critical' || severity === 'major' || severity === 'severe') {
      return 'critical';
    }
    
    // Patient safety incidents
    if (this.isPatientSafetyIncident(resource)) {
      return 'critical';
    }
    
    // Open/active incidents
    if (resource.status === 'open' || resource.status === 'investigating') {
      return 'abnormal';
    }
    
    return 'abnormal'; // All incidents are at least abnormal
  }

  private generateIncidentSummary(resource: any): string {
    const title = resource.title || resource.description?.substring(0, 50) || 'Incident';
    const severity = resource.severity || 'unknown severity';
    const status = resource.status || 'unknown status';
    const date = this.extractDate(resource);
    const location = resource.location || 'unknown location';
    
    let summary = `${severity} incident: "${title}"`;
    
    if (location !== 'unknown location') {
      summary += ` at ${location}`;
    }
    
    if (date) {
      summary += ` on ${date}`;
    }
    
    summary += ` - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Title
    if (resource.title) {
      facts.push(this.createChunk(
        `Title: ${resource.title}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Severity
    if (resource.severity) {
      facts.push(this.createChunk(
        `Severity: ${resource.severity}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Type
    if (resource.type) {
      facts.push(this.createChunk(
        `Type: ${resource.type}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Category
    if (resource.category) {
      facts.push(this.createChunk(
        `Category: ${resource.category}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Description
    if (resource.description) {
      facts.push(this.createChunk(
        `Description: ${resource.description}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Incident date
    if (resource.incidentDate) {
      facts.push(this.createChunk(
        `Incident date: ${new Date(resource.incidentDate).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Report date
    if (resource.reportDate) {
      facts.push(this.createChunk(
        `Report date: ${new Date(resource.reportDate).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Location
    if (resource.location) {
      facts.push(this.createChunk(
        `Location: ${resource.location}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Reporter
    if (resource.reporter) {
      facts.push(this.createChunk(
        `Reporter: ${resource.reporter}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Involved parties
    if (resource.involvedParties?.length > 0) {
      resource.involvedParties.forEach((party: any, index: number) => {
        facts.push(this.createChunk(
          `Involved party ${index + 1}: ${party}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Patient involved
    if (resource.patientInvolved) {
      facts.push(this.createChunk(
        `Patient involved: ${resource.patientInvolved}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Immediate actions
    if (resource.immediateActions) {
      facts.push(this.createChunk(
        `Immediate actions: ${resource.immediateActions}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Investigation findings
    if (resource.investigationFindings) {
      facts.push(this.createChunk(
        `Investigation findings: ${resource.investigationFindings}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Root cause
    if (resource.rootCause) {
      facts.push(this.createChunk(
        `Root cause: ${resource.rootCause}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Corrective actions
    if (resource.correctiveActions?.length > 0) {
      resource.correctiveActions.forEach((action: any, index: number) => {
        facts.push(this.createChunk(
          `Corrective action ${index + 1}: ${action}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Preventive actions
    if (resource.preventiveActions?.length > 0) {
      resource.preventiveActions.forEach((action: any, index: number) => {
        facts.push(this.createChunk(
          `Preventive action ${index + 1}: ${action}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Assigned to
    if (resource.assignedTo) {
      facts.push(this.createChunk(
        `Assigned to: ${resource.assignedTo}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Due date
    if (resource.dueDate) {
      facts.push(this.createChunk(
        `Due date: ${new Date(resource.dueDate).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Closure date
    if (resource.closureDate) {
      facts.push(this.createChunk(
        `Closure date: ${new Date(resource.closureDate).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Closure notes
    if (resource.closureNotes) {
      facts.push(this.createChunk(
        `Closure notes: ${resource.closureNotes}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Regulatory reporting required
    if (resource.regulatoryReportingRequired !== undefined) {
      facts.push(this.createChunk(
        `Regulatory reporting required: ${resource.regulatoryReportingRequired}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // External reporting
    if (resource.externalReporting?.length > 0) {
      resource.externalReporting.forEach((report: any, index: number) => {
        facts.push(this.createChunk(
          `External reporting ${index + 1}: ${report}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    return facts;
  }

  private extractIncidentCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Title
    if (resource.title) {
      codes.push(resource.title.toLowerCase());
    }
    
    // Type
    if (resource.type) {
      codes.push(resource.type.toLowerCase());
    }
    
    // Category
    if (resource.category) {
      codes.push(resource.category.toLowerCase());
    }
    
    // Severity
    if (resource.severity) {
      codes.push(resource.severity.toLowerCase());
    }
    
    // Location
    if (resource.location) {
      codes.push(resource.location.toLowerCase());
    }
    
    return codes;
  }

  private isPatientSafetyIncident(resource: any): boolean {
    const safetyKeywords = [
      'patient safety', 'medication error', 'fall', 'infection',
      'wrong patient', 'wrong procedure', 'adverse event',
      'patient harm', 'never event', 'sentinel event'
    ];
    
    const text = `${resource.title || ''} ${resource.description || ''} ${resource.category || ''} ${resource.type || ''}`.toLowerCase();
    
    return safetyKeywords.some(keyword => text.includes(keyword));
  }

  private extractPatientId(resource: any): string {
    if (resource.patientInvolved) {
      if (resource.patientInvolved.startsWith('Patient/')) {
        return resource.patientInvolved.replace('Patient/', '');
      }
      return resource.patientInvolved;
    }
    
    return '';
  }

  protected extractDate(resource: any): string | undefined {
    if (resource.incidentDate) {
      return new Date(resource.incidentDate).toISOString().split('T')[0];
    }
    
    if (resource.reportDate) {
      return new Date(resource.reportDate).toISOString().split('T')[0];
    }
    
    if (resource.meta?.lastUpdated) {
      return new Date(resource.meta.lastUpdated).toISOString().split('T')[0];
    }
    
    return undefined;
  }
}
