import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance, ChunkType } from '../ResourceTemplateService';

export class PatientTemplate extends BaseResourceTemplate {
  resourceType = 'Patient';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'critical';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Main patient summary chunk
    const patientSummary = this.generatePatientSummary(resource);
    chunks.push(this.createChunk(patientSummary, 'resource_summary', resource));
    
    // Granular fact chunks
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const patientId = resource.id;
    const birthDate = resource.birthDate ? new Date(resource.birthDate) : null;
    const age = birthDate ? this.calculateAge(birthDate) : null;
    
    return {
      patient_id: patientId,
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'admin',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: resource.meta?.lastUpdated?.split('T')[0] || new Date().toISOString().split('T')[0],
        encounter_id: undefined,
        episode_id: undefined
      },
      chunk_type: 'resource_summary',
      chunk_level: 'patient',
      searchable_codes: this.extractIdentifierCodes(resource),
      searchable_values: age ? [age] : [],
      searchable_units: age ? ['years'] : [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Patient records are generally normal unless there are critical flags
    if (resource.active === false) {
      return 'abnormal';
    }
    
    // Check for critical flags in extensions or tags
    if (resource.meta?.tag?.some((tag: any) => tag.code === 'critical')) {
      return 'critical';
    }
    
    return 'normal';
  }

  private generatePatientSummary(resource: any): string {
    const name = this.extractPatientName(resource);
    const age = this.extractAge(resource);
    const gender = resource.gender || 'unknown';
    const active = resource.active !== false ? 'active' : 'inactive';
    const mrn = this.extractMRN(resource);
    
    let summary = `Patient ${name}`;
    
    if (mrn) {
      summary += ` (MRN: ${mrn})`;
    }
    
    summary += ` is a ${age}-year-old ${gender} with ${active} status`;
    
    // Add contact information if available
    const phone = resource.telecom?.find((t: any) => t.system === 'phone')?.value;
    const email = resource.telecom?.find((t: any) => t.system === 'email')?.value;
    
    if (phone || email) {
      summary += '. Contact: ';
      if (phone) summary += `Phone ${phone}`;
      if (phone && email) summary += ', ';
      if (email) summary += `Email ${email}`;
    }
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    
    // Demographics facts
    if (resource.birthDate) {
      const age = this.extractAge(resource);
      facts.push(this.createChunk(
        `Patient is ${age} years old (born ${resource.birthDate})`,
        'granular_fact',
        resource
      ));
    }
    
    if (resource.gender) {
      facts.push(this.createChunk(
        `Patient gender is ${resource.gender}`,
        'granular_fact',
        resource
      ));
    }
    
    // Address facts
    if (resource.address?.length > 0) {
      const address = resource.address[0];
      const addressText = this.formatAddress(address);
      facts.push(this.createChunk(
        `Patient address: ${addressText}`,
        'granular_fact',
        resource
      ));
    }
    
    // Contact facts
    if (resource.telecom?.length > 0) {
      resource.telecom.forEach((contact: any) => {
        facts.push(this.createChunk(
          `Patient ${contact.system}: ${contact.value}`,
          'granular_fact',
          resource
        ));
      });
    }
    
    // Identifier facts
    if (resource.identifier?.length > 0) {
      resource.identifier.forEach((id: any) => {
        const system = id.system || 'unknown system';
        const value = id.value;
        const type = id.type?.coding?.[0]?.display || id.type?.text || 'identifier';
        
        facts.push(this.createChunk(
          `Patient ${type}: ${value} (${system})`,
          'granular_fact',
          resource
        ));
      });
    }
    
    // Marital status
    if (resource.maritalStatus) {
      const status = resource.maritalStatus.coding?.[0]?.display || 
                   resource.maritalStatus.text || 'unknown';
      facts.push(this.createChunk(
        `Patient marital status: ${status}`,
        'granular_fact',
        resource
      ));
    }
    
    // Emergency contact
    if (resource.contact?.length > 0) {
      resource.contact.forEach((contact: any) => {
        const name = contact.name?.family || contact.name?.given?.join(' ') || 'Unknown';
        const relationship = contact.relationship?.[0]?.coding?.[0]?.display || 
                           contact.relationship?.[0]?.text || 'contact';
        
        facts.push(this.createChunk(
          `Emergency contact: ${name} (${relationship})`,
          'granular_fact',
          resource
        ));
      });
    }
    
    return facts;
  }

  private extractPatientName(resource: any): string {
    if (!resource.name?.length) return 'Unknown';
    
    const name = resource.name[0];
    const given = Array.isArray(name.given) ? name.given.join(' ') : name.given || '';
    const family = name.family || '';
    
    return `${given} ${family}`.trim() || 'Unknown';
  }

  private extractAge(resource: any): string {
    if (!resource.birthDate) return 'unknown age';
    
    const birthDate = new Date(resource.birthDate);
    const age = this.calculateAge(birthDate);
    
    return age !== null ? age.toString() : 'unknown age';
  }

  private calculateAge(birthDate: Date): number | null {
    try {
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      
      return age;
    } catch {
      return null;
    }
  }

  private extractMRN(resource: any): string | null {
    if (!resource.identifier?.length) return null;
    
    // Look for MRN identifier
    const mrnIdentifier = resource.identifier.find((id: any) => 
      id.type?.coding?.[0]?.code === 'MR' ||
      id.type?.text?.toLowerCase().includes('mrn') ||
      id.system?.toLowerCase().includes('mrn')
    );
    
    return mrnIdentifier?.value || null;
  }

  private formatAddress(address: any): string {
    const parts = [];
    
    if (address.line?.length) {
      parts.push(address.line.join(' '));
    }
    
    if (address.city) parts.push(address.city);
    if (address.state) parts.push(address.state);
    if (address.postalCode) parts.push(address.postalCode);
    
    return parts.join(', ') || 'Unknown address';
  }

  private extractIdentifierCodes(resource: any): string[] {
    const codes: string[] = [];
    
    if (resource.identifier?.length > 0) {
      resource.identifier.forEach((id: any) => {
        if (id.value) codes.push(id.value);
        if (id.type?.coding?.[0]?.code) codes.push(id.type.coding[0].code);
      });
    }
    
    return codes;
  }
}