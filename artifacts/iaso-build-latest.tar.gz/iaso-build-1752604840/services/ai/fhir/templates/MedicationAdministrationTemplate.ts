import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../ResourceTemplateService';

export class MedicationAdministrationTemplate extends BaseResourceTemplate {
  resourceType = 'MedicationAdministration';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'critical';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.status) {
      chunks.push({
        id: `${resource.id}-status`,
        type: 'granular_fact',
        content: `Administration status: ${resource.status}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.medicationCodeableConcept) {
      chunks.push({
        id: `${resource.id}-medication`,
        type: 'granular_fact',
        content: `Medication: ${resource.medicationCodeableConcept.text || resource.medicationCodeableConcept.coding?.[0]?.display}`,
        metadata: this.extractMetadata(resource)
      });
    } else if (resource.medicationReference) {
      chunks.push({
        id: `${resource.id}-medication`,
        type: 'granular_fact',
        content: `Medication: ${resource.medicationReference.display || resource.medicationReference.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.dosage) {
      const dose = resource.dosage.dose;
      const rate = resource.dosage.rate;
      chunks.push({
        id: `${resource.id}-dosage`,
        type: 'granular_fact',
        content: `Dosage: ${dose?.value || ''} ${dose?.unit || dose?.code || ''} ${resource.dosage.route?.text || ''} ${rate ? `at ${rate.value || rate.quantity?.value} ${rate.unit || rate.quantity?.unit || ''}` : ''}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.effectivePeriod) {
      chunks.push({
        id: `${resource.id}-effective`,
        type: 'granular_fact',
        content: `Administered: ${resource.effectivePeriod.start} to ${resource.effectivePeriod.end || 'ongoing'}`,
        metadata: this.extractMetadata(resource)
      });
    } else if (resource.effectiveDateTime) {
      chunks.push({
        id: `${resource.id}-effective`,
        type: 'granular_fact',
        content: `Administered at: ${resource.effectiveDateTime}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.performer) {
      resource.performer.forEach((perf: any, index: number) => {
        chunks.push({
          id: `${resource.id}-performer-${index}`,
          type: 'granular_fact',
          content: `Administered by: ${perf.actor.display || perf.actor.reference} (${perf.function?.text || 'N/A'})`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.reasonCode) {
      resource.reasonCode.forEach((reason: any, index: number) => {
        chunks.push({
          id: `${resource.id}-reason-${index}`,
          type: 'granular_fact',
          content: `Reason: ${reason.text || reason.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.note) {
      resource.note.forEach((note: any, index: number) => {
        chunks.push({
          id: `${resource.id}-note-${index}`,
          type: 'granular_fact',
          content: `Note: ${note.text}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.statusReason) {
      resource.statusReason.forEach((reason: any, index: number) => {
        chunks.push({
          id: `${resource.id}-status-reason-${index}`,
          type: 'granular_fact',
          content: `Status reason: ${reason.text || reason.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.request) {
      chunks.push({
        id: `${resource.id}-request`,
        type: 'granular_fact',
        content: `Based on request: ${resource.request.display || resource.request.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.device) {
      resource.device.forEach((device: any, index: number) => {
        chunks.push({
          id: `${resource.id}-device-${index}`,
          type: 'granular_fact',
          content: `Device used: ${device.display || device.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Medication Administration: ${resource.medicationCodeableConcept?.text || resource.medicationReference?.display || 'Medication'} administered to ${resource.subject?.display || 'patient'} - Status: ${resource.status}, Dose: ${resource.dosage?.dose?.value || 'N/A'} ${resource.dosage?.dose?.unit || ''}`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Medication Given: ${resource.medicationCodeableConcept?.text || resource.medicationReference?.display || 'N/A'} - ${resource.dosage?.dose?.value || 'N/A'} ${resource.dosage?.dose?.unit || ''}, Status: ${resource.status}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract medication codes
    if (resource.medicationCodeableConcept) {
      codes.push(...this.extractClinicalCodes(resource.medicationCodeableConcept));
    }
    
    // Extract reason codes
    if (resource.reasonCode) {
      resource.reasonCode.forEach((reason: any) => {
        codes.push(...this.extractClinicalCodes(reason));
      });
    }
    
    // Extract route codes
    if (resource.dosage?.route) {
      codes.push(...this.extractClinicalCodes(resource.dosage.route));
    }
    
    // Extract status reason codes
    if (resource.statusReason) {
      resource.statusReason.forEach((reason: any) => {
        codes.push(...this.extractClinicalCodes(reason));
      });
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.effectiveDateTime || resource.effectivePeriod?.start,
      clinicalCodes: codes,
      references: [
        ...(resource.subject ? [`${resource.subject.reference}`] : []),
        ...(resource.context ? [`${resource.context.reference}`] : []),
        ...(resource.medicationReference ? [`${resource.medicationReference.reference}`] : []),
        ...(resource.request ? [`${resource.request.reference}`] : []),
        ...(resource.performer ? resource.performer.map((p: any) => p.actor.reference) : []),
        ...(resource.device ? resource.device.map((d: any) => d.reference) : [])
      ],
      tags: [
        'medication-administration',
        'medication-given',
        'clinical-event',
        ...(resource.status ? [resource.status] : []),
        ...(resource.dosage?.route?.text ? [resource.dosage.route.text.toLowerCase().replace(/\s+/g, '-')] : []),
        ...(resource.category?.text ? [resource.category.text.toLowerCase().replace(/\s+/g, '-')] : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    // Not given medications
    if (resource.status === 'not-done' || resource.status === 'stopped') return 'critical';
    
    // Error status
    if (resource.status === 'entered-in-error') return 'abnormal';
    
    // Check for high-alert medications
    const medicationText = resource.medicationCodeableConcept?.text?.toLowerCase() || 
                          resource.medicationCodeableConcept?.coding?.[0]?.display?.toLowerCase() || '';
    const highAlertMeds = ['insulin', 'heparin', 'warfarin', 'morphine', 'fentanyl', 'digoxin', 'chemotherapy'];
    if (highAlertMeds.some(med => medicationText.includes(med))) return 'critical';
    
    // Check for adverse events in notes
    if (resource.note?.some((note: any) => {
      const noteText = note.text?.toLowerCase() || '';
      return noteText.includes('adverse') || noteText.includes('reaction') || noteText.includes('error');
    })) return 'critical';
    
    if (resource.status === 'completed') return 'normal';
    
    return 'normal';
  }
}