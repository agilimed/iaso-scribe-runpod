import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class PractitionerTemplate extends BaseResourceTemplate {
  resourceType = 'Practitioner';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'critical';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Main practitioner summary chunk
    const practitionerSummary = this.generatePractitionerSummary(resource);
    chunks.push(this.createChunk(practitionerSummary, 'resource_summary', resource));
    
    // Granular fact chunks
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: '', // Practitioners don't have patients
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'admin',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: resource.meta?.lastUpdated?.split('T')[0] || new Date().toISOString().split('T')[0],
        encounter_id: undefined,
        episode_id: undefined
      },
      chunk_type: 'resource_summary',
      chunk_level: 'patient',
      searchable_codes: this.extractPractitionerCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Inactive practitioners might be abnormal
    if (resource.active === false) {
      return 'abnormal';
    }
    
    return 'normal';
  }

  private generatePractitionerSummary(resource: any): string {
    const name = this.extractPractitionerName(resource);
    const qualifications = this.extractQualifications(resource);
    const specialties = this.extractSpecialties(resource);
    const npi = this.extractNPI(resource);
    const active = resource.active !== false ? 'active' : 'inactive';
    
    let summary = `${name}`;
    
    if (qualifications.length > 0) {
      summary += ` (${qualifications.join(', ')})`;
    }
    
    if (specialties.length > 0) {
      summary += ` practices ${specialties.join(', ')}`;
    }
    
    if (npi) {
      summary += ` with NPI ${npi}`;
    }
    
    summary += ` - ${active} status`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    
    // Name fact
    const name = this.extractPractitionerName(resource);
    if (name) {
      facts.push(this.createChunk(
        `Practitioner name: ${name}`,
        'granular_fact',
        resource
      ));
    }
    
    // Qualification facts
    const qualifications = this.extractQualifications(resource);
    qualifications.forEach(qual => {
      facts.push(this.createChunk(
        `Qualification: ${qual}`,
        'granular_fact',
        resource
      ));
    });
    
    // Specialty facts
    const specialties = this.extractSpecialties(resource);
    specialties.forEach(specialty => {
      facts.push(this.createChunk(
        `Specialty: ${specialty}`,
        'granular_fact',
        resource
      ));
    });
    
    // Identifier facts
    if (resource.identifier?.length > 0) {
      resource.identifier.forEach((id: any) => {
        const system = id.system || 'unknown system';
        const value = id.value;
        const type = id.type?.coding?.[0]?.display || id.type?.text || 'identifier';
        
        facts.push(this.createChunk(
          `${type}: ${value} (${system})`,
          'granular_fact',
          resource
        ));
      });
    }
    
    // Contact facts
    if (resource.telecom?.length > 0) {
      resource.telecom.forEach((contact: any) => {
        facts.push(this.createChunk(
          `Contact ${contact.system}: ${contact.value}`,
          'granular_fact',
          resource
        ));
      });
    }
    
    // Address facts
    if (resource.address?.length > 0) {
      const address = resource.address[0];
      const addressText = this.formatAddress(address);
      facts.push(this.createChunk(
        `Address: ${addressText}`,
        'granular_fact',
        resource
      ));
    }
    
    // Gender fact
    if (resource.gender) {
      facts.push(this.createChunk(
        `Gender: ${resource.gender}`,
        'granular_fact',
        resource
      ));
    }
    
    // Birth date fact
    if (resource.birthDate) {
      facts.push(this.createChunk(
        `Birth date: ${resource.birthDate}`,
        'granular_fact',
        resource
      ));
    }
    
    return facts;
  }

  private extractPractitionerName(resource: any): string {
    if (!resource.name?.length) return 'Unknown Practitioner';
    
    const name = resource.name[0];
    const prefix = name.prefix ? name.prefix.join(' ') + ' ' : '';
    const given = Array.isArray(name.given) ? name.given.join(' ') : name.given || '';
    const family = name.family || '';
    const suffix = name.suffix ? ' ' + name.suffix.join(' ') : '';
    
    return `${prefix}${given} ${family}${suffix}`.trim() || 'Unknown Practitioner';
  }

  private extractQualifications(resource: any): string[] {
    const qualifications: string[] = [];
    
    if (resource.qualification?.length > 0) {
      resource.qualification.forEach((qual: any) => {
        const code = qual.code?.coding?.[0]?.display || qual.code?.text;
        if (code) {
          qualifications.push(code);
        }
      });
    }
    
    return qualifications;
  }

  private extractSpecialties(resource: any): string[] {
    const specialties: string[] = [];
    
    // Note: Specialties are typically in PractitionerRole, not Practitioner
    // But we'll check for any specialty-related extensions
    if (resource.extension?.length > 0) {
      resource.extension.forEach((ext: any) => {
        if (ext.url?.includes('specialty') && ext.valueCodeableConcept) {
          const specialty = ext.valueCodeableConcept.coding?.[0]?.display || 
                          ext.valueCodeableConcept.text;
          if (specialty) {
            specialties.push(specialty);
          }
        }
      });
    }
    
    return specialties;
  }

  private extractNPI(resource: any): string | null {
    if (!resource.identifier?.length) return null;
    
    const npiIdentifier = resource.identifier.find((id: any) => 
      id.system?.includes('npi') ||
      id.type?.coding?.[0]?.code === 'NPI' ||
      id.type?.text?.toLowerCase().includes('npi')
    );
    
    return npiIdentifier?.value || null;
  }

  private formatAddress(address: any): string {
    const parts = [];
    
    if (address.line?.length) {
      parts.push(address.line.join(' '));
    }
    
    if (address.city) parts.push(address.city);
    if (address.state) parts.push(address.state);
    if (address.postalCode) parts.push(address.postalCode);
    
    return parts.join(', ') || 'Unknown address';
  }

  private extractPractitionerCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Extract identifier values
    if (resource.identifier?.length > 0) {
      resource.identifier.forEach((id: any) => {
        if (id.value) codes.push(id.value);
        if (id.type?.coding?.[0]?.code) codes.push(id.type.coding[0].code);
      });
    }
    
    // Extract qualification codes
    if (resource.qualification?.length > 0) {
      resource.qualification.forEach((qual: any) => {
        if (qual.code?.coding) {
          qual.code.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    return codes;
  }
}