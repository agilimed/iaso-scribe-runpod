import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class CompositionTemplate extends BaseResourceTemplate {
  resourceType = 'Composition';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const compositionSummary = this.generateCompositionSummary(resource);
    chunks.push(this.createChunk(compositionSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'documents',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'encounter',
      searchable_codes: this.extractCompositionCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Emergency or critical document types
    if (this.isCriticalDocumentType(resource)) {
      return 'critical';
    }
    
    // Preliminary or amended documents
    if (resource.status === 'preliminary' || resource.status === 'amended') {
      return 'abnormal';
    }
    
    // Final documents are normal
    if (resource.status === 'final') {
      return 'normal';
    }
    
    return 'normal';
  }

  private generateCompositionSummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const title = resource.title || 'Document';
    const type = this.extractDocumentType(resource);
    const status = resource.status || 'unknown';
    const date = this.extractDate(resource);
    
    let summary = `Patient ${patientId} has ${type} "${title}"`;
    
    if (date) {
      summary += ` dated ${date}`;
    }
    
    summary += ` - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Title
    if (resource.title) {
      facts.push(this.createChunk(
        `Title: ${resource.title}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Type
    const type = this.extractDocumentType(resource);
    facts.push(this.createChunk(
      `Type: ${type}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Class
    if (resource.class) {
      const docClass = resource.class.coding?.[0]?.display || resource.class.text;
      facts.push(this.createChunk(
        `Class: ${docClass}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Category
    if (resource.category?.length > 0) {
      resource.category.forEach((category: any) => {
        const display = category.coding?.[0]?.display || category.text;
        facts.push(this.createChunk(
          `Category: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Date
    if (resource.date) {
      facts.push(this.createChunk(
        `Date: ${new Date(resource.date).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Authors
    if (resource.author?.length > 0) {
      resource.author.forEach((author: any) => {
        const name = author.display || author.reference;
        facts.push(this.createChunk(
          `Author: ${name}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Confidentiality
    if (resource.confidentiality) {
      facts.push(this.createChunk(
        `Confidentiality: ${resource.confidentiality}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Attester
    if (resource.attester?.length > 0) {
      resource.attester.forEach((attester: any) => {
        const party = attester.party?.display || attester.party?.reference;
        const mode = attester.mode || 'unknown';
        facts.push(this.createChunk(
          `Attester: ${party} (${mode})`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Custodian
    if (resource.custodian) {
      const custodian = resource.custodian.display || resource.custodian.reference;
      facts.push(this.createChunk(
        `Custodian: ${custodian}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Relates to
    if (resource.relatesTo?.length > 0) {
      resource.relatesTo.forEach((relation: any) => {
        const code = relation.code || 'unknown';
        const target = relation.targetReference?.display || relation.targetReference?.reference;
        facts.push(this.createChunk(
          `Relates to: ${target} (${code})`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Event
    if (resource.event?.length > 0) {
      resource.event.forEach((event: any) => {
        if (event.code?.length > 0) {
          event.code.forEach((code: any) => {
            const display = code.coding?.[0]?.display || code.text;
            facts.push(this.createChunk(
              `Event: ${display}`,
              'granular_fact',
              resource,
              significance
            ));
          });
        }
        
        if (event.period) {
          const start = event.period.start ? new Date(event.period.start).toISOString().split('T')[0] : '';
          const end = event.period.end ? new Date(event.period.end).toISOString().split('T')[0] : '';
          
          if (start && end) {
            facts.push(this.createChunk(
              `Event period: ${start} to ${end}`,
              'granular_fact',
              resource,
              significance
            ));
          } else if (start) {
            facts.push(this.createChunk(
              `Event start: ${start}`,
              'granular_fact',
              resource,
              significance
            ));
          }
        }
      });
    }
    
    // Sections
    if (resource.section?.length > 0) {
      resource.section.forEach((section: any, index: number) => {
        if (section.title) {
          facts.push(this.createChunk(
            `Section ${index + 1}: ${section.title}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (section.code) {
          const code = section.code.coding?.[0]?.display || section.code.text;
          facts.push(this.createChunk(
            `Section ${index + 1} code: ${code}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (section.text?.div) {
          const text = section.text.div.replace(/<[^>]*>/g, '').substring(0, 200);
          facts.push(this.createChunk(
            `Section ${index + 1} text: ${text}`,
            'granular_fact',
            resource,
            significance
          ));
        }
        
        if (section.entry?.length > 0) {
          section.entry.forEach((entry: any) => {
            const ref = entry.display || entry.reference;
            facts.push(this.createChunk(
              `Section ${index + 1} entry: ${ref}`,
              'granular_fact',
              resource,
              significance
            ));
          });
        }
      });
    }
    
    return facts;
  }

  private extractDocumentType(resource: any): string {
    if (resource.type?.coding?.length > 0) {
      return resource.type.coding[0].display || resource.type.coding[0].code || 'Unknown document';
    }
    
    if (resource.type?.text) {
      return resource.type.text;
    }
    
    return 'Unknown document';
  }

  private extractCompositionCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Type codes
    if (resource.type?.coding) {
      resource.type.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    // Class codes
    if (resource.class?.coding) {
      resource.class.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
      });
    }
    
    // Category codes
    if (resource.category?.length > 0) {
      resource.category.forEach((category: any) => {
        if (category.coding) {
          category.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    return codes;
  }

  private isCriticalDocumentType(resource: any): boolean {
    const type = this.extractDocumentType(resource).toLowerCase();
    const criticalTypes = [
      'emergency', 'trauma', 'discharge', 'operative', 'pathology',
      'radiology', 'cardiology', 'critical', 'urgent'
    ];
    
    return criticalTypes.some(criticalType => type.includes(criticalType));
  }
}
