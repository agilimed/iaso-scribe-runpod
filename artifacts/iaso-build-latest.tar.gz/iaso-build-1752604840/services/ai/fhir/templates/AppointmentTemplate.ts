import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class AppointmentTemplate extends BaseResourceTemplate {
  resourceType = 'Appointment';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const appointmentSummary = this.generateAppointmentSummary(resource);
    chunks.push(this.createChunk(appointmentSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientFromParticipants(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'admin',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: undefined,
        episode_id: undefined
      },
      chunk_type: 'resource_summary',
      chunk_level: 'encounter',
      searchable_codes: this.extractAppointmentCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Urgent appointments are critical
    if (resource.priority === 'urgent' || resource.priority === 'stat') {
      return 'critical';
    }
    
    // Cancelled/no-show appointments might be abnormal
    if (resource.status === 'cancelled' || resource.status === 'noshow') {
      return 'abnormal';
    }
    
    return 'normal';
  }

  private generateAppointmentSummary(resource: any): string {
    const patientId = this.extractPatientFromParticipants(resource);
    const serviceType = this.extractServiceType(resource);
    const appointmentType = this.extractAppointmentType(resource);
    const start = resource.start ? new Date(resource.start).toISOString().split('T')[0] : 'unscheduled';
    const status = resource.status || 'unknown';
    const location = this.extractLocation(resource);
    
    let summary = `Appointment for Patient ${patientId}`;
    
    if (appointmentType || serviceType) {
      summary += ` for ${appointmentType || serviceType}`;
    }
    
    summary += ` scheduled for ${start}`;
    
    if (location) {
      summary += ` at ${location}`;
    }
    
    summary += ` - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Service category
    if (resource.serviceCategory?.length > 0) {
      resource.serviceCategory.forEach((category: any) => {
        const display = category.coding?.[0]?.display || category.text;
        facts.push(this.createChunk(
          `Service category: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Service type
    if (resource.serviceType?.length > 0) {
      resource.serviceType.forEach((type: any) => {
        const display = type.coding?.[0]?.display || type.text;
        facts.push(this.createChunk(
          `Service type: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Appointment type
    if (resource.appointmentType) {
      const type = resource.appointmentType.coding?.[0]?.display || resource.appointmentType.text;
      facts.push(this.createChunk(
        `Appointment type: ${type}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Reason
    if (resource.reasonCode?.length > 0) {
      resource.reasonCode.forEach((reason: any) => {
        const display = reason.coding?.[0]?.display || reason.text;
        facts.push(this.createChunk(
          `Reason: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Priority
    if (resource.priority) {
      facts.push(this.createChunk(
        `Priority: ${resource.priority}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Duration
    if (resource.minutesDuration) {
      facts.push(this.createChunk(
        `Duration: ${resource.minutesDuration} minutes`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Start time
    if (resource.start) {
      facts.push(this.createChunk(
        `Start time: ${new Date(resource.start).toISOString()}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // End time
    if (resource.end) {
      facts.push(this.createChunk(
        `End time: ${new Date(resource.end).toISOString()}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Created date
    if (resource.created) {
      facts.push(this.createChunk(
        `Created: ${new Date(resource.created).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Comment
    if (resource.comment) {
      facts.push(this.createChunk(
        `Comment: ${resource.comment}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Participants
    if (resource.participant?.length > 0) {
      resource.participant.forEach((participant: any) => {
        const actor = participant.actor?.display || participant.actor?.reference;
        const type = participant.type?.[0]?.coding?.[0]?.display || 'participant';
        const status = participant.status || 'unknown';
        
        facts.push(this.createChunk(
          `${type}: ${actor} (${status})`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    return facts;
  }

  private extractPatientFromParticipants(resource: any): string {
    if (resource.participant?.length > 0) {
      const patient = resource.participant.find((p: any) => 
        p.actor?.reference?.startsWith('Patient/') ||
        p.type?.[0]?.coding?.[0]?.code === 'patient'
      );
      
      if (patient) {
        return patient.actor?.reference?.replace('Patient/', '') || 
               patient.actor?.display || 
               'Unknown patient';
      }
    }
    
    return 'Unknown patient';
  }

  private extractServiceType(resource: any): string | null {
    if (resource.serviceType?.length > 0) {
      return resource.serviceType[0].coding?.[0]?.display || 
             resource.serviceType[0].text || 
             null;
    }
    
    return null;
  }

  private extractAppointmentType(resource: any): string | null {
    if (resource.appointmentType) {
      return resource.appointmentType.coding?.[0]?.display || 
             resource.appointmentType.text || 
             null;
    }
    
    return null;
  }

  private extractLocation(resource: any): string | null {
    if (resource.participant?.length > 0) {
      const location = resource.participant.find((p: any) => 
        p.actor?.reference?.startsWith('Location/') ||
        p.type?.[0]?.coding?.[0]?.code === 'location'
      );
      
      if (location) {
        return location.actor?.display || 
               location.actor?.reference || 
               null;
      }
    }
    
    return null;
  }

  private extractAppointmentCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Service category codes
    if (resource.serviceCategory?.length > 0) {
      resource.serviceCategory.forEach((category: any) => {
        if (category.coding) {
          category.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    // Service type codes
    if (resource.serviceType?.length > 0) {
      resource.serviceType.forEach((type: any) => {
        if (type.coding) {
          type.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    // Appointment type codes
    if (resource.appointmentType?.coding) {
      resource.appointmentType.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
      });
    }
    
    return codes;
  }
}