import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class DiagnosticReportTemplate extends BaseResourceTemplate {
  resourceType = 'DiagnosticReport';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const reportSummary = this.generateReportSummary(resource);
    chunks.push(this.createChunk(reportSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'labs',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'encounter',
      searchable_codes: this.extractReportCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Check conclusion for critical findings
    if (resource.conclusion && this.hasCriticalFindings(resource.conclusion)) {
      return 'critical';
    }
    
    // Check coded conclusions
    if (resource.conclusionCode?.length > 0) {
      const hasCriticalCode = resource.conclusionCode.some((code: any) => 
        this.isCriticalDiagnosticCode(code.coding?.[0]?.code)
      );
      
      if (hasCriticalCode) {
        return 'critical';
      }
    }
    
    // Check result references for abnormal findings
    if (resource.result?.length > 0) {
      // This would ideally check the actual observation results
      // For now, assume normal unless proven otherwise
      return 'normal';
    }
    
    return 'normal';
  }

  private generateReportSummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const testName = this.extractTestName(resource);
    const date = this.extractDate(resource);
    const status = resource.status || 'unknown';
    const conclusion = resource.conclusion ? 
      (resource.conclusion.length > 100 ? 
        resource.conclusion.substring(0, 100) + '...' : 
        resource.conclusion) : 
      null;
    
    let summary = `Patient ${patientId} had ${testName} report on ${date}`;
    
    if (conclusion) {
      summary += ` with ${conclusion}`;
    }
    
    summary += ` - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Test name
    const testName = this.extractTestName(resource);
    facts.push(this.createChunk(
      `Test: ${testName}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Status
    facts.push(this.createChunk(
      `Status: ${resource.status}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Category
    if (resource.category?.length > 0) {
      resource.category.forEach((category: any) => {
        const display = category.coding?.[0]?.display || category.text;
        facts.push(this.createChunk(
          `Category: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Effective date/time
    if (resource.effectiveDateTime) {
      facts.push(this.createChunk(
        `Effective date: ${new Date(resource.effectiveDateTime).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Issued date
    if (resource.issued) {
      facts.push(this.createChunk(
        `Issued: ${new Date(resource.issued).toISOString().split('T')[0]}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Performer
    if (resource.performer?.length > 0) {
      resource.performer.forEach((performer: any) => {
        const display = performer.display || performer.reference;
        facts.push(this.createChunk(
          `Performed by: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Results interpreter
    if (resource.resultsInterpreter?.length > 0) {
      resource.resultsInterpreter.forEach((interpreter: any) => {
        const display = interpreter.display || interpreter.reference;
        facts.push(this.createChunk(
          `Interpreted by: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Specimen
    if (resource.specimen?.length > 0) {
      resource.specimen.forEach((specimen: any) => {
        const display = specimen.display || specimen.reference;
        facts.push(this.createChunk(
          `Specimen: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Results
    if (resource.result?.length > 0) {
      resource.result.forEach((result: any) => {
        const display = result.display || result.reference;
        facts.push(this.createChunk(
          `Result: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Imaging study
    if (resource.imagingStudy?.length > 0) {
      resource.imagingStudy.forEach((study: any) => {
        const display = study.display || study.reference;
        facts.push(this.createChunk(
          `Imaging study: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Media
    if (resource.media?.length > 0) {
      resource.media.forEach((media: any) => {
        const comment = media.comment || 'Media attachment';
        facts.push(this.createChunk(
          `Media: ${comment}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Conclusion
    if (resource.conclusion) {
      facts.push(this.createChunk(
        `Conclusion: ${resource.conclusion}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Conclusion codes
    if (resource.conclusionCode?.length > 0) {
      resource.conclusionCode.forEach((code: any) => {
        const display = code.coding?.[0]?.display || code.text;
        facts.push(this.createChunk(
          `Conclusion code: ${display}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Presented form
    if (resource.presentedForm?.length > 0) {
      resource.presentedForm.forEach((form: any) => {
        const title = form.title || form.contentType || 'Attached document';
        facts.push(this.createChunk(
          `Document: ${title}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    return facts;
  }

  private extractTestName(resource: any): string {
    if (resource.code?.coding?.length > 0) {
      return resource.code.coding[0].display || resource.code.coding[0].code || 'Unknown test';
    }
    
    if (resource.code?.text) {
      return resource.code.text;
    }
    
    return 'Unknown test';
  }

  private extractReportCodes(resource: any): string[] {
    const codes: string[] = [];
    
    // Test codes
    if (resource.code?.coding) {
      resource.code.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    // Category codes
    if (resource.category?.length > 0) {
      resource.category.forEach((category: any) => {
        if (category.coding) {
          category.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    // Conclusion codes
    if (resource.conclusionCode?.length > 0) {
      resource.conclusionCode.forEach((code: any) => {
        if (code.coding) {
          code.coding.forEach((coding: any) => {
            if (coding.code) codes.push(coding.code);
          });
        }
      });
    }
    
    return codes;
  }

  private hasCriticalFindings(conclusion: string): boolean {
    const criticalTerms = [
      'malignant', 'cancer', 'tumor', 'carcinoma', 'neoplasm',
      'critical', 'severe', 'acute', 'emergency', 'urgent',
      'failure', 'infarction', 'hemorrhage', 'thrombosis',
      'positive', 'abnormal', 'elevated', 'decreased'
    ];
    
    const lowerConclusion = conclusion.toLowerCase();
    return criticalTerms.some(term => lowerConclusion.includes(term));
  }

  private isCriticalDiagnosticCode(code: string): boolean {
    if (!code) return false;
    
    // Example critical diagnostic codes (would need comprehensive list)
    const criticalCodes = [
      'C', // Cancer codes (ICD-10)
      'I21', // Acute myocardial infarction
      'I46', // Cardiac arrest
      'R57', // Shock
    ];
    
    return criticalCodes.some(criticalCode => code.startsWith(criticalCode));
  }
}