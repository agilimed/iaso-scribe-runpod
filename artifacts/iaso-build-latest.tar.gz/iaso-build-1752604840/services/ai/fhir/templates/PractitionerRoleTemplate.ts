import { BaseResourceTemplate, ResourceChunk, ChunkType, ChunkMetadata } from '../ResourceTemplateService';

export class PractitionerRoleTemplate extends BaseResourceTemplate {
  resourceType = 'PractitionerRole';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'medium';
  chunkTypes: ChunkType[] = ['granular_fact', 'resource_summary', 'ips_summary'];

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    // Granular facts
    if (resource.active !== undefined) {
      chunks.push({
        id: `${resource.id}-active`,
        type: 'granular_fact',
        content: `Role active: ${resource.active ? 'Yes' : 'No'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.period) {
      chunks.push({
        id: `${resource.id}-period`,
        type: 'granular_fact',
        content: `Role period: ${resource.period.start} to ${resource.period.end || 'ongoing'}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.practitioner) {
      chunks.push({
        id: `${resource.id}-practitioner`,
        type: 'granular_fact',
        content: `Practitioner: ${resource.practitioner.display || resource.practitioner.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.organization) {
      chunks.push({
        id: `${resource.id}-organization`,
        type: 'granular_fact',
        content: `Organization: ${resource.organization.display || resource.organization.reference}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    if (resource.code) {
      resource.code.forEach((role: any, index: number) => {
        chunks.push({
          id: `${resource.id}-role-${index}`,
          type: 'granular_fact',
          content: `Role: ${role.text || role.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.specialty) {
      resource.specialty.forEach((spec: any, index: number) => {
        chunks.push({
          id: `${resource.id}-specialty-${index}`,
          type: 'granular_fact',
          content: `Specialty: ${spec.text || spec.coding?.[0]?.display}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.location) {
      resource.location.forEach((loc: any, index: number) => {
        chunks.push({
          id: `${resource.id}-location-${index}`,
          type: 'granular_fact',
          content: `Location: ${loc.display || loc.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.healthcareService) {
      resource.healthcareService.forEach((service: any, index: number) => {
        chunks.push({
          id: `${resource.id}-service-${index}`,
          type: 'granular_fact',
          content: `Healthcare service: ${service.display || service.reference}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.telecom) {
      resource.telecom.forEach((contact: any, index: number) => {
        chunks.push({
          id: `${resource.id}-telecom-${index}`,
          type: 'granular_fact',
          content: `Contact ${contact.system}: ${contact.value} (${contact.use || 'N/A'})`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.availableTime) {
      resource.availableTime.forEach((time: any, index: number) => {
        chunks.push({
          id: `${resource.id}-available-${index}`,
          type: 'granular_fact',
          content: `Available: ${time.daysOfWeek?.join(', ') || 'All days'} ${time.allDay ? 'All day' : `${time.availableStartTime || ''} - ${time.availableEndTime || ''}`}`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.notAvailable) {
      resource.notAvailable.forEach((notAvail: any, index: number) => {
        chunks.push({
          id: `${resource.id}-not-available-${index}`,
          type: 'granular_fact',
          content: `Not available: ${notAvail.description} (${notAvail.during?.start} to ${notAvail.during?.end || 'N/A'})`,
          metadata: this.extractMetadata(resource)
        });
      });
    }
    
    if (resource.availabilityExceptions) {
      chunks.push({
        id: `${resource.id}-exceptions`,
        type: 'granular_fact',
        content: `Availability exceptions: ${resource.availabilityExceptions}`,
        metadata: this.extractMetadata(resource)
      });
    }
    
    // Resource summary
    chunks.push({
      id: `${resource.id}-summary`,
      type: 'resource_summary',
      content: `Practitioner Role: ${resource.practitioner?.display || 'Practitioner'} as ${resource.code?.[0]?.text || 'healthcare provider'} at ${resource.organization?.display || 'organization'} - ${resource.active ? 'Active' : 'Inactive'}`,
      metadata: this.extractMetadata(resource)
    });
    
    // IPS summary
    chunks.push({
      id: `${resource.id}-ips`,
      type: 'ips_summary',
      content: `Healthcare Provider Role: ${resource.code?.[0]?.text || 'N/A'} - ${resource.specialty?.[0]?.text || 'General'}, ${resource.active ? 'Currently active' : 'Not active'}`,
      metadata: this.extractMetadata(resource)
    });
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    const codes = [];
    
    // Extract role codes
    if (resource.code) {
      resource.code.forEach((role: any) => {
        codes.push(...this.extractClinicalCodes(role));
      });
    }
    
    // Extract specialty codes
    if (resource.specialty) {
      resource.specialty.forEach((spec: any) => {
        codes.push(...this.extractClinicalCodes(spec));
      });
    }
    
    return {
      resourceId: resource.id,
      resourceType: this.resourceType,
      lastUpdated: resource.lastUpdated || resource.period?.start,
      clinicalCodes: codes,
      references: [
        ...(resource.practitioner ? [`${resource.practitioner.reference}`] : []),
        ...(resource.organization ? [`${resource.organization.reference}`] : []),
        ...(resource.location ? resource.location.map((l: any) => l.reference) : []),
        ...(resource.healthcareService ? resource.healthcareService.map((s: any) => s.reference) : []),
        ...(resource.endpoint ? resource.endpoint.map((e: any) => e.reference) : [])
      ],
      tags: [
        'practitioner-role',
        'provider-role',
        'healthcare-provider',
        ...(resource.active ? ['active-role'] : ['inactive-role']),
        ...(resource.code ? resource.code.map((c: any) => c.text?.toLowerCase().replace(/\s+/g, '-')).filter(Boolean) : []),
        ...(resource.specialty ? resource.specialty.map((s: any) => s.text?.toLowerCase().replace(/\s+/g, '-')).filter(Boolean) : [])
      ]
    };
  }

  clinicalSignificance(resource: any): 'critical' | 'abnormal' | 'normal' {
    // Inactive roles
    if (!resource.active) return 'abnormal';
    
    // Emergency or critical care roles
    if (resource.code?.some((c: any) => {
      const text = c.text?.toLowerCase() || c.coding?.[0]?.display?.toLowerCase() || '';
      return text.includes('emergency') || text.includes('critical care') || text.includes('trauma');
    })) return 'critical';
    
    // Expired roles
    if (resource.period?.end && new Date(resource.period.end) < new Date()) return 'abnormal';
    
    // Roles with no availability
    if (resource.availableTime?.length === 0 && resource.notAvailable?.length > 0) return 'abnormal';
    
    return 'normal';
  }
}