import { BaseResourceTemplate, ResourceChunk, ChunkMetadata, ClinicalSignificance } from '../ResourceTemplateService';

export class ProcedureTemplate extends BaseResourceTemplate {
  resourceType = 'Procedure';
  priority: 'critical' | 'high' | 'medium' | 'low' = 'high';
  chunkTypes = ['granular_fact', 'resource_summary'] as const;

  generateChunks(resource: any): ResourceChunk[] {
    const chunks: ResourceChunk[] = [];
    
    const procedureSummary = this.generateProcedureSummary(resource);
    chunks.push(this.createChunk(procedureSummary, 'resource_summary', resource, this.clinicalSignificance(resource)));
    
    chunks.push(...this.generateGranularFacts(resource));
    
    return chunks;
  }

  extractMetadata(resource: any): ChunkMetadata {
    return {
      patient_id: this.extractPatientId(resource),
      resource_type: this.resourceType,
      resource_id: resource.id,
      tenant_id: resource.meta?.tenant_id || '',
      clinical_domain: 'procedures',
      clinical_significance: this.clinicalSignificance(resource),
      temporal_context: {
        date: this.extractDate(resource),
        encounter_id: this.extractEncounterId(resource),
        episode_id: this.extractEpisodeId(resource)
      },
      chunk_type: 'resource_summary',
      chunk_level: 'encounter',
      searchable_codes: this.extractProcedureCodes(resource),
      searchable_values: [],
      searchable_units: [],
      reference_ranges: undefined
    };
  }

  clinicalSignificance(resource: any): ClinicalSignificance {
    // Major surgeries are critical
    const procedureCode = resource.code?.coding?.[0]?.code;
    if (procedureCode && this.isMajorSurgery(procedureCode)) {
      return 'critical';
    }
    
    // Emergency procedures
    if (resource.category?.coding?.[0]?.code === 'emergency') {
      return 'critical';
    }
    
    // Invasive procedures might be abnormal
    if (this.isInvasiveProcedure(resource)) {
      return 'abnormal';
    }
    
    return 'normal';
  }

  private generateProcedureSummary(resource: any): string {
    const patientId = this.extractPatientId(resource);
    const procedureName = this.extractProcedureName(resource);
    const performer = this.extractPerformer(resource);
    const date = this.extractDate(resource);
    const status = resource.status || 'unknown';
    
    let summary = `Patient ${patientId} underwent ${procedureName}`;
    
    if (date) {
      summary += ` on ${date}`;
    }
    
    if (performer) {
      summary += ` performed by ${performer}`;
    }
    
    summary += ` - ${status}`;
    
    return summary;
  }

  private generateGranularFacts(resource: any): ResourceChunk[] {
    const facts: ResourceChunk[] = [];
    const significance = this.clinicalSignificance(resource);
    
    // Procedure name
    const procedureName = this.extractProcedureName(resource);
    facts.push(this.createChunk(
      `Procedure: ${procedureName}`,
      'granular_fact',
      resource,
      significance
    ));
    
    // Status
    if (resource.status) {
      facts.push(this.createChunk(
        `Status: ${resource.status}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Category
    if (resource.category) {
      const category = resource.category.coding?.[0]?.display || resource.category.text;
      facts.push(this.createChunk(
        `Category: ${category}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Body site
    if (resource.bodySite?.length > 0) {
      resource.bodySite.forEach((site: any) => {
        const siteDisplay = site.coding?.[0]?.display || site.text;
        facts.push(this.createChunk(
          `Body site: ${siteDisplay}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Outcome
    if (resource.outcome) {
      const outcome = resource.outcome.coding?.[0]?.display || resource.outcome.text;
      facts.push(this.createChunk(
        `Outcome: ${outcome}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Reason
    if (resource.reasonCode?.length > 0) {
      resource.reasonCode.forEach((reason: any) => {
        const reasonDisplay = reason.coding?.[0]?.display || reason.text;
        facts.push(this.createChunk(
          `Reason: ${reasonDisplay}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Performers
    if (resource.performer?.length > 0) {
      resource.performer.forEach((performer: any) => {
        const actor = performer.actor?.display || performer.actor?.reference;
        const function_text = performer.function?.coding?.[0]?.display || 'performer';
        facts.push(this.createChunk(
          `${function_text}: ${actor}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    // Location
    if (resource.location) {
      const location = resource.location.display || resource.location.reference;
      facts.push(this.createChunk(
        `Location: ${location}`,
        'granular_fact',
        resource,
        significance
      ));
    }
    
    // Follow up
    if (resource.followUp?.length > 0) {
      resource.followUp.forEach((followUp: any) => {
        const followUpDisplay = followUp.coding?.[0]?.display || followUp.text;
        facts.push(this.createChunk(
          `Follow up: ${followUpDisplay}`,
          'granular_fact',
          resource,
          significance
        ));
      });
    }
    
    return facts;
  }

  private extractProcedureName(resource: any): string {
    return resource.code?.coding?.[0]?.display || 
           resource.code?.text || 
           'Unknown procedure';
  }

  private extractPerformer(resource: any): string | null {
    if (resource.performer?.length > 0) {
      return resource.performer[0].actor?.display || 
             resource.performer[0].actor?.reference || 
             null;
    }
    return null;
  }

  private extractProcedureCodes(resource: any): string[] {
    const codes: string[] = [];
    
    if (resource.code?.coding) {
      resource.code.coding.forEach((coding: any) => {
        if (coding.code) codes.push(coding.code);
        if (coding.display) codes.push(coding.display.toLowerCase());
      });
    }
    
    if (resource.code?.text) {
      codes.push(resource.code.text.toLowerCase());
    }
    
    return codes;
  }

  private isMajorSurgery(code: string): boolean {
    // Common major surgery codes (simplified)
    const majorSurgeryCodes = [
      // Cardiac procedures
      '33533', '33534', '33535', // CABG
      '33404', '33405', // Aortic valve replacement
      // Neurosurgery
      '61510', '61512', // Craniotomy
      // Orthopedic
      '27447', // Total knee replacement
      '27130', // Total hip replacement
    ];
    
    return majorSurgeryCodes.includes(code);
  }

  private isInvasiveProcedure(resource: any): boolean {
    const category = resource.category?.coding?.[0]?.code;
    return category === 'surgical' || category === 'invasive';
  }
}