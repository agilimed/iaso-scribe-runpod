// Query Complexity Analyzer - Automatically determines SQL generation strategy
export class QueryComplexityAnalyzer {
  
  // Keywords that suggest complex queries needing CTEs
  private static complexityIndicators = {
    multipleConditions: ['both', 'and also', 'as well as', 'combined with', 'together with'],
    aggregations: ['average', 'total', 'count', 'sum', 'group by', 'per', 'by'],
    comparisons: ['more than', 'less than', 'greater than', 'between', 'compare'],
    timeWindows: ['last', 'past', 'recent', 'monthly', 'daily', 'over time'],
    ranking: ['top', 'best', 'worst', 'rank', 'highest', 'lowest', 'most', 'least'],
    multiStep: ['then', 'after that', 'finally', 'first', 'next', 'based on'],
    joins: ['with their', 'including their', 'along with', 'related', 'associated']
  };

  /**
   * Analyzes query complexity and suggests SQL generation approach
   */
  static analyzeQuery(nlQuery: string): {
    complexity: 'simple' | 'medium' | 'complex';
    suggestedApproach: 'direct' | 'cte' | 'multi_cte';
    enhancedPrompt: string;
    hints: string[];
  } {
    const lowerQuery = nlQuery.toLowerCase();
    const hints: string[] = [];
    let complexityScore = 0;

    // Check for complexity indicators
    for (const [category, keywords] of Object.entries(this.complexityIndicators)) {
      for (const keyword of keywords) {
        if (lowerQuery.includes(keyword)) {
          complexityScore++;
          hints.push(category);
        }
      }
    }

    // Determine complexity level
    let complexity: 'simple' | 'medium' | 'complex';
    let suggestedApproach: 'direct' | 'cte' | 'multi_cte';

    if (complexityScore === 0) {
      complexity = 'simple';
      suggestedApproach = 'direct';
    } else if (complexityScore <= 2) {
      complexity = 'medium';
      suggestedApproach = 'cte';
    } else {
      complexity = 'complex';
      suggestedApproach = 'multi_cte';
    }

    // Generate enhanced prompt based on complexity
    const enhancedPrompt = this.enhancePrompt(nlQuery, suggestedApproach, hints);

    return {
      complexity,
      suggestedApproach,
      enhancedPrompt,
      hints
    };
  }

  /**
   * Enhances the prompt with technical hints without user knowing
   */
  private static enhancePrompt(
    originalQuery: string, 
    approach: 'direct' | 'cte' | 'multi_cte',
    hints: string[]
  ): string {
    let enhancement = '';

    switch (approach) {
      case 'cte':
        enhancement = '\n[Use a CTE for better organization]';
        break;
      case 'multi_cte':
        enhancement = '\n[Use multiple CTEs to break down this complex query]';
        break;
    }

    // Add specific hints based on detected patterns
    if (hints.includes('ranking')) {
      enhancement += '\n[Use ROW_NUMBER() or RANK() window functions]';
    }
    if (hints.includes('timeWindows')) {
      enhancement += '\n[Use date functions and intervals]';
    }
    if (hints.includes('aggregations') && hints.includes('multipleConditions')) {
      enhancement += '\n[Consider grouping sets or multiple aggregations]';
    }

    return originalQuery + enhancement;
  }

  /**
   * Converts user-friendly queries to technically enhanced versions
   */
  static convertUserQuery(userQuery: string): string {
    const patterns = [
      // Multi-condition queries
      {
        pattern: /patients? (?:who have|with) (.+) and (?:also have|with) (.+)/i,
        replacement: 'Find patients with both $1 and $2 using appropriate query structure'
      },
      // Ranking queries
      {
        pattern: /(?:show me |find )?(?:the )?top (\d+) (.+)/i,
        replacement: 'Rank and show the top $1 $2 using window functions'
      },
      // Time-based aggregations
      {
        pattern: /(.+) (?:per|by) (month|week|day|year)/i,
        replacement: 'Calculate $1 grouped by $2 using time-based aggregation'
      },
      // Complex conditions
      {
        pattern: /(.+) who (?:have|had) (.+) (?:in the last|over the past) (\d+) (days?|months?|years?)/i,
        replacement: 'Find $1 with $2 within the last $3 $4 using date filtering'
      }
    ];

    let enhancedQuery = userQuery;
    for (const { pattern, replacement } of patterns) {
      enhancedQuery = enhancedQuery.replace(pattern, replacement);
    }

    return enhancedQuery;
  }
}