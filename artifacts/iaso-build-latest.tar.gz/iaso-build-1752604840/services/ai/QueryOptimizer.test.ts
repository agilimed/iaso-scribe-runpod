/**
 * Query Optimizer Test Suite
 */

import { RedisService } from '../cache/RedisService';

import { QueryOptimizer } from './QueryOptimizer';
import { ParsedQuery } from './NLPQueryParser';

// Mock dependencies
jest.mock('../cache/RedisService');
jest.mock('../clickhouse');
jest.mock('../../utils/logger');

describe('QueryOptimizer', () => {
  let queryOptimizer: QueryOptimizer;
  let mockRedis: jest.Mocked<RedisService>;

  beforeEach(() => {
    // Clear all mocks
    jest.clearAllMocks();
    
    // Create instance
    queryOptimizer = new QueryOptimizer();
    mockRedis = (queryOptimizer as any).redis;
  });

  describe('optimizeQuery', () => {
    const mockParsedQuery: ParsedQuery = {
      originalQuery: 'How many patients were admitted today?',
      intent: {
        type: 'aggregation',
        subType: 'count',
        confidence: 0.95
      },
      entities: [
        { type: 'resource', value: 'Patient', text: 'patients' }
      ],
      timeRange: {
        start: new Date('2024-01-01'),
        end: new Date('2024-01-01')
      },
      resourceTypes: ['Patient']
    };

    const mockSQL = 'SELECT COUNT(*) FROM fhir_events WHERE resource_type = \'Patient\'';

    it('should return cached result when available', async () => {
      // Mock cache hit
      mockRedis.exists.mockResolvedValue(true);

      const result = await queryOptimizer.optimizeQuery(
        mockParsedQuery,
        mockSQL,
        { tenantId: 'test-tenant', userId: 'test-user' }
      );

      expect(result.executionPlan.strategy).toBe('cache');
      expect(result.estimatedCost).toBe(0.1);
    });

    it('should optimize query with materialized view', async () => {
      // Mock cache miss
      mockRedis.exists.mockResolvedValue(false);
      
      const dailyQuery: ParsedQuery = {
        ...mockParsedQuery,
        intent: { type: 'aggregation', subType: 'count', confidence: 0.9 },
        resourceTypes: ['Encounter'],
        timeRange: { period: 'day' }
      };

      const result = await queryOptimizer.optimizeQuery(
        dailyQuery,
        'SELECT COUNT(*) FROM fhir_events',
        { tenantId: 'test-tenant' }
      );

      expect(result.executionPlan.strategy).toBe('materialized_view');
      expect(result.optimizedSQL).toContain('mv_daily_encounters');
    });

    it('should add sampling for large trend queries', async () => {
      mockRedis.exists.mockResolvedValue(false);
      
      const trendQuery: ParsedQuery = {
        ...mockParsedQuery,
        intent: { type: 'trend', subType: null, confidence: 0.9 }
      };

      const result = await queryOptimizer.optimizeQuery(
        trendQuery,
        'SELECT * FROM large_table',
        {}
      );

      // Check if optimization was applied
      expect(result.optimizedSQL).toContain('SAMPLE');
    });
  });

  describe('cacheQueryResult', () => {
    it('should cache query results with appropriate TTL', async () => {
      mockRedis.setex.mockResolvedValue(true);

      const mockResult = [{ count: 100 }];
      const success = await queryOptimizer.cacheQueryResult(
        'test-cache-key',
        mockResult,
        {
          ...mockParsedQuery,
          intent: { type: 'metric', subType: null, confidence: 0.9 }
        } as ParsedQuery
      );

      expect(success).toBe(true);
      expect(mockRedis.setex).toHaveBeenCalledWith(
        'query_result:test-cache-key',
        900, // 15 minutes for metric queries
        expect.any(String)
      );
    });

    it('should handle cache failures gracefully', async () => {
      mockRedis.setex.mockRejectedValue(new Error('Redis error'));

      const success = await queryOptimizer.cacheQueryResult(
        'test-cache-key',
        [],
        mockParsedQuery
      );

      expect(success).toBe(false);
    });
  });

  describe('getCachedResult', () => {
    it('should return cached data when valid', async () => {
      const cachedData = {
        result: [{ count: 50 }],
        cachedAt: new Date().toISOString(),
        ttl: 300
      };
      
      mockRedis.get.mockResolvedValue(JSON.stringify(cachedData));

      const result = await queryOptimizer.getCachedResult('test-key');
      
      expect(result).toEqual(cachedData.result);
    });

    it('should return null for expired cache', async () => {
      const expiredData = {
        result: [{ count: 50 }],
        cachedAt: new Date(Date.now() - 600000).toISOString(), // 10 minutes ago
        ttl: 300 // 5 minute TTL
      };
      
      mockRedis.get.mockResolvedValue(JSON.stringify(expiredData));
      mockRedis.delete.mockResolvedValue(true);

      const result = await queryOptimizer.getCachedResult('test-key');
      
      expect(result).toBeNull();
      expect(mockRedis.delete).toHaveBeenCalledWith('query_result:test-key');
    });
  });

  describe('invalidateCache', () => {
    it('should invalidate matching cache entries', async () => {
      mockRedis.keys.mockResolvedValue([
        'query_result:abc123',
        'query_result:def456'
      ]);
      mockRedis.delete.mockResolvedValue(true);

      const count = await queryOptimizer.invalidateCache(['Patient']);
      
      expect(count).toBe(2);
      expect(mockRedis.delete).toHaveBeenCalledTimes(2);
    });
  });

  describe('getCacheStatistics', () => {
    it('should return cache statistics by intent type', async () => {
      mockRedis.hget
        .mockResolvedValueOnce('100') // hits
        .mockResolvedValueOnce('50')  // misses
        .mockResolvedValueOnce('10'); // expired

      const stats = await queryOptimizer.getCacheStatistics();
      
      expect(stats.aggregation).toBeDefined();
      expect(stats.aggregation.hits).toBe(100);
      expect(stats.aggregation.misses).toBe(50);
      expect(stats.aggregation.hitRate).toBe('66.67');
    });
  });

  describe('Query Optimization Suggestions', () => {
    it('should suggest materialized view for slow queries', async () => {
      mockRedis.exists.mockResolvedValue(false);
      
      const slowQuery: ParsedQuery = {
        ...mockParsedQuery,
        intent: { type: 'aggregation', subType: 'complex', confidence: 0.9 }
      };

      const result = await queryOptimizer.optimizeQuery(
        slowQuery,
        'SELECT complex_aggregation FROM large_table',
        {}
      );

      const mvSuggestion = result.suggestions.find(s => s.type === 'materialized_view');
      expect(mvSuggestion).toBeDefined();
      expect(mvSuggestion?.impact).toBe('high');
    });

    it('should suggest time range filter when missing', async () => {
      mockRedis.exists.mockResolvedValue(false);
      
      const queryWithoutTime: ParsedQuery = {
        ...mockParsedQuery,
        timeRange: undefined
      };

      const result = await queryOptimizer.optimizeQuery(
        queryWithoutTime,
        'SELECT * FROM events',
        {}
      );

      const timeSuggestion = result.suggestions.find(s => 
        s.description.includes('time range')
      );
      expect(timeSuggestion).toBeDefined();
    });
  });
});