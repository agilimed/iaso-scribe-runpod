import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import pinoHttp from 'pino-http';
import { rateLimit } from 'express-rate-limit';
import { EmbeddingService } from './services/EmbeddingService';
import { HealthCheckService } from './services/HealthCheckService';
import { logger } from './utils/logger';
import { config } from './config';

async function startServer() {
  const app = express();
  
  // Security middleware
  app.use(helmet());
  app.use(cors({
    origin: config.corsOrigins,
    credentials: true
  }));
  
  // Rate limiting
  const limiter = rateLimit({
    windowMs: 60 * 1000, // 1 minute
    max: 100, // 100 requests per minute
    message: 'Too many requests from this IP'
  });
  app.use('/api/', limiter);
  
  // Logging
  app.use(pinoHttp({ logger }));
  
  // Body parsing
  app.use(express.json({ limit: '10mb' }));
  
  // Initialize services
  const embeddingService = new EmbeddingService();
  const healthCheckService = new HealthCheckService(embeddingService);
  
  // Wait for models to load
  logger.info('Initializing embedding models...');
  await embeddingService.initialize();
  logger.info('Embedding models loaded successfully');
  
  // Health check endpoints
  app.get('/health', (_req, res) => {
    const health = healthCheckService.getHealth();
    res.status(health.status === 'healthy' ? 200 : 503).json(health);
  });
  
  app.get('/ready', async (_req, res) => {
    const readiness = await healthCheckService.checkReadiness();
    res.status(readiness.ready ? 200 : 503).json(readiness);
  });
  
  // Embedding endpoints
  app.post('/api/v1/embed', async (req, res) => {
    try {
      const { text, texts, model } = req.body;
      
      if (!text && !texts) {
        res.status(400).json({ 
          error: 'Either "text" or "texts" field is required' 
        });
        return;
      }
      
      const startTime = Date.now();
      let embeddings;
      
      if (text) {
        embeddings = await embeddingService.embed(text, model);
      } else {
        embeddings = await embeddingService.embedBatch(texts, model);
      }
      
      const duration = Date.now() - startTime;
      
      res.json({
        embeddings,
        model: model || embeddingService.getActiveModel(),
        dimensions: Array.isArray(embeddings) && embeddings.length > 0 ? 
          (Array.isArray(embeddings[0]) ? embeddings[0].length : embeddings.length) : 0,
        duration_ms: duration
      });
    } catch (error) {
      logger.error('Embedding error:', error);
      res.status(500).json({ 
        error: 'Internal server error', 
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Model management endpoints
  app.get('/api/v1/models', (_req, res) => {
    res.json({
      models: embeddingService.getAvailableModels(),
      active: embeddingService.getActiveModel()
    });
  });
  
  app.post('/api/v1/models/:model/activate', async (req, res) => {
    try {
      const { model } = req.params;
      await embeddingService.switchModel(model);
      res.json({ 
        message: 'Model activated successfully',
        model 
      });
    } catch (error) {
      res.status(400).json({ 
        error: 'Failed to activate model',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Benchmark endpoint
  app.post('/api/v1/benchmark', async (req, res) => {
    try {
      const { samples = 100 } = req.body;
      const results = await embeddingService.benchmark(samples);
      res.json(results);
    } catch (error) {
      res.status(500).json({ 
        error: 'Benchmark failed',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Start server
  const port = config.port;
  app.listen(port, '0.0.0.0', () => {
    logger.info(`Embedding service listening on port ${port}`);
    logger.info(`Active model: ${embeddingService.getActiveModel()}`);
    logger.info(`Available models: ${embeddingService.getAvailableModels().join(', ')}`);
  });
  
  // Graceful shutdown
  process.on('SIGTERM', async () => {
    logger.info('SIGTERM received, shutting down gracefully...');
    await embeddingService.shutdown();
    process.exit(0);
  });
}

// Start the server
startServer().catch(error => {
  logger.error('Failed to start server:', error);
  process.exit(1);
});