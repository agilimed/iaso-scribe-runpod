import { pipeline } from '@xenova/transformers';
import NodeCache from 'node-cache';
import PQueue from 'p-queue';
import { logger } from '../utils/logger';
import { config } from '../config';

interface EmbeddingModel {
  name: string;
  pipeline: any | null;
  dimensions: number;
  description: string;
  initialized: boolean;
}

export class EmbeddingService {
  private models: Map<string, EmbeddingModel>;
  private activeModel: string;
  private cache: NodeCache;
  private queue: PQueue;
  
  constructor() {
    this.models = new Map();
    this.activeModel = config.defaultModel;
    this.cache = new NodeCache({ 
      stdTTL: config.cacheTTL,
      checkperiod: 600 
    });
    this.queue = new PQueue({ 
      concurrency: config.maxConcurrentRequests 
    });
    
    // Define available models
    this.registerModels();
  }
  
  private registerModels() {
    // General purpose model - fast and good quality
    this.models.set('all-MiniLM-L6-v2', {
      name: 'Xenova/all-MiniLM-L6-v2',
      pipeline: null,
      dimensions: 384,
      description: 'General purpose, fast, good quality',
      initialized: false
    });
    
    // Medical/Scientific model
    this.models.set('biobert-base', {
      name: 'dmis-lab/biobert-base-cased-v1.1',
      pipeline: null,
      dimensions: 768,
      description: 'Optimized for biomedical text',
      initialized: false
    });
    
    // Multilingual model
    this.models.set('multilingual-e5-base', {
      name: 'intfloat/multilingual-e5-base',
      pipeline: null,
      dimensions: 768,
      description: 'Multilingual support',
      initialized: false
    });
    
    // High quality model
    this.models.set('bge-base-en', {
      name: 'BAAI/bge-base-en-v1.5',
      pipeline: null,
      dimensions: 768,
      description: 'High quality, slower',
      initialized: false
    });
    
    // Small fast model
    this.models.set('all-MiniLM-L12-v2', {
      name: 'Xenova/all-MiniLM-L12-v2',
      pipeline: null,
      dimensions: 384,
      description: 'Balanced speed and quality',
      initialized: false
    });
  }
  
  async initialize(): Promise<void> {
    // Load the default model
    await this.loadModel(this.activeModel);
  }
  
  private async loadModel(modelKey: string): Promise<void> {
    const model = this.models.get(modelKey);
    if (!model) {
      throw new Error(`Unknown model: ${modelKey}`);
    }
    
    if (model.initialized) {
      return;
    }
    
    try {
      logger.info(`Loading model: ${modelKey} (${model.name})`);
      const startTime = Date.now();
      
      model.pipeline = await pipeline(
        'feature-extraction',
        model.name,
        {
          cache_dir: config.modelCachePath,
          local_files_only: false,
          progress_callback: (progress: any) => {
            if (progress.status === 'download') {
              logger.info(`Downloading ${progress.file}: ${progress.progress}%`);
            }
          }
        }
      );
      
      model.initialized = true;
      const duration = Date.now() - startTime;
      logger.info(`Model ${modelKey} loaded in ${duration}ms`);
    } catch (error) {
      logger.error(`Failed to load model ${modelKey}:`, error);
      throw error;
    }
  }
  
  async embed(text: string, modelKey?: string): Promise<number[]> {
    const key = modelKey || this.activeModel;
    
    // Check cache
    if (config.cacheEnabled) {
      const cacheKey = `${key}:${text}`;
      const cached = this.cache.get<number[]>(cacheKey);
      if (cached) {
        return cached;
      }
    }
    
    // Queue the embedding task
    const embedding = await this.queue.add(async () => {
      const result = await this._embed(text, key);
      
      // Cache the result
      if (config.cacheEnabled) {
        const cacheKey = `${key}:${text}`;
        this.cache.set(cacheKey, result);
      }
      
      return result;
    });
    
    return embedding || [];
  }
  
  async embedBatch(texts: string[], modelKey?: string): Promise<number[][]> {
    const key = modelKey || this.activeModel;
    const batches = this.createBatches(texts, config.maxBatchSize);
    const results: number[][] = [];
    
    for (const batch of batches) {
      const batchEmbeddings = await Promise.all(
        batch.map(text => this.embed(text, key))
      );
      results.push(...batchEmbeddings);
    }
    
    return results;
  }
  
  private async _embed(text: string, modelKey: string): Promise<number[]> {
    const model = this.models.get(modelKey);
    if (!model || !model.initialized) {
      await this.loadModel(modelKey);
    }
    
    const pipeline = this.models.get(modelKey)!.pipeline;
    if (!pipeline) {
      throw new Error(`Model ${modelKey} not loaded`);
    }
    
    try {
      const output = await pipeline(text, {
        pooling: 'mean',
        normalize: true
      });
      
      // Convert to array
      return Array.from(output.data);
    } catch (error) {
      logger.error(`Embedding failed for model ${modelKey}:`, error);
      throw error;
    }
  }
  
  private createBatches<T>(items: T[], batchSize: number): T[][] {
    const batches: T[][] = [];
    for (let i = 0; i < items.length; i += batchSize) {
      batches.push(items.slice(i, i + batchSize));
    }
    return batches;
  }
  
  async switchModel(modelKey: string): Promise<void> {
    if (!this.models.has(modelKey)) {
      throw new Error(`Unknown model: ${modelKey}`);
    }
    
    await this.loadModel(modelKey);
    this.activeModel = modelKey;
    
    // Clear cache when switching models
    this.cache.flushAll();
    
    logger.info(`Switched to model: ${modelKey}`);
  }
  
  getAvailableModels(): string[] {
    return Array.from(this.models.keys());
  }
  
  getActiveModel(): string {
    return this.activeModel;
  }
  
  getModelInfo(modelKey: string): EmbeddingModel | undefined {
    return this.models.get(modelKey);
  }
  
  async benchmark(samples: number = 100): Promise<any> {
    const testTexts = [
      'Patient has diabetes mellitus type 2',
      'SELECT * FROM fhir_current WHERE resource_type = "Patient"',
      'Blood glucose level is 126 mg/dL',
      'The patient was admitted to the emergency department',
      'JSONExtractString(resource, "birthDate")'
    ];
    
    const results: any = {};
    
    for (const [modelKey, model] of this.models) {
      if (!model.initialized) {
        await this.loadModel(modelKey);
      }
      
      let totalTime = 0;
      
      for (let i = 0; i < samples; i++) {
        const text = testTexts[i % testTexts.length];
        const embedStart = Date.now();
        await this._embed(text, modelKey);
        totalTime += Date.now() - embedStart;
      }
      
      results[modelKey] = {
        totalTime,
        avgTime: totalTime / samples,
        dimensions: model.dimensions,
        description: model.description
      };
    }
    
    return results;
  }
  
  async shutdown(): Promise<void> {
    // Clear cache
    this.cache.flushAll();
    
    // Clear queue
    this.queue.clear();
    
    logger.info('Embedding service shutdown complete');
  }
}