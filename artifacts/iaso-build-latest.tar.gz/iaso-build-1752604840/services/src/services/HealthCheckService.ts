import { EmbeddingService } from './EmbeddingService';
import { logger } from '../utils/logger';

interface HealthStatus {
  status: 'healthy' | 'unhealthy';
  timestamp: string;
  uptime: number;
  checks: {
    models: boolean;
    memory: boolean;
    cache: boolean;
  };
  details: {
    activeModel: string;
    availableModels: string[];
    memoryUsage: NodeJS.MemoryUsage;
  };
}

export class HealthCheckService {
  private startTime: Date;
  
  constructor(private embeddingService: EmbeddingService) {
    this.startTime = new Date();
  }
  
  getHealth(): HealthStatus {
    const memoryUsage = process.memoryUsage();
    const uptime = Date.now() - this.startTime.getTime();
    
    // Check if memory usage is reasonable (< 4GB)
    const memoryHealthy = memoryUsage.heapUsed < 4 * 1024 * 1024 * 1024;
    
    // Check if models are loaded
    const modelsHealthy = this.embeddingService.getAvailableModels().length > 0;
    
    const allHealthy = memoryHealthy && modelsHealthy;
    
    return {
      status: allHealthy ? 'healthy' : 'unhealthy',
      timestamp: new Date().toISOString(),
      uptime,
      checks: {
        models: modelsHealthy,
        memory: memoryHealthy,
        cache: true // Cache is always healthy if service is running
      },
      details: {
        activeModel: this.embeddingService.getActiveModel(),
        availableModels: this.embeddingService.getAvailableModels(),
        memoryUsage
      }
    };
  }
  
  async checkReadiness(): Promise<{ ready: boolean; message: string }> {
    try {
      // Try to generate an embedding
      const testText = 'health check';
      const embedding = await this.embeddingService.embed(testText);
      
      if (embedding && embedding.length > 0) {
        return { 
          ready: true, 
          message: 'Service is ready' 
        };
      }
      
      return { 
        ready: false, 
        message: 'Embedding generation failed' 
      };
    } catch (error) {
      logger.error('Readiness check failed:', error);
      return { 
        ready: false, 
        message: `Error: ${error instanceof Error ? error.message : 'Unknown error'}` 
      };
    }
  }
}