#!/usr/bin/env node

import { EmbeddingService } from '../services/EmbeddingService';
import { logger } from '../utils/logger';

const testSentences = [
  // Medical sentences
  'Patient presents with acute myocardial infarction and elevated troponin levels',
  'Diabetes mellitus type 2 with peripheral neuropathy',
  'Blood glucose level measured at 126 mg/dL fasting',
  
  // FHIR/Technical sentences  
  'SELECT * FROM fhir_current WHERE resource_type = "Observation"',
  'JSONExtractString(resource, "code.coding[0].code") = "2339-0"',
  'Patient.identifier[0].value matches the MRN pattern',
  
  // Mixed medical-technical
  'Query all Observation resources with LOINC code 718-7 for hemoglobin',
  'Extract patient demographics from FHIR Patient resource JSON',
  'Filter encounters by admission date using period.start field'
];

async function runBenchmark() {
  logger.info('Starting embedding service benchmark...\n');
  
  const embeddingService = new EmbeddingService();
  await embeddingService.initialize();
  
  const models = embeddingService.getAvailableModels();
  
  logger.info(`Testing ${models.length} models with ${testSentences.length} sentences\n`);
  
  const results: any[] = [];
  
  for (const model of models) {
    logger.info(`\nBenchmarking model: ${model}`);
    
    try {
      // Switch to model
      await embeddingService.switchModel(model);
      const modelInfo = embeddingService.getModelInfo(model);
      
      // Warm up
      await embeddingService.embed('warm up');
      
      // Single embedding test
      const singleTimes: number[] = [];
      for (const sentence of testSentences) {
        const start = Date.now();
        await embeddingService.embed(sentence);
        singleTimes.push(Date.now() - start);
      }
      
      // Batch embedding test
      const batchStart = Date.now();
      await embeddingService.embedBatch(testSentences);
      const batchTime = Date.now() - batchStart;
      
      // Calculate stats
      const avgSingle = singleTimes.reduce((a, b) => a + b, 0) / singleTimes.length;
      const minSingle = Math.min(...singleTimes);
      const maxSingle = Math.max(...singleTimes);
      
      const result = {
        model,
        dimensions: modelInfo?.dimensions,
        description: modelInfo?.description,
        singleEmbedding: {
          avg: Math.round(avgSingle),
          min: minSingle,
          max: maxSingle
        },
        batchEmbedding: {
          total: batchTime,
          perItem: Math.round(batchTime / testSentences.length)
        },
        throughput: {
          singlePerSecond: Math.round(1000 / avgSingle),
          batchPerSecond: Math.round((testSentences.length * 1000) / batchTime)
        }
      };
      
      results.push(result);
      
      logger.info(`  Avg single: ${result.singleEmbedding.avg}ms`);
      logger.info(`  Batch total: ${result.batchEmbedding.total}ms`);
      logger.info(`  Throughput: ${result.throughput.batchPerSecond} embeddings/sec`);
      
    } catch (error) {
      logger.error(`Failed to benchmark ${model}:`, error);
    }
  }
  
  // Summary
  logger.info('\n\n=== BENCHMARK SUMMARY ===\n');
  
  // Sort by throughput
  results.sort((a, b) => b.throughput.batchPerSecond - a.throughput.batchPerSecond);
  
  logger.info('Performance ranking (by batch throughput):');
  results.forEach((result, index) => {
    logger.info(`\n${index + 1}. ${result.model}`);
    logger.info(`   Dimensions: ${result.dimensions}`);
    logger.info(`   Single embedding: ${result.singleEmbedding.avg}ms avg`);
    logger.info(`   Batch throughput: ${result.throughput.batchPerSecond} embeddings/sec`);
    logger.info(`   Description: ${result.description}`);
  });
  
  // Recommendations
  logger.info('\n\n=== RECOMMENDATIONS ===\n');
  
  const fastest = results[0];
  logger.info(`Fastest: ${fastest.model}`);
  logger.info(`  - Use for real-time queries`);
  logger.info(`  - ${fastest.throughput.batchPerSecond} embeddings/sec\n`);
  
  const medical = results.find(r => r.model.includes('biobert'));
  if (medical) {
    logger.info(`Best for medical text: ${medical.model}`);
    logger.info(`  - Use for clinical notes and medical terminology`);
    logger.info(`  - ${medical.throughput.batchPerSecond} embeddings/sec\n`);
  }
  
  const highQuality = results.find(r => r.model.includes('bge'));
  if (highQuality) {
    logger.info(`Highest quality: ${highQuality.model}`);
    logger.info(`  - Use for initial document indexing`);
    logger.info(`  - ${highQuality.throughput.batchPerSecond} embeddings/sec`);
  }
}

// Run if called directly
if (require.main === module) {
  runBenchmark().catch(error => {
    logger.error('Benchmark failed:', error);
    process.exit(1);
  });
}