#!/usr/bin/env node

import { pipeline } from '@xenova/transformers';
import { logger } from '../utils/logger';
import { config } from '../config';
import fs from 'fs/promises';
import path from 'path';

const models = [
  {
    key: 'all-MiniLM-L6-v2',
    name: 'Xenova/all-MiniLM-L6-v2',
    description: 'General purpose embeddings (384 dims)'
  },
  {
    key: 'biobert-base',
    name: 'dmis-lab/biobert-base-cased-v1.1',
    description: 'Medical/biomedical embeddings (768 dims)'
  },
  {
    key: 'bge-base-en',
    name: 'BAAI/bge-base-en-v1.5',
    description: 'High quality embeddings (768 dims)'
  }
];

async function downloadModels() {
  logger.info('Starting model download...');
  logger.info(`Models will be cached in: ${config.modelCachePath}`);
  
  // Ensure cache directory exists
  await fs.mkdir(config.modelCachePath, { recursive: true });
  
  for (const model of models) {
    logger.info(`\nDownloading ${model.key}: ${model.description}`);
    
    try {
      const startTime = Date.now();
      
      // Download and initialize the model
      await pipeline(
        'feature-extraction',
        model.name,
        {
          cache_dir: config.modelCachePath,
          local_files_only: false,
          progress_callback: (progress: any) => {
            if (progress.status === 'download' && progress.file) {
              const percent = Math.round(progress.progress || 0);
              process.stdout.write(`\r  Downloading ${progress.file}: ${percent}%`);
            } else if (progress.status === 'done') {
              process.stdout.write('\n');
            }
          }
        }
      );
      
      const duration = Date.now() - startTime;
      logger.info(`✓ ${model.key} downloaded successfully in ${(duration / 1000).toFixed(1)}s`);
      
    } catch (error) {
      logger.error(`✗ Failed to download ${model.key}:`, error);
    }
  }
  
  // List downloaded models
  logger.info('\n\nDownloaded models:');
  const modelPath = path.join(config.modelCachePath, 'models--Xenova');
  try {
    const files = await fs.readdir(modelPath);
    for (const file of files) {
      const stats = await fs.stat(path.join(modelPath, file));
      if (stats.isDirectory()) {
        logger.info(`  - ${file}`);
      }
    }
  } catch (error) {
    logger.warn('Could not list model directory');
  }
  
  logger.info('\nModel download complete!');
  logger.info('You can now start the embedding service.');
}

// Run if called directly
if (require.main === module) {
  downloadModels().catch(error => {
    logger.error('Download failed:', error);
    process.exit(1);
  });
}

export { downloadModels };