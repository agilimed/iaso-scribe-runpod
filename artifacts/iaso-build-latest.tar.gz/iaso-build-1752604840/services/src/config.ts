import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

export const config = {
  port: parseInt(process.env.PORT || '8090', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  
  // CORS configuration
  corsOrigins: process.env.CORS_ORIGINS?.split(',') || [
    'http://localhost:3000',
    'http://localhost:3003'
  ],
  
  // Model configuration
  defaultModel: process.env.DEFAULT_MODEL || 'all-MiniLM-L6-v2',
  modelCachePath: process.env.MODEL_CACHE_PATH || './models',
  
  // Performance settings
  maxBatchSize: parseInt(process.env.MAX_BATCH_SIZE || '100', 10),
  cacheEnabled: process.env.CACHE_ENABLED !== 'false',
  cacheTTL: parseInt(process.env.CACHE_TTL || '3600', 10), // 1 hour
  
  // Resource limits
  maxConcurrentRequests: parseInt(process.env.MAX_CONCURRENT_REQUESTS || '10', 10),
  requestTimeout: parseInt(process.env.REQUEST_TIMEOUT || '30000', 10), // 30 seconds
  
  // Monitoring
  metricsEnabled: process.env.METRICS_ENABLED === 'true',
  logLevel: process.env.LOG_LEVEL || 'info'
};